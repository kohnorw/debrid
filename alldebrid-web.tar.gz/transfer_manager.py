"""
AllDebrid transfer manager — tracks torrent state using SQLite.

States:
  queued      → just received, not yet processed
  cached      → AllDebrid has it cached (ready field = true), ready to stream
  downloading → not cached, magnet uploaded to AllDebrid, polling status
  complete    → transfer finished downloading, ready to stream
  error       → something went wrong

File lists and CDN URLs are stored persistently in the `files` table.
AllDebrid's link/unlock is called once per file when first needed, then only
again when a CDN URL actually expires (403/410) during playback.

AllDebrid rate limit: 250 requests/minute (enforced via sliding-window
token bucket in app._ad_api_acquire — all API calls route through there).
"""

import hashlib
import hmac as _hmac
import logging
import os
import re
import secrets as _secrets
import sqlite3
import threading
import time
import urllib.parse

import requests

log = logging.getLogger(__name__)

# ── AllDebrid API endpoints ───────────────────────────────────────────────────
AD_BASE    = "https://api.alldebrid.com/v4"
AD_UPLOAD  = f"{AD_BASE}/magnet/upload"
AD_DELETE  = f"{AD_BASE}/magnet/delete"
AD_STATUS  = "https://api.alldebrid.com/v4.1/magnet/status"
AD_FILES   = f"{AD_BASE}/magnet/files"
AD_UNLOCK  = f"{AD_BASE}/link/unlock"

# CDN URL lifetime: AllDebrid links last at least 48h in practice.
# We store them and only refresh after expiry (403/410 during real playback).
CDN_TTL        = 172800   # 48 h
REFRESH_MARGIN = 3600     # start background refresh 1 h before expiry

# ── HTTP / retry params ───────────────────────────────────────────────────────
READ_TIMEOUT      = int(os.environ.get("FUSE_READ_TIMEOUT", "10"))
READ_MAX_ATTEMPTS = 5
READ_BACKOFF_BASE = 0.5
READ_BACKOFF_CAP  = 4.0

POLL_INTERVAL = 15   # seconds between polling downloading transfers

# How often to check AllDebrid's full magnet library for anything added
# outside this app (website, mobile app, other tools). Kept fairly long
# since this fetches the ENTIRE account library in one call every time —
# no incremental/delta mode is used here (that exists via Live Mode's
# session+counter, but adds real complexity for relatively low value at
# this poll frequency).
LIBRARY_SYNC_INTERVAL = int(os.environ.get("AD_LIBRARY_SYNC_INTERVAL", "300"))  # 5 min

# How many per-folder Plex "refresh this path" requests to fire concurrently
# during a partial/missing-only scan. Plex itself, not AllDebrid's rate
# limiter, is the ceiling here — these are local HTTP calls to your own Plex
# server, not AllDebrid's API — so this can be raised well above
# FUSE_DIRECTDL_WORKERS if your Plex server handles it comfortably.
PLEX_SCAN_WORKERS = int(os.environ.get("PLEX_SCAN_WORKERS", "8"))

# How often to cross-check the whole cached/complete library against
# AllDebrid's live magnet list and re-add anything that's vanished (cache
# eviction, DMCA takedown, etc). Cheap to run often — one _ad_all_magnets
# call covers the whole account; per-transfer API calls only happen for
# transfers that are ACTUALLY missing, which should normally be zero.
MISSING_REPAIR_INTERVAL = int(os.environ.get("AD_MISSING_REPAIR_INTERVAL", str(12 * 3600)))  # 12h

DB_PATH = os.environ.get("DB_PATH", "/app/alldebrid.db")

# ── Stream token (shared with app.py) ─────────────────────────────────────────
_TOKEN_SECRET: str = ""

def _get_token_secret() -> str:
    global _TOKEN_SECRET
    if _TOKEN_SECRET:
        return _TOKEN_SECRET
    try:
        import sys as _sys
        _app = _sys.modules.get("app") or _sys.modules.get("__main__")
        _load  = getattr(_app, "_load_config",  None)
        _save  = getattr(_app, "_save_config",  None)
        if not _load:
            return _secrets.token_hex(32)
        cfg = _load()
        if "token_secret" not in cfg:
            cfg["token_secret"] = _secrets.token_hex(32)
            if _save:
                _save(cfg)
        _TOKEN_SECRET = cfg["token_secret"]
    except Exception:
        _TOKEN_SECRET = _secrets.token_hex(32)
    return _TOKEN_SECRET

def _make_stream_token(hash_: str, filename: str) -> str:
    secret  = _get_token_secret()
    return _hmac.new(secret.encode(), f"{hash_}:{filename}".encode(), "sha256").hexdigest()

# ── AllDebrid API helpers (rate-limited via app._ad_api_acquire) ──────────────

# AllDebrid requires an `agent` query parameter on EVERY v4 endpoint (it's
# marked required:true in their OpenAPI spec, and AUTH_MISSING_AGENT is a
# real error code) — without it, calls fail even with a valid apikey.
AD_AGENT = os.environ.get("ALLDEBRID_AGENT", "alldebrid-web")

def _ad_headers(api_key: str) -> dict:
    return {"Authorization": f"Bearer {api_key}"}

def _ad_acquire():
    """Route through app._ad_api_acquire so all calls share one 250 req/min bucket."""
    try:
        import sys as _sys
        _app = _sys.modules.get("app") or _sys.modules.get("__main__")
        acquire = getattr(_app, "_ad_api_acquire", None)
        if acquire:
            acquire()
            return
    except Exception:
        pass
    time.sleep(0.25)   # fallback: 4 req/s if app not available

def _ad_post(api_key: str, url: str, pairs: list) -> dict:
    _ad_acquire()
    try:
        all_pairs = [("agent", AD_AGENT)] + list(pairs)
        r = requests.post(
            url,
            headers={**_ad_headers(api_key), "Content-Type": "application/x-www-form-urlencoded"},
            data=urllib.parse.urlencode(all_pairs),
            timeout=20,
        )
        if r.status_code >= 400:
            try:
                body = r.json()
            except Exception:
                body = r.text[:200]
            log.warning(f"[ad-post] {url} -> HTTP {r.status_code}: {body}")
            return body if isinstance(body, dict) else {}
        return r.json()
    except Exception as e:
        log.warning(f"[ad-post] {url}: {e}")
        return {}

def _ad_get(api_key: str, url: str, params: dict | None = None) -> dict:
    _ad_acquire()
    try:
        merged = {"agent": AD_AGENT}
        if params:
            merged.update(params)
        r = requests.get(url, headers=_ad_headers(api_key), params=merged, timeout=20)
        if r.status_code >= 400:
            try:
                body = r.json()
            except Exception:
                body = r.text[:200]
            log.warning(f"[ad-get] {url} -> HTTP {r.status_code}: {body}")
            return body if isinstance(body, dict) else {}
        return r.json()
    except Exception as e:
        log.warning(f"[ad-get] {url}: {e}")
        return {}

def _ad_upload_magnet(api_key: str, hash_: str, name: str) -> dict:
    """Upload a magnet to AllDebrid. Returns the response dict."""
    magnet = f"magnet:?xt=urn:btih:{hash_.lower()}&dn={urllib.parse.quote(name or '', safe='')}"
    return _ad_post(api_key, AD_UPLOAD, [("magnets[]", magnet)])

def _ad_delete_magnet(api_key: str, magnet_id: int):
    """Remove a magnet from AllDebrid library."""
    _ad_post(api_key, AD_DELETE, [("id", magnet_id)])

def _ad_unlock_link(api_key: str, link: str) -> str | None:
    """Unlock a single AllDebrid download link. Returns the direct CDN URL."""
    data = _ad_get(api_key, AD_UNLOCK, params={"link": link})
    return data.get("data", {}).get("link")

def _ad_get_files(api_key: str, magnet_id: int) -> list:
    """Fetch the file list for an uploaded AllDebrid magnet ID."""
    data = _ad_get(api_key, AD_FILES, params={"id[]": magnet_id})
    raw  = data.get("data", {}).get("magnets", [])
    files = []
    VIDEO_EXTS = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts", ".wmv", ".flv", ".webm"}
    def _collect(node):
        if isinstance(node, list):
            for item in node:
                _collect(item)
        elif isinstance(node, dict):
            if node.get("l"):
                name = node.get("n", "")
                ext  = os.path.splitext(name)[1].lower()
                files.append({
                    "name":     name,
                    "path":     name,
                    "size":     int(node.get("s", 0) or 0),
                    "link":     node["l"],
                    "is_video": ext in VIDEO_EXTS,
                })
            if node.get("e"):
                _collect(node["e"])
    for m in raw:
        _collect(m.get("files", []))
    return files

def _ad_magnet_status(api_key: str, magnet_id: int) -> dict:
    """Get status for a single uploaded magnet."""
    data = _ad_get(api_key, AD_STATUS, params={"id[]": magnet_id})
    magnets = data.get("data", {}).get("magnets", [])
    return magnets[0] if magnets else {}

def _ad_all_magnets(api_key: str) -> list:
    """Fetch every magnet currently in the AllDebrid account.

    Calling magnet/status with no `id` and no `status` filter returns the
    full library in one response (not traditionally paginated — AllDebrid
    just returns the whole array). Each item has `id`, `filename`, `size`,
    `status`, `statusCode` etc. but notably NO hash — that's only ever
    returned at upload time, not afterwards.
    """
    data = _ad_get(api_key, AD_STATUS, params={})
    if data.get("status") == "error":
        err = data.get("error", {})
        log.warning(f"[lib-sync] AllDebrid error {err.get('code')}: {err.get('message')}")
        return []
    return data.get("data", {}).get("magnets", [])

# ── Plex scanner ──────────────────────────────────────────────────────────────
# Identical debounced scanner to premiumize-web; reads config from app._load_config.

class _PlexScanner:
    def __init__(self):
        self._lock   = threading.Lock()
        self._timer: threading.Timer | None = None
        self._pending: set = set()
        self._loc_cache: dict = {}
        self._log = logging.getLogger(__name__ + ".plex")
        self._interval_stop = threading.Event()
        self._interval_wake = threading.Event()
        t = threading.Thread(target=self._interval_loop, daemon=True)
        t.start()

    def _load_plex_cfg(self) -> dict:
        try:
            import sys as _s
            _a = _s.modules.get("app") or _s.modules.get("__main__")
            lc = getattr(_a, "_load_config", None)
            return (lc() or {}).get("plex", {}) if lc else {}
        except Exception:
            return {}

    def _scan_interval_minutes(self) -> int:
        try:
            return int(self._load_plex_cfg().get("scan_interval_minutes", 60))
        except Exception:
            return 60

    def _config(self):
        cfg        = self._load_plex_cfg()
        url        = (os.environ.get("PLEX_URL") or cfg.get("url", "")).rstrip("/")
        token      = os.environ.get("PLEX_TOKEN") or cfg.get("token", "")
        movies     = os.environ.get("PLEX_MOVIES_SECTION") or str(cfg.get("movies_section", "1"))
        tv         = os.environ.get("PLEX_TV_SECTION") or str(cfg.get("tv_section", "2"))
        debounce   = int(os.environ.get("PLEX_SCAN_DEBOUNCE", "0") or cfg.get("debounce_seconds", 30))
        mount      = (os.environ.get("PLEX_MOUNT_PATH") or cfg.get("mount_path", "/docker/alldebrid-web/mnt")).rstrip("/")
        movie_root = (os.environ.get("PLEX_MOVIE_ROOT") or cfg.get("movie_root") or mount + "/movies").rstrip("/")
        tv_root    = (os.environ.get("PLEX_TV_ROOT")    or cfg.get("tv_root")    or mount + "/series").rstrip("/")
        movie4k    = (cfg.get("movie4k_root") or mount + "/movies4k").rstrip("/")
        tv4k       = (cfg.get("tv4k_root")    or mount + "/series4k").rstrip("/")
        debounce   = debounce or 30
        return (url or None, token or None, movies, tv, debounce, movie_root, tv_root, movie4k, tv4k)

    def _cfg_bool(self, key: str, default: bool) -> bool:
        v = os.environ.get("PLEX_" + key.upper())
        if v is not None:
            return v.strip().lower() not in ("0", "false", "no", "off")
        return bool(self._load_plex_cfg().get(key, default))

    def _auto_scan_enabled(self)  -> bool: return self._cfg_bool("auto_scan_enabled",  True)
    def _partial_enabled(self)    -> bool: return self._cfg_bool("partial_scan",        True)
    def _fallback_full_enabled(self) -> bool: return self._cfg_bool("fallback_full_scan", True)

    def notify_ready(self, subdir: str, rel_path: str | None = None):
        if not self._auto_scan_enabled():
            return
        _, _, _, _, debounce, *_ = self._config()
        with self._lock:
            self._pending.add((subdir, rel_path))
            if self._timer is not None:
                self._timer.cancel()
            self._timer = threading.Timer(debounce, self._fire)
            self._timer.daemon = True
            self._timer.start()
            self._log.warning(f"[plex-add] scan in {debounce}s queued={self._pending}")

    def bulk_scan(self, transfer_manager=None) -> dict:
        """Fast first-import scan.

        1. Pre-warm FUSE file cache in parallel so CDN URLs are fetched before
           Plex hits the filesystem — Plex sees real file sizes on first stat.
        2. Fire a single full-section refresh for movies and series instead of
           one HTTP call per folder.  One call is all Plex needs to walk the
           entire section tree.

        Returns {"movies": bool, "series": bool, "prewarmed": int}.
        """
        url, token, movies_sec, tv_sec, _, movie_root, tv_root, movie4k, tv4k = self._config()
        if not url or not token:
            return {"error": "Plex not configured", "movies": False, "series": False, "prewarmed": 0}

        # ── Step 1: pre-warm CDN URLs in parallel ─────────────────────────────
        prewarmed = 0
        try:
            import fuse_mount as _fm
            tm = transfer_manager or self
            hashes = []
            try:
                hashes = tm.streamable_hashes()
            except Exception:
                pass
            if hashes and _fm._pfs:
                self._log.info(f"[bulk-scan] pre-warming {len(hashes)} transfers in parallel…")
                _fm._pfs._prewarm_parallel(hashes, block=True)
                prewarmed = len(hashes)
                self._log.info(f"[bulk-scan] pre-warm complete")
        except Exception as e:
            self._log.warning(f"[bulk-scan] pre-warm failed: {e}")

        # ── Step 2: single full-section refresh per section ───────────────────
        movies_ok = series_ok = False
        try:
            q = urllib.parse.urlencode({"X-Plex-Token": token})
            r = requests.get(f"{url}/library/sections/{movies_sec}/refresh?{q}", timeout=15)
            movies_ok = r.status_code in (200, 204)
            self._log.info(f"[bulk-scan] movies section refresh: {r.status_code}")
        except Exception as e:
            self._log.warning(f"[bulk-scan] movies refresh failed: {e}")
        try:
            q = urllib.parse.urlencode({"X-Plex-Token": token})
            r = requests.get(f"{url}/library/sections/{tv_sec}/refresh?{q}", timeout=15)
            series_ok = r.status_code in (200, 204)
            self._log.info(f"[bulk-scan] series section refresh: {r.status_code}")
        except Exception as e:
            self._log.warning(f"[bulk-scan] series refresh failed: {e}")

        return {"movies": movies_ok, "series": series_ok, "prewarmed": prewarmed}

    def _fire(self):
        with self._lock:
            self._pending.clear()
            self._timer = None
        url, token, *_ = self._config()
        if not url or not token:
            return
        self.scan_missing_from_plex()

    def _interval_loop(self):
        while not self._interval_stop.is_set():
            mins = self._scan_interval_minutes()
            if mins <= 0:
                self._interval_wake.wait(timeout=60)
                self._interval_wake.clear()
                continue
            self._interval_wake.wait(timeout=mins * 60)
            self._interval_wake.clear()
            if not self._interval_stop.is_set():
                try:
                    self.unlock_scanned_by_plex()
                    self.scan_missing_from_plex()
                except Exception as e:
                    self._log.warning(f"[plex-interval] error: {e}")

    def _do_refresh(self, url, token, section, subdir, target_path):
        if target_path:
            q = urllib.parse.urlencode({"path": target_path, "X-Plex-Token": token})
        else:
            q = urllib.parse.urlencode({"X-Plex-Token": token})
        try:
            r = requests.get(f"{url}/library/sections/{section}/refresh?{q}", timeout=10)
            if r.status_code not in (200, 204) and target_path and self._fallback_full_enabled():
                self._do_refresh(url, token, section, subdir, None)
        except requests.RequestException as e:
            self._log.warning(f"Plex scan failed: {e}")
            if target_path and self._fallback_full_enabled():
                self._do_refresh(url, token, section, subdir, None)

    def get_missing_from_plex(self) -> dict:
        url, token, movies_sec, tv_sec, _, movie_root, tv_root, movie4k, tv4k = self._config()
        if not url or not token:
            return {"error": "Plex not configured", "movies": [], "series": []}
        def _plex_folders(section, root):
            names = set()
            try:
                r = requests.get(
                    f"{url}/library/sections/{section}/all",
                    headers={"X-Plex-Token": token, "Accept": "application/json"},
                    timeout=15)
                if r.status_code == 200:
                    for item in r.json().get("MediaContainer", {}).get("Metadata") or []:
                        for media in item.get("Media") or []:
                            for part in media.get("Part") or []:
                                fp = part.get("file") or ""
                                if fp:
                                    names.add(os.path.basename(os.path.dirname(fp)))
            except Exception as e:
                self._log.warning(f"Plex section query failed: {e}")
            return names
        plex_movies = _plex_folders(movies_sec, movie_root)
        plex_series = _plex_folders(tv_sec, tv_root)
        try:
            import fuse_mount as _fm
            import sys as _s
            _a  = _s.modules.get("app") or _s.modules.get("__main__")
            _tm = getattr(_a, "_transfer_manager", None)
            nm  = _fm.build_name_map(_tm or self)
        except Exception as e:
            return {"error": str(e), "movies": [], "series": []}
        miss = {"movies": [], "movies4k": [], "series": [], "series4k": []}
        for key in nm:
            parts = key.split("/", 1)
            if len(parts) != 2:
                continue
            sd, folder = parts
            if sd in ("movies", "movies4k") and folder not in plex_movies:
                miss[sd].append(folder)
            elif sd in ("series", "series4k") and folder not in plex_series:
                miss[sd].append(folder)
        return miss

    def scan_missing_from_plex(self) -> dict:
        miss = self.get_missing_from_plex()
        if "error" in miss:
            return miss
        url, token, movies_sec, tv_sec, _, movie_root, tv_root, movie4k, tv4k = self._config()

        jobs = []
        for folder in miss.get("movies",   []): jobs.append((movies_sec, "movies",   movie_root + "/" + folder, "movies",  folder))
        for folder in miss.get("movies4k", []): jobs.append((movies_sec, "movies4k", movie4k    + "/" + folder, "movies",  folder))
        for folder in miss.get("series",   []): jobs.append((tv_sec,     "series",   tv_root    + "/" + folder, "series",  folder))
        for folder in miss.get("series4k", []): jobs.append((tv_sec,     "series4k", tv4k       + "/" + folder, "series",  folder))

        scanned = {"movies": [], "series": []}
        if not jobs:
            return {"scanned": scanned, "missing": miss}

        # Fire all per-folder refreshes concurrently — this is the difference
        # between a first scan taking minutes (one HTTP round-trip per folder,
        # serialized) vs seconds. Bounded pool so we don't open hundreds of
        # sockets to Plex at once on a very large first import.
        from concurrent.futures import ThreadPoolExecutor
        # If many folders 404/error and fallback_full_scan is on, _do_refresh
        # would otherwise fire a full-section refresh once per failure — cap
        # that to a single fallback per section regardless of how many
        # individual folder refreshes failed.
        fallback_done = {"movies": False, "series": False}
        fallback_lock = threading.Lock()

        def _refresh_one(section, subdir, target_path, bucket, folder):
            try:
                q = urllib.parse.urlencode({"path": target_path, "X-Plex-Token": token})
                r = requests.get(f"{url}/library/sections/{section}/refresh?{q}", timeout=10)
                ok = r.status_code in (200, 204)
            except requests.RequestException as e:
                self._log.warning(f"Plex scan failed for {target_path}: {e}")
                ok = False
            if not ok and self._fallback_full_enabled():
                with fallback_lock:
                    already = fallback_done[bucket]
                    fallback_done[bucket] = True
                if not already:
                    self._do_refresh(url, token, section, subdir, None)
            scanned[bucket].append(folder)

        with ThreadPoolExecutor(max_workers=PLEX_SCAN_WORKERS, thread_name_prefix="plex-scan") as pool:
            list(pool.map(lambda j: _refresh_one(*j), jobs))

        return {"scanned": scanned, "missing": miss}

    def unlock_scanned_by_plex(self) -> dict:
        url, token, movies_sec, tv_sec, _, movie_root, tv_root, movie4k, tv4k = self._config()
        if not url or not token:
            return {"error": "Plex not configured", "unlocked": 0}
        def _plex_folder_map(section, root):
            result = {}
            try:
                r = requests.get(f"{url}/library/sections/{section}/all",
                                 headers={"X-Plex-Token": token, "Accept": "application/json"},
                                 params={"type": "1" if "movie" in root else "4"}, timeout=15)
                if r.status_code == 200:
                    for item in r.json().get("MediaContainer", {}).get("Metadata") or []:
                        rk = item.get("ratingKey") or ""
                        for media in item.get("Media") or []:
                            for part in media.get("Part") or []:
                                fp = part.get("file") or ""
                                if fp and rk:
                                    result[os.path.basename(os.path.dirname(fp))] = rk
            except Exception as e:
                self._log.warning(f"Plex folder map failed: {e}")
            return result
        plex_movies = _plex_folder_map(movies_sec, movie_root)
        plex_series = _plex_folder_map(tv_sec,     tv_root)
        try:
            import fuse_mount as _fm
            import sys as _s
            _a  = _s.modules.get("app") or _s.modules.get("__main__")
            _tm = getattr(_a, "_transfer_manager", None)
            nm  = _fm.build_name_map(_tm or self)
        except Exception as e:
            return {"error": str(e), "unlocked": 0}
        import sys as _s2
        _a2  = _s2.modules.get("app") or _s2.modules.get("__main__")
        _tm2 = getattr(_a2, "_transfer_manager", None)
        unlocked = 0
        for key, hash_ in nm.items():
            parts = key.split("/", 1)
            if len(parts) != 2:
                continue
            sd, folder = parts
            rk = plex_movies.get(folder) if sd in ("movies", "movies4k") else plex_series.get(folder)
            if not rk:
                continue
            if _tm2 and _tm2.is_cdn_unlocked(hash_):
                continue
            ok = _tm2.unlock_file_cdn(hash_, mark_played=False) if _tm2 else False
            if ok:
                unlocked += 1
                try:
                    requests.put(f"{url}/library/metadata/{rk}/refresh",
                                 headers={"X-Plex-Token": token},
                                 params={"force": 1, "refreshLocalMediaAgent": 1}, timeout=8)
                except Exception:
                    pass
                try:
                    import fuse_mount as _fmx
                    if _fmx._pfs is not None:
                        _fmx._pfs._stat_invalidate(key)
                except Exception:
                    pass
        return {"unlocked": unlocked}


_plex = _PlexScanner()

# ── In-memory CDN-unlocked set (fast FUSE read-path) ─────────────────────────
_unlocked_hashes: set = set()

# ── FUSE location helper ──────────────────────────────────────────────────────

def _fuse_location(hash_: str, name: str, category: str = "", kind: str = ""):
    try:
        import fuse_mount as _fm
        if _fm._pfs is not None:
            nm = _fm._pfs._get_name_map()
            for key, h in nm.items():
                if h == hash_ and "/" in key:
                    sd, folder = key.split("/", 1)
                    return sd, folder
    except Exception:
        pass
    try:
        from fuse_mount import _category_subdir, _safe_name
        sd = _category_subdir(name or "", category or "", kind=kind or "")
        return sd, _safe_name(name or hash_)
    except Exception:
        return ("series" if kind == "series" else "movies"), (name or hash_)


class RateLimitError(Exception):
    def __init__(self, retry_after: int = 60):
        self.retry_after = retry_after
        super().__init__(f"Rate limited, retry after {retry_after}s")


class TransferManager:
    """
    Manages AllDebrid transfers.  Drop-in replacement for the Premiumize
    TransferManager — exposes the same public interface so fuse_mount.py and
    qbt_mock.py work unchanged.

    Key differences from Premiumize:
    - Cache check: upload magnet → read ready flag → delete (no permanent upload)
    - Add cached:  upload magnet → keep in library (ad_id stored in DB)
    - Get files:   magnet/files → link/unlock each file → store CDN URLs
    - Poll:        magnet/status by id
    - No fair-use meter, no directdl, no /transfer/list
    """

    def __init__(self, ad_api_key_fn, *_args, **_kwargs):
        self._key_fn = ad_api_key_fn
        self._lock   = threading.Lock()
        self._local  = threading.local()
        self._init_db()
        self._start_poller()

    # ── DB ────────────────────────────────────────────────────────────────────

    def _make_conn(self):
        os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
        conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA cache_size=-8000")
        return conn

    def _db(self):
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = self._make_conn()
            self._local.conn = conn
        else:
            try:
                conn.execute("SELECT 1")
            except Exception:
                conn = self._make_conn()
                self._local.conn = conn
        return conn

    def _init_db(self):
        with self._lock:
            self._db().executescript("""
                CREATE TABLE IF NOT EXISTS transfers (
                    hash        TEXT PRIMARY KEY,
                    name        TEXT,
                    state       TEXT DEFAULT 'queued',
                    ad_id       INTEGER,
                    error       TEXT,
                    added_at    REAL,
                    updated_at  REAL,
                    category    TEXT DEFAULT '',
                    kind        TEXT DEFAULT '',
                    cdn_unlocked INTEGER DEFAULT 0,
                    streamable_at REAL,
                    last_played REAL,
                    is_stub     INTEGER DEFAULT 0,
                    imported    INTEGER DEFAULT 0,
                    size        INTEGER DEFAULT 0
                );
                CREATE TABLE IF NOT EXISTS files (
                    hash        TEXT NOT NULL,
                    name        TEXT NOT NULL,
                    path        TEXT DEFAULT '',
                    size        INTEGER DEFAULT 0,
                    cdn_url     TEXT DEFAULT '',
                    cdn_expires REAL DEFAULT 0,
                    cdn_unlocked INTEGER DEFAULT 0,
                    cdn_played   INTEGER DEFAULT 0,
                    PRIMARY KEY (hash, name)
                );
                CREATE TABLE IF NOT EXISTS meta (
                    key   TEXT PRIMARY KEY,
                    value TEXT
                );
                CREATE TABLE IF NOT EXISTS deleted (
                    hash       TEXT PRIMARY KEY,
                    deleted_at REAL NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_transfers_state  ON transfers(state);
                CREATE INDEX IF NOT EXISTS idx_transfers_stub   ON transfers(is_stub, state);
                CREATE INDEX IF NOT EXISTS idx_transfers_played ON transfers(last_played);
                CREATE INDEX IF NOT EXISTS idx_files_hash      ON files(hash);
            """)
            # Migrations for existing DBs
            t_cols = {r[1] for r in self._db().execute("PRAGMA table_info(transfers)").fetchall()}
            f_cols = {r[1] for r in self._db().execute("PRAGMA table_info(files)").fetchall()}
            for col, defval in [
                ("ad_id",         "INTEGER"),
                ("cdn_unlocked",  "INTEGER DEFAULT 0"),
                ("streamable_at", "REAL"),
                ("last_played",   "REAL"),
                ("is_stub",       "INTEGER DEFAULT 0"),
                ("imported",      "INTEGER DEFAULT 0"),
                ("size",          "INTEGER DEFAULT 0"),
                ("kind",          "TEXT DEFAULT ''"),
                ("category",      "TEXT DEFAULT ''"),
            ]:
                if col not in t_cols:
                    self._db().execute(f"ALTER TABLE transfers ADD COLUMN {col} {defval}")
            for col, defval in [
                ("cdn_unlocked", "INTEGER DEFAULT 0"),
                ("cdn_played",   "INTEGER DEFAULT 0"),
            ]:
                if col not in f_cols:
                    self._db().execute(f"ALTER TABLE files ADD COLUMN {col} {defval}")
            # Backfill streamable_at for old rows
            self._db().execute(
                "UPDATE transfers SET streamable_at = COALESCE(added_at, updated_at) "
                "WHERE state IN ('cached','complete') AND streamable_at IS NULL"
            )
            # Ensure every cached/complete non-stub transfer is unlocked.
            # Transfers added before unlock tracking existed, or synced via
            # sync_library, may have cdn_unlocked=0 even though they're ready.
            # Safe to re-run on every startup — no-op for rows already set to 1.
            self._db().execute(
                "UPDATE transfers SET cdn_unlocked=1 "
                "WHERE state IN ('cached','complete') AND is_stub=0"
            )
            self._db().execute(
                "UPDATE files SET cdn_unlocked=1 WHERE hash IN ("
                "  SELECT hash FROM transfers "
                "  WHERE state IN ('cached','complete') AND is_stub=0"
                ")"
            )
            self._db().commit()
            # Restore unlocked set from DB
            global _unlocked_hashes
            rows = self._db().execute("SELECT hash FROM transfers WHERE cdn_unlocked=1").fetchall()
            _unlocked_hashes = {r[0] for r in rows}
            log.info(f"[init] {len(_unlocked_hashes)} transfer(s) marked unlocked")

    def _get(self, hash_: str):
        row = self._db().execute("SELECT * FROM transfers WHERE hash=?", (hash_,)).fetchone()
        return dict(row) if row else None

    def _set(self, hash_: str, **kwargs):
        kwargs["updated_at"] = time.time()
        with self._lock:
            ex = self._get(hash_)
            if kwargs.get("state") in ("cached", "complete") and not (ex and ex.get("streamable_at")):
                kwargs.setdefault("streamable_at", time.time())
            if ex:
                sets = ", ".join(f"{k}=?" for k in kwargs)
                vals = list(kwargs.values()) + [hash_]
                self._db().execute(f"UPDATE transfers SET {sets} WHERE hash=?", vals)
            else:
                kwargs.setdefault("added_at", time.time())
                kwargs["hash"] = hash_
                cols = ", ".join(kwargs.keys())
                phs  = ", ".join("?" * len(kwargs))
                self._db().execute(f"INSERT INTO transfers ({cols}) VALUES ({phs})", list(kwargs.values()))
            self._db().commit()

    # ── File DB helpers ───────────────────────────────────────────────────────

    def _db_get_files(self, hash_: str) -> list:
        rows = self._db().execute(
            "SELECT name, path, size, cdn_url, cdn_expires, cdn_unlocked FROM files WHERE hash=?",
            (hash_,)
        ).fetchall()
        return [dict(r) for r in rows]

    def _db_store_files(self, hash_: str, files: list):
        """Persist file list, preserving existing cdn_unlocked / cdn_played
        flags AND the existing cdn_url when the new row doesn't carry one
        (e.g. a light/discovery-only fetch with just name+size — see
        get_files_light). Without this, re-storing a lighter file list would
        wipe out a real CDN URL obtained from an earlier full fetch/unlock.
        """
        now = time.time()
        with self._lock:
            old = self._db().execute(
                "SELECT name, path, cdn_url, cdn_unlocked, cdn_played FROM files WHERE hash=?", (hash_,)
            ).fetchall()
            unlocked_keys: dict = {}
            played_keys:   dict = {}
            cdn_url_keys:  dict = {}
            for r in old:
                keys = [r["name"], r["path"], os.path.basename(r["path"] or "")]
                if int(r["cdn_unlocked"] or 0):
                    for k in keys:
                        unlocked_keys[k] = 1
                if int(r["cdn_played"] or 0):
                    for k in keys:
                        played_keys[k]   = 1
                if r["cdn_url"]:
                    for k in keys:
                        cdn_url_keys[k] = r["cdn_url"]
            self._db().execute("DELETE FROM files WHERE hash=?", (hash_,))
            for f in files:
                name  = f.get("name") or ""
                path  = f.get("path") or ""
                bname = os.path.basename(path)
                ul    = 1 if (unlocked_keys.get(name) or unlocked_keys.get(path) or unlocked_keys.get(bname)) else 0
                pl    = 1 if (played_keys.get(name)   or played_keys.get(path)   or played_keys.get(bname))   else 0
                new_cdn_url = f.get("cdn_url") or f.get("link") or ""
                if not new_cdn_url:
                    new_cdn_url = cdn_url_keys.get(name) or cdn_url_keys.get(path) or cdn_url_keys.get(bname) or ""
                self._db().execute(
                    "INSERT OR REPLACE INTO files "
                    "(hash, name, path, size, cdn_url, cdn_expires, cdn_unlocked, cdn_played) "
                    "VALUES (?,?,?,?,?,?,?,?)",
                    (hash_, name, path, int(f.get("size", 0) or 0),
                     new_cdn_url,
                     now + CDN_TTL, ul, pl),
                )
            self._db().commit()

    def _db_files_to_list(self, rows: list) -> list:
        VIDEO_EXTS = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts", ".wmv", ".flv", ".webm"}
        import urllib.parse as _up
        result = []
        for r in rows:
            name = r.get("name") or ""
            if not name:
                continue
            cdn   = r.get("cdn_url") or ""
            ext   = os.path.splitext(name)[1].lower()
            token = ""
            try:
                token = _make_stream_token(r.get("hash", ""), name)
            except Exception:
                pass
            result.append({
                "name":      name,
                "path":      r.get("path", ""),
                "link":      cdn,
                "cdn_url":   cdn,
                "size":      int(r.get("size", 0) or 0),
                "is_video":  ext in VIDEO_EXTS,
                "cdn_expires": r.get("cdn_expires", 0),
                "stream_url": (
                    f"/api/stream/{token}?h={r.get('hash','')}&f={_up.quote(name)}"
                    if token else ""
                ),
            })
        return result

    # ── Public API ────────────────────────────────────────────────────────────

    def add(self, hash_: str, name: str):
        hash_ = hash_.lower()
        ex = self._get(hash_)
        if ex and ex["state"] in ("cached", "downloading", "complete"):
            if ex.get("name") == hash_ and name and name != hash_:
                self._set(hash_, name=name)
            return self._get(hash_)
        self._set(hash_, name=name, state="queued")
        try:
            import sys as _s
            _a = _s.modules.get("app") or _s.modules.get("__main__")
            pool = getattr(_a, "_pool", None)
            if pool:
                pool.submit(self._process, hash_)
            else:
                raise ImportError
        except Exception:
            threading.Thread(target=self._process, args=(hash_,), daemon=True).start()
        return self._get(hash_)

    def delete(self, hash_: str):
        t = self._get(hash_)
        if t:
            ad_id   = t.get("ad_id")
            api_key = self._key_fn()
            if ad_id and api_key:
                try:
                    _ad_delete_magnet(api_key, ad_id)
                except Exception:
                    pass
        with self._lock:
            self._db().execute("DELETE FROM transfers WHERE hash=?", (hash_,))
            self._db().execute("DELETE FROM files WHERE hash=?", (hash_,))
            # Record in tombstone table so sync_library and restore never
            # re-import this hash automatically.
            self._db().execute(
                "INSERT OR REPLACE INTO deleted (hash, deleted_at) VALUES (?,?)",
                (hash_, time.time())
            )
            self._db().commit()

    def is_user_deleted(self, hash_: str) -> bool:
        """Return True if this hash was explicitly removed by the user."""
        row = self._db().execute(
            "SELECT 1 FROM deleted WHERE hash=?", (hash_,)
        ).fetchone()
        return row is not None

    def get_transfer(self, hash_: str):
        return self._get(hash_)

    def all_transfers(self):
        rows = self._db().execute("SELECT * FROM transfers").fetchall()
        return [dict(r) for r in rows]

    def streamable_hashes(self):
        rows = self._db().execute(
            "SELECT hash FROM transfers WHERE state IN ('cached','complete')"
        ).fetchall()
        return [r["hash"] for r in rows]

    def get_files_light(self, hash_: str, force: bool = False) -> list:
        """Names + sizes only — skips the per-file link/unlock call entirely.

        Plex's directory discovery (readdir/getattr) only needs a filename
        and a size to know the file exists and what size to report; it never
        touches cdn_url. The full get_files() unlock-per-file loop costs one
        extra AllDebrid call per file and is only actually needed for
        playback, which goes through the auto-unlock-on-read path in FUSE's
        read() instead. Use this for bulk prewarming so a library scan costs
        one magnet/files call per transfer (O(transfers)) instead of one
        magnet/files plus one link/unlock per file (O(files)).

        Stores rows with cdn_url left empty (not the raw locked link) so
        is_file_cdn_unlocked() correctly continues reporting locked/stub
        until a real unlock happens — this is purely a fast path to make
        files show up with correct names/sizes during a scan, not a way to
        skip unlocking.
        """
        t = self._get(hash_)
        if not t or t["state"] not in ("cached", "complete"):
            return []

        if not force:
            db_rows = self._db_get_files(hash_)
            if db_rows:
                for r in db_rows:
                    r["hash"] = hash_
                result = self._db_files_to_list(db_rows)
                if result:
                    return result

        api_key = self._key_fn()
        if not api_key:
            log.error(f"[{hash_[:8]}] get_files_light: ALLDEBRID_API_KEY not set")
            return []

        ad_id = t.get("ad_id")
        if not ad_id:
            resp    = _ad_upload_magnet(api_key, hash_, t.get("name") or hash_)
            magnets = resp.get("data", {}).get("magnets", [])
            if not magnets or magnets[0].get("error"):
                return []
            ad_id = magnets[0].get("id")
            if not magnets[0].get("ready"):
                if ad_id:
                    self._set(hash_, ad_id=ad_id)
                return []
            if ad_id:
                self._set(hash_, ad_id=ad_id)

        raw_files = _ad_get_files(api_key, ad_id)
        if not raw_files:
            return []

        # Store name/size/path only — cdn_url stays empty until a real unlock.
        light = [{"name": f.get("name", ""), "path": f.get("name", ""),
                  "size": f.get("size", 0)} for f in raw_files]
        self._db_store_files(hash_, light)

        db_rows = self._db_get_files(hash_)
        for r in db_rows:
            r["hash"] = hash_
        return self._db_files_to_list(db_rows)

    def get_files(self, hash_: str, force: bool = False) -> list:
        """
        Return unlocked file list for hash.

        AllDebrid flow:
          1. DB cache hit → return immediately (no API call)
          2. DB miss or force=True:
             a. Fetch raw file list via magnet/files
             b. Unlock each download link via link/unlock
             c. Store CDN URLs in DB
        """
        t = self._get(hash_)
        if not t or t["state"] not in ("cached", "complete"):
            return []

        if not force:
            db_rows = self._db_get_files(hash_)
            if db_rows:
                for r in db_rows:
                    r["hash"] = hash_
                result = self._db_files_to_list(db_rows)
                if result:
                    return result

        api_key = self._key_fn()
        if not api_key:
            log.error(f"[{hash_[:8]}] get_files: ALLDEBRID_API_KEY not set")
            return []

        ad_id = t.get("ad_id")
        if not ad_id:
            # Upload fresh to get an ID, but immediately delete afterwards
            resp    = _ad_upload_magnet(api_key, hash_, t.get("name") or hash_)
            magnets = resp.get("data", {}).get("magnets", [])
            if not magnets or magnets[0].get("error"):
                return []
            ad_id = magnets[0].get("id")
            if not magnets[0].get("ready"):
                # Not cached yet — store id for polling and return empty
                if ad_id:
                    self._set(hash_, ad_id=ad_id)
                return []
            if ad_id:
                self._set(hash_, ad_id=ad_id)

        raw_files = _ad_get_files(api_key, ad_id)
        if not raw_files:
            return []

        # Unlock each link to get a direct CDN URL
        unlocked = []
        for f in raw_files:
            raw_link = f.get("link") or ""
            if not raw_link:
                continue
            cdn_url = _ad_unlock_link(api_key, raw_link)
            if cdn_url:
                unlocked.append({**f, "cdn_url": cdn_url})

        if unlocked:
            self._db_store_files(hash_, unlocked)

        db_rows = self._db_get_files(hash_)
        for r in db_rows:
            r["hash"] = hash_
        return self._db_files_to_list(db_rows)

    def refresh_cdn_url(self, hash_: str, filename: str) -> str | None:
        """Force-refresh one expired CDN URL (called on 403/410 during playback)."""
        t = self._get(hash_)
        if not t:
            return None
        api_key = self._key_fn()
        if not api_key:
            return None
        ad_id = t.get("ad_id")
        if not ad_id:
            return None
        # Re-fetch the file list and re-unlock
        raw_files = _ad_get_files(api_key, ad_id)
        for f in raw_files:
            name  = f.get("name") or ""
            bname = os.path.basename(f.get("path") or name)
            if name == filename or bname == filename or (f.get("path") or "").endswith("/" + filename):
                cdn = _ad_unlock_link(api_key, f.get("link") or "")
                if cdn:
                    with self._lock:
                        self._db().execute(
                            "UPDATE files SET cdn_url=?, cdn_expires=? WHERE hash=? AND name=?",
                            (cdn, time.time() + CDN_TTL, hash_, name)
                        )
                        self._db().commit()
                    log.info(f"[{hash_[:8]}] CDN URL refreshed for {filename}")
                    return cdn
        return None

    def is_cdn_unlocked(self, hash_: str) -> bool:
        if hash_ in _unlocked_hashes:
            return True
        try:
            row = self._db().execute(
                "SELECT cdn_unlocked FROM transfers WHERE hash=?", (hash_,)
            ).fetchone()
            result = bool(row and row[0])
            if result:
                _unlocked_hashes.add(hash_)
            return result
        except Exception:
            return False

    def is_file_cdn_unlocked(self, hash_: str, filename: str | None = None) -> bool:
        if not filename:
            return self.is_cdn_unlocked(hash_)
        base = os.path.basename(filename or "")
        try:
            row = self._db().execute(
                "SELECT cdn_unlocked FROM files WHERE hash=? AND (name=? OR path=? OR path LIKE ?) LIMIT 1",
                (hash_, base, filename, "%/" + base),
            ).fetchone()
            if row and int(row[0] or 0):
                return True
        except Exception:
            pass
        return self.is_cdn_unlocked(hash_)

    def is_file_played(self, hash_: str, filename: str) -> bool:
        base = os.path.basename(filename or "")
        try:
            row = self._db().execute(
                "SELECT cdn_played FROM files WHERE hash=? AND (name=? OR path=? OR path LIKE ?) LIMIT 1",
                (hash_, base, filename, "%/" + base),
            ).fetchone()
            return bool(row and int(row[0] or 0))
        except Exception:
            return False

    def unlock_file_cdn(self, hash_: str, filename: str | None = None,
                        mark_played: bool = False) -> bool:
        global _unlocked_hashes
        hash_ = (hash_ or "").lower().strip()
        if not hash_:
            return False
        base = os.path.basename(filename or "") if filename else ""
        with self._lock:
            if base:
                played_sql = ", cdn_played=1" if mark_played else ""
                cur = self._db().execute(
                    f"UPDATE files SET cdn_unlocked=1{played_sql} "
                    "WHERE hash=? AND (name=? OR path=? OR path LIKE ?)",
                    (hash_, base, filename, "%/" + base),
                )
                self._db().commit()
                return bool(cur.rowcount)
            played_sql = ", cdn_played=1" if mark_played else ""
            self._db().execute(f"UPDATE transfers SET cdn_unlocked=1{played_sql} WHERE hash=?", (hash_,))
            if mark_played:
                self._db().execute("UPDATE files SET cdn_played=1 WHERE hash=?", (hash_,))
            self._db().commit()
            _unlocked_hashes.add(hash_)
            return True

    def touch_played(self, hash_: str):
        """Record playback: reset last_played to now and clear is_stub.

        Called every time a file from this transfer is opened for streaming.
        Resets the 30-day inactivity clock so the stub manager leaves it alone.
        Clears is_stub=0 defensively so a re-added stub that is already playing
        is never re-stubbed on the next hourly pass.
        """
        self._set(hash_, last_played=time.time(), is_stub=0)

    # ── Processing ────────────────────────────────────────────────────────────

    def _process(self, hash_: str):
        """Upload magnet to AllDebrid and read cache state from the response.

        AllDebrid's magnet/instant endpoint was deprecated and no longer
        reflects real cache state — the only reliable signal is the `ready`
        flag returned by magnet/upload itself, so we upload once and trust
        that directly (no separate pre-check needed; we're uploading either
        way since this transfer is being added for real).
        """
        t = self._get(hash_)
        if not t or t["state"] in ("cached", "complete", "downloading"):
            return
        api_key = self._key_fn()
        if not api_key:
            self._set(hash_, state="error", error="API key not set")
            return
        try:
            resp = _ad_upload_magnet(api_key, hash_, t.get("name") or hash_)

            # Top-level error (bad apikey, rate limited, etc.) — no "data"
            # key at all in this case, so resp.get("data",{}) alone would
            # silently produce an empty magnets list and a useless generic
            # "Upload failed" message instead of the real reason.
            if resp.get("status") == "error":
                err = resp.get("error", {})
                code = err.get("code", "UNKNOWN")
                msg  = err.get("message", "Upload failed")
                log.warning(f"[{hash_[:8]}] AllDebrid error {code}: {msg}")
                self._set(hash_, state="error", error=f"{code}: {msg}")
                return

            magnets = resp.get("data", {}).get("magnets", [])
            if not magnets or magnets[0].get("error"):
                err = magnets[0].get("error", {}) if magnets else {}
                code = err.get("code", "UNKNOWN")
                msg  = err.get("message", "Upload failed")
                log.warning(f"[{hash_[:8]}] {code}: {msg}")
                self._set(hash_, state="error", error=f"{code}: {msg}")
                return
            m     = magnets[0]
            ad_id = m.get("id")
            if m.get("ready"):
                log.info(f"[{hash_[:8]}] Cached on AllDebrid — ready to stream")
                self._set(hash_, state="cached", ad_id=ad_id)
                self._on_ready(hash_)
            else:
                log.info(f"[{hash_[:8]}] Not cached — queued for download (ad_id={ad_id})")
                self._set(hash_, state="downloading", ad_id=ad_id)
        except Exception as e:
            log.exception(f"[{hash_[:8]}] _process error")
            self._set(hash_, state="error", error=str(e))

    def _on_ready(self, hash_: str):
        """Called when a transfer becomes cached or complete."""
        t2 = self._get(hash_)
        if not t2:
            return
        _name     = t2.get("name") or hash_
        _category = t2.get("category") or ""
        _files    = []
        try:
            from name_match import classify_from_files
            _files = self.get_files(hash_) or []
            _kind = classify_from_files(_files)
            if _kind and not t2.get("kind"):
                self._set(hash_, kind=_kind)
            else:
                _kind = t2.get("kind") or _kind or ""
        except Exception as e:
            log.debug(f"[{hash_[:8]}] classify failed: {e}")
        try:
            import qbt_mock as _qbt
            _fn = _qbt._pick_fake_filename(_name, _files)
            _qbt._make_fake_file(_category, _qbt._safe_name(_name), _fn, _files)
        except Exception as e:
            log.debug(f"[{hash_[:8]}] fake-file failed: {e}")

        # Unlock at both levels:
        #   transfers.cdn_unlocked=1  → fast path for is_cdn_unlocked()
        #   files.cdn_unlocked=1      → FUSE per-file check used by getattr/read
        with self._lock:
            self._db().execute(
                "UPDATE transfers SET cdn_unlocked=1 WHERE hash=?", (hash_,)
            )
            self._db().execute(
                "UPDATE files SET cdn_unlocked=1 WHERE hash=?", (hash_,)
            )
            self._db().commit()
        global _unlocked_hashes
        _unlocked_hashes.add(hash_)
        log.info(f"[{hash_[:8]}] Unlocked (transfers + files) — ready to stream from CDN")

        # Push file list into FUSE in-process cache WITH updated unlock state,
        # and invalidate the stat cache so Plex sees the real file size immediately.
        try:
            _files_fresh = self.get_files(hash_) or _files
        except Exception:
            _files_fresh = _files

        try:
            import fuse_mount as _fm
            if _fm._pfs is not None:
                with _fm._pfs._lock:
                    _fm._pfs._file_cache[hash_] = (
                        _files_fresh, time.time() + _fm.DIRECTDL_TTL
                    )
                _fm._pfs._stat_invalidate_all()
                _fm._pfs._invalidate_name_map()
        except Exception as e:
            log.debug(f"[{hash_[:8]}] FUSE cache update failed: {e}")

        t2 = self._get(hash_)
        subdir, folder = _fuse_location(
            hash_, t2.get("name", ""), t2.get("category", ""), t2.get("kind", "")
        )
        _plex.notify_ready(subdir, folder)

    # ── Background poller ─────────────────────────────────────────────────────

    def _start_poller(self):
        if getattr(TransferManager, "_poller_started", False):
            return
        TransferManager._poller_started = True
        threading.Thread(target=self._poll_loop,        daemon=True, name="ad-poller").start()
        threading.Thread(target=self._cdn_refresh_loop, daemon=True, name="ad-cdn-refresh").start()
        threading.Thread(target=self._library_sync_loop, daemon=True, name="ad-lib-sync").start()
        threading.Thread(target=self._missing_repair_loop, daemon=True, name="ad-repair").start()

    def _cdn_refresh_loop(self):
        """Run _refresh_expired_cdn_urls at startup then every 12 hours.

        AllDebrid CDN URLs are valid for ~48h. We refresh anything expiring
        within the next 24h so playback never hits a mid-session 403.
        Only unlocked files are checked — locked stubs have no CDN URLs.
        """
        time.sleep(15)   # let app + FUSE finish initialising
        self._refresh_expired_cdn_urls()
        while True:
            time.sleep(12 * 3600)
            self._refresh_expired_cdn_urls()

    def _refresh_expired_cdn_urls(self):
        now  = time.time()
        soon = now + 86400   # 24 h from now
        try:
            rows = self._db().execute(
                """SELECT DISTINCT t.hash, t.name
                   FROM transfers t
                   JOIN files f ON f.hash = t.hash
                   WHERE f.cdn_unlocked = 1
                     AND (f.cdn_expires < ? OR f.cdn_expires = 0)
                     AND t.state IN ('cached', 'complete')
                   ORDER BY f.cdn_expires ASC""",
                (soon,)
            ).fetchall()
        except Exception as e:
            log.warning(f"[cdn-refresh] query failed: {e}")
            return

        if not rows:
            log.info("[cdn-refresh] all CDN URLs are fresh")
            return

        expired  = sum(1 for r in rows if self._db().execute(
            "SELECT COUNT(*) FROM files WHERE hash=? AND cdn_expires < ? AND cdn_expires > 0",
            (r["hash"], now)).fetchone()[0] > 0)
        log.warning(f"[cdn-refresh] {expired} expired, {len(rows)-expired} expiring within 24h — refreshing {len(rows)} transfer(s)")

        api_key = self._key_fn()
        if not api_key:
            log.warning("[cdn-refresh] no API key — skipping")
            return

        refreshed = failed = readded = 0
        for row in rows:
            try:
                _ad_acquire()
                ad_id = self._db().execute(
                    "SELECT ad_id FROM transfers WHERE hash=?", (row["hash"],)
                ).fetchone()
                ad_id = ad_id[0] if ad_id else None
                if not ad_id:
                    # No ad_id at all yet — re-upload to get a fresh one.
                    resp = _ad_upload_magnet(api_key, row["hash"], row["name"] or row["hash"])
                    mags = resp.get("data", {}).get("magnets", [])
                    if not mags or mags[0].get("error") or not mags[0].get("ready"):
                        failed += 1; continue
                    ad_id = mags[0].get("id")
                    if ad_id:
                        self._set(row["hash"], ad_id=ad_id)

                raw_files = _ad_get_files(api_key, ad_id)
                if not raw_files:
                    # ad_id is set but AllDebrid has nothing for it anymore —
                    # the magnet itself was purged/expired from their cache,
                    # not just the CDN link. Re-upload by hash to recover it,
                    # same as repair_missing()'s manual-repair path. Without
                    # this fallback, a purged magnet would just fail silently
                    # here forever (every 12h) until someone happened to
                    # press the manual Repair button.
                    if not row["hash"].startswith("ad-"):
                        log.info(f"[cdn-refresh] {row['hash'][:8]} ad_id={ad_id} returned no files — "
                                 f"magnet likely purged, attempting re-upload")
                        resp = _ad_upload_magnet(api_key, row["hash"], row["name"] or row["hash"])
                        mags = resp.get("data", {}).get("magnets", [])
                        if mags and not mags[0].get("error") and mags[0].get("ready"):
                            new_id = mags[0].get("id")
                            if new_id:
                                self._set(row["hash"], ad_id=new_id, state="cached")
                                ad_id = new_id
                                raw_files = _ad_get_files(api_key, ad_id)
                                if raw_files:
                                    readded += 1
                    if not raw_files:
                        # Still nothing — genuinely gone, not just a transient
                        # API hiccup. Mark missing so the UI's repair list and
                        # /api/repair/missing surface it for a manual search,
                        # instead of silently retrying forever.
                        log.warning(f"[cdn-refresh] {row['hash'][:8]} could not be recovered — marking missing")
                        self._set(row["hash"], state="missing", ad_id=None)
                        failed += 1
                        continue

                unlocked = []
                for f in raw_files:
                    raw_link = f.get("link") or ""
                    if not raw_link:
                        continue
                    cdn = _ad_unlock_link(api_key, raw_link)
                    if cdn:
                        unlocked.append({**f, "cdn_url": cdn})

                if unlocked:
                    self._db_store_files(row["hash"], unlocked)
                    refreshed += 1
                else:
                    failed += 1
            except Exception as e:
                log.debug(f"[cdn-refresh] {row['hash'][:8]}: {e}")
                failed += 1

        log.warning(f"[cdn-refresh] done — refreshed {refreshed}, re-added {readded}, failed {failed}")
        # Invalidate FUSE block cache for refreshed URLs so stale blocks aren't served
        try:
            import fuse_mount as _fm
            if _fm._pfs is not None:
                _fm._pfs._stat_invalidate_all()
                with _fm._pfs._lock:
                    for h, _ in rows[:refreshed]:
                        _fm._pfs._file_cache.pop(h if isinstance(h, str) else h["hash"], None)
        except Exception:
            pass

    def _missing_repair_loop(self):
        """Run repair_missing() at startup then every MISSING_REPAIR_INTERVAL
        seconds (12h default).

        This is the scheduled counterpart to the manual "🔧 Repair" button —
        catches torrents that vanished from AllDebrid (cache eviction, DMCA
        takedown, etc.) and re-adds them automatically, without requiring
        anyone to notice playback is broken and click Repair by hand.
        Anything that can't be recovered is marked 'missing' so it still
        shows up in the manual repair-search UI as a fallback.
        """
        time.sleep(20)   # let app + FUSE finish initialising, after the other loops' 15s
        self._run_missing_repair()
        while True:
            time.sleep(MISSING_REPAIR_INTERVAL)
            self._run_missing_repair()

    def _run_missing_repair(self):
        try:
            result = self.repair_missing()
        except Exception as e:
            log.warning(f"[repair] scheduled run failed: {e}")
            return
        if result.get("error"):
            log.warning(f"[repair] scheduled run skipped: {result['error']}")
            return
        readded = result.get("readded", [])
        missing = result.get("missing", [])
        if readded or missing:
            log.warning(f"[repair] scheduled run — re-added {len(readded)}, "
                        f"still missing {len(missing)} (of {result.get('total', 0)} checked)")
            for r in readded:
                log.info(f"[repair]   ✓ re-added: {r['name'][:60]}")
            for m in missing:
                log.info(f"[repair]   ✕ still missing: {m['name'][:60]}")
        else:
            log.info(f"[repair] scheduled run — all {result.get('total', 0)} transfer(s) present, nothing to do")

    # ── Full-library sync (picks up magnets added outside this app) ──────────
    # AllDebrid's account-wide magnet/status has no hash field — only `id`,
    # `filename`, `size`, `status`/`statusCode`. Anything synced in this way
    # gets a synthetic "ad-<id>" key as its `hash` column value since we
    # never have a real info-hash for it. That synthetic key is never used
    # to build a magnet:// URI (we'd only do that to re-upload something,
    # and a synced-in magnet is already in the library by definition), so
    # it's safe everywhere else hash is used (DB key, FUSE folder lookup,
    # log truncation, stream tokens).

    def _library_sync_loop(self):
        import fcntl
        try:
            _lf = open("/tmp/ad_libsync.lock", "w")
            fcntl.flock(_lf, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            return
        time.sleep(20)   # let app + FUSE finish initialising, after the other pollers
        while True:
            try:
                self.sync_library()
            except Exception:
                log.exception("[lib-sync] error")
            time.sleep(LIBRARY_SYNC_INTERVAL)

    def sync_library(self):
        """Pull in any AllDebrid magnets not already tracked locally.

        Additive only — never deletes or modifies a transfer we already
        know about, even if it's missing from this AllDebrid response (a
        partial/failed API call should never look like "the user deleted
        everything"). Returns the number of newly-discovered magnets.
        """
        api_key = self._key_fn()
        if not api_key:
            log.debug("[lib-sync] no API key — skipping")
            return 0

        magnets = _ad_all_magnets(api_key)
        if not magnets:
            log.info("[lib-sync] AllDebrid library is empty or call failed — nothing to sync")
            return 0

        known_ad_ids = {
            int(r[0]) for r in self._db().execute(
                "SELECT ad_id FROM transfers WHERE ad_id IS NOT NULL"
            ).fetchall()
        }

        # Never re-import hashes the user explicitly deleted.
        deleted_hashes: set[str] = {
            r[0] for r in self._db().execute("SELECT hash FROM deleted").fetchall()
        }

        new_count = 0
        newly_ready: list[str] = []
        for m in magnets:
            ad_id = m.get("id")
            if ad_id is None:
                continue
            ad_id = int(ad_id)
            if ad_id in known_ad_ids:
                continue   # already tracked — sync is additive only

            synth_hash = f"ad-{ad_id}"
            if synth_hash in deleted_hashes:
                continue   # user explicitly removed this — don't re-import
            name = m.get("filename") or f"magnet-{ad_id}"
            status_code = m.get("statusCode")
            ad_status   = m.get("status", "")

            if status_code == 4 or ad_status in ("Ready", "Seeding"):
                state = "cached"
            elif status_code is not None and status_code >= 5:
                state = "error"
            else:
                state = "downloading"

            self._set(
                synth_hash,
                name=name,
                state=state,
                ad_id=ad_id,
                size=int(m.get("size", 0) or 0),
                error=(ad_status if state == "error" else None),
            )
            new_count += 1
            if state == "cached":
                newly_ready.append(synth_hash)

        if new_count:
            log.info(f"[lib-sync] found {new_count} new magnet(s) from AllDebrid library "
                      f"({len(newly_ready)} ready to stream)")
        else:
            log.info(f"[lib-sync] checked {len(magnets)} magnet(s), nothing new")

        # Bring newly-discovered ready magnets fully online: fetch+unlock
        # files, populate FUSE's in-process cache, trigger Plex scan —
        # exactly the same path a normal add() takes once upload succeeds.
        for h in newly_ready:
            try:
                self._on_ready(h)
            except Exception as e:
                log.warning(f"[lib-sync] _on_ready failed for {h}: {e}")

        return new_count

    def repair_missing(self) -> dict:
        """Cross-check local cached/complete transfers against the live AllDebrid
        library and repair anything that has gone missing.

        For each local transfer whose ad_id is no longer present in AllDebrid:
          1. Try to re-upload the same magnet hash.
          2. If AllDebrid reports ready=True  → update ad_id, call _on_ready().
          3. If AllDebrid reports ready=False → torrent is no longer cached;
             mark state='missing' and return it in `needs_search` so the caller
             can offer a fallback search.
          4. If the transfer has no real hash (synthetic 'ad-NNN' keys from
             library-sync) it can't be re-added; mark it 'missing' too.

        Returns:
          {
            "readdded":   [{"hash":…, "name":…}],   # re-added successfully
            "missing":    [{"hash":…, "name":…}],   # gone, needs manual search
            "ok":         int,                       # count re-added
            "total":      int,                       # total transfers checked
          }
        """
        api_key = self._key_fn()
        if not api_key:
            return {"error": "API key not set", "readded": [], "missing": [], "ok": 0, "total": 0}

        # Fetch live AllDebrid library (id → status)
        live_magnets = _ad_all_magnets(api_key)
        live_ids: set[int] = set()
        live_status: dict[int, dict] = {}
        for m in live_magnets:
            mid = m.get("id")
            if mid is not None:
                live_ids.add(int(mid))
                live_status[int(mid)] = m

        # Transfers we track locally as cached/complete with a real ad_id
        rows = self._db().execute(
            "SELECT hash, name, ad_id, state FROM transfers "
            "WHERE state IN ('cached','complete') AND ad_id IS NOT NULL AND is_stub=0"
        ).fetchall()

        readded: list[dict] = []
        missing: list[dict] = []

        for row in rows:
            hash_  = row["hash"]
            name   = row["name"] or hash_
            ad_id  = int(row["ad_id"])

            if ad_id in live_ids:
                continue  # still present — nothing to do

            # Gone from AllDebrid.
            # Synthetic hashes (ad-NNN) have no real info-hash to re-upload.
            if hash_.startswith("ad-"):
                log.info(f"[repair] synthetic {hash_} gone from AD library — marking missing")
                self._set(hash_, state="missing", ad_id=None)
                missing.append({"hash": hash_, "name": name})
                continue

            log.info(f"[repair] {hash_[:8]} (ad_id={ad_id}) gone — attempting re-add")
            try:
                resp    = _ad_upload_magnet(api_key, hash_, name)
                if resp.get("status") == "error":
                    err = resp.get("error", {})
                    log.warning(f"[repair] {hash_[:8]} upload error: {err.get('code')} {err.get('message')}")
                    self._set(hash_, state="missing", ad_id=None)
                    missing.append({"hash": hash_, "name": name})
                    continue

                mags = resp.get("data", {}).get("magnets", [])
                if not mags or mags[0].get("error"):
                    err = mags[0].get("error", {}) if mags else {}
                    log.warning(f"[repair] {hash_[:8]} magnet error: {err.get('code')} {err.get('message')}")
                    self._set(hash_, state="missing", ad_id=None)
                    missing.append({"hash": hash_, "name": name})
                    continue

                m     = mags[0]
                new_id = m.get("id")
                if m.get("ready"):
                    log.info(f"[repair] {hash_[:8]} re-added and cached (new ad_id={new_id})")
                    self._set(hash_, ad_id=new_id, state="cached", is_stub=0)
                    try:
                        self._on_ready(hash_)
                    except Exception as e:
                        log.warning(f"[repair] _on_ready failed for {hash_[:8]}: {e}")
                    readded.append({"hash": hash_, "name": name})
                else:
                    log.info(f"[repair] {hash_[:8]} re-uploaded but not cached — marking missing")
                    # Clean up the magnet we just uploaded since it won't cache
                    if new_id:
                        try:
                            _ad_delete_magnet(api_key, new_id)
                        except Exception:
                            pass
                    self._set(hash_, state="missing", ad_id=None)
                    missing.append({"hash": hash_, "name": name})

            except Exception as e:
                log.warning(f"[repair] {hash_[:8]} exception: {e}")
                self._set(hash_, state="missing", ad_id=None)
                missing.append({"hash": hash_, "name": name})

        # Also add 'missing' state to migrations schema if not done
        # (state column is TEXT, so 'missing' is valid without a schema change)

        log.info(
            f"[repair] done — {len(readded)} re-added, {len(missing)} missing "
            f"out of {len(rows)} checked"
        )
        return {
            "readded":  readded,
            "missing":  missing,
            "ok":       len(readded),
            "total":    len(rows),
        }

    def _poll_loop(self):
        import fcntl
        try:
            _lf = open("/tmp/ad_poller.lock", "w")
            fcntl.flock(_lf, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            return
        while True:
            try:
                self._poll_all()
            except Exception:
                log.exception("Poller error")
            time.sleep(POLL_INTERVAL)

    def _poll_all(self):
        rows = self._db().execute(
            "SELECT hash, name, ad_id FROM transfers WHERE state='downloading'"
        ).fetchall()
        if not rows:
            return
        api_key = self._key_fn()
        if not api_key:
            return
        for row in rows:
            hash_  = row["hash"]
            ad_id  = row["ad_id"]
            if not ad_id:
                continue
            try:
                status = _ad_magnet_status(api_key, int(ad_id))
                st     = status.get("status", "")
                if status.get("ready") or st in ("Ready", "Seeding"):
                    log.info(f"[{hash_[:8]}] AllDebrid download complete")
                    self._set(hash_, state="complete")
                    self._on_ready(hash_)
                elif st in ("Error", "Fail", "Deleted"):
                    err = status.get("error", {}).get("message", st) if isinstance(status.get("error"), dict) else st
                    self._set(hash_, state="error", error=err)
            except Exception as e:
                log.debug(f"[{hash_[:8]}] poll error: {e}")
