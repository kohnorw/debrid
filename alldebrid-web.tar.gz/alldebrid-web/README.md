# AllDebrid Web Search

Search torrents and check/add to AllDebrid — in your browser.

## Quick start

```bash
docker compose up --build
```

Then open **http://localhost:5000**

## Usage

1. Paste your AllDebrid API key from https://alldebrid.com/apikeys
2. Search for any movie or show (e.g. `Breaking Bad S03`, `Oppenheimer 2023`)
3. Click **Add** on any result to send it to AllDebrid

## Search format

| Query | What it does |
|-------|-------------|
| `Breaking Bad S03` | Season 3 only |
| `Breaking Bad S03E05` | Specific episode |
| `The Bear Season 2` | Season 2 (auto-converts) |
| `Oppenheimer 2023` | By title + year |

## Run without Docker

```bash
pip install -r requirements.txt
python app.py
```
