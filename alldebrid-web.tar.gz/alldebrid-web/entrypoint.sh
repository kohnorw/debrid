#!/bin/sh
set -e

SHARE_ROOT="${SHARE_ROOT:-/docker/alldebrid-web}"
FUSE_MOUNT="${FUSE_MOUNTPOINT:-/docker/alldebrid-web/mnt}"
CACHE_DIR="${FUSE_CACHE_DIR:-/docker/alldebrid-web/cache}"
DOWNLOADS_ROOT="${DOWNLOADS_ROOT:-/docker/alldebrid-web/downloads}"
APP_PID=""
_STOPPING=0

log() { echo "[entrypoint] $*"; }

_unmount_fuse() {
    # Try graceful FUSE unmount first, then lazy unmount. Repeat because the
    # Python/FUSE thread can take a moment to release file handles during stop.
    n=0
    while [ "$n" -lt 10 ]; do
        if ! mountpoint -q "$FUSE_MOUNT" 2>/dev/null; then
            # Also treat a readable/stat-able dir as clean.
            timeout 3 stat "$FUSE_MOUNT" >/dev/null 2>&1 && return 0
        fi

        fusermount -uz "$FUSE_MOUNT" 2>/dev/null || \
        fusermount3 -uz "$FUSE_MOUNT" 2>/dev/null || \
        umount -l "$FUSE_MOUNT" 2>/dev/null || \
        umount "$FUSE_MOUNT" 2>/dev/null || true

        sleep 0.2
        n=$((n + 1))
    done

    if mountpoint -q "$FUSE_MOUNT" 2>/dev/null; then
        log "WARNING: FUSE mount still present at $FUSE_MOUNT after unmount attempts"
        return 1
    fi
    return 0
}

_cleanup() {
    code="$?"
    [ "$_STOPPING" = "1" ] && exit "$code"
    _STOPPING=1

    log "Shutdown requested — stopping app and unmounting FUSE"

    if [ -n "$APP_PID" ] && kill -0 "$APP_PID" 2>/dev/null; then
        kill -TERM "$APP_PID" 2>/dev/null || true

        # Give the app a short chance to exit cleanly.
        i=0
        while kill -0 "$APP_PID" 2>/dev/null && [ "$i" -lt 25 ]; do
            sleep 0.2
            i=$((i + 1))
        done

        if kill -0 "$APP_PID" 2>/dev/null; then
            log "App did not stop cleanly — killing"
            kill -KILL "$APP_PID" 2>/dev/null || true
        fi
        wait "$APP_PID" 2>/dev/null || true
    fi

    _unmount_fuse || true
    log "Shutdown cleanup complete"
    exit "$code"
}

trap _cleanup INT TERM HUP QUIT EXIT

# ── Step 1: ensure SHARE_ROOT is a shared bind-mount ─────────────────────────
if mountpoint -q "$SHARE_ROOT" 2>/dev/null; then
    mount --make-rshared "$SHARE_ROOT" 2>/dev/null \
        && log "$SHARE_ROOT marked rshared" \
        || log "WARNING: could not mark $SHARE_ROOT rshared"
else
    mount --bind "$SHARE_ROOT" "$SHARE_ROOT" 2>/dev/null \
        && mount --make-rshared "$SHARE_ROOT" 2>/dev/null \
        && log "$SHARE_ROOT bind-mounted and marked rshared" \
        || log "WARNING: could not bind/share $SHARE_ROOT (running without SYS_ADMIN?)"
fi

# ── Step 2: clear stale/broken FUSE mount before app starts ──────────────────
i=0
while true; do
    if mountpoint -q "$FUSE_MOUNT" 2>/dev/null; then
        log "Stale FUSE mount detected at $FUSE_MOUNT — unmounting (attempt $((i+1)))..."
        _unmount_fuse || true
    elif ! timeout 5 stat "$FUSE_MOUNT" >/dev/null 2>&1; then
        log "Broken/unresponsive endpoint at $FUSE_MOUNT — forcing unmount (attempt $((i+1)))..."
        fusermount -uz "$FUSE_MOUNT" 2>/dev/null || fusermount3 -uz "$FUSE_MOUNT" 2>/dev/null || umount -l "$FUSE_MOUNT" 2>/dev/null || true
    else
        break
    fi

    i=$((i + 1))
    if [ "$i" -ge 15 ]; then
        log "WARNING: could not fully clear $FUSE_MOUNT after 15 attempts — proceeding anyway"
        break
    fi
    sleep 0.2
done

# ── Step 3: ensure directories exist ─────────────────────────────────────────
mkdir -p "$FUSE_MOUNT" "$CACHE_DIR" "$DOWNLOADS_ROOT"
chmod 777 "$DOWNLOADS_ROOT"

log "Startup complete — launching app"
python /app/app.py &
APP_PID="$!"
wait "$APP_PID"
