import os
import re
import urllib.parse
import requests
from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

APIBAY_URLS = [
    "https://apibay.org/q.php",
    "https://apibay.nocensor.space/q.php",
    "https://thepiratebay.org/q.php",
]
ALLDEBRID_UPLOAD = "https://api.alldebrid.com/v4/magnet/upload"
ALLDEBRID_DELETE = "https://api.alldebrid.com/v4/magnet/delete"

CATEGORIES = {
    range(200, 300): "Movie",
    range(500, 600): "TV Show",
    range(300, 400): "Audio",
    range(600, 700): "XXX",
}

# ── helpers ───────────────────────────────────────────────────────────────────

def get_category(cat_id):
    try:
        c = int(cat_id)
        for r, name in CATEGORIES.items():
            if c in r:
                return name
    except Exception:
        pass
    return "Other"

def fmt_size(b):
    try:
        b = int(b)
    except Exception:
        return "?"
    if b > 1_000_000_000: return f"{b/1_000_000_000:.2f} GB"
    if b > 1_000_000:     return f"{b/1_000_000:.0f} MB"
    if b > 1_000:         return f"{b/1_000:.0f} KB"
    return f"{b} B"

def parse_query(raw):
    season, episode = None, None
    m = re.search(r'\bseason\s+(\d+)\b', raw, re.IGNORECASE)
    if m:
        season = int(m.group(1))
        raw = re.sub(r'\bseason\s+\d+\b', f'S{season:02d}', raw, flags=re.IGNORECASE)
    m = re.search(r'\bS(\d{1,2})(?:E(\d{1,2}))?\b', raw, re.IGNORECASE)
    if m:
        season = int(m.group(1))
        if m.group(2):
            episode = int(m.group(2))
    return raw.strip(), season, episode

def strip_season(query):
    t = re.sub(r'\bS\d{1,2}(?:E\d{1,2})?\b', '', query, flags=re.IGNORECASE)
    return ' '.join(t.split())

def _fetch(query, limit=40):
    for url in APIBAY_URLS:
        try:
            r = requests.get(url, params={"q": query, "cat": 0}, timeout=10)
            if r.status_code != 200:
                continue
            data = r.json()
            if not data or (isinstance(data, list) and data[0].get("id") == "0"):
                continue
            valid = [
                x for x in data
                if isinstance(x, dict)
                and x.get("info_hash")
                and re.fullmatch(r'[0-9a-fA-F]{40}', x["info_hash"])
            ]
            if valid:
                return valid[:limit]
        except Exception:
            continue
    return []

def filter_by_season(torrents, season, episode):
    if season is None:
        return torrents
    s_str = f"S{season:02d}"
    s_alt = f"SEASON {season}"
    out = []
    for t in torrents:
        nu = t.get("name", "").upper()
        if s_str not in nu and s_alt not in nu:
            continue
        others = re.findall(r'S(\d{2})E\d{2}', nu)
        if others and not all(int(s) == season for s in others):
            continue
        if episode is not None and f"E{episode:02d}" not in nu:
            continue
        out.append(t)
    return out

def _make_magnet(torrent):
    h    = torrent["info_hash"].lower()
    name = urllib.parse.quote(torrent.get("name", ""), safe="")
    return f"magnet:?xt=urn:btih:{h}&dn={name}"

def _ad_post(api_key, torrents):
    if not torrents:
        return {}
    pairs = [("magnets[]", _make_magnet(t)) for t in torrents]
    body  = urllib.parse.urlencode(pairs)
    try:
        r = requests.post(
            ALLDEBRID_UPLOAD,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type":  "application/x-www-form-urlencoded",
            },
            data=body,
            timeout=15,
        )
        r.raise_for_status()
        return r.json()
    except requests.RequestException:
        return {}

def _delete_magnets(api_key, ids):
    for mid in ids:
        try:
            body = urllib.parse.urlencode({"id": mid})
            requests.post(
                ALLDEBRID_DELETE,
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type":  "application/x-www-form-urlencoded",
                },
                data=body,
                timeout=10,
            )
        except Exception:
            pass

def check_cache(api_key, torrents):
    result = _ad_post(api_key, torrents)
    if result.get("status") == "error":
        return {}, {}
    ready_map = {}
    ids_to_delete = []
    for m in result.get("data", {}).get("magnets", []):
        if m.get("error"):
            continue
        h   = (m.get("hash") or "").lower()
        mid = m.get("id")
        if h:
            ready_map[h] = bool(m.get("ready", False))
        if mid:
            ids_to_delete.append(mid)
    _delete_magnets(api_key, ids_to_delete)
    return ready_map

def add_magnet(api_key, torrent):
    result = _ad_post(api_key, [torrent])
    magnets = result.get("data", {}).get("magnets", [])
    if not magnets:
        return {"error": result.get("error", {}).get("message", "Unknown error")}
    m = magnets[0]
    if m.get("error"):
        return {"error": m["error"].get("message", "Unknown error")}
    return {
        "name":  m.get("name", torrent.get("name", "?")),
        "ready": bool(m.get("ready", False)),
        "id":    m.get("id"),
    }

# ── routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/search", methods=["POST"])
def search():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip()
    query   = data.get("query", "").strip()

    if not api_key:
        return jsonify({"error": "API key required"}), 400
    if not query:
        return jsonify({"error": "Query required"}), 400

    parsed_query, season, episode = parse_query(query)

    torrents = _fetch(parsed_query, 40)
    if not torrents and season is not None:
        fallback = strip_season(parsed_query)
        if fallback and fallback.lower() != parsed_query.lower():
            torrents = _fetch(fallback, 80)

    if not torrents:
        return jsonify({"results": [], "total": 0})

    filtered = filter_by_season(torrents, season, episode)
    if not filtered and season is not None:
        filtered = torrents
    if not filtered:
        return jsonify({"results": [], "total": 0})

    ready_map = check_cache(api_key, filtered)

    results = []
    for t in filtered:
        h = t["info_hash"].lower()
        results.append({
            "hash":     h,
            "name":     t.get("name", "Unknown"),
            "size":     fmt_size(t.get("size", 0)),
            "seeders":  t.get("seeders", "?"),
            "category": get_category(t.get("category", 0)),
            "cached":   ready_map.get(h, False),
        })

    # Sort: cached first, then by seeders desc
    results.sort(key=lambda x: (not x["cached"], -int(x["seeders"]) if str(x["seeders"]).isdigit() else 0))

    return jsonify({"results": results, "total": len(results)})

@app.route("/api/add", methods=["POST"])
def add():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip()
    hash_   = data.get("hash", "").strip().lower()
    name    = data.get("name", "").strip()

    if not api_key or not hash_:
        return jsonify({"error": "api_key and hash required"}), 400

    result = add_magnet(api_key, {"info_hash": hash_, "name": name})
    if "error" in result:
        return jsonify(result), 400
    return jsonify(result)

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
