import os
import re
import json
import hmac
import secrets
import threading
import time
import urllib.parse
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from xml.sax.saxutils import escape as xml_escape

import requests
from flask import Flask, request, jsonify, render_template, Response

import logging
import sys

app = Flask(__name__)

logging.basicConfig(
    stream=sys.stdout, level=logging.INFO,
    format="[%(asctime)s] %(levelname)s in %(name)s: %(message)s", force=True,
)
app.logger.setLevel(logging.INFO)

def _log(msg: str) -> None:
    try:
        app.logger.warning(msg)
    except Exception:
        pass

# ── Thread pool ───────────────────────────────────────────────────────────────
_pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="ad-worker")

# ── AllDebrid API endpoints ───────────────────────────────────────────────────
AD_BASE        = "https://api.alldebrid.com/v4"
AD_UPLOAD      = f"{AD_BASE}/magnet/upload"
AD_DELETE      = f"{AD_BASE}/magnet/delete"
AD_STATUS      = "https://api.alldebrid.com/v4.1/magnet/status"
AD_FILES       = f"{AD_BASE}/magnet/files"
AD_UNLOCK      = f"{AD_BASE}/link/unlock"
AD_USER        = f"{AD_BASE}/user"

AD_API_KEY_ENV = os.environ.get("ALLDEBRID_API_KEY", "")
TORZNAB_APIKEY = os.environ.get("TORZNAB_APIKEY", "changeme")
PROWLARR_URL   = os.environ.get("PROWLARR_URL", "")
PROWLARR_KEY   = os.environ.get("PROWLARR_API_KEY", "")

# ── AllDebrid rate limiter ────────────────────────────────────────────────────
# AllDebrid allows 12 req/s and 600 req/min by their docs.
# We self-limit to 250 req/min (configurable) — comfortably inside the ceiling,
# with headroom for bursts. Implemented as a sliding-window token bucket so
# the sustained rate never exceeds the configured limit regardless of thread count.

_AD_RATE_LIMIT  = int(os.environ.get("AD_RATE_LIMIT",  "250"))  # tokens per window
_AD_RATE_WINDOW = 60.0                                            # window in seconds

_ad_rate_lock  = threading.Lock()
_ad_timestamps: list[float] = []  # sorted list of recent API call monotonic timestamps


def _ad_api_acquire() -> None:
    """
    Block the calling thread until an AllDebrid API slot is available.

    Uses a sliding-window algorithm: maintains a list of the timestamps of the
    last _AD_RATE_LIMIT calls within the past _AD_RATE_WINDOW seconds. When
    the window is full, sleeps until the oldest call ages out, then claims a slot.
    Thread-safe via _ad_rate_lock.
    """
    while True:
        now    = time.monotonic()
        cutoff = now - _AD_RATE_WINDOW
        with _ad_rate_lock:
            # Drop timestamps that have aged out of the window
            while _ad_timestamps and _ad_timestamps[0] < cutoff:
                _ad_timestamps.pop(0)
            if len(_ad_timestamps) < _AD_RATE_LIMIT:
                _ad_timestamps.append(now)
                return
            # Window is full — calculate exactly how long until the oldest slot frees
            wait = (_ad_timestamps[0] - cutoff) + 0.01   # +10 ms to avoid rounding slip
        time.sleep(max(wait, 0.05))


def _ad_headers(api_key: str) -> dict:
    return {"Authorization": f"Bearer {api_key}"}


def _ad_post(api_key: str, url: str, data: dict | None = None, params: dict | None = None) -> dict:
    """Rate-limited POST to AllDebrid. Consumes one rate-limit token."""
    _ad_api_acquire()
    try:
        r = requests.post(
            url,
            headers={**_ad_headers(api_key), "Content-Type": "application/x-www-form-urlencoded"},
            data=urllib.parse.urlencode(data or {}),
            params=params,
            timeout=20,
        )
        r.raise_for_status()
        return r.json()
    except Exception as e:
        app.logger.debug(f"[ad-post] {url}: {e}")
        return {}


def _ad_get(api_key: str, url: str, params: dict | None = None) -> dict:
    """Rate-limited GET to AllDebrid. Consumes one rate-limit token."""
    _ad_api_acquire()
    try:
        r = requests.get(url, headers=_ad_headers(api_key), params=params, timeout=20)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        app.logger.debug(f"[ad-get] {url}: {e}")
        return {}

# ── Torznab per-IP rate limiter ───────────────────────────────────────────────
# Separate from the AllDebrid limiter — this caps external clients (Prowlarr,
# Sonarr, Radarr) so they cannot flood the AllDebrid quota.

TORZNAB_RATE_LIMIT  = int(os.environ.get("TORZNAB_RATE_LIMIT",  "60"))
TORZNAB_RATE_WINDOW = int(os.environ.get("TORZNAB_RATE_WINDOW", "60"))

_tz_rate_lock = threading.Lock()
_tz_rate_data: dict[str, list] = defaultdict(list)


def _check_torznab_rate(ip: str):
    now    = time.time()
    cutoff = now - TORZNAB_RATE_WINDOW
    with _tz_rate_lock:
        hits      = [t for t in _tz_rate_data[ip] if t > cutoff]
        remaining = max(0, TORZNAB_RATE_LIMIT - len(hits))
        reset_ts  = int(now + TORZNAB_RATE_WINDOW)
        if remaining == 0:
            return False, TORZNAB_RATE_LIMIT, 0, reset_ts
        hits.append(now)
        _tz_rate_data[ip] = hits
        return True, TORZNAB_RATE_LIMIT, remaining - 1, reset_ts


def _rate_headers(limit, remaining, reset_ts):
    return {
        "X-RateLimit-Limit":     str(limit),
        "X-RateLimit-Remaining": str(remaining),
        "X-RateLimit-Reset":     str(reset_ts),
    }

# ── Persistent config ─────────────────────────────────────────────────────────
CONFIG_PATH   = os.environ.get("CONFIG_PATH", "/app/config.json")
_cfg_lock     = threading.Lock()
_cfg_cache: dict | None = None


def _load_config() -> dict:
    global _cfg_cache
    if _cfg_cache is not None:
        return _cfg_cache
    try:
        with open(CONFIG_PATH) as f:
            _cfg_cache = json.load(f)
    except Exception:
        _cfg_cache = {}
    return _cfg_cache


def _save_config(cfg: dict):
    global _cfg_cache
    os.makedirs(os.path.dirname(CONFIG_PATH) or ".", exist_ok=True)
    with _cfg_lock:
        _cfg_cache = cfg
        with open(CONFIG_PATH, "w") as f:
            json.dump(cfg, f, indent=2)


def get_ad_api_key() -> str:
    return AD_API_KEY_ENV or _load_config().get("ad_api_key", "")


def save_ad_api_key(key: str):
    cfg = _load_config()
    cfg["ad_api_key"] = key
    _save_config(cfg)


def get_prowlarr_config() -> dict:
    saved = _load_config().get("prowlarr", {})
    return {
        "url":      PROWLARR_URL or saved.get("url", ""),
        "api_key":  PROWLARR_KEY or saved.get("api_key", ""),
        "from_env": bool(PROWLARR_URL or PROWLARR_KEY),
    }


def save_prowlarr_config(url: str, api_key: str):
    url = url.strip().rstrip("/")
    if url and not url.startswith(("http://", "https://")):
        url = "http://" + url
    cfg = _load_config()
    cfg["prowlarr"] = {"url": url, "api_key": api_key}
    _save_config(cfg)

# ── SQLite transfer + file index ──────────────────────────────────────────────
DB_PATH = os.environ.get("DB_PATH", "/app/alldebrid.db")
_db_lock = threading.Lock()

# After this many days of no playback a transfer is stubbed out of AllDebrid
STUB_AFTER_DAYS = int(os.environ.get("STUB_AFTER_DAYS", "30"))
STUB_AFTER_SECS = STUB_AFTER_DAYS * 86400

import sqlite3


def _db_connect() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH, check_same_thread=False)
    con.row_factory = sqlite3.Row
    return con


def _db_init():
    os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
    with _db_lock:
        con = _db_connect()
        con.executescript("""
            CREATE TABLE IF NOT EXISTS transfers (
                hash        TEXT PRIMARY KEY,
                name        TEXT,
                ad_id       INTEGER,
                state       TEXT DEFAULT 'queued',
                added_at    REAL,
                last_played REAL,
                is_stub     INTEGER DEFAULT 0,
                category    TEXT DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS files (
                hash        TEXT NOT NULL,
                name        TEXT NOT NULL,
                path        TEXT,
                link        TEXT,
                size        INTEGER DEFAULT 0,
                is_video    INTEGER DEFAULT 0,
                fetched_at  REAL,
                PRIMARY KEY (hash, name)
            );
            CREATE INDEX IF NOT EXISTS idx_transfers_state  ON transfers(state);
            CREATE INDEX IF NOT EXISTS idx_transfers_stub   ON transfers(is_stub);
            CREATE INDEX IF NOT EXISTS idx_transfers_played ON transfers(last_played);
            CREATE INDEX IF NOT EXISTS idx_files_hash       ON files(hash);
        """)
        con.commit()
        con.close()


_db_init()


def _db_get(hash_: str) -> dict | None:
    with _db_lock:
        con = _db_connect()
        row = con.execute("SELECT * FROM transfers WHERE hash=?", (hash_,)).fetchone()
        con.close()
    return dict(row) if row else None


def _db_set(hash_: str, **kwargs):
    with _db_lock:
        con = _db_connect()
        exists = con.execute("SELECT 1 FROM transfers WHERE hash=?", (hash_,)).fetchone()
        if exists:
            if kwargs:
                sets = ", ".join(f"{k}=?" for k in kwargs)
                vals = list(kwargs.values()) + [hash_]
                con.execute(f"UPDATE transfers SET {sets} WHERE hash=?", vals)
        else:
            kwargs.setdefault("added_at", time.time())
            kwargs["hash"] = hash_
            cols = ", ".join(kwargs.keys())
            phs  = ", ".join("?" * len(kwargs))
            con.execute(f"INSERT INTO transfers ({cols}) VALUES ({phs})", list(kwargs.values()))
        con.commit()
        con.close()


def _db_delete(hash_: str):
    with _db_lock:
        con = _db_connect()
        con.execute("DELETE FROM transfers WHERE hash=?", (hash_,))
        con.execute("DELETE FROM files WHERE hash=?", (hash_,))
        con.commit()
        con.close()


def _db_all() -> list:
    with _db_lock:
        con = _db_connect()
        rows = con.execute("SELECT * FROM transfers ORDER BY added_at DESC").fetchall()
        con.close()
    return [dict(r) for r in rows]


def _db_store_files(hash_: str, files: list):
    with _db_lock:
        con = _db_connect()
        con.execute("DELETE FROM files WHERE hash=?", (hash_,))
        now = time.time()
        for f in files:
            con.execute(
                "INSERT OR REPLACE INTO files (hash, name, path, link, size, is_video, fetched_at) "
                "VALUES (?,?,?,?,?,?,?)",
                (hash_, f.get("name",""), f.get("path",""), f.get("link",""),
                 int(f.get("size",0) or 0), int(bool(f.get("is_video"))), now),
            )
        con.commit()
        con.close()


def _db_get_files(hash_: str) -> list:
    with _db_lock:
        con = _db_connect()
        rows = con.execute("SELECT * FROM files WHERE hash=?", (hash_,)).fetchall()
        con.close()
    return [dict(r) for r in rows]


def _db_touch_played(hash_: str):
    """Record playback — updates last_played and clears stub flag."""
    _db_set(hash_, last_played=time.time(), is_stub=0)

# ── 30-day stub manager ───────────────────────────────────────────────────────
# Runs hourly. Transfers inactive for STUB_AFTER_DAYS days are:
#   1. Deleted from AllDebrid (frees space / quota)
#   2. Marked is_stub=1 in the DB
# On stub playback (_ensure_ad_magnet / /api/links), the magnet is re-added
# to AllDebrid automatically before links are resolved.

_stub_stop   = threading.Event()
_stub_thread: threading.Thread | None = None


def _do_stub_pass():
    cutoff    = time.time() - STUB_AFTER_SECS
    transfers = _db_all()
    stubbed   = 0
    for t in transfers:
        if t.get("is_stub"):
            continue
        if t.get("state") not in ("cached", "complete"):
            continue
        last     = t.get("last_played") or t.get("added_at") or 0
        if last and last < cutoff:
            hash_  = t["hash"]
            ad_id  = t.get("ad_id")
            name   = t.get("name") or hash_
            _log(f"[stub] stubbing '{name[:60]}' (inactive >{STUB_AFTER_DAYS}d)")
            if ad_id:
                api_key = get_ad_api_key()
                if api_key:
                    _ad_delete_magnet(api_key, ad_id)
            _db_set(hash_, is_stub=1, ad_id=None)
            stubbed += 1
    if stubbed:
        _log(f"[stub] pass complete — {stubbed} transfer(s) stubbed")


def _stub_loop():
    while not _stub_stop.wait(timeout=3600):
        try:
            _do_stub_pass()
        except Exception as e:
            _log(f"[stub] loop error: {e}")


def _start_stub_manager():
    global _stub_thread
    _stub_stop.clear()
    _stub_thread = threading.Thread(target=_stub_loop, daemon=True, name="stub-manager")
    _stub_thread.start()
    _log(f"[stub] manager started — stub after {STUB_AFTER_DAYS}d inactivity")


_start_stub_manager()

# ── AllDebrid magnet helpers ───────────────────────────────────────────────────

APIBAY_URLS = [
    "https://apibay.org/q.php",
    "https://apibay.nocensor.space/q.php",
    "https://thepiratebay.org/q.php",
]


def _make_magnet(hash_: str, name: str = "") -> str:
    h = hash_.lower()
    n = urllib.parse.quote(name, safe="")
    return f"magnet:?xt=urn:btih:{h}&dn={n}" if n else f"magnet:?xt=urn:btih:{h}"


def _ad_upload_magnets_raw(api_key: str, magnets: list) -> dict:
    """
    Upload magnets to AllDebrid. Consumes ONE rate-limit token for the batch.
    Returns raw response dict.
    """
    pairs = [("magnets[]", m) for m in magnets]
    _ad_api_acquire()
    try:
        r = requests.post(
            AD_UPLOAD,
            headers={**_ad_headers(api_key), "Content-Type": "application/x-www-form-urlencoded"},
            data=urllib.parse.urlencode(pairs),
            timeout=20,
        )
        r.raise_for_status()
        return r.json()
    except Exception as e:
        app.logger.debug(f"[ad-upload] {e}")
        return {}


def _ad_delete_magnet(api_key: str, magnet_id: int):
    """Delete a single magnet from AllDebrid. Consumes one rate-limit token."""
    if not api_key or not magnet_id:
        return
    _ad_api_acquire()
    try:
        requests.post(
            AD_DELETE,
            headers={**_ad_headers(api_key), "Content-Type": "application/x-www-form-urlencoded"},
            data=urllib.parse.urlencode({"id": magnet_id}),
            timeout=15,
        )
    except Exception as e:
        app.logger.debug(f"[ad-delete] id={magnet_id}: {e}")

# ── Cache check ───────────────────────────────────────────────────────────────
# Cache-check flow:
#   1. Upload all magnets in a single batch POST (1 API call)
#   2. Read the `ready` field on each returned magnet entry
#   3. Delete all uploaded magnet IDs (1 API call per ID, fire-and-forget)
#
# Nothing permanent is added to the user's library — the uploads and deletes
# are symmetrical.  Results are cached in-process for 5 minutes so repeated
# searches for the same hashes cost only one upstream batch.

_cache_check_results: dict = {}
_cache_check_lock = threading.Lock()
_CACHE_CHECK_TTL  = 300  # 5 minutes


def check_cache_ad(api_key: str, torrents: list) -> dict:
    """Return {hash: bool} — True means AllDebrid has it instantly cached."""
    if not torrents or not api_key:
        return {}

    hashes = [t["info_hash"].lower() for t in torrents]
    now    = time.time()

    with _cache_check_lock:
        stale = [h for h in hashes
                 if h not in _cache_check_results or now >= _cache_check_results[h][1]]

    if not stale:
        with _cache_check_lock:
            return {h: _cache_check_results[h][0] for h in hashes
                    if h in _cache_check_results}

    torrent_map = {t["info_hash"].lower(): t for t in torrents}
    magnets     = [_make_magnet(h, torrent_map[h].get("name", "")) for h in stale]

    result      = _ad_upload_magnets_raw(api_key, magnets)
    ready_map: dict[str, bool] = {}
    ids_to_delete: list        = []

    for m in result.get("data", {}).get("magnets", []):
        if m.get("error"):
            continue
        h = (m.get("hash") or "").lower()
        if h:
            ready_map[h] = bool(m.get("ready", False))
        mid = m.get("id")
        if mid:
            ids_to_delete.append(mid)

    # Delete uploaded magnets asynchronously — keeps the response fast and
    # stays within rate limit because each delete is a separate token.
    for mid in ids_to_delete:
        _pool.submit(_ad_delete_magnet, api_key, mid)

    expire = now + _CACHE_CHECK_TTL
    with _cache_check_lock:
        for h in stale:
            _cache_check_results[h] = (ready_map.get(h, False), expire)

    with _cache_check_lock:
        return {h: _cache_check_results[h][0] for h in hashes
                if h in _cache_check_results}

# ── Search (TPB + Prowlarr) ───────────────────────────────────────────────────

QUALITY_PATTERNS = re.compile(
    r'\b(2160p?|1080p?|720p?|480p?|4k|uhd|hdr|hdr10|dv|web-?dl|webrip|bluray|'
    r'blu-ray|hevc|x265|x264|h264|h265|remux|proper|repack)\b',
    re.IGNORECASE,
)


def fmt_size(b):
    try:    return int(b)
    except: return 0


def fmt_size_str(b):
    try:    b = int(b)
    except: return "?"
    if b > 1_000_000_000: return f"{b/1_000_000_000:.2f} GB"
    if b > 1_000_000:     return f"{b/1_000_000:.0f} MB"
    if b > 1_000:         return f"{b/1_000:.0f} KB"
    return f"{b} B"


def _sanitize(q: str) -> str:
    q = re.sub(r"[''`´]", "", q)
    q = re.sub(r"[^\w\s\-]", " ", q)
    return re.sub(r"\s+", " ", q).strip()


def parse_query(raw: str):
    quality    = QUALITY_PATTERNS.findall(raw)
    search_raw = QUALITY_PATTERNS.sub("", raw).strip()
    season = episode = None
    m = re.search(r'\bseason\s+(\d+)\b', search_raw, re.IGNORECASE)
    if m:
        season     = int(m.group(1))
        search_raw = re.sub(r'\bseason\s+\d+\b', f'S{season:02d}', search_raw, flags=re.IGNORECASE)
    m = re.search(r'(?<![a-zA-Z])S(\d{1,2})(?:E(\d{1,2}))?(?![a-zA-Z0-9])', search_raw, re.IGNORECASE)
    if m:
        season = int(m.group(1))
        if m.group(2):
            episode = int(m.group(2))
    return " ".join(search_raw.split()).strip(), season, episode, quality


def strip_season(q: str) -> str:
    t = re.sub(r'(?<![a-zA-Z])S\d{1,2}(?:E\d{1,2})?(?![a-zA-Z0-9])', '', q, flags=re.IGNORECASE)
    return " ".join(t.split())


def tpb_to_newznab(cat, name=""):
    nu = (name or "").upper()
    if re.search(r'S\d{2}E\d{2}|SEASON\s+\d+|\bS\d{2}\b', nu):
        return 5000
    try:    c = int(cat)
    except: return 8000
    if 200 <= c < 300: return 2000
    if 500 <= c < 600: return 5000
    if 300 <= c < 400: return 3000
    return 8000


def normalize_newznab_category(cat, name=""):
    try:    c = int(cat or 0)
    except: c = 0
    if 0 < c < 1000: return tpb_to_newznab(c, name)
    if c >= 1000:    return c
    return 8000


def _fetch_tpb(query: str, limit: int = 40) -> list:
    queries = [query]
    san = _sanitize(query)
    if san.lower() != query.lower():
        queries.append(san)
    for q in queries:
        for url in APIBAY_URLS:
            try:
                r = requests.get(url, params={"q": q, "cat": 0}, timeout=10)
                if r.status_code != 200:
                    continue
                data = r.json()
                if not data or (isinstance(data, list) and data[0].get("id") == "0"):
                    continue
                valid = [x for x in data
                         if isinstance(x, dict) and x.get("info_hash")
                         and re.fullmatch(r'[0-9a-fA-F]{40}', x["info_hash"])]
                if valid:
                    return valid[:limit]
            except Exception:
                continue
    return []


def _fetch_prowlarr(query: str, season=None, episode=None, limit: int = 40) -> list:
    cfg = get_prowlarr_config()
    if not cfg.get("url") or not cfg.get("api_key"):
        return []
    base, key = cfg["url"], cfg["api_key"]
    q = query
    if season is not None:
        q_base = strip_season(query)
        q = f"{q_base} S{season:02d}" if q_base else f"S{season:02d}"
        if episode is not None:
            q += f"E{episode:02d}"
        q = " ".join(q.split())
    try:
        r = requests.get(
            f"{base}/api/v1/search",
            headers={"X-Api-Key": key},
            params={"query": q, "indexerIds": -2,
                    "categories": [2000, 5000, 8000], "type": "search", "limit": limit},
            timeout=20,
        )
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        app.logger.warning(f"Prowlarr search failed: {e}")
        return []

    def _extract_hash(item: dict) -> str:
        h = (item.get("infoHash") or "").lower().strip()
        if re.fullmatch(r'[0-9a-fA-F]{40}', h):
            return h
        for field in ("magnetUrl", "downloadUrl", "guid"):
            val = item.get(field) or ""
            m = re.search(r'btih:([0-9a-fA-F]{40})', val, re.IGNORECASE)
            if m: return m.group(1).lower()
            m = re.search(r'(?<![0-9a-fA-F])([0-9a-fA-F]{40})(?![0-9a-fA-F])', val)
            if m: return m.group(1).lower()
        return ""

    results = []
    for item in data:
        h = _extract_hash(item)
        if not h:
            continue
        cats = item.get("categories") or []
        cat  = 8000
        for c in cats:
            cid = c.get("id", 0) if isinstance(c, dict) else c
            try:   cid = int(cid or 0)
            except: continue
            if 2000 <= cid < 3000: cat = cid; break
            if 5000 <= cid < 6000: cat = cid; break
        results.append({
            "info_hash": h,
            "name":      item.get("title", "Unknown"),
            "size":      item.get("size", 0),
            "seeders":   item.get("seeders", 0) or 0,
            "leechers":  item.get("leechers", 0) or 0,
            "category":  cat,
            "indexer":   item.get("indexer", ""),
        })
    return results


def do_search(query, season=None, episode=None, quality=None, limit=40, ad_key=None):
    cfg = get_prowlarr_config()
    if cfg.get("url") and cfg.get("api_key"):
        torrents = _fetch_prowlarr(query, season, episode, limit)
        source   = "prowlarr"
    else:
        torrents = []
        source   = "tpb"

    if not torrents:
        torrents = _fetch_tpb(query, limit)
        source   = "tpb"
        if not torrents and season is not None:
            fb = strip_season(query)
            if fb and fb.lower() != query.lower():
                torrents = _fetch_tpb(fb, limit * 2)

    if not torrents:
        return []

    if source == "tpb":
        if season is not None:
            s_str = f"S{season:02d}"
            s_alt = f"SEASON {season}"
            filtered = [t for t in torrents
                        if s_str in t.get("name","").upper() or s_alt in t.get("name","").upper()]
            if filtered:
                torrents = filtered
        if quality:
            qf = [t for t in torrents
                  if any(q.upper().rstrip("P") in t.get("name","").upper() for q in quality)]
            if qf:
                torrents = qf

    # Cache check: upload batch to AllDebrid, read ready flags, delete uploaded IDs
    ready_map = check_cache_ad(ad_key, torrents) if ad_key else {}

    results, seen = [], set()
    for t in torrents:
        h = t["info_hash"].lower()
        if h in seen:
            continue
        seen.add(h)
        cat = normalize_newznab_category(t.get("category", 8000), t.get("name", ""))
        results.append({
            "hash":     h,
            "name":     t.get("name", "Unknown"),
            "size":     fmt_size(t.get("size", 0)),
            "size_str": fmt_size_str(t.get("size", 0)),
            "seeders":  int(t.get("seeders", 0) or 0),
            "leechers": int(t.get("leechers", 0) or 0),
            "category": cat,
            "cached":   ready_map.get(h, False),
            "indexer":  t.get("indexer", "TPB"),
        })
    results.sort(key=lambda x: (not x["cached"], -x["seeders"]))
    return results

# ── Torznab XML ───────────────────────────────────────────────────────────────

_FALLBACK_TRACKERS = [
    "udp://tracker.opentrackr.org:1337/announce",
    "udp://open.tracker.cl:1337/announce",
    "udp://tracker.openbittorrent.com:6969/announce",
    "udp://tracker.torrent.eu.org:451/announce",
]


def torznab_caps() -> str:
    return '''<?xml version="1.0" encoding="UTF-8"?>
<caps>
  <server title="AllDebrid Indexer" />
  <limits default="40" max="100"/>
  <searching>
    <search available="yes" supportedParams="q"/>
    <tv-search available="yes" supportedParams="q,season,ep"/>
    <movie-search available="yes" supportedParams="q"/>
  </searching>
  <categories>
    <category id="2000" name="Movies">
      <subcat id="2010" name="Movies/Foreign"/>
      <subcat id="2030" name="Movies/SD"/>
      <subcat id="2040" name="Movies/HD"/>
      <subcat id="2045" name="Movies/UHD"/>
      <subcat id="2050" name="Movies/BluRay"/>
    </category>
    <category id="5000" name="TV">
      <subcat id="5010" name="TV/WEB-DL"/>
      <subcat id="5030" name="TV/SD"/>
      <subcat id="5040" name="TV/HD"/>
      <subcat id="5045" name="TV/UHD"/>
    </category>
    <category id="8000" name="Other"/>
  </categories>
</caps>'''


def torznab_results(results: list, query: str = "") -> str:
    now   = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
    items = []
    for r in results:
        tr_params = "".join(f"&tr={urllib.parse.quote(t, safe='')}" for t in _FALLBACK_TRACKERS)
        magnet    = (f"magnet:?xt=urn:btih:{r['hash']}"
                     f"&dn={urllib.parse.quote(r['name'], safe='')}{tr_params}")
        cached_attr = '<torznab:attr name="cached" value="1"/>' if r.get("cached") else ""
        added_at    = r.get("added_at") or 0
        pub_date    = (datetime.fromtimestamp(float(added_at), tz=timezone.utc)
                       .strftime("%a, %d %b %Y %H:%M:%S +0000") if added_at else now)
        items.append(f"""    <item>
      <title>{xml_escape(r['name'])}</title>
      <guid>{xml_escape(magnet)}</guid>
      <link>{xml_escape(magnet)}</link>
      <pubDate>{pub_date}</pubDate>
      <size>{r['size']}</size>
      <enclosure url="{xml_escape(magnet)}" length="{r['size']}" type="application/x-bittorrent"/>
      <torznab:attr name="magneturl" value="{xml_escape(magnet)}"/>
      <torznab:attr name="infohash" value="{r['hash']}"/>
      <torznab:attr name="seeders" value="{r.get('seeders', 0)}"/>
      <torznab:attr name="leechers" value="{r.get('leechers', 0)}"/>
      <torznab:attr name="size" value="{r['size']}"/>
      <torznab:attr name="category" value="{normalize_newznab_category(r.get('category'), r.get('name',''))}"/>
      {cached_attr}
    </item>""")
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:torznab="http://torznab.com/schemas/2015/feed">
  <channel>
    <title>AllDebrid Indexer</title>
    <description>TPB/Prowlarr via AllDebrid cache check</description>
    <link>http://localhost</link>
    <language>en-US</language>
    <pubDate>{now}</pubDate>
    <response xmlns="urn:newznab:api" offset="0" total="{len(results)}"/>
{chr(10).join(items)}
  </channel>
</rss>'''


def xml_error(code, description, extra_headers=None):
    r = Response(
        f'''<?xml version="1.0" encoding="UTF-8"?>
<error code="{code}" description="{xml_escape(description)}"/>''',
        mimetype="application/xml", status=400,
    )
    if extra_headers:
        for k, v in extra_headers.items():
            r.headers[k] = v
    return r

# ── File / link helpers ────────────────────────────────────────────────────────

VIDEO_EXTS = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts", ".wmv", ".flv", ".webm"}


def _collect_links(node) -> list:
    """Recursively collect file leaf nodes from AllDebrid's nested file tree."""
    links = []
    if isinstance(node, list):
        for item in node:
            links.extend(_collect_links(item))
    elif isinstance(node, dict):
        if node.get("l"):
            links.append({"name": node.get("n",""), "link": node["l"], "size": node.get("s",0)})
        if node.get("e"):
            links.extend(_collect_links(node["e"]))
    return links


def _fetch_ad_files(api_key: str, magnet_id: int) -> list:
    """Fetch and flatten file list for an uploaded AllDebrid magnet."""
    data = _ad_get(api_key, AD_FILES, params={"id[]": magnet_id})
    raw  = data.get("data", {}).get("magnets", [])
    files = []
    for m in raw:
        for f in _collect_links(m.get("files", [])):
            ext = os.path.splitext(f["name"])[1].lower()
            files.append({**f, "path": f["name"], "is_video": ext in VIDEO_EXTS})
    return files


def _ensure_ad_magnet(api_key: str, hash_: str, name: str) -> tuple:
    """
    Ensure the magnet is in AllDebrid and return (magnet_id, files).
    If already tracked in the DB with an ad_id, reuses it.
    Otherwise uploads fresh. The magnet STAYS in the user's library after this.
    """
    t     = _db_get(hash_)
    ad_id = t.get("ad_id") if t else None

    if not ad_id:
        magnet  = _make_magnet(hash_, name)
        result  = _ad_upload_magnets_raw(api_key, [magnet])
        magnets = result.get("data", {}).get("magnets", [])
        if not magnets or magnets[0].get("error"):
            return None, []
        m     = magnets[0]
        ad_id = m.get("id")
        if ad_id:
            _db_set(hash_, ad_id=ad_id, name=name or hash_,
                    state="cached" if m.get("ready") else "queued", is_stub=0)

    if not ad_id:
        return None, []

    # Return files from DB cache if available, else fetch fresh
    files = _db_get_files(hash_)
    if not files:
        files = _fetch_ad_files(api_key, ad_id)
        if files:
            _db_store_files(hash_, files)

    return ad_id, files


def _unlock_link(api_key: str, link: str) -> str | None:
    """Unlock a single AllDebrid link. Returns direct CDN URL or None."""
    data = _ad_get(api_key, AD_UNLOCK, params={"link": link})
    return data.get("data", {}).get("link")

# ── HMAC stream tokens ────────────────────────────────────────────────────────

def _get_token_secret() -> str:
    cfg = _load_config()
    if "token_secret" not in cfg:
        cfg["token_secret"] = secrets.token_hex(32)
        _save_config(cfg)
    return cfg["token_secret"]


def _make_stream_token(hash_: str, filename: str) -> str:
    secret = _get_token_secret().encode()
    return hmac.new(secret, f"{hash_}:{filename}".encode(), "sha256").hexdigest()


def _verify_stream_token(token: str, hash_: str, filename: str) -> bool:
    return hmac.compare_digest(token, _make_stream_token(hash_, filename))

# ── Re-add helper ─────────────────────────────────────────────────────────────

def _readd_to_ad(api_key: str, hash_: str, name: str):
    """Re-upload a stubbed transfer to AllDebrid and update the DB."""
    try:
        magnet  = _make_magnet(hash_, name)
        result  = _ad_upload_magnets_raw(api_key, [magnet])
        magnets = result.get("data", {}).get("magnets", [])
        if magnets and not magnets[0].get("error"):
            m     = magnets[0]
            ad_id = m.get("id")
            state = "cached" if m.get("ready") else "queued"
            _db_set(hash_, ad_id=ad_id, state=state, is_stub=0)
            _log(f"[readd] '{name[:60]}' re-added to AllDebrid (id={ad_id})")
        else:
            err = (magnets[0].get("error", {}).get("message","") if magnets else "no magnets")
            _log(f"[readd] failed for {hash_}: {err}")
    except Exception as e:
        _log(f"[readd] error: {e}")

# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    from flask import make_response
    r = make_response(render_template("index.html"))
    r.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    return r

# ── Torznab ───────────────────────────────────────────────────────────────────

@app.route("/torznab")
@app.route("/torznab/api")
def torznab():
    t = request.args.get("t", "").lower()

    if t == "caps":
        return Response(torznab_caps(), mimetype="application/xml")

    apikey = request.args.get("apikey", "") or request.headers.get("X-Api-Key", "")
    if TORZNAB_APIKEY and apikey != TORZNAB_APIKEY:
        return xml_error(100, "Invalid API key")

    ip      = request.headers.get("X-Forwarded-For", request.remote_addr).split(",")[0].strip()
    allowed, limit, remaining, reset_ts = _check_torznab_rate(ip)
    rh      = _rate_headers(limit, remaining, reset_ts)

    if not allowed:
        retry = reset_ts - int(time.time())
        return Response(
            f'''<?xml version="1.0" encoding="UTF-8"?>
<error code="429" description="Rate limit exceeded. Retry after {retry}s"/>''',
            mimetype="application/xml", status=429,
            headers={**rh, "Retry-After": str(retry)},
        )

    if t in ("search", "tvsearch", "movie"):
        q      = request.args.get("q", "").strip()
        season = request.args.get("season", "").strip()
        ep     = request.args.get("ep", "").strip()
        cat    = request.args.get("cat", "").strip()

        app.logger.info(f"Torznab {t}: q={q!r} season={season!r} ep={ep!r}")

        parsed_s, parsed_ep = None, None
        if season:
            try:
                parsed_s = int(season)
                if ep:
                    parsed_ep = int(ep)
            except ValueError:
                pass

        # Empty query — return library (Prowlarr connection test / RSS browse)
        if not q:
            transfers  = _db_all()
            streamable = [tr for tr in transfers if tr["state"] in ("cached", "complete")]
            fb         = []
            for tr in streamable:
                h    = tr["hash"]
                name = tr.get("name") or h
                is_s = bool(re.search(r'\bS\d{1,2}(?:E\d{1,2})?\b|\bSeason\s*\d+\b',
                                      name, re.IGNORECASE))
                fb.append({
                    "hash":     h,
                    "name":     name,
                    "size":     0,
                    "seeders":  1,
                    "leechers": 0,
                    "category": 5000 if is_s else 2000,
                    "cached":   True,
                    "indexer":  "alldebrid",
                    "added_at": tr.get("added_at") or 0,
                })
            if cat and cat != "0":
                requested = [int(c) for c in cat.split(",") if c.strip().isdigit()]
                if requested:
                    filtered = [r for r in fb if any(
                        normalize_newznab_category(r["category"]) == rc
                        or normalize_newznab_category(r["category"]) // 1000 == rc // 1000
                        for rc in requested)]
                    if filtered:
                        fb = filtered
            if not fb:
                raw = _fetch_tpb("1080p", 20)
                for ti in raw:
                    fb.append({
                        "hash":     ti["info_hash"].lower(),
                        "name":     ti.get("name", "Unknown"),
                        "size":     fmt_size(ti.get("size", 0)),
                        "seeders":  int(ti.get("seeders", 0) or 0),
                        "leechers": int(ti.get("leechers", 0) or 0),
                        "category": tpb_to_newznab(ti.get("category", 0), ti.get("name", "")),
                        "cached":   False,
                        "indexer":  "TPB",
                    })
            fb.sort(key=lambda x: float(x.get("added_at") or 0), reverse=True)
            resp = Response(torznab_results(fb, ""), mimetype="application/xml")
            for k, v in rh.items():
                resp.headers[k] = v
            return resp

        parsed_q, ps, pe, quality = parse_query(q)
        parsed_s  = parsed_s  or ps
        parsed_ep = parsed_ep or pe

        results = do_search(parsed_q, parsed_s, parsed_ep, quality, limit=40,
                            ad_key=get_ad_api_key())

        if _load_config().get("torznab_cached_only", False):
            cached = [r for r in results if r.get("cached")]
            if cached:
                results = cached

        if cat and cat != "0":
            requested = [int(c) for c in cat.split(",") if c.strip().isdigit()]
            if requested:
                filtered = [r for r in results if any(
                    normalize_newznab_category(r.get("category")) == rc
                    or normalize_newznab_category(r.get("category")) // 1000 == rc // 1000
                    for rc in requested)]
                if filtered:
                    results = filtered

        resp = Response(torznab_results(results, q), mimetype="application/xml")
        for k, v in rh.items():
            resp.headers[k] = v
        return resp

    return xml_error(202, f"Unknown function: {t}", rh)

# ── Web UI search ─────────────────────────────────────────────────────────────

@app.route("/api/search", methods=["POST"])
def search():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip() or get_ad_api_key()
    query   = data.get("query", "").strip()
    if not api_key:
        return jsonify({"error": "API key required"}), 400
    if not query:
        return jsonify({"error": "Query required"}), 400
    parsed_q, season, episode, quality = parse_query(query)
    results = do_search(parsed_q, season, episode, quality, limit=40, ad_key=api_key)
    return jsonify({
        "results": [{**r, "size": r["size_str"]} for r in results],
        "total":   len(results),
        "source":  "prowlarr" if get_prowlarr_config().get("url") else "tpb",
    })

# ── Add torrent ───────────────────────────────────────────────────────────────

@app.route("/api/add", methods=["POST"])
def add():
    data      = request.json or {}
    api_key   = data.get("api_key", "").strip() or get_ad_api_key()
    hash_     = data.get("hash", "").strip().lower()
    name      = data.get("name", "").strip()
    is_cached = data.get("cached", None)

    if not hash_:
        return jsonify({"error": "hash required"}), 400
    if not api_key:
        return jsonify({"error": "API key required"}), 400

    t = _db_get(hash_)

    if t and t.get("is_stub"):
        # Was stubbed — re-add to AllDebrid
        _pool.submit(_readd_to_ad, api_key, hash_, name or t.get("name") or hash_)
        _db_set(hash_, is_stub=0)
        t = _db_get(hash_)
    elif not t or t.get("state") not in ("cached", "complete"):
        # New or re-queue — upload to AllDebrid (stays in library)
        magnet  = _make_magnet(hash_, name)
        result  = _ad_upload_magnets_raw(api_key, [magnet])
        magnets = result.get("data", {}).get("magnets", [])
        if not magnets or magnets[0].get("error"):
            err = magnets[0].get("error", {}).get("message","Upload failed") if magnets else "Upload failed"
            return jsonify({"error": err}), 400
        m     = magnets[0]
        ad_id = m.get("id")
        state = "cached" if m.get("ready") else "queued"
        _db_set(hash_, name=name or m.get("name") or hash_, state=state,
                ad_id=ad_id, added_at=time.time(), is_stub=0)
        t = _db_get(hash_)

    return jsonify({
        "name":  t.get("name") if t else name,
        "hash":  hash_,
        "state": t.get("state") if t else "queued",
        "ready": (t.get("state") in ("cached","complete")) if t else False,
    })

# ── Remove torrent ────────────────────────────────────────────────────────────

@app.route("/api/remove", methods=["POST"])
def remove_transfer():
    data    = request.json or {}
    hash_   = data.get("hash", "").strip().lower()
    api_key = data.get("api_key", "").strip() or get_ad_api_key()
    if not hash_:
        return jsonify({"error": "hash required"}), 400
    t = _db_get(hash_)
    if t:
        ad_id = t.get("ad_id")
        if ad_id and api_key:
            _pool.submit(_ad_delete_magnet, api_key, ad_id)
    _db_delete(hash_)
    return jsonify({"ok": True})

# ── Links / play ──────────────────────────────────────────────────────────────

@app.route("/api/links", methods=["POST"])
def get_links():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip() or get_ad_api_key()
    hash_   = data.get("hash", "").strip().lower()
    name    = data.get("name", "").strip()

    if not api_key or not hash_:
        return jsonify({"error": "api_key and hash required"}), 400

    t = _db_get(hash_)

    # Re-add to AllDebrid if this is a stub being played
    if t and t.get("is_stub"):
        _log(f"[links] stub play for '{name or hash_}' — re-adding to AllDebrid")
        _readd_to_ad(api_key, hash_, name or t.get("name") or hash_)
        t = _db_get(hash_)

    ad_id, files = _ensure_ad_magnet(api_key, hash_, name or (t.get("name") if t else "") or hash_)
    if not ad_id:
        return jsonify({"error": "Could not upload to AllDebrid"}), 502
    if not files:
        return jsonify({"error": "No files found in magnet"}), 404

    unlocked = []
    for f in files:
        raw_link = f.get("link") or ""
        if not raw_link:
            continue
        direct = _unlock_link(api_key, raw_link)
        if direct:
            unlocked.append({
                "name":     f.get("name", ""),
                "link":     direct,
                "size":     f.get("size", 0),
                "is_video": bool(f.get("is_video")),
                "path":     f.get("path", ""),
            })

    if not unlocked:
        return jsonify({"error": "Could not unlock any links"}), 400

    # Record playback — resets the 30-day stub timer
    _db_touch_played(hash_)
    return jsonify({"links": unlocked})

# ── Stream proxy ──────────────────────────────────────────────────────────────

@app.route("/api/stream/<token>")
def stream_proxy(token):
    hash_    = request.args.get("h", "").strip().lower()
    filename = request.args.get("f", "").strip()
    if not hash_ or not filename:
        return jsonify({"error": "Missing parameters"}), 400
    if not _verify_stream_token(token, hash_, filename):
        return jsonify({"error": "Invalid stream token"}), 403

    api_key = get_ad_api_key()
    t       = _db_get(hash_)
    name    = t.get("name") if t else filename

    if t and t.get("is_stub"):
        _readd_to_ad(api_key, hash_, name or hash_)
        t = _db_get(hash_)

    files  = _db_get_files(hash_)
    target = next((f for f in files
                   if f.get("name") == filename or (f.get("path") or "").endswith(filename)), None)
    if not target:
        return jsonify({"error": "File not found"}), 404

    cdn_url = _unlock_link(api_key, target.get("link", ""))
    if not cdn_url:
        return jsonify({"error": "Could not unlock link"}), 502

    _db_touch_played(hash_)

    headers = {}
    if "Range" in request.headers:
        headers["Range"] = request.headers["Range"]
    try:
        upstream = requests.get(cdn_url, headers=headers, stream=True, timeout=30)
    except requests.RequestException as e:
        return jsonify({"error": str(e)}), 502

    ext  = os.path.splitext(filename)[1].lower()
    mime = {".mp4": "video/mp4", ".mkv": "video/x-matroska", ".avi": "video/x-msvideo",
            ".mov": "video/quicktime", ".m4v": "video/mp4", ".ts": "video/mp2t",
            ".webm": "video/webm", ".wmv": "video/x-ms-wmv"}
    ct = upstream.headers.get("Content-Type") or mime.get(ext, "application/octet-stream")
    rh = {"Content-Type": ct, "Accept-Ranges": upstream.headers.get("Accept-Ranges", "bytes")}
    if "Content-Length" in upstream.headers: rh["Content-Length"] = upstream.headers["Content-Length"]
    if "Content-Range"  in upstream.headers: rh["Content-Range"]  = upstream.headers["Content-Range"]

    def generate():
        for chunk in upstream.iter_content(chunk_size=256 * 1024):
            yield chunk

    return Response(generate(), status=upstream.status_code, headers=rh)

# ── Library list ──────────────────────────────────────────────────────────────

@app.route("/api/transfers")
def list_transfers():
    transfers = _db_all()
    now       = time.time()
    result    = []
    for t in transfers:
        last          = t.get("last_played") or t.get("added_at") or 0
        days_inactive = max(0, int((now - last) / 86400)) if last else None
        days_until_stub = None
        if not t.get("is_stub") and last:
            remaining = STUB_AFTER_SECS - (now - last)
            days_until_stub = max(0, int(remaining / 86400))
        result.append({
            "hash":            t["hash"],
            "name":            t.get("name") or t["hash"],
            "state":           t["state"],
            "is_stub":         bool(t.get("is_stub")),
            "last_played":     t.get("last_played"),
            "days_inactive":   days_inactive,
            "days_until_stub": days_until_stub,
            "ad_id":           t.get("ad_id"),
            "category":        t.get("category") or "",
            "added_at":        t.get("added_at"),
        })
    return jsonify({"transfers": result})

# ── Transfer status ───────────────────────────────────────────────────────────

@app.route("/api/transfer/status", methods=["POST"])
def transfer_status():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip() or get_ad_api_key()
    hash_   = data.get("hash", "").strip().lower()
    if not api_key or not hash_:
        return jsonify({"error": "api_key and hash required"}), 400
    t = _db_get(hash_)
    if not t:
        return jsonify({"error": "Not found"}), 404
    ad_id = t.get("ad_id")
    if not ad_id:
        return jsonify({"hash": hash_, "state": t["state"], "progress": 0,
                        "is_stub": bool(t.get("is_stub"))})
    resp    = _ad_get(api_key, AD_STATUS, params={"id[]": ad_id})
    magnets = resp.get("data", {}).get("magnets", [])
    m       = magnets[0] if magnets else {}
    return jsonify({
        "hash":     hash_,
        "state":    t["state"],
        "ad_state": m.get("status", ""),
        "progress": m.get("downloaded", 0),
        "is_stub":  bool(t.get("is_stub")),
    })

# ── Cache check (web UI) ──────────────────────────────────────────────────────

@app.route("/api/cache-check", methods=["POST"])
def cache_check():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip() or get_ad_api_key()
    hash_   = data.get("hash", "").strip().lower()
    name    = data.get("name", "").strip()
    if not api_key:
        return jsonify({"error": "API key required"}), 400
    if not hash_:
        return jsonify({"error": "hash required"}), 400
    result = check_cache_ad(api_key, [{"info_hash": hash_, "name": name}])
    return jsonify({"hash": hash_, "cached": bool(result.get(hash_, False)), "name": name})

# ── Config ────────────────────────────────────────────────────────────────────

@app.route("/api/config")
def get_config():
    return jsonify({
        "has_ad_key":       bool(get_ad_api_key()),
        "has_prowlarr_env": bool(PROWLARR_URL or PROWLARR_KEY),
        "stub_after_days":  STUB_AFTER_DAYS,
        "ad_rate_limit":    _AD_RATE_LIMIT,
    })


@app.route("/api/config/ad_key", methods=["POST"])
def save_ad_key():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip()
    if not api_key:
        return jsonify({"error": "api_key required"}), 400
    resp = _ad_get(api_key, AD_USER)
    if resp.get("status") != "success":
        return jsonify({"error": resp.get("error", {}).get("message", "Auth failed")}), 401
    save_ad_api_key(api_key)
    return jsonify({"ok": True})


@app.route("/api/account", methods=["POST"])
def account():
    data    = request.json or {}
    api_key = data.get("api_key", "").strip() or get_ad_api_key()
    if not api_key:
        return jsonify({"error": "API key required"}), 400
    resp = _ad_get(api_key, AD_USER)
    if resp.get("status") != "success":
        return jsonify({"error": resp.get("error", {}).get("message", "Auth failed")}), 401
    user = resp.get("data", {}).get("user", {})
    return jsonify({
        "username":      user.get("username"),
        "is_premium":    user.get("isPremium", False),
        "premium_until": user.get("premiumUntil"),
        "is_trial":      user.get("isTrial", False),
    })

# ── Prowlarr config ───────────────────────────────────────────────────────────

@app.route("/api/prowlarr/config", methods=["GET"])
def prowlarr_config_get():
    cfg = get_prowlarr_config()
    return jsonify({
        "url":        cfg.get("url", ""),
        "api_key":    cfg.get("api_key", ""),
        "configured": bool(cfg.get("url") and cfg.get("api_key")),
        "from_env":   cfg.get("from_env", False),
    })


@app.route("/api/prowlarr/config", methods=["POST"])
def prowlarr_config_save():
    data    = request.json or {}
    url     = data.get("url", "").strip()
    api_key = data.get("api_key", "").strip()
    if not url or not api_key:
        return jsonify({"error": "url and api_key required"}), 400
    try:
        r = requests.get(f"{url.rstrip('/')}/api/v1/indexer",
                         headers={"X-Api-Key": api_key}, timeout=10)
        r.raise_for_status()
        indexers = r.json()
    except requests.RequestException as e:
        return jsonify({"error": f"Could not connect to Prowlarr: {e}"}), 400
    save_prowlarr_config(url, api_key)
    torrent = [i for i in indexers if i.get("protocol") == "torrent"]
    return jsonify({
        "ok": True,
        "indexer_count": len(torrent),
        "indexers": [{"id": i["id"], "name": i["name"]} for i in torrent],
    })


@app.route("/api/prowlarr/config", methods=["DELETE"])
def prowlarr_config_delete():
    cfg = _load_config()
    cfg.pop("prowlarr", None)
    _save_config(cfg)
    return jsonify({"ok": True})

# ── Torznab cached-only toggle ────────────────────────────────────────────────

@app.route("/api/torznab/cached-only", methods=["GET"])
def get_cached_only():
    return jsonify({"cached_only": _load_config().get("torznab_cached_only", False)})


@app.route("/api/torznab/cached-only", methods=["POST"])
def set_cached_only():
    data = request.json or {}
    val  = bool(data.get("cached_only", True))
    cfg  = _load_config()
    cfg["torznab_cached_only"] = val
    _save_config(cfg)
    return jsonify({"ok": True, "cached_only": val})

# ── Stub management ───────────────────────────────────────────────────────────

@app.route("/api/stubs/list")
def stubs_list():
    stubs = [t for t in _db_all() if t.get("is_stub")]
    return jsonify({"stubs": stubs, "count": len(stubs)})


@app.route("/api/stubs/restore", methods=["POST"])
def stubs_restore():
    """Manually restore a stubbed transfer back into AllDebrid."""
    data    = request.json or {}
    hash_   = data.get("hash", "").strip().lower()
    api_key = data.get("api_key", "").strip() or get_ad_api_key()
    if not hash_:
        return jsonify({"error": "hash required"}), 400
    t = _db_get(hash_)
    if not t:
        return jsonify({"error": "Transfer not found"}), 404
    if not t.get("is_stub"):
        return jsonify({"ok": True, "message": "Not a stub"})
    _pool.submit(_readd_to_ad, api_key, hash_, t.get("name") or hash_)
    return jsonify({"ok": True, "message": f"Re-adding {t.get('name') or hash_} to AllDebrid"})


@app.route("/api/stubs/run-pass", methods=["POST"])
def stubs_run_pass():
    """Manually trigger the stub pass (useful for testing)."""
    try:
        _do_stub_pass()
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

# ── Backup / Restore ──────────────────────────────────────────────────────────

@app.route("/api/backup", methods=["GET"])
def backup():
    transfers = _db_all()
    cached    = [
        {
            "hash":        t["hash"],
            "name":        t.get("name") or t["hash"],
            "ad_id":       t.get("ad_id"),
            "is_stub":     bool(t.get("is_stub")),
            "last_played": t.get("last_played"),
            "added_at":    t.get("added_at") or 0,
            "category":    t.get("category") or "",
        }
        for t in transfers if t.get("state") in ("cached", "complete")
    ]
    cfg    = dict(_load_config())
    active = get_ad_api_key()
    if active and not cfg.get("ad_api_key"):
        cfg["ad_api_key"] = active
    ts = int(time.time())
    return Response(
        json.dumps({"version": 1, "config": cfg, "transfers": cached}, indent=2),
        mimetype="application/json",
        headers={"Content-Disposition": f'attachment; filename="alldebrid-backup-{ts}.json"'},
    )


@app.route("/api/restore", methods=["POST"])
def restore():
    global _cfg_cache
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400
    try:
        data = json.load(request.files["file"])
    except Exception as e:
        return jsonify({"error": f"Invalid JSON: {e}"}), 400
    if isinstance(data, dict):
        rc = data.get("config")
        if isinstance(rc, dict) and rc:
            merged = {**_load_config(), **rc}
            _save_config(merged)
            _cfg_cache = merged
        data = data.get("transfers", [])
    if not isinstance(data, list):
        return jsonify({"error": "Expected list or backup object"}), 400
    imported = skipped = errors = 0
    for item in data:
        hash_ = (item.get("hash") or "").strip().lower()
        if not hash_ or not re.fullmatch(r'[0-9a-f]{40}', hash_):
            errors += 1; continue
        if _db_get(hash_):
            skipped += 1; continue
        try:
            _db_set(
                hash_,
                name=item.get("name") or hash_,
                ad_id=item.get("ad_id"),
                state="cached",
                added_at=float(item.get("added_at") or time.time()),
                last_played=item.get("last_played"),
                is_stub=int(bool(item.get("is_stub"))),
                category=item.get("category") or "",
            )
            imported += 1
        except Exception as e:
            app.logger.warning(f"Restore error {hash_}: {e}")
            errors += 1
    return jsonify({"ok": True, "imported": imported, "skipped": skipped, "errors": errors})

# ── Debug / health ────────────────────────────────────────────────────────────

@app.route("/api/rate-status")
def rate_status():
    """Live view of the AllDebrid rate limiter bucket."""
    now    = time.monotonic()
    cutoff = now - _AD_RATE_WINDOW
    with _ad_rate_lock:
        used = sum(1 for ts in _ad_timestamps if ts > cutoff)
    return jsonify({
        "limit_per_minute": _AD_RATE_LIMIT,
        "used_last_minute": used,
        "remaining":        max(0, _AD_RATE_LIMIT - used),
        "window_seconds":   int(_AD_RATE_WINDOW),
    })

# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))

    import resource
    try:
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        target = min(hard, 65536)
        if soft < target:
            resource.setrlimit(resource.RLIMIT_NOFILE, (target, hard))
    except Exception:
        pass

    from werkzeug.serving import make_server as _make_server
    max_threads = int(os.environ.get("SERVER_THREADS", "16"))
    _thread_sem = threading.Semaphore(max_threads)
    _srv        = _make_server("0.0.0.0", port, app, threaded=True)

    def _capped(req, addr):
        if _thread_sem.acquire(blocking=False):
            def _run():
                try:    _srv.finish_request(req, addr)
                except: _srv.handle_error(req, addr)
                finally:
                    _srv.shutdown_request(req)
                    _thread_sem.release()
            threading.Thread(target=_run, daemon=True).start()
        else:
            try:    _srv.finish_request(req, addr)
            except: _srv.handle_error(req, addr)
            finally: _srv.shutdown_request(req)

    _srv.process_request = _capped
    app.logger.info(f"Starting AllDebrid Web on :{port} (AD rate limit: {_AD_RATE_LIMIT} req/min)")
    _srv.serve_forever()
