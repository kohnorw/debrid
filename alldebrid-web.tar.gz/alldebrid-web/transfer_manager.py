"""
AllDebrid transfer manager — tracks torrent state using SQLite.

States:
  queued      → just received, not yet processed
  cached      → AllDebrid has it cached (ready field = true), ready to stream
  downloading → not cached, magnet uploaded to AllDebrid, polling status
  complete    → transfer finished downloading, ready to stream
  error       → something went wrong

File lists and CDN URLs are stored persistently in the `files` table.
AllDebrid's link/unlock is called once per file when first needed, then only
again when a CDN URL actually expires (403/410) during playback.

AllDebrid rate limit: 250 requests/minute (enforced via sliding-window
token bucket in app._ad_api_acquire — all API calls route through there).
"""

import hashlib
import hmac as _hmac
import logging
import os
import re
import secrets as _secrets
import sqlite3
import threading
import time
import urllib.parse

import requests

log = logging.getLogger(__name__)

# ── AllDebrid API endpoints ───────────────────────────────────────────────────
AD_BASE    = "https://api.alldebrid.com/v4"
AD_UPLOAD  = f"{AD_BASE}/magnet/upload"
AD_DELETE  = f"{AD_BASE}/magnet/delete"
AD_STATUS  = "https://api.alldebrid.com/v4.1/magnet/status"
AD_FILES   = f"{AD_BASE}/magnet/files"
AD_UNLOCK  = f"{AD_BASE}/link/unlock"
AD_INSTANT = f"{AD_BASE}/magnet/instant"   # read-only cache check, never adds to library

# CDN URL lifetime: AllDebrid links last at least 48h in practice.
# We store them and only refresh after expiry (403/410 during real playback).
CDN_TTL        = 172800   # 48 h
REFRESH_MARGIN = 3600     # start background refresh 1 h before expiry

# ── HTTP / retry params ───────────────────────────────────────────────────────
READ_TIMEOUT      = int(os.environ.get("FUSE_READ_TIMEOUT", "10"))
READ_MAX_ATTEMPTS = 5
READ_BACKOFF_BASE = 0.5
READ_BACKOFF_CAP  = 4.0

POLL_INTERVAL = 15   # seconds between polling downloading transfers

DB_PATH = os.environ.get("DB_PATH", "/app/alldebrid.db")

# ── Stream token (shared with app.py) ─────────────────────────────────────────
_TOKEN_SECRET: str = ""

def _get_token_secret() -> str:
    global _TOKEN_SECRET
    if _TOKEN_SECRET:
        return _TOKEN_SECRET
    try:
        import sys as _sys
        _app = _sys.modules.get("app") or _sys.modules.get("__main__")
        _load  = getattr(_app, "_load_config",  None)
        _save  = getattr(_app, "_save_config",  None)
        if not _load:
            return _secrets.token_hex(32)
        cfg = _load()
        if "token_secret" not in cfg:
            cfg["token_secret"] = _secrets.token_hex(32)
            if _save:
                _save(cfg)
        _TOKEN_SECRET = cfg["token_secret"]
    except Exception:
        _TOKEN_SECRET = _secrets.token_hex(32)
    return _TOKEN_SECRET

def _make_stream_token(hash_: str, filename: str) -> str:
    secret  = _get_token_secret()
    return _hmac.new(secret.encode(), f"{hash_}:{filename}".encode(), "sha256").hexdigest()

# ── AllDebrid API helpers (rate-limited via app._ad_api_acquire) ──────────────

def _ad_headers(api_key: str) -> dict:
    return {"Authorization": f"Bearer {api_key}"}

def _ad_acquire():
    """Route through app._ad_api_acquire so all calls share one 250 req/min bucket."""
    try:
        import sys as _sys
        _app = _sys.modules.get("app") or _sys.modules.get("__main__")
        acquire = getattr(_app, "_ad_api_acquire", None)
        if acquire:
            acquire()
            return
    except Exception:
        pass
    time.sleep(0.25)   # fallback: 4 req/s if app not available

def _ad_post(api_key: str, url: str, pairs: list) -> dict:
    _ad_acquire()
    try:
        r = requests.post(
            url,
            headers={**_ad_headers(api_key), "Content-Type": "application/x-www-form-urlencoded"},
            data=urllib.parse.urlencode(pairs),
            timeout=20,
        )
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.debug(f"[ad-post] {url}: {e}")
        return {}

def _ad_get(api_key: str, url: str, params: dict | None = None) -> dict:
    _ad_acquire()
    try:
        r = requests.get(url, headers=_ad_headers(api_key), params=params, timeout=20)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.debug(f"[ad-get] {url}: {e}")
        return {}

def _ad_upload_magnet(api_key: str, hash_: str, name: str) -> dict:
    """Upload a magnet to AllDebrid. Returns the response dict."""
    magnet = f"magnet:?xt=urn:btih:{hash_.lower()}&dn={urllib.parse.quote(name or '', safe='')}"
    return _ad_post(api_key, AD_UPLOAD, [("magnets[]", magnet)])

def _ad_delete_magnet(api_key: str, magnet_id: int):
    """Remove a magnet from AllDebrid library."""
    _ad_post(api_key, AD_DELETE, [("id", magnet_id)])

def _ad_unlock_link(api_key: str, link: str) -> str | None:
    """Unlock a single AllDebrid download link. Returns the direct CDN URL."""
    data = _ad_get(api_key, AD_UNLOCK, params={"link": link})
    return data.get("data", {}).get("link")

def _ad_get_files(api_key: str, magnet_id: int) -> list:
    """Fetch the file list for an uploaded AllDebrid magnet ID."""
    data = _ad_get(api_key, AD_FILES, params={"id[]": magnet_id})
    raw  = data.get("data", {}).get("magnets", [])
    files = []
    VIDEO_EXTS = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts", ".wmv", ".flv", ".webm"}
    def _collect(node):
        if isinstance(node, list):
            for item in node:
                _collect(item)
        elif isinstance(node, dict):
            if node.get("l"):
                name = node.get("n", "")
                ext  = os.path.splitext(name)[1].lower()
                files.append({
                    "name":     name,
                    "path":     name,
                    "size":     int(node.get("s", 0) or 0),
                    "link":     node["l"],
                    "is_video": ext in VIDEO_EXTS,
                })
            if node.get("e"):
                _collect(node["e"])
    for m in raw:
        _collect(m.get("files", []))
    return files

def _ad_magnet_status(api_key: str, magnet_id: int) -> dict:
    """Get status for a single uploaded magnet."""
    data = _ad_get(api_key, AD_STATUS, params={"id[]": magnet_id})
    magnets = data.get("data", {}).get("magnets", [])
    return magnets[0] if magnets else {}

# ── Plex scanner ──────────────────────────────────────────────────────────────
# Identical debounced scanner to premiumize-web; reads config from app._load_config.

class _PlexScanner:
    def __init__(self):
        self._lock   = threading.Lock()
        self._timer: threading.Timer | None = None
        self._pending: set = set()
        self._loc_cache: dict = {}
        self._log = logging.getLogger(__name__ + ".plex")
        self._interval_stop = threading.Event()
        self._interval_wake = threading.Event()
        t = threading.Thread(target=self._interval_loop, daemon=True)
        t.start()

    def _load_plex_cfg(self) -> dict:
        try:
            import sys as _s
            _a = _s.modules.get("app") or _s.modules.get("__main__")
            lc = getattr(_a, "_load_config", None)
            return (lc() or {}).get("plex", {}) if lc else {}
        except Exception:
            return {}

    def _scan_interval_minutes(self) -> int:
        try:
            return int(self._load_plex_cfg().get("scan_interval_minutes", 60))
        except Exception:
            return 60

    def _config(self):
        cfg        = self._load_plex_cfg()
        url        = (os.environ.get("PLEX_URL") or cfg.get("url", "")).rstrip("/")
        token      = os.environ.get("PLEX_TOKEN") or cfg.get("token", "")
        movies     = os.environ.get("PLEX_MOVIES_SECTION") or str(cfg.get("movies_section", "1"))
        tv         = os.environ.get("PLEX_TV_SECTION") or str(cfg.get("tv_section", "2"))
        debounce   = int(os.environ.get("PLEX_SCAN_DEBOUNCE", "0") or cfg.get("debounce_seconds", 30))
        mount      = (os.environ.get("PLEX_MOUNT_PATH") or cfg.get("mount_path", "/docker/alldebrid-web/mnt")).rstrip("/")
        movie_root = (os.environ.get("PLEX_MOVIE_ROOT") or cfg.get("movie_root") or mount + "/movies").rstrip("/")
        tv_root    = (os.environ.get("PLEX_TV_ROOT")    or cfg.get("tv_root")    or mount + "/series").rstrip("/")
        movie4k    = (cfg.get("movie4k_root") or mount + "/movies4k").rstrip("/")
        tv4k       = (cfg.get("tv4k_root")    or mount + "/series4k").rstrip("/")
        debounce   = debounce or 30
        return (url or None, token or None, movies, tv, debounce, movie_root, tv_root, movie4k, tv4k)

    def _cfg_bool(self, key: str, default: bool) -> bool:
        v = os.environ.get("PLEX_" + key.upper())
        if v is not None:
            return v.strip().lower() not in ("0", "false", "no", "off")
        return bool(self._load_plex_cfg().get(key, default))

    def _auto_scan_enabled(self)  -> bool: return self._cfg_bool("auto_scan_enabled",  True)
    def _partial_enabled(self)    -> bool: return self._cfg_bool("partial_scan",        True)
    def _fallback_full_enabled(self) -> bool: return self._cfg_bool("fallback_full_scan", True)

    def notify_ready(self, subdir: str, rel_path: str | None = None):
        if not self._auto_scan_enabled():
            return
        _, _, _, _, debounce, *_ = self._config()
        with self._lock:
            self._pending.add((subdir, rel_path))
            if self._timer is not None:
                self._timer.cancel()
            self._timer = threading.Timer(debounce, self._fire)
            self._timer.daemon = True
            self._timer.start()
            self._log.warning(f"[plex-add] scan in {debounce}s queued={self._pending}")

    def _fire(self):
        with self._lock:
            self._pending.clear()
            self._timer = None
        url, token, *_ = self._config()
        if not url or not token:
            return
        self.scan_missing_from_plex()

    def _interval_loop(self):
        while not self._interval_stop.is_set():
            mins = self._scan_interval_minutes()
            if mins <= 0:
                self._interval_wake.wait(timeout=60)
                self._interval_wake.clear()
                continue
            self._interval_wake.wait(timeout=mins * 60)
            self._interval_wake.clear()
            if not self._interval_stop.is_set():
                try:
                    self.unlock_scanned_by_plex()
                    self.scan_missing_from_plex()
                except Exception as e:
                    self._log.warning(f"[plex-interval] error: {e}")

    def _do_refresh(self, url, token, section, subdir, target_path):
        if target_path:
            q = urllib.parse.urlencode({"path": target_path, "X-Plex-Token": token})
        else:
            q = urllib.parse.urlencode({"X-Plex-Token": token})
        try:
            r = requests.get(f"{url}/library/sections/{section}/refresh?{q}", timeout=10)
            if r.status_code not in (200, 204) and target_path and self._fallback_full_enabled():
                self._do_refresh(url, token, section, subdir, None)
        except requests.RequestException as e:
            self._log.warning(f"Plex scan failed: {e}")
            if target_path and self._fallback_full_enabled():
                self._do_refresh(url, token, section, subdir, None)

    def get_missing_from_plex(self) -> dict:
        url, token, movies_sec, tv_sec, _, movie_root, tv_root, movie4k, tv4k = self._config()
        if not url or not token:
            return {"error": "Plex not configured", "movies": [], "series": []}
        def _plex_folders(section, root):
            names = set()
            try:
                r = requests.get(
                    f"{url}/library/sections/{section}/all",
                    headers={"X-Plex-Token": token, "Accept": "application/json"},
                    timeout=15)
                if r.status_code == 200:
                    for item in r.json().get("MediaContainer", {}).get("Metadata") or []:
                        for media in item.get("Media") or []:
                            for part in media.get("Part") or []:
                                fp = part.get("file") or ""
                                if fp:
                                    names.add(os.path.basename(os.path.dirname(fp)))
            except Exception as e:
                self._log.warning(f"Plex section query failed: {e}")
            return names
        plex_movies = _plex_folders(movies_sec, movie_root)
        plex_series = _plex_folders(tv_sec, tv_root)
        try:
            import fuse_mount as _fm
            import sys as _s
            _a  = _s.modules.get("app") or _s.modules.get("__main__")
            _tm = getattr(_a, "_transfer_manager", None)
            nm  = _fm.build_name_map(_tm or self)
        except Exception as e:
            return {"error": str(e), "movies": [], "series": []}
        miss = {"movies": [], "movies4k": [], "series": [], "series4k": []}
        for key in nm:
            parts = key.split("/", 1)
            if len(parts) != 2:
                continue
            sd, folder = parts
            if sd in ("movies", "movies4k") and folder not in plex_movies:
                miss[sd].append(folder)
            elif sd in ("series", "series4k") and folder not in plex_series:
                miss[sd].append(folder)
        return miss

    def scan_missing_from_plex(self) -> dict:
        miss = self.get_missing_from_plex()
        if "error" in miss:
            return miss
        url, token, movies_sec, tv_sec, _, movie_root, tv_root, movie4k, tv4k = self._config()
        scanned = {"movies": [], "series": []}
        for folder in miss.get("movies",   []): self._do_refresh(url, token, movies_sec, "movies",   movie_root  + "/" + folder); scanned["movies"].append(folder)
        for folder in miss.get("movies4k", []): self._do_refresh(url, token, movies_sec, "movies4k", movie4k     + "/" + folder); scanned["movies"].append(folder)
        for folder in miss.get("series",   []): self._do_refresh(url, token, tv_sec,     "series",   tv_root     + "/" + folder); scanned["series"].append(folder)
        for folder in miss.get("series4k", []): self._do_refresh(url, token, tv_sec,     "series4k", tv4k        + "/" + folder); scanned["series"].append(folder)
        return {"scanned": scanned, "missing": miss}

    def unlock_scanned_by_plex(self) -> dict:
        url, token, movies_sec, tv_sec, _, movie_root, tv_root, movie4k, tv4k = self._config()
        if not url or not token:
            return {"error": "Plex not configured", "unlocked": 0}
        def _plex_folder_map(section, root):
            result = {}
            try:
                r = requests.get(f"{url}/library/sections/{section}/all",
                                 headers={"X-Plex-Token": token, "Accept": "application/json"},
                                 params={"type": "1" if "movie" in root else "4"}, timeout=15)
                if r.status_code == 200:
                    for item in r.json().get("MediaContainer", {}).get("Metadata") or []:
                        rk = item.get("ratingKey") or ""
                        for media in item.get("Media") or []:
                            for part in media.get("Part") or []:
                                fp = part.get("file") or ""
                                if fp and rk:
                                    result[os.path.basename(os.path.dirname(fp))] = rk
            except Exception as e:
                self._log.warning(f"Plex folder map failed: {e}")
            return result
        plex_movies = _plex_folder_map(movies_sec, movie_root)
        plex_series = _plex_folder_map(tv_sec,     tv_root)
        try:
            import fuse_mount as _fm
            import sys as _s
            _a  = _s.modules.get("app") or _s.modules.get("__main__")
            _tm = getattr(_a, "_transfer_manager", None)
            nm  = _fm.build_name_map(_tm or self)
        except Exception as e:
            return {"error": str(e), "unlocked": 0}
        import sys as _s2
        _a2  = _s2.modules.get("app") or _s2.modules.get("__main__")
        _tm2 = getattr(_a2, "_transfer_manager", None)
        unlocked = 0
        for key, hash_ in nm.items():
            parts = key.split("/", 1)
            if len(parts) != 2:
                continue
            sd, folder = parts
            rk = plex_movies.get(folder) if sd in ("movies", "movies4k") else plex_series.get(folder)
            if not rk:
                continue
            if _tm2 and _tm2.is_cdn_unlocked(hash_):
                continue
            ok = _tm2.unlock_file_cdn(hash_, mark_played=False) if _tm2 else False
            if ok:
                unlocked += 1
                try:
                    requests.put(f"{url}/library/metadata/{rk}/refresh",
                                 headers={"X-Plex-Token": token},
                                 params={"force": 1, "refreshLocalMediaAgent": 1}, timeout=8)
                except Exception:
                    pass
                try:
                    import fuse_mount as _fmx
                    if _fmx._pfs is not None:
                        _fmx._pfs._stat_invalidate(key)
                except Exception:
                    pass
        return {"unlocked": unlocked}


_plex = _PlexScanner()

# ── In-memory CDN-unlocked set (fast FUSE read-path) ─────────────────────────
_unlocked_hashes: set = set()

# ── FUSE location helper ──────────────────────────────────────────────────────

def _fuse_location(hash_: str, name: str, category: str = "", kind: str = ""):
    try:
        import fuse_mount as _fm
        if _fm._pfs is not None:
            nm = _fm._pfs._get_name_map()
            for key, h in nm.items():
                if h == hash_ and "/" in key:
                    sd, folder = key.split("/", 1)
                    return sd, folder
    except Exception:
        pass
    try:
        from fuse_mount import _category_subdir, _safe_name
        sd = _category_subdir(name or "", category or "", kind=kind or "")
        return sd, _safe_name(name or hash_)
    except Exception:
        return ("series" if kind == "series" else "movies"), (name or hash_)


class RateLimitError(Exception):
    def __init__(self, retry_after: int = 60):
        self.retry_after = retry_after
        super().__init__(f"Rate limited, retry after {retry_after}s")


class TransferManager:
    """
    Manages AllDebrid transfers.  Drop-in replacement for the Premiumize
    TransferManager — exposes the same public interface so fuse_mount.py and
    qbt_mock.py work unchanged.

    Key differences from Premiumize:
    - Cache check: upload magnet → read ready flag → delete (no permanent upload)
    - Add cached:  upload magnet → keep in library (ad_id stored in DB)
    - Get files:   magnet/files → link/unlock each file → store CDN URLs
    - Poll:        magnet/status by id
    - No fair-use meter, no directdl, no /transfer/list
    """

    def __init__(self, ad_api_key_fn, *_args, **_kwargs):
        self._key_fn = ad_api_key_fn
        self._lock   = threading.Lock()
        self._local  = threading.local()
        self._init_db()
        self._start_poller()

    # ── DB ────────────────────────────────────────────────────────────────────

    def _make_conn(self):
        os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
        conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA cache_size=-8000")
        return conn

    def _db(self):
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = self._make_conn()
            self._local.conn = conn
        else:
            try:
                conn.execute("SELECT 1")
            except Exception:
                conn = self._make_conn()
                self._local.conn = conn
        return conn

    def _init_db(self):
        with self._lock:
            self._db().executescript("""
                CREATE TABLE IF NOT EXISTS transfers (
                    hash        TEXT PRIMARY KEY,
                    name        TEXT,
                    state       TEXT DEFAULT 'queued',
                    ad_id       INTEGER,
                    error       TEXT,
                    added_at    REAL,
                    updated_at  REAL,
                    category    TEXT DEFAULT '',
                    kind        TEXT DEFAULT '',
                    cdn_unlocked INTEGER DEFAULT 0,
                    streamable_at REAL,
                    last_played REAL,
                    is_stub     INTEGER DEFAULT 0,
                    imported    INTEGER DEFAULT 0,
                    size        INTEGER DEFAULT 0
                );
                CREATE TABLE IF NOT EXISTS files (
                    hash        TEXT NOT NULL,
                    name        TEXT NOT NULL,
                    path        TEXT DEFAULT '',
                    size        INTEGER DEFAULT 0,
                    cdn_url     TEXT DEFAULT '',
                    cdn_expires REAL DEFAULT 0,
                    cdn_unlocked INTEGER DEFAULT 0,
                    cdn_played   INTEGER DEFAULT 0,
                    PRIMARY KEY (hash, name)
                );
                CREATE TABLE IF NOT EXISTS meta (
                    key   TEXT PRIMARY KEY,
                    value TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_transfers_state ON transfers(state);
                CREATE INDEX IF NOT EXISTS idx_files_hash      ON files(hash);
            """)
            # Migrations for existing DBs
            t_cols = {r[1] for r in self._db().execute("PRAGMA table_info(transfers)").fetchall()}
            f_cols = {r[1] for r in self._db().execute("PRAGMA table_info(files)").fetchall()}
            for col, defval in [
                ("ad_id",         "INTEGER"),
                ("cdn_unlocked",  "INTEGER DEFAULT 0"),
                ("streamable_at", "REAL"),
                ("last_played",   "REAL"),
                ("is_stub",       "INTEGER DEFAULT 0"),
                ("imported",      "INTEGER DEFAULT 0"),
                ("size",          "INTEGER DEFAULT 0"),
                ("kind",          "TEXT DEFAULT ''"),
                ("category",      "TEXT DEFAULT ''"),
            ]:
                if col not in t_cols:
                    self._db().execute(f"ALTER TABLE transfers ADD COLUMN {col} {defval}")
            for col, defval in [
                ("cdn_unlocked", "INTEGER DEFAULT 0"),
                ("cdn_played",   "INTEGER DEFAULT 0"),
            ]:
                if col not in f_cols:
                    self._db().execute(f"ALTER TABLE files ADD COLUMN {col} {defval}")
            # Backfill streamable_at for old rows
            self._db().execute(
                "UPDATE transfers SET streamable_at = COALESCE(added_at, updated_at) "
                "WHERE state IN ('cached','complete') AND streamable_at IS NULL"
            )
            self._db().commit()
            # Restore unlocked set from DB
            global _unlocked_hashes
            rows = self._db().execute("SELECT hash FROM transfers WHERE cdn_unlocked=1").fetchall()
            _unlocked_hashes = {r[0] for r in rows}

    def _get(self, hash_: str):
        row = self._db().execute("SELECT * FROM transfers WHERE hash=?", (hash_,)).fetchone()
        return dict(row) if row else None

    def _set(self, hash_: str, **kwargs):
        kwargs["updated_at"] = time.time()
        with self._lock:
            ex = self._get(hash_)
            if kwargs.get("state") in ("cached", "complete") and not (ex and ex.get("streamable_at")):
                kwargs.setdefault("streamable_at", time.time())
            if ex:
                sets = ", ".join(f"{k}=?" for k in kwargs)
                vals = list(kwargs.values()) + [hash_]
                self._db().execute(f"UPDATE transfers SET {sets} WHERE hash=?", vals)
            else:
                kwargs.setdefault("added_at", time.time())
                kwargs["hash"] = hash_
                cols = ", ".join(kwargs.keys())
                phs  = ", ".join("?" * len(kwargs))
                self._db().execute(f"INSERT INTO transfers ({cols}) VALUES ({phs})", list(kwargs.values()))
            self._db().commit()

    # ── File DB helpers ───────────────────────────────────────────────────────

    def _db_get_files(self, hash_: str) -> list:
        rows = self._db().execute(
            "SELECT name, path, size, cdn_url, cdn_expires, cdn_unlocked FROM files WHERE hash=?",
            (hash_,)
        ).fetchall()
        return [dict(r) for r in rows]

    def _db_store_files(self, hash_: str, files: list):
        """Persist file list, preserving existing cdn_unlocked / cdn_played flags."""
        now = time.time()
        with self._lock:
            old = self._db().execute(
                "SELECT name, path, cdn_unlocked, cdn_played FROM files WHERE hash=?", (hash_,)
            ).fetchall()
            unlocked_keys: dict = {}
            played_keys:   dict = {}
            for r in old:
                keys = [r["name"], r["path"], os.path.basename(r["path"] or "")]
                if int(r["cdn_unlocked"] or 0):
                    for k in keys:
                        unlocked_keys[k] = 1
                if int(r["cdn_played"] or 0):
                    for k in keys:
                        played_keys[k]   = 1
            self._db().execute("DELETE FROM files WHERE hash=?", (hash_,))
            for f in files:
                name  = f.get("name") or ""
                path  = f.get("path") or ""
                bname = os.path.basename(path)
                ul    = 1 if (unlocked_keys.get(name) or unlocked_keys.get(path) or unlocked_keys.get(bname)) else 0
                pl    = 1 if (played_keys.get(name)   or played_keys.get(path)   or played_keys.get(bname))   else 0
                self._db().execute(
                    "INSERT OR REPLACE INTO files "
                    "(hash, name, path, size, cdn_url, cdn_expires, cdn_unlocked, cdn_played) "
                    "VALUES (?,?,?,?,?,?,?,?)",
                    (hash_, name, path, int(f.get("size", 0) or 0),
                     f.get("cdn_url") or f.get("link") or "",
                     now + CDN_TTL, ul, pl),
                )
            self._db().commit()

    def _db_files_to_list(self, rows: list) -> list:
        VIDEO_EXTS = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts", ".wmv", ".flv", ".webm"}
        import urllib.parse as _up
        result = []
        for r in rows:
            name = r.get("name") or ""
            if not name:
                continue
            cdn   = r.get("cdn_url") or ""
            ext   = os.path.splitext(name)[1].lower()
            token = ""
            try:
                token = _make_stream_token(r.get("hash", ""), name)
            except Exception:
                pass
            result.append({
                "name":      name,
                "path":      r.get("path", ""),
                "link":      cdn,
                "cdn_url":   cdn,
                "size":      int(r.get("size", 0) or 0),
                "is_video":  ext in VIDEO_EXTS,
                "cdn_expires": r.get("cdn_expires", 0),
                "stream_url": (
                    f"/api/stream/{token}?h={r.get('hash','')}&f={_up.quote(name)}"
                    if token else ""
                ),
            })
        return result

    # ── Public API ────────────────────────────────────────────────────────────

    def add(self, hash_: str, name: str):
        hash_ = hash_.lower()
        ex = self._get(hash_)
        if ex and ex["state"] in ("cached", "downloading", "complete"):
            if ex.get("name") == hash_ and name and name != hash_:
                self._set(hash_, name=name)
            return self._get(hash_)
        self._set(hash_, name=name, state="queued")
        try:
            import sys as _s
            _a = _s.modules.get("app") or _s.modules.get("__main__")
            pool = getattr(_a, "_pool", None)
            if pool:
                pool.submit(self._process, hash_)
            else:
                raise ImportError
        except Exception:
            threading.Thread(target=self._process, args=(hash_,), daemon=True).start()
        return self._get(hash_)

    def delete(self, hash_: str):
        t = self._get(hash_)
        if t:
            ad_id   = t.get("ad_id")
            api_key = self._key_fn()
            if ad_id and api_key:
                try:
                    _ad_delete_magnet(api_key, ad_id)
                except Exception:
                    pass
        with self._lock:
            self._db().execute("DELETE FROM transfers WHERE hash=?", (hash_,))
            self._db().execute("DELETE FROM files WHERE hash=?", (hash_,))
            self._db().commit()

    def get_transfer(self, hash_: str):
        return self._get(hash_)

    def all_transfers(self):
        rows = self._db().execute("SELECT * FROM transfers").fetchall()
        return [dict(r) for r in rows]

    def streamable_hashes(self):
        rows = self._db().execute(
            "SELECT hash FROM transfers WHERE state IN ('cached','complete')"
        ).fetchall()
        return [r["hash"] for r in rows]

    def get_files(self, hash_: str, force: bool = False) -> list:
        """
        Return unlocked file list for hash.

        AllDebrid flow:
          1. DB cache hit → return immediately (no API call)
          2. DB miss or force=True:
             a. Fetch raw file list via magnet/files
             b. Unlock each download link via link/unlock
             c. Store CDN URLs in DB
        """
        t = self._get(hash_)
        if not t or t["state"] not in ("cached", "complete"):
            return []

        if not force:
            db_rows = self._db_get_files(hash_)
            if db_rows:
                for r in db_rows:
                    r["hash"] = hash_
                result = self._db_files_to_list(db_rows)
                if result:
                    return result

        api_key = self._key_fn()
        if not api_key:
            log.error(f"[{hash_[:8]}] get_files: ALLDEBRID_API_KEY not set")
            return []

        ad_id = t.get("ad_id")
        if not ad_id:
            # Upload fresh to get an ID, but immediately delete afterwards
            resp    = _ad_upload_magnet(api_key, hash_, t.get("name") or hash_)
            magnets = resp.get("data", {}).get("magnets", [])
            if not magnets or magnets[0].get("error"):
                return []
            ad_id = magnets[0].get("id")
            if not magnets[0].get("ready"):
                # Not cached yet — store id for polling and return empty
                if ad_id:
                    self._set(hash_, ad_id=ad_id)
                return []
            if ad_id:
                self._set(hash_, ad_id=ad_id)

        raw_files = _ad_get_files(api_key, ad_id)
        if not raw_files:
            return []

        # Store the raw file list even when CDN unlock fails/rate-limits.
        # Sonarr/Radarr imports and pack-stub rebuilds only need filenames/sizes;
        # playback can refresh CDN URLs later. The old code discarded raw_files
        # if no link/unlock succeeded, which caused restored/ready packs to show
        # "No files found" even though AllDebrid returned a file list.
        stored = []
        for f in raw_files:
            raw_link = f.get("link") or ""
            cdn_url = ""
            if raw_link:
                try:
                    cdn_url = _ad_unlock_link(api_key, raw_link) or ""
                except Exception:
                    cdn_url = ""
            stored.append({**f, "cdn_url": cdn_url})

        if stored:
            self._db_store_files(hash_, stored)

        db_rows = self._db_get_files(hash_)
        for r in db_rows:
            r["hash"] = hash_
        return self._db_files_to_list(db_rows)

    def refresh_cdn_url(self, hash_: str, filename: str) -> str | None:
        """Force-refresh one expired CDN URL (called on 403/410 during playback)."""
        t = self._get(hash_)
        if not t:
            return None
        api_key = self._key_fn()
        if not api_key:
            return None
        ad_id = t.get("ad_id")
        if not ad_id:
            return None
        # Re-fetch the file list and re-unlock
        raw_files = _ad_get_files(api_key, ad_id)
        for f in raw_files:
            name  = f.get("name") or ""
            bname = os.path.basename(f.get("path") or name)
            if name == filename or bname == filename or (f.get("path") or "").endswith("/" + filename):
                cdn = _ad_unlock_link(api_key, f.get("link") or "")
                if cdn:
                    with self._lock:
                        self._db().execute(
                            "UPDATE files SET cdn_url=?, cdn_expires=? WHERE hash=? AND name=?",
                            (cdn, time.time() + CDN_TTL, hash_, name)
                        )
                        self._db().commit()
                    log.info(f"[{hash_[:8]}] CDN URL refreshed for {filename}")
                    return cdn
        return None

    def is_cdn_unlocked(self, hash_: str) -> bool:
        if hash_ in _unlocked_hashes:
            return True
        try:
            row = self._db().execute(
                "SELECT cdn_unlocked FROM transfers WHERE hash=?", (hash_,)
            ).fetchone()
            result = bool(row and row[0])
            if result:
                _unlocked_hashes.add(hash_)
            return result
        except Exception:
            return False

    def is_file_cdn_unlocked(self, hash_: str, filename: str | None = None) -> bool:
        if not filename:
            return self.is_cdn_unlocked(hash_)
        base = os.path.basename(filename or "")
        try:
            row = self._db().execute(
                "SELECT cdn_unlocked FROM files WHERE hash=? AND (name=? OR path=? OR path LIKE ?) LIMIT 1",
                (hash_, base, filename, "%/" + base),
            ).fetchone()
            if row and int(row[0] or 0):
                return True
        except Exception:
            pass
        return self.is_cdn_unlocked(hash_)

    def is_file_played(self, hash_: str, filename: str) -> bool:
        base = os.path.basename(filename or "")
        try:
            row = self._db().execute(
                "SELECT cdn_played FROM files WHERE hash=? AND (name=? OR path=? OR path LIKE ?) LIMIT 1",
                (hash_, base, filename, "%/" + base),
            ).fetchone()
            return bool(row and int(row[0] or 0))
        except Exception:
            return False

    def unlock_file_cdn(self, hash_: str, filename: str | None = None,
                        mark_played: bool = False) -> bool:
        global _unlocked_hashes
        hash_ = (hash_ or "").lower().strip()
        if not hash_:
            return False
        base = os.path.basename(filename or "") if filename else ""
        with self._lock:
            if base:
                played_sql = ", cdn_played=1" if mark_played else ""
                cur = self._db().execute(
                    f"UPDATE files SET cdn_unlocked=1{played_sql} "
                    "WHERE hash=? AND (name=? OR path=? OR path LIKE ?)",
                    (hash_, base, filename, "%/" + base),
                )
                self._db().commit()
                return bool(cur.rowcount)
            played_sql = ", cdn_played=1" if mark_played else ""
            self._db().execute(f"UPDATE transfers SET cdn_unlocked=1{played_sql} WHERE hash=?", (hash_,))
            if mark_played:
                self._db().execute("UPDATE files SET cdn_played=1 WHERE hash=?", (hash_,))
            self._db().commit()
            _unlocked_hashes.add(hash_)
            return True

    def find_hash_by_filename(self, filename: str) -> str | None:
        row = self._db().execute("SELECT hash FROM files WHERE name=? LIMIT 1", (filename,)).fetchone()
        if row:
            return row[0]
        stem      = re.sub(r'\.[^.]+$', '', filename).lower()
        stem_norm = re.sub(r'[^a-z0-9]', '', stem)
        rows = self._db().execute("SELECT hash, name FROM files").fetchall()
        for r in rows:
            n = re.sub(r'[^a-z0-9]', '', re.sub(r'\.[^.]+$', '', r[1]).lower())
            if n == stem_norm:
                return r[0]
        return None

    # ── Processing ────────────────────────────────────────────────────────────

    def _process(self, hash_: str):
        t = self._get(hash_)
        if not t or t["state"] in ("cached", "complete", "downloading"):
            return
        api_key = self._key_fn()
        if not api_key:
            self._set(hash_, state="error", error="API key not set")
            return
        try:
            resp    = _ad_upload_magnet(api_key, hash_, t.get("name") or hash_)
            magnets = resp.get("data", {}).get("magnets", [])
            if not magnets or magnets[0].get("error"):
                err = magnets[0].get("error", {}).get("message", "Upload failed") if magnets else "Upload failed"
                self._set(hash_, state="error", error=err)
                return
            m     = magnets[0]
            ad_id = m.get("id")
            if m.get("ready"):
                log.info(f"[{hash_[:8]}] Cached on AllDebrid — ready to stream")
                self._set(hash_, state="cached", ad_id=ad_id)
                self._on_ready(hash_)
            else:
                log.info(f"[{hash_[:8]}] Not cached — queued for download (ad_id={ad_id})")
                self._set(hash_, state="downloading", ad_id=ad_id)
        except Exception as e:
            log.exception(f"[{hash_[:8]}] _process error")
            self._set(hash_, state="error", error=str(e))

    def _on_ready(self, hash_: str):
        """Called when a transfer becomes cached or complete."""
        t2 = self._get(hash_)
        if not t2:
            return
        _name     = t2.get("name") or hash_
        _category = t2.get("category") or ""
        _files    = []
        try:
            from name_match import classify_from_files
            _files = self.get_files(hash_) or []
            _kind = classify_from_files(_files)
            if _kind and not t2.get("kind"):
                self._set(hash_, kind=_kind)
            else:
                _kind = t2.get("kind") or _kind or ""
        except Exception as e:
            log.debug(f"[{hash_[:8]}] classify failed: {e}")
        try:
            import qbt_mock as _qbt
            _qbt._make_fake_files(_category, _qbt._safe_name(_name), _name, _files)
        except Exception as e:
            log.debug(f"[{hash_[:8]}] fake-file failed: {e}")

        # Unlock at both levels:
        #   transfers.cdn_unlocked=1  → fast path for is_cdn_unlocked()
        #   files.cdn_unlocked=1      → FUSE per-file check used by getattr/read
        with self._lock:
            self._db().execute(
                "UPDATE transfers SET cdn_unlocked=1 WHERE hash=?", (hash_,)
            )
            self._db().execute(
                "UPDATE files SET cdn_unlocked=1 WHERE hash=?", (hash_,)
            )
            self._db().commit()
        global _unlocked_hashes
        _unlocked_hashes.add(hash_)
        log.info(f"[{hash_[:8]}] Unlocked (transfers + files) — ready to stream from CDN")

        # Push file list into FUSE in-process cache WITH updated unlock state,
        # and invalidate the stat cache so Plex sees the real file size immediately.
        try:
            _files_fresh = self.get_files(hash_) or _files
        except Exception:
            _files_fresh = _files

        try:
            import fuse_mount as _fm
            if _fm._pfs is not None:
                with _fm._pfs._lock:
                    _fm._pfs._file_cache[hash_] = (
                        _files_fresh, time.time() + _fm.DIRECTDL_TTL
                    )
                _fm._pfs._stat_invalidate_all()
                _fm._pfs._invalidate_name_map()
        except Exception as e:
            log.debug(f"[{hash_[:8]}] FUSE cache update failed: {e}")

        t2 = self._get(hash_)
        subdir, folder = _fuse_location(
            hash_, t2.get("name", ""), t2.get("category", ""), t2.get("kind", "")
        )
        _plex.notify_ready(subdir, folder)

    # ── Background poller ─────────────────────────────────────────────────────

    def _start_poller(self):
        if getattr(TransferManager, "_poller_started", False):
            return
        TransferManager._poller_started = True
        threading.Thread(target=self._poll_loop,        daemon=True, name="ad-poller").start()
        threading.Thread(target=self._cdn_refresh_loop, daemon=True, name="ad-cdn-refresh").start()

    def _cdn_refresh_loop(self):
        """Run _refresh_expired_cdn_urls at startup then every 12 hours.

        AllDebrid CDN URLs are valid for ~48h. We refresh anything expiring
        within the next 24h so playback never hits a mid-session 403.
        Only unlocked files are checked — locked stubs have no CDN URLs.
        """
        time.sleep(15)   # let app + FUSE finish initialising
        self._refresh_expired_cdn_urls()
        while True:
            time.sleep(12 * 3600)
            self._refresh_expired_cdn_urls()

    def _refresh_expired_cdn_urls(self):
        now  = time.time()
        soon = now + 86400   # 24 h from now
        try:
            rows = self._db().execute(
                """SELECT DISTINCT t.hash, t.name
                   FROM transfers t
                   JOIN files f ON f.hash = t.hash
                   WHERE f.cdn_unlocked = 1
                     AND (f.cdn_expires < ? OR f.cdn_expires = 0)
                     AND t.state IN ('cached', 'complete')
                   ORDER BY f.cdn_expires ASC""",
                (soon,)
            ).fetchall()
        except Exception as e:
            log.warning(f"[cdn-refresh] query failed: {e}")
            return

        if not rows:
            log.info("[cdn-refresh] all CDN URLs are fresh")
            return

        expired  = sum(1 for r in rows if self._db().execute(
            "SELECT COUNT(*) FROM files WHERE hash=? AND cdn_expires < ? AND cdn_expires > 0",
            (r["hash"], now)).fetchone()[0] > 0)
        log.warning(f"[cdn-refresh] {expired} expired, {len(rows)-expired} expiring within 24h — refreshing {len(rows)} transfer(s)")

        api_key = self._key_fn()
        if not api_key:
            log.warning("[cdn-refresh] no API key — skipping")
            return

        refreshed = failed = 0
        for row in rows:
            try:
                _ad_acquire()
                ad_id = self._db().execute(
                    "SELECT ad_id FROM transfers WHERE hash=?", (row["hash"],)
                ).fetchone()
                ad_id = ad_id[0] if ad_id else None
                if not ad_id:
                    # Re-upload to get a fresh ID
                    resp = _ad_upload_magnet(api_key, row["hash"], row["name"] or row["hash"])
                    mags = resp.get("data", {}).get("magnets", [])
                    if not mags or mags[0].get("error") or not mags[0].get("ready"):
                        failed += 1; continue
                    ad_id = mags[0].get("id")
                    if ad_id:
                        self._set(row["hash"], ad_id=ad_id)

                raw_files = _ad_get_files(api_key, ad_id)
                if not raw_files:
                    failed += 1; continue

                unlocked = []
                for f in raw_files:
                    raw_link = f.get("link") or ""
                    if not raw_link:
                        continue
                    cdn = _ad_unlock_link(api_key, raw_link)
                    if cdn:
                        unlocked.append({**f, "cdn_url": cdn})

                if unlocked:
                    self._db_store_files(row["hash"], unlocked)
                    refreshed += 1
                else:
                    failed += 1
            except Exception as e:
                log.debug(f"[cdn-refresh] {row['hash'][:8]}: {e}")
                failed += 1

        log.warning(f"[cdn-refresh] done — refreshed {refreshed}, failed {failed}")
        # Invalidate FUSE block cache for refreshed URLs so stale blocks aren't served
        try:
            import fuse_mount as _fm
            if _fm._pfs is not None:
                _fm._pfs._stat_invalidate_all()
                with _fm._pfs._lock:
                    for h, _ in rows[:refreshed]:
                        _fm._pfs._file_cache.pop(h if isinstance(h, str) else h["hash"], None)
        except Exception:
            pass

    def _poll_loop(self):
        import fcntl
        try:
            _lf = open("/tmp/ad_poller.lock", "w")
            fcntl.flock(_lf, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            return
        while True:
            try:
                self._poll_all()
            except Exception:
                log.exception("Poller error")
            time.sleep(POLL_INTERVAL)

    def _poll_all(self):
        rows = self._db().execute(
            "SELECT hash, name, ad_id FROM transfers WHERE state='downloading'"
        ).fetchall()
        if not rows:
            return
        api_key = self._key_fn()
        if not api_key:
            return
        for row in rows:
            hash_  = row["hash"]
            ad_id  = row["ad_id"]
            if not ad_id:
                continue
            try:
                status = _ad_magnet_status(api_key, int(ad_id))
                st     = status.get("status", "")
                if status.get("ready") or st in ("Ready", "Seeding"):
                    log.info(f"[{hash_[:8]}] AllDebrid download complete")
                    self._set(hash_, state="complete")
                    self._on_ready(hash_)
                elif st in ("Error", "Fail", "Deleted"):
                    err = status.get("error", {}).get("message", st) if isinstance(status.get("error"), dict) else st
                    self._set(hash_, state="error", error=err)
            except Exception as e:
                log.debug(f"[{hash_[:8]}] poll error: {e}")
