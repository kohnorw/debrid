"""
AllDebrid Web — Flask app + FUSE virtual filesystem.

Single source of truth: the TransferManager (transfer_manager.py) owns the
SQLite DB, all AllDebrid API calls, the CDN-unlock lifecycle, and the FUSE
file-cache.  app.py is the HTTP layer on top — every route that needs
torrent/file data delegates to _tm (the global TransferManager instance).
"""

import json
import logging
import os
import re
import secrets
import shutil
import signal
import sqlite3
import sys
import threading
import time
import urllib.parse
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from xml.sax.saxutils import escape as xml_escape

import requests
from flask import Flask, Response, jsonify, render_template, request, stream_with_context

# ── App ───────────────────────────────────────────────────────────────────────
app = Flask(__name__)
logging.basicConfig(
    stream=sys.stdout, level=logging.INFO,
    format="[%(asctime)s] %(levelname)s %(name)s: %(message)s", force=True,
)
app.logger.setLevel(logging.INFO)

def _log(msg: str):
    try: app.logger.warning(msg)
    except Exception: pass

# ── Thread pool (used for fire-and-forget AD API calls) ──────────────────────
_pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="ad-worker")

# ── AllDebrid API endpoints ───────────────────────────────────────────────────
AD_BASE   = "https://api.alldebrid.com/v4"
AD_UPLOAD   = f"{AD_BASE}/magnet/upload"
AD_DELETE = f"{AD_BASE}/magnet/delete"
AD_STATUS = "https://api.alldebrid.com/v4.1/magnet/status"
AD_FILES  = f"{AD_BASE}/magnet/files"
AD_UNLOCK = f"{AD_BASE}/link/unlock"
AD_USER   = f"{AD_BASE}/user"

# AllDebrid requires an `agent` query parameter on EVERY v4 endpoint
# (it's marked required:true in their OpenAPI spec, and AUTH_MISSING_AGENT
# is a real error code) — without it, calls fail even with a valid apikey.
AD_AGENT = os.environ.get("ALLDEBRID_AGENT", "alldebrid-web")

AD_API_KEY_ENV = os.environ.get("ALLDEBRID_API_KEY", "")
TORZNAB_APIKEY = os.environ.get("TORZNAB_APIKEY", "changeme")
PROWLARR_URL   = os.environ.get("PROWLARR_URL", "")
PROWLARR_KEY   = os.environ.get("PROWLARR_API_KEY", "")

# ── AllDebrid rate limiter — 250 req/min sliding-window + minimum spacing ─────
# The per-minute cap alone only limits total volume — it does nothing to stop
# many threads passing the check in the same instant (e.g. FUSE_DIRECTDL_WORKERS
# parallel prewarm threads, each making one magnet/files + one link/unlock call
# per file). AllDebrid's nginx front-end enforces its own short-window burst
# limit independent of the per-minute total, so a burst like that can trip
# 503s even while staying well under 250/min. AD_MIN_SPACING_MS adds a floor
# on the gap between consecutive request *starts* so concurrent callers queue
# up and release one at a time instead of firing together. Default spacing
# matches even distribution across the per-minute budget (60s / 250 ≈ 240ms).
_AD_RATE_LIMIT    = int(os.environ.get("AD_RATE_LIMIT", "250"))
_AD_RATE_WINDOW   = 60.0
_AD_MIN_SPACING   = float(os.environ.get("AD_MIN_SPACING_MS", "240")) / 1000.0
_ad_rate_lock     = threading.Lock()
_ad_timestamps: list[float] = []
_ad_last_request_at = 0.0

def _ad_api_acquire():
    global _ad_last_request_at
    while True:
        now    = time.monotonic()
        cutoff = now - _AD_RATE_WINDOW
        with _ad_rate_lock:
            while _ad_timestamps and _ad_timestamps[0] < cutoff:
                _ad_timestamps.pop(0)
            since_last = now - _ad_last_request_at
            under_cap  = len(_ad_timestamps) < _AD_RATE_LIMIT
            spaced_out = since_last >= _AD_MIN_SPACING
            if under_cap and spaced_out:
                _ad_timestamps.append(now)
                _ad_last_request_at = now
                return
            wait_for_cap   = (_ad_timestamps[0] - cutoff) + 0.01 if not under_cap else 0.0
            wait_for_space = (_AD_MIN_SPACING - since_last) if not spaced_out else 0.0
            wait = max(wait_for_cap, wait_for_space)
        time.sleep(max(wait, 0.01))

def _ad_headers(key: str) -> dict:
    return {"Authorization": f"Bearer {key}"}

def _ad_params(params: dict | None = None) -> dict:
    """Merge the required `agent` param into any query/form params."""
    merged = {"agent": AD_AGENT}
    if params:
        merged.update(params)
    return merged

def _ad_get(key: str, url: str, params: dict | None = None) -> dict:
    _ad_api_acquire()
    try:
        r = requests.get(url, headers=_ad_headers(key), params=_ad_params(params), timeout=20)
        if r.status_code >= 400:
            # Surface the actual AllDebrid error body instead of swallowing
            # it — error codes like AUTH_MISSING_AGENT / AUTH_BAD_APIKEY are
            # only visible here, not from a generic raise_for_status().
            try:
                body = r.json()
            except Exception:
                body = r.text[:200]
            app.logger.warning(f"[ad-get] {url} -> HTTP {r.status_code}: {body}")
            return body if isinstance(body, dict) else {}
        return r.json()
    except Exception as e:
        app.logger.warning(f"[ad-get] {url}: {e}"); return {}

def _ad_post_raw(key: str, url: str, pairs: list) -> dict:
    _ad_api_acquire()
    try:
        all_pairs = [("agent", AD_AGENT)] + list(pairs)
        r = requests.post(url,
            headers={**_ad_headers(key), "Content-Type": "application/x-www-form-urlencoded"},
            data=urllib.parse.urlencode(all_pairs), timeout=20)
        if r.status_code >= 400:
            try:
                body = r.json()
            except Exception:
                body = r.text[:200]
            app.logger.warning(f"[ad-post] {url} -> HTTP {r.status_code}: {body}")
            return body if isinstance(body, dict) else {}
        return r.json()
    except Exception as e:
        app.logger.warning(f"[ad-post] {url}: {e}"); return {}

def _ad_upload_batch(key: str, magnets: list) -> dict:
    return _ad_post_raw(key, AD_UPLOAD, [("magnets[]", m) for m in magnets])

def _ad_delete(key: str, mid: int):
    if not key or not mid: return
    _ad_api_acquire()
    try:
        r = requests.post(AD_DELETE,
            headers={**_ad_headers(key), "Content-Type": "application/x-www-form-urlencoded"},
            data=urllib.parse.urlencode({"agent": AD_AGENT, "id": mid}), timeout=15)
        if r.status_code >= 400:
            app.logger.warning(f"[ad-delete] {mid} -> HTTP {r.status_code}: {r.text[:200]}")
    except Exception as e:
        app.logger.warning(f"[ad-delete] {mid}: {e}")

def _make_magnet(hash_: str, name: str = "") -> str:
    n = urllib.parse.quote(name, safe="")
    return f"magnet:?xt=urn:btih:{hash_.lower()}&dn={n}" if n else f"magnet:?xt=urn:btih:{hash_.lower()}"

# ── Torznab per-IP rate limiter ───────────────────────────────────────────────
TORZNAB_RATE_LIMIT  = int(os.environ.get("TORZNAB_RATE_LIMIT",  "60"))
TORZNAB_RATE_WINDOW = int(os.environ.get("TORZNAB_RATE_WINDOW", "60"))
_tz_lock = threading.Lock()
_tz_data: dict[str, list] = defaultdict(list)

def _check_torznab_rate(ip: str):
    now    = time.time()
    cutoff = now - TORZNAB_RATE_WINDOW
    with _tz_lock:
        hits = [t for t in _tz_data[ip] if t > cutoff]
        rem  = max(0, TORZNAB_RATE_LIMIT - len(hits))
        rst  = int(now + TORZNAB_RATE_WINDOW)
        if rem == 0: return False, TORZNAB_RATE_LIMIT, 0, rst
        hits.append(now); _tz_data[ip] = hits
        return True, TORZNAB_RATE_LIMIT, rem - 1, rst

def _rate_hdrs(limit, rem, rst):
    return {"X-RateLimit-Limit": str(limit),
            "X-RateLimit-Remaining": str(rem),
            "X-RateLimit-Reset": str(rst)}

# ── Persistent config ─────────────────────────────────────────────────────────
CONFIG_PATH  = os.environ.get("CONFIG_PATH", "/app/data/config.json")
_cfg_lock    = threading.Lock()
_cfg_cache: dict | None = None

def _load_config() -> dict:
    global _cfg_cache
    if _cfg_cache is not None: return _cfg_cache
    try:
        with open(CONFIG_PATH) as f: _cfg_cache = json.load(f)
    except Exception: _cfg_cache = {}
    return _cfg_cache

def _save_config(cfg: dict):
    global _cfg_cache
    os.makedirs(os.path.dirname(CONFIG_PATH) or ".", exist_ok=True)
    with _cfg_lock:
        _cfg_cache = cfg
        with open(CONFIG_PATH, "w") as f: json.dump(cfg, f, indent=2)

def get_ad_api_key() -> str:
    # Treat common unedited-placeholder values as "not actually set" so a
    # leftover `ALLDEBRID_API_KEY=your_alldebrid_api_key_here` in
    # docker-compose.yml (the literal default shipped in this repo) can't
    # permanently block the key saved via the web UI settings page.
    env_key = AD_API_KEY_ENV.strip()
    placeholder_values = {
        "", "your_alldebrid_api_key_here", "changeme",
        "your_api_key_here", "your_apikey_here",
    }
    if env_key.lower() in placeholder_values:
        return _load_config().get("ad_api_key", "")
    return env_key

def save_ad_api_key(k: str):
    cfg = _load_config(); cfg["ad_api_key"] = k; _save_config(cfg)

def get_prowlarr_config() -> dict:
    s = _load_config().get("prowlarr", {})
    return {"url": PROWLARR_URL or s.get("url",""),
            "api_key": PROWLARR_KEY or s.get("api_key",""),
            "from_env": bool(PROWLARR_URL or PROWLARR_KEY)}

def save_prowlarr_config(url: str, key: str):
    url = url.strip().rstrip("/")
    if url and not url.startswith(("http://","https://")): url = "http://" + url
    cfg = _load_config(); cfg["prowlarr"] = {"url": url, "api_key": key}; _save_config(cfg)

# ── HMAC stream tokens ────────────────────────────────────────────────────────
import hmac as _hmac

def _get_token_secret() -> str:
    cfg = _load_config()
    if "token_secret" not in cfg:
        cfg["token_secret"] = secrets.token_hex(32); _save_config(cfg)
    return cfg["token_secret"]

def _make_stream_token(hash_: str, filename: str) -> str:
    return _hmac.new(_get_token_secret().encode(), f"{hash_}:{filename}".encode(), "sha256").hexdigest()

def _verify_stream_token(token: str, hash_: str, filename: str) -> bool:
    return _hmac.compare_digest(token, _make_stream_token(hash_, filename))

# ── Cache-check (upload → read ready → delete) ───────────────────────────────
# AllDebrid deprecated real-time "instant availability" lookups (magnet/instant
# no longer reflects true cache state — see their API changelog). The only
# reliable way to know if a torrent is cached now is to actually upload the
# magnet: the upload response's `ready` flag is accurate immediately. If we
# don't want to keep it (just checking for search), we delete it right after.
_cc_results: dict = {}
_cc_lock          = threading.Lock()
_CC_TTL           = 300

def check_cache_ad(key: str, torrents: list) -> dict:
    """Return {hash: bool} — True means AllDebrid has the torrent cached.

    Method: upload magnet(s) → read `ready` from the upload response →
    delete any magnet we uploaded purely for checking (i.e. not already a
    real tracked transfer the user added on purpose). This costs 2 API calls
    per *uncached-in-our-local-cache* batch (1 upload + 1 delete-per-id) but
    is the only method that reflects AllDebrid's real cache state today.

    Results are cached in-process for 5 minutes (_CC_TTL) so repeated
    searches for the same hashes don't re-hit the upstream API.
    """
    if not torrents or not key: return {}
    hashes = [t["info_hash"].lower() for t in torrents]
    now    = time.time()
    with _cc_lock:
        stale = [h for h in hashes if h not in _cc_results or now >= _cc_results[h][1]]
    if not stale:
        with _cc_lock: return {h: _cc_results[h][0] for h in hashes if h in _cc_results}

    # Don't re-check (or delete!) hashes the user already has as a real,
    # tracked transfer — those stay in their AllDebrid library on purpose.
    tracked_hashes: set = set()
    try:
        if _tm is not None:
            tracked_hashes = {t["hash"].lower() for t in _tm.all_transfers() if not t.get("is_stub")}
    except Exception:
        pass

    name_by_hash = {t["info_hash"].lower(): t.get("name", "") for t in torrents}
    ready_map: dict[str, bool] = {}
    to_delete: list[int] = []  # ad_ids to clean up after reading ready state

    # Upload in chunks — AllDebrid accepts multiple magnets[] per request,
    # but very large batches are split to stay well under any payload limits.
    CHUNK = 20
    for i in range(0, len(stale), CHUNK):
        chunk = stale[i:i + CHUNK]
        magnets = [_make_magnet(h, name_by_hash.get(h, "")) for h in chunk]
        if i == 0:
            # One real sample per check, logged at INFO so it survives in
            # production — lets us see exactly what we sent and exactly
            # what AllDebrid sent back without guessing.
            app.logger.info(f"[cache-check] sample magnet sent: {magnets[0]}")
        try:
            resp = _ad_upload_batch(key, magnets)
        except Exception as e:
            app.logger.warning(f"[cache-check] upload failed: {e}")
            continue
        if i == 0:
            app.logger.info(f"[cache-check] raw response (truncated): {str(resp)[:500]}")

        # A failed call can come back as a TOP-LEVEL error (e.g. bad apikey,
        # rate limited) rather than a per-magnet one — in that case there is
        # no "data" key at all, so silently doing resp.get("data",{}) here
        # would make every hash in this chunk look "not cached" with zero
        # indication anything actually went wrong. Surface it instead.
        if resp.get("status") == "error":
            err = resp.get("error", {})
            app.logger.warning(
                f"[cache-check] AllDebrid error {err.get('code')}: {err.get('message')}"
            )
            continue

        items = resp.get("data", {}).get("magnets", [])
        if not items:
            app.logger.warning(
                f"[cache-check] upload returned status=success but 0 magnets "
                f"in response for {len(chunk)} requested hash(es) — "
                f"raw response: {str(resp)[:300]}"
            )
        n_errors = 0
        for idx, m in enumerate(items):
            # AllDebrid normally echoes the hash back; fall back to the
            # request's positional order if it's ever missing so we don't
            # drop results silently.
            h = (m.get("hash") or "").lower()
            if not h and idx < len(chunk):
                h = chunk[idx]
            if not h:
                app.logger.warning(f"[cache-check] magnet item has no hash and no positional fallback: {m}")
                continue
            if m.get("error"):
                err = m["error"]
                app.logger.warning(f"[cache-check] {h[:8]}: {err.get('code')} {err.get('message')}")
                ready_map[h] = False
                n_errors += 1
                continue
            ready_map[h] = bool(m.get("ready", False))
            ad_id = m.get("id")
            if ad_id and h not in tracked_hashes:
                to_delete.append(ad_id)

        n_ready = sum(1 for m in items if not m.get("error") and m.get("ready"))
        app.logger.info(
            f"[cache-check] batch of {len(chunk)}: {n_ready} ready, "
            f"{n_errors} errored, {len(items) - n_ready - n_errors} not-ready"
        )

    # Clean up — remove anything we uploaded just to probe cache status.
    # Fire-and-forget via the thread pool so search responses aren't held up.
    for ad_id in to_delete:
        try:
            _pool.submit(_ad_delete, key, ad_id)
        except Exception:
            _ad_delete(key, ad_id)

    exp = now + _CC_TTL
    with _cc_lock:
        for h in stale:
            _cc_results[h] = (ready_map.get(h, False), exp)
    with _cc_lock:
        return {h: _cc_results[h][0] for h in hashes if h in _cc_results}



# ── TransferManager — single global instance ──────────────────────────────────
_tm = None   # set by _init_tm() below
_fuse_thread = None
_remount_lock = threading.Lock()

def _init_tm():
    global _tm
    try:
        from transfer_manager import TransferManager
        _tm = TransferManager(ad_api_key_fn=get_ad_api_key)
        _log("[TM] AllDebrid TransferManager initialised")
        try:
            import qbt_mock as _qm; _qm._tm = _tm
        except Exception: pass
    except Exception as e:
        _log(f"[TM] init failed: {e}")

def _start_fuse():
    global _fuse_thread
    mp = os.environ.get("FUSE_MOUNTPOINT", "/docker/alldebrid-web/mnt")
    try:
        import fuse_mount as _fm

        # Apply any previously-saved Mount Configuration settings FIRST,
        # before any early-return — these update plain Python globals in
        # fuse_mount (chunk size, timeouts, etc.) and should take effect
        # regardless of whether the actual mount succeeds this time, so a
        # transient "fusepy not installed" or "TransferManager not ready"
        # condition can't silently skip applying them.
        saved_fuse = _load_config().get("fuse", {})
        if saved_fuse:
            try:
                _fm.apply_mount_options(saved_fuse)
                _fm.apply_runtime_settings(saved_fuse)
            except Exception as e:
                _log(f"[FUSE] applying saved settings failed: {e}")

        if not _fm.FUSE_AVAILABLE:
            _log("[FUSE] fusepy not installed — mount skipped"); return
        if _tm is None:
            _log("[FUSE] TransferManager not ready — mount skipped"); return
        _fm._overrides          = _load_config().get("classification_overrides", {})
        _fm._4K_FOLDERS_ENABLED = bool(_load_config().get("fuse",{}).get("enable_4k_folders", False))
        _log(f"[FUSE] Mounting AllDebrid FS at {mp}")
        _fuse_thread = threading.Thread(
            target=_fm.mount, args=(mp, _tm), kwargs={"foreground": True},
            daemon=True, name="fuse-mount")
        _fuse_thread.start()
    except Exception as e:
        _log(f"[FUSE] startup failed: {e}")

def _remount_fuse(timeout: float = 15.0) -> bool:
    """Cleanly unmount and remount FUSE — used when a setting that can only
    take effect at FUSE() construction time changes (uid/gid/umask/cache_dir).

    Locked so two settings-saves in quick succession can't both trigger a
    remount at once and race on the same mountpoint. Returns True if the
    new mount thread started; doesn't guarantee the mount itself succeeded
    (that's logged separately by fuse_mount.mount()), since mount() blocks
    for the mount's whole lifetime and we can't wait on it here.
    """
    global _fuse_thread
    if not _remount_lock.acquire(blocking=False):
        _log("[FUSE] remount already in progress — ignoring concurrent request")
        return False
    try:
        import fuse_mount as _fm
        _log("[FUSE] Remounting to apply uid/gid/umask/cache_dir change...")
        _fm.unmount()
        old_thread = _fuse_thread
        if old_thread is not None and old_thread.is_alive():
            old_thread.join(timeout=timeout)
            if old_thread.is_alive():
                _log(f"[FUSE] WARNING: old mount thread still alive after {timeout}s — "
                     f"starting new mount anyway, may conflict")
        _start_fuse()
        return True
    except Exception as e:
        _log(f"[FUSE] remount failed: {e}")
        return False
    finally:
        _remount_lock.release()

# Register qbt Blueprint before init so it's available immediately
try:
    from qbt_mock import qbt as _qbt_bp
    app.register_blueprint(_qbt_bp)
    _log("[qbt] Blueprint registered at /qbt/api/v2")
except Exception as _e:
    _log(f"[qbt] Blueprint not loaded: {_e}")

_init_tm()
_start_fuse()

# ── 30-day stub manager ───────────────────────────────────────────────────────
STUB_AFTER_DAYS = int(_load_config().get("stub_after_days", 0) or os.environ.get("STUB_AFTER_DAYS", "30"))
STUB_AFTER_SECS = STUB_AFTER_DAYS * 86400
_stub_stop = threading.Event()

def _do_stub_pass():
    """Stub transfers inactive for more than STUB_AFTER_DAYS.

    'Last activity' is the most recent of last_played and added_at — whichever
    is later wins.  This means a transfer that was added but never played starts
    its 30-day clock from added_at, while one that has been played starts it
    from last_played.  We only stub transfers in 'cached' or 'complete' state
    so in-progress downloads are never touched.
    """
    if _tm is None: return
    cutoff = time.time() - STUB_AFTER_SECS
    stubbed = 0
    for t in _tm.all_transfers():
        if t.get("is_stub") or t.get("state") not in ("cached", "complete"): continue
        # Use the most-recent activity timestamp as the inactivity clock start.
        last_played = t.get("last_played") or 0
        added_at    = t.get("added_at")    or 0
        last_activity = max(last_played, added_at)
        if last_activity == 0 or last_activity >= cutoff:
            continue
        h = t["hash"]; ad_id = t.get("ad_id"); name = t.get("name") or h
        inactive_days = int((time.time() - last_activity) / 86400)
        _log(f"[stub] stubbing '{name[:60]}' (inactive {inactive_days}d > {STUB_AFTER_DAYS}d limit)")
        key = get_ad_api_key()
        if ad_id and key:
            _pool.submit(_ad_delete, key, ad_id)
        _tm._set(h, is_stub=1, ad_id=None)
        stubbed += 1
    if stubbed: _log(f"[stub] {stubbed} transfer(s) stubbed this pass")

def _stub_loop():
    while not _stub_stop.wait(timeout=3600):
        try: _do_stub_pass()
        except Exception as e: _log(f"[stub] error: {e}")

threading.Thread(target=_stub_loop, daemon=True, name="stub-manager").start()
_log(f"[stub] manager started — stub after {STUB_AFTER_DAYS}d inactivity")

# ── Search (TPB + Prowlarr) ───────────────────────────────────────────────────
QUALITY_RE = re.compile(
    r'\b(2160p?|1080p?|720p?|480p?|4k|uhd|hdr|hdr10|dv|web-?dl|webrip|bluray|'
    r'blu-ray|hevc|x265|x264|h264|h265|remux|proper|repack)\b', re.I)

APIBAY = ["https://apibay.org/q.php",
          "https://apibay.nocensor.space/q.php",
          "https://thepiratebay.org/q.php"]

def _fmt_size(b):
    try: b=int(b)
    except: return 0
    return b

def _fmt_size_str(b):
    try: b=int(b)
    except: return "?"
    if b>1e9: return f"{b/1e9:.2f} GB"
    if b>1e6: return f"{b/1e6:.0f} MB"
    if b>1e3: return f"{b/1e3:.0f} KB"
    return f"{b} B"

def _sanitize(q):
    q = re.sub(r"[''`´]","",q); q = re.sub(r"[^\w\s\-]"," ",q)
    return re.sub(r"\s+"," ",q).strip()

def parse_query(raw):
    quality = QUALITY_RE.findall(raw); s = QUALITY_RE.sub("",raw).strip()
    season = episode = None
    m = re.search(r'\bseason\s+(\d+)\b',s,re.I)
    if m: season=int(m.group(1)); s=re.sub(r'\bseason\s+\d+\b',f'S{season:02d}',s,flags=re.I)
    m = re.search(r'(?<![a-zA-Z])S(\d{1,2})(?:E(\d{1,2}))?(?![a-zA-Z0-9])',s,re.I)
    if m: season=int(m.group(1)); episode=int(m.group(2)) if m.group(2) else None
    return " ".join(s.split()).strip(), season, episode, quality

def strip_season(q):
    return " ".join(re.sub(r'(?<![a-zA-Z])S\d{1,2}(?:E\d{1,2})?(?![a-zA-Z0-9])','',q,flags=re.I).split())

def tpb_to_newznab(cat, name=""):
    n=(name or "").upper()
    if re.search(r'S\d{2}E\d{2}|SEASON\s+\d+|\bS\d{2}\b',n): return 5000
    try: c=int(cat)
    except: return 8000
    if 200<=c<300: return 2000
    if 500<=c<600: return 5000
    if 300<=c<400: return 3000
    return 8000

def normalize_cat(cat, name=""):
    try: c=int(cat or 0)
    except: c=0
    if 0<c<1000: return tpb_to_newznab(c,name)
    if c>=1000: return c
    return 8000

def _fetch_tpb(query, limit=40):
    for q in ([query,_sanitize(query)] if _sanitize(query).lower()!=query.lower() else [query]):
        for url in APIBAY:
            try:
                r=requests.get(url,params={"q":q,"cat":0},timeout=10)
                if r.status_code!=200: continue
                data=r.json()
                if not data or (isinstance(data,list) and data[0].get("id")=="0"): continue
                v=[x for x in data if isinstance(x,dict) and x.get("info_hash")
                   and re.fullmatch(r'[0-9a-fA-F]{40}',x["info_hash"])]
                if v: return v[:limit]
            except Exception: continue
    return []

def _fetch_prowlarr(query, season=None, episode=None, limit=40):
    cfg=get_prowlarr_config()
    if not cfg.get("url") or not cfg.get("api_key"): return []
    base,key=cfg["url"],cfg["api_key"]
    q=query
    if season is not None:
        qb=strip_season(query); q=f"{qb} S{season:02d}" if qb else f"S{season:02d}"
        if episode is not None: q+=f"E{episode:02d}"
        q=" ".join(q.split())
    try:
        r=requests.get(f"{base}/api/v1/search",headers={"X-Api-Key":key},
            params={"query":q,"indexerIds":-2,"categories":[2000,5000,8000],"type":"search","limit":limit},timeout=20)
        r.raise_for_status(); data=r.json()
    except Exception as e:
        app.logger.warning(f"Prowlarr: {e}"); return []
    def _hash(item):
        h=(item.get("infoHash") or "").lower().strip()
        if re.fullmatch(r'[0-9a-fA-F]{40}',h): return h
        for f in ("magnetUrl","downloadUrl","guid"):
            v=item.get(f) or ""
            m=re.search(r'btih:([0-9a-fA-F]{40})',v,re.I)
            if m: return m.group(1).lower()
            m=re.search(r'(?<![0-9a-fA-F])([0-9a-fA-F]{40})(?![0-9a-fA-F])',v)
            if m: return m.group(1).lower()
        return ""
    results=[]
    for item in data:
        h=_hash(item)
        if not h: continue
        cats=item.get("categories") or []; cat=8000
        for c in cats:
            cid=c.get("id",0) if isinstance(c,dict) else c
            try: cid=int(cid or 0)
            except: continue
            if 2000<=cid<3000: cat=cid; break
            if 5000<=cid<6000: cat=cid; break
        results.append({"info_hash":h,"name":item.get("title","Unknown"),
            "size":item.get("size",0),"seeders":item.get("seeders",0) or 0,
            "leechers":item.get("leechers",0) or 0,"category":cat,"indexer":item.get("indexer","")})
    return results

def do_search(query, season=None, episode=None, quality=None, limit=40, ad_key=None):
    cfg=get_prowlarr_config()
    if cfg.get("url") and cfg.get("api_key"):
        torrents=_fetch_prowlarr(query,season,episode,limit); source="prowlarr"
    else:
        torrents=[]; source="tpb"
    if not torrents:
        torrents=_fetch_tpb(query,limit); source="tpb"
        if not torrents and season is not None:
            fb=strip_season(query)
            if fb and fb.lower()!=query.lower(): torrents=_fetch_tpb(fb,limit*2)
    if not torrents: return []
    if source=="tpb":
        if season is not None:
            s_str=f"S{season:02d}"; s_alt=f"SEASON {season}"
            f2=[t for t in torrents if s_str in t.get("name","").upper() or s_alt in t.get("name","").upper()]
            if f2: torrents=f2
        if quality:
            f2=[t for t in torrents if any(q.upper().rstrip("P") in t.get("name","").upper() for q in quality)]
            if f2: torrents=f2
    # Only probe cache status for the first page of results — checking
    # every result on every search (which uploads+deletes a magnet per
    # torrent) doesn't scale, and most users only look at the top results
    # anyway. Anything beyond the cap is shown as not-cached by default;
    # it'll get a real check if/when the user actually clicks Add on it.
    CACHE_CHECK_LIMIT = 20
    to_check  = torrents[:CACHE_CHECK_LIMIT]
    ready_map = check_cache_ad(ad_key, to_check) if ad_key else {}
    results,seen=[],set()
    for t in torrents:
        h=t["info_hash"].lower()
        if h in seen: continue
        seen.add(h)
        results.append({"hash":h,"name":t.get("name","Unknown"),
            "size":_fmt_size(t.get("size",0)),"size_str":_fmt_size_str(t.get("size",0)),
            "seeders":int(t.get("seeders",0) or 0),"leechers":int(t.get("leechers",0) or 0),
            "category":normalize_cat(t.get("category",8000),t.get("name","")),
            "cached":ready_map.get(h,False),"indexer":t.get("indexer","TPB")})
    results.sort(key=lambda x:(not x["cached"],-x["seeders"]))
    return results

# ── Torznab XML ───────────────────────────────────────────────────────────────
_TRACKERS=["udp://tracker.opentrackr.org:1337/announce","udp://open.tracker.cl:1337/announce",
           "udp://tracker.openbittorrent.com:6969/announce","udp://tracker.torrent.eu.org:451/announce"]

def torznab_caps():
    return '''<?xml version="1.0" encoding="UTF-8"?>
<caps>
  <server title="AllDebrid Indexer"/>
  <limits default="40" max="100"/>
  <searching>
    <search available="yes" supportedParams="q"/>
    <tv-search available="yes" supportedParams="q,season,ep"/>
    <movie-search available="yes" supportedParams="q"/>
  </searching>
  <categories>
    <category id="2000" name="Movies">
      <subcat id="2040" name="Movies/HD"/><subcat id="2045" name="Movies/UHD"/>
      <subcat id="2050" name="Movies/BluRay"/>
    </category>
    <category id="5000" name="TV">
      <subcat id="5040" name="TV/HD"/><subcat id="5045" name="TV/UHD"/>
    </category>
    <category id="8000" name="Other"/>
  </categories>
</caps>'''

def torznab_results(results, query=""):
    now = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
    items=[]
    for r in results:
        tr="".join(f"&tr={urllib.parse.quote(t,safe='')}" for t in _TRACKERS)
        mag=f"magnet:?xt=urn:btih:{r['hash']}&dn={urllib.parse.quote(r['name'],safe='')}{tr}"
        ca='<torznab:attr name="cached" value="1"/>' if r.get("cached") else ""
        ao=r.get("added_at") or 0
        pd=(datetime.fromtimestamp(float(ao),tz=timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000") if ao else now)
        items.append(f"""    <item>
      <title>{xml_escape(r['name'])}</title>
      <guid>{xml_escape(mag)}</guid><link>{xml_escape(mag)}</link>
      <pubDate>{pd}</pubDate><size>{r['size']}</size>
      <enclosure url="{xml_escape(mag)}" length="{r['size']}" type="application/x-bittorrent"/>
      <torznab:attr name="magneturl" value="{xml_escape(mag)}"/>
      <torznab:attr name="infohash" value="{r['hash']}"/>
      <torznab:attr name="seeders" value="{r.get('seeders',0)}"/>
      <torznab:attr name="leechers" value="{r.get('leechers',0)}"/>
      <torznab:attr name="size" value="{r['size']}"/>
      <torznab:attr name="category" value="{normalize_cat(r.get('category'),r.get('name',''))}"/>
      {ca}
    </item>""")
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:torznab="http://torznab.com/schemas/2015/feed">
  <channel>
    <title>AllDebrid Indexer</title>
    <link>http://localhost</link><language>en-US</language>
    <pubDate>{now}</pubDate>
    <response xmlns="urn:newznab:api" offset="0" total="{len(results)}"/>
{chr(10).join(items)}
  </channel>
</rss>'''

def xml_error(code, desc, hdrs=None):
    r=Response(f'''<?xml version="1.0" encoding="UTF-8"?>
<error code="{code}" description="{xml_escape(desc)}"/>''',mimetype="application/xml",status=400)
    if hdrs:
        for k,v in hdrs.items(): r.headers[k]=v
    return r

# ── TM convenience wrappers ───────────────────────────────────────────────────
def _tm_add(hash_: str, name: str):
    if _tm: return _tm.add(hash_, name)
    return None

def _tm_get(hash_: str):
    if _tm: return _tm.get_transfer(hash_)
    return None

def _tm_all():
    if _tm: return _tm.all_transfers()
    return []

def _tm_files(hash_: str, force=False):
    if _tm: return _tm.get_files(hash_, force=force)
    return []

def _tm_set(hash_: str, **kw):
    if _tm: _tm._set(hash_, **kw)

def _tm_delete(hash_: str):
    if _tm: _tm.delete(hash_)

def _tm_touch_played(hash_: str):
    """Record playback — update last_played, clear stub flag, unlock CDN.

    last_played is written to the DB here so the stub manager's inactivity
    clock resets on every play.  is_stub is cleared in the same write so a
    stub that was re-added and is playing doesn't accidentally get re-stubbed
    on the next hourly pass before _tm_readd finishes.
    """
    if _tm:
        _tm.touch_played(hash_)
        _tm.unlock_file_cdn(hash_, filename=None, mark_played=False)

def _tm_readd(hash_: str, name: str):
    """Re-add a stubbed transfer back to AllDebrid.

    After a successful upload we call _on_ready() so CDN links are fetched,
    unlocked, and written to the DB before the next FUSE read or stream
    request arrives.  last_played and is_stub are also updated here so the
    stub manager's inactivity clock starts fresh from now.
    """
    if _tm is None: return
    try:
        key = get_ad_api_key()
        if not key: return
        res = _ad_upload_batch(key, [_make_magnet(hash_, name)])
        mags = res.get("data", {}).get("magnets", [])
        if mags and not mags[0].get("error"):
            m = mags[0]; mid = m.get("id")
            state = "cached" if m.get("ready") else "downloading"
            _tm._set(hash_, ad_id=mid, state=state, is_stub=0, last_played=time.time())
            if m.get("ready"):
                # _on_ready fetches + unlocks CDN URLs, updates FUSE cache,
                # and triggers Plex scan — do it inline (we're already in a
                # worker thread, so it's safe to block here briefly).
                try:
                    _tm._on_ready(hash_)
                except Exception as e:
                    _log(f"[readd] _on_ready failed for {hash_[:8]}: {e}")
            _log(f"[readd] '{name[:60]}' re-added (id={mid}, state={state})")
        else:
            err = (mags[0].get("error", {}).get("message", "") if mags else "no magnets")
            _log(f"[readd] failed {hash_}: {err}")
    except Exception as e:
        _log(f"[readd] error: {e}")

# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    from flask import make_response
    r=make_response(render_template("index.html"))
    r.headers["Cache-Control"]="no-store,no-cache,must-revalidate,max-age=0"
    return r

# ── Torznab ───────────────────────────────────────────────────────────────────

@app.route("/torznab")
@app.route("/torznab/api")
def torznab():
    t=request.args.get("t","").lower()
    if t=="caps": return Response(torznab_caps(),mimetype="application/xml")
    apikey=request.args.get("apikey","") or request.headers.get("X-Api-Key","")
    if TORZNAB_APIKEY and apikey!=TORZNAB_APIKEY: return xml_error(100,"Invalid API key")
    ip=request.headers.get("X-Forwarded-For",request.remote_addr).split(",")[0].strip()
    ok,lim,rem,rst=_check_torznab_rate(ip); rh=_rate_hdrs(lim,rem,rst)
    if not ok:
        retry=rst-int(time.time())
        return Response(f'''<?xml version="1.0" encoding="UTF-8"?>
<error code="429" description="Rate limit exceeded. Retry after {retry}s"/>''',
            mimetype="application/xml",status=429,headers={**rh,"Retry-After":str(retry)})
    if t in ("search","tvsearch","movie"):
        q=request.args.get("q","").strip()
        season=request.args.get("season","").strip()
        ep=request.args.get("ep","").strip()
        cat=request.args.get("cat","").strip()
        ps=pe=None
        if season:
            try: ps=int(season); pe=int(ep) if ep else None
            except ValueError: pass
        if not q:
            transfers=_tm_all()
            fb=[]
            for tr in transfers:
                if tr.get("state") not in ("cached","complete"): continue
                nm=tr.get("name") or tr["hash"]
                is_s=bool(re.search(r'\bS\d{1,2}(?:E\d{1,2})?\b|\bSeason\s*\d+\b',nm,re.I))
                fb.append({"hash":tr["hash"],"name":nm,"size":0,"seeders":1,"leechers":0,
                    "category":5000 if is_s else 2000,"cached":True,"indexer":"alldebrid",
                    "added_at":tr.get("added_at") or 0})
            if cat and cat!="0":
                req=[int(c) for c in cat.split(",") if c.strip().isdigit()]
                if req:
                    f2=[r for r in fb if any(normalize_cat(r["category"])==rc
                        or normalize_cat(r["category"])//1000==rc//1000 for rc in req)]
                    if f2: fb=f2
            fb.sort(key=lambda x:float(x.get("added_at") or 0),reverse=True)
            resp=Response(torznab_results(fb,""),mimetype="application/xml")
            for k,v in rh.items(): resp.headers[k]=v
            return resp
        pq,pss,ppe,qual=parse_query(q); ps=ps or pss; pe=pe or ppe
        results=do_search(pq,ps,pe,qual,limit=40,ad_key=get_ad_api_key())
        if _load_config().get("torznab_cached_only",False):
            c2=[r for r in results if r.get("cached")]
            if c2: results=c2
        if cat and cat!="0":
            req=[int(c) for c in cat.split(",") if c.strip().isdigit()]
            if req:
                f2=[r for r in results if any(normalize_cat(r.get("category"))==rc
                    or normalize_cat(r.get("category"))//1000==rc//1000 for rc in req)]
                if f2: results=f2
        resp=Response(torznab_results(results,q),mimetype="application/xml")
        for k,v in rh.items(): resp.headers[k]=v
        return resp
    return xml_error(202,f"Unknown function: {t}",rh)

# ── Search ────────────────────────────────────────────────────────────────────

@app.route("/api/search",methods=["POST"])
def search():
    d=request.json or {}
    key=d.get("api_key","").strip() or get_ad_api_key()
    q=d.get("query","").strip()
    if not key: return jsonify({"error":"API key required"}),400
    if not q:   return jsonify({"error":"Query required"}),400
    pq,s,e,qual=parse_query(q)
    results=do_search(pq,s,e,qual,limit=40,ad_key=key)
    return jsonify({"results":[{**r,"size":r["size_str"]} for r in results],"total":len(results),
        "source":"prowlarr" if get_prowlarr_config().get("url") else "tpb"})

# ── Add — goes through TransferManager so FUSE sees it immediately ────────────

@app.route("/api/add",methods=["POST"])
def add():
    d=request.json or {}
    key=d.get("api_key","").strip() or get_ad_api_key()
    hash_=d.get("hash","").strip().lower()
    name=d.get("name","").strip()
    if not hash_: return jsonify({"error":"hash required"}),400
    if not key:   return jsonify({"error":"API key required"}),400
    if _tm is None: return jsonify({"error":"Service initialising"}),503
    # If the user previously deleted this hash and is now explicitly re-adding
    # it, clear the tombstone so sync_library tracks it normally going forward.
    if _tm.is_user_deleted(hash_):
        with _tm._lock:
            _tm._db().execute("DELETE FROM deleted WHERE hash=?", (hash_,))
            _tm._db().commit()
    t=_tm_get(hash_)
    if t and t.get("is_stub"):
        # Stub triggered on add — re-upload to AllDebrid.
        # Update last_played now (before the async re-add finishes) so the
        # stub manager's inactivity clock resets immediately and doesn't
        # re-stub this transfer on the next hourly pass.
        _tm_set(hash_, is_stub=0, last_played=time.time())
        _pool.submit(_tm_readd, hash_, name or t.get("name") or hash_)
        t = _tm_get(hash_)
    elif not t or t.get("state") not in ("cached","complete","downloading"):
        t=_tm_add(hash_, name)  # TransferManager uploads, polls, unlocks
    return jsonify({
        "name":  t.get("name") if t else name,
        "hash":  hash_,
        "state": t.get("state") if t else "queued",
        "ready": t.get("state") in ("cached","complete") if t else False,
    })

# ── Remove ────────────────────────────────────────────────────────────────────

@app.route("/api/remove",methods=["POST"])
def remove():
    d=request.json or {}
    hash_=d.get("hash","").strip().lower()
    if not hash_: return jsonify({"error":"hash required"}),400
    _tm_delete(hash_)
    return jsonify({"ok":True})

# ── Links (unlocked CDN URLs for modal player) ────────────────────────────────

@app.route("/api/links",methods=["POST"])
def get_links():
    d=request.json or {}
    key=d.get("api_key","").strip() or get_ad_api_key()
    hash_=d.get("hash","").strip().lower()
    name=d.get("name","").strip()
    if not key or not hash_: return jsonify({"error":"api_key and hash required"}),400
    if _tm is None: return jsonify({"error":"Service initialising"}),503
    t=_tm_get(hash_)
    # Re-add if stub was triggered
    if t and t.get("is_stub"):
        _log(f"[links] stub play '{name or hash_}' — re-adding")
        # Reset last_played immediately so the stub manager doesn't
        # re-stub this transfer during the async re-add window.
        _tm_set(hash_, is_stub=0, last_played=time.time())
        _tm_readd(hash_, name or t.get("name") or hash_)
        t = _tm_get(hash_)
    # Ensure it's in AllDebrid and get files (TransferManager handles upload + unlock)
    files=_tm_files(hash_)
    if not files:
        # Not yet uploaded — add it now and wait briefly for upload
        if not t or t.get("state") not in ("cached","complete"):
            _tm_add(hash_, name or (t.get("name") if t else "") or hash_)
            time.sleep(1.5)
            files=_tm_files(hash_)
    if not files: return jsonify({"error":"No files found — torrent may not be cached on AllDebrid"}),404
    # Build link list with stream URLs
    import urllib.parse as _up
    result=[]
    VIDEO_EXTS={".mkv",".mp4",".avi",".mov",".m4v",".ts",".wmv",".flv",".webm"}
    for f in files:
        nm=f.get("name") or ""
        ext=os.path.splitext(nm)[1].lower()
        cdn=f.get("cdn_url") or f.get("link") or ""
        tok=_make_stream_token(hash_,nm) if cdn else ""
        result.append({"name":nm,"link":cdn,"size":f.get("size",0),
            "is_video":ext in VIDEO_EXTS,
            "stream_url":f"/api/stream/{tok}?h={hash_}&f={_up.quote(nm)}" if tok else ""})
    _tm_touch_played(hash_)
    return jsonify({"links":result})

# ── Stream proxy ──────────────────────────────────────────────────────────────

@app.route("/api/stream/<token>")
def stream_proxy(token):
    hash_=request.args.get("h","").strip().lower()
    fn=request.args.get("f","").strip()
    if not hash_ or not fn: return jsonify({"error":"Missing params"}),400
    if not _verify_stream_token(token,hash_,fn): return jsonify({"error":"Invalid token"}),403
    if _tm is None: return jsonify({"error":"Service initialising"}),503
    t=_tm_get(hash_)
    if t and t.get("is_stub"):
        # Reset last_played immediately so the hourly stub pass doesn't
        # re-stub this while _tm_readd is still running in the background.
        _tm_set(hash_, is_stub=0, last_played=time.time())
        _pool.submit(_tm_readd, hash_, t.get("name") or hash_)
        time.sleep(0.5)
    files=_tm_files(hash_)
    f=next((x for x in files if x.get("name")==fn or (x.get("path") or "").endswith("/"+fn)),None)
    if not f: return jsonify({"error":"File not found"}),404
    cdn=f.get("cdn_url") or f.get("link") or ""
    if not cdn:
        # CDN URL missing — try refresh
        new=_tm.refresh_cdn_url(hash_,fn) if _tm else None
        if not new: return jsonify({"error":"Could not get CDN URL"}),502
        cdn=new
    _tm_touch_played(hash_)
    hdrs={}
    if "Range" in request.headers: hdrs["Range"]=request.headers["Range"]
    try: up=requests.get(cdn,headers=hdrs,stream=True,timeout=30)
    except requests.RequestException as e: return jsonify({"error":str(e)}),502
    ext=os.path.splitext(fn)[1].lower()
    mime={".mp4":"video/mp4",".mkv":"video/x-matroska",".avi":"video/x-msvideo",
          ".mov":"video/quicktime",".m4v":"video/mp4",".ts":"video/mp2t",
          ".webm":"video/webm",".wmv":"video/x-ms-wmv"}
    ct=up.headers.get("Content-Type") or mime.get(ext,"application/octet-stream")
    rh={"Content-Type":ct,"Accept-Ranges":up.headers.get("Accept-Ranges","bytes")}
    if "Content-Length" in up.headers: rh["Content-Length"]=up.headers["Content-Length"]
    if "Content-Range"  in up.headers: rh["Content-Range"]=up.headers["Content-Range"]
    def gen():
        for chunk in up.iter_content(chunk_size=256*1024): yield chunk
    return Response(gen(),status=up.status_code,headers=rh)

# ── Library / transfers list ──────────────────────────────────────────────────

@app.route("/api/transfers")
def list_transfers():
    now=time.time()
    result=[]
    for t in _tm_all():
        last=t.get("last_played") or t.get("added_at") or 0
        di=max(0,int((now-last)/86400)) if last else None
        dus=None
        if not t.get("is_stub") and last:
            dus=max(0,int((STUB_AFTER_SECS-(now-last))/86400))
        result.append({"hash":t["hash"],"name":t.get("name") or t["hash"],
            "state":t.get("state","queued"),"is_stub":bool(t.get("is_stub")),
            "last_played":t.get("last_played"),"days_inactive":di,"days_until_stub":dus,
            "ad_id":t.get("ad_id"),"category":t.get("category") or "",
            "added_at":t.get("added_at"),"kind":t.get("kind") or ""})
    return jsonify({"transfers":result})

@app.route("/api/transfer/status",methods=["POST"])
def transfer_status():
    d=request.json or {}
    key=d.get("api_key","").strip() or get_ad_api_key()
    hash_=d.get("hash","").strip().lower()
    if not key or not hash_: return jsonify({"error":"api_key and hash required"}),400
    t=_tm_get(hash_)
    if not t: return jsonify({"error":"Not found"}),404
    ad_id=t.get("ad_id")
    if not ad_id: return jsonify({"hash":hash_,"state":t.get("state","queued"),
        "progress":0,"is_stub":bool(t.get("is_stub"))})
    resp=_ad_get(key,AD_STATUS,params={"id[]":ad_id})
    mags=resp.get("data",{}).get("magnets",[])
    m=mags[0] if mags else {}
    return jsonify({"hash":hash_,"state":t.get("state"),"ad_state":m.get("status",""),
        "progress":m.get("downloaded",0),"is_stub":bool(t.get("is_stub"))})

# ── Cache check (magnet section UI) ──────────────────────────────────────────

@app.route("/api/cache-check",methods=["POST"])
def cache_check():
    d=request.json or {}
    key=d.get("api_key","").strip() or get_ad_api_key()
    hash_=d.get("hash","").strip().lower()
    name=d.get("name","").strip()
    if not key: return jsonify({"error":"API key required"}),400
    if not hash_: return jsonify({"error":"hash required"}),400
    res=check_cache_ad(key,[{"info_hash":hash_,"name":name}])
    return jsonify({"hash":hash_,"cached":bool(res.get(hash_,False)),"name":name})

# ── Config ────────────────────────────────────────────────────────────────────

@app.route("/api/config")
def get_config():
    return jsonify({"has_ad_key":bool(get_ad_api_key()),
        "has_prowlarr_env":bool(PROWLARR_URL or PROWLARR_KEY),
        "stub_after_days":STUB_AFTER_DAYS,"ad_rate_limit":_AD_RATE_LIMIT,
        "library_imported":bool(_load_config().get("library_imported")),
        "torznab_apikey":TORZNAB_APIKEY})

@app.route("/api/config/stub-days",methods=["POST"])
def set_stub_days():
    global STUB_AFTER_DAYS, STUB_AFTER_SECS
    d=request.json or {}
    days=int(d.get("stub_after_days",0))
    if days < 1: return jsonify({"error":"stub_after_days must be >= 1"}),400
    STUB_AFTER_DAYS = days
    STUB_AFTER_SECS = days * 86400
    cfg=_load_config(); cfg["stub_after_days"]=days; _save_config(cfg)
    _log(f"[stub] TTL updated to {days}d")
    return jsonify({"ok":True,"stub_after_days":days})

@app.route("/api/config/ad_key",methods=["POST"])
def save_ad_key_route():
    d=request.json or {}; key=d.get("api_key","").strip()
    if not key: return jsonify({"error":"api_key required"}),400
    r=_ad_get(key,AD_USER)
    if r.get("status")!="success":
        return jsonify({"error":r.get("error",{}).get("message","Auth failed")}),401
    save_ad_api_key(key)
    return jsonify({"ok":True})

@app.route("/api/account",methods=["POST"])
def account():
    d=request.json or {}; key=d.get("api_key","").strip() or get_ad_api_key()
    if not key: return jsonify({"error":"API key required"}),400
    r=_ad_get(key,AD_USER)
    if r.get("status")!="success":
        return jsonify({"error":r.get("error",{}).get("message","Auth failed")}),401
    u=r.get("data",{}).get("user",{})
    return jsonify({"username":u.get("username"),"is_premium":u.get("isPremium",False),
        "premium_until":u.get("premiumUntil"),"is_trial":u.get("isTrial",False)})

# ── Prowlarr config ───────────────────────────────────────────────────────────

@app.route("/api/prowlarr/config",methods=["GET"])
def prowlarr_get():
    cfg=get_prowlarr_config()
    return jsonify({"url":cfg.get("url",""),"api_key":cfg.get("api_key",""),
        "configured":bool(cfg.get("url") and cfg.get("api_key")),"from_env":cfg.get("from_env",False)})

@app.route("/api/prowlarr/config",methods=["POST"])
def prowlarr_save():
    d=request.json or {}; url=d.get("url","").strip(); key=d.get("api_key","").strip()
    if not url or not key: return jsonify({"error":"url and api_key required"}),400
    try:
        r=requests.get(f"{url.rstrip('/')}/api/v1/indexer",headers={"X-Api-Key":key},timeout=10)
        r.raise_for_status(); indexers=r.json()
    except requests.RequestException as e:
        return jsonify({"error":f"Cannot connect to Prowlarr: {e}"}),400
    save_prowlarr_config(url,key)
    t2=[i for i in indexers if i.get("protocol")=="torrent"]
    return jsonify({"ok":True,"indexer_count":len(t2),"indexers":[{"id":i["id"],"name":i["name"]} for i in t2]})

@app.route("/api/prowlarr/config",methods=["DELETE"])
def prowlarr_delete():
    cfg=_load_config(); cfg.pop("prowlarr",None); _save_config(cfg)
    return jsonify({"ok":True})

@app.route("/api/prowlarr/indexers",methods=["GET"])
def prowlarr_indexers():
    cfg=get_prowlarr_config()
    if not cfg.get("url") or not cfg.get("api_key"): return jsonify({"indexers":[]})
    try:
        r=requests.get(f"{cfg['url'].rstrip('/')}/api/v1/indexer",
            headers={"X-Api-Key":cfg["api_key"]},timeout=10)
        r.raise_for_status()
        t=[{"id":i["id"],"name":i["name"],"enabled":i.get("enable",True)}
           for i in r.json() if i.get("protocol")=="torrent"]
        return jsonify({"indexers":t})
    except Exception as e:
        return jsonify({"indexers":[],"error":str(e)})

# ── Torznab cached-only ───────────────────────────────────────────────────────

@app.route("/api/torznab/cached-only",methods=["GET"])
def cached_only_get():
    return jsonify({"cached_only":_load_config().get("torznab_cached_only",False)})

@app.route("/api/torznab/cached-only",methods=["POST"])
def cached_only_set():
    d=request.json or {}; val=bool(d.get("cached_only",True))
    cfg=_load_config(); cfg["torznab_cached_only"]=val; _save_config(cfg)
    return jsonify({"ok":True,"cached_only":val})

# ── Stubs ─────────────────────────────────────────────────────────────────────

@app.route("/api/stubs/list")
def stubs_list():
    s=[t for t in _tm_all() if t.get("is_stub")]
    return jsonify({"stubs":s,"count":len(s)})

@app.route("/api/stubs/restore",methods=["POST"])
def stubs_restore():
    d=request.json or {}; hash_=d.get("hash","").strip().lower()
    if not hash_: return jsonify({"error":"hash required"}),400
    t=_tm_get(hash_)
    if not t: return jsonify({"error":"Not found"}),404
    if not t.get("is_stub"): return jsonify({"ok":True,"message":"Not a stub"})
    _pool.submit(_tm_readd,hash_,t.get("name") or hash_)
    return jsonify({"ok":True,"message":f"Re-adding {t.get('name') or hash_}"})

@app.route("/api/stubs/run-pass",methods=["POST"])
def stubs_run_pass():
    try: _do_stub_pass(); return jsonify({"ok":True})
    except Exception as e: return jsonify({"ok":False,"error":str(e)}),500

# ── Backup / restore ──────────────────────────────────────────────────────────

@app.route("/api/backup",methods=["GET"])
def backup():
    transfers=_tm_all()
    cached=[{"hash":t["hash"],"name":t.get("name") or t["hash"],"ad_id":t.get("ad_id"),
        "is_stub":bool(t.get("is_stub")),"last_played":t.get("last_played"),
        "added_at":t.get("added_at") or 0,"category":t.get("category") or "",
        "kind":t.get("kind") or ""}
        for t in transfers if t.get("state") in ("cached","complete")]
    cfg=dict(_load_config()); key=get_ad_api_key()
    if key and not cfg.get("ad_api_key"): cfg["ad_api_key"]=key
    ts=int(time.time())
    return Response(json.dumps({"version":1,"config":cfg,"transfers":cached},indent=2),
        mimetype="application/json",
        headers={"Content-Disposition":f'attachment; filename="alldebrid-backup-{ts}.json"'})

@app.route("/api/restore",methods=["POST"])
def restore():
    """Restore transfers from a backup JSON file.

    stub_mode=true (form field): write every entry as is_stub=1 instantly —
    no AllDebrid upload, no cache check. Imports 2000 items in seconds.
    Files re-add themselves to AllDebrid automatically on first play.
    Use the "Import Complete" button afterwards (once, after the whole
    library has been restored) to unlock every file and scan Plex.

    Default (stub_mode=false): upload each hash to AllDebrid to verify it is
    cached before keeping it.
    """
    global _cfg_cache
    if "file" not in request.files:
        return jsonify({"error":"No file uploaded"}),400
    stub_mode = request.form.get("stub_mode","").lower() in ("1","true","yes")
    try:
        data=json.load(request.files["file"])
    except Exception as e:
        return jsonify({"error":f"Invalid JSON: {e}"}),400

    if isinstance(data,dict):
        rc=data.get("config")
        if isinstance(rc,dict) and rc:
            merged={**_load_config(),**rc}; _save_config(merged); _cfg_cache=merged
        data=data.get("transfers",[])

    if not isinstance(data,list):
        return jsonify({"error":"Expected list or backup object"}),400

    entries=[]
    for item in data:
        if not isinstance(item,dict): continue
        h=((item.get("hash") or item.get("info_hash") or item.get("infoHash") or "")
           .strip().lower())
        if not re.fullmatch(r'[0-9a-f]{40}',h): continue
        entries.append({
            "hash":        h,
            "name":        item.get("name") or item.get("title") or h,
            "ad_id":       item.get("ad_id"),
            "is_stub":     bool(item.get("is_stub")),
            "last_played": item.get("last_played"),
            "added_at":    float(item.get("added_at") or time.time()),
            "category":    item.get("category") or "",
            "kind":        item.get("kind") or "",
        })

    total=len(entries)
    api_key=get_ad_api_key()

    def generate():
        imported=skipped=not_cached=errors=0
        for i,item in enumerate(entries,1):
            h=item["hash"]; name=item["name"]
            if _tm and _tm.is_user_deleted(h):
                skipped+=1
                yield json.dumps({"type":"progress","current":i,"total":total,
                                   "name":name,"status":"skipped"})+"\n"
                continue
            if _tm_get(h):
                skipped+=1
                yield json.dumps({"type":"progress","current":i,"total":total,
                                   "name":name,"status":"skipped"})+"\n"
                continue

            # ── Stub mode: write everything as a stub instantly ────────────
            if stub_mode:
                try:
                    _tm_set(h,
                        name=name, ad_id=None, state="cached",
                        added_at=item["added_at"], last_played=item["last_played"],
                        is_stub=1, category=item["category"], kind=item["kind"],
                    )
                    imported+=1
                    yield json.dumps({"type":"progress","current":i,"total":total,
                                       "name":name,"status":"imported"})+"\n"
                except Exception as e:
                    app.logger.warning(f"Restore stub {h}: {e}")
                    errors+=1
                    yield json.dumps({"type":"progress","current":i,"total":total,
                                       "name":name,"status":"error"})+"\n"
                continue

            # Existing stubs from backup stay as stubs
            if item["is_stub"]:
                try:
                    _tm_set(h,
                        name=name, ad_id=item["ad_id"], state="cached",
                        added_at=item["added_at"], last_played=item["last_played"],
                        is_stub=1, category=item["category"], kind=item["kind"],
                    )
                    imported+=1
                    yield json.dumps({"type":"progress","current":i,"total":total,
                                       "name":name,"status":"imported"})+"\n"
                except Exception as e:
                    app.logger.warning(f"Restore {h}: {e}")
                    errors+=1
                    yield json.dumps({"type":"progress","current":i,"total":total,
                                       "name":name,"status":"error"})+"\n"
                continue

            if not api_key:
                errors+=1
                yield json.dumps({"type":"progress","current":i,"total":total,
                                   "name":name,"status":"error"})+"\n"
                continue

            try:
                mag=f"magnet:?xt=urn:btih:{h}&dn={urllib.parse.quote(name,safe='')}"
                res=_ad_upload_batch(api_key,[mag])
                if res.get("status")=="error":
                    err=res.get("error",{})
                    app.logger.warning(f"[restore] {h[:8]}: {err.get('code')} {err.get('message')}")
                    errors+=1
                    yield json.dumps({"type":"progress","current":i,"total":total,
                                       "name":name,"status":"error"})+"\n"
                    continue
                mags=res.get("data",{}).get("magnets",[])
                m=mags[0] if mags else {}
                ad_id=m.get("id")
                if not mags or m.get("error"):
                    err=m.get("error",{}) if m else {}
                    app.logger.warning(f"[restore] {h[:8]} upload failed: {err.get('code','UNKNOWN')} {err.get('message','')}")
                    errors+=1
                    yield json.dumps({"type":"progress","current":i,"total":total,
                                       "name":name,"status":"error"})+"\n"
                    continue
                if not m.get("ready"):
                    if ad_id:
                        try: _pool.submit(_ad_delete,api_key,ad_id)
                        except Exception: _ad_delete(api_key,ad_id)
                    not_cached+=1
                    yield json.dumps({"type":"progress","current":i,"total":total,
                                       "name":name,"status":"not_cached"})+"\n"
                    continue
                _tm_set(h,
                    name=name, ad_id=ad_id, state="cached",
                    added_at=item["added_at"], last_played=item["last_played"],
                    is_stub=0, category=item["category"], kind=item["kind"],
                )
                try:
                    _tm._on_ready(h)
                except Exception as e:
                    app.logger.debug(f"[restore] _on_ready {h[:8]}: {e}")
                imported+=1
                yield json.dumps({"type":"progress","current":i,"total":total,
                                   "name":name,"status":"imported"})+"\n"
            except Exception as e:
                app.logger.warning(f"Restore {h}: {e}")
                errors+=1
                yield json.dumps({"type":"progress","current":i,"total":total,
                                   "name":name,"status":"error"})+"\n"

        try:
            import fuse_mount as _fm
            if _fm._pfs: _fm._pfs._invalidate_name_map()
        except Exception: pass

        yield json.dumps({"type":"done","imported":imported,"skipped":skipped,
                           "not_cached":not_cached,"errors":errors,"total":total,
                           "stub_mode":stub_mode})+"\n"
        # Full import only: auto bulk-scan in background
        if imported > 0 and not stub_mode:
            def _bulk():
                try:
                    from transfer_manager import _plex as _plx
                    result = _plx.bulk_scan(transfer_manager=_tm)
                    _log(f"[restore] bulk-scan done: {result}")
                except Exception as e:
                    _log(f"[restore] bulk-scan failed: {e}")
            _pool.submit(_bulk)

    return app.response_class(
        stream_with_context(generate()),
        mimetype="application/x-ndjson",
        headers={"X-Accel-Buffering":"no","Cache-Control":"no-cache"},
    )

# ── Rate status / debug ───────────────────────────────────────────────────────

@app.route("/api/rate-status")
def rate_status():
    now=time.monotonic(); cutoff=now-_AD_RATE_WINDOW
    with _ad_rate_lock: used=sum(1 for ts in _ad_timestamps if ts>cutoff)
    return jsonify({"limit_per_minute":_AD_RATE_LIMIT,"used_last_minute":used,
        "remaining":max(0,_AD_RATE_LIMIT-used),"window_seconds":int(_AD_RATE_WINDOW)})

# ── Classification overrides ──────────────────────────────────────────────────

@app.route("/api/overrides",methods=["GET"])
def overrides_get():
    return jsonify(_load_config().get("classification_overrides",{}))

@app.route("/api/overrides",methods=["POST"])
def overrides_set():
    d=request.get_json(force=True) or {}
    name=(d.get("name") or "").strip(); kind=d.get("kind","")
    if not name: return jsonify({"error":"name required"}),400
    from name_match import override_key_for
    cfg=_load_config(); ov=cfg.setdefault("classification_overrides",{})
    if kind in ("movie","series"):
        # Key on the show title (for series) or title+year (for movie) so
        # this override matches future episodes of the same show / future
        # re-adds of the same movie, not just this one exact transfer name.
        key = override_key_for(name, kind)
        ov[key]={"kind":kind,"label":name}
    else:
        # Removing — the override could be stored under either key shape
        # (or the old literal-name key, for overrides set before this fix)
        # depending on when/how it was originally set. Clear all of them.
        for k in {override_key_for(name,"series"), override_key_for(name,"movie"),
                  re.sub(r"[^a-z0-9]","",name.lower())}:
            ov.pop(k, None)
        key = override_key_for(name, "series")  # for the response only
    _save_config(cfg)
    # Push into live FUSE module
    try:
        import fuse_mount as _fm
        _fm._overrides=ov
        if _fm._pfs: _fm._pfs._invalidate_name_map()
    except Exception: pass
    return jsonify({"ok":True,"key":key,"kind":kind})

@app.route("/api/transfers/setkind",methods=["POST"])
def transfers_setkind():
    d=request.get_json(force=True) or {}
    hash_=(d.get("hash") or "").strip().lower()
    kind=(d.get("kind") or "").strip().lower()
    if not hash_ or kind not in ("movie","series"):
        return jsonify({"error":"hash and kind required"}),400
    _tm_set(hash_,kind=kind)
    try:
        import fuse_mount as _fm
        if _fm._pfs: _fm._pfs._invalidate_name_map()
    except Exception: pass
    return jsonify({"ok":True,"hash":hash_,"kind":kind})

@app.route("/api/transfers/classify",methods=["POST"])
def transfers_classify():
    if _tm is None: return jsonify({"ok":True,"updated":0,"skipped":0,"no_files":0})
    try: from name_match import classify_from_files
    except ImportError: return jsonify({"ok":False,"error":"name_match not available"}),500
    updated=skipped=no_files=0
    for t in _tm.all_transfers():
        if t.get("state") not in ("cached","complete"): continue
        if t.get("kind"): skipped+=1; continue
        rows=_tm._db_get_files(t["hash"])
        if not rows: no_files+=1; continue
        kind=classify_from_files([dict(r) for r in rows])
        if kind: _tm._set(t["hash"],kind=kind); updated+=1
        else: no_files+=1
    try:
        import fuse_mount as _fm
        if _fm._pfs: _fm._pfs._invalidate_name_map()
    except Exception: pass
    return jsonify({"ok":True,"updated":updated,"skipped":skipped,"no_files":no_files})

# ── FUSE settings ─────────────────────────────────────────────────────────────
def _dir_size_bytes(path: str) -> int:
    """Sum the size of all files under `path` (the FUSE block cache).

    Deliberately NOT shutil.disk_usage(path) — that reports used/free space
    for the whole filesystem/volume `path` lives on, not the size of the
    cache directory's own contents, so it stays huge even when the cache is
    empty (e.g. a docker host with other data on the same volume).
    """
    total = 0
    try:
        for entry in os.scandir(path):
            try:
                if entry.is_file(follow_symlinks=False):
                    total += entry.stat(follow_symlinks=False).st_size
                elif entry.is_dir(follow_symlinks=False):
                    total += _dir_size_bytes(entry.path)
            except OSError:
                continue
    except OSError:
        pass
    return total

_FUSE_DEFAULTS={
    "cache_dir":"/docker/alldebrid-web/cache","disk_cache_size":"30GB",
    "buffer_memory":"512MB","cache_expiry":"24h","cache_cleanup":"20m",
    "chunk_size":"8MB","read_ahead":"500MB","daemon_timeout":"10s",
    "uid":None,"gid":None,"umask":"022","prefetch":True,"video_only":True,
    "enable_4k_folders":False,"live_chunk_size":"8 MB","live_buffer_mb":0,
    "live_disk_used":"0 B","live_prefetch":True,"cached_blocks":0,
}

@app.route("/api/fuse/settings",methods=["GET"])
def fuse_settings_get():
    saved=_load_config().get("fuse",{}); result={**_FUSE_DEFAULTS,**saved}
    try:
        import fuse_mount as _fm
        live=_fm.get_current_settings()
        # Live values reflect what's ACTUALLY active right now, which is
        # what the UI's stats bar and field defaults should show — the
        # saved config can differ from live state right after a failed
        # apply, a fresh container with stale saved settings, etc.
        result["live_chunk_size"]=live["chunk_size"]
        result["live_prefetch"]=live["prefetch"]
        result["cached_blocks"]=live["cached_blocks"]
        result["live_buffer_mb"]=(live["max_blocks"]*_fm.BLOCK_SIZE)//1024//1024
        cd=saved.get("cache_dir",live["cache_dir"])
        if cd and os.path.isdir(cd):
            result["live_disk_used"]=f"{_dir_size_bytes(cd)//(1024*1024)} MB"
    except Exception as e:
        app.logger.debug(f"[fuse-settings] live snapshot failed: {e}")
    return jsonify(result)

@app.route("/api/fuse/settings",methods=["POST"])
def fuse_settings_save():
    data=request.get_json(force=True) or {}
    cfg=_load_config(); old=cfg.get("fuse",{}); cfg["fuse"]=data; _save_config(cfg)
    remounted=False
    try:
        import fuse_mount as _fm
        _fm._4K_FOLDERS_ENABLED=bool(data.get("enable_4k_folders",False))
        _fm._overrides=cfg.get("classification_overrides",{})

        # uid/gid/umask/cache_dir can only take effect at FUSE() construction
        # time — check against what's actually mounted right now (not just
        # the previously-saved config, in case they drifted) and remount if
        # any of them actually changed.
        needs_remount=_fm.settings_need_remount(data)
        if needs_remount:
            _fm.apply_mount_options(data)

        # Everything else applies live, in-process, immediately.
        _fm.apply_runtime_settings(data)

        if _fm._pfs: _fm._pfs._invalidate_name_map()

        if needs_remount:
            remounted=_remount_fuse()
    except Exception as e:
        app.logger.warning(f"[fuse-settings] apply failed: {e}")
    return jsonify({"ok":True,"remounted":remounted})

@app.route("/api/fuse/4k-enabled",methods=["GET"])
def fuse_4k_enabled():
    return jsonify({"enabled":bool(_load_config().get("fuse",{}).get("enable_4k_folders",False))})

@app.route("/api/fuse/cache/clear",methods=["POST"])
def fuse_cache_clear():
    cd=_load_config().get("fuse",{}).get("cache_dir",
        os.environ.get("FUSE_CACHE_DIR","/docker/alldebrid-web/cache"))
    cleared=0
    errors=[]
    if cd and os.path.isdir(cd):
        for e in os.scandir(cd):
            try:
                shutil.rmtree(e.path) if e.is_dir() else os.remove(e.path)
                cleared+=1
            except OSError as ex:
                errors.append(f"{os.path.basename(e.path)}: {ex.strerror or ex}")
    elif cd:
        errors.append(f"cache directory not found: {cd}")
    try:
        import fuse_mount as _fm
        _fm._block_cache._store.clear()
        if _fm._pfs: _fm._pfs._stat_invalidate_all()
    except Exception as ex:
        errors.append(f"in-memory cache clear failed: {ex}")
    return jsonify({"ok":len(errors)==0,"cleared":cleared,"errors":errors})

# ── Plex ──────────────────────────────────────────────────────────────────────
_PLEX_DEFAULTS={"url":"","token":"","movies_section":"1","tv_section":"2","debounce_seconds":30,
    "mount_path":"/docker/alldebrid-web/mnt","movie_root":"/docker/alldebrid-web/mnt/movies",
    "tv_root":"/docker/alldebrid-web/mnt/series","movie4k_root":"/docker/alldebrid-web/mnt/movies4k",
    "tv4k_root":"/docker/alldebrid-web/mnt/series4k","scan_exact_item":True,
    "auto_scan_enabled":False,"partial_scan":False,"fallback_full_scan":False,
    "scan_on_unlock":False,"partial_scan_enabled":False,"partial_scan_time":"03:00",
    "scan_interval_minutes":0}

@app.route("/api/plex/config",methods=["GET"])
def plex_config_get():
    return jsonify({**_PLEX_DEFAULTS,**_load_config().get("plex",{})})

@app.route("/api/plex/config",methods=["POST"])
def plex_config_save():
    data=request.get_json(force=True) or {}
    cfg=_load_config(); cfg["plex"]=data; _save_config(cfg)
    return jsonify({"ok":True})

@app.route("/api/plex/test",methods=["POST"])
def plex_test():
    d=request.get_json(force=True) or {}
    url=(d.get("url") or "").strip().rstrip("/"); tok=(d.get("token") or "").strip()
    if not url or not tok: return jsonify({"error":"url and token required"}),400
    try:
        r=requests.get(f"{url}/library/sections",
            headers={"X-Plex-Token":tok,"Accept":"application/json"},timeout=8)
        if r.status_code==401: return jsonify({"error":"Invalid token"}),401
        r.raise_for_status()
        secs=[{"key":s.get("key"),"title":s.get("title"),"type":s.get("type")}
              for s in r.json().get("MediaContainer",{}).get("Directory",[])]
        return jsonify({"ok":True,"sections":secs})
    except requests.RequestException as e:
        return jsonify({"error":str(e)}),502

def _plex_scan_sections():
    cfg=_load_config().get("plex",{})
    url=cfg.get("url","").rstrip("/"); tok=cfg.get("token","")
    if not url or not tok: return jsonify({"error":"Plex not configured"}),400
    secs=[cfg.get("movies_section","1"),cfg.get("tv_section","2")]
    triggered,errors=[],[]
    for s in secs:
        try:
            r=requests.get(f"{url}/library/sections/{s}/refresh?X-Plex-Token={tok}",timeout=8)
            (triggered if r.status_code in (200,204) else errors).append(s)
        except requests.RequestException as e: errors.append(f"{s}: {e}")
    return jsonify({"ok":not errors,"triggered":triggered,"errors":errors})

@app.route("/api/plex/scan",methods=["POST"])
def plex_scan(): return _plex_scan_sections()

@app.route("/api/plex/partial-scan",methods=["POST"])
def plex_partial_scan():
    """Targeted scan: only refresh the specific folders Plex hasn't seen yet,
    instead of a full-section refresh. Much faster than "Full Scan Now" once
    most of the library is already in Plex — only new folders get scanned,
    and those per-folder refreshes fire in parallel (PLEX_SCAN_WORKERS).
    """
    if _tm is None: return jsonify({"ok":True,"triggered":[],"errors":["TM not initialised"]})
    try:
        from transfer_manager import _plex as _plx
        result = _plx.scan_missing_from_plex()
        if "error" in result:
            return jsonify({"ok":False,"triggered":[],"errors":[result["error"]]})
        scanned = result.get("scanned",{})
        n_movies = len(scanned.get("movies",[]))
        n_series = len(scanned.get("series",[]))
        triggered = []
        if n_movies: triggered.append(f"{n_movies} movie folder(s)")
        if n_series: triggered.append(f"{n_series} series folder(s)")
        if not triggered: triggered.append("nothing new — library already up to date")
        return jsonify({"ok":True,"triggered":triggered,"errors":[],
            "scanned":scanned,"missing":result.get("missing",{})})
    except Exception as e:
        return jsonify({"ok":False,"triggered":[],"errors":[str(e)]})

@app.route("/api/plex/patch-library",methods=["POST"])
def plex_patch_library():
    """Patch existing library: reset to stubs → Plex scan → wait → unlock all.

    Use this when Plex imported items with wrong metadata (stub duration showing
    as 11 minutes, wrong resolution, etc). The sequence forces Plex to re-scan
    all FUSE files while they temporarily report real size, so Plex picks up
    the correct duration/codec/size — zero CDN cost (no bytes streamed).

    Steps:
      1. Reset all files to locked (stub-size) state — FUSE reports stub bytes
      2. Trigger full Plex section refresh
      3. Wait scan_delay seconds (default 120) for Plex to walk all directories
      4. Unlock all files — FUSE now reports real size; Plex refreshes metadata
    """
    import threading as _thr
    if _tm is None:
        return jsonify({"ok":False,"error":"TransferManager not initialised"}),503
    data       = request.get_json(silent=True) or {}
    scan_delay = int(data.get("scan_delay", 120))

    def _do_patch():
        try:
            # Step 1: reset every file to stub state
            with _tm._lock:
                _tm._db().execute("UPDATE files     SET cdn_unlocked=0, cdn_played=0")
                _tm._db().execute("UPDATE transfers SET cdn_unlocked=0")
                _tm._db().commit()
            from transfer_manager import _unlocked_hashes
            _unlocked_hashes.clear()
            try:
                import fuse_mount as _fm
                if _fm._pfs: _fm._pfs._stat_invalidate_all()
            except Exception: pass
            _log("[patch-library] Step 1: reset all files to stub state")

            # Step 2: trigger Plex section scan
            try:
                cfg   = _load_config().get("plex", {})
                url   = cfg.get("url","").rstrip("/")
                token = cfg.get("token","")
                if url and token:
                    for sec in [cfg.get("movies_section","1"), cfg.get("tv_section","2")]:
                        requests.get(f"{url}/library/sections/{sec}/refresh",
                                     params={"X-Plex-Token": token}, timeout=10)
                    _log(f"[patch-library] Step 2: Plex scan triggered, waiting {scan_delay}s")
                else:
                    _log("[patch-library] Step 2: Plex not configured — skipping scan")
            except Exception as e:
                _log(f"[patch-library] Step 2 scan error: {e}")

            # Step 3: wait for Plex to finish scanning
            import time as _t; _t.sleep(scan_delay)

            # Step 4: unlock everything and invalidate stat cache
            with _tm._lock:
                _tm._db().execute(
                    "UPDATE files SET cdn_unlocked=1 WHERE hash IN "
                    "(SELECT hash FROM transfers WHERE state IN ('cached','complete'))"
                )
                _tm._db().execute(
                    "UPDATE transfers SET cdn_unlocked=1 WHERE state IN ('cached','complete')"
                )
                _tm._db().commit()
            # Restore in-memory set
            rows = _tm._db().execute(
                "SELECT hash FROM transfers WHERE cdn_unlocked=1"
            ).fetchall()
            from transfer_manager import _unlocked_hashes as _uh
            for r in rows: _uh.add(r[0])
            try:
                import fuse_mount as _fm
                if _fm._pfs:
                    _fm._pfs._stat_invalidate_all()
                    _fm._pfs._invalidate_name_map()
            except Exception: pass
            _log("[patch-library] Step 4: all files unlocked — patch complete")
        except Exception as e:
            _log(f"[patch-library] error: {e}")

    _thr.Thread(target=_do_patch, daemon=True).start()
    return jsonify({"ok":True,
        "message":f"Patching library — resetting stubs, scanning Plex, unlocking in {scan_delay}s. Check logs for progress."})

def _unlock_all_cached_transfers() -> int:
    """Unlock every cached/complete non-stub transfer immediately.

    Sets cdn_unlocked=1 on both the transfers and files tables so FUSE
    serves real CDN URLs and Plex sees actual file sizes straight away.
    Returns the number of transfers updated.
    """
    with _tm._lock:
        cur = _tm._db().execute(
            "UPDATE transfers SET cdn_unlocked=1 "
            "WHERE state IN ('cached','complete') AND is_stub=0"
        )
        transfers_updated = cur.rowcount
        _tm._db().execute(
            "UPDATE files SET cdn_unlocked=1 WHERE hash IN ("
            "  SELECT hash FROM transfers "
            "  WHERE state IN ('cached','complete') AND is_stub=0"
            ")"
        )
        _tm._db().commit()
    from transfer_manager import _unlocked_hashes
    rows = _tm._db().execute(
        "SELECT hash FROM transfers WHERE cdn_unlocked=1"
    ).fetchall()
    for r in rows:
        _unlocked_hashes.add(r[0])
    try:
        import fuse_mount as _fm
        if _fm._pfs:
            _fm._pfs._stat_invalidate_all()
            _fm._pfs._invalidate_name_map()
    except Exception:
        pass
    _log(f"[unlock-all] {transfers_updated} transfer(s) unlocked")
    return transfers_updated

def _relock_all_cached_transfers() -> int:
    """Relock every cached/complete non-stub transfer — the inverse of
    _unlock_all_cached_transfers(). Sets cdn_unlocked=0 on both transfers
    and files so FUSE goes back to serving stub bytes/sizes instead of real
    CDN content.

    Mirrors every step the unlock path touches, in reverse:
      - DB columns on both transfers and files
      - the in-memory _unlocked_hashes set (is_cdn_unlocked() checks this
        FIRST and trusts it over the DB, so leaving stale entries here would
        make relocked files still report as unlocked)
      - the FUSE stat cache, so the next getattr() re-reads the DB and
        reports the stub size again instead of a cached real size

    Returns the number of transfers updated.
    """
    with _tm._lock:
        cur = _tm._db().execute(
            "UPDATE transfers SET cdn_unlocked=0 "
            "WHERE state IN ('cached','complete') AND is_stub=0"
        )
        transfers_updated = cur.rowcount
        _tm._db().execute(
            "UPDATE files SET cdn_unlocked=0 WHERE hash IN ("
            "  SELECT hash FROM transfers "
            "  WHERE state IN ('cached','complete') AND is_stub=0"
            ")"
        )
        _tm._db().commit()
    from transfer_manager import _unlocked_hashes
    rows = _tm._db().execute(
        "SELECT hash FROM transfers WHERE state IN ('cached','complete') AND is_stub=0"
    ).fetchall()
    for r in rows:
        _unlocked_hashes.discard(r[0])
    try:
        import fuse_mount as _fm
        if _fm._pfs:
            _fm._pfs._stat_invalidate_all()
            _fm._pfs._invalidate_name_map()
    except Exception:
        pass
    _log(f"[relock-all] {transfers_updated} transfer(s) relocked")
    return transfers_updated

@app.route("/api/library/unlock-all", methods=["POST"])
def library_unlock_all():
    """Single switch to unlock or relock the whole library.

    POST body: {"action": "unlock"} (default if omitted) or {"action": "lock"}.
      - "unlock": every cached/complete file streams real CDN bytes.
      - "lock":   every cached/complete file goes back to serving its stub —
                  use this to undo a bulk unlock (e.g. testing, or to shrink
                  Plex metadata back down before re-importing).
    Returns {"ok": true, "action": "...", "count": N}.
    """
    if _tm is None: return jsonify({"error":"Transfer manager unavailable"}),500
    data = request.get_json(silent=True) or {}
    action = str(data.get("action", "unlock")).strip().lower()
    if action not in ("unlock", "lock"):
        return jsonify({"error":"action must be 'unlock' or 'lock'"}),400
    try:
        if action == "unlock":
            n = _unlock_all_cached_transfers()
        else:
            n = _relock_all_cached_transfers()
        return jsonify({"ok": True, "action": action, "count": n})
    except Exception as e:
        return jsonify({"error": str(e)}),500

@app.route("/api/plex/unlock-all",methods=["POST"])
def plex_unlock_all():
    """Unlock every cached/complete non-stub transfer immediately, regardless
    of whether Plex has scanned it yet.

    This is the "Unlock All Files" button — it must NOT be gated on Plex
    having already seen the file (that's unlock_scanned_by_plex's job, used
    by the separate "Unlock Scanned by Plex" button).
    """
    if _tm is None: return jsonify({"ok":True,"unlocked":0,"message":"TM not initialised"})
    try:
        u = _unlock_all_cached_transfers()
        return jsonify({"ok":True,"unlocked":u,
            "message":f"{u} transfer(s) unlocked — streaming from AllDebrid CDN"})
    except Exception as e:
        return jsonify({"ok":False,"error":str(e)}),500

@app.route("/api/plex/unlock-scanned",methods=["POST"])
def plex_unlock_scanned():
    if _tm is None: return jsonify({"ok":True,"unlocked":0})
    try:
        from transfer_manager import _plex as _plx
        r=_plx.unlock_scanned_by_plex()
        return jsonify({"ok":True,"unlocked":r.get("unlocked",0)})
    except Exception as e:
        return jsonify({"ok":False,"error":str(e)}),500

@app.route("/api/unlock-all",methods=["POST"])
def unlock_all_transfers():
    """Unlock every cached/complete non-stub transfer immediately. Same
    underlying operation as /api/plex/unlock-all — kept as a separate route
    for callers that want the plain {"unlocked": N} shape without "message".
    """
    if _tm is None: return jsonify({"error":"Transfer manager unavailable"}),500
    try:
        u = _unlock_all_cached_transfers()
        return jsonify({"ok":True,"unlocked":u})
    except Exception as e:
        return jsonify({"error":str(e)}),500

# ── Downloads ─────────────────────────────────────────────────────────────────

@app.route("/api/downloads/clear",methods=["POST"])
def downloads_clear():
    root=os.environ.get("DOWNLOADS_ROOT","/docker/alldebrid-web/downloads")
    removed=0
    if os.path.isdir(root):
        for cat in os.scandir(root):
            if not cat.is_dir(): continue
            for e in os.scandir(cat.path):
                if e.is_dir():
                    try: shutil.rmtree(e.path); removed+=1
                    except Exception: pass
    return jsonify({"ok":True,"removed":removed,"message":f"Removed {removed} folder(s)."})

@app.route("/api/downloads/clear-config",methods=["GET"])
def dl_clear_cfg_get():
    return jsonify({"interval_hours":_load_config().get("downloads_clear",{}).get("interval_hours",0)})

@app.route("/api/downloads/clear-config",methods=["POST"])
def dl_clear_cfg_save():
    d=request.get_json(force=True) or {}
    hours=max(0,int(d.get("interval_hours",0)))
    cfg=_load_config(); cfg["downloads_clear"]={"interval_hours":hours}; _save_config(cfg)
    return jsonify({"ok":True,"interval_hours":hours})

# ── Auto backup ───────────────────────────────────────────────────────────────
BACKUP_DIR=os.path.join(os.path.dirname(CONFIG_PATH),"backups")

@app.route("/api/backup-config",methods=["GET"])
def backup_cfg_get():
    c=_load_config().get("auto_backup",{})
    return jsonify({"interval_days":c.get("interval_days",0),
        "keep_count":c.get("keep_count",5),"last_backup":c.get("last_backup")})

@app.route("/api/backup-config",methods=["POST"])
def backup_cfg_save():
    d=request.get_json(force=True) or {}
    days=max(0,int(d.get("interval_days",0))); keep=max(1,int(d.get("keep_count",5)))
    cfg=_load_config(); cfg.setdefault("auto_backup",{}).update({"interval_days":days,"keep_count":keep})
    _save_config(cfg); return jsonify({"ok":True})

def _do_auto_backup():
    try:
        os.makedirs(BACKUP_DIR,exist_ok=True)
        transfers=_tm_all()
        cached=[{"hash":t["hash"],"name":t.get("name") or t["hash"],
            "added_at":t.get("added_at") or 0,"is_stub":bool(t.get("is_stub")),
            "last_played":t.get("last_played")}
            for t in transfers if t.get("state") in ("cached","complete")]
        ts=datetime.now().strftime("%Y-%m-%d_%H-%M")
        path=os.path.join(BACKUP_DIR,f"alldebrid-backup-{ts}.json")
        cfg=dict(_load_config()); key=get_ad_api_key()
        if key and not cfg.get("ad_api_key"): cfg["ad_api_key"]=key
        with open(path,"w") as f: json.dump({"version":1,"config":cfg,"transfers":cached},f,indent=2)
        keep=_load_config().get("auto_backup",{}).get("keep_count",5)
        all_b=sorted(os.path.join(BACKUP_DIR,fn) for fn in os.listdir(BACKUP_DIR)
            if fn.startswith("alldebrid-backup-") and fn.endswith(".json"))
        for old in all_b[:-keep]:
            try: os.remove(old)
            except OSError: pass
        cfg2=_load_config(); cfg2.setdefault("auto_backup",{})["last_backup"]=ts; _save_config(cfg2)
        return path
    except Exception as e:
        _log(f"[auto-backup] failed: {e}"); return None

@app.route("/api/backup-config/run",methods=["POST"])
def backup_run():
    path=_do_auto_backup()
    return jsonify({"ok":bool(path),"path":path or ""})

# ── Config export / import ────────────────────────────────────────────────────

@app.route("/api/config/export",methods=["GET"])
def config_export():
    cfg=dict(_load_config()); key=get_ad_api_key()
    if key and not cfg.get("ad_api_key"): cfg["ad_api_key"]=key
    ts=datetime.now().strftime("%Y-%m-%d_%H-%M")
    return Response(json.dumps(cfg,indent=2),mimetype="application/json",
        headers={"Content-Disposition":f'attachment; filename="alldebrid-config-{ts}.json"'})

@app.route("/api/config/import",methods=["POST"])
def config_import():
    global _cfg_cache
    if "file" not in request.files: return jsonify({"error":"No file uploaded"}),400
    try: uploaded=json.load(request.files["file"])
    except Exception as e: return jsonify({"error":f"Invalid JSON: {e}"}),400
    if not isinstance(uploaded,dict): return jsonify({"error":"Expected JSON object"}),400
    mode=request.args.get("mode","merge")
    new_cfg=uploaded if mode=="replace" else {**_load_config(),**uploaded}
    _save_config(new_cfg); _cfg_cache=new_cfg
    return jsonify({"ok":True,"mode":mode,"keys":list(new_cfg.keys())})

# ── Sync ──────────────────────────────────────────────────────────────────────

@app.route("/api/sync/config",methods=["GET"])
def sync_cfg_get():
    return jsonify({"instances":_load_config().get("sync",{}).get("instances",[])})

@app.route("/api/sync/config",methods=["POST"])
def sync_cfg_save():
    d=request.get_json(force=True) or {}; insts=d.get("instances",[])
    for i in insts: i["url"]=(i.get("url") or "").rstrip("/")
    cfg=_load_config(); cfg["sync"]={"instances":insts}; _save_config(cfg)
    return jsonify({"ok":True})

@app.route("/api/sync/run",methods=["POST"])
def sync_run():
    import re as _re
    d=request.get_json(force=True) or {}
    arr=d.get("arr","radarr"); mode=d.get("mode","partial")
    base_url=d.get("arr_url","").rstrip("/"); api_key=d.get("arr_key","")
    arr_name=d.get("arr_name",arr.title()); arr_root=d.get("arr_root","").strip().rstrip("/")
    STUBS=os.path.join(os.path.dirname(__file__),"stubs")
    def _hdrs(): return {"X-Api-Key":api_key,"Content-Type":"application/json"}
    def sse(log=None,pct=None,status=None,done=False,error=False):
        o={}
        if log    is not None: o["log"]=log
        if pct    is not None: o["pct"]=pct
        if status is not None: o["status"]=status
        if done: o["done"]=True; o["error"]=error
        return f"data: {json.dumps(o)}\n\n"
    def _res(name):
        n=name.upper()
        if "2160" in n or "4K" in n or "UHD" in n: return "2160p"
        if "1080" in n: return "1080p"
        if "720" in n: return "720p"
        return "1080p"
    def _sname(name): return _re.sub(r'[<>:"/\\|?*\x00-\x1f]','',(name or "unknown")).strip()
    def _write_stub(dest,fn):
        os.makedirs(dest,exist_ok=True); p=os.path.join(dest,fn)
        if os.path.exists(p): os.utime(p,None); return p
        res=_res(fn); src=os.path.join(STUBS,f"{res}.mkv")
        if not os.path.exists(src): src=os.path.join(STUBS,"1080p.mkv")
        if os.path.exists(src): shutil.copy2(src,p)
        else: open(p,"wb").close()
        try: os.chmod(p,0o666)
        except OSError: pass
        return p
    def generate():
        if not base_url or not api_key:
            yield sse(log="❌ Missing URL or API key.",done=True,error=True); return
        yield sse(log=f"Connecting to {arr_name}…",pct=2,status="Connecting…")
        try:
            ping=requests.get(f"{base_url}/api/v3/system/status",headers=_hdrs(),timeout=8)
            if ping.status_code not in (200,201):
                yield sse(log=f"❌ HTTP {ping.status_code}",done=True,error=True); return
            yield sse(log=f"Connected v{ping.json().get('version','?')}",pct=5)
        except Exception as e:
            yield sse(log=f"❌ {e}",done=True,error=True); return
        try:
            rf=requests.get(f"{base_url}/api/v3/rootFolder",headers=_hdrs(),timeout=8).json()
            root=(rf[0]["path"].rstrip("/") if rf else "/movies") if not arr_root else arr_root
        except Exception: root=arr_root or ("/tv" if arr=="sonarr" else "/movies")
        yield sse(log=f"Root: {root}",pct=8)
        transfers=_tm_all(); is_series=arr=="sonarr"
        streamable=[t for t in transfers if t.get("state") in ("cached","complete")]
        def _cls(t):
            nm=t.get("name") or ""
            s=bool(_re.search(r'\bS\d{1,2}(?:E\d{1,3})?\b|\bSeason\s*\d+\b|\bEpisode\s*\d+\b',nm,_re.I))
            return "sonarr" if s else "radarr"
        items=[t for t in streamable if _cls(t)==arr]
        if not items: yield sse(log=f"No {arr} items.",done=True); return
        yield sse(log=f"Found {len(items)} items",pct=14)
        added=skipped=errors=0; total=len(items)
        for i,t in enumerate(items):
            pct=14+int(82*(i+1)/max(total,1)); name=t.get("name") or t["hash"]
            yield sse(status=f"[{i+1}/{total}] {name[:48]}",pct=pct)
            try:
                safe=_sname(name); dest_dir=os.path.join(root,safe)
                fake_fn=f"{safe}.WEBRip-{_res(name)}.mkv"
                if mode=="partial" and os.path.exists(os.path.join(dest_dir,fake_fn)):
                    skipped+=1; continue
                stub_path=_write_stub(dest_dir,fake_fn)
                endpoint="series" if is_series else "movie"
                try:
                    lib=requests.get(f"{base_url}/api/v3/{endpoint}",headers=_hdrs(),timeout=15).json()
                    for item in (lib if isinstance(lib,list) else []):
                        tn=_re.sub(r"[^a-z0-9]","",(item.get("title") or "").lower())
                        nn=_re.sub(r"[^a-z0-9]","",safe.lower())
                        if tn==nn or tn in nn or nn in tn:
                            cmd="RescanSeries" if is_series else "RescanMovie"
                            kw="seriesId" if is_series else "movieId"
                            requests.post(f"{base_url}/api/v3/command",headers=_hdrs(),
                                json={"name":cmd,kw:item["id"]},timeout=8)
                            break
                except Exception: pass
                added+=1; yield sse(log=f"  ✓ {safe}",pct=pct)
            except Exception as e:
                errors+=1; yield sse(log=f"  ❌ {name[:50]}: {e}")
        yield sse(log=f"\n✅ Done. Written:{added} Skipped:{skipped} Errors:{errors}",
            pct=100,status="Done",done=True)
    return app.response_class(stream_with_context(generate()),
        mimetype="text/event-stream",headers={"X-Accel-Buffering":"no","Cache-Control":"no-cache"})

# ── Library clean ─────────────────────────────────────────────────────────────

def _find_redundant_episodes() -> list[dict]:
    """Return transfers that are redundant because a season pack for the same
    show+season already exists in the library.

    Logic:
      - Parse every cached/complete/stub transfer with parse_episode().
      - Build a set of (normalised_title, season) pairs that have a season pack
        (eps=None from parse_episode).
      - Any transfer for the same (title, season) that has specific episode
        numbers is redundant — the pack covers it.
      - Multi-season packs (e.g. S01-S06, season=1 eps=None) cover season 1
        only by parse_episode's design; the other seasons are separate entries.
    """
    from name_match import parse_episode, _norm

    transfers = _tm_all()

    # First pass: collect all season packs keyed by (norm_title, season)
    packs: set[tuple] = set()
    for t in transfers:
        if t.get("state") not in ("cached", "complete") and not t.get("is_stub"):
            continue
        title, season, eps = parse_episode(t.get("name") or "")
        if title and season is not None and eps is None:
            packs.add((_norm(title), season))

    # Second pass: find individual episodes whose pack is present
    redundant: list[dict] = []
    for t in transfers:
        if t.get("state") not in ("cached", "complete") and not t.get("is_stub"):
            continue
        title, season, eps = parse_episode(t.get("name") or "")
        if title and season is not None and eps is not None:
            if (_norm(title), season) in packs:
                redundant.append({
                    "hash":    t["hash"],
                    "name":    t.get("name") or t["hash"],
                    "title":   title,
                    "season":  season,
                    "episodes": eps,
                    "state":   t.get("state"),
                    "is_stub": bool(t.get("is_stub")),
                })

    # Sort by show title then season for readable output
    redundant.sort(key=lambda x: (_norm(x["title"]), x["season"], x["episodes"][0] if x["episodes"] else 0))
    return redundant


def _find_duplicate_movies() -> list[dict]:
    """Return movie transfers that are exact duplicates — same title, same
    year, AND same resolution tier as another transfer already in the
    library. Keeps the single best copy per (title, year, resolution) group
    (largest file size; ties broken by earliest-added) and flags the rest as
    removable.

    Deliberately does NOT cross resolution tiers — a 4K and a 1080p copy of
    the same movie are two different, intentionally-kept versions (mirrors
    the existing movies/movies4k folder split), never flagged as duplicates
    of each other.
    """
    from name_match import classify, parse_movie, parse_resolution, _norm

    transfers = _tm_all()
    groups: dict[tuple, list[dict]] = {}

    for t in transfers:
        if t.get("state") not in ("cached", "complete") and not t.get("is_stub"):
            continue
        name = t.get("name") or ""
        if classify(name, stored_kind=t.get("kind", "")) != "movie":
            continue
        title, year = parse_movie(name)
        if not title:
            continue
        res = parse_resolution(name)
        key = (_norm(title), year, res)
        groups.setdefault(key, []).append(t)

    duplicates: list[dict] = []
    for (norm_title, year, res), group in groups.items():
        if len(group) < 2:
            continue
        # Keep the largest file (best/most complete copy); tie-break by
        # earliest added_at so we prefer the long-standing copy over a
        # freshly re-added one when sizes are identical.
        group.sort(key=lambda t: (-(int(t.get("size") or 0)), t.get("added_at") or 0))
        keep = group[0]
        for t in group[1:]:
            duplicates.append({
                "hash":        t["hash"],
                "name":        t.get("name") or t["hash"],
                "title":       t.get("name") or norm_title,
                "year":        year,
                "resolution":  res,
                "size":        int(t.get("size") or 0),
                "state":       t.get("state"),
                "is_stub":     bool(t.get("is_stub")),
                "kept_hash":   keep["hash"],
                "kept_name":   keep.get("name") or keep["hash"],
                "kept_size":   int(keep.get("size") or 0),
            })

    duplicates.sort(key=lambda x: (x["title"], x["resolution"]))
    return duplicates


@app.route("/api/library/clean/preview", methods=["POST"])
def library_clean_preview():
    """Return removable transfers without deleting anything:
      - episodes/files redundant because a season pack already covers them
      - duplicate movies at the same resolution (4K vs 1080p vs 720p are
        kept as separate, intentional versions — never flagged against
        each other)
    """
    if _tm is None: return jsonify({"error": "Transfer manager unavailable"}), 500
    try:
        redundant_episodes = _find_redundant_episodes()
        duplicate_movies   = _find_duplicate_movies()
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    total = len(_tm_all())
    removable = len(redundant_episodes) + len(duplicate_movies)
    return jsonify({
        "redundant_episodes": redundant_episodes,
        "duplicate_movies":   duplicate_movies,
        "count":              removable,
        "total":              total,
        "headroom":           max(0, 5000 - total),
        "headroom_after":     max(0, 5000 - (total - removable)),
    })


@app.route("/api/library/clean/apply", methods=["POST"])
def library_clean_apply():
    """Delete removable transfers identified by preview (redundant episodes
    covered by a season pack, and duplicate movies at the same resolution).

    Body: { hashes: [hash, ...] }  — delete only these specific hashes.
    If hashes is omitted, deletes EVERYTHING flagged by preview (bulk clean).
    """
    if _tm is None: return jsonify({"error": "Transfer manager unavailable"}), 500
    d = request.get_json(force=True) or {}
    explicit = [h.strip().lower() for h in (d.get("hashes") or []) if h]

    if explicit:
        to_delete = explicit
    else:
        try:
            redundant_episodes = _find_redundant_episodes()
            duplicate_movies   = _find_duplicate_movies()
        except Exception as e:
            return jsonify({"error": str(e)}), 500
        to_delete = [r["hash"] for r in redundant_episodes] + [d["hash"] for d in duplicate_movies]

    removed = 0
    errors  = []
    for h in to_delete:
        try:
            _tm_delete(h)
            removed += 1
        except Exception as e:
            errors.append({"hash": h, "error": str(e)})

    try:
        import fuse_mount as _fm
        if _fm._pfs: _fm._pfs._invalidate_name_map()
    except Exception:
        pass

    total_after = len(_tm_all())
    return jsonify({
        "removed":     removed,
        "errors":      errors,
        "total_after": total_after,
        "headroom":    max(0, 5000 - total_after),
    })


# ── Library sync (pulls in magnets added outside this app) ───────────────────

@app.route("/api/library/bulk-scan", methods=["POST"])
def library_bulk_scan():
    """Pre-warm all CDN URLs in parallel then trigger a single full Plex section
    refresh for movies and series.  Much faster than per-folder scans on first
    import of a large library.
    """
    if _tm is None: return jsonify({"error":"Transfer manager unavailable"}),500
    try:
        from transfer_manager import _plex as _plx
        result = _plx.bulk_scan(transfer_manager=_tm)
        return jsonify({"ok": True, **result})
    except Exception as e:
        return jsonify({"error": str(e)}),500


@app.route("/api/library/import-complete", methods=["POST"])
def library_import_complete():
    """The one-time "I'm done importing" switch.

    Meant to be pressed exactly once, after a full library import (stub or
    full). Until it's pressed, every file is a stub — Plex will show and
    play stub placeholders, not real content. Pressing it:

    1. Unlocks every cached/complete transfer (cdn_unlocked=1 on both
       transfers and files) so FUSE serves real CDN bytes instead of stubs.
    2. Forces an immediate rebuild of the FUSE name map and primes the stat
       cache so Plex's first readdir/getattr calls are instant.
    3. Fires a single full-section Plex refresh per section in the
       background (one HTTP call covers the whole library).
    4. Persists library_imported=true to config — permanent, survives
       restarts. Calling this route again after that is a no-op that
       returns ok:false with already_done:true; it never re-runs.
    """
    if _tm is None: return jsonify({"error":"Transfer manager unavailable"}),500

    cfg = _load_config()
    if cfg.get("library_imported"):
        return jsonify({"ok": False, "already_done": True,
                        "error": "Import already marked complete — this can only be run once."})

    # Step 1 — the part that actually matters: unlock every cached/complete
    # transfer so it streams real content instead of a stub. If this throws,
    # we genuinely haven't completed the job, so don't mark it done.
    try:
        unlocked = _unlock_all_cached_transfers()
    except Exception as e:
        return jsonify({"error": f"Unlock failed: {e}"}),500

    # Step 2 — best-effort speed-ups. These make the Plex scan faster/more
    # complete but their failure shouldn't undo step 1 or block marking the
    # import complete — the files are already unlocked and real either way.
    primed = 0
    try:
        import fuse_mount as _fm
        if _fm._pfs:
            nm = _fm.build_name_map(_tm)
            with _fm._pfs._name_map_lock:
                _fm._pfs._name_map         = nm
                _fm._pfs._name_map_expires = time.time() + _fm.NAME_MAP_TTL
            primed = len(nm)
            _log(f"[import-complete] name map pre-built: {primed} entries")
    except Exception as e:
        _log(f"[import-complete] name map prime failed (non-fatal): {e}")

    try:
        def _scan():
            try:
                from transfer_manager import _plex as _plx
                result = _plx.bulk_scan(transfer_manager=_tm)
                _log(f"[import-complete] bulk-scan done: {result}")
            except Exception as e:
                _log(f"[import-complete] bulk-scan failed: {e}")
        _pool.submit(_scan)
    except Exception as e:
        _log(f"[import-complete] failed to schedule Plex scan (non-fatal): {e}")

    # Step 3 — persist the one-way flag. Always runs once we get here, since
    # step 1 (the part that matters) already succeeded.
    try:
        cfg = _load_config()
        cfg["library_imported"] = True
        _save_config(cfg)
    except Exception as e:
        _log(f"[import-complete] WARNING: unlock succeeded but failed to persist "
             f"library_imported flag: {e} — button may remain pressable")

    _log(f"[import-complete] DONE — {unlocked} transfer(s) unlocked, "
         f"{primed} folder(s) in name map. Marked permanently complete.")

    return jsonify({"ok": True, "unlocked": unlocked, "name_map_entries": primed,
                        "message": f"{unlocked} file(s) unlocked, {primed} folder(s) ready — Plex scan started"})

@app.route("/api/library/sync",methods=["POST"])
def library_sync():
    """Manually trigger a full AllDebrid library sync right now, instead of
    waiting for the periodic background sync (every AD_LIBRARY_SYNC_INTERVAL
    seconds, 5 min by default)."""
    if _tm is None: return jsonify({"error":"Transfer manager unavailable"}),500
    try:
        new_count = _tm.sync_library()
    except Exception as e:
        app.logger.warning(f"[lib-sync] manual trigger failed: {e}")
        return jsonify({"error":str(e)}),500
    return jsonify({"ok":True,"new_count":new_count})

# ── Repair ────────────────────────────────────────────────────────────────────

@app.route("/api/repair",methods=["POST"])
def repair():
    """Cross-check local library against AllDebrid and repair missing transfers.

    For each cached/complete transfer whose ad_id is gone from AllDebrid:
      - If the same hash is still cached → re-add it (free, instant).
      - If it's no longer cached → mark as 'missing', return in needs_search
        so the UI can offer a fallback search for an equivalent torrent.
    """
    if _tm is None: return jsonify({"error":"Transfer manager unavailable"}),500
    try:
        result = _tm.repair_missing()
    except Exception as e:
        app.logger.warning(f"[repair] failed: {e}")
        return jsonify({"error":str(e)}),500
    return jsonify(result)

@app.route("/api/repair/search",methods=["POST"])
def repair_search():
    """Search for an alternative torrent for a missing transfer and re-add it.

    Body: { hash, name, replacement_hash, replacement_name }
      - If replacement_hash is provided, upload it directly.
      - Otherwise run a search using name and return candidates.
    """
    if _tm is None: return jsonify({"error":"Transfer manager unavailable"}),500
    d=request.get_json(force=True) or {}
    orig_hash  = (d.get("hash")  or "").strip().lower()
    name       = (d.get("name")  or "").strip()
    rep_hash   = (d.get("replacement_hash") or "").strip().lower()
    rep_name   = (d.get("replacement_name") or name).strip()

    if not orig_hash: return jsonify({"error":"hash required"}),400

    # If a replacement has been chosen — add it and remove the broken entry
    if rep_hash:
        key = get_ad_api_key()
        if not key: return jsonify({"error":"API key not configured"}),400
        res = _ad_upload_batch(key,[_make_magnet(rep_hash, rep_name)])
        mags = res.get("data",{}).get("magnets",[])
        if not mags or mags[0].get("error"):
            err = mags[0].get("error",{}).get("message","Upload failed") if mags else "Upload failed"
            return jsonify({"error":err}),502
        m = mags[0]
        mid = m.get("id")
        state = "cached" if m.get("ready") else "downloading"
        # Remove old broken entry, add new one
        if orig_hash != rep_hash:
            _tm_delete(orig_hash)
        _tm_set(rep_hash, name=rep_name, ad_id=mid, state=state, is_stub=0)
        if m.get("ready"):
            try: _tm._on_ready(rep_hash)
            except Exception as e: _log(f"[repair-search] _on_ready failed: {e}")
        return jsonify({"ok":True,"hash":rep_hash,"name":rep_name,"state":state,"cached":m.get("ready",False)})

    # No replacement chosen yet — run a search and return candidates
    if not name: return jsonify({"error":"name required for search"}),400
    pq,s,e,qual = parse_query(name)
    key = get_ad_api_key()
    results = do_search(pq, s, e, qual, limit=20, ad_key=key)
    # Filter to cached-only for repair — uncached replacements aren't useful
    cached = [r for r in results if r.get("cached")]
    return jsonify({"candidates": cached or results[:10], "query": pq})

@app.route("/api/repair/missing",methods=["GET"])
def repair_missing_list():
    """Return all transfers currently in 'missing' state."""
    if _tm is None: return jsonify({"missing":[]}),200
    rows = _tm.all_transfers()
    missing = [t for t in rows if t.get("state") == "missing"]
    return jsonify({"missing": missing, "count": len(missing)})

# ── Cache check endpoint ──────────────────────────────────────────────────────

@app.route("/api/search/cache-check",methods=["POST"])
def search_cache_check():
    """Check if a single hash is cached on AllDebrid.

    Checks our local DB first (free — no API call if we already track it).
    Otherwise falls back to the same upload→ready→delete method used by
    bulk search, since AllDebrid's old instant-check endpoint no longer
    reflects real cache state.
    """
    d=request.get_json(force=True) or {}
    hash_=(d.get("hash") or "").strip().lower()
    name=(d.get("name") or "").strip()
    if not hash_: return jsonify({"error":"Missing hash"}),400
    api_key=get_ad_api_key()
    if not api_key: return jsonify({"error":"API key not configured"}),400

    # Check local DB first — free, no API call needed
    if _tm is not None:
        t=_tm.get_transfer(hash_)
        if t and t.get("state") in ("cached","complete") and not t.get("is_stub"):
            files=_tm.get_files(hash_) or []
            return jsonify({"cached":True,"state":t.get("state"),"file_count":len(files),"files":files[:10]})

    # Not tracked yet — use the real cache-check method (upload, read ready, delete)
    ready_map=check_cache_ad(api_key,[{"info_hash":hash_,"name":name}])
    cached=bool(ready_map.get(hash_,False))
    return jsonify({"cached":cached,"state":"cached" if cached else None,"file_count":0,"files":[]})

# ── Shutdown handling ──────────────────────────────────────────────────────────
# NOTE: actual SIGTERM/SIGINT handlers are registered in the __main__ block
# below, since signal.signal() only works from the main thread, and that's
# also where we have the werkzeug server instance to shut down cleanly.
# atexit is kept as a last-resort safety net for normal interpreter exits
# (e.g. an uncaught exception bubbling out of serve_forever) — it does NOT
# fire on SIGTERM by default, which is why the explicit handler below exists.

def _shutdown_handler():
    """Best-effort FUSE cleanup on any interpreter exit path."""
    try:
        import fuse_mount as _fm
        _fm.unmount()
    except Exception as e:
        app.logger.warning(f"FUSE cleanup on shutdown failed: {e}")

import atexit
atexit.register(_shutdown_handler)

# ── Entry point ───────────────────────────────────────────────────────────────

if __name__=="__main__":
    port=int(os.environ.get("PORT",5000))
    import resource
    try:
        soft,hard=resource.getrlimit(resource.RLIMIT_NOFILE)
        t=min(hard,65536)
        if soft<t: resource.setrlimit(resource.RLIMIT_NOFILE,(t,hard))
    except Exception: pass
    from werkzeug.serving import make_server as _mks
    max_t=int(os.environ.get("SERVER_THREADS","16"))
    sem=threading.Semaphore(max_t); srv=_mks("0.0.0.0",port,app,threaded=True)
    def _cap(req,addr):
        if sem.acquire(blocking=False):
            def _r():
                try: srv.finish_request(req,addr)
                except: srv.handle_error(req,addr)
                finally: srv.shutdown_request(req); sem.release()
            threading.Thread(target=_r,daemon=True).start()
        else:
            try: srv.finish_request(req,addr)
            except: srv.handle_error(req,addr)
            finally: srv.shutdown_request(req)
    srv.process_request=_cap

    # ── Graceful shutdown: SIGTERM (docker stop) / SIGINT (Ctrl-C) ───────────
    # signal.signal() only works from the main thread, which is exactly where
    # we are here (serve_forever() below runs ON this thread). The handler
    # itself must do as little as possible and return quickly — srv.shutdown()
    # is called from a tiny helper thread because calling it from the same
    # thread that's blocked in serve_forever() (i.e. right here) deadlocks.
    _shutting_down = threading.Event()

    def _handle_term(signum, frame):
        if _shutting_down.is_set():
            return  # already shutting down, ignore repeat signals
        _shutting_down.set()
        app.logger.info(f"[shutdown] Received signal {signum} — shutting down gracefully...")

        def _unmount_fuse():
            try:
                import fuse_mount as _fm
                _fm.unmount()
            except Exception as e:
                app.logger.warning(f"[shutdown] FUSE unmount failed: {e}")

        # Run both concurrently — fusermount can block several seconds on a
        # busy mount, and we don't want that to delay srv.shutdown() (or
        # vice versa) within Docker's ~10s SIGTERM grace period.
        threading.Thread(target=_unmount_fuse, daemon=True).start()
        threading.Thread(target=srv.shutdown,  daemon=True).start()

    signal.signal(signal.SIGTERM, _handle_term)
    signal.signal(signal.SIGINT,  _handle_term)

    app.logger.info(f"AllDebrid Web :{port} rate={_AD_RATE_LIMIT}/min")
    srv.serve_forever()
    app.logger.info("[shutdown] Server stopped — exiting")
