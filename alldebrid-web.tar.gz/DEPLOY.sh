#!/bin/bash
# AllDebrid Web - Quick Deployment Script
# Usage: bash DEPLOY.sh [backup_db] [restart_service]

set -e

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║        AllDebrid Web - Deployment Script                      ║"
echo "╚════════════════════════════════════════════════════════════════╝"

# Configuration
APP_DIR="${1:-.}"
BACKUP_DB="${2:-true}"
RESTART_SERVICE="${3:-true}"
SERVICE_NAME="alldebrid-web"

echo ""
echo "📁 Deployment Directory: $APP_DIR"
echo ""

# Step 1: Backup database if requested
if [ "$BACKUP_DB" = "true" ] || [ "$BACKUP_DB" = "1" ]; then
    if [ -f "$APP_DIR/alldebrid.db" ]; then
        echo "💾 Backing up database..."
        cp "$APP_DIR/alldebrid.db" "$APP_DIR/alldebrid.db.backup.$(date +%Y%m%d-%H%M%S)"
        echo "   ✓ Backup created"
    else
        echo "   ⚠ Database not found at $APP_DIR/alldebrid.db"
    fi
else
    echo "⊘ Database backup skipped"
fi

echo ""

# Step 2: Extract fixed application
if [ -f "alldebrid-web-FIXED.tar.gz" ]; then
    echo "📦 Extracting fixed application..."
    tar -xzf alldebrid-web-FIXED.tar.gz
    echo "   ✓ Extracted"
else
    echo "   ⚠ alldebrid-web-FIXED.tar.gz not found"
fi

echo ""

# Step 3: Copy files
echo "📝 Copying fixed files to $APP_DIR..."
if [ -d "alldebrid-web" ]; then
    cp alldebrid-web/transfer_manager.py "$APP_DIR/" && echo "   ✓ transfer_manager.py"
    cp alldebrid-web/fuse_mount.py "$APP_DIR/" && echo "   ✓ fuse_mount.py"
    cp alldebrid-web/app.py "$APP_DIR/" && echo "   ✓ app.py"
else
    echo "   ✗ alldebrid-web directory not found"
    exit 1
fi

echo ""

# Step 4: Verify Python syntax
echo "🔍 Verifying Python syntax..."
python3 -m py_compile "$APP_DIR/transfer_manager.py" && echo "   ✓ transfer_manager.py"
python3 -m py_compile "$APP_DIR/fuse_mount.py" && echo "   ✓ fuse_mount.py"
python3 -m py_compile "$APP_DIR/app.py" && echo "   ✓ app.py"

echo ""

# Step 5: Restart service if requested
if [ "$RESTART_SERVICE" = "true" ] || [ "$RESTART_SERVICE" = "1" ]; then
    echo "🔄 Restarting $SERVICE_NAME service..."
    if systemctl is-active --quiet "$SERVICE_NAME"; then
        systemctl restart "$SERVICE_NAME"
        sleep 2
        if systemctl is-active --quiet "$SERVICE_NAME"; then
            echo "   ✓ Service restarted successfully"
        else
            echo "   ✗ Service failed to start!"
            exit 1
        fi
    else
        echo "   ⚠ Service $SERVICE_NAME not running"
        echo "     Start manually with: systemctl start $SERVICE_NAME"
    fi
else
    echo "⊘ Service restart skipped"
    echo "   Start manually with: systemctl restart $SERVICE_NAME"
fi

echo ""

# Step 6: Verify
echo "✅ Verification..."
if [ -f "$APP_DIR/transfer_manager.py" ] && \
   [ -f "$APP_DIR/fuse_mount.py" ] && \
   [ -f "$APP_DIR/app.py" ]; then
    echo "   ✓ All files deployed successfully"
else
    echo "   ✗ Some files are missing"
    exit 1
fi

echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                  ✅ DEPLOYMENT COMPLETE                       ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""
echo "Next steps:"
echo "  1. Monitor logs: tail -f /var/log/alldebrid/app.log"
echo "  2. Test: curl http://localhost:5000/api/user"
echo "  3. Read documentation in current directory"
echo ""
