#!/bin/sh
set -e

SHARE_ROOT="/docker/alldebrid-web"
FUSE_MOUNT="${FUSE_MOUNTPOINT:-/docker/alldebrid-web/mnt}"
CACHE_DIR="${FUSE_CACHE_DIR:-/docker/alldebrid-web/cache}"

log() { echo "[entrypoint] $*"; }

# ── Step 1: ensure SHARE_ROOT is a shared bind-mount ─────────────────────────
if mountpoint -q "$SHARE_ROOT" 2>/dev/null; then
    mount --make-rshared "$SHARE_ROOT" 2>/dev/null \
        && log "$SHARE_ROOT marked rshared" \
        || log "WARNING: could not mark $SHARE_ROOT rshared"
else
    mount --bind "$SHARE_ROOT" "$SHARE_ROOT" 2>/dev/null \
        && mount --make-rshared "$SHARE_ROOT" 2>/dev/null \
        && log "$SHARE_ROOT bind-mounted and marked rshared" \
        || log "WARNING: could not bind/share $SHARE_ROOT (running without SYS_ADMIN?)"
fi

# ── Step 2: tear down any stale FUSE mount ────────────────────────────────────
_unmount_fuse() {
    fusermount -uz "$FUSE_MOUNT" 2>/dev/null && return 0
    umount -l   "$FUSE_MOUNT"   2>/dev/null && return 0
    umount      "$FUSE_MOUNT"   2>/dev/null && return 0
    return 1
}

i=0
while true; do
    if mountpoint -q "$FUSE_MOUNT" 2>/dev/null; then
        log "Stale FUSE mount detected at $FUSE_MOUNT — unmounting (attempt $((i+1)))..."
        _unmount_fuse || true
    elif ! timeout 5 stat "$FUSE_MOUNT" >/dev/null 2>&1; then
        log "Broken/unresponsive endpoint at $FUSE_MOUNT — forcing unmount (attempt $((i+1)))..."
        umount -l "$FUSE_MOUNT" 2>/dev/null || true
    else
        break
    fi
    i=$((i + 1))
    if [ $i -ge 15 ]; then
        log "WARNING: could not fully clear $FUSE_MOUNT after 15 attempts — proceeding anyway"
        break
    fi
    sleep 0.2
done

# ── Step 3: ensure directories exist ─────────────────────────────────────────
mkdir -p "$FUSE_MOUNT"
mkdir -p "$CACHE_DIR"
DOWNLOADS_ROOT="${DOWNLOADS_ROOT:-/docker/alldebrid-web/downloads}"
mkdir -p "$DOWNLOADS_ROOT"
chmod 777 "$DOWNLOADS_ROOT"

log "Starting app"
exec python /app/app.py
