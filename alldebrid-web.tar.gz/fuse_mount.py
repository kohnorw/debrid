"""
AllDebrid virtual filesystem using FUSE.

Directory structure mirrors premiumize-web exactly:
  /docker/alldebrid-web/mnt/
    movies/   <torrent name>/<filename>.mkv
    series/   <show name>/<episode>.mkv
    movies4k/ ...
    series4k/ ...

CDN URLs come from the `files` table (populated by transfer_manager.get_files
which calls AllDebrid link/unlock once per file and caches the result).
URLs are refreshed only when a real playback read returns 403/410.

Block-cache, read-ahead, analysis-aware prefetch gate, and all FUSE ops are
identical to the Premiumize version — only the "get CDN URL" path differs.
"""

import errno
import hashlib
import logging
import os
import re
import stat
import threading
import time
from collections import OrderedDict

import requests

log = logging.getLogger(__name__)

# ── CDN URL cache timings ──────────────────────────────────────────────────────
DIRECTDL_TTL   = 172800   # 48 h — AllDebrid unlocked links last at least 48h
REFRESH_MARGIN = 3600     # background refresh 1 h before expiry

# ── HTTP retry ────────────────────────────────────────────────────────────────
READ_TIMEOUT      = int(os.environ.get("FUSE_READ_TIMEOUT", "10"))
READ_MAX_ATTEMPTS = 5
READ_BACKOFF_BASE = 0.5
READ_BACKOFF_CAP  = 4.0

# ── Block cache / read-ahead ──────────────────────────────────────────────────
_RA_MB            = int(os.environ.get("FUSE_READAHEAD_MB",  "8"))
_CACHE_N          = int(os.environ.get("FUSE_CACHE_BLOCKS", "64"))
_PREFETCH_ENABLED = os.environ.get("FUSE_PREFETCH", "true").lower() != "false"
_CACHE_DIR        = os.environ.get("FUSE_CACHE_DIR", "/docker/alldebrid-web/cache").strip()
_VIDEO_ONLY       = os.environ.get("FUSE_VIDEO_ONLY", "true").lower() != "false"
_AUTO_UNLOCK_ON_READ  = os.environ.get("FUSE_AUTO_UNLOCK_ON_READ",  "false").lower() not in ("0","false","no")
_PREWARM_ON_UNLOCK    = os.environ.get("FUSE_PREWARM_ON_UNLOCK",    "false").lower() not in ("0","false","no")

BLOCK_SIZE = _RA_MB * 1024 * 1024

PREFETCH_SEQ_THRESHOLD = int(os.environ.get("FUSE_PREFETCH_SEQ_THRESHOLD", "2"))
_SEQ_GAP_TOLERANCE     = 1 * 1024 * 1024

def _parse_size(val: str, default: int) -> int:
    if not val:
        return default
    val = val.strip().upper().replace(" ", "")
    for sfx, mult in sorted({"TB":1024**4,"GB":1024**3,"MB":1024**2,"KB":1024,"B":1}.items(), key=lambda x:-len(x[0])):
        if val.endswith(sfx):
            try:
                return int(float(val[:-len(sfx)]) * mult)
            except ValueError:
                return default
    try:
        return int(val)
    except ValueError:
        return default

_READ_AHEAD_BYTES = _parse_size(os.environ.get("FUSE_READ_AHEAD", "500MB"), 500*1024*1024)

VIDEO_EXTENSIONS = {".mkv",".mp4",".avi",".mov",".m4v",".ts",".wmv",".flv",".webm",".m2ts",".mpg",".mpeg"}
EXTRA_PATTERNS   = re.compile(r'(?i)(^|\b)(sample|trailer|featurette|behind.the.scenes|deleted.scene|interview|short|scene|extra)s?(\b|$)')

def _is_video(fn: str) -> bool:
    return os.path.splitext(fn)[1].lower() in VIDEO_EXTENSIONS

def _is_extra(fn: str) -> bool:
    return bool(EXTRA_PATTERNS.search(os.path.splitext(fn)[0]))

def _include_file(fn: str) -> bool:
    if not _VIDEO_ONLY:
        return True
    return _is_video(fn) and not _is_extra(fn)

NAME_MAP_TTL  = 300   # 5 min — rebuilt lazily; long TTL is fine since we
                      # call _invalidate_name_map() on every add/remove
STAT_CACHE_TTL = 300
KERNEL_ATTR_TIMEOUT  = float(os.environ.get("FUSE_ATTR_TIMEOUT",  "30"))
KERNEL_ENTRY_TIMEOUT = float(os.environ.get("FUSE_ENTRY_TIMEOUT", "30"))
DIRECTDL_WORKERS     = int(os.environ.get("FUSE_DIRECTDL_WORKERS", "12"))

_UNLOCK_LOGGED: set  = set()
_UNLOCK_LOG_LOCK     = threading.Lock()

try:
    from fuse import FUSE, FuseOSError, Operations
    FUSE_AVAILABLE = True
except ImportError:
    FUSE_AVAILABLE = False
    log.warning("fusepy not installed — FUSE mount unavailable")

def _safe_name(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name)
    return name.strip('. ')[:200] or "unknown"

import re as _re
from name_match import _SERIES_RE, _4K_RE, override_key_for

_4K_FOLDERS_ENABLED = False
_pfs = None

_overrides: dict = {}
_re_nonalnum = re.compile(r'[^a-z0-9]')

def _override_key(name: str) -> str:
    return _re_nonalnum.sub('', (name or '').lower())

def _find_override_entry(name: str):
    """Check the series-title key, then the movie title+year key, then the
    legacy literal-name key (for overrides saved before this fix). Returns
    the override dict or None. See override_key_for() in name_match.py for
    why two different keys are checked.
    """
    series_key = override_key_for(name, "series")
    if series_key in _overrides:
        return _overrides[series_key]
    movie_key = override_key_for(name, "movie")
    if movie_key in _overrides:
        return _overrides[movie_key]
    legacy_key = _override_key(name)
    if legacy_key in _overrides:
        return _overrides[legacy_key]
    return None

def _category_subdir(name: str, category: str = "", kind: str = "") -> str:
    hit = _find_override_entry(name)
    if hit:
        is_s = hit["kind"] == "series"
        if _4K_FOLDERS_ENABLED and _4K_RE.search(name or ""):
            return "series4k" if is_s else "movies4k"
        return "series" if is_s else "movies"
    if kind in ("series", "movie"):
        is_s = kind == "series"
        if _4K_FOLDERS_ENABLED and _4K_RE.search(name or ""):
            return "series4k" if is_s else "movies4k"
        return "series" if is_s else "movies"
    is_s = bool(_SERIES_RE.search(name or ""))
    cat = (category or "").lower()
    if not is_s:
        is_s = any(k in cat for k in ("sonarr","tv","series","show"))
    if _4K_FOLDERS_ENABLED and _4K_RE.search(name or ""):
        return "series4k" if is_s else "movies4k"
    return "series" if is_s else "movies"


def build_name_map(transfer_manager) -> dict:
    result = {}
    try:
        from name_match import classify_from_files as _clf
        _clf_available = True
    except Exception:
        _clf_available = False
    try:
        hashes = transfer_manager.streamable_hashes()
    except Exception as e:
        log.warning(f"build_name_map: streamable_hashes failed: {e}")
        return result
    _hash_re = re.compile(r'^[0-9a-f]{32,64}$', re.IGNORECASE)
    for h in hashes:
        try:
            t = transfer_manager.get_transfer(h)
            if not t:
                continue
            stored_kind = t.get("kind", "")
            stored_name = t.get("name") or ""
            # Resolve hash-only names from cached file list
            if not stored_name or _hash_re.match(stored_name.strip()):
                if _pfs is not None:
                    cached = _pfs._file_cache.get(h)
                    if cached:
                        files_c, _ = cached
                        tops = [f.get("path","").split("/")[0] for f in files_c if f.get("path")]
                        tops = [t for t in tops if t and not _hash_re.match(t)]
                        if tops:
                            import collections as _coll
                            resolved = _coll.Counter(tops).most_common(1)[0][0]
                            base_r, ext_r = os.path.splitext(resolved)
                            if ext_r.lower() in (".mkv",".mp4",".avi",".ts",".m4v"):
                                resolved = base_r
                            if resolved:
                                stored_name = resolved
                                try:
                                    transfer_manager._set(h, name=resolved)
                                except Exception:
                                    pass
            if not stored_kind and _clf_available and _pfs is not None:
                cached = _pfs._file_cache.get(h)
                if cached:
                    files_c, _ = cached
                    try:
                        inferred = _clf(files_c)
                        if inferred:
                            stored_kind = inferred
                            try:
                                transfer_manager._set(h, kind=inferred)
                            except Exception:
                                pass
                    except Exception:
                        pass
            base   = _safe_name(stored_name or h)
            subdir = _category_subdir(stored_name or "", t.get("category",""), kind=stored_kind)
            key    = f"{subdir}/{base}"
            if key in result:
                key = f"{subdir}/{base}_{h[:8]}"
            result[key] = h
        except Exception as e:
            log.warning(f"build_name_map: error for {h[:8]}: {e}")
    return result


def dir_name_for_hash(transfer_manager, hash_: str):
    for nm, h in build_name_map(transfer_manager).items():
        if h == hash_:
            return nm
    return None

# ── Disk block cache path ─────────────────────────────────────────────────────

def _disk_block_path(cache_dir: str, cdn_url: str, block_idx: int) -> str:
    url_hash = hashlib.sha256(cdn_url.encode()).hexdigest()[:16]
    return os.path.join(cache_dir, url_hash, f"{block_idx}.bin")

# ── LRU block cache ───────────────────────────────────────────────────────────

class _BlockCache:
    def __init__(self, max_blocks: int, cache_dir: str = ""):
        self._max       = max_blocks
        self._cache_dir = cache_dir
        self._lock      = threading.Lock()
        self._store: OrderedDict = OrderedDict()

    def get(self, key):
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
                return self._store[key]
        if self._cache_dir:
            cdn_url, block_idx = key
            path = _disk_block_path(self._cache_dir, cdn_url, block_idx)
            try:
                with open(path, "rb") as f:
                    data = f.read()
                self.put(key, data)
                return data
            except (FileNotFoundError, OSError):
                pass
        return None

    def put(self, key, data: bytes):
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
            else:
                self._store[key] = data
                while len(self._store) > self._max:
                    self._store.popitem(last=False)
        if self._cache_dir:
            cdn_url, block_idx = key
            path = _disk_block_path(self._cache_dir, cdn_url, block_idx)
            try:
                os.makedirs(os.path.dirname(path), exist_ok=True)
                tmp = path + ".tmp"
                with open(tmp, "wb") as f:
                    f.write(data)
                os.replace(tmp, path)
            except OSError as e:
                log.debug(f"Disk cache write failed: {e}")

    def invalidate_url(self, cdn_url: str):
        with self._lock:
            for k in [k for k in self._store if k[0] == cdn_url]:
                del self._store[k]
        if self._cache_dir:
            url_hash = hashlib.sha256(cdn_url.encode()).hexdigest()[:16]
            import shutil
            shutil.rmtree(os.path.join(self._cache_dir, url_hash), ignore_errors=True)

    @property
    def size(self):
        with self._lock:
            return len(self._store)


_block_cache = _BlockCache(_CACHE_N, _CACHE_DIR)


class AllDebridFS(Operations):
    """
    FUSE filesystem backed by AllDebrid CDN.

    Identical structure to PremiumizeFS — the only functional difference is
    that CDN URLs are stored in the `files` DB table (populated by
    transfer_manager.get_files / link/unlock) rather than fetched fresh from
    a directdl endpoint on every FUSE readdir.
    """

    def __init__(self, transfer_manager):
        self._tm   = transfer_manager
        self._now  = time.time()
        self._lock = threading.Lock()

        self._file_cache: dict[str, tuple[list, float]] = {}
        self._refreshing: set = set()
        self._fetching:   set = set()
        self._fetch_lock  = threading.Lock()

        self._read_state: dict[int, dict] = {}
        self._read_state_lock             = threading.Lock()

        self._fh_counter: int = 0
        self._fh_lock         = threading.Lock()

        self._name_map:         dict  = {}
        self._name_map_expires: float = 0.0
        self._name_map_lock           = threading.Lock()

        self._stat_cache: dict[str, tuple[dict, float]] = {}
        self._stat_lock                                  = threading.Lock()

        self._inline_repair_attempted: dict[str, float] = {}
        self._inline_repair_lock = threading.Lock()

    # ── Name map ──────────────────────────────────────────────────────────────

    def _get_name_map(self) -> dict:
        now = time.time()
        with self._name_map_lock:
            if now < self._name_map_expires:
                return self._name_map
        nm = build_name_map(self._tm)
        with self._name_map_lock:
            self._name_map         = nm
            self._name_map_expires = now + NAME_MAP_TTL
        return nm

    def _invalidate_name_map(self):
        with self._name_map_lock:
            self._name_map_expires = 0.0

    # ── Stat cache ────────────────────────────────────────────────────────────

    def _stat_get(self, path: str):
        now = time.time()
        with self._stat_lock:
            entry = self._stat_cache.get(path)
            if entry and now < entry[1]:
                return entry[0]
        return None

    def _stat_put(self, path: str, st: dict):
        with self._stat_lock:
            self._stat_cache[path] = (st, time.time() + STAT_CACHE_TTL)

    def _stat_invalidate(self, path: str):
        with self._stat_lock:
            self._stat_cache.pop(path, None)

    def _stat_invalidate_all(self):
        with self._stat_lock:
            self._stat_cache.clear()

    # ── File list (CDN URLs from DB via transfer_manager.get_files) ───────────

    def _get_files(self, hash_: str, force: bool = False) -> list:
        """
        Return the unlocked file list for hash.

        Checks the in-process FUSE cache first (TTL=48h), then delegates to
        transfer_manager.get_files which reads from the persistent `files` DB
        table (populated by link/unlock on first access).
        """
        now = time.time()
        if not force:
            with self._lock:
                cached = self._file_cache.get(hash_)
            if cached:
                files, expires_at = cached
                if now < expires_at - REFRESH_MARGIN:
                    return files
                if now < expires_at:
                    self._spawn_refresh(hash_)
                    return files

        files = self._tm.get_files(hash_, force=force)
        if files:
            with self._lock:
                self._file_cache[hash_] = (files, now + DIRECTDL_TTL)
        return files

    def _get_files_light(self, hash_: str) -> list:
        """Discovery-only variant of _get_files: names + sizes, no per-file
        unlock cost. Shares the same _file_cache as _get_files — if a full
        fetch already populated it (e.g. a previous playback), that richer
        data is reused as-is rather than refetched. Use this anywhere the
        caller only needs to list/stat files (readdir), never for anything
        that will read file bytes or needs a real cdn_url.
        """
        now = time.time()
        with self._lock:
            cached = self._file_cache.get(hash_)
        if cached:
            files, expires_at = cached
            if now < expires_at:
                return files
        files = self._tm.get_files_light(hash_)
        if files:
            with self._lock:
                self._file_cache[hash_] = (files, now + DIRECTDL_TTL)
        return files

    def _spawn_refresh(self, hash_: str):
        with self._lock:
            if hash_ in self._refreshing:
                return
            self._refreshing.add(hash_)
        def _do():
            try:
                files = self._tm.get_files(hash_, force=True)
                if files:
                    with self._lock:
                        self._file_cache[hash_] = (files, time.time() + DIRECTDL_TTL)
            except Exception:
                log.warning(f"[{hash_[:8]}] background refresh failed", exc_info=True)
            finally:
                with self._lock:
                    self._refreshing.discard(hash_)
        threading.Thread(target=_do, daemon=True).start()

    def _invalidate_files(self, hash_: str):
        with self._lock:
            self._file_cache.pop(hash_, None)

    def _prewarm_parallel(self, hashes: list, block: bool = False):
        from concurrent.futures import ThreadPoolExecutor, as_completed
        def _fetch_one(h):
            if h in self._file_cache:
                files, exp = self._file_cache[h]
                if time.time() < exp:
                    return
            files = self._tm.get_files_light(h)
            if files:
                with self._lock:
                    self._file_cache[h] = (files, time.time() + DIRECTDL_TTL)
        pool = ThreadPoolExecutor(max_workers=DIRECTDL_WORKERS, thread_name_prefix="fuse-prewarm")
        futures = [pool.submit(_fetch_one, h) for h in hashes]
        pool.shutdown(wait=block)
        if not block:
            def _log_errs():
                for f in as_completed(futures):
                    try:
                        f.result()
                    except Exception as e:
                        log.debug(f"[prewarm] {e}")
            threading.Thread(target=_log_errs, daemon=True).start()

    # ── Path helpers ──────────────────────────────────────────────────────────

    def _parse_path(self, path):
        parts = [p for p in path.split("/") if p]
        if not parts:
            return None, None, None, None
        if parts[0] in ("movies","series","movies4k","series4k"):
            subdir   = parts[0]
            dirname  = parts[1] if len(parts) > 1 else None
            filename = "/".join(parts[2:]) if len(parts) > 2 else None
        else:
            subdir   = None
            dirname  = parts[0]
            filename = "/".join(parts[1:]) if len(parts) > 1 else None
        if dirname is None:
            return subdir, None, None, None
        key   = f"{subdir}/{dirname}" if subdir else dirname
        hash_ = self._get_name_map().get(key)
        return subdir, dirname, filename, hash_

    def _find_file(self, hash_: str, filename: str, force: bool = False):
        for f in self._get_files(hash_, force=force):
            f_name = f.get("name","")
            f_base = os.path.basename(f.get("path","") or f_name)
            if f_name == filename or f_base == filename:
                return f
        return None

    def _find_file_light(self, hash_: str, filename: str):
        """Discovery-only counterpart to _find_file — for callers that only
        need to confirm a file exists and get its size (getattr, open),
        never its cdn_url. Saves the per-file unlock cost for files that
        haven't been read yet."""
        for f in self._get_files_light(hash_):
            f_name = f.get("name","")
            f_base = os.path.basename(f.get("path","") or f_name)
            if f_name == filename or f_base == filename:
                return f
        return None

    # ── FUSE ops ──────────────────────────────────────────────────────────────

    def getattr(self, path, fh=None):
        try:
            return self._getattr_safe(path)
        except FuseOSError:
            raise
        except Exception as e:
            log.warning(f"getattr({path}): {e}", exc_info=True)
            raise FuseOSError(errno.ENOENT)

    def _getattr_safe(self, path):
        cached = self._stat_get(path)
        if cached is not None:
            return cached

        base = {
            "st_uid": os.getuid(), "st_gid": os.getgid(),
            "st_atime": self._now, "st_mtime": self._now, "st_ctime": self._now,
            "st_nlink": 2,
        }

        if path == "/":
            st = {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
            self._stat_put(path, st); return st

        _valid = {"/movies", "/series"}
        if _4K_FOLDERS_ENABLED:
            _valid |= {"/movies4k", "/series4k"}
        if path in _valid:
            st = {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
            self._stat_put(path, st); return st

        subdir, dirname, filename, hash_ = self._parse_path(path)

        if not filename:
            if hash_ is not None:
                st = {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
                self._stat_put(path, st); return st
            raise FuseOSError(errno.ENOENT)

        if hash_ is None:
            raise FuseOSError(errno.ENOENT)

        if filename.lower().endswith(".nfo"):
            if _VIDEO_ONLY:
                raise FuseOSError(errno.ENOENT)
            video_name = os.path.splitext(filename)[0]
            for f in self._get_files_light(hash_):
                raw  = f.get("name","") or f.get("path","")
                name = os.path.basename(raw) if raw else raw
                if os.path.splitext(name)[0] == video_name and _include_file(name):
                    nfo = self._nfo_content(hash_, name)
                    st  = {**base, "st_mode": stat.S_IFREG | 0o444, "st_nlink": 1,
                           "st_size": len(nfo) if nfo else 256}
                    self._stat_put(path, st); return st
            raise FuseOSError(errno.ENOENT)

        f = self._find_file_light(hash_, filename)
        if not f:
            raise FuseOSError(errno.ENOENT)
        if not _include_file(filename):
            raise FuseOSError(errno.ENOENT)

        file_size = int(float(f.get("size", 0) or 0))
        if file_size == 0:
            raise FuseOSError(errno.ENOENT)

        if not self._tm.is_file_cdn_unlocked(hash_, filename):
            try:
                from qbt_mock import _stub_bytes_for
                stub = _stub_bytes_for(filename)
                reported_size = len(stub) if stub else file_size
            except Exception:
                reported_size = file_size
            mtime = self._now
        else:
            reported_size = file_size
            try:
                t = self._tm.get_transfer(hash_)
                mtime = float(t.get("streamable_at") or t.get("added_at") or self._now)
            except Exception:
                mtime = self._now

        st = {**base, "st_mode": stat.S_IFREG | 0o444, "st_nlink": 1,
              "st_size": reported_size, "st_mtime": mtime, "st_ctime": mtime}
        self._stat_put(path, st)
        return st

    def readdir(self, path, fh):
        try:
            return self._readdir_safe(path)
        except Exception as e:
            log.error(f"readdir({path}): {e}", exc_info=True)
            return [".", ".."]

    def _readdir_safe(self, path):
        entries = [".", ".."]
        if path == "/":
            entries += ["movies", "series"]
            if _4K_FOLDERS_ENABLED:
                entries += ["movies4k", "series4k"]
            return entries
        valid = ["/movies", "/series"]
        if _4K_FOLDERS_ENABLED:
            valid += ["/movies4k", "/series4k"]
        if path in valid:
            subdir = path.lstrip("/")
            nm     = self._get_name_map()
            names, hashes = [], []
            for key in nm:
                if key.startswith(subdir + "/"):
                    names.append(key[len(subdir)+1:])
                    hashes.append(nm[key])
            uncached = [h for h in hashes
                        if h not in self._file_cache or time.time() >= self._file_cache[h][1]]
            if uncached:
                self._prewarm_parallel(uncached)
            entries += names
            return entries
        subdir, dirname, _, hash_ = self._parse_path(path)
        if hash_:
            try:
                files = self._get_files_light(hash_)
            except Exception:
                files = []
            for f in files:
                raw  = f.get("name","") or f.get("path","")
                name = os.path.basename(raw) if raw else raw
                if not name:
                    continue
                try:
                    size = int(float(f.get("size", 0) or 0))
                except (ValueError, TypeError):
                    size = 0
                if _include_file(name) and size > 0:
                    entries.append(name)
                    if not _VIDEO_ONLY:
                        entries.append(os.path.splitext(name)[0] + ".nfo")
        return entries

    def _nfo_content(self, hash_: str, filename: str) -> bytes | None:
        try:
            from qbt_mock import _parse_stub_meta, _make_nfo_content
            return _make_nfo_content(_parse_stub_meta(filename)).encode("utf-8")
        except Exception:
            return None

    def open(self, path, flags):
        try:
            subdir, dirname, filename, hash_ = self._parse_path(path)
            if not filename or hash_ is None:
                raise FuseOSError(errno.ENOENT)
            if filename.lower().endswith(".nfo"):
                if _VIDEO_ONLY:
                    raise FuseOSError(errno.ENOENT)
                return 0
            f = self._find_file_light(hash_, filename)
            if not f or int(float(f.get("size", 0) or 0)) == 0:
                raise FuseOSError(errno.ENOENT)
            with self._fh_lock:
                self._fh_counter += 1
                fh = self._fh_counter
            return fh
        except FuseOSError:
            raise
        except Exception as e:
            log.warning(f"open({path}): {e}")
            raise FuseOSError(errno.ENOENT)

    def release(self, path, fh):
        with self._read_state_lock:
            self._read_state.pop(fh, None)
        return 0

    # ── Block cache read ──────────────────────────────────────────────────────

    def _block_key(self, cdn_url: str, block_idx: int):
        return (cdn_url, block_idx)

    def _ensure_unlocked_for_read(self, hash_: str, filename: str, path: str) -> bool:
        # Re-check the DB each call — _on_ready may have just set cdn_unlocked=1
        # while our stat cache still reports stub size. If already unlocked,
        # invalidate the stat so the next getattr returns the real file size.
        if self._tm.is_file_cdn_unlocked(hash_, filename):
            self._stat_invalidate(path)
            return True
        if not _AUTO_UNLOCK_ON_READ:
            return False
        ok = False
        try:
            ok = bool(self._tm.unlock_file_cdn(hash_, filename))
        except Exception as e:
            log.warning(f"[auto-unlock] failed hash={hash_[:8]} file={filename}: {e}")
            return False
        self._stat_invalidate(path)
        self._invalidate_files(hash_)
        f = None
        files = self._get_files(hash_, force=True) or []
        for cand in files:
            raw  = cand.get("name","") or cand.get("path","")
            base = os.path.basename(raw) if raw else raw
            if raw == filename or base == filename or (cand.get("path","") or "").endswith("/" + filename):
                f = cand
                break
        cdn_url   = (f or {}).get("cdn_url") or (f or {}).get("link","")
        file_size = int(float((f or {}).get("size", 0) or 0))
        if ok and _PREWARM_ON_UNLOCK and cdn_url and file_size:
            try:
                self._fetch_block(cdn_url, 0, file_size)
            except Exception:
                pass
        key = (hash_, filename)
        with _UNLOCK_LOG_LOCK:
            if key not in _UNLOCK_LOGGED:
                _UNLOCK_LOGGED.add(key)
                log.warning(f"[auto-unlock] {'unlocked' if ok else 'failed'} hash={hash_[:8]} file={filename}")
        return self._tm.is_file_cdn_unlocked(hash_, filename)

    def _serve_stub(self, filename: str, offset: int, size: int) -> bytes:
        """Serve bytes from the local stub placeholder file for `filename`,
        padded with zeros if the read goes past the stub's own length.
        Shared by every place read() falls back to stub bytes — file still
        locked, auto-unlock disabled, or recovery failed.
        """
        try:
            from qbt_mock import _stub_bytes_for
            stub = _stub_bytes_for(filename) or b""
        except Exception:
            stub = b""
        if offset >= len(stub):
            return b""
        chunk = stub[offset:offset+size]
        if len(chunk) < size:
            chunk = chunk + b"\x00" * (size - len(chunk))
        return chunk

    def _try_inline_repair(self, hash_: str) -> bool:
        """One inline recovery attempt for a transfer whose magnet has
        apparently been purged from AllDebrid (get_files() returned nothing
        even though we have an ad_id on file) — re-upload just this one
        hash via the cheap single-transfer path (no full-library
        _ad_all_magnets scan), run synchronously here so THIS read can
        succeed without waiting for the next scheduled repair pass.

        Rate-limited per hash (60s) so repeated reads/retries during the
        same failed playback attempt don't each trigger a fresh re-upload
        call — if it just failed, it's going to keep failing for at least
        that long.
        """
        now = time.time()
        with self._inline_repair_lock:
            last = self._inline_repair_attempted.get(hash_, 0)
            if now - last < 60:
                return False
            self._inline_repair_attempted[hash_] = now
        try:
            return bool(self._tm.repair_one(hash_))
        except Exception as e:
            log.warning(f"[{hash_[:8]}] inline repair attempt failed: {e}")
            return False

    def _fetch_block(self, cdn_url: str, block_idx: int, file_size: int,
                     force_url: str = None, hash_: str = None, filename: str = None) -> bytes | None:
        url     = force_url or cdn_url
        start   = block_idx * BLOCK_SIZE
        end     = min(start + BLOCK_SIZE - 1, file_size - 1) if file_size else start + BLOCK_SIZE - 1
        headers = {"Range": f"bytes={start}-{end}"}
        last_err = None
        for attempt in range(READ_MAX_ATTEMPTS):
            try:
                r = requests.get(url, headers=headers, timeout=(5, READ_TIMEOUT), stream=True)
            except requests.RequestException as e:
                last_err = e
                log.warning(f"Block fetch error (try {attempt+1}): {e}")
                if attempt == 0 and cdn_url and hash_ and filename:
                    new_url = self._refresh_cdn_url(hash_, filename, cdn_url)
                    if new_url and new_url != url:
                        url = new_url
                self._read_backoff(attempt)
                continue
            try:
                status = r.status_code
                if status in (200, 206):
                    data = r.content
                    _block_cache.put(self._block_key(cdn_url, block_idx), data)
                    return data
                if status in (403, 410):
                    log.info(f"CDN URL expired (block {block_idx}, status {status})")
                    return None
                if status in (429, 500, 502, 503, 504):
                    last_err = f"status {status}"
                    self._read_backoff(attempt)
                    continue
                last_err = f"status {status}"
                break
            finally:
                r.close()
        log.warning(f"Block fetch failed after {READ_MAX_ATTEMPTS} tries: {last_err}")
        return None

    def _refresh_cdn_url(self, hash_: str, filename: str, old_url: str) -> str | None:
        new_url = self._tm.refresh_cdn_url(hash_, filename)
        if new_url and new_url != old_url:
            _block_cache.invalidate_url(old_url)
            self._invalidate_files(hash_)
            log.info(f"CDN URL refreshed for {filename}")
            return new_url
        return old_url

    def _prefetch_block(self, cdn_url: str, block_idx: int, file_size: int):
        key = self._block_key(cdn_url, block_idx)
        if _block_cache.get(key) is not None:
            return
        with self._fetch_lock:
            if key in self._fetching:
                return
            self._fetching.add(key)
        def _do():
            try:
                self._fetch_block(cdn_url, block_idx, file_size)
            finally:
                with self._fetch_lock:
                    self._fetching.discard(key)
        threading.Thread(target=_do, daemon=True).start()

    def _note_read_and_should_prefetch(self, fh, offset, size) -> bool:
        if PREFETCH_SEQ_THRESHOLD <= 0:
            return True
        bs        = BLOCK_SIZE or (1024*1024)
        block_idx = offset // bs
        now       = time.time()
        with self._read_state_lock:
            if len(self._read_state) > 256:
                cutoff = now - 300
                for k in [k for k, v in self._read_state.items() if v["ts"] < cutoff]:
                    self._read_state.pop(k, None)
            st = self._read_state.get(fh)
            if st is None:
                st = {"next": -1, "block": -1, "run": 0, "ts": now}
                self._read_state[fh] = st
            contiguous = (st["next"] >= 0 and abs(offset - st["next"]) <= _SEQ_GAP_TOLERANCE)
            if contiguous and block_idx > st["block"]:
                st["run"] += 1
            elif not contiguous:
                st["run"] = 0
            st["block"] = block_idx
            st["next"]  = offset + size
            st["ts"]    = now
            return st["run"] >= PREFETCH_SEQ_THRESHOLD

    def read(self, path, size, offset, fh):
        try:
            return self._read_safe(path, size, offset, fh)
        except FuseOSError:
            raise
        except Exception as e:
            log.warning(f"read({path}): {e}", exc_info=True)
            raise FuseOSError(errno.EIO)

    def _read_safe(self, path, size, offset, fh=0):
        subdir, dirname, filename, hash_ = self._parse_path(path)
        if hash_ is None:
            raise FuseOSError(errno.ENOENT)

        if filename.lower().endswith(".nfo"):
            if _VIDEO_ONLY:
                raise FuseOSError(errno.ENOENT)
            video_name = os.path.splitext(filename)[0]
            for f in self._get_files_light(hash_):
                raw  = f.get("name","") or f.get("path","")
                name = os.path.basename(raw) if raw else raw
                if os.path.splitext(name)[0] == video_name and _include_file(name):
                    nfo = self._nfo_content(hash_, name)
                    if nfo:
                        return nfo[offset:offset+size]
            raise FuseOSError(errno.ENOENT)

        f = self._find_file(hash_, filename)
        if not f:
            raise FuseOSError(errno.ENOENT)

        if not self._tm.is_file_cdn_unlocked(hash_, filename):
            if not self._ensure_unlocked_for_read(hash_, filename, path):
                return self._serve_stub(filename, offset, size)
            refreshed = self._find_file(hash_, filename, force=True)
            if refreshed is None:
                # force=True came back with NO files at all for this hash —
                # not "this one link expired" but "AllDebrid has nothing for
                # this magnet anymore" (get_files() returned []). Using the
                # old `f` here would mean reading from a cdn_url that's
                # already known to be dead, which is exactly what produced
                # silent EIO failures (Plex's prober gets zero bytes on its
                # first read and reports Video: None / Audio: None, even
                # though metadata loaded fine from Plex's separate online
                # agent lookup). Try one inline recovery attempt — same
                # re-upload-by-hash logic as the scheduled repair loop —
                # before giving up and serving the stub gracefully.
                log.warning(f"[{hash_[:8]}] force re-fetch returned no files for "
                            f"{filename!r} — magnet likely purged, attempting inline repair")
                if self._try_inline_repair(hash_):
                    refreshed = self._find_file(hash_, filename, force=True)
                if refreshed is None:
                    self._tm._set(hash_, cdn_unlocked=0)
                    return self._serve_stub(filename, offset, size)
            f = refreshed

        cdn_url   = f.get("cdn_url") or f.get("link","")
        file_size = int(float(f.get("size", 0) or 0))
        if not cdn_url:
            raise FuseOSError(errno.EIO)

        block_idx = offset // BLOCK_SIZE
        cached    = _block_cache.get(self._block_key(cdn_url, block_idx))

        if cached is None:
            cached = self._fetch_block(cdn_url, block_idx, file_size, hash_=hash_, filename=filename)
            if cached is None:
                new_url = self._refresh_cdn_url(hash_, filename, cdn_url)
                if new_url and new_url != cdn_url:
                    cdn_url = new_url
                    cached  = self._fetch_block(cdn_url, block_idx, file_size, hash_=hash_, filename=filename)
            if cached is None:
                log.warning(f"FUSE read failed for {path} block {block_idx}")
                raise FuseOSError(errno.EIO)

        if _PREFETCH_ENABLED and file_size and self._note_read_and_should_prefetch(fh, offset, size):
            ahead = max(2, min(32, _READ_AHEAD_BYTES // BLOCK_SIZE))
            for a in range(1, ahead + 1):
                nb = block_idx + a
                if nb * BLOCK_SIZE < file_size:
                    self._prefetch_block(cdn_url, nb, file_size)

        block_start  = block_idx * BLOCK_SIZE
        slice_offset = offset - block_start
        chunk = cached[slice_offset:slice_offset+size]

        # Cross-block reads
        remaining = size - len(chunk)
        nb = block_idx + 1
        while remaining > 0 and nb * BLOCK_SIZE < file_size:
            nc = _block_cache.get(self._block_key(cdn_url, nb))
            if nc is None:
                nc = self._fetch_block(cdn_url, nb, file_size, hash_=hash_, filename=filename)
                if nc is None:
                    break
            chunk    += nc[:remaining]
            remaining -= len(nc[:remaining])
            nb        += 1

        return chunk

    @staticmethod
    def _read_backoff(attempt: int):
        time.sleep(min(READ_BACKOFF_BASE * (attempt + 1), READ_BACKOFF_CAP))

    def write(self, path, data, offset, fh): raise FuseOSError(errno.EROFS)
    def create(self, path, mode, fi=None):   raise FuseOSError(errno.EROFS)
    def unlink(self, path):                  raise FuseOSError(errno.EROFS)
    def mkdir(self, path, mode):             raise FuseOSError(errno.EROFS)
    def rmdir(self, path):                   raise FuseOSError(errno.EROFS)
    def rename(self, old, new):              raise FuseOSError(errno.EROFS)


# Keep the class accessible under the Premiumize name so qbt_mock.py and any
# other module that does `from fuse_mount import PremiumizeFS` still works.
PremiumizeFS = AllDebridFS


def _disk_cache_cleanup_pass(cache_dir: str) -> tuple[int, int]:
    """Delete on-disk cached blocks older than _CACHE_EXPIRY_SECONDS.

    Returns (files_removed, bytes_removed). Removes empty parent
    directories left behind once all their block files are gone.
    """
    if not cache_dir or not os.path.isdir(cache_dir):
        return 0, 0
    now = time.time()
    removed_files = 0
    removed_bytes = 0
    for entry in os.scandir(cache_dir):
        if not entry.is_dir(follow_symlinks=False):
            continue
        any_left = False
        try:
            for f in os.scandir(entry.path):
                try:
                    st = f.stat(follow_symlinks=False)
                except OSError:
                    continue
                if now - st.st_mtime > _CACHE_EXPIRY_SECONDS:
                    try:
                        os.remove(f.path)
                        removed_files += 1
                        removed_bytes += st.st_size
                    except OSError as e:
                        log.debug(f"[cache-cleanup] could not remove {f.path}: {e}")
                        any_left = True
                else:
                    any_left = True
        except OSError as e:
            log.debug(f"[cache-cleanup] could not scan {entry.path}: {e}")
            continue
        if not any_left:
            try:
                os.rmdir(entry.path)
            except OSError:
                pass
    return removed_files, removed_bytes


def _disk_cache_total_bytes(cache_dir: str) -> int:
    total = 0
    try:
        for entry in os.scandir(cache_dir):
            if entry.is_dir(follow_symlinks=False):
                for f in os.scandir(entry.path):
                    try:
                        total += f.stat(follow_symlinks=False).st_size
                    except OSError:
                        pass
    except OSError:
        pass
    return total


def _disk_cache_enforce_size_cap(cache_dir: str) -> tuple[int, int]:
    """Evict oldest-first (by mtime) until total disk usage is back under
    _DISK_CACHE_MAX_BYTES. Returns (files_removed, bytes_removed).
    """
    if not cache_dir or not os.path.isdir(cache_dir):
        return 0, 0
    total = _disk_cache_total_bytes(cache_dir)
    if total <= _DISK_CACHE_MAX_BYTES:
        return 0, 0

    files = []
    for entry in os.scandir(cache_dir):
        if not entry.is_dir(follow_symlinks=False):
            continue
        for f in os.scandir(entry.path):
            try:
                st = f.stat(follow_symlinks=False)
                files.append((st.st_mtime, f.path, st.st_size, entry.path))
            except OSError:
                pass
    files.sort(key=lambda x: x[0])  # oldest first

    removed_files = removed_bytes = 0
    touched_dirs = set()
    for _, path, size, parent in files:
        if total <= _DISK_CACHE_MAX_BYTES:
            break
        try:
            os.remove(path)
            total -= size
            removed_files += 1
            removed_bytes += size
            touched_dirs.add(parent)
        except OSError:
            pass

    for d in touched_dirs:
        try:
            if not os.listdir(d):
                os.rmdir(d)
        except OSError:
            pass

    return removed_files, removed_bytes


def _disk_cache_cleanup_loop():
    """Background thread: periodically expire old on-disk cache blocks and
    enforce the configured disk cache size cap.

    Reads _CACHE_EXPIRY_SECONDS / _CACHE_CLEANUP_SECONDS / _DISK_CACHE_MAX_BYTES
    fresh on every pass (not captured at thread-start time) so changing them
    via Settings → Save & Apply takes effect on the next cycle without
    needing a restart.
    """
    while True:
        try:
            time.sleep(_CACHE_CLEANUP_SECONDS)
        except Exception:
            time.sleep(1200)
            continue
        try:
            n, b = _disk_cache_cleanup_pass(_CACHE_DIR)
            if n:
                log.info(f"[cache-cleanup] removed {n} expired block(s), "
                         f"{b // (1024*1024)} MB freed from {_CACHE_DIR}")
            n2, b2 = _disk_cache_enforce_size_cap(_CACHE_DIR)
            if n2:
                log.info(f"[cache-cleanup] evicted {n2} oldest block(s), "
                         f"{b2 // (1024*1024)} MB freed to stay under "
                         f"{_DISK_CACHE_MAX_BYTES // (1024*1024)} MB cap")
        except Exception as e:
            log.warning(f"[cache-cleanup] pass failed: {e}")


def mount(mountpoint: str, transfer_manager, foreground=True):
    if not FUSE_AVAILABLE:
        log.error("fusepy not installed — cannot mount")
        return
    os.makedirs(mountpoint, exist_ok=True)
    log.info(f"Mounting AllDebrid FS at {mountpoint} "
             f"(block={BLOCK_SIZE//1024//1024}MB, cache={_CACHE_N} blocks, "
             f"prefetch={'on' if _PREFETCH_ENABLED else 'off'})")
    global _pfs
    _pfs = AllDebridFS(transfer_manager)
    threading.Thread(target=_disk_cache_cleanup_loop, daemon=True, name="fuse-cache-cleanup").start()
    try:
        hashes = transfer_manager.streamable_hashes()
        if hashes:
            log.info(f"[FUSE] Pre-warming file cache for {len(hashes)} transfers…")
            _pfs._prewarm_parallel(hashes, block=False)
    except Exception as e:
        log.warning(f"[FUSE] Startup pre-warm failed: {e}")
    try:
        FUSE(
            _pfs, mountpoint,
            nothreads=False, foreground=foreground,
            allow_other=True, nonempty=True, ro=True,
            attr_timeout=KERNEL_ATTR_TIMEOUT,
            entry_timeout=KERNEL_ENTRY_TIMEOUT,
            negative_timeout=10.0,
        )
    except Exception as e:
        log.error(f"FUSE mount exited with exception: {e}", exc_info=True)
        # The mount thread is about to die while the rest of the app (Flask,
        # the scheduler loops) keeps running — nothing else will notice this
        # happened or clean up after it. Best-effort unmount now so a crash
        # inside FUSE() doesn't leave an orphaned/broken mountpoint sitting
        # around until the next full container restart picks it up via
        # entrypoint.sh's stale-mount sweep.
        try:
            unmount()
        except Exception as ue:
            log.warning(f"[FUSE] cleanup after mount failure also failed: {ue}")
        raise
    log.info("FUSE mount exited cleanly")


# ── Unmount ───────────────────────────────────────────────────────────────────

def unmount():
    """Unmount the FUSE filesystem. Called by app.py on shutdown."""
    mp = None
    try:
        import subprocess
        if _pfs is None:
            return
        # Find the mountpoint from the global _pfs reference
        from app import _fuse_thread as _ft
    except Exception:
        pass
    try:
        import subprocess
        mp = os.environ.get("FUSE_MOUNTPOINT", "/docker/alldebrid-web/mnt")
        def _try(cmd):
            try:
                return subprocess.run(cmd, timeout=5, capture_output=True).returncode == 0
            except Exception:
                return False
        ok = (
            _try(["fusermount", "-u",  mp]) or
            _try(["fusermount", "-uz", mp]) or
            _try(["umount", mp]) or
            _try(["umount", "-l", mp])
        )
        if ok:
            log.info(f"Unmounted {mp}")
        else:
            log.warning(f"Could not unmount {mp}")
    except Exception as e:
        log.warning(f"unmount error: {e}")


# ── Mount settings (Mount Configuration panel in app.py) ─────────────────────
# These are no-ops or minimal stubs — the working version doesn't expose
# live settings editing, so app.py calls these but they don't need to do much.

_MOUNT_UID   = os.environ.get("FUSE_UID",    "").strip() or None
_MOUNT_GID   = os.environ.get("FUSE_GID",    "").strip() or None
_MOUNT_UMASK = os.environ.get("FUSE_UMASK",  "").strip() or None

_DISK_CACHE_MAX_BYTES  = _parse_size(os.environ.get("FUSE_DISK_CACHE_SIZE", "30GB"), 30*1024**3)

def _parse_duration(val: str, default: float) -> float:
    if not val:
        return default
    val = val.strip().lower().replace(" ", "")
    for suf, mult in {"d": 86400, "h": 3600, "m": 60, "s": 1}.items():
        if val.endswith(suf):
            try:
                return float(val[:-1]) * mult
            except ValueError:
                return default
    try:
        return float(val)
    except ValueError:
        return default

_CACHE_EXPIRY_SECONDS  = _parse_duration(os.environ.get("FUSE_CACHE_EXPIRY",           "24h"),  86400)
_CACHE_CLEANUP_SECONDS = _parse_duration(os.environ.get("FUSE_CACHE_CLEANUP_INTERVAL", "20m"),  1200)

_REMOUNT_REQUIRED_KEYS = {"uid", "gid", "umask", "cache_dir"}


def settings_need_remount(new: dict) -> bool:
    """Return True if any setting requires unmount+remount to take effect."""
    global _MOUNT_UID, _MOUNT_GID, _MOUNT_UMASK, _CACHE_DIR
    for key in _REMOUNT_REQUIRED_KEYS:
        if key not in new:
            continue
        cur = {"uid": _MOUNT_UID, "gid": _MOUNT_GID,
               "umask": _MOUNT_UMASK, "cache_dir": _CACHE_DIR}.get(key)
        nv  = str(new[key]) if new.get(key) else None
        if cur != nv:
            return True
    return False


def apply_mount_options(settings: dict):
    """Apply uid/gid/umask/cache_dir — only take effect at next mount()."""
    global _MOUNT_UID, _MOUNT_GID, _MOUNT_UMASK, _CACHE_DIR, _block_cache
    if "uid" in settings:
        _MOUNT_UID = str(settings["uid"]) if settings.get("uid") else None
    if "gid" in settings:
        _MOUNT_GID = str(settings["gid"]) if settings.get("gid") else None
    if "umask" in settings:
        _MOUNT_UMASK = (settings.get("umask") or "").strip() or None
    if "cache_dir" in settings and (settings.get("cache_dir") or "").strip():
        _CACHE_DIR = settings["cache_dir"].strip()
        os.makedirs(_CACHE_DIR, exist_ok=True)
        _block_cache = _BlockCache(_CACHE_N, _CACHE_DIR)


def apply_runtime_settings(settings: dict):
    """Apply settings that take effect immediately without remount."""
    global BLOCK_SIZE, _RA_MB, _READ_AHEAD_BYTES, _PREFETCH_ENABLED, _VIDEO_ONLY
    global _CACHE_N, _CACHE_EXPIRY_SECONDS, _CACHE_CLEANUP_SECONDS, _DISK_CACHE_MAX_BYTES

    if "chunk_size" in settings:
        _RA_MB      = _parse_size(str(settings["chunk_size"]), _RA_MB * 1024 * 1024) // (1024 * 1024)
        BLOCK_SIZE  = _RA_MB * 1024 * 1024
    if "read_ahead" in settings:
        _READ_AHEAD_BYTES = _parse_size(str(settings["read_ahead"]), _READ_AHEAD_BYTES)
    if "prefetch" in settings:
        _PREFETCH_ENABLED = bool(settings["prefetch"])
    if "video_only" in settings:
        _VIDEO_ONLY = bool(settings["video_only"])
    if "buffer_memory" in settings:
        mem = _parse_size(str(settings["buffer_memory"]), _CACHE_N * BLOCK_SIZE)
        _CACHE_N = max(1, mem // max(BLOCK_SIZE, 1))
    if "disk_cache_size" in settings:
        _DISK_CACHE_MAX_BYTES = _parse_size(str(settings["disk_cache_size"]), _DISK_CACHE_MAX_BYTES)
    if "cache_expiry" in settings:
        _CACHE_EXPIRY_SECONDS = _parse_duration(str(settings["cache_expiry"]), _CACHE_EXPIRY_SECONDS)
    if "cache_cleanup" in settings:
        _CACHE_CLEANUP_SECONDS = _parse_duration(str(settings["cache_cleanup"]), _CACHE_CLEANUP_SECONDS)


def get_current_settings() -> dict:
    """Return current live settings for the Mount Configuration panel."""
    return {
        "chunk_size":      f"{BLOCK_SIZE // 1024 // 1024}MB",
        "read_ahead":      f"{_READ_AHEAD_BYTES // 1024 // 1024}MB",
        "buffer_memory":   f"{(_CACHE_N * BLOCK_SIZE) // 1024 // 1024}MB",
        "disk_cache_size": f"{_DISK_CACHE_MAX_BYTES // 1024 // 1024 // 1024}GB",
        "cache_expiry":    f"{int(_CACHE_EXPIRY_SECONDS // 3600)}h",
        "cache_cleanup":   f"{int(_CACHE_CLEANUP_SECONDS // 60)}m",
        "daemon_timeout":  f"{READ_TIMEOUT}s",
        "prefetch":        _PREFETCH_ENABLED,
        "video_only":      _VIDEO_ONLY,
        "cache_dir":       _CACHE_DIR,
        "uid":             _MOUNT_UID,
        "gid":             _MOUNT_GID,
        "umask":           _MOUNT_UMASK,
        "cached_blocks":   _block_cache.size,
        "max_blocks":      _CACHE_N,
    }
