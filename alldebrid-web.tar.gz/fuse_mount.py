"""
AllDebrid virtual filesystem using FUSE.

Directory structure mirrors premiumize-web exactly:
  /docker/alldebrid-web/mnt/
    movies/   <torrent name>/<filename>.mkv
    series/   <show name>/<episode>.mkv
    movies4k/ ...
    series4k/ ...

CDN URLs come from the `files` table (populated by transfer_manager.get_files
which calls AllDebrid link/unlock once per file and caches the result).
URLs are refreshed only when a real playback read returns 403/410.

Block-cache, read-ahead, analysis-aware prefetch gate, and all FUSE ops are
identical to the Premiumize version — only the "get CDN URL" path differs.
"""

import errno
import hashlib
import logging
import os
import re
import signal
import atexit
import stat
import threading
import time
from collections import OrderedDict

import requests

log = logging.getLogger(__name__)

# ── CDN URL cache timings ──────────────────────────────────────────────────────
DIRECTDL_TTL   = 172800   # 48 h — AllDebrid unlocked links last at least 48h
REFRESH_MARGIN = 3600     # background refresh 1 h before expiry

# ── HTTP retry ────────────────────────────────────────────────────────────────
# NOTE: READ_TIMEOUT, BLOCK_SIZE, _CACHE_N, _PREFETCH_ENABLED, _VIDEO_ONLY,
# _READ_AHEAD_BYTES, _DISK_CACHE_MAX_BYTES, and _CACHE_EXPIRY_SECONDS below
# are all genuinely mutable at runtime — apply_runtime_settings() (further
# down) updates them live from the web UI's Mount Configuration panel via
# `global` reassignment. They start from env vars only as first-boot
# defaults, mirroring how they worked before settings became live-editable.
READ_TIMEOUT      = int(os.environ.get("FUSE_READ_TIMEOUT", "10"))
READ_MAX_ATTEMPTS = 5
READ_BACKOFF_BASE = 0.5
READ_BACKOFF_CAP  = 4.0

# ── Block cache / read-ahead ──────────────────────────────────────────────────
_RA_MB            = int(os.environ.get("FUSE_READAHEAD_MB",  "8"))
_CACHE_N          = int(os.environ.get("FUSE_CACHE_BLOCKS", "64"))
_PREFETCH_ENABLED = os.environ.get("FUSE_PREFETCH", "true").lower() != "false"
_CACHE_DIR        = os.environ.get("FUSE_CACHE_DIR", "/docker/alldebrid-web/cache").strip()
_VIDEO_ONLY       = os.environ.get("FUSE_VIDEO_ONLY", "true").lower() != "false"
_AUTO_UNLOCK_ON_READ  = os.environ.get("FUSE_AUTO_UNLOCK_ON_READ",  "false").lower() not in ("0","false","no")
_PREWARM_ON_UNLOCK    = os.environ.get("FUSE_PREWARM_ON_UNLOCK",    "false").lower() not in ("0","false","no")

BLOCK_SIZE = _RA_MB * 1024 * 1024

PREFETCH_SEQ_THRESHOLD = int(os.environ.get("FUSE_PREFETCH_SEQ_THRESHOLD", "2"))
_SEQ_GAP_TOLERANCE     = 1 * 1024 * 1024

def _parse_size(val: str, default: int) -> int:
    if not val:
        return default
    val = val.strip().upper().replace(" ", "")
    for sfx, mult in sorted({"TB":1024**4,"GB":1024**3,"MB":1024**2,"KB":1024,"B":1}.items(), key=lambda x:-len(x[0])):
        if val.endswith(sfx):
            try:
                return int(float(val[:-len(sfx)]) * mult)
            except ValueError:
                return default
    try:
        return int(val)
    except ValueError:
        return default

def _parse_duration(val: str, default: float) -> float:
    """Parse '24h', '1d', '20m', '10s', '90' (bare seconds) into seconds."""
    if not val:
        return default
    val = val.strip().lower().replace(" ", "")
    units = {"d": 86400, "h": 3600, "m": 60, "s": 1}
    for suf, mult in units.items():
        if val.endswith(suf):
            try:
                return float(val[:-1]) * mult
            except ValueError:
                return default
    try:
        return float(val)
    except ValueError:
        return default

_READ_AHEAD_BYTES = _parse_size(os.environ.get("FUSE_READ_AHEAD", "500MB"), 500*1024*1024)

# Disk cache enforcement (genuinely new — previously unbounded and never expired).
_DISK_CACHE_MAX_BYTES   = _parse_size(os.environ.get("FUSE_DISK_CACHE_SIZE", "30GB"), 30*1024**3)
_CACHE_EXPIRY_SECONDS   = _parse_duration(os.environ.get("FUSE_CACHE_EXPIRY", "24h"), 86400)
_CACHE_CLEANUP_SECONDS  = _parse_duration(os.environ.get("FUSE_CACHE_CLEANUP_INTERVAL", "20m"), 1200)

# Mount-time-only options (UID/GID/UMASK) — these are real libfuse mount
# options that fusepy passes straight through to `-o key=value` on the
# underlying mount(8) call. They can only take effect at the moment FUSE()
# is constructed, so changing them triggers an actual unmount+remount
# rather than a live in-process update.
_MOUNT_UID   = os.environ.get("FUSE_UID", "").strip() or None
_MOUNT_GID   = os.environ.get("FUSE_GID", "").strip() or None
_MOUNT_UMASK = os.environ.get("FUSE_UMASK", "").strip() or None

VIDEO_EXTENSIONS = {".mkv",".mp4",".avi",".mov",".m4v",".ts",".wmv",".flv",".webm",".m2ts",".mpg",".mpeg"}
EXTRA_PATTERNS   = re.compile(r'(?i)(^|\b)(sample|trailer|featurette|behind.the.scenes|deleted.scene|interview|short|scene|extra)s?(\b|$)')

def _is_video(fn: str) -> bool:
    return os.path.splitext(fn)[1].lower() in VIDEO_EXTENSIONS

def _is_extra(fn: str) -> bool:
    return bool(EXTRA_PATTERNS.search(os.path.splitext(fn)[0]))

def _include_file(fn: str) -> bool:
    if not _VIDEO_ONLY:
        return True
    return _is_video(fn) and not _is_extra(fn)

NAME_MAP_TTL  = 60
STAT_CACHE_TTL = 300
KERNEL_ATTR_TIMEOUT  = float(os.environ.get("FUSE_ATTR_TIMEOUT",  "30"))
KERNEL_ENTRY_TIMEOUT = float(os.environ.get("FUSE_ENTRY_TIMEOUT", "30"))
DIRECTDL_WORKERS     = int(os.environ.get("FUSE_DIRECTDL_WORKERS", "2"))

_UNLOCK_LOGGED: set  = set()
_UNLOCK_LOG_LOCK     = threading.Lock()

try:
    from fuse import FUSE, FuseOSError, Operations
    FUSE_AVAILABLE = True
except (ImportError, OSError, EnvironmentError) as _fuse_err:
    FUSE_AVAILABLE = False
    log.warning(f"fusepy unavailable ({_fuse_err}) — FUSE mount disabled")
    # AllDebridFS(Operations) below would raise NameError at class-definition
    # time (module import) without this fallback — better to fail loudly and
    # specifically inside mount() (which already checks FUSE_AVAILABLE) than
    # to crash the whole module import.
    class Operations:  # type: ignore
        pass
    class FuseOSError(Exception):  # type: ignore
        def __init__(self, errno_):
            super().__init__(errno_)
            self.errno = errno_

def _safe_name(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name)
    return name.strip('. ')[:200] or "unknown"

import re as _re
from name_match import _SERIES_RE, _4K_RE

_4K_FOLDERS_ENABLED = False
# ── In-process FUSE instance (for cleanup on shutdown) ─────────────────────────
_pfs = None
_fuse_instance = None
_mount_point = None

def _cleanup_fuse():
    """Unmount FUSE cleanly on shutdown.

    Safe to call multiple times and safe to call even if nothing was ever
    mounted. Does NOT pre-check with os.path.exists()/os.stat() — on a
    wedged "Transport endpoint is not connected" mount (the same condition
    entrypoint.sh already guards against on startup), a stat call can raise
    instead of cleanly returning False, so we just attempt the unmount
    directly and let it no-op if there's nothing there.
    """
    global _pfs, _fuse_instance, _mount_point
    mp = _mount_point
    if not mp:
        return
    log.info(f"Cleaning up FUSE mount at {mp}...")
    import subprocess

    def _try(cmd, timeout=5):
        try:
            result = subprocess.run(cmd, timeout=timeout, capture_output=True, check=False)
            return result.returncode == 0
        except Exception as e:
            log.debug(f"{' '.join(cmd)} failed: {e}")
            return False

    # Graceful first (brief — a busy mount shouldn't block shutdown for
    # long), then lazy (detaches immediately regardless of busy handles,
    # so this should always succeed near-instantly), then force as a last
    # resort. Mirrors entrypoint.sh's startup cleanup so shutdown is at
    # least as robust as startup.
    ok = (
        _try(["fusermount", "-u", mp], timeout=3)
        or _try(["fusermount", "-uz", mp], timeout=3)
        or _try(["umount", mp], timeout=3)
        or _try(["umount", "-l", mp], timeout=3)
    )
    if ok:
        log.info(f"Successfully unmounted {mp}")
    else:
        log.warning(f"Could not unmount {mp} — it may already be unmounted, "
                     f"or will be cleaned up by entrypoint.sh on next container start")

    _pfs = None
    _fuse_instance = None
    _mount_point = None
    log.info("FUSE cleanup complete")


_overrides: dict = {}
_re_nonalnum = re.compile(r'[^a-z0-9]')

def _override_key(name: str) -> str:
    return _re_nonalnum.sub('', (name or '').lower())

def _category_subdir(name: str, category: str = "", kind: str = "") -> str:
    key = _override_key(name)
    if key in _overrides:
        is_s = _overrides[key]["kind"] == "series"
        if _4K_FOLDERS_ENABLED and _4K_RE.search(name or ""):
            return "series4k" if is_s else "movies4k"
        return "series" if is_s else "movies"
    if kind in ("series", "movie"):
        is_s = kind == "series"
        if _4K_FOLDERS_ENABLED and _4K_RE.search(name or ""):
            return "series4k" if is_s else "movies4k"
        return "series" if is_s else "movies"
    is_s = bool(_SERIES_RE.search(name or ""))
    cat = (category or "").lower()
    if not is_s:
        is_s = any(k in cat for k in ("sonarr","tv","series","show"))
    if _4K_FOLDERS_ENABLED and _4K_RE.search(name or ""):
        return "series4k" if is_s else "movies4k"
    return "series" if is_s else "movies"


def build_name_map(transfer_manager) -> dict:
    result = {}
    try:
        from name_match import classify_from_files as _clf
        _clf_available = True
    except Exception:
        _clf_available = False
    try:
        hashes = transfer_manager.streamable_hashes()
    except Exception as e:
        log.warning(f"build_name_map: streamable_hashes failed: {e}")
        return result
    _hash_re = re.compile(r'^[0-9a-f]{32,64}$', re.IGNORECASE)
    for h in hashes:
        try:
            t = transfer_manager.get_transfer(h)
            if not t:
                continue
            stored_kind = t.get("kind", "")
            stored_name = t.get("name") or ""
            # Resolve hash-only names from cached file list
            if not stored_name or _hash_re.match(stored_name.strip()):
                if _pfs is not None:
                    cached = _pfs._file_cache.get(h)
                    if cached:
                        files_c, _ = cached
                        tops = [f.get("path","").split("/")[0] for f in files_c if f.get("path")]
                        tops = [t for t in tops if t and not _hash_re.match(t)]
                        if tops:
                            import collections as _coll
                            resolved = _coll.Counter(tops).most_common(1)[0][0]
                            base_r, ext_r = os.path.splitext(resolved)
                            if ext_r.lower() in (".mkv",".mp4",".avi",".ts",".m4v"):
                                resolved = base_r
                            if resolved:
                                stored_name = resolved
                                try:
                                    transfer_manager._set(h, name=resolved)
                                except Exception:
                                    pass
            if not stored_kind and _clf_available and _pfs is not None:
                cached = _pfs._file_cache.get(h)
                if cached:
                    files_c, _ = cached
                    try:
                        inferred = _clf(files_c)
                        if inferred:
                            stored_kind = inferred
                            try:
                                transfer_manager._set(h, kind=inferred)
                            except Exception:
                                pass
                    except Exception:
                        pass
            base   = _safe_name(stored_name or h)
            subdir = _category_subdir(stored_name or "", t.get("category",""), kind=stored_kind)
            key    = f"{subdir}/{base}"
            if key in result:
                key = f"{subdir}/{base}_{h[:8]}"
            result[key] = h
        except Exception as e:
            log.warning(f"build_name_map: error for {h[:8]}: {e}")
    return result


def dir_name_for_hash(transfer_manager, hash_: str):
    for nm, h in build_name_map(transfer_manager).items():
        if h == hash_:
            return nm
    return None

# ── Disk block cache path ─────────────────────────────────────────────────────

def _disk_block_path(cache_dir: str, cdn_url: str, block_idx: int) -> str:
    url_hash = hashlib.sha256(cdn_url.encode()).hexdigest()[:16]
    return os.path.join(cache_dir, url_hash, f"{block_idx}.bin")

# ── LRU block cache ───────────────────────────────────────────────────────────

class _BlockCache:
    """In-memory LRU (bounded by block count, derived from the Buffer Memory
    setting) plus an on-disk cache (bounded by Disk Cache Size, expired by
    Cache Expiry). Both disk limits are enforced by a periodic sweep
    (_disk_cleanup_sweep, run from a background thread at Cache Cleanup
    Interval) rather than on every write, since checking total directory
    size on every single block write would be far too slow.
    """
    def __init__(self, max_blocks: int, cache_dir: str = ""):
        self._max       = max_blocks
        self._cache_dir = cache_dir
        self._lock      = threading.Lock()
        self._store: OrderedDict = OrderedDict()

    def set_max_blocks(self, max_blocks: int):
        """Resize the in-memory budget live (Buffer Memory setting)."""
        with self._lock:
            self._max = max(1, max_blocks)
            while len(self._store) > self._max:
                self._store.popitem(last=False)

    def get(self, key):
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
                return self._store[key]
        if self._cache_dir:
            cdn_url, block_idx = key
            path = _disk_block_path(self._cache_dir, cdn_url, block_idx)
            try:
                # Expiry check: a disk block older than _CACHE_EXPIRY_SECONDS
                # is treated as a miss and removed, forcing a re-fetch —
                # this is the actual "Cache Expiry" setting taking effect.
                age = time.time() - os.path.getmtime(path)
                if _CACHE_EXPIRY_SECONDS > 0 and age > _CACHE_EXPIRY_SECONDS:
                    try: os.remove(path)
                    except OSError: pass
                    return None
                with open(path, "rb") as f:
                    data = f.read()
                self.put(key, data, _skip_disk_write=True)
                return data
            except (FileNotFoundError, OSError):
                pass
        return None

    def put(self, key, data: bytes, _skip_disk_write: bool = False):
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
            else:
                self._store[key] = data
                while len(self._store) > self._max:
                    self._store.popitem(last=False)
        if self._cache_dir and not _skip_disk_write:
            cdn_url, block_idx = key
            path = _disk_block_path(self._cache_dir, cdn_url, block_idx)
            try:
                os.makedirs(os.path.dirname(path), exist_ok=True)
                tmp = path + ".tmp"
                with open(tmp, "wb") as f:
                    f.write(data)
                os.replace(tmp, path)
            except OSError as e:
                log.debug(f"Disk cache write failed: {e}")

    def invalidate_url(self, cdn_url: str):
        with self._lock:
            for k in [k for k in self._store if k[0] == cdn_url]:
                del self._store[k]
        if self._cache_dir:
            url_hash = hashlib.sha256(cdn_url.encode()).hexdigest()[:16]
            import shutil
            shutil.rmtree(os.path.join(self._cache_dir, url_hash), ignore_errors=True)

    @property
    def size(self):
        with self._lock:
            return len(self._store)

    def disk_cleanup_sweep(self) -> dict:
        """Enforce Cache Expiry (delete anything older than the TTL) and
        Disk Cache Size (once under the TTL, if still over budget, delete
        oldest-by-mtime blocks until under budget). Returns stats for
        logging. Safe to call from a background thread — only touches
        files, no in-memory state lock held during disk I/O.
        """
        cache_dir = self._cache_dir
        if not cache_dir or not os.path.isdir(cache_dir):
            return {"expired": 0, "evicted": 0, "total_bytes": 0}
        now = time.time()
        entries = []  # (path, mtime, size)
        for root, _, files in os.walk(cache_dir):
            for fn in files:
                if not fn.endswith(".bin"):
                    continue
                p = os.path.join(root, fn)
                try:
                    st = os.stat(p)
                    entries.append((p, st.st_mtime, st.st_size))
                except OSError:
                    continue

        expired = 0
        if _CACHE_EXPIRY_SECONDS > 0:
            kept = []
            for p, mtime, size in entries:
                if now - mtime > _CACHE_EXPIRY_SECONDS:
                    try:
                        os.remove(p)
                        expired += 1
                    except OSError:
                        pass
                else:
                    kept.append((p, mtime, size))
            entries = kept

        total_bytes = sum(size for _, _, size in entries)
        evicted = 0
        if _DISK_CACHE_MAX_BYTES > 0 and total_bytes > _DISK_CACHE_MAX_BYTES:
            entries.sort(key=lambda e: e[1])  # oldest mtime first
            for p, mtime, size in entries:
                if total_bytes <= _DISK_CACHE_MAX_BYTES:
                    break
                try:
                    os.remove(p)
                    total_bytes -= size
                    evicted += 1
                except OSError:
                    pass

        # Clean up now-empty per-URL subdirectories left behind
        for entry in os.scandir(cache_dir):
            if entry.is_dir():
                try:
                    if not os.listdir(entry.path):
                        os.rmdir(entry.path)
                except OSError:
                    pass

        return {"expired": expired, "evicted": evicted, "total_bytes": total_bytes}


_block_cache = _BlockCache(_CACHE_N, _CACHE_DIR)

_cleanup_thread_started = False
_cleanup_wake = threading.Event()

def _disk_cleanup_loop():
    """Background sweep — runs at _CACHE_CLEANUP_SECONDS interval. The
    interval is re-read each iteration so changing Cache Cleanup Interval
    takes effect on the very next cycle without needing a restart."""
    while True:
        interval = max(10, _CACHE_CLEANUP_SECONDS)
        _cleanup_wake.wait(timeout=interval)
        _cleanup_wake.clear()
        try:
            stats = _block_cache.disk_cleanup_sweep()
            if stats["expired"] or stats["evicted"]:
                log.info(f"[cache-cleanup] expired={stats['expired']} "
                          f"evicted(over-budget)={stats['evicted']} "
                          f"total={stats['total_bytes']//1024//1024}MB")
        except Exception:
            log.exception("[cache-cleanup] sweep failed")

def _start_cleanup_thread():
    global _cleanup_thread_started
    if _cleanup_thread_started:
        return
    _cleanup_thread_started = True
    threading.Thread(target=_disk_cleanup_loop, daemon=True, name="fuse-cache-cleanup").start()


class AllDebridFS(Operations):
    """
    FUSE filesystem backed by AllDebrid CDN.

    Identical structure to PremiumizeFS — the only functional difference is
    that CDN URLs are stored in the `files` DB table (populated by
    transfer_manager.get_files / link/unlock) rather than fetched fresh from
    a directdl endpoint on every FUSE readdir.
    """

    def __init__(self, transfer_manager):
        self._tm   = transfer_manager
        self._now  = time.time()
        self._lock = threading.Lock()

        self._file_cache: dict[str, tuple[list, float]] = {}
        self._refreshing: set = set()
        self._fetching:   set = set()
        self._fetch_lock  = threading.Lock()

        self._read_state: dict[int, dict] = {}
        self._read_state_lock             = threading.Lock()

        self._fh_counter: int = 0
        self._fh_lock         = threading.Lock()

        self._name_map:         dict  = {}
        self._name_map_expires: float = 0.0
        self._name_map_lock           = threading.Lock()

        self._stat_cache: dict[str, tuple[dict, float]] = {}
        self._stat_lock                                  = threading.Lock()

    # ── Name map ──────────────────────────────────────────────────────────────

    def _get_name_map(self) -> dict:
        now = time.time()
        with self._name_map_lock:
            if now < self._name_map_expires:
                return self._name_map
        nm = build_name_map(self._tm)
        with self._name_map_lock:
            self._name_map         = nm
            self._name_map_expires = now + NAME_MAP_TTL
        return nm

    def _invalidate_name_map(self):
        with self._name_map_lock:
            self._name_map_expires = 0.0

    # ── Stat cache ────────────────────────────────────────────────────────────

    def _stat_get(self, path: str):
        now = time.time()
        with self._stat_lock:
            entry = self._stat_cache.get(path)
            if entry and now < entry[1]:
                return entry[0]
        return None

    def _stat_put(self, path: str, st: dict):
        with self._stat_lock:
            self._stat_cache[path] = (st, time.time() + STAT_CACHE_TTL)

    def _stat_invalidate(self, path: str):
        with self._stat_lock:
            self._stat_cache.pop(path, None)

    def _stat_invalidate_all(self):
        with self._stat_lock:
            self._stat_cache.clear()

    # ── File list (CDN URLs from DB via transfer_manager.get_files) ───────────

    def _get_files(self, hash_: str, force: bool = False) -> list:
        """
        Return the unlocked file list for hash.

        Checks the in-process FUSE cache first (TTL=48h), then delegates to
        transfer_manager.get_files which reads from the persistent `files` DB
        table (populated by link/unlock on first access).
        """
        now = time.time()
        if not force:
            with self._lock:
                cached = self._file_cache.get(hash_)
            if cached:
                files, expires_at = cached
                if now < expires_at - REFRESH_MARGIN:
                    return files
                if now < expires_at:
                    self._spawn_refresh(hash_)
                    return files

        files = self._tm.get_files(hash_, force=force)
        if files:
            with self._lock:
                self._file_cache[hash_] = (files, now + DIRECTDL_TTL)
        return files

    def _spawn_refresh(self, hash_: str):
        with self._lock:
            if hash_ in self._refreshing:
                return
            self._refreshing.add(hash_)
        def _do():
            try:
                files = self._tm.get_files(hash_, force=True)
                if files:
                    with self._lock:
                        self._file_cache[hash_] = (files, time.time() + DIRECTDL_TTL)
            except Exception:
                log.warning(f"[{hash_[:8]}] background refresh failed", exc_info=True)
            finally:
                with self._lock:
                    self._refreshing.discard(hash_)
        threading.Thread(target=_do, daemon=True).start()

    def _invalidate_files(self, hash_: str):
        with self._lock:
            self._file_cache.pop(hash_, None)

    def _prewarm_parallel(self, hashes: list, block: bool = False):
        from concurrent.futures import ThreadPoolExecutor, as_completed
        def _fetch_one(h):
            if h in self._file_cache:
                files, exp = self._file_cache[h]
                if time.time() < exp:
                    return
            files = self._tm.get_files(h)
            if files:
                with self._lock:
                    self._file_cache[h] = (files, time.time() + DIRECTDL_TTL)
        pool = ThreadPoolExecutor(max_workers=DIRECTDL_WORKERS, thread_name_prefix="fuse-prewarm")
        futures = [pool.submit(_fetch_one, h) for h in hashes]
        pool.shutdown(wait=block)
        if not block:
            def _log_errs():
                for f in as_completed(futures):
                    try:
                        f.result()
                    except Exception as e:
                        log.debug(f"[prewarm] {e}")
            threading.Thread(target=_log_errs, daemon=True).start()

    # ── Path helpers ──────────────────────────────────────────────────────────

    def _parse_path(self, path):
        parts = [p for p in path.split("/") if p]
        if not parts:
            return None, None, None, None
        if parts[0] in ("movies","series","movies4k","series4k"):
            subdir   = parts[0]
            dirname  = parts[1] if len(parts) > 1 else None
            filename = "/".join(parts[2:]) if len(parts) > 2 else None
        else:
            subdir   = None
            dirname  = parts[0]
            filename = "/".join(parts[1:]) if len(parts) > 1 else None
        if dirname is None:
            return subdir, None, None, None
        key   = f"{subdir}/{dirname}" if subdir else dirname
        hash_ = self._get_name_map().get(key)
        return subdir, dirname, filename, hash_

    def _find_file(self, hash_: str, filename: str, force: bool = False):
        for f in self._get_files(hash_, force=force):
            f_name = f.get("name","")
            f_base = os.path.basename(f.get("path","") or f_name)
            if f_name == filename or f_base == filename:
                return f
        return None

    # ── FUSE ops ──────────────────────────────────────────────────────────────

    def getattr(self, path, fh=None):
        try:
            return self._getattr_safe(path)
        except FuseOSError:
            raise
        except Exception as e:
            log.warning(f"getattr({path}): {e}", exc_info=True)
            raise FuseOSError(errno.ENOENT)

    def _getattr_safe(self, path):
        cached = self._stat_get(path)
        if cached is not None:
            return cached

        base = {
            "st_uid": os.getuid(), "st_gid": os.getgid(),
            "st_atime": self._now, "st_mtime": self._now, "st_ctime": self._now,
            "st_nlink": 2,
        }

        if path == "/":
            st = {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
            self._stat_put(path, st); return st

        _valid = {"/movies", "/series"}
        if _4K_FOLDERS_ENABLED:
            _valid |= {"/movies4k", "/series4k"}
        if path in _valid:
            st = {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
            self._stat_put(path, st); return st

        subdir, dirname, filename, hash_ = self._parse_path(path)

        if not filename:
            if hash_ is not None:
                st = {**base, "st_mode": stat.S_IFDIR | 0o755, "st_size": 0}
                self._stat_put(path, st); return st
            raise FuseOSError(errno.ENOENT)

        if hash_ is None:
            raise FuseOSError(errno.ENOENT)

        if filename.lower().endswith(".nfo"):
            if _VIDEO_ONLY:
                raise FuseOSError(errno.ENOENT)
            video_name = os.path.splitext(filename)[0]
            for f in self._get_files(hash_):
                raw  = f.get("name","") or f.get("path","")
                name = os.path.basename(raw) if raw else raw
                if os.path.splitext(name)[0] == video_name and _include_file(name):
                    nfo = self._nfo_content(hash_, name)
                    st  = {**base, "st_mode": stat.S_IFREG | 0o444, "st_nlink": 1,
                           "st_size": len(nfo) if nfo else 256}
                    self._stat_put(path, st); return st
            raise FuseOSError(errno.ENOENT)

        f = self._find_file(hash_, filename)
        if not f:
            raise FuseOSError(errno.ENOENT)
        if not _include_file(filename):
            raise FuseOSError(errno.ENOENT)

        file_size = int(float(f.get("size", 0) or 0))
        if file_size == 0:
            raise FuseOSError(errno.ENOENT)

        if not self._tm.is_file_cdn_unlocked(hash_, filename):
            try:
                from qbt_mock import _stub_bytes_for
                stub = _stub_bytes_for(filename)
                reported_size = len(stub) if stub else file_size
            except Exception:
                reported_size = file_size
            mtime = self._now
        else:
            reported_size = file_size
            try:
                t = self._tm.get_transfer(hash_)
                mtime = float(t.get("streamable_at") or t.get("added_at") or self._now)
            except Exception:
                mtime = self._now

        st = {**base, "st_mode": stat.S_IFREG | 0o444, "st_nlink": 1,
              "st_size": reported_size, "st_mtime": mtime, "st_ctime": mtime}
        self._stat_put(path, st)
        return st

    def readdir(self, path, fh):
        try:
            return self._readdir_safe(path)
        except Exception as e:
            log.error(f"readdir({path}): {e}", exc_info=True)
            return [".", ".."]

    def _readdir_safe(self, path):
        entries = [".", ".."]
        if path == "/":
            entries += ["movies", "series"]
            if _4K_FOLDERS_ENABLED:
                entries += ["movies4k", "series4k"]
            return entries
        valid = ["/movies", "/series"]
        if _4K_FOLDERS_ENABLED:
            valid += ["/movies4k", "/series4k"]
        if path in valid:
            subdir = path.lstrip("/")
            nm     = self._get_name_map()
            names, hashes = [], []
            for key in nm:
                if key.startswith(subdir + "/"):
                    names.append(key[len(subdir)+1:])
                    hashes.append(nm[key])
            uncached = [h for h in hashes
                        if h not in self._file_cache or time.time() >= self._file_cache[h][1]]
            if uncached:
                self._prewarm_parallel(uncached)
            entries += names
            return entries
        subdir, dirname, _, hash_ = self._parse_path(path)
        if hash_:
            try:
                files = self._get_files(hash_)
            except Exception:
                files = []
            for f in files:
                raw  = f.get("name","") or f.get("path","")
                name = os.path.basename(raw) if raw else raw
                if not name:
                    continue
                try:
                    size = int(float(f.get("size", 0) or 0))
                except (ValueError, TypeError):
                    size = 0
                if _include_file(name) and size > 0:
                    entries.append(name)
                    if not _VIDEO_ONLY:
                        entries.append(os.path.splitext(name)[0] + ".nfo")
        return entries

    def _nfo_content(self, hash_: str, filename: str) -> bytes | None:
        try:
            from qbt_mock import _parse_stub_meta, _make_nfo_content
            return _make_nfo_content(_parse_stub_meta(filename)).encode("utf-8")
        except Exception:
            return None

    def open(self, path, flags):
        try:
            subdir, dirname, filename, hash_ = self._parse_path(path)
            if not filename or hash_ is None:
                raise FuseOSError(errno.ENOENT)
            if filename.lower().endswith(".nfo"):
                if _VIDEO_ONLY:
                    raise FuseOSError(errno.ENOENT)
                return 0
            f = self._find_file(hash_, filename)
            if not f or int(float(f.get("size", 0) or 0)) == 0:
                raise FuseOSError(errno.ENOENT)
            with self._fh_lock:
                self._fh_counter += 1
                fh = self._fh_counter
            return fh
        except FuseOSError:
            raise
        except Exception as e:
            log.warning(f"open({path}): {e}")
            raise FuseOSError(errno.ENOENT)

    def release(self, path, fh):
        with self._read_state_lock:
            self._read_state.pop(fh, None)
        return 0

    # ── Block cache read ──────────────────────────────────────────────────────

    def _block_key(self, cdn_url: str, block_idx: int):
        return (cdn_url, block_idx)

    def _ensure_unlocked_for_read(self, hash_: str, filename: str, path: str) -> bool:
        # Re-check the DB each call — _on_ready may have just set cdn_unlocked=1
        # while our stat cache still reports stub size. If already unlocked,
        # invalidate the stat so the next getattr returns the real file size.
        if self._tm.is_file_cdn_unlocked(hash_, filename):
            self._stat_invalidate(path)
            return True
        if not _AUTO_UNLOCK_ON_READ:
            return False
        ok = False
        try:
            ok = bool(self._tm.unlock_file_cdn(hash_, filename))
        except Exception as e:
            log.warning(f"[auto-unlock] failed hash={hash_[:8]} file={filename}: {e}")
            return False
        self._stat_invalidate(path)
        self._invalidate_files(hash_)
        f = None
        files = self._get_files(hash_, force=True) or []
        for cand in files:
            raw  = cand.get("name","") or cand.get("path","")
            base = os.path.basename(raw) if raw else raw
            if raw == filename or base == filename or (cand.get("path","") or "").endswith("/" + filename):
                f = cand
                break
        cdn_url   = (f or {}).get("cdn_url") or (f or {}).get("link","")
        file_size = int(float((f or {}).get("size", 0) or 0))
        if ok and _PREWARM_ON_UNLOCK and cdn_url and file_size:
            try:
                self._fetch_block(cdn_url, 0, file_size)
            except Exception:
                pass
        key = (hash_, filename)
        with _UNLOCK_LOG_LOCK:
            if key not in _UNLOCK_LOGGED:
                _UNLOCK_LOGGED.add(key)
                log.warning(f"[auto-unlock] {'unlocked' if ok else 'failed'} hash={hash_[:8]} file={filename}")
        return self._tm.is_file_cdn_unlocked(hash_, filename)

    def _fetch_block(self, cdn_url: str, block_idx: int, file_size: int,
                     force_url: str = None, hash_: str = None, filename: str = None) -> bytes | None:
        url     = force_url or cdn_url
        start   = block_idx * BLOCK_SIZE
        end     = min(start + BLOCK_SIZE - 1, file_size - 1) if file_size else start + BLOCK_SIZE - 1
        headers = {"Range": f"bytes={start}-{end}"}
        last_err = None
        for attempt in range(READ_MAX_ATTEMPTS):
            try:
                r = requests.get(url, headers=headers, timeout=(5, READ_TIMEOUT), stream=True)
            except requests.RequestException as e:
                last_err = e
                log.warning(f"Block fetch error (try {attempt+1}): {e}")
                if attempt == 0 and cdn_url and hash_ and filename:
                    new_url = self._refresh_cdn_url(hash_, filename, cdn_url)
                    if new_url and new_url != url:
                        url = new_url
                self._read_backoff(attempt)
                continue
            try:
                status = r.status_code
                if status in (200, 206):
                    data = r.content
                    _block_cache.put(self._block_key(cdn_url, block_idx), data)
                    return data
                if status in (403, 410):
                    log.info(f"CDN URL expired (block {block_idx}, status {status})")
                    return None
                if status in (429, 500, 502, 503, 504):
                    last_err = f"status {status}"
                    self._read_backoff(attempt)
                    continue
                last_err = f"status {status}"
                break
            finally:
                r.close()
        log.warning(f"Block fetch failed after {READ_MAX_ATTEMPTS} tries: {last_err}")
        return None

    def _refresh_cdn_url(self, hash_: str, filename: str, old_url: str) -> str | None:
        new_url = self._tm.refresh_cdn_url(hash_, filename)
        if new_url and new_url != old_url:
            _block_cache.invalidate_url(old_url)
            self._invalidate_files(hash_)
            log.info(f"CDN URL refreshed for {filename}")
            return new_url
        return old_url

    def _prefetch_block(self, cdn_url: str, block_idx: int, file_size: int):
        key = self._block_key(cdn_url, block_idx)
        if _block_cache.get(key) is not None:
            return
        with self._fetch_lock:
            if key in self._fetching:
                return
            self._fetching.add(key)
        def _do():
            try:
                self._fetch_block(cdn_url, block_idx, file_size)
            finally:
                with self._fetch_lock:
                    self._fetching.discard(key)
        threading.Thread(target=_do, daemon=True).start()

    def _note_read_and_should_prefetch(self, fh, offset, size) -> bool:
        if PREFETCH_SEQ_THRESHOLD <= 0:
            return True
        bs        = BLOCK_SIZE or (1024*1024)
        block_idx = offset // bs
        now       = time.time()
        with self._read_state_lock:
            if len(self._read_state) > 256:
                cutoff = now - 300
                for k in [k for k, v in self._read_state.items() if v["ts"] < cutoff]:
                    self._read_state.pop(k, None)
            st = self._read_state.get(fh)
            if st is None:
                st = {"next": -1, "block": -1, "run": 0, "ts": now}
                self._read_state[fh] = st
            contiguous = (st["next"] >= 0 and abs(offset - st["next"]) <= _SEQ_GAP_TOLERANCE)
            if contiguous and block_idx > st["block"]:
                st["run"] += 1
            elif not contiguous:
                st["run"] = 0
            st["block"] = block_idx
            st["next"]  = offset + size
            st["ts"]    = now
            return st["run"] >= PREFETCH_SEQ_THRESHOLD

    def read(self, path, size, offset, fh):
        try:
            return self._read_safe(path, size, offset, fh)
        except FuseOSError:
            raise
        except Exception as e:
            log.warning(f"read({path}): {e}", exc_info=True)
            raise FuseOSError(errno.EIO)

    def _read_safe(self, path, size, offset, fh=0):
        subdir, dirname, filename, hash_ = self._parse_path(path)
        if hash_ is None:
            raise FuseOSError(errno.ENOENT)

        if filename.lower().endswith(".nfo"):
            if _VIDEO_ONLY:
                raise FuseOSError(errno.ENOENT)
            video_name = os.path.splitext(filename)[0]
            for f in self._get_files(hash_):
                raw  = f.get("name","") or f.get("path","")
                name = os.path.basename(raw) if raw else raw
                if os.path.splitext(name)[0] == video_name and _include_file(name):
                    nfo = self._nfo_content(hash_, name)
                    if nfo:
                        return nfo[offset:offset+size]
            raise FuseOSError(errno.ENOENT)

        f = self._find_file(hash_, filename)
        if not f:
            raise FuseOSError(errno.ENOENT)

        if not self._tm.is_file_cdn_unlocked(hash_, filename):
            if not self._ensure_unlocked_for_read(hash_, filename, path):
                try:
                    from qbt_mock import _stub_bytes_for
                    stub = _stub_bytes_for(filename) or b""
                except Exception:
                    stub = b""
                if offset >= len(stub):
                    return b""
                chunk = stub[offset:offset+size]
                if len(chunk) < size:
                    chunk = chunk + b"\x00" * (size - len(chunk))
                return chunk
            f = self._find_file(hash_, filename, force=True) or f

        cdn_url   = f.get("cdn_url") or f.get("link","")
        file_size = int(float(f.get("size", 0) or 0))
        if not cdn_url:
            raise FuseOSError(errno.EIO)

        block_idx = offset // BLOCK_SIZE
        cached    = _block_cache.get(self._block_key(cdn_url, block_idx))

        if cached is None:
            cached = self._fetch_block(cdn_url, block_idx, file_size, hash_=hash_, filename=filename)
            if cached is None:
                new_url = self._refresh_cdn_url(hash_, filename, cdn_url)
                if new_url and new_url != cdn_url:
                    cdn_url = new_url
                    cached  = self._fetch_block(cdn_url, block_idx, file_size, hash_=hash_, filename=filename)
            if cached is None:
                log.warning(f"FUSE read failed for {path} block {block_idx}")
                raise FuseOSError(errno.EIO)

        if _PREFETCH_ENABLED and file_size and self._note_read_and_should_prefetch(fh, offset, size):
            ahead = max(2, min(32, _READ_AHEAD_BYTES // BLOCK_SIZE))
            for a in range(1, ahead + 1):
                nb = block_idx + a
                if nb * BLOCK_SIZE < file_size:
                    self._prefetch_block(cdn_url, nb, file_size)

        block_start  = block_idx * BLOCK_SIZE
        slice_offset = offset - block_start
        chunk = cached[slice_offset:slice_offset+size]

        # Cross-block reads
        remaining = size - len(chunk)
        nb = block_idx + 1
        while remaining > 0 and nb * BLOCK_SIZE < file_size:
            nc = _block_cache.get(self._block_key(cdn_url, nb))
            if nc is None:
                nc = self._fetch_block(cdn_url, nb, file_size, hash_=hash_, filename=filename)
                if nc is None:
                    break
            chunk    += nc[:remaining]
            remaining -= len(nc[:remaining])
            nb        += 1

        return chunk

    @staticmethod
    def _read_backoff(attempt: int):
        time.sleep(min(READ_BACKOFF_BASE * (attempt + 1), READ_BACKOFF_CAP))

    def write(self, path, data, offset, fh): raise FuseOSError(errno.EROFS)
    def create(self, path, mode, fi=None):   raise FuseOSError(errno.EROFS)
    def unlink(self, path):                  raise FuseOSError(errno.EROFS)
    def mkdir(self, path, mode):             raise FuseOSError(errno.EROFS)
    def rmdir(self, path):                   raise FuseOSError(errno.EROFS)
    def rename(self, old, new):              raise FuseOSError(errno.EROFS)


# Keep the class accessible under the Premiumize name so qbt_mock.py and any
# other module that does `from fuse_mount import PremiumizeFS` still works.
PremiumizeFS = AllDebridFS


def mount(mountpoint: str, transfer_manager, foreground=True):
    """Mount the AllDebrid FUSE filesystem.

    NOTE: this always runs on a background thread (started by app.py's
    _start_fuse()), so signal handlers CANNOT be registered here — Python
    only allows signal.signal() from the main thread of the main
    interpreter. Shutdown/cleanup is instead driven from app.py's main
    thread via fuse_mount.unmount(), called from a SIGTERM/SIGINT handler
    registered in app.py's __main__ block, plus an atexit fallback here
    for normal interpreter exit.
    """
    if not FUSE_AVAILABLE:
        log.error("fusepy not installed — cannot mount")
        return
    os.makedirs(mountpoint, exist_ok=True)
    log.info(f"Mounting AllDebrid FS at {mountpoint} "
             f"(block={BLOCK_SIZE//1024//1024}MB, cache={_CACHE_N} blocks, "
             f"prefetch={'on' if _PREFETCH_ENABLED else 'off'}, "
             f"uid={_MOUNT_UID or 'default'}, gid={_MOUNT_GID or 'default'}, "
             f"umask={_MOUNT_UMASK or 'default'})")
    global _pfs, _fuse_instance, _mount_point
    _mount_point = mountpoint
    _pfs = AllDebridFS(transfer_manager)
    try:
        hashes = transfer_manager.streamable_hashes()
        if hashes:
            log.info(f"[FUSE] Pre-warming file cache for {len(hashes)} transfers…")
            _pfs._prewarm_parallel(hashes, block=False)
    except Exception as e:
        log.warning(f"[FUSE] Startup pre-warm failed: {e}")

    _start_cleanup_thread()

    # atexit fires from the main thread on normal interpreter shutdown
    # (clean exit, unhandled exception, sys.exit()) regardless of which
    # thread registered it — this is a safety net in addition to the
    # explicit unmount() call app.py makes from its own signal handler.
    atexit.register(_cleanup_fuse)

    # uid/gid/umask are real libfuse mount options (-o uid=N,gid=N,umask=NNN)
    # — fusepy's FUSE() converts any kwarg not in its special OPTIONS tuple
    # (foreground/debug/nothreads) straight into "-o key=value", so passing
    # them here genuinely reaches the kernel mount, not just cosmetic state.
    mount_kwargs = dict(
        nothreads=False, foreground=foreground,
        allow_other=True, nonempty=True, ro=True,
        attr_timeout=KERNEL_ATTR_TIMEOUT,
        entry_timeout=KERNEL_ENTRY_TIMEOUT,
        negative_timeout=10.0,
    )
    if _MOUNT_UID:
        mount_kwargs["uid"] = _MOUNT_UID
    if _MOUNT_GID:
        mount_kwargs["gid"] = _MOUNT_GID
    if _MOUNT_UMASK:
        mount_kwargs["umask"] = _MOUNT_UMASK

    try:
        _fuse_instance = FUSE(_pfs, mountpoint, **mount_kwargs)
    except Exception as e:
        log.error(f"FUSE mount exited with exception: {e}", exc_info=True)
        _cleanup_fuse()
        raise
    finally:
        log.info("FUSE mount exited")


def unmount():
    """Public entry point for app.py to call from its main-thread signal
    handler. Safe to call multiple times; safe to call even if never
    mounted."""
    _cleanup_fuse()


# ── Live settings application (Mount Configuration panel) ────────────────────

# Settings that only take effect at FUSE() construction time and therefore
# require a full unmount+remount cycle to change.
_REMOUNT_REQUIRED_KEYS = {"uid", "gid", "umask", "cache_dir"}

def get_current_settings() -> dict:
    """Snapshot of the currently-active (not just saved) runtime settings,
    for the GET /api/fuse/settings live-stats display."""
    return {
        "chunk_size":       f"{BLOCK_SIZE // 1024 // 1024}MB",
        "read_ahead":       f"{_READ_AHEAD_BYTES // 1024 // 1024}MB",
        "buffer_memory":    f"{(_CACHE_N * BLOCK_SIZE) // 1024 // 1024}MB",
        "disk_cache_size":  f"{_DISK_CACHE_MAX_BYTES // 1024 // 1024 // 1024}GB",
        "cache_expiry":     f"{int(_CACHE_EXPIRY_SECONDS // 3600)}h",
        "cache_cleanup":    f"{int(_CACHE_CLEANUP_SECONDS // 60)}m",
        "daemon_timeout":   f"{READ_TIMEOUT}s",
        "prefetch":         _PREFETCH_ENABLED,
        "video_only":       _VIDEO_ONLY,
        "cache_dir":        _CACHE_DIR,
        "uid":              _MOUNT_UID,
        "gid":              _MOUNT_GID,
        "umask":            _MOUNT_UMASK,
        "cached_blocks":    _block_cache.size,
        "max_blocks":       _CACHE_N,
    }


def settings_need_remount(new: dict) -> bool:
    """True if any of the provided keys differ from the currently mounted
    values AND require a remount to actually apply (uid/gid/umask/cache_dir).
    """
    if "uid" in new and str(new.get("uid") or "") != str(_MOUNT_UID or ""):
        return True
    if "gid" in new and str(new.get("gid") or "") != str(_MOUNT_GID or ""):
        return True
    if "umask" in new and str(new.get("umask") or "") != str(_MOUNT_UMASK or ""):
        return True
    if "cache_dir" in new:
        new_dir = (new.get("cache_dir") or "").strip()
        if new_dir and new_dir != _CACHE_DIR:
            return True
    return False


def apply_runtime_settings(settings: dict):
    """Apply the Mount Configuration panel's settings live, in-process.

    Called from app.py's POST /api/fuse/settings handler. Updates every
    setting that CAN take effect without remounting. Settings that need a
    remount (uid/gid/umask/cache_dir) are intentionally left untouched
    here — the caller is responsible for checking settings_need_remount()
    first and triggering an actual unmount+remount via app.py's
    _start_fuse() when needed; silently no-op'ing a uid change would be
    worse than not supporting it, since the UI would claim success.
    """
    global BLOCK_SIZE, _RA_MB, _READ_AHEAD_BYTES, _PREFETCH_ENABLED, _VIDEO_ONLY
    global _DISK_CACHE_MAX_BYTES, _CACHE_EXPIRY_SECONDS, _CACHE_CLEANUP_SECONDS
    global READ_TIMEOUT, _CACHE_N

    if "chunk_size" in settings and settings["chunk_size"]:
        new_block_size = _parse_size(settings["chunk_size"], BLOCK_SIZE)
        if new_block_size > 0:
            BLOCK_SIZE = new_block_size
            _RA_MB = BLOCK_SIZE // (1024 * 1024)

    if "read_ahead" in settings and settings["read_ahead"]:
        _READ_AHEAD_BYTES = _parse_size(settings["read_ahead"], _READ_AHEAD_BYTES)

    if "buffer_memory" in settings and settings["buffer_memory"]:
        buf_bytes = _parse_size(settings["buffer_memory"], _CACHE_N * BLOCK_SIZE)
        new_max_blocks = max(1, buf_bytes // max(BLOCK_SIZE, 1))
        _CACHE_N = new_max_blocks
        _block_cache.set_max_blocks(new_max_blocks)

    if "disk_cache_size" in settings and settings["disk_cache_size"]:
        _DISK_CACHE_MAX_BYTES = _parse_size(settings["disk_cache_size"], _DISK_CACHE_MAX_BYTES)

    if "cache_expiry" in settings and settings["cache_expiry"]:
        _CACHE_EXPIRY_SECONDS = _parse_duration(settings["cache_expiry"], _CACHE_EXPIRY_SECONDS)

    if "cache_cleanup" in settings and settings["cache_cleanup"]:
        _CACHE_CLEANUP_SECONDS = _parse_duration(settings["cache_cleanup"], _CACHE_CLEANUP_SECONDS)
        _cleanup_wake.set()   # wake the sweep thread so a shorter interval applies immediately

    if "daemon_timeout" in settings and settings["daemon_timeout"]:
        READ_TIMEOUT = int(_parse_duration(settings["daemon_timeout"], READ_TIMEOUT))

    if "prefetch" in settings:
        _PREFETCH_ENABLED = bool(settings["prefetch"])

    if "video_only" in settings:
        _VIDEO_ONLY = bool(settings["video_only"])

    log.info(f"[fuse-settings] applied live: chunk={BLOCK_SIZE//1024//1024}MB "
              f"buffer={_CACHE_N} blocks read_ahead={_READ_AHEAD_BYTES//1024//1024}MB "
              f"disk_cap={_DISK_CACHE_MAX_BYTES//1024//1024//1024}GB "
              f"expiry={_CACHE_EXPIRY_SECONDS//3600}h cleanup={_CACHE_CLEANUP_SECONDS//60}m "
              f"timeout={READ_TIMEOUT}s prefetch={_PREFETCH_ENABLED} video_only={_VIDEO_ONLY}")


def apply_mount_options(settings: dict):
    """Set the module-level mount-time-only globals (uid/gid/umask/cache_dir)
    BEFORE a remount — these are read by mount() at FUSE() construction
    time, so this must be called prior to the unmount+remount cycle, not
    after."""
    global _MOUNT_UID, _MOUNT_GID, _MOUNT_UMASK, _CACHE_DIR, _block_cache
    if "uid" in settings:
        _MOUNT_UID = str(settings["uid"]) if settings.get("uid") else None
    if "gid" in settings:
        _MOUNT_GID = str(settings["gid"]) if settings.get("gid") else None
    if "umask" in settings:
        _MOUNT_UMASK = (settings.get("umask") or "").strip() or None
    if "cache_dir" in settings and (settings.get("cache_dir") or "").strip():
        _CACHE_DIR = settings["cache_dir"].strip()
        os.makedirs(_CACHE_DIR, exist_ok=True)
        _block_cache = _BlockCache(_CACHE_N, _CACHE_DIR)

