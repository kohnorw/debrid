"""
tmdb.py — TMDB metadata lookup and Kodi/Plex NFO generation.

Provides:
  get_tmdb_api_key()          — read key from config
  lookup(title, year, kind)   — search TMDB, return metadata dict or None
  make_nfo(meta)              — render full Kodi-compatible NFO XML string
  nfo_for_file(filename)      — parse filename → lookup → NFO string (with fallback)

Results are cached in memory with a 24-hour TTL so repeated FUSE reads
for the same file never hit the network more than once per day.
"""

import logging
import os
import re
import threading
import time

import requests

log = logging.getLogger(__name__)

TMDB_BASE    = "https://api.themoviedb.org/3"
TMDB_IMG     = "https://image.tmdb.org/t/p/original"
CACHE_TTL    = 86_400   # 24 hours
_cache: dict = {}       # key → (result_or_None, expires_at)
_cache_lock  = threading.Lock()

# ── config ────────────────────────────────────────────────────────────────────

def get_tmdb_api_key() -> str:
    key = os.environ.get("TMDB_API_KEY", "").strip()
    if key:
        return key
    try:
        from app import _load_config
        return (_load_config().get("tmdb_api_key") or "").strip()
    except Exception:
        return ""


# ── cache helpers ─────────────────────────────────────────────────────────────

def _cache_get(key: str):
    with _cache_lock:
        entry = _cache.get(key)
    if entry and time.time() < entry[1]:
        return entry[0], True
    return None, False


def _cache_put(key: str, value):
    with _cache_lock:
        _cache[key] = (value, time.time() + CACHE_TTL)


# ── XML helpers ───────────────────────────────────────────────────────────────

def _x(s) -> str:
    return (str(s) if s is not None else "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


# ── filename parser ───────────────────────────────────────────────────────────

_NOISE = re.compile(
    r'\b(?:2160p?|1080p?|720p?|480p?|576p?|4k|uhd|hdr\w*|bluray|blu.?ray|bdrip|'
    r'web.?dl|webrip|web|hdtv|dvdrip|dvd|x264|x265|h264|h265|hevc|avc|av1|'
    r'10bit|8bit|aac|dts|truehd|atmos|ac3|eac3|flac|mp3|opus|remux|repack|'
    r'proper|extended|directors?.cut|imax|dual.audio|multi.?sub\w*|'
    r'tgx|yts|yify|rarbg|pahe|erai.?raws|subsplease|horriblesubs)\b.*',
    re.IGNORECASE,
)

_GROUP_TAG = re.compile(r'^\[[^\]]{1,20}\]\s*')   # leading [GroupName]
_HASH_TAG  = re.compile(r'\[[0-9A-Fa-f]{6,8}\]')  # trailing [AABBCCDD]
_YEAR_RE   = re.compile(r'(?<!\d)((?:19|20)\d{2})(?!\d)')
_EP_RE     = re.compile(r'S(\d{1,2})[.\s_-]?E(\d{1,3})', re.IGNORECASE)
_EP_BARE   = re.compile(r'(?<![.\w])-\s*(\d{1,3})\b(?!\s*(?:bit|fps|hz|p\b))')


def parse_filename(filename: str) -> dict:
    """
    Return {kind, title, year, season, episode} parsed from a release filename.
    kind is 'movie' or 'episode'.
    """
    base = os.path.splitext(filename)[0]
    base = _GROUP_TAG.sub('', base)
    base = _HASH_TAG.sub('', base)
    base = base.replace('.', ' ').replace('_', ' ')

    # Episode: SxxExx
    ep_m = _EP_RE.search(base)
    if ep_m:
        season  = int(ep_m.group(1))
        episode = int(ep_m.group(2))
        raw = base[:ep_m.start()]
        raw = _NOISE.sub('', raw)
        raw = re.sub(r'\[.*?\]|\(.*?\)', ' ', raw)
        title = re.sub(r'\s+', ' ', raw).strip(' -–')
        return {"kind": "episode", "title": title, "year": None,
                "season": season, "episode": episode}

    # Bare anime episode: "Title - 05"
    bare_m = _EP_BARE.search(base)
    if bare_m:
        episode = int(bare_m.group(1))
        raw = base[:bare_m.start()]
        raw = _NOISE.sub('', raw)
        raw = re.sub(r'\[.*?\]|\(.*?\)', ' ', raw)
        title = re.sub(r'\s+', ' ', raw).strip(' -–')
        if title:
            return {"kind": "episode", "title": title, "year": None,
                    "season": 1, "episode": episode}

    # Movie: strip noise then look for year
    cleaned = _NOISE.sub('', base)
    cleaned = re.sub(r'\[.*?\]|\(.*?\)', ' ', cleaned)
    yr_m = _YEAR_RE.search(cleaned)
    if yr_m:
        year  = int(yr_m.group(1))
        title = re.sub(r'\s+', ' ', cleaned[:yr_m.start()]).strip(' -–')
        return {"kind": "movie", "title": title, "year": year,
                "season": None, "episode": None}

    title = re.sub(r'\s+', ' ', cleaned).strip(' -–')
    return {"kind": "movie", "title": title, "year": None,
            "season": None, "episode": None}


# ── TMDB search ───────────────────────────────────────────────────────────────

def _auth_kwargs(api_key: str) -> dict:
    """Build requests kwargs for TMDB auth, supporting BOTH credential types:
      • v3 API key — 32-char hex string, sent as ?api_key=
      • v4 Read Access Token — a JWT (three dot-separated parts), sent as
        Authorization: Bearer …
    The TMDB dashboard shows the v4 token most prominently, so users routinely
    paste that into the key field. Accepting both avoids a spurious 'invalid
    key' failure on a perfectly valid v4 token."""
    key = (api_key or "").strip()
    if key.count(".") == 2 and len(key) > 100:          # looks like a v4 JWT
        return {"headers": {"Authorization": f"Bearer {key}"}}
    return {"params": {"api_key": key}}                  # v3 query-param key


def validate_key(api_key: str) -> tuple[bool, str]:
    """Cheap validity check against /configuration using whichever auth scheme
    the key format implies. Returns (ok, message)."""
    key = (api_key or "").strip()
    if not key:
        return False, "Empty API key"
    auth = _auth_kwargs(key)
    try:
        r = requests.get(
            f"{TMDB_BASE}/configuration",
            params=auth.get("params", {}),
            headers=auth.get("headers", {}),
            timeout=10,
        )
        if r.status_code == 401:
            return False, "Invalid TMDB API key (401)"
        r.raise_for_status()
        return True, "ok"
    except requests.RequestException as e:
        return False, str(e)


def _tmdb_get(path: str, params: dict, api_key: str) -> dict | None:
    auth = _auth_kwargs(api_key)
    try:
        r = requests.get(
            f"{TMDB_BASE}{path}",
            params={**auth.get("params", {}), **params},
            headers=auth.get("headers", {}),
            timeout=10,
        )
        if r.status_code == 200:
            return r.json()
        log.debug(f"TMDB {path} → HTTP {r.status_code}")
    except requests.RequestException as e:
        log.debug(f"TMDB request error: {e}")
    return None


def _search_movie(title: str, year, api_key: str) -> dict | None:
    params = {"query": title, "include_adult": "false"}
    if year:
        params["year"] = year
    data = _tmdb_get("/search/movie", params, api_key)
    if not data:
        return None
    results = data.get("results", [])
    if not results and year:
        # Retry without year — some releases have wrong year in name
        data = _tmdb_get("/search/movie", {"query": title, "include_adult": "false"}, api_key)
        results = (data or {}).get("results", [])
    if not results:
        return None
    best = results[0]
    # Fetch full details with credits
    detail = _tmdb_get(f"/movie/{best['id']}", {"append_to_response": "credits"}, api_key)
    return detail or best


def _search_tv(title: str, year, api_key: str) -> dict | None:
    params = {"query": title}
    if year:
        params["first_air_date_year"] = year
    data = _tmdb_get("/search/tv", params, api_key)
    if not data:
        return None
    results = data.get("results", [])
    if not results and year:
        data = _tmdb_get("/search/tv", {"query": title}, api_key)
        results = (data or {}).get("results", [])
    if not results:
        return None
    best = results[0]
    detail = _tmdb_get(f"/tv/{best['id']}", {"append_to_response": "credits"}, api_key)
    return detail or best


def _search_episode(title: str, year, season: int, episode: int, api_key: str) -> tuple[dict | None, dict | None]:
    """Return (show_detail, episode_detail)."""
    show = _search_tv(title, year, api_key)
    if not show:
        return None, None
    ep = _tmdb_get(
        f"/tv/{show['id']}/season/{season}/episode/{episode}",
        {}, api_key,
    )
    return show, ep


def lookup(title: str, year, kind: str, season: int = None, episode: int = None) -> dict | None:
    """
    Search TMDB for title/year/kind.
    Returns a normalised metadata dict or None if not found / no key.
    """
    api_key = get_tmdb_api_key()
    if not api_key or not title:
        return None

    cache_key = f"{kind}:{title.lower()}:{year}:{season}:{episode}"
    cached, hit = _cache_get(cache_key)
    if hit:
        return cached

    try:
        if kind == "movie":
            raw = _search_movie(title, year, api_key)
            result = _normalise_movie(raw) if raw else None
        elif kind == "episode":
            show, ep = _search_episode(title, year, season or 1, episode or 1, api_key)
            result = _normalise_episode(show, ep, season, episode) if show else None
        else:
            result = None
    except Exception as e:
        log.warning(f"TMDB lookup failed for '{title}': {e}")
        result = None

    _cache_put(cache_key, result)
    return result


# ── normalise raw TMDB responses ──────────────────────────────────────────────

def _actors(credits: dict, limit: int = 5) -> list[dict]:
    cast = (credits or {}).get("cast", [])
    return [
        {"name": a.get("name", ""), "role": a.get("character", "")}
        for a in cast[:limit]
    ]


def _genres(data: dict) -> list[str]:
    return [g["name"] for g in data.get("genres", [])]


def _normalise_movie(d: dict) -> dict:
    credits = d.get("credits", {})
    crew    = credits.get("crew", [])
    directors = [p["name"] for p in crew if p.get("job") == "Director"]
    runtime = d.get("runtime") or 0
    year = None
    rd = d.get("release_date", "")
    if rd and len(rd) >= 4:
        try:
            year = int(rd[:4])
        except ValueError:
            pass
    return {
        "kind":      "movie",
        "title":     d.get("title") or d.get("original_title") or "",
        "year":      year,
        "plot":      d.get("overview") or "",
        "rating":    round(float(d.get("vote_average") or 0), 1),
        "votes":     d.get("vote_count") or 0,
        "runtime":   runtime,
        "genres":    _genres(d),
        "actors":    _actors(credits),
        "directors": directors,
        "tmdbid":    d.get("id"),
        "imdbid":    d.get("imdb_id") or "",
        "thumb":     (TMDB_IMG + d["poster_path"]) if d.get("poster_path") else "",
        "fanart":    (TMDB_IMG + d["backdrop_path"]) if d.get("backdrop_path") else "",
    }


def _normalise_episode(show: dict, ep: dict | None, season: int, episode: int) -> dict:
    credits = show.get("credits", {})
    year = None
    fd = show.get("first_air_date", "")
    if fd and len(fd) >= 4:
        try:
            year = int(fd[:4])
        except ValueError:
            pass
    ep = ep or {}
    runtime_list = show.get("episode_run_time") or []
    runtime = ep.get("runtime") or (runtime_list[0] if runtime_list else 0)
    return {
        "kind":      "episode",
        "show":      show.get("name") or show.get("original_name") or "",
        "title":     ep.get("name") or "",
        "year":      year,
        "season":    season,
        "episode":   episode,
        "plot":      ep.get("overview") or show.get("overview") or "",
        "rating":    round(float(ep.get("vote_average") or show.get("vote_average") or 0), 1),
        "votes":     ep.get("vote_count") or show.get("vote_count") or 0,
        "runtime":   runtime,
        "genres":    _genres(show),
        "actors":    _actors(credits),
        "tmdbid":    show.get("id"),
        "thumb":     (TMDB_IMG + ep["still_path"]) if ep.get("still_path") else
                     ((TMDB_IMG + show["poster_path"]) if show.get("poster_path") else ""),
        "fanart":    (TMDB_IMG + show["backdrop_path"]) if show.get("backdrop_path") else "",
    }


# ── NFO rendering ─────────────────────────────────────────────────────────────

def make_nfo(meta: dict) -> str:
    """Render a Kodi/Plex-compatible NFO XML string from a metadata dict."""
    if meta.get("kind") == "episode":
        return _nfo_episode(meta)
    return _nfo_movie(meta)


def _tag(name: str, value, indent: str = "  ") -> str:
    if value is None or value == "" or value == 0:
        return ""
    return f"{indent}<{name}>{_x(value)}</{name}>\n"


def _nfo_movie(m: dict) -> str:
    lines = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<movie>\n']
    lines.append(_tag("title",         m.get("title")))
    lines.append(_tag("originaltitle", m.get("title")))
    lines.append(_tag("year",          m.get("year")))
    lines.append(_tag("plot",          m.get("plot")))
    lines.append(_tag("runtime",       m.get("runtime") or 120))
    if m.get("rating"):
        lines.append(
            f'  <ratings>\n'
            f'    <rating name="tmdb" max="10" default="true">\n'
            f'      <value>{_x(m["rating"])}</value>\n'
            f'      <votes>{_x(m.get("votes", 0))}</votes>\n'
            f'    </rating>\n'
            f'  </ratings>\n'
        )
    for g in (m.get("genres") or []):
        lines.append(_tag("genre", g))
    for d in (m.get("directors") or []):
        lines.append(_tag("director", d))
    for a in (m.get("actors") or []):
        lines.append(
            f'  <actor>\n'
            f'    <name>{_x(a["name"])}</name>\n'
            f'    <role>{_x(a["role"])}</role>\n'
            f'  </actor>\n'
        )
    if m.get("tmdbid"):
        lines.append(f'  <uniqueid type="tmdb" default="true">{_x(m["tmdbid"])}</uniqueid>\n')
    if m.get("imdbid"):
        lines.append(f'  <uniqueid type="imdb">{_x(m["imdbid"])}</uniqueid>\n')
    if m.get("thumb"):
        lines.append(_tag("thumb", m["thumb"]))
    if m.get("fanart"):
        lines.append(f'  <fanart><thumb>{_x(m["fanart"])}</thumb></fanart>\n')
    lines.append("</movie>\n")
    return "".join(lines)


def _nfo_episode(m: dict) -> str:
    lines = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<episodedetails>\n']
    lines.append(_tag("title",   m.get("title") or m.get("show")))
    lines.append(_tag("showtitle", m.get("show")))
    lines.append(_tag("season",  m.get("season")))
    lines.append(_tag("episode", m.get("episode")))
    lines.append(_tag("plot",    m.get("plot")))
    lines.append(_tag("runtime", m.get("runtime") or 45))
    if m.get("rating"):
        lines.append(
            f'  <ratings>\n'
            f'    <rating name="tmdb" max="10" default="true">\n'
            f'      <value>{_x(m["rating"])}</value>\n'
            f'      <votes>{_x(m.get("votes", 0))}</votes>\n'
            f'    </rating>\n'
            f'  </ratings>\n'
        )
    for g in (m.get("genres") or []):
        lines.append(_tag("genre", g))
    for a in (m.get("actors") or []):
        lines.append(
            f'  <actor>\n'
            f'    <name>{_x(a["name"])}</name>\n'
            f'    <role>{_x(a["role"])}</role>\n'
            f'  </actor>\n'
        )
    if m.get("tmdbid"):
        lines.append(f'  <uniqueid type="tmdb" default="true">{_x(m["tmdbid"])}</uniqueid>\n')
    if m.get("thumb"):
        lines.append(_tag("thumb", m["thumb"]))
    if m.get("fanart"):
        lines.append(f'  <fanart><thumb>{_x(m["fanart"])}</thumb></fanart>\n')
    lines.append("</episodedetails>\n")
    return "".join(lines)


# ── fallback NFO (no TMDB key) ────────────────────────────────────────────────

def _fallback_nfo(parsed: dict) -> str:
    """Minimal NFO from filename parse alone — same as the old behaviour."""
    title = _x(parsed.get("title") or "Unknown")
    if parsed["kind"] == "episode":
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<episodedetails>\n'
            f'  <title>{title}</title>\n'
            f'  <season>{parsed["season"]}</season>\n'
            f'  <episode>{parsed["episode"]}</episode>\n'
            '  <runtime>45</runtime>\n'
            '</episodedetails>\n'
        )
    year_tag = f'  <year>{parsed["year"]}</year>\n' if parsed.get("year") else ''
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
        '<movie>\n'
        f'  <title>{title}</title>\n'
        f'{year_tag}'
        '  <runtime>120</runtime>\n'
        '</movie>\n'
    )


# ── public entry point ────────────────────────────────────────────────────────

def nfo_for_file(filename: str) -> str:
    """
    Full pipeline: parse filename → TMDB lookup → NFO string.
    Falls back to filename-only NFO if TMDB is unavailable.
    """
    parsed = parse_filename(filename)
    title  = parsed.get("title", "")

    if not title:
        return _fallback_nfo(parsed)

    meta = lookup(
        title  = title,
        year   = parsed.get("year"),
        kind   = parsed["kind"],
        season = parsed.get("season"),
        episode= parsed.get("episode"),
    )

    if meta:
        log.debug(f"TMDB hit for '{filename}': {meta.get('title') or meta.get('show')}")
        return make_nfo(meta)

    log.debug(f"TMDB miss for '{filename}', using filename fallback")
    return _fallback_nfo(parsed)
