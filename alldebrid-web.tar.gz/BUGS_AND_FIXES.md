# AllDebrid Web - Critical Bug Analysis & Fixes

## Issues Identified

### 1. **Cache Check Not Working Correctly on Debrid Import**
**File:** `transfer_manager.py` - `_process()` method (line 870)

**Problem:**
- When importing/adding a torrent, the code uploads the magnet and checks `m.get("ready")` to determine if cached
- However, **it doesn't properly handle all content types** (movies, series, seasons, series packs)
- The cache check works for simple uploads but may fail when AllDebrid needs extra time to verify cache status
- Missing: retry logic with delays for cache verification

**Current Code:**
```python
def _process(self, hash_: str):
    # ... uploads magnet
    m = magnets[0]
    if m.get("ready"):
        self._set(hash_, state="cached", ad_id=ad_id)
    else:
        self._set(hash_, state="downloading", ad_id=ad_id)
```

**Issues:**
1. Single instant check may not capture all cache states
2. No differentiation for content types (movies vs series vs packs)
3. No fallback verification

---

### 2. **Missing File Information for Stubs**
**Files:** `transfer_manager.py`, `app.py`

**Problem:**
- When stubs are created (via `/api/sync/run`), file information is NOT stored
- `get_files()` returns empty for stub transfers because:
  - No `ad_id` is stored for stubs
  - No file list is cached in DB
  - Web UI search can't detect what's in the stub

**Current Code (app.py, line 1487-1496):**
```python
def _write_stub(dest, fn):
    # Creates fake .mkv files but doesn't:
    # - Store file list in DB
    # - Track ad_id for the stub
    # - Mark files as "stub" status
    os.makedirs(dest, exist_ok=True)
    p = os.path.join(dest, fn)
    # ... creates file ...
```

**Impact:**
- Can't show file info in web UI search results
- Can't detect if stub is cached when searching
- Stub status isn't properly tracked

---

### 3. **Web UI Search Can't Detect Cached Status**
**Files:** `app.py` - `/api/search` route (around line 1000-1200)

**Problem:**
- Search results don't include cache status verification
- Doesn't check if searched torrent is already cached
- No integration with AllDebrid instant check (`AD_INSTANT` endpoint)
- Missing file list preview for cached items

**Current Issues:**
1. Search query might return same result twice (once as cached, once from search)
2. No visual indication of cache status
3. No file preview from actual cache

---

### 4. **Stub Files Not Converting to Real Files**
**Files:** `transfer_manager.py`, `app.py`, `qbt_mock.py`

**Problem:**
- When a stub becomes a real file (imported to library), it's not added to AllDebrid
- Stub state isn't tracked properly
- No mechanism to:
  - Upload the real magnet to AllDebrid
  - Update the stub transfer with real `ad_id`
  - Move stub from "stub" to "cached/complete" state

**Missing Logic:**
- When library import completes, need to detect and upload the original magnet
- Need to update stub transfer record with real AllDebrid ID
- Need to populate file list from real torrent

---

### 5. **FUSE Mount Not Unmounting on Shutdown**
**File:** `fuse_mount.py`, `app.py`

**Problem:**
- No cleanup handler for FUSE mount on app shutdown
- When app terminates, FUSE mount stays active
- Can cause:
  - Zombie mount points
  - Resource leaks
  - Inability to restart app

**Current Code (fuse_mount.py, line 880-905):**
```python
def mount(transfer_manager, mountpoint=None, foreground=False):
    global _pfs
    _pfs = AllDebridFS(transfer_manager)
    try:
        FUSE(_pfs, mountpoint, ...)  # <-- blocks forever, no cleanup
    except Exception as e:
        log.error(f"FUSE mount exited: {e}")
    log.info("FUSE mount exited cleanly")
```

**Missing:**
1. Signal handlers for graceful shutdown
2. FUSE unmount call on exit
3. Integration with app shutdown hooks

---

## Detailed Fixes

### Fix 1: Improve Cache Check with Retry & Verification

**File:** `transfer_manager.py` - Add new method and update `_process()`

```python
def _verify_cache_status(self, api_key: str, hash_: str, max_retries: int = 3) -> bool:
    """
    Verify if magnet is cached on AllDebrid with retry logic.
    Uses instant check endpoint which doesn't add to library.
    """
    magnet = f"magnet:?xt=urn:btih:{hash_.lower()}"
    for attempt in range(max_retries):
        try:
            data = _ad_get(api_key, AD_INSTANT, params={"magnets[]": magnet})
            magnets = data.get("data", {}).get("magnets", [])
            if magnets and not magnets[0].get("error"):
                if magnets[0].get("ready"):
                    log.info(f"[{hash_[:8]}] Cache verified on attempt {attempt + 1}")
                    return True
                # Not ready yet, try again after delay
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)  # exponential backoff: 1s, 2s, 4s
        except Exception as e:
            log.debug(f"[{hash_[:8]}] cache verify attempt {attempt + 1} failed: {e}")
            if attempt < max_retries - 1:
                time.sleep(1)
    return False

def _process(self, hash_: str):
    """Upload magnet and detect if cached."""
    t = self._get(hash_)
    if not t or t["state"] in ("cached", "complete", "downloading"):
        return
    api_key = self._key_fn()
    if not api_key:
        self._set(hash_, state="error", error="API key not set")
        return
    try:
        # First, quick instant check without uploading
        if self._verify_cache_status(api_key, hash_):
            log.info(f"[{hash_[:8]}] Cached on AllDebrid (instant check)")
            # Now upload and store the ad_id
            resp = _ad_upload_magnet(api_key, hash_, t.get("name") or hash_)
            magnets = resp.get("data", {}).get("magnets", [])
            if magnets and not magnets[0].get("error"):
                ad_id = magnets[0].get("id")
                self._set(hash_, state="cached", ad_id=ad_id)
                self._on_ready(hash_)
            return
        
        # Not cached, do normal upload
        resp = _ad_upload_magnet(api_key, hash_, t.get("name") or hash_)
        magnets = resp.get("data", {}).get("magnets", [])
        if not magnets or magnets[0].get("error"):
            err = magnets[0].get("error", {}).get("message", "Upload failed") if magnets else "Upload failed"
            self._set(hash_, state="error", error=err)
            return
        m = magnets[0]
        ad_id = m.get("id")
        if m.get("ready"):
            log.info(f"[{hash_[:8]}] Cached on AllDebrid")
            self._set(hash_, state="cached", ad_id=ad_id)
            self._on_ready(hash_)
        else:
            log.info(f"[{hash_[:8]}] Not cached — queued for download (ad_id={ad_id})")
            self._set(hash_, state="downloading", ad_id=ad_id)
    except Exception as e:
        log.exception(f"[{hash_[:8]}] _process error")
        self._set(hash_, state="error", error=str(e))
```

---

### Fix 2: Store File Information for Stubs

**File:** `app.py` - Update `/api/sync/run` route

```python
# Around line 1520-1550, in the sync_run() generate() function:

items = [t for t in streamable if _cls(t) == arr]
if not items:
    yield sse(log=f"No {arr} items.", done=True)
    return
yield sse(log=f"Found {len(items)} items", pct=14)

added = skipped = errors = 0
total = len(items)
for i, t in enumerate(items):
    pct = 14 + int(82 * (i + 1) / max(total, 1))
    name = t.get("name") or t["hash"]
    yield sse(status=f"[{i+1}/{total}] {name[:48]}", pct=pct)
    try:
        safe = _sname(name)
        dest_dir = os.path.join(root, safe)
        fake_fn = f"{safe}.WEBRip-{_res(name)}.mkv"
        if mode == "partial" and os.path.exists(os.path.join(dest_dir, fake_fn)):
            skipped += 1
            continue
        stub_path = _write_stub(dest_dir, fake_fn)
        
        # *** NEW: Store stub file info in DB ***
        try:
            _tm = _tm_get()
            if _tm:
                # Create a stub file entry in the database
                stub_files = [{
                    "name": fake_fn,
                    "path": fake_fn,
                    "size": os.path.getsize(stub_path),
                    "link": "",
                    "is_video": True,
                }]
                _tm._db_store_files(t["hash"], stub_files)
                # Mark this transfer as a stub
                _tm._set(t["hash"], is_stub=1)
                yield sse(log=f"  ✓ {safe} (stub filed)", pct=pct)
        except Exception as e:
            log.warning(f"[sync] Failed to store stub file info: {e}")
            yield sse(log=f"  ⚠ {safe} (stub created but file info failed)", pct=pct)
        
        # Rest of sync logic...
        endpoint = "series" if is_series else "movie"
        try:
            lib = requests.get(f"{base_url}/api/v3/{endpoint}", headers=_hdrs(), timeout=15).json()
            for item in (lib if isinstance(lib, list) else []):
                tn = _re.sub(r"[^a-z0-9]", "", (item.get("title") or "").lower())
                nn = _re.sub(r"[^a-z0-9]", "", safe.lower())
                if tn == nn or tn in nn or nn in tn:
                    cmd = "RescanSeries" if is_series else "RescanMovie"
                    kw = "seriesId" if is_series else "movieId"
                    requests.post(f"{base_url}/api/v3/command", headers=_hdrs(),
                        json={"name": cmd, kw: item["id"]}, timeout=8)
                    break
        except Exception:
            pass
        
        added += 1
    except Exception as e:
        errors += 1
        yield sse(log=f"  ❌ {name[:50]}: {e}")
```

---

### Fix 3: Detect Cache Status in Web UI Search

**File:** `app.py` - Update search route (around line 1200-1300)

```python
# Add new helper route to check cache status
@app.route("/api/search/cache-check", methods=["POST"])
def search_cache_check():
    """Check if magnet is cached without adding to library."""
    d = request.get_json(force=True) or {}
    hash_ = (d.get("hash") or "").strip().lower()
    
    if not hash_:
        return jsonify({"error": "Missing hash"}), 400
    
    api_key = get_ad_api_key()
    if not api_key:
        return jsonify({"error": "API key not configured"}), 400
    
    # Check local DB first
    _tm = _tm_get()
    if _tm:
        t = _tm.get_transfer(hash_)
        if t and t.get("state") in ("cached", "complete"):
            return jsonify({
                "cached": True,
                "state": t.get("state"),
                "files": _tm.get_files(hash_),
            })
    
    # Check AllDebrid instant (doesn't add to library)
    magnet = f"magnet:?xt=urn:btih:{hash_}"
    resp = _ad_get(api_key, AD_INSTANT, params={"magnets[]": magnet})
    magnets = resp.get("data", {}).get("magnets", [])
    
    if magnets and not magnets[0].get("error"):
        if magnets[0].get("ready"):
            return jsonify({"cached": True, "state": "cached", "files": []})
    
    return jsonify({"cached": False, "state": None, "files": []})


# Update existing search route to include cache detection
@app.route("/api/search", methods=["GET", "POST"])
def search():
    """Search for torrents - enhanced with cache detection."""
    query = (request.args.get("q") or request.get_json(force=True, silent=True) or {}).get("q", "").strip()
    
    if not query:
        return jsonify({"error": "Missing search query"}), 400
    
    api_key = get_ad_api_key()
    _tm = _tm_get()
    
    # ... existing search logic ...
    
    # After getting results, enhance with cache info
    results = []
    for item in raw_results:  # raw search results
        hash_ = (item.get("infohash") or "").lower()
        
        # Check if already in DB
        cached = False
        state = None
        files = []
        if _tm and hash_:
            t = _tm.get_transfer(hash_)
            if t and t.get("state") in ("cached", "complete"):
                cached = True
                state = t.get("state")
                files = _tm.get_files(hash_)
        
        results.append({
            **item,
            "cached": cached,
            "state": state,
            "file_count": len(files),
            "files_preview": files[:5] if files else [],  # show first 5 files
        })
    
    return jsonify({"results": results})
```

---

### Fix 4: Handle Stub-to-Real Conversion

**File:** `transfer_manager.py` - Add stub promotion logic

```python
def promote_stub_to_real(self, hash_: str, name: str = ""):
    """
    When a stub is imported as real, upload the magnet and link it.
    Used when Radarr/Sonarr confirms file in library.
    """
    t = self._get(hash_)
    if not t:
        return False
    
    if not t.get("is_stub"):
        # Already promoted or not a stub
        return False
    
    api_key = self._key_fn()
    if not api_key:
        log.warning(f"[{hash_[:8]}] promote_stub: API key not set")
        return False
    
    try:
        # Upload the magnet to get a real ad_id
        resp = _ad_upload_magnet(api_key, hash_, name or t.get("name") or hash_)
        magnets = resp.get("data", {}).get("magnets", [])
        
        if not magnets or magnets[0].get("error"):
            err = magnets[0].get("error", {}).get("message", "Upload failed") if magnets else "Upload failed"
            log.error(f"[{hash_[:8]}] promote_stub failed: {err}")
            return False
        
        m = magnets[0]
        ad_id = m.get("id")
        
        # Update the transfer
        if m.get("ready"):
            log.info(f"[{hash_[:8]}] Stub promoted - cached on AllDebrid")
            self._set(hash_, state="cached", ad_id=ad_id, is_stub=0)
            self._on_ready(hash_)
        else:
            log.info(f"[{hash_[:8]}] Stub promoted - downloading (ad_id={ad_id})")
            self._set(hash_, state="downloading", ad_id=ad_id, is_stub=0)
        
        return True
    except Exception as e:
        log.exception(f"[{hash_[:8]}] promote_stub error")
        return False


# Also add an API endpoint to trigger promotion
@app.route("/api/transfer/promote-stub/<hash_>", methods=["POST"])
def transfer_promote_stub(hash_):
    """Promote a stub transfer to real (when library confirmed)."""
    hash_ = hash_.lower().strip()
    name = request.args.get("name", "").strip()
    
    _tm = _tm_get()
    if not _tm:
        return jsonify({"error": "Transfer manager unavailable"}), 500
    
    if not _tm.promote_stub_to_real(hash_, name):
        return jsonify({"error": "Promotion failed"}), 400
    
    t = _tm.get_transfer(hash_)
    return jsonify({"ok": True, "transfer": t})
```

---

### Fix 5: Graceful FUSE Unmount on Shutdown

**File:** `fuse_mount.py` - Add unmount handler

```python
import signal
import atexit

# Global reference to FUSE instance
_fuse_instance = None
_mount_point = None

def _cleanup_fuse():
    """Unmount FUSE on shutdown."""
    global _pfs, _fuse_instance, _mount_point
    try:
        if _pfs is not None:
            log.info(f"Cleaning up FUSE mount at {_mount_point}...")
            try:
                import subprocess
                subprocess.run(["fusermount", "-u", _mount_point], timeout=5, check=False)
            except Exception as e:
                log.debug(f"fusermount unmount failed: {e}")
            
            try:
                subprocess.run(["umount", _mount_point], timeout=5, check=False)
            except Exception as e:
                log.debug(f"umount failed: {e}")
            
            _pfs = None
        log.info("FUSE cleanup complete")
    except Exception as e:
        log.error(f"FUSE cleanup error: {e}")


def mount(transfer_manager, mountpoint=None, foreground=False):
    """Mount AllDebrid FS with cleanup handlers."""
    global _pfs, _fuse_instance, _mount_point
    
    if mountpoint is None:
        mountpoint = "/docker/alldebrid-web/mnt"
    
    _mount_point = mountpoint
    
    os.makedirs(mountpoint, exist_ok=True)
    log.info(f"Mounting AllDebrid FS at {mountpoint} "
             f"(block={BLOCK_SIZE//1024//1024}MB, cache={_CACHE_N} blocks, "
             f"prefetch={'on' if _PREFETCH_ENABLED else 'off'})")
    
    _pfs = AllDebridFS(transfer_manager)
    
    try:
        hashes = transfer_manager.streamable_hashes()
        if hashes:
            log.info(f"[FUSE] Pre-warming file cache for {len(hashes)} transfers…")
            _pfs._prewarm_parallel(hashes, block=False)
    except Exception as e:
        log.warning(f"[FUSE] Startup pre-warm failed: {e}")
    
    # Register cleanup handlers
    atexit.register(_cleanup_fuse)
    
    def _signal_handler(sig, frame):
        log.info(f"Received signal {sig}, initiating graceful shutdown...")
        _cleanup_fuse()
        raise KeyboardInterrupt()
    
    signal.signal(signal.SIGTERM, _signal_handler)
    signal.signal(signal.SIGINT, _signal_handler)
    
    try:
        _fuse_instance = FUSE(
            _pfs, mountpoint,
            nothreads=False, foreground=foreground,
            allow_other=True, nonempty=True, ro=True,
            attr_timeout=KERNEL_ATTR_TIMEOUT,
            entry_timeout=KERNEL_ENTRY_TIMEOUT,
            negative_timeout=10.0,
        )
    except KeyboardInterrupt:
        log.info("FUSE mount interrupted")
        _cleanup_fuse()
    except Exception as e:
        log.error(f"FUSE mount exited with exception: {e}", exc_info=True)
        _cleanup_fuse()
        raise
    finally:
        log.info("FUSE mount exited")
```

**File:** `app.py` - Add shutdown hook

```python
# Add near the bottom of app.py, before the if __name__ == "__main__" block

def _shutdown_handler():
    """Cleanup on app shutdown."""
    try:
        import fuse_mount as _fm
        _fm._cleanup_fuse()
    except Exception as e:
        app.logger.warning(f"FUSE cleanup on shutdown failed: {e}")

atexit.register(_shutdown_handler)

# Also handle graceful shutdown in the main server loop
if __name__ == "__main__":
    import atexit
    
    port = int(os.environ.get("PORT", 5000))
    import resource
    try:
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        t = min(hard, 65536)
        if soft < t:
            resource.setrlimit(resource.RLIMIT_NOFILE, (t, hard))
    except Exception:
        pass
    
    from werkzeug.serving import make_server as _mks
    max_t = int(os.environ.get("SERVER_THREADS", "16"))
    sem = threading.Semaphore(max_t)
    srv = _mks("0.0.0.0", port, app, threaded=True)
    
    def _cap(req, addr):
        if sem.acquire(blocking=False):
            def _r():
                try:
                    srv.finish_request(req, addr)
                except:
                    srv.handle_error(req, addr)
                finally:
                    srv.shutdown_request(req)
                    sem.release()
            threading.Thread(target=_r, daemon=True).start()
        else:
            try:
                srv.finish_request(req, addr)
            except:
                srv.handle_error(req, addr)
            finally:
                srv.shutdown_request(req)
    
    srv.process_request = _cap
    app.logger.info(f"AllDebrid Web :{port} rate={_AD_RATE_LIMIT}/min")
    
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        app.logger.info("Server shutdown requested")
    finally:
        _shutdown_handler()
        srv.shutdown()
```

---

## Testing Checklist

- [ ] Test cache check with quick instant verify before upload
- [ ] Test sync creates stubs with file info in DB
- [ ] Test search results show cached status
- [ ] Test search results show file previews
- [ ] Test stub promotion when added to Radarr/Sonarr
- [ ] Test FUSE unmounts cleanly on app shutdown
- [ ] Test FUSE doesn't leave zombie mounts
- [ ] Test all content types: movies, series, seasons, packs
- [ ] Test adding then removing from library detects changes
- [ ] Verify file count and sizes in web UI match actual

---

## Implementation Priority

1. **High:** Fix FUSE unmount (prevents data loss/mount issues)
2. **High:** Improve cache check with retry logic (fixes main import issue)
3. **Medium:** Store file info for stubs (enables proper UI display)
4. **Medium:** Add cache detection to search (better UX)
5. **Low:** Handle stub promotion (improvement when library changes)
