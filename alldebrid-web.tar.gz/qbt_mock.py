"""
qBittorrent Web API v2 mock.

Implements the endpoints Sonarr and Radarr use:
  GET  /qbt/api/v2/auth/login
  GET  /qbt/api/v2/app/version
  GET  /qbt/api/v2/app/webapiVersion
  GET  /qbt/api/v2/torrents/info
  POST /qbt/api/v2/torrents/add
  POST /qbt/api/v2/torrents/delete
  GET  /qbt/api/v2/torrents/files
  GET  /qbt/api/v2/torrents/properties

qBittorrent state mapping:
  queued      → "checkingResumeData"
  cached      → "uploading"   (already on CDN — treat as complete so Sonarr/Radarr imports)
  downloading → "downloading"
  complete    → "uploading"   (seeding = complete in qbt terms)
  error       → "error"
"""

import hashlib
import os
import re
import time
import urllib.parse

from flask import Blueprint, jsonify, request, Response

qbt = Blueprint("qbt", __name__, url_prefix="/qbt/api/v2")

# Injected by app.py on startup
_tm = None

FAKE_FILE_TTL = int(os.environ.get("FAKE_FILE_TTL", "300"))  # seconds, default 5 min

# Periodic full purge of the downloads folders. Independent of the TTL cleanup
# above: every FAKE_PURGE_INTERVAL seconds, ALL fake-file folders under every
# category in DOWNLOADS_ROOT are removed. Folders touched within
# FAKE_PURGE_GRACE seconds are skipped so an in-progress Radarr/Sonarr import is
# never clobbered mid-flight.
FAKE_PURGE_INTERVAL = int(os.environ.get("FAKE_PURGE_INTERVAL", "300"))  # 5 min
FAKE_PURGE_GRACE    = int(os.environ.get("FAKE_PURGE_GRACE", "60"))      # seconds

def _cleanup_stale_fake_folders():
    """
    Remove fake folders older than FAKE_FILE_TTL seconds.
    Runs every 30 seconds so folders disappear promptly after the TTL.
    Uses folder mtime which is touched on every fresh grab, so the timer
    always measures from the most recent add — not the original creation.
    """
    import threading, time, shutil
    def _run():
        while True:
            try:
                now = time.time()
                if os.path.isdir(DOWNLOADS_ROOT):
                    for cat_dir in os.scandir(DOWNLOADS_ROOT):
                        if not cat_dir.is_dir():
                            continue
                        for entry in os.scandir(cat_dir.path):
                            if not entry.is_dir():
                                continue
                            age = now - entry.stat().st_mtime
                            if age > FAKE_FILE_TTL:
                                shutil.rmtree(entry.path, ignore_errors=True)
                                _log.info(
                                    f"Auto-cleaned fake folder "                                    f"({int(age)}s > {FAKE_FILE_TTL}s TTL): {entry.name}"
                                )
            except Exception as e:
                _log.debug(f"Cleanup error: {e}")
            time.sleep(30)  # check every 30s for prompt cleanup
    threading.Thread(target=_run, daemon=True).start()

def _purge_all_fake_folders():
    """
    Every FAKE_PURGE_INTERVAL seconds (default 5 min), remove ALL fake-file
    torrent folders under DOWNLOADS_ROOT — at any nesting depth. A "torrent
    folder" is any directory that directly contains one or more files (e.g.
    DOWNLOADS_ROOT/<category>/<torrent>/file.mkv, or DOWNLOADS_ROOT/<torrent>/
    file.mkv when no category level is used). Pure container folders (the
    category dirs, which hold only sub-directories) are left in place.

    Folders whose mtime is within FAKE_PURGE_GRACE seconds are skipped so a
    fake file that was just created for an active import is not deleted before
    the *arr imports it.
    """
    import threading, time, shutil
    def _run():
        while True:
            time.sleep(FAKE_PURGE_INTERVAL)
            try:
                if not os.path.isdir(DOWNLOADS_ROOT):
                    continue
                now = time.time()
                removed = 0

                # Collect every directory that directly holds files (= a torrent
                # folder), at any depth, before deleting so we don't mutate the
                # tree mid-walk.
                torrent_dirs = []
                for dirpath, dirnames, filenames in os.walk(DOWNLOADS_ROOT):
                    if dirpath == DOWNLOADS_ROOT:
                        # loose files sitting directly in the root get cleaned too
                        for fn in filenames:
                            fp = os.path.join(dirpath, fn)
                            try:
                                if now - os.stat(fp).st_mtime > FAKE_PURGE_GRACE:
                                    os.remove(fp)
                                    removed += 1
                            except OSError:
                                pass
                        continue
                    if filenames:
                        torrent_dirs.append(dirpath)

                for d in torrent_dirs:
                    try:
                        if now - os.stat(d).st_mtime <= FAKE_PURGE_GRACE:
                            continue  # too fresh — may be mid-import
                        shutil.rmtree(d, ignore_errors=True)
                        removed += 1
                    except OSError:
                        pass

                if removed:
                    _log.info(
                        f"Periodic purge: cleared {removed} fake-file torrent "
                        f"folder(s)/file(s) from {DOWNLOADS_ROOT}"
                    )
            except Exception as e:
                _log.debug(f"Purge error: {e}")
    threading.Thread(target=_run, daemon=True).start()

def _fix_downloads_permissions():
    """
    Walk DOWNLOADS_ROOT on startup:
    - Empty torrent folders = file was already moved by Radarr/Sonarr but
      torrents/delete was never called (e.g. container restarted mid-import).
      Remove them and mark the transfer imported so they never reappear.
    - Non-empty folders: ensure 777/666 permissions so Radarr can delete.
    """
    import shutil
    if not os.path.isdir(DOWNLOADS_ROOT):
        return
    try:
        os.chmod(DOWNLOADS_ROOT, 0o777)
    except OSError:
        pass
    for cat_dir in os.scandir(DOWNLOADS_ROOT):
        if not cat_dir.is_dir():
            continue
        try:
            os.chmod(cat_dir.path, 0o777)
        except OSError:
            pass
        for entry in os.scandir(cat_dir.path):
            if not entry.is_dir():
                continue
            files_in_dir = [f for f in os.scandir(entry.path) if f.is_file()]
            if not files_in_dir:
                # Empty folder — clean it up and mark transfer imported
                try:
                    shutil.rmtree(entry.path, ignore_errors=True)
                    _log.info(f"[startup] removed empty fake folder: {entry.path}")
                except OSError:
                    pass
                # Mark transfer imported in DB if we can identify the hash
                if _tm is not None:
                    for t in _tm.all_transfers():
                        t_name = t.get("name") or t["hash"]
                        t_cat  = t.get("category") or ""
                        if _safe_name(t_name) == entry.name:
                            _tm._set(t["hash"], imported=1)
                            _log.info(f"[startup] marked imported: {t['hash'][:8]} ({t_name[:40]})")
                            break
            else:
                # Non-empty — fix permissions
                try:
                    os.chmod(entry.path, 0o777)
                except OSError:
                    pass
                for f in files_in_dir:
                    try:
                        os.chmod(f.path, 0o666)
                    except OSError:
                        pass


def init(transfer_manager):
    global _tm
    _tm = transfer_manager
    _fix_downloads_permissions()  # _tm must be set first for imported marking
    _cleanup_stale_fake_folders()
    _purge_all_fake_folders()


# ── State helpers ─────────────────────────────────────────────────────────────

QBT_STATE = {
    "queued":      "checkingResumeData",
    "cached":      "uploading",    # uploading = seeding = completed download, triggers Arr import
    "downloading": "downloading",
    "complete":    "uploading",    # uploading triggers Arr completed download handler
    "error":       "error",
}

MOUNTPOINT = os.environ.get("FUSE_MOUNTPOINT", "/docker/alldebrid-web/mnt")

# Fake-file download folder.
# When a transfer becomes ready, we create a real folder containing a tiny
# placeholder .mkv file named after the torrent. Radarr/Sonarr import this
# file (it's just a few bytes), register the movie/show in their database,
# then call /torrents/delete. We delete the fake folder — done.
# Plex streams the real file from the FUSE mount independently.
#
#   /docker/alldebrid-web/downloads/
#     radarr/
#       Movie.Name.2024/
#         Movie.Name.2024.mkv    ← 1KB placeholder, gets imported then deleted
#     sonarr/
#       Show.Name.S01E01/
#         Show.Name.S01E01.mkv   ← same

DOWNLOADS_ROOT = os.environ.get("DOWNLOADS_ROOT", "/docker/alldebrid-web/downloads")

# ── NFO generation ────────────────────────────────────────────────────────────
# Plex reads Kodi-style NFO files alongside video files.
# The critical field is <runtime> — if present, Plex uses it instead of
# probing the stub via MediaInfo, which would hit Premiumize's API.

def _xml_esc(s: str) -> str:
    return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

def _parse_stub_meta(filename: str) -> dict:
    """Extract title/year/season/episode from a stub filename for NFO generation."""
    base = os.path.splitext(filename)[0]  # strip extension

    # Episode: SxxExx or Sxx.Exx
    ep_m = re.search(r'S(\d{1,2})[.\s]?E(\d{1,3})', base, re.IGNORECASE)
    if ep_m:
        season  = int(ep_m.group(1))
        episode = int(ep_m.group(2))
        raw     = base[:ep_m.start()].replace('.', ' ').replace('_', ' ')
        title   = re.sub(r'\s+', ' ', raw).strip(' -–')
        return {"kind": "episode", "title": title,
                "season": season, "episode": episode, "year": None}

    # Movie: look for 4-digit year
    yr_m = re.search(r'(?<!\d)((?:19|20)\d{2})(?!\d)', base)
    if yr_m:
        year  = int(yr_m.group(1))
        raw   = base[:yr_m.start()].replace('.', ' ').replace('_', ' ')
        title = re.sub(r'\s+', ' ', raw).strip(' -–')
        return {"kind": "movie", "title": title, "year": year,
                "season": None, "episode": None}

    # Fallback — strip quality tags and use what's left
    raw   = re.sub(
        r'\b(2160p?|1080p?|720p?|480p?|4k|uhd|hdr|bluray|web-?dl|webrip|'
        r'hdtv|x264|x265|hevc|remux|proper|repack|10bit)\b.*',
        '', base, flags=re.IGNORECASE
    )
    title = re.sub(r'\s+', ' ', raw.replace('.', ' ').replace('_', ' ')).strip(' -–')
    return {"kind": "movie", "title": title, "year": None,
            "season": None, "episode": None}


def _make_nfo_content(meta: dict) -> str:
    """Generate Kodi/Plex-compatible NFO XML from parsed metadata."""
    title = _xml_esc(meta.get("title") or "Unknown")

    if meta["kind"] == "episode":
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<episodedetails>\n'
            f'  <title>{title}</title>\n'
            f'  <season>{meta["season"]}</season>\n'
            f'  <episode>{meta["episode"]}</episode>\n'
            '  <runtime>45</runtime>\n'
            '  <plot></plot>\n'
            '</episodedetails>\n'
        )
    else:
        year_tag = f'  <year>{meta["year"]}</year>\n' if meta.get("year") else ''
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<movie>\n'
            f'  <title>{title}</title>\n'
            f'{year_tag}'
            '  <runtime>120</runtime>\n'
            '  <plot></plot>\n'
            '</movie>\n'
        )


def write_nfo(video_path: str) -> str | None:
    """Write a .nfo file alongside a stub video file.
    video_path: full path to the .mkv stub
    Returns the nfo path, or None on failure.
    """
    nfo_path = os.path.splitext(video_path)[0] + ".nfo"
    try:
        filename = os.path.basename(video_path)
        meta     = _parse_stub_meta(filename)
        content  = _make_nfo_content(meta)
        with open(nfo_path, "w", encoding="utf-8") as f:
            f.write(content)
        try:
            os.chmod(nfo_path, 0o666)
        except OSError:
            pass
        return nfo_path
    except Exception as e:
        _log.debug(f"NFO write failed for {video_path}: {e}")
        return None

# ── Fake-file stubs ───────────────────────────────────────────────────────────
# Sonarr/Radarr decide a file's QUALITY from two things:
#   * SOURCE (BluRay/WEB-DL/HDTV...) — parsed from the file NAME only.
#   * RESOLUTION — parsed from the name BUT overridden by MediaInfo when present.
#     In their quality aggregator, Confidence.MediaInfo outranks Confidence.Tag,
#     so the file's real pixel dimensions WIN over the "1080p"/"2160p" in the
#     name. MediaInfo maps dimensions to a resolution tier roughly as:
#         width >=3200            -> 2160p
#         width >=1800            -> 1080p
#         width >=1200            -> 720p
#         height>=560 (w<1000)    -> 576p
#         anything else >0        -> 480p
# A fixed tiny 2x2 stub therefore makes EVERYTHING import as 480p, regardless of
# the release name. To report the correct quality we ship one black stub per
# resolution tier (in ./stubs) and pick the one matching the release name, so
# MediaInfo and the name agree. Each stub is a real ~11-minute (660s) h264/aac
# file — long enough to clear the flat 600s sample-detection threshold — and,
# being static black, compresses to well under a few hundred KB.
#
# Regenerate a stub with (example for 1080p):
#   ffmpeg -f lavfi -i color=c=black:s=1920x1080:r=1 -f lavfi -i anullsrc=r=8000:cl=mono \
#     -t 660 -map_metadata -1 -c:v libx264 -preset ultrafast -crf 51 \
#     -pix_fmt yuv420p -g 60 -c:a aac -b:a 8k stubs/1080p.mkv
import base64 as _b64

_STUB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stubs")

# Resolution tiers we ship stubs for, in descending order. The value is the
# stub filename under _STUB_DIR.
_RES_STUBS = {
    "2160p": "2160p.mkv",
    "1080p": "1080p.mkv",
    "720p":  "720p.mkv",
    "576p":  "576p.mkv",
    "480p":  "480p.mkv",
}

# Resolution detection from the release name. Mirrors how Radarr/Sonarr parse
# the resolution token so our stub matches what they'd read from the name.
# Order matters: check highest-res tokens first.
_RES_PATTERNS = [
    ("2160p", re.compile(r"(?i)(2160[ip]|\b4k\b|\buhd\b|3840[\s._x-]?2160|4096[\s._x-]?2160)")),
    ("1080p", re.compile(r"(?i)(1080[ip]|1440[ip]?|1920[\s._x-]?1080)")),
    ("720p",  re.compile(r"(?i)(720[ip]|1280[\s._x-]?720)")),
    ("576p",  re.compile(r"(?i)(576[ip]|720[\s._x-]?576|pal\b)")),
    ("480p",  re.compile(r"(?i)(480[ip]|360[ip]|640[\s._x-]?480|848[\s._x-]?480|ntsc\b|\bsd\b|dvdrip|dvd-?r)")),
]

# Default tier when the name carries no resolution token. 1080p is by far the
# most common modern release and the safest assumption.
_DEFAULT_RES = "1080p"

# Embedded 1080p stub, used only as a last-resort fallback if the stubs/ assets
# are missing from the image for some reason — keeps the mock functional.
_FALLBACK_1080P = _b64.b64decode(
    "GkXfo6NChoEBQveBAULygQRC84EIQoKIbWF0cm9za2FCh4EEQoWBAhhTgGcBAAAAAAIOnRFNm3TBv4QT5TN0TbuLU6uEFUmpZlOsgaFNu4tTq4QWVK5rU6yBzE27jFOrhBJUw2dTrIIBtE27jVOrhBxTu2tTrIMCDb7sAQAAAAAAAFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFUmpZqa/hPDLqLwq17GDD0JATYCETGF2ZldBhExhdmZEiYhBJCVAAAAAABZUrmtA4r+Er/Un1K4BAAAAAAAAf9eBAXPFiAAAAAAAAAABnIEAIrWcg3VuZIiBAIaPVl9NUEVHNC9JU08vQVZDg4EBI+ODhDuaygDgi7CCB4C6ggQ4moECVe6BAOwBAAAAAAAAAgAAY6KpAULAKP/hABlnQsAo2gHgCJ+XARAAAAMAEAAAAwAg8YMqAQAFaM4BlyCuAQAAAAAAAEvXgQJzxYgAAAAAAAAAApyBACK1nIN1bmSIgQCGhUFfQUFDVqqEB6EgAIOBAuGRn4EBtYhAv0AAAAAAAGJkgSBV7oEAY6KFFYhW5QASVMNnQKS/hJ6bJ51zc85jwItjxYgAAAAAAAAAAWfImUWjh0VOQ09ERVJEh4xMYXZjIGxpYngyNjRnyKFFo4hEVVJBVElPTkSHkzAwOjExOjAwLjAwMDAwMDAwMABzc8pjwItjxYgAAAAAAAAAAmfIlUWjh0VOQ09ERVJEh4hMYXZjIGFhY2fIoUWjiERVUkFUSU9ORIeTMDA6MTE6MDAuMTI4MDAwMDAwAB9DtnVcRr+E9Mf2WueBAKOIggAAgAEYIAejWmyBAACAAAACUgYF//9O3EXpvebZSLeWLNgg2SPu73gyNjQgLSBjb3JlIDE2NCByMzEwOCAzMWUxOWY5IC0gSC4yNjQvTVBFRy00IEFWQyBjb2RlYyAtIENvcHlsZWZ0IDIwMDMtMjAyMyAtIGh0dHA6Ly93d3cudmlkZW9sYW4ub3JnL3gyNjQuaHRtbCAtIG9wdGlvbnM6IGNhYmFjPTAgcmVmPTEgZGVibG9jaz0wOjA6MCBhbmFseXNlPTA6MCBtZT1kaWEgc3VibWU9MCBwc3k9MSBwc3lfcmQ9MS4wMDowLjAwIG1peGVkX3JlZj0wIG1lX3JhbmdlPTE2IGNocm9tYV9tZT0xIHRyZWxsaXM9MCA4eDhkY3Q9MCBjcW09MCBkZWFkem9uZT0yMSwxMSBmYXN0X3Bza2lwPTEgY2hyb21hX3FwX29mZnNldD0wIHRocmVhZHM9MSBsb29rYWhlYWRfdGhyZWFkcz0xIHNsaWNlZF90aHJlYWRzPTAgbnI9MCBkZWNpbWF0ZT0xIGludGVybGFjZWQ9MCBibHVyYXlfY29tcGF0PTAgY29uc3RyYWluZWRfaW50cmE9MCBiZnJhbWVzPTAgd2VpZ2h0cD0wIGtleWludD02MCBrZXlpbnRfbWluPTEgc2NlbmVjdXQ9MCBpbnRyYV9yZWZyZXNoPTAgcmM9Y3JmIG1idHJlZT0wIGNyZj01MS4wIHFjb21wPTAuNjAgcXBtaW49MCBxcG1heD02OSBxcHN0ZXA9NCBpcF9yYXRpbz0xLjQwIGFxPTAAgAAAGA5liIQ6JigAFZOTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrwKOIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo5CBA+gAAAAACEGaIBSgAP8Mo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejkIEH0AAAAAAIQZpAFaAA/wyjiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OQgQu4AAAAAAhBmmAVoAD/DKOIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo5CBD6AAAAAACEGagBagAP8Mo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHH0O2dUHqv4SCf3/b54ITgKOIggAAgAEYIAejiIIAgIABGCAHo5CBAAgAAAAACEGaoBagAP8Mo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OQgQPwAAAAAAhBmsAWoAD/DKOIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo5CBB9gAAAAACEGa4BagAP8Mo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejkIELwAAAAAAIQZsAFqAA/wyjiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OQgQ+oAAAAAAhBmyAWoAD/DKOIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggBx9DtnVB6r+EMpyek+eCJwCjiIIAAIABGCAHo4iCAICAARggB6OQgQAQAAAAAAhBm0AWoAD/DKOIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejkIED+AAAAAAIQZtgFqAA/wyjiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OQgQfgAAAAAAhBm4AWoAD/DKOIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo5CBC8gAAAAACEGboBagAP8Mo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejkIEPsAAAAAAIQZvAFqAA/wyjiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeq/hOSleFHngjqAo4iCAACAARggB6OIggCAgAEYIAejkIEAGAAAAAAIQZvgFqAA/wyjiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo5CBBAAAAAAACEGaABagAP8Mo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejkIEH6AAAAAAIQZogFqAA/wyjiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OQgQvQAAAAAAhBmkAWoAD/DKOIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo5CBD7gAAAAACEGaYBagAP8Mo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHH0O2dUHqv4RKoawO54JOAKOIggAAgAEYIAejiIIAgIABGCAHo5CBACAAAAAACEGagBagAP8Mo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejkIEECAAAAAAIQZqgFqAA/wyjiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo5CBB/AAAAAACEGawBagAP8Mo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejkIEL2AAAAAAIQZrgFqAA/wyjiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OQgQ/AAAAAAAhBmwAWoAD/DKOIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggBx9DtnVB6r+EBpeG0eeCYYCjiIIAAIABGCAHo4iCAICAARggB6OQgQAoAAAAAAhBmyAWoAD/DKOIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo5CBBBAAAAAACEGbQBagAP8Mo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OQgQf4AAAAAAhBm2AWoAD/DKOIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo5CBC+AAAAAACEGbgBagAP8Mo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejkIEPyAAAAAAIQZugFqAA/wyjiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeq/hCw/9izngnUAo4iCAACAARggB6OIggCAgAEYIAejkIEAMAAAAAAIQZvAFqAA/wyjiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OQgQQYAAAAAAhBm+AWoAD/DKOIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejkIEIAAAAAAAIQZoAFqAA/wyjiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OQgQvoAAAAAAhBmiAWoAD/DKOIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo5CBD9AAAAAACEGaQBagAP8Mo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHH0O2dUHqv4QDkA2w54KIgKOIggAAgAEYIAejiIIAgIABGCAHo5CBADgAAAAACEGaYBagAP8Mo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejkIEEIAAAAAAIQZqAFqAA/wyjiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OQgQgIAAAAAAhBmqAWoAD/DKOIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejkIEL8AAAAAAIQZrAFqAA/wyjiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OQgQ/YAAAAAAhBmuAWoAD/DKOIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggBx9DtnVB6r+Etao4QeeCnACjiIIAAIABGCAHo4iCAICAARggB6OQgQBAAAAAAAhBmwAWoAD/DKOIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo5CBBCgAAAAACEGbIBagAP8Mo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejkIEIEAAAAAAIQZtAFqAA/wyjiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo5CBC/gAAAAACEGbYBagAP8Mo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejkIEP4AAAAAAIQZuAFqAA/wyjiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeq/hFIrqkDngq+Ao4iCAACAARggB6OIggCAgAEYIAejkIEASAAAAAAIQZugFqAA/wyjiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OQgQQwAAAAAAhBm8AWoAD/DKOIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo5CBCBgAAAAACEGb4BagAP8Mo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OQgQwAAAAAAAhBmgAWoAD/DKOIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo5CBD+gAAAAACEGaIBagAP8Mo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHH0O2dUHqv4QtOVd254LDAKOIggAAgAEYIAejiIIAgIABGCAHo5CBAFAAAAAACEGaQBagAP8Mo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejkIEEOAAAAAAIQZpgFqAA/wyjiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OQgQggAAAAAAhBmoAWoAD/DKOIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo5CBDAgAAAAACEGaoBagAP8Mo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OQgQ/wAAAAAAhBmsAWoAD/DKOIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggBx9DtnVB6r+EPGWNu+eC1oCjiIIAAIABGCAHo4iCAICAARggB6OQgQBYAAAAAAhBmuAWoAD/DKOIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo5CBBEAAAAAACEGbABagAP8Mo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejkIEIKAAAAAAIQZsgFqAA/wyjiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OQgQwQAAAAAAhBm0AWoAD/DKOIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejkIEP+AAAAAAIQZtgFqAA/wyjiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1WfO/hPJwBb3nguoAo4iCAACAARggB6OIggCAgAEYIAejWBiBAGCAAAAYEGWIggGaJigACHnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJyddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddeCjiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OQgQRIAAAAAAhBmiAVoAD/DKOIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo5CBCDAAAAAACEGaQBWgAP8Mo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejkIEMGAAAAAAIQZpgFaAA/wyjiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo5CBEAAAAAAACEGagBagAP8Mo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHH0O2dUHqv4RvJLen54L9gKOIggAAgAEYIAejiIIAgIABGCAHo5CBAGgAAAAACEGaoBagAP8Mo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejkIEEUAAAAAAIQZrAFqAA/wyjiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OQgQg4AAAAAAhBmuAWoAD/DKOIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo5CBDCAAAAAACEGbABagAP8Mo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejkIEQCAAAAAAIQZsgFqAA/wyjiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggBx9DtnVB67+ESKRWceeDAREAo4iCAACAARggB6OIggCAgAEYIAejkIEAcAAAAAAIQZtAFqAA/wyjiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OQgQRYAAAAAAhBm2AWoAD/DKOIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo5CBCEAAAAAACEGbgBagAP8Mo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejkIEMKAAAAAAIQZugFqAA/wyjiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OQgRAQAAAAAAhBm8AWoAD/DKOIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHH0O2dUHrv4Qa6I0654MBJICjiIIAAIABGCAHo4iCAICAARggB6OQgQB4AAAAAAhBm+AWoAD/DKOIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo5CBBGAAAAAACEGaABagAP8Mo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejkIEISAAAAAAIQZogFqAA/wyjiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OQgQwwAAAAAAhBmkAWoAD/DKOIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo5CBEBgAAAAACEGaYBagAP8Mo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeu/hKo2f8PngwE4AKOIggAAgAEYIAejiIIAgIABGCAHo5CBAIAAAAAACEGagBagAP8Mo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejkIEEaAAAAAAIQZqgFqAA/wyjiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OQgQhQAAAAAAhBmsAWoAD/DKOIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo5CBDDgAAAAACEGa4BagAP8Mo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejkIEQIAAAAAAIQZsAFqAA/wyjiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggBx9DtnVB67+EQL+gyOeDAUuAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo5CBAIgAAAAACEGbIBagAP8Mo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OQgQRwAAAAAAhBm0AWoAD/DKOIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo5CBCFgAAAAACEGbYBagAP8Mo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejkIEMQAAAAAAIQZuAFqAA/wyjiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OQgRAoAAAAAAhBm6AWoAD/DKOIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHH0O2dUHrv4Q/PCHC54MBXwCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejkIEAkAAAAAAIQZvAFqAA/wyjiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo5CBBHgAAAAACEGb4BagAP8Mo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejkIEIYAAAAAAIQZoAFqAA/wyjiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OQgQxIAAAAAAhBmiAWoAD/DKOIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo5CBEDAAAAAACEGaQBagAP8Mo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeu/hFidM4LngwFygKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OQgQCYAAAAAAhBmmAWoAD/DKOIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejkIEEgAAAAAAIQZqAFqAA/wyjiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OQgQhoAAAAAAhBmqAWoAD/DKOIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo5CBDFAAAAAACEGawBagAP8Mo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejkIEQOAAAAAAIQZrgFqAA/wyjiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggBx9DtnVB67+EOcXwhOeDAYYAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo5CBAKAAAAAACEGbABagAP8Mo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejkIEEiAAAAAAIQZsgFqAA/wyjiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo5CBCHAAAAAACEGbQBagAP8Mo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejkIEMWAAAAAAIQZtgFqAA/wyjiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OQgRBAAAAAAAhBm4AWoAD/DKOIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHH0O2dUHrv4QDJ1oa54MBmYCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejkIEAqAAAAAAIQZugFqAA/wyjiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OQgQSQAAAAAAhBm8AWoAD/DKOIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejkIEIeAAAAAAIQZvgFqAA/wyjiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OQgQxgAAAAAAhBmgAWoAD/DKOIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo5CBEEgAAAAACEGaIBagAP8Mo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeu/hKC70ojngwGtAKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OQgQCwAAAAAAhBmkAWoAD/DKOIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo5CBBJgAAAAACEGaYBagAP8Mo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OQgQiAAAAAAAhBmoAWoAD/DKOIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo5CBDGgAAAAACEGaoBagAP8Mo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejkIEQUAAAAAAIQZrAFqAA/wyjiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggBx9DtnVB67+EVHjNwueDAcCAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo5CBALgAAAAACEGa4BagAP8Mo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejkIEEoAAAAAAIQZsAFqAA/wyjiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OQgQiIAAAAAAhBmyAWoAD/DKOIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejkIEMcAAAAAAIQZtAFqAA/wyjiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OQgRBYAAAAAAhBm2AWoAD/DKOIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHH0O2dVn0v4SVewG454MB1ACjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejWBiBAMCAAAAYEGWIhAZomKAAIecnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJ1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111114CjiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OQgQSoAAAAAAhBmiAVoAD/DKOIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo5CBCJAAAAAACEGaQBWgAP8Mo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OQgQx4AAAAAAhBmmAVoAD/DKOIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo5CBEGAAAAAACEGagBagAP8Mo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeu/hEMoLzjngwHngKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OQgQDIAAAAAAhBmqAWoAD/DKOIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo5CBBLAAAAAACEGawBagAP8Mo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejkIEImAAAAAAIQZrgFqAA/wyjiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo5CBDIAAAAAACEGbABagAP8Mo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejkIEQaAAAAAAIQZsgFqAA/wyjiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggBx9DtnVB67+Ef0WGAueDAfsAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo5CBANAAAAAACEGbQBagAP8Mo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejkIEEuAAAAAAIQZtgFqAA/wyjiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OQgQigAAAAAAhBm4AWoAD/DKOIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo5CBDIgAAAAACEGboBagAP8Mo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OQgRBwAAAAAAhBm8AWoAD/DKOIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHH0O2dUHrv4SjtDjG54MCDoCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejkIEA2AAAAAAIQZvgFqAA/wyjiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OQgQTAAAAAAAhBmgAWoAD/DKOIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo5CBCKgAAAAACEGaIBagAP8Mo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejkIEMkAAAAAAIQZpAFqAA/wyjiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo5CBEHgAAAAACEGaYBagAP8Mo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeu/hIGmLOnngwIiAKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OQgQDgAAAAAAhBmoAWoAD/DKOIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo5CBBMgAAAAACEGaoBagAP8Mo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejkIEIsAAAAAAIQZrAFqAA/wyjiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OQgQyYAAAAAAhBmuAWoAD/DKOIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejkIEQgAAAAAAIQZsAFqAA/wyjiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggBx9DtnVB67+Et0bTmeeDAjWAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo5CBAOgAAAAACEGbIBagAP8Mo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejkIEE0AAAAAAIQZtAFqAA/wyjiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OQgQi4AAAAAAhBm2AWoAD/DKOIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo5CBDKAAAAAACEGbgBagAP8Mo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejkIEQiAAAAAAIQZugFqAA/wyjiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHH0O2dUHrv4TPo93O54MCSQCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejkIEA8AAAAAAIQZvAFqAA/wyjiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OQgQTYAAAAAAhBm+AWoAD/DKOIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo5CBCMAAAAAACEGaABagAP8Mo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejkIEMqAAAAAAIQZogFqAA/wyjiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OQgRCQAAAAAAhBmkAWoAD/DKOIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeu/hHCIwL7ngwJcgKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OQgQD4AAAAAAhBmmAWoAD/DKOIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo5CBBOAAAAAACEGagBagAP8Mo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejkIEIyAAAAAAIQZqgFqAA/wyjiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OQgQywAAAAAAhBmsAWoAD/DKOIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo5CBEJgAAAAACEGa4BagAP8Mo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggBx9DtnVB67+EYn5sNeeDAnAAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo5CBAQAAAAAACEGbABagAP8Mo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejkIEE6AAAAAAIQZsgFqAA/wyjiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OQgQjQAAAAAAhBm0AWoAD/DKOIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo5CBDLgAAAAACEGbYBagAP8Mo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejkIEQoAAAAAAIQZuAFqAA/wyjiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHH0O2dUHrv4TuYxyH54MCg4CjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo5CBAQgAAAAACEGboBagAP8Mo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OQgQTwAAAAAAhBm8AWoAD/DKOIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo5CBCNgAAAAACEGb4BagAP8Mo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejkIEMwAAAAAAIQZoAFqAA/wyjiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OQgRCoAAAAAAhBmiAWoAD/DKOIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeu/hOjkObnngwKXAKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejkIEBEAAAAAAIQZpAFqAA/wyjiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo5CBBPgAAAAACEGaYBagAP8Mo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejkIEI4AAAAAAIQZqAFqAA/wyjiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OQgQzIAAAAAAhBmqAWoAD/DKOIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo5CBELAAAAAACEGawBagAP8Mo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggBx9DtnVB67+EvJb4beeDAqqAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OQgQEYAAAAAAhBmuAWoAD/DKOIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejkIEFAAAAAAAIQZsAFqAA/wyjiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OQgQjoAAAAAAhBmyAWoAD/DKOIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo5CBDNAAAAAACEGbQBagAP8Mo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejkIEQuAAAAAAIQZtgFqAA/wyjiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHH0O2dVn0v4Q5/Zr954MCvgCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo1gYgQEggAAAGBBliIIBmiYoAAh5ycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXgo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejkIEFCAAAAAAIQZogFaAA/wyjiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo5CBCPAAAAAACEGaQBWgAP8Mo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejkIEM2AAAAAAIQZpgFaAA/wyjiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OQgRDAAAAAAAhBmoAWoAD/DKOIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeu/hCBrE9fngwLRgKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejkIEBKAAAAAAIQZqgFqAA/wyjiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OQgQUQAAAAAAhBmsAWoAD/DKOIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejkIEI+AAAAAAIQZrgFqAA/wyjiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OQgQzgAAAAAAhBmwAWoAD/DKOIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo5CBEMgAAAAACEGbIBagAP8Mo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggBx9DtnVB67+EWmBKoOeDAuUAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OQgQEwAAAAAAhBm0AWoAD/DKOIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo5CBBRgAAAAACEGbYBagAP8Mo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OQgQkAAAAAAAhBm4AWoAD/DKOIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo5CBDOgAAAAACEGboBagAP8Mo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejkIEQ0AAAAAAIQZvAFqAA/wyjiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHH0O2dUHrv4RCJluX54MC+ICjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo5CBATgAAAAACEGb4BagAP8Mo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejkIEFIAAAAAAIQZoAFqAA/wyjiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OQgQkIAAAAAAhBmiAWoAD/DKOIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejkIEM8AAAAAAIQZpAFqAA/wyjiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OQgRDYAAAAAAhBmmAWoAD/DKOIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeu/hBMbpxTngwMMAKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejkIEBQAAAAAAIQZqAFqAA/wyjiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OQgQUoAAAAAAhBmqAWoAD/DKOIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo5CBCRAAAAAACEGawBagAP8Mo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OQgQz4AAAAAAhBmuAWoAD/DKOIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo5CBEOAAAAAACEGbABagAP8Mo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggBx9DtnVB67+EngUaLOeDAx+Ao4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OQgQFIAAAAAAhBmyAWoAD/DKOIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo5CBBTAAAAAACEGbQBagAP8Mo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejkIEJGAAAAAAIQZtgFqAA/wyjiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo5CBDQAAAAAACEGbgBagAP8Mo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejkIEQ6AAAAAAIQZugFqAA/wyjiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHH0O2dUHrv4Ql1M3t54MDMwCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo5CBAVAAAAAACEGbwBagAP8Mo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejkIEFOAAAAAAIQZvgFqAA/wyjiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OQgQkgAAAAAAhBmgAWoAD/DKOIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo5CBDQgAAAAACEGaIBagAP8Mo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OQgRDwAAAAAAhBmkAWoAD/DKOIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeu/hOjuH0DngwNGgKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejkIEBWAAAAAAIQZpgFqAA/wyjiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OQgQVAAAAAAAhBmoAWoAD/DKOIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo5CBCSgAAAAACEGaoBagAP8Mo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejkIENEAAAAAAIQZrAFqAA/wyjiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo5CBEPgAAAAACEGa4BagAP8Mo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggBx9DtnVB67+Eyq0ut+eDA1oAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OQgQFgAAAAAAhBmwAWoAD/DKOIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo5CBBUgAAAAACEGbIBagAP8Mo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejkIEJMAAAAAAIQZtAFqAA/wyjiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OQgQ0YAAAAAAhBm2AWoAD/DKOIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejkIERAAAAAAAIQZuAFqAA/wyjiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHH0O2dUHrv4Qi1w9j54MDbYCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo5CBAWgAAAAACEGboBagAP8Mo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejkIEFUAAAAAAIQZvAFqAA/wyjiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OQgQk4AAAAAAhBm+AWoAD/DKOIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo5CBDSAAAAAACEGaABagAP8Mo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejkIERCAAAAAAIQZogFqAA/wyjiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeu/hAfiFNLngwOBAKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejkIEBcAAAAAAIQZpAFqAA/wyjiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OQgQVYAAAAAAhBmmAWoAD/DKOIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo5CBCUAAAAAACEGagBagAP8Mo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejkIENKAAAAAAIQZqgFqAA/wyjiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OQgREQAAAAAAhBmsAWoAD/DKOIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggBx9DtnVB67+ET6Th2ueDA5SAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OQgQF4AAAAAAhBmuAWoAD/DKOIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo5CBBWAAAAAACEGbABagAP8Mo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejkIEJSAAAAAAIQZsgFqAA/wyjiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OQgQ0wAAAAAAhBm0AWoAD/DKOIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo5CBERgAAAAACEGbYBagAP8Mo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHH0O2dVn0v4QPkp2e54MDqACjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo1gYgQGAgAAAGBBliIQGaJigACHnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJyddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddeAo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejkIEFaAAAAAAIQZogFaAA/wyjiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OQgQlQAAAAAAhBmkAVoAD/DKOIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo5CBDTgAAAAACEGaYBWgAP8Mo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejkIERIAAAAAAIQZqAFqAA/wyjiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeu/hFxhmLzngwO7gKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo5CBAYgAAAAACEGaoBagAP8Mo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OQgQVwAAAAAAhBmsAWoAD/DKOIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo5CBCVgAAAAACEGa4BagAP8Mo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejkIENQAAAAAAIQZsAFqAA/wyjiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OQgREoAAAAAAhBmyAWoAD/DKOIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggBx9DtnVB67+Ea++nYueDA88Ao4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejkIEBkAAAAAAIQZtAFqAA/wyjiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo5CBBXgAAAAACEGbYBagAP8Mo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejkIEJYAAAAAAIQZuAFqAA/wyjiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OQgQ1IAAAAAAhBm6AWoAD/DKOIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo5CBETAAAAAACEGbwBagAP8Mo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHH0O2dUHrv4TUQ61D54MD4oCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OQgQGYAAAAAAhBm+AWoAD/DKOIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejkIEFgAAAAAAIQZoAFqAA/wyjiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OQgQloAAAAAAhBmiAWoAD/DKOIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo5CBDVAAAAAACEGaQBagAP8Mo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejkIEROAAAAAAIQZpgFqAA/wyjiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeu/hOSb//PngwP2AKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo5CBAaAAAAAACEGagBagAP8Mo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejkIEFiAAAAAAIQZqgFqAA/wyjiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo5CBCXAAAAAACEGawBagAP8Mo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejkIENWAAAAAAIQZrgFqAA/wyjiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OQgRFAAAAAAAhBmwAWoAD/DKOIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggBx9DtnVB67+EBndEQOeDBAmAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejkIEBqAAAAAAIQZsgFqAA/wyjiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OQgQWQAAAAAAhBm0AWoAD/DKOIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejkIEJeAAAAAAIQZtgFqAA/wyjiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OQgQ1gAAAAAAhBm4AWoAD/DKOIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo5CBEUgAAAAACEGboBagAP8Mo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHH0O2dUHrv4TQSRIn54MEHQCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OQgQGwAAAAAAhBm8AWoAD/DKOIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo5CBBZgAAAAACEGb4BagAP8Mo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OQgQmAAAAAAAhBmgAWoAD/DKOIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo5CBDWgAAAAACEGaIBagAP8Mo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejkIERUAAAAAAIQZpAFqAA/wyjiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeu/hPIlL3TngwQwgKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo5CBAbgAAAAACEGaYBagAP8Mo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejkIEFoAAAAAAIQZqAFqAA/wyjiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OQgQmIAAAAAAhBmqAWoAD/DKOIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejkIENcAAAAAAIQZrAFqAA/wyjiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OQgRFYAAAAAAhBmuAWoAD/DKOIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggBx9DtnVB67+EWlPSyueDBEQAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejkIEBwAAAAAAIQZsAFqAA/wyjiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OQgQWoAAAAAAhBmyAWoAD/DKOIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo5CBCZAAAAAACEGbQBagAP8Mo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OQgQ14AAAAAAhBm2AWoAD/DKOIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo5CBEWAAAAAACEGbgBagAP8Mo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHH0O2dUHrv4T7RvDw54MEV4CjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OQgQHIAAAAAAhBm6AWoAD/DKOIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo5CBBbAAAAAACEGbwBagAP8Mo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejkIEJmAAAAAAIQZvgFqAA/wyjiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo5CBDYAAAAAACEGaABagAP8Mo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejkIERaAAAAAAIQZogFqAA/wyjiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeu/hBqQo//ngwRrAKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo5CBAdAAAAAACEGaQBagAP8Mo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejkIEFuAAAAAAIQZpgFqAA/wyjiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OQgQmgAAAAAAhBmoAWoAD/DKOIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo5CBDYgAAAAACEGaoBagAP8Mo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OQgRFwAAAAAAhBmsAWoAD/DKOIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggBx9DtnVB67+Etlohb+eDBH6Ao4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejkIEB2AAAAAAIQZrgFqAA/wyjiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OQgQXAAAAAAAhBmwAWoAD/DKOIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo5CBCagAAAAACEGbIBagAP8Mo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejkIENkAAAAAAIQZtAFqAA/wyjiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo5CBEXgAAAAACEGbYBagAP8Mo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHH0O2dVn0v4Soj9ay54MEkgCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6NYGIEB4IAAABgQZYiCAZomKAAIecnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJ1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111114KOIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo5CBBcgAAAAACEGaIBWgAP8Mo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejkIEJsAAAAAAIQZpAFaAA/wyjiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OQgQ2YAAAAAAhBmmAVoAD/DKOIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejkIERgAAAAAAIQZqAFqAA/wyjiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeu/hHoa+MHngwSlgKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo5CBAegAAAAACEGaoBagAP8Mo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejkIEF0AAAAAAIQZrAFqAA/wyjiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OQgQm4AAAAAAhBmuAWoAD/DKOIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo5CBDaAAAAAACEGbABagAP8Mo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejkIERiAAAAAAIQZsgFqAA/wyjiIISgIABGCAHo4iCEwCAARggBx9DtnVB67+Evl8jVeeDBLkAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejkIEB8AAAAAAIQZtAFqAA/wyjiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OQgQXYAAAAAAhBm2AWoAD/DKOIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo5CBCcAAAAAACEGbgBagAP8Mo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejkIENqAAAAAAIQZugFqAA/wyjiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OQgRGQAAAAAAhBm8AWoAD/DKOIghKAgAEYIAejiIITAIABGCAHH0O2dUHrv4RDSmad54MEzICjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OQgQH4AAAAAAhBm+AWoAD/DKOIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo5CBBeAAAAAACEGaABagAP8Mo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejkIEJyAAAAAAIQZogFqAA/wyjiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OQgQ2wAAAAAAhBmkAWoAD/DKOIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo5CBEZgAAAAACEGaYBagAP8Mo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeu/hIGOJmDngwTgAKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo5CBAgAAAAAACEGagBagAP8Mo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejkIEF6AAAAAAIQZqgFqAA/wyjiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OQgQnQAAAAAAhBmsAWoAD/DKOIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo5CBDbgAAAAACEGa4BagAP8Mo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejkIERoAAAAAAIQZsAFqAA/wyjiIISgIABGCAHo4iCEwCAARggBx9DtnVB67+EVOVUqueDBPOAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo5CBAggAAAAACEGbIBagAP8Mo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OQgQXwAAAAAAhBm0AWoAD/DKOIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo5CBCdgAAAAACEGbYBagAP8Mo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejkIENwAAAAAAIQZuAFqAA/wyjiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OQgRGoAAAAAAhBm6AWoAD/DKOIghKAgAEYIAejiIITAIABGCAHH0O2dUHrv4RHQR2r54MFBwCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejkIECEAAAAAAIQZvAFqAA/wyjiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo5CBBfgAAAAACEGb4BagAP8Mo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejkIEJ4AAAAAAIQZoAFqAA/wyjiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OQgQ3IAAAAAAhBmiAWoAD/DKOIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo5CBEbAAAAAACEGaQBagAP8Mo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeu/hAOkyKfngwUagKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OQgQIYAAAAAAhBmmAWoAD/DKOIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejkIEGAAAAAAAIQZqAFqAA/wyjiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OQgQnoAAAAAAhBmqAWoAD/DKOIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo5CBDdAAAAAACEGawBagAP8Mo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejkIERuAAAAAAIQZrgFqAA/wyjiIISgIABGCAHo4iCEwCAARggBx9DtnVB67+Ex6MfWOeDBS4Ao4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo5CBAiAAAAAACEGbABagAP8Mo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejkIEGCAAAAAAIQZsgFqAA/wyjiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo5CBCfAAAAAACEGbQBagAP8Mo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejkIEN2AAAAAAIQZtgFqAA/wyjiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OQgRHAAAAAAAhBm4AWoAD/DKOIghKAgAEYIAejiIITAIABGCAHH0O2dUHrv4RIjqQf54MFQYCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejkIECKAAAAAAIQZugFqAA/wyjiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OQgQYQAAAAAAhBm8AWoAD/DKOIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejkIEJ+AAAAAAIQZvgFqAA/wyjiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OQgQ3gAAAAAAhBmgAWoAD/DKOIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo5CBEcgAAAAACEGaIBagAP8Mo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeu/hHyTDqDngwVVAKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OQgQIwAAAAAAhBmkAWoAD/DKOIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo5CBBhgAAAAACEGaYBagAP8Mo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OQgQoAAAAAAAhBmoAWoAD/DKOIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo5CBDegAAAAACEGaoBagAP8Mo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejkIER0AAAAAAIQZrAFqAA/wyjiIISgIABGCAHo4iCEwCAARggBx9DtnVB67+EtjhapOeDBWiAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo5CBAjgAAAAACEGa4BagAP8Mo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejkIEGIAAAAAAIQZsAFqAA/wyjiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OQgQoIAAAAAAhBmyAWoAD/DKOIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejkIEN8AAAAAAIQZtAFqAA/wyjiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OQgRHYAAAAAAhBm2AWoAD/DKOIghKAgAEYIAejiIITAIABGCAHH0O2dVn0v4QRDO7x54MFfACjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejWBiBAkCAAAAYEGWIhAZomKAAIecnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJ1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111114CjiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OQgQYoAAAAAAhBmiAVoAD/DKOIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo5CBChAAAAAACEGaQBWgAP8Mo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OQgQ34AAAAAAhBmmAVoAD/DKOIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo5CBEeAAAAAACEGagBagAP8Mo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeu/hIGfjLLngwWPgKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OQgQJIAAAAAAhBmqAWoAD/DKOIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo5CBBjAAAAAACEGawBagAP8Mo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejkIEKGAAAAAAIQZrgFqAA/wyjiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo5CBDgAAAAAACEGbABagAP8Mo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejkIER6AAAAAAIQZsgFqAA/wyjiIISgIABGCAHo4iCEwCAARggBx9DtnVB67+EVUnKWueDBaMAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo5CBAlAAAAAACEGbQBagAP8Mo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejkIEGOAAAAAAIQZtgFqAA/wyjiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OQgQogAAAAAAhBm4AWoAD/DKOIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo5CBDggAAAAACEGboBagAP8Mo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OQgRHwAAAAAAhBm8AWoAD/DKOIghKAgAEYIAejiIITAIABGCAHH0O2dUHrv4TQ2sDy54MFtoCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejkIECWAAAAAAIQZvgFqAA/wyjiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OQgQZAAAAAAAhBmgAWoAD/DKOIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo5CBCigAAAAACEGaIBagAP8Mo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejkIEOEAAAAAAIQZpAFqAA/wyjiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo5CBEfgAAAAACEGaYBagAP8Mo4iCEoCAARggB6OIghMAgAEYIAcfQ7Z1Qeu/hFheOY3ngwXKAKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OQgQJgAAAAAAhBmoAWoAD/DKOIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo5CBBkgAAAAACEGaoBagAP8Mo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejkIEKMAAAAAAIQZrAFqAA/wyjiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OQgQ4YAAAAAAhBmuAWoAD/DKOIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejkIESAAAAAAAIQZsAFqAA/wyjiIISgIABGCAHo4iCEwCAARggBx9DtnVB67+EzTHl2OeDBd2Ao4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo5CBAmgAAAAACEGbIBagAP8Mo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejkIEGUAAAAAAIQZtAFqAA/wyjiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OQgQo4AAAAAAhBm2AWoAD/DKOIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo5CBDiAAAAAACEGbgBagAP8Mo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejkIESCAAAAAAIQZugFqAA/wyjiIITAIABGCAHH0O2dUHrv4TARbbU54MF8QCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejkIECcAAAAAAIQZvAFqAA/wyjiIIDAIABGCAHo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OQgQZYAAAAAAhBm+AWoAD/DKOIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo5CBCkAAAAAACEGaABagAP8Mo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejkIEOKAAAAAAIQZogFqAA/wyjiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OQgRIQAAAAAAhBmkAWoAD/DKOIghMAgAEYIAcfQ7Z1Qeu/hAf+RRXngwYEgKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OQgQJ4AAAAAAhBmmAWoAD/DKOIggMAgAEYIAejiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo5CBBmAAAAAACEGagBagAP8Mo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejkIEKSAAAAAAIQZqgFqAA/wyjiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OQgQ4wAAAAAAhBmsAWoAD/DKOIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo5CBEhgAAAAACEGa4BagAP8Mo4iCEwCAARggBx9DtnVB67+E1lrIDeeDBhgAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo5CBAoAAAAAACEGbABagAP8Mo4iCAwCAARggB6OIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejkIEGaAAAAAAIQZsgFqAA/wyjiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OQgQpQAAAAAAhBm0AWoAD/DKOIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo5CBDjgAAAAACEGbYBagAP8Mo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejkIESIAAAAAAIQZuAFqAA/wyjiIITAIABGCAHH0O2dUHrv4TJy5V354MGK4CjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo5CBAogAAAAACEGboBagAP8Mo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OQgQZwAAAAAAhBm8AWoAD/DKOIggcAgAEYIAejiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo5CBClgAAAAACEGb4BagAP8Mo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejkIEOQAAAAAAIQZoAFqAA/wyjiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OQgRIoAAAAAAhBmiAWoAD/DKOIghMAgAEYIAcfQ7Z1Qeu/hD2NkqbngwY/AKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejkIECkAAAAAAIQZpAFqAA/wyjiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo5CBBngAAAAACEGaYBagAP8Mo4iCBwCAARggB6OIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejkIEKYAAAAAAIQZqAFqAA/wyjiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OQgQ5IAAAAAAhBmqAWoAD/DKOIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo5CBEjAAAAAACEGawBagAP8Mo4iCEwCAARggBx9DtnVB67+EI6npcueDBlKAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OQgQKYAAAAAAhBmuAWoAD/DKOIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejkIEGgAAAAAAIQZsAFqAA/wyjiIIHAIABGCAHo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OQgQpoAAAAAAhBmyAWoAD/DKOIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo5CBDlAAAAAACEGbQBagAP8Mo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejkIESOAAAAAAIQZtgFqAA/wyjiIITAIABGCAHH0O2dVn0v4TUAuZk54MGZgCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo1gYgQKggAAAGBBliIIBmiYoAAh5ycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXgo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejkIEGiAAAAAAIQZogFaAA/wyjiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo5CBCnAAAAAACEGaQBWgAP8Mo4iCCwCAARggB6OIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejkIEOWAAAAAAIQZpgFaAA/wyjiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OQgRJAAAAAAAhBmoAWoAD/DKOIghMAgAEYIAcfQ7Z1Qeu/hJ/8CobngwZ5gKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejkIECqAAAAAAIQZqgFqAA/wyjiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OQgQaQAAAAAAhBmsAWoAD/DKOIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejkIEKeAAAAAAIQZrgFqAA/wyjiIILAIABGCAHo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OQgQ5gAAAAAAhBmwAWoAD/DKOIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo5CBEkgAAAAACEGbIBagAP8Mo4iCEwCAARggBx9DtnVB67+EMCEJD+eDBo0Ao4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OQgQKwAAAAAAhBm0AWoAD/DKOIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo5CBBpgAAAAACEGbYBagAP8Mo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OQgQqAAAAAAAhBm4AWoAD/DKOIggsAgAEYIAejiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo5CBDmgAAAAACEGboBagAP8Mo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejkIESUAAAAAAIQZvAFqAA/wyjiIITAIABGCAHH0O2dUHrv4RunJSi54MGoICjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo5CBArgAAAAACEGb4BagAP8Mo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejkIEGoAAAAAAIQZoAFqAA/wyjiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OQgQqIAAAAAAhBmiAWoAD/DKOIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejkIEOcAAAAAAIQZpAFqAA/wyjiIIPAIABGCAHo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OQgRJYAAAAAAhBmmAWoAD/DKOIghMAgAEYIAcfQ7Z1Qeu/hDdvCkvngwa0AKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejkIECwAAAAAAIQZqAFqAA/wyjiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OQgQaoAAAAAAhBmqAWoAD/DKOIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo5CBCpAAAAAACEGawBagAP8Mo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OQgQ54AAAAAAhBmuAWoAD/DKOIgg8AgAEYIAejiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo5CBEmAAAAAACEGbABagAP8Mo4iCEwCAARggBx9DtnVB67+EeapaAueDBseAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OQgQLIAAAAAAhBmyAWoAD/DKOIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo5CBBrAAAAAACEGbQBagAP8Mo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejkIEKmAAAAAAIQZtgFqAA/wyjiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo5CBDoAAAAAACEGbgBagAP8Mo4iCDwCAARggB6OIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejkIESaAAAAAAIQZugFqAA/wyjiIITAIABGCAHH0O2dUHrv4T7DWQV54MG2wCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo5CBAtAAAAAACEGbwBagAP8Mo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejkIEGuAAAAAAIQZvgFqAA/wyjiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OQgQqgAAAAAAhBmgAWoAD/DKOIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo5CBDogAAAAACEGaIBagAP8Mo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OQgRJwAAAAAAhBmkAWoAD/DKOIghMAgAEYIAcfQ7Z1Qeu/hMQTQqDngwbugKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejkIEC2AAAAAAIQZpgFqAA/wyjiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OQgQbAAAAAAAhBmoAWoAD/DKOIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo5CBCqgAAAAACEGaoBagAP8Mo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejkIEOkAAAAAAIQZrAFqAA/wyjiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo5CBEngAAAAACEGa4BagAP8Mo4iCEwCAARggBx9DtnVB67+E4uUnceeDBwIAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OQgQLgAAAAAAhBmwAWoAD/DKOIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo5CBBsgAAAAACEGbIBagAP8Mo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejkIEKsAAAAAAIQZtAFqAA/wyjiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OQgQ6YAAAAAAhBm2AWoAD/DKOIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejkIESgAAAAAAIQZuAFqAA/wyjiIITAIABGCAHH0O2dUHrv4QLw5vr54MHFYCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo5CBAugAAAAACEGboBagAP8Mo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejkIEG0AAAAAAIQZvAFqAA/wyjiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OQgQq4AAAAAAhBm+AWoAD/DKOIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo5CBDqAAAAAACEGaABagAP8Mo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAejkIESiAAAAAAIQZogFqAA/wwfQ7Z1Qeu/hAwr7J7ngwcpAKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejkIEC8AAAAAAIQZpAFqAA/wyjiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OQgQbYAAAAAAhBmmAWoAD/DKOIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo5CBCsAAAAAACEGagBagAP8Mo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejkIEOqAAAAAAIQZqgFqAA/wyjiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggB6OQgRKQAAAAAAhBmsAWoAD/DB9DtnVB67+EFOKYn+eDBzyAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OQgQL4AAAAAAhBmuAWoAD/DKOIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo5CBBuAAAAAACEGbABagAP8Mo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejkIEKyAAAAAAIQZsgFqAA/wyjiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OQgQ6wAAAAAAhBm0AWoAD/DKOIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHo5CBEpgAAAAACEGbYBagAP8MH0O2dVn0v4Q1Ff1i54MHUACjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo1gYgQMAgAAAGBBliIQGaJigACHnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJyddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddeAo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejkIEG6AAAAAAIQZogFaAA/wyjiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OQgQrQAAAAAAhBmkAVoAD/DKOIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo5CBDrgAAAAACEGaYBWgAP8Mo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAejkIESoAAAAAAIQZqAFqAA/wwfQ7Z1Qeu/hK6Gh5vngwdjgKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo5CBAwgAAAAACEGaoBagAP8Mo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OQgQbwAAAAAAhBmsAWoAD/DKOIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo5CBCtgAAAAACEGa4BagAP8Mo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejkIEOwAAAAAAIQZsAFqAA/wyjiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggB6OQgRKoAAAAAAhBmyAWoAD/DB9DtnVB67+EqryBV+eDB3cAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejkIEDEAAAAAAIQZtAFqAA/wyjiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo5CBBvgAAAAACEGbYBagAP8Mo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejkIEK4AAAAAAIQZuAFqAA/wyjiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OQgQ7IAAAAAAhBm6AWoAD/DKOIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHo5CBErAAAAAACEGbwBagAP8MH0O2dUHrv4SsumfX54MHioCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OQgQMYAAAAAAhBm+AWoAD/DKOIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejkIEHAAAAAAAIQZoAFqAA/wyjiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OQgQroAAAAAAhBmiAWoAD/DKOIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo5CBDtAAAAAACEGaQBagAP8Mo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAejkIESuAAAAAAIQZpgFqAA/wwfQ7Z1Qeu/hKKInOXngweeAKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo5CBAyAAAAAACEGagBagAP8Mo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejkIEHCAAAAAAIQZqgFqAA/wyjiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo5CBCvAAAAAACEGawBagAP8Mo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejkIEO2AAAAAAIQZrgFqAA/wyjiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggB6OQgRLAAAAAAAhBmwAWoAD/DB9DtnVB67+EAN65ReeDB7GAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejkIEDKAAAAAAIQZsgFqAA/wyjiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OQgQcQAAAAAAhBm0AWoAD/DKOIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejkIEK+AAAAAAIQZtgFqAA/wyjiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OQgQ7gAAAAAAhBm4AWoAD/DKOIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHo5CBEsgAAAAACEGboBagAP8MH0O2dUHrv4SUPbBO54MHxQCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OQgQMwAAAAAAhBm8AWoAD/DKOIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo5CBBxgAAAAACEGb4BagAP8Mo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OQgQsAAAAAAAhBmgAWoAD/DKOIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo5CBDugAAAAACEGaIBagAP8Mo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAejkIES0AAAAAAIQZpAFqAA/wwfQ7Z1Qeu/hJIcVO3ngwfYgKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo5CBAzgAAAAACEGaYBagAP8Mo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejkIEHIAAAAAAIQZqAFqAA/wyjiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OQgQsIAAAAAAhBmqAWoAD/DKOIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejkIEO8AAAAAAIQZrAFqAA/wyjiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggB6OQgRLYAAAAAAhBmuAWoAD/DB9DtnVB67+E33UUp+eDB+wAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejkIEDQAAAAAAIQZsAFqAA/wyjiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OQgQcoAAAAAAhBmyAWoAD/DKOIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo5CBCxAAAAAACEGbQBagAP8Mo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OQgQ74AAAAAAhBm2AWoAD/DKOIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHo5CBEuAAAAAACEGbgBagAP8MH0O2dUHrv4QbmhWJ54MH/4CjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OQgQNIAAAAAAhBm6AWoAD/DKOIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo5CBBzAAAAAACEGbwBagAP8Mo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejkIELGAAAAAAIQZvgFqAA/wyjiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo5CBDwAAAAAACEGaABagAP8Mo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAejkIES6AAAAAAIQZogFqAA/wwfQ7Z1Qeu/hP1+9nDngwgTAKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo5CBA1AAAAAACEGaQBagAP8Mo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejkIEHOAAAAAAIQZpgFqAA/wyjiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OQgQsgAAAAAAhBmoAWoAD/DKOIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo5CBDwgAAAAACEGaoBagAP8Mo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggB6OQgRLwAAAAAAhBmsAWoAD/DB9DtnVB67+EEA8EmeeDCCaAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejkIEDWAAAAAAIQZrgFqAA/wyjiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OQgQdAAAAAAAhBmwAWoAD/DKOIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo5CBCygAAAAACEGbIBagAP8Mo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejkIEPEAAAAAAIQZtAFqAA/wyjiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHo5CBEvgAAAAACEGbYBagAP8MH0O2dVn0v4Ql7yAq54MIOgCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6NYGIEDYIAAABgQZYiCAZomKAAIecnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJ1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111114KOIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo5CBB0gAAAAACEGaIBWgAP8Mo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejkIELMAAAAAAIQZpAFaAA/wyjiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OQgQ8YAAAAAAhBmmAVoAD/DKOIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAejkIETAAAAAAAIQZqAFqAA/wwfQ7Z1QfW/hFkWTt7ngwhNgKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo5CBA2gAAAAACEGaoBagAP8Mo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejkIEHUAAAAAAIQZrAFqAA/wyjiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OQgQs4AAAAAAhBmuAWoAD/DKOIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo5CBDyAAAAAACEGbABagAP8Mo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggB6OIghOAgAEYIAejkIETCAAAAAAIQZsgFqAA/wwfQ7Z1Qeu/hEbrw6nngwhhgKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejkIEC8AAAAAAIQZtAFqAA/wyjiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OQgQbYAAAAAAhBm2AWoAD/DKOIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo5CBCsAAAAAACEGbgBagAP8Mo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejkIEOqAAAAAAIQZugFqAA/wyjiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggB6OQgRKQAAAAAAhBm8AWoAD/DB9DtnVB67+ESxsCHueDCHUAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OQgQL4AAAAAAhBm+AWoAD/DKOIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo5CBBuAAAAAACEGaABagAP8Mo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejkIEKyAAAAAAIQZogFqAA/wyjiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OQgQ6wAAAAAAhBmkAWoAD/DKOIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHo5CBEpgAAAAACEGaYBagAP8MH0O2dUHrv4QmFB4854MIiICjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo5CBAwAAAAAACEGagBagAP8Mo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejkIEG6AAAAAAIQZqgFqAA/wyjiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OQgQrQAAAAAAhBmsAWoAD/DKOIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo5CBDrgAAAAACEGa4BagAP8Mo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAejkIESoAAAAAAIQZsAFqAA/wwfQ7Z1Qeu/hGBvh4PngwicAKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo5CBAwgAAAAACEGbIBagAP8Mo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OQgQbwAAAAAAhBm0AWoAD/DKOIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo5CBCtgAAAAACEGbYBagAP8Mo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejkIEOwAAAAAAIQZuAFqAA/wyjiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggB6OQgRKoAAAAAAhBm6AWoAD/DB9DtnVB67+EEKXi0eeDCK+Ao4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejkIEDEAAAAAAIQZvAFqAA/wyjiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo5CBBvgAAAAACEGb4BagAP8Mo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejkIEK4AAAAAAIQZoAFqAA/wyjiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OQgQ7IAAAAAAhBmiAWoAD/DKOIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHo5CBErAAAAAACEGaQBagAP8MH0O2dUHrv4RODmyu54MIwwCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OQgQMYAAAAAAhBmmAWoAD/DKOIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejkIEHAAAAAAAIQZqAFqAA/wyjiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OQgQroAAAAAAhBmqAWoAD/DKOIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo5CBDtAAAAAACEGawBagAP8Mo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAejkIESuAAAAAAIQZrgFqAA/wwfQ7Z1Qeu/hI5bj/nngwjWgKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo5CBAyAAAAAACEGbABagAP8Mo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejkIEHCAAAAAAIQZsgFqAA/wyjiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo5CBCvAAAAAACEGbQBagAP8Mo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejkIEO2AAAAAAIQZtgFqAA/wyjiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggB6OQgRLAAAAAAAhBm4AWoAD/DB9DtnVB67+ElYJd/ueDCOoAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejkIEDKAAAAAAIQZugFqAA/wyjiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OQgQcQAAAAAAhBm8AWoAD/DKOIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejkIEK+AAAAAAIQZvgFqAA/wyjiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OQgQ7gAAAAAAhBmgAWoAD/DKOIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHo5CBEsgAAAAACEGaIBagAP8MH0O2dUHrv4RRI/t854MI/YCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OQgQMwAAAAAAhBmkAWoAD/DKOIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo5CBBxgAAAAACEGaYBagAP8Mo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OQgQsAAAAAAAhBmoAWoAD/DKOIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo5CBDugAAAAACEGaoBagAP8Mo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAejkIES0AAAAAAIQZrAFqAA/wwfQ7Z1Qeu/hF9JunrngwkRAKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo5CBAzgAAAAACEGa4BagAP8Mo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejkIEHIAAAAAAIQZsAFqAA/wyjiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OQgQsIAAAAAAhBmyAWoAD/DKOIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejkIEO8AAAAAAIQZtAFqAA/wyjiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggB6OQgRLYAAAAAAhBm2AWoAD/DB9DtnVZ9L+E9t2gGOeDCSSAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejWBiBA0CAAAAYEGWIhAZomKAAIecnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJ1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111114CjiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OQgQcoAAAAAAhBmiAVoAD/DKOIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo5CBCxAAAAAACEGaQBWgAP8Mo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OQgQ74AAAAAAhBmmAVoAD/DKOIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHo5CBEuAAAAAACEGagBagAP8MH0O2dUHrv4QLmCX254MJOACjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OQgQNIAAAAAAhBmqAWoAD/DKOIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo5CBBzAAAAAACEGawBagAP8Mo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejkIELGAAAAAAIQZrgFqAA/wyjiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo5CBDwAAAAAACEGbABagAP8Mo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAejkIES6AAAAAAIQZsgFqAA/wwfQ7Z1Qeu/hA8zY4XngwlLgKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo5CBA1AAAAAACEGbQBagAP8Mo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejkIEHOAAAAAAIQZtgFqAA/wyjiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OQgQsgAAAAAAhBm4AWoAD/DKOIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo5CBDwgAAAAACEGboBagAP8Mo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggB6OQgRLwAAAAAAhBm8AWoAD/DB9DtnVB67+EiBxMYOeDCV8Ao4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejkIEDWAAAAAAIQZvgFqAA/wyjiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo4iCB4CAARggB6OQgQdAAAAAAAhBmgAWoAD/DKOIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejiIILgIABGCAHo5CBCygAAAAACEGaIBagAP8Mo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OIgg+AgAEYIAejkIEPEAAAAAAIQZpAFqAA/wyjiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHo5CBEvgAAAAACEGaYBagAP8MH0O2dUHrv4SwK+vf54MJcoCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OQgQNgAAAAAAhBmoAWoAD/DKOIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejiIIHgIABGCAHo5CBB0gAAAAACEGaoBagAP8Mo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OIgguAgAEYIAejkIELMAAAAAAIQZrAFqAA/wyjiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo4iCD4CAARggB6OQgQ8YAAAAAAhBmuAWoAD/DKOIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAejkIETAAAAAAAIQZsAFqAA/wwfQ7Z1QfW/hEuzCSvngwmGAKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo5CBA2gAAAAACEGbIBagAP8Mo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OIggeAgAEYIAejkIEHUAAAAAAIQZtAFqAA/wyjiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo4iCC4CAARggB6OQgQs4AAAAAAhBm2AWoAD/DKOIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejiIIPgIABGCAHo5CBDyAAAAAACEGbgBagAP8Mo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggB6OIghOAgAEYIAejkIETCAAAAAAIQZugFqAA/wwfQ7Z1Qeu/hBXBJZ/ngwmaAKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejkIEC8AAAAAAIQZvAFqAA/wyjiIIDgIABGCAHo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OQgQbYAAAAAAhBm+AWoAD/DKOIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo5CBCsAAAAAACEGaABagAP8Mo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejkIEOqAAAAAAIQZogFqAA/wyjiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggB6OQgRKQAAAAAAhBmkAWoAD/DB9DtnVB67+EQW12jOeDCa2Ao4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OQgQL4AAAAAAhBmmAWoAD/DKOIggOAgAEYIAejiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo5CBBuAAAAAACEGagBagAP8Mo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejkIEKyAAAAAAIQZqgFqAA/wyjiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OQgQ6wAAAAAAhBmsAWoAD/DKOIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHo5CBEpgAAAAACEGa4BagAP8MH0O2dUHrv4ST21cc54MJwQCjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo5CBAwAAAAAACEGbABagAP8Mo4iCA4CAARggB6OIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejkIEG6AAAAAAIQZsgFqAA/wyjiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OQgQrQAAAAAAhBm0AWoAD/DKOIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo5CBDrgAAAAACEGbYBagAP8Mo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAejkIESoAAAAAAIQZuAFqAA/wwfQ7Z1Qeu/hHbDQg3ngwnUgKOIggAAgAEYIAejiIIAgIABGCAHo4iCAQCAARggB6OIggGAgAEYIAejiIICAIABGCAHo4iCAoCAARggB6OIggMAgAEYIAejiIIDgIABGCAHo5CBAwgAAAAACEGboBagAP8Mo4iCBACAARggB6OIggSAgAEYIAejiIIFAIABGCAHo4iCBYCAARggB6OIggYAgAEYIAejiIIGgIABGCAHo4iCBwCAARggB6OQgQbwAAAAAAhBm8AWoAD/DKOIggeAgAEYIAejiIIIAIABGCAHo4iCCICAARggB6OIggkAgAEYIAejiIIJgIABGCAHo4iCCgCAARggB6OIggqAgAEYIAejiIILAIABGCAHo5CBCtgAAAAACEGb4BagAP8Mo4iCC4CAARggB6OIggwAgAEYIAejiIIMgIABGCAHo4iCDQCAARggB6OIgg2AgAEYIAejiIIOAIABGCAHo4iCDoCAARggB6OIgg8AgAEYIAejkIEOwAAAAAAIQZoAFqAA/wyjiIIPgIABGCAHo4iCEACAARggB6OIghCAgAEYIAejiIIRAIABGCAHo4iCEYCAARggB6OIghIAgAEYIAejiIISgIABGCAHo4iCEwCAARggB6OQgRKoAAAAAAhBmiAWoAD/DB9DtnVB67+EYkXSzueDCegAo4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAejkIEDEAAAAAAIQZpAFqAA/wyjiIIEAIABGCAHo4iCBICAARggB6OIggUAgAEYIAejiIIFgIABGCAHo4iCBgCAARggB6OIggaAgAEYIAejiIIHAIABGCAHo5CBBvgAAAAACEGaYBagAP8Mo4iCB4CAARggB6OIgggAgAEYIAejiIIIgIABGCAHo4iCCQCAARggB6OIggmAgAEYIAejiIIKAIABGCAHo4iCCoCAARggB6OIggsAgAEYIAejkIEK4AAAAAAIQZqAFqAA/wyjiIILgIABGCAHo4iCDACAARggB6OIggyAgAEYIAejiIINAIABGCAHo4iCDYCAARggB6OIgg4AgAEYIAejiIIOgIABGCAHo4iCDwCAARggB6OQgQ7IAAAAAAhBmqAWoAD/DKOIgg+AgAEYIAejiIIQAIABGCAHo4iCEICAARggB6OIghEAgAEYIAejiIIRgIABGCAHo4iCEgCAARggB6OIghKAgAEYIAejiIITAIABGCAHo5CBErAAAAAACEGawBagAP8MH0O2dUHrv4QIOm1r54MJ+4CjiIIAAIABGCAHo4iCAICAARggB6OIggEAgAEYIAejiIIBgIABGCAHo4iCAgCAARggB6OIggKAgAEYIAejiIIDAIABGCAHo4iCA4CAARggB6OQgQMYAAAAAAhBmuAWoAD/DKOIggQAgAEYIAejiIIEgIABGCAHo4iCBQCAARggB6OIggWAgAEYIAejiIIGAIABGCAHo4iCBoCAARggB6OIggcAgAEYIAejkIEHAAAAAAAIQZsAFqAA/wyjiIIHgIABGCAHo4iCCACAARggB6OIggiAgAEYIAejiIIJAIABGCAHo4iCCYCAARggB6OIggoAgAEYIAejiIIKgIABGCAHo4iCCwCAARggB6OQgQroAAAAAAhBmyAWoAD/DKOIgguAgAEYIAejiIIMAIABGCAHo4iCDICAARggB6OIgg0AgAEYIAejiIINgIABGCAHo4iCDgCAARggB6OIgg6AgAEYIAejiIIPAIABGCAHo5CBDtAAAAAACEGbQBagAP8Mo4iCD4CAARggB6OIghAAgAEYIAejiIIQgIABGCAHo4iCEQCAARggB6OIghGAgAEYIAejiIISAIABGCAHo4iCEoCAARggB6OIghMAgAEYIAejkIESuAAAAAAIQZtgFqAA/wwfQ7Z127+EpLweZueDCg8Ao4iCAACAARggB6OIggCAgAEYIAejiIIBAIABGCAHo4iCAYCAARggB6OIggIAgAEYIAejiIICgIABGCAHo4iCAwCAARggB6OIggOAgAEYIAccU7trQNm/hCAeYEe7j7OBALeK94EB8YICXvCBE7uQs4LqYLeK94EB8YIz+vCBHruRs4MB1MC3iveBAfGCY03wgSm7kbODAr8gt4r3gQHxgpKi8IEzu5GzgwOpgLeK94EB8YLB9/CBM7uRs4MEk+C3iveBAfGC8UzwgT27krODBX5At4v3gQHxgwEgofCBR7uSs4MGaKC3i/eBAfGDAU/28IFRu5KzgwdTALeL94EB8YMBf0vwgVG7krODCD1gt4v3gQHxgwGuoPCBW7uSs4MJJ8C3i/eBAfGDAd3/8IFb"
)

def _detect_resolution(*names: str) -> str:
    """Return a resolution tier ('2160p'..'480p') parsed from any of the given
    names (release/file/folder), falling back to _DEFAULT_RES."""
    for n in names:
        if not n:
            continue
        for tier, pat in _RES_PATTERNS:
            if pat.search(n):
                return tier
    return _DEFAULT_RES

def _stub_bytes_for(*names: str) -> bytes:
    """Pick the stub matching the detected resolution and return its bytes.
    Falls back to the 1080p stub file, then to the embedded 1080p stub."""
    tier = _detect_resolution(*names)
    for candidate in (tier, _DEFAULT_RES):
        path = os.path.join(_STUB_DIR, _RES_STUBS.get(candidate, ""))
        try:
            with open(path, "rb") as fh:
                return fh.read()
        except OSError:
            continue
    return _FALLBACK_1080P

import logging as _qbt_log
_log = _qbt_log.getLogger(__name__)

def _dl_dir(category: str) -> str:
    """
    Return the download subfolder for a given Arr category.
    Uses whatever category Radarr/Sonarr set (e.g. "radarr", "tv-sonarr").
    Created on demand — no hardcoded subdirs, downloads root stays empty.
    """
    cat = (category or "default").strip().lower() or "default"
    path = os.path.join(DOWNLOADS_ROOT, cat)
    os.makedirs(path, exist_ok=True)
    try:
        os.chmod(path, 0o777)
    except OSError:
        pass
    return path

def _fake_folder(category: str, folder_name: str) -> str:
    return os.path.join(_dl_dir(category), folder_name)

def _pick_fake_filename(name: str, files: list) -> str:
    """
    Choose the best filename for the fake file.
    Prefer the largest video file's name from the real file list so Radarr
    parses it correctly (resolution, codec, group tags all come from the name).
    Always ensures a resolution token is present — injects WEBRip-1080p if not,
    so Radarr/Sonarr never fall back to SDTV.
    """
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts",
                  ".wmv", ".flv", ".webm", ".m2ts", ".mpg", ".mpeg"}
    best, best_size = None, 0
    for f in files:
        raw   = f.get("name") or f.get("path") or ""
        fname = os.path.basename(raw)
        _, ext = os.path.splitext(fname)
        fsize = int(f.get("size", 0))
        if ext.lower() in video_exts and fsize > best_size:
            best, best_size = fname, fsize

    if best:
        # Use the real filename but ensure it has a resolution token.
        # If not, inject WEBRip-1080p before the extension.
        has_res = any(p.search(best) for _, p in _RES_PATTERNS)
        if not has_res:
            stem, ext = os.path.splitext(best)
            best = f"{stem}.WEBRip-1080p{ext}"
        return best

    # Fallback: sanitise the torrent name and inject WEBRip-1080p if needed.
    safe = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(". ")[:160]
    has_res = any(p.search(safe) for _, p in _RES_PATTERNS)
    if not has_res:
        safe = f"{safe}.WEBRip-1080p"
    return f"{safe}.mkv"

def _write_one_stub(folder: str, filename: str, folder_name: str) -> str:
    """Write a single stub .mkv file and optional .nfo into folder.
    Returns the path written."""
    fpath = os.path.join(folder, filename)
    try:
        data = _stub_bytes_for(filename, folder_name)
        with open(fpath, "wb") as fh:
            fh.write(data)
        try:
            os.chmod(fpath, 0o666)
        except OSError:
            pass
        _log.info(
            f"Fake file created: {fpath} "
            f"({len(data)} bytes, {_detect_resolution(filename, folder_name)}, 660s runtime)"
        )
        try:
            import fuse_mount as _fm
            _nfo_enabled = not getattr(_fm, "_VIDEO_ONLY", False)
        except Exception:
            _nfo_enabled = True
        if _nfo_enabled:
            write_nfo(fpath)
    except OSError as e:
        _log.warning(f"Could not create fake file {fpath}: {e}")
    return fpath


def _make_fake_file(category: str, folder_name: str, filename: str,
                    files: list | None = None) -> str:
    """
    Create fake MKV stub(s) in the download folder for Radarr/Sonarr to import.

    For individual episodes: one stub named after the episode file.
    For season packs: one stub per episode, named SxxExx so Sonarr can map
    each one to the correct episode slot in its library.

    Stubs use resolution-matched black video (MediaInfo outranks name tags)
    with a 660s runtime to clear Sonarr's 600s sample-detection threshold.
    """
    folder = _fake_folder(category, folder_name)
    os.makedirs(folder, exist_ok=True)
    try:
        os.chmod(folder, 0o777)
    except OSError:
        pass

    # ── Season-pack path: create one stub per episode ────────────────────────
    # A season pack has real episode files inside it (multiple videos), or its
    # name matches SNN without an episode number. In either case we need one
    # stub per episode so Sonarr can map each file to the right episode slot.
    # Without this, Sonarr imports the pack as one unmatched file and every
    # episode stays orange in the UI ("Episode file already imported" forever).
    _vid_ext = (".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts",
                ".wmv", ".flv", ".webm", ".m2ts", ".mpg", ".mpeg")
    video_files = [
        f for f in (files or [])
        if os.path.splitext((f.get("name") or f.get("path") or "").lower())[1] in _vid_ext
    ]
    _looks_pack = bool(
        re.search(r"\bS\d{1,2}\b(?!E)|\bseasons?\b|\bcomplete\b|\bseries\b", folder_name, re.IGNORECASE)
        and not re.search(r"S\d{1,2}E\d{1,3}", folder_name, re.IGNORECASE)
    )

    if len(video_files) > 1 or (_looks_pack and video_files):
        # Use real filenames from AllDebrid — they already carry SxxExx tags.
        written = []
        for vf in video_files:
            ep_name = os.path.basename(vf.get("name") or vf.get("path") or "")
            if not ep_name:
                continue
            # Ensure resolution token is present
            if not any(p.search(ep_name) for _, p in _RES_PATTERNS):
                stem, ext = os.path.splitext(ep_name)
                ep_name = f"{stem}.WEBRip-1080p{ext}"
            ep_path = os.path.join(folder, ep_name)
            if os.path.exists(ep_path):
                try:
                    os.utime(folder, None)
                    os.chmod(ep_path, 0o666)
                except OSError:
                    pass
                written.append(ep_path)
                continue
            written.append(_write_one_stub(folder, ep_name, folder_name))
        if written:
            _log.info(f"Season pack: wrote {len(written)} episode stub(s) in {folder}")
            return written[0]

    if _looks_pack and not video_files:
        # Pack with no real file list yet — fall back to single stub for now.
        # Sonarr will re-grab once files are available and we'll write per-episode stubs.
        _log.debug(f"[{folder_name[:40]}] pack but no file list yet — writing single stub")

    # ── Single-file path (individual episode or movie) ───────────────────────
    fpath = os.path.join(folder, filename)
    if os.path.exists(fpath):
        has_res = any(p.search(filename) for _, p in _RES_PATTERNS)
        if has_res:
            os.utime(folder, None)
            try:
                os.chmod(folder, 0o777)
                os.chmod(fpath, 0o666)
            except OSError:
                pass
            return fpath
        else:
            try:
                os.remove(fpath)
            except OSError:
                pass

    return _write_one_stub(folder, filename, folder_name)

def _remove_fake_folder(category: str, folder_name: str):
    """Remove the fake download folder after Radarr/Sonarr have imported."""
    import shutil
    folder = _fake_folder(category, folder_name)
    if os.path.isdir(folder):
        try:
            shutil.rmtree(folder)
            _log.info(f"Fake folder removed: {folder}")
        except OSError as e:
            _log.warning(f"Could not remove fake folder {folder}: {e}")

# Matches S01, S01E01, S01E01-E03, Season 1, etc.
from name_match import is_series as _is_series
def _category_subdir(name: str, category: str = "") -> str:
    """Return 'series' or 'movies' based on torrent name patterns."""
    if _is_series(name):
        return "series"
    # Fall back to category keyword if name gives no signal
    cat = (category or "").lower()
    if any(k in cat for k in ("sonarr", "tv", "series", "show")):
        return "series"
    return "movies"

# Lazy import so fuse_mount.py doesn't have to be importable at module load
def _safe_name(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name)
    return name.strip('. ')[:200] or "unknown"


def _torrent_to_qbt(t: dict) -> dict:
    hash_  = t["hash"]
    name   = t.get("name") or hash_
    state  = t.get("state", "queued")

    # Pull file list for ready transfers to get correct filename/size.
    # We also use stored size from DB as fallback so Radarr never sees 0 bytes.
    is_ready = state in ("cached", "complete")
    files    = []
    if is_ready and _tm is not None:
        try:
            files = _tm.get_files(hash_) or []
        except Exception:
            files = []

    file_size    = sum(int(f.get("size", 0)) for f in files)
    stored_size  = int(t.get("size", 0) or 0)
    # Never report 0 — Radarr skips 0-byte torrents. Fall back to 1GB if needed.
    size         = file_size or stored_size or (1024 * 1024 * 1024)
    completed    = size if is_ready else 0
    progress     = 1.0 if is_ready else 0.0

    fuse_dir      = _safe_name(name)
    category      = t.get("category") or ""
    fake_filename = _pick_fake_filename(name, files)

    # Compute paths without touching the filesystem — fake file creation is
    # handled explicitly by torrents/info and torrents/add, not here as a
    # side effect. This prevents cleared download folders from being silently
    # recreated on every poll cycle.
    #
    # Normalise the category the same way _dl_dir() does (strip + lower) so the
    # reported path matches where the auto-importer actually writes the stubs.
    _cat         = (category or "default").strip().lower() or "default"
    save_path    = os.path.join(DOWNLOADS_ROOT, _cat)
    folder_path  = os.path.join(save_path, fuse_dir)

    # qBittorrent reports a SINGLE-file torrent's content_path as the file, but
    # a MULTI-file torrent's content_path as the ROOT FOLDER. Season / multi-
    # season / complete packs are written as one stub per episode inside the
    # folder, so Sonarr must scan the folder — pointing it at one (real-torrent)
    # filename we never wrote causes "path does not exist". Detect a pack by
    # multiple video files in the real list, or by a season/complete marker in
    # the name.
    _vid_ext  = (".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts", ".wmv",
                 ".flv", ".webm", ".m2ts", ".mpg", ".mpeg")
    _n_videos = sum(1 for f in files
                    if os.path.splitext((f.get("name") or f.get("path") or "").lower())[1] in _vid_ext)
    _looks_pack = bool(re.search(r'\bS\d{1,2}\b(?!E)|\bseasons?\b|\bcomplete\b|\bseries\b',
                                 name, re.IGNORECASE)
                       and not re.search(r'S\d{1,2}E\d{1,3}', name, re.IGNORECASE))
    if _n_videos > 1 or _looks_pack:
        content_path = folder_path
    else:
        content_path = os.path.join(folder_path, fake_filename)

    return {
        "hash":           hash_,
        "name":           name,
        "state":          QBT_STATE.get(state, "unknown"),
        "size":           size,
        "completed":      completed,
        "progress":       progress,
        "save_path":      save_path,
        "content_path":   content_path,
        "category":       t.get("category") or "",
        "tags":           "",
        "added_on":       int(t.get("added_at", time.time())),
        "completion_on":  int(t.get("updated_at", time.time())) if state in ("complete", "cached") else -1,
        "dl_speed":       0,
        "up_speed":       0,
        "eta":            8640000 if state == "downloading" else 0,
        "num_seeds":      0,
        "num_leechs":     0,
        "ratio":          0.0,
        "tracker":        "",
        "seq_dl":         False,
        "f_l_piece_prio": False,
        "force_start":    False,
        "super_seeding":  False,
        "auto_tmm":       False,
        "availability":   1.0 if state in ("complete", "cached") else 0.0,
    }


def _extract_hash(src: str) -> str | None:
    """Extract info hash from magnet URI or raw hash string."""
    if src.startswith("magnet:"):
        m = re.search(r'urn:btih:([0-9a-fA-F]{40})', src, re.IGNORECASE)
        if m:
            return m.group(1).lower()
        # base32 btih
        m = re.search(r'urn:btih:([A-Z2-7]{32})', src, re.IGNORECASE)
        if m:
            import base64
            try:
                b = base64.b32decode(m.group(1).upper())
                return b.hex()
            except Exception:
                pass
    if re.fullmatch(r'[0-9a-fA-F]{40}', src):
        return src.lower()
    return None


def _extract_name(src: str) -> str:
    """Extract torrent name from the dn= parameter of a magnet URI."""
    m = re.search(r'[?&]dn=([^&]+)', src)
    if m:
        return urllib.parse.unquote_plus(m.group(1))
    return ""


# ── Routes ────────────────────────────────────────────────────────────────────

@qbt.route("/auth/login", methods=["GET", "POST"])
def login():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/auth/logout", methods=["POST"])
def logout():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/app/version")
def app_version():
    return Response("v4.6.0", mimetype="text/plain")

@qbt.route("/app/webapiVersion")
def webapi_version():
    return Response("2.8.3", mimetype="text/plain")

@qbt.route("/app/preferences")
def preferences():
    return jsonify({
        "save_path":                  DOWNLOADS_ROOT,  # root; category subdirs created on demand
        "temp_path":                  DOWNLOADS_ROOT,
        "temp_path_enabled":          False,
        "autorun_enabled":            False,
        "queueing_enabled":           False,
        "max_active_downloads":       5,
        "max_active_torrents":        5,
        "max_active_uploads":         5,
        "incomplete_files_ext":       False,
        "add_to_top_of_queue":        False,
    })

@qbt.route("/torrents/info")
def torrents_info():
    if _tm is None:
        return jsonify([])
    filter_   = request.args.get("filter", "all")
    hashes    = request.args.get("hashes", "")
    category  = request.args.get("category", "")
    hash_set  = set(h.lower() for h in hashes.split("|") if h) if hashes else None

    all_t  = _tm.all_transfers()
    result = []
    for t in all_t:
        # Only expose cached/complete torrents
        if t.get("state") not in ("cached", "complete"):
            continue
        # Skip torrents that have already been imported — Radarr called
        # torrents/delete on them, meaning the import completed successfully.
        # Without this gate, the auto-recreate below would re-expose them and
        # Radarr would import the same movie twice.
        if t.get("imported"):
            continue
        if hash_set and t["hash"] not in hash_set:
            continue
        if category and t.get("category", "") != category:
            continue
        # Gate on fake folder having files — if the folder exists but is empty,
        # Radarr already moved the file out (import succeeded) but hasn't called
        # torrents/delete yet, or the delete failed. Either way treat it as done.
        t_category = t.get("category") or ""
        t_name     = t.get("name") or t["hash"]
        fake_dir   = _fake_folder(t_category, _safe_name(t_name))
        folder_has_files = (os.path.isdir(fake_dir) and
                            any(True for _ in os.scandir(fake_dir)))
        if not folder_has_files:
            if os.path.isdir(fake_dir):
                # Empty folder — file was moved out, clean up and mark imported.
                _remove_fake_folder(t_category, _safe_name(t_name))
                _tm._set(t["hash"], imported=1)
                _log.info(f"[torrents/info] empty folder cleaned, marked imported: {t['hash'][:8]}")
                continue
            # Folder missing entirely — skip. Fake files are created explicitly
            # by torrents/add (on grab) and reconcile/auto-import commands.
            # Auto-recreating here causes cleared folders to immediately refill
            # on every poll cycle for both Radarr and Sonarr.
            continue
        result.append(_torrent_to_qbt(t))

    return jsonify(result)


def _arr_title_exists(torrent_name: str, category: str) -> bool:
    """
    Check whether a movie or series with a matching title already exists in
    the configured Sonarr/Radarr instance for this category.

    Returns True  -> title found -> allow import.
    Returns False -> title NOT found -> block import.
    Also returns True when no instances are configured (fail-open so the
    system keeps working without Arr setup).
    """
    import re as _re2
    import logging as _log_mod
    _log2 = _log_mod.getLogger(__name__)

    try:
        import sys as _sys2
        _app2 = _sys2.modules.get("app") or _sys2.modules.get("__main__")
        _cfg_fn = getattr(_app2, "_load_config", None)
        if not _cfg_fn:
            return True  # no config access -> fail-open
        cfg = _cfg_fn()
        instances = cfg.get("sync", {}).get("instances", [])
        if not instances:
            return True  # no instances configured -> fail-open
    except Exception:
        return True

    # Determine Arr type from category string
    cat_lower = (category or "").lower()
    is_tv = any(k in cat_lower for k in ("sonarr", "tv", "series", "show"))
    arr_type = "sonarr" if is_tv else "radarr"

    # Find matching instances
    matching = [i for i in instances if i.get("type") == arr_type or i.get("type") == "any"]
    if not matching:
        return True  # No instance of this type configured -> fail-open

    def _norm(s: str) -> str:
        """Normalise a title for fuzzy comparison."""
        # Import site-prefix stripper from name_match (same logic everywhere)
        try:
            import sys as _sys2
            _nm = _sys2.modules.get("name_match")
            if _nm is None:
                import importlib; _nm = importlib.import_module("name_match")
            s = _nm._strip_site_prefix(s or "")
        except Exception:
            pass
        # Replace dots/underscores with spaces FIRST so season/episode
        # patterns like "Season.1" are recognised correctly
        s = s.replace('.', ' ').replace('_', ' ').lower()
        s = _re2.sub(r'\bs\d{1,2}(?:e\d{1,3})?\b.*', '', s)
        s = _re2.sub(r'\bseason\s*\d+\b.*', '', s)
        s = _re2.sub(r'\b(?:19|20)\d{2}\b.*', '', s)
        s = _re2.sub(
            r'\b(?:2160p?|1080p?|720p?|480p?|4k|uhd|hdr|bluray|web-?dl|webrip|hdtv|x264|x265|hevc|remux)\b.*',
            '', s, flags=_re2.IGNORECASE,
        )
        s = _re2.sub(r'[^a-z0-9\s]', '', s)
        return _re2.sub(r'\s+', ' ', s).strip()

    norm_torrent = _norm(torrent_name)
    if not norm_torrent:
        return True  # Can't normalise -> fail-open

    import requests as _req2
    for inst in matching:
        url = (inst.get("url") or "").rstrip("/")
        key = inst.get("key") or inst.get("api_key") or ""
        if not url or not key:
            continue
        endpoint = "series" if arr_type == "sonarr" else "movie"
        try:
            resp = _req2.get(
                f"{url}/api/v3/{endpoint}",
                headers={"X-Api-Key": key},
                timeout=8,
            )
            if resp.status_code != 200:
                _log2.warning(f"[arr_check] {url} returned {resp.status_code} — skipping instance")
                continue
            items = resp.json()
            for item in (items if isinstance(items, list) else []):
                candidates = [item.get("title") or "", item.get("sortTitle") or ""]
                candidates += [t.get("title", "") for t in item.get("alternateTitles", [])]
                for candidate in candidates:
                    if candidate and _norm(candidate) == norm_torrent:
                        _log2.info(
                            f"[arr_check] '{torrent_name}' matched '{candidate}' in {arr_type}"
                        )
                        return True
        except Exception as exc:
            _log2.warning(f"[arr_check] error querying {url}: {exc}")
            # Network error -> fail-open for this instance only
            return True

    _log2.info(
        f"[arr_check] '{torrent_name}' not found in any {arr_type} instance — blocking grab"
    )
    return False


@qbt.route("/torrents/add", methods=["POST"])
def torrents_add():
    import logging
    import threading as _threading
    _log = logging.getLogger(__name__)

    if _tm is None:
        return Response("fails", mimetype="text/plain")

    # Log everything Sonarr/Radarr sends so we can see what fields are available
    _log.info(f"[torrents/add] form fields: { {k: v for k, v in request.form.items()} }")
    _log.info(f"[torrents/add] files: { [f.filename for f in request.files.getlist('torrents')] }")

    # Accept magnet URLs or torrent files
    magnets = request.form.getlist("urls") or []
    raw     = request.form.get("urls", "")
    if raw and not magnets:
        magnets = [u.strip() for u in raw.splitlines() if u.strip()]

    # Sonarr/Radarr sends the release title in 'rename', fall back to
    # extracting from the magnet dn= or torrent metadata, never use raw hash
    rename   = (request.form.get("rename", "")
                or request.form.get("name", "")).strip()
    category = request.form.get("category", "").strip()

    _log.info(f"[torrents/add] rename='{rename}' category='{category}' magnets={len(magnets)}")

    # Collect all hashes + names from magnets
    torrents = []
    for src in magnets:
        hash_ = _extract_hash(src)
        if not hash_:
            continue
        torrent_name = rename or _extract_name(src) or hash_
        _log.info(f"[torrents/add] magnet hash={hash_[:8]} name='{torrent_name}'")
        torrents.append((hash_, torrent_name))

    # Also handle uploaded .torrent files
    for f in request.files.getlist("torrents"):
        data  = f.read()
        hash_ = _hash_from_torrent(data)
        if hash_:
            meta_name    = _name_from_torrent(data)
            torrent_name = rename or meta_name or os.path.splitext(f.filename)[0] or hash_
            _log.info(f"[torrents/add] torrent file hash={hash_[:8]} filename='{f.filename}' meta_name='{meta_name}' final='{torrent_name}'")
            torrents.append((hash_, torrent_name))

    if not torrents:
        return Response("fails", mimetype="text/plain")

    # ── Arr existence gate ─────────────────────────────────────────────────────
    # Only allow the grab if the movie/series already exists in the configured
    # Sonarr or Radarr instance. This prevents Sonarr/Radarr from adding new
    # library entries for content the user didn't explicitly want tracked.
    # We use the first torrent name as the title to check (all names in a single
    # grab are the same release, so checking the first is sufficient).
    _grab_name = torrents[0][1] if torrents else ""
    if _grab_name and not _arr_title_exists(_grab_name, category):
        _log.info(
            f"[torrents/add] BLOCKED — '{_grab_name}' not in Sonarr/Radarr library"
        )
        # Return "Ok." so Sonarr/Radarr don't flag the client as broken, but
        # don't create a fake file, so they never see the download complete and
        # never attempt an import.
        return Response("Ok.", mimetype="text/plain")
    # ──────────────────────────────────────────────────────────────────────────

    # Check AllDebrid cache for all hashes in one API call — cached torrents
    # are set to state="cached" immediately so the very first /torrents/info
    # poll from Sonarr/Radarr already sees them as complete (state="uploading").
    # Uncached torrents fall through to background _process() which creates a
    # transfer and polls until done.
    cache_input = [{"info_hash": h} for h, _ in torrents]
    try:
        # Use app-level cache check (upload→read ready→delete, no permanent adds)
        import sys as _sys
        _app = _sys.modules.get("app") or _sys.modules.get("__main__")
        _check = getattr(_app, "check_cache_ad", None)
        _key_fn = getattr(_app, "get_ad_api_key", None)
        if _check and _key_fn:
            cached_map = _check(_key_fn(), cache_input)
        elif hasattr(_tm, "_cache_fn"):
            cached_map = _tm._cache_fn(cache_input)
        else:
            cached_map = {}
    except Exception:
        cached_map = {}

    for hash_, name in torrents:
        # Skip hashes the user explicitly deleted — don't let Sonarr/Radarr
        # re-import something the user removed from the library.
        if _tm.is_user_deleted(hash_):
            _log.info(f"[{hash_[:8]}] qbt add: skipping user-deleted hash")
            continue

        existing = _tm.get_transfer(hash_)

        if existing and existing["state"] in ("cached", "downloading", "complete"):
            # Update name and category if they changed
            stored_name = existing.get("name", "")
            if (not stored_name or stored_name == hash_) and name and name != hash_:
                _tm._set(hash_, name=name)
            if category and existing.get("category") != category:
                _tm._set(hash_, category=category)
            # Re-create fake file in case category changed or file was deleted
            if existing["state"] in ("cached", "complete"):
                try:
                    real_files = _tm.get_files(hash_) or []
                except Exception:
                    real_files = []
                fake_fn = _pick_fake_filename(existing.get("name") or name, real_files)
                _make_fake_file(category, _safe_name(existing.get("name") or name), fake_fn, real_files)
            continue

        # Transfer missing or in error/queued state — check Premiumize cache.
        # If already confirmed cached above skip the API round-trip.
        is_cached = cached_map.get(hash_, False)

        # If the DB says it was cached/complete before but cache_map missed it
        # (e.g. API error), trust the DB rather than re-queuing.
        if not is_cached and existing and existing["state"] in ("cached", "complete"):
            is_cached = True

        if is_cached:
            _log.info(f"[{hash_[:8]}] qbt add: cached on AllDebrid — marking ready")
            _tm._set(hash_, name=name, state="cached", category=category, added_at=time.time())
            # _on_ready does: get_files → fake_file → unlock_cdn → update FUSE cache → Plex notify.
            # We need the fake file on disk before Radarr's first /torrents/info poll (~5s away).
            # Run synchronously so the stub exists when we return "Ok.".
            try:
                _tm._on_ready(hash_)
            except Exception as _e:
                _log.warning(f"[{hash_[:8]}] _on_ready error: {_e}")
        else:
            _log.info(f"[{hash_[:8]}] qbt add: not cached — queuing for download via AllDebrid")
            _tm.add(hash_, name)
            if category:
                _tm._set(hash_, category=category)

    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/delete", methods=["POST"])
def torrents_delete():
    if _tm is None:
        return Response("Ok.", mimetype="text/plain")
    # Radarr/Sonarr may send hashes pipe-separated or individually
    raw_hashes = request.form.get("hashes", "") or request.form.get("hash", "")
    _log.info(f"[torrents/delete] raw hashes: {raw_hashes!r}")
    for h in raw_hashes.split("|"):
        h = h.strip().lower()
        if not h:
            continue
        # Remove the fake download folder — do NOT delete the transfer from
        # the DB. The FUSE mount must keep serving the file after Radarr/Sonarr
        # import it. Deleting from DB would unmount the file and break playback.
        # Mark imported=1 so torrents/info never shows this torrent again,
        # preventing duplicate imports on the next reconcile or poll cycle.
        t = _tm.get_transfer(h)
        if t:
            name     = t.get("name") or h
            category = t.get("category") or ""
            folder   = _fake_folder(category, _safe_name(name))
            _log.info(f"[torrents/delete] removing fake folder: {folder}")
            _remove_fake_folder(category, _safe_name(name))
            _tm._set(h, imported=1)
            _log.info(f"[torrents/delete] marked imported: {h[:8]}")
        else:
            _log.warning(f"[torrents/delete] hash {h[:8]} not found in DB — scanning downloads dir")
            # Fallback: scan all category dirs for any folder whose name matches
            import shutil
            if os.path.isdir(DOWNLOADS_ROOT):
                for cat_dir in os.scandir(DOWNLOADS_ROOT):
                    if not cat_dir.is_dir():
                        continue
                    for entry in os.scandir(cat_dir.path):
                        if entry.is_dir() and h[:8] in entry.name.lower():
                            shutil.rmtree(entry.path, ignore_errors=True)
                            _log.info(f"[torrents/delete] fallback removed: {entry.path}")
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/pause", methods=["POST"])
def torrents_pause():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/resume", methods=["POST"])
def torrents_resume():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/files")
def torrents_files():
    if _tm is None:
        return jsonify([])
    hash_ = request.args.get("hash", "").lower()
    files = _tm.get_files(hash_)
    result = []
    for i, f in enumerate(files):
        # FIX: use basename so paths with slashes don't confuse Sonarr/Radarr
        name = os.path.basename(f.get("name", "") or f.get("path", ""))
        result.append({
            "index":        i,
            "name":         name,
            "size":         int(f.get("size", 0)),
            "progress":     1.0,
            "priority":     1,
            "is_seed":      True,
            "piece_range":  [0, 0],
            "availability": 1.0,
        })
    return jsonify(result)

@qbt.route("/torrents/properties")
def torrents_properties():
    if _tm is None:
        return jsonify({})
    hash_ = request.args.get("hash", "").lower()
    t     = _tm.get_transfer(hash_)
    if not t:
        return jsonify({}), 404
    qbt_t = _torrent_to_qbt(t)
    return jsonify({
        "save_path":         qbt_t["save_path"],
        "creation_date":     int(t.get("added_at", time.time())),
        "piece_size":        262144,
        "comment":           "",
        "total_wasted":      0,
        "total_uploaded":    0,
        "total_downloaded":  qbt_t["completed"],
        "up_limit":          -1,
        "dl_limit":          -1,
        "time_elapsed":      0,
        "seeding_time":      0,
        "nb_connections":    0,
        "share_ratio":       0.0,
        "addition_date":     int(t.get("added_at", time.time())),
        "completion_date":   qbt_t["completion_on"],
        "created_by":        "alldebrid-web",
        "dl_speed_avg":      0,
        "up_speed_avg":      0,
        "eta":               qbt_t["eta"],
        "last_seen":         int(time.time()),
        "peers":             0,
        "peers_total":       0,
        "pieces_have":       1,
        "pieces_num":        1,
        "reannounce":        0,
        "seeds":             0,
        "seeds_total":       0,
        "total_size":        qbt_t["size"],
    })

@qbt.route("/torrents/setCategory", methods=["POST"])
def set_category():
    hashes   = request.form.get("hashes", "")
    category = request.form.get("category", "")
    for h in hashes.split("|"):
        h = h.strip().lower()
        if h and _tm:
            _tm._set(h, category=category)
    return Response("Ok.", mimetype="text/plain")

# ── Categories ────────────────────────────────────────────────────────────────
# Sonarr calls GET /torrents/categories on connection test and expects a 200
# with a JSON object of {name: {name, savePath}}.  It also POSTs createCategory
# and editCategory when setting up the download client category.

# Categories are created on demand when Radarr/Sonarr connect.
# savePath is set dynamically to the category-named subfolder.
_CATEGORIES: dict = {}

@qbt.route("/torrents/categories")
def get_categories():
    return jsonify(_CATEGORIES)

@qbt.route("/torrents/createCategory", methods=["POST"])
def create_category():
    name      = request.form.get("category", "").strip()
    save_path = _dl_dir(name) if name else DOWNLOADS_ROOT
    if name:
        _CATEGORIES[name] = {"name": name, "savePath": save_path}
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/editCategory", methods=["POST"])
def edit_category():
    name      = request.form.get("category", "").strip()
    save_path = _dl_dir(name) if name else DOWNLOADS_ROOT
    if name:
        _CATEGORIES[name] = {"name": name, "savePath": save_path}
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/removeCategories", methods=["POST"])
def remove_categories():
    cats = request.form.get("categories", "")
    for c in cats.splitlines():
        _CATEGORIES.pop(c.strip(), None)
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/addTags", methods=["POST"])
def add_tags():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/torrents/setAutoManagement", methods=["POST"])
def set_auto_mgmt():
    return Response("Ok.", mimetype="text/plain")

@qbt.route("/sync/maindata")
def sync_maindata():
    if _tm is None:
        return jsonify({"rid": 0, "full_update": True, "torrents": {}, "categories": {}})
    all_t = _tm.all_transfers()
    torrents = {}
    for t in all_t:
        if t.get("state") not in ("cached", "complete"):
            continue
        if t.get("imported"):
            continue
        t_category = t.get("category") or ""
        t_name     = t.get("name") or t["hash"]
        fake_dir   = _fake_folder(t_category, _safe_name(t_name))
        folder_has_files = (os.path.isdir(fake_dir) and
                            any(True for _ in os.scandir(fake_dir)))
        if not folder_has_files:
            # Same rule as torrents/info: don't auto-recreate for Sonarr
            is_sonarr = any(k in t_category.lower() for k in ("sonarr", "tv", "series"))
            if is_sonarr:
                continue
        torrents[t["hash"]] = _torrent_to_qbt(t)
    return jsonify({
        "rid":         int(time.time()),
        "full_update": True,
        "torrents":    torrents,
        "categories":  {},
        "tags":        [],
        "trackers":    {},
    })


# ── Torrent hash extraction ───────────────────────────────────────────────────

def _bencode_value_end(data: bytes, start: int) -> int:
    """Given the start index of a bencode value, return the index just past
    its end. Handles all four bencode types (int, string, list, dict)
    including arbitrarily nested structures — needed to find exactly where
    the 'info' dict ends, since it is NOT always the last top-level key.
    """
    c = data[start:start+1]
    if c == b"i":  # integer: i<digits>e
        end = data.index(b"e", start)
        return end + 1
    if c == b"d" or c == b"l":  # dict or list: recurse until matching 'e'
        i = start + 1
        if c == b"d":
            while data[i:i+1] != b"e":
                i = _bencode_value_end(data, i)   # key (always a string)
                i = _bencode_value_end(data, i)   # value
        else:  # list
            while data[i:i+1] != b"e":
                i = _bencode_value_end(data, i)
        return i + 1
    if c.isdigit():  # string: <len>:<bytes>
        colon = data.index(b":", start)
        length = int(data[start:colon])
        return colon + 1 + length
    raise ValueError(f"invalid bencode at offset {start}: {c!r}")


def _hash_from_torrent(data: bytes) -> str | None:
    """Extract the real BitTorrent info-hash: SHA1 of the exact bencoded
    bytes of the top-level 'info' dict (per the BitTorrent spec — this is
    what every tracker/client actually computes, and the only thing AllDebrid
    will recognize).

    'info' is not always the last top-level key — torrents with DHT nodes,
    web seeds, or other trailing metadata are common in the wild — so this
    walks the bencode structure properly instead of assuming the info dict
    ends one byte before EOF.
    """
    try:
        idx = data.find(b"4:info")
        if idx == -1:
            return None
        info_start = idx + 6  # skip past "4:info"
        info_end   = _bencode_value_end(data, info_start)
        info_data  = data[info_start:info_end]
        return hashlib.sha1(info_data).hexdigest()
    except Exception:
        return None


def _name_from_torrent(data: bytes) -> str:
    """Extract torrent name from bencode — tries name.utf-8 then name."""
    try:
        for key in (b"12:name.utf-8", b"4:name"):
            idx = data.find(key)
            if idx == -1:
                continue
            rest = data[idx + len(key):]
            m = re.match(rb'(\d+):', rest)
            if m:
                length = int(m.group(1))
                start  = len(m.group(0))
                name   = rest[start:start + length].decode("utf-8", errors="replace").strip()
                if name:
                    return name
    except Exception:
        pass
    return ""


@qbt.route("/debug/queue")
def debug_queue():
    """Show exactly what Radarr/Sonarr see when they poll /torrents/info."""
    if _tm is None:
        return jsonify({"error": "transfer manager not initialized"})
    
    result = []
    for t in _tm.all_transfers():
        if t.get("state") not in ("cached", "complete"):
            continue
        t_category = t.get("category") or ""
        t_name     = t.get("name") or t["hash"]
        fake_dir   = _fake_folder(t_category, _safe_name(t_name))
        
        files_in_dir = []
        if os.path.isdir(fake_dir):
            files_in_dir = os.listdir(fake_dir)
        
        qbt = _torrent_to_qbt(t)
        result.append({
            "hash":         t["hash"][:8],
            "name":         t_name[:60],
            "category":     t_category,
            "state":        qbt["state"],
            "size_mb":      qbt["size"] // 1024 // 1024,
            "progress":     qbt["progress"],
            "save_path":    qbt["save_path"],
            "content_path": qbt["content_path"],
            "fake_dir_exists": os.path.isdir(fake_dir),
            "fake_dir_files":  files_in_dir,
            "file_exists":  os.path.exists(qbt["content_path"]),
            "file_size_mb": os.path.getsize(qbt["content_path"]) // 1024 // 1024 if os.path.exists(qbt["content_path"]) else 0,
        })
    
    return jsonify(result)
