"""
name_match.py — shared release-name parsing and fuzzy matching for
premiumize-web sync/reconcile.

All matching is done by normalising both sides to a comparable token set,
then doing graded comparison (exact → year+title → title-only → partial).
"""

import re
from difflib import SequenceMatcher

# ---------------------------------------------------------------------------
# Common noise tokens that appear in release names but not in Arr titles
# ---------------------------------------------------------------------------
_NOISE = re.compile(
    r'\b(?:'
    r'1080[ip]|720[ip]|2160[ip]|480[ip]|576[ip]'
    r'|4k|uhd|hdr|hdr10|hdr10\+|dv|dolbyvision'
    r'|bluray|blu.?ray|bdrip|bdremux|bdrip'
    r'|web.?dl|webrip|web|hmax|nf|atvp|dsnp|amzn|peacock|max'
    r'|hdtv|pdtv|dsr|dvdrip|dvd'
    r'|x264|x265|h264|h265|hevc|avc|av1|xvid|divx'
    r'|10bit|8bit|hi10p'
    r'|aac|dts|truehd|atmos|dd5?\.?1|ac3|eac3|flac|mp3|opus'
    r'|remux|repack|proper|extended|theatrical|directors?cut|final\.?cut'
    r'|imax|open\.?matte|hfr'
    r'|complete|season|collection|trilogy|series|mini.?series'
    r'|tgx|yts|yify|rarbg|ethel|ntb|cakes|nahom|rav1ne|edge2020|pahe'
    r')\b',
    re.IGNORECASE,
)

_SERIES_RE = re.compile(
    r'\bS(0?[1-9]|[1-5]\d|60)(?:E\d{1,3})?(?:[-–]E?\d{1,3})?\b(?![a-zA-Z])'  # S01-S60, S01E01
    r'|\bSeasons?[\s._-]*\d+\b'                                     # Season 1, Seasons 1
    r'|\bSeasons?[\s._-]*(?:One|Two|Three|Four|Five|Six|Seven|Eight|Nine|Ten)\b'  # Season One
    r'|\bSeasons?[\s._-]*\d+[\s._-]*(?:to|and|&|[-–])[\s._-]*\d+\b'  # Seasons 1 to 6
    r'|\bSeasons?[\s._-]*\d+(?:[\s._-]*[+]\s*\d+)+\b'          # Seizoen 1+2+3
    r'|\b\d{1,2}x\d{2}\b'                                          # 1x01
    r'|\bEpisode[\s._-]*\d+\b'                                      # Episode 1
    r'|\bComplete[\s._-]*Series\b'                                   # Complete Series
    r'|\bFull[\s._-]*Series\b'                                       # Full Series
    r'|\bMini[\s._-]*Series\b'                                       # Mini Series
    r'|\bPart[\s._-]*\d+\s+of\s+\d+\b'                          # Part 1 of 3
    r'|\bSeizoen[\s._-]*\d+\b'                                      # Dutch: Seizoen 1
    r'|\bSeizoen[\s._-]*\d+(?:[+\s]*\d+)+\b'                     # Dutch: Seizoen 1+2+3
    r'|\bStagione[\s._-]*\d+\b'                                     # Italian
    r'|\bTemporada[\s._-]*\d+\b'                                    # Spanish
    r'|\bSaison[\s._-]*\d+\b'                                       # French
    r'|\bStaffel[\s._-]*\d+\b'                                      # German
    r'|\bSeries[\s._-]*\d+\b'                                       # British: Series 1
    r'|\((?:19|20)\d{2}[-–](?:19|20)\d{2}\)'               # (1999-2015) TV run in parens
    r'|\[Complete\]'                                                   # [Complete] tag
    r'|\bComplete\b'                                                   # bare Complete (anime packs etc)
    # ── anime-specific patterns ───────────────────────────────────────────────
    r'|\bS(\d{1,2})\b(?![\w/])'                                    # bare S2, S3 (no E following)
    r'|(?<![\w\d])-\s+(\d{1,3})\b(?!\s*(?:bit|fps|hz|p\b))'   # anime ep separator: - 05, - 138
    r'|\((\d{2,3})-(\d{2,3})\)'                                    # episode range in parens: (01-25)
    r'|\b(\d{2,3})\s*~\s*(\d{2,3})\b'                           # tilde range: 01 ~ 14
    r'|\(Batch\)'                                                      # (Batch)
    r'|\bBatch\b'                                                      # bare Batch
    r'|\bOVAs?\b'                                                      # OVA, OVAs
    r'|\bSpecials?\b',                                                  # Special, Specials
    re.IGNORECASE,
)

_YEAR_RE   = re.compile(r'\b((?:19|20)\d{2})\b')
_SEASON_RE = re.compile(
    r'(?i)\bS(\d{1,2})(?:[-\u2013]S?\d{1,2})?\b'        # S01 / S01-S10
    r'|\bSeason[\s._-]*(\d{1,2})\b'                  # Season 1
    r'|\bEpisode[\s._-]*\d+'                          # Episode N (season unknown)
)

# Matches explicit multi-season ranges: S01-S10, S01-10, Seasons 1-10
_SEASON_RANGE_RE = re.compile(
    r'(?i)\bS(\d{1,2})[-\u2013]S?(\d{1,2})\b'                              # S01-S10 or S01-10
    r'|\bSeasons?[\s._-]*(\d{1,2})[\s._-]*(?:[-\u2013]|to|and|&)[\s._-]*(\d{1,2})\b'  # Season/seasons 01-06, 1 to 10
    r'|\bSeizoen[\s._-]*(\d{1,2})(?:[+\s]*\d+)+\b'                          # Dutch: Seizoen 1+2+3
)

# Patterns that indicate a complete/whole series pack with no season info
_COMPLETE_SERIES_RE = re.compile(
    r'(?i)\b(?:complete[\s._-]*series|full[\s._-]*series|the[\s._-]*complete[\s._-]*series)\b'
)


def parse_season_range(name: str) -> tuple[int, int] | None:
    """Return (season_start, season_end) if name is a multi-season or complete-series pack.

    Returns None if it's a single season or single episode.
    """
    n = _strip_site_prefix(name or '')
    m = _SEASON_RANGE_RE.search(n)
    if m:
        g = m.groups()
        if g[0] and g[1]:    # S01-S10
            return int(g[0]), int(g[1])
        if g[2] and g[3]:    # Season/seasons 01-06
            return int(g[2]), int(g[3])
        if g[4]:             # Seizoen 1+2+3 — start=g[4], find all +N numbers for end
            start = int(g[4])
            extras = re.findall(r'\d+', n[m.end():m.start()+20] if m.end() > m.start() else n[m.start():])
            end = max([start] + [int(x) for x in extras if x.isdigit()])
            if end > start:
                return start, end
    return None
_EPISODE_RE = re.compile(
    r'(?i)\bS(\d{1,2})E(\d{1,3})(?:[-–]E?(\d{1,3}))?\b'
)

# 4K detection: 2160p, 4K, UHD
_4K_RE = re.compile(r'(?i)(2160p|\b4k\b|\buhd\b|3840[\s._x]?2160|4096[\s._x]?2160)')

# Resolution tiers, checked in this order (highest first) so e.g. a name
# containing both "1080p" and "720p" noise (rare, but release groups do
# weird things) resolves to the higher one. "unknown" sorts lowest so an
# unidentifiable resolution never beats a known one when picking which
# duplicate to keep.
_RES_TIERS = [
    ("2160p", _4K_RE),
    ("1080p", re.compile(r'(?i)\b1080[ip]\b')),
    ("720p",  re.compile(r'(?i)\b720[ip]\b')),
    ("576p",  re.compile(r'(?i)\b576[ip]\b')),
    ("480p",  re.compile(r'(?i)\b480[ip]\b')),
]
_RES_RANK = {"2160p": 5, "1080p": 4, "720p": 3, "576p": 2, "480p": 1, "unknown": 0}


def parse_resolution(name: str) -> str:
    """Return one of '2160p','1080p','720p','576p','480p','unknown'."""
    for tier, pattern in _RES_TIERS:
        if pattern.search(name or ""):
            return tier
    return "unknown"


def resolution_rank(tier: str) -> int:
    """Higher = better quality. Used to pick which duplicate to keep."""
    return _RES_RANK.get(tier, 0)


def _norm(s: str) -> str:
    """Collapse to lowercase alphanumeric only.
    Normalises & → and first so 'Locke & Key' == 'Locke and Key'.
    """
    s = re.sub(r'\s*&\s*', ' and ', (s or ''))
    return re.sub(r'[^a-z0-9]', '', s.lower())


# Matches site prefixes that appear before the actual title in a release name:
#   www.UIndex.org - Show Name S01E01 ...
#   [TorrentSite.com] Show Name ...
#   SiteName.to - Show Name ...
_SITE_PREFIX_RE = re.compile(
    r'^(?:'
    r'\[[^\]]{1,60}\]\s*'                                        # [TAG] at start
    r'|www[\s._]+[A-Za-z0-9][\w.-]*\.[A-Za-z]{2,6}[\s._]*[-\u2013\u2014][\s._]*'  # www.Site.tld -
    r'|[A-Za-z0-9][\w-]*\.[A-Za-z]{2,6}[\s._]*[-\u2013\u2014][\s._]*'             # Site.tld -
    r')',
    re.IGNORECASE,
)


def _strip_site_prefix(s: str) -> str:
    """Remove leading site/scene-group prefixes from a release name.

    Examples stripped:
        www.UIndex.org - Friday Night Lights S01E02 ...
        www.UIndex.org    -    Shrinking S03E06 ...
        [TorrentDay.com] Show Name S01 ...
        ReleaseGroup.to - Movie.Title.2023 ...

    The remainder is returned unchanged.
    """
    # Run on the original string (dots intact) so www.UIndex.org is recognised,
    # then strip leading whitespace/dashes left after removal
    stripped = _SITE_PREFIX_RE.sub('', s or '').strip(' \t-\u2013\u2014._')
    # If stripping left nothing (the whole name was a prefix), return original
    return stripped if stripped else s


def _clean_title(name: str) -> str:
    """
    Strip release noise from a folder/torrent name to get the bare title.
    Also strips leading/trailing articles for comparison.
    """
    # Strip site prefix first (before dot replacement so www.Site.tld is matched)
    n = _strip_site_prefix(name or '').replace('.', ' ').replace('_', ' ')
    # Strip multi-season range patterns BEFORE _SERIES_RE so fragments don't survive
    # e.g. "seasons 01-06", "Seizoen 1+2+3", "Seasons 1 and 2"
    n = re.sub(r'(?i)\bseasons?\s*\d{1,2}\s*(?:[-\u2013]|to|and|&)\s*\d{1,2}\b.*', '', n)
    n = re.sub(r'(?i)\bseizoen\s*\d{1,2}(?:\s*[+]\s*\d+)+\b.*', '', n)
    # Remove series markers and everything after
    n = _SERIES_RE.sub('', n)
    # Remove year and everything after first year
    m = _YEAR_RE.search(n)
    if m:
        n = n[:m.start()]
    # Remove noise tokens
    n = _NOISE.sub('', n)
    # Strip group tags and quality tags in brackets/parens
    n = re.sub(r'[\[\(][^\]\)]{0,40}[\]\)]', ' ', n)
    # Strip any dangling opening bracket
    n = re.sub(r'[\[\(]\s*$', '', n)
    # Strip leftover season-range fragments: +2+3, -06, bare 01-06 etc
    n = re.sub(r'(?:^|\s)[+]\d+(?:[+]\d+)*', ' ', n)
    n = re.sub(r'\b\d{2}[-\u2013]\d{2}\b', ' ', n)
    # Collapse whitespace and strip
    n = re.sub(r'\s+', ' ', n).strip(' -–()')
    return n


def parse_movie(name: str):
    """
    Returns (clean_title, year|None) from a movie release name.
    """
    # Strip site prefix first so "www.UIndex.org - Title.2023" resolves correctly
    n = _strip_site_prefix(name or '').replace('.', ' ').replace('_', ' ')
    m = _YEAR_RE.search(n)
    year  = m.group(1) if m else None
    title = n[:m.start()].strip() if m else n
    title = _NOISE.sub('', title).strip()
    title = re.sub(r'\s+', ' ', title).strip(' -–')
    return title, year


def parse_episode(name: str):
    """
    Returns (series_title, season, [episode_nums]) from a release name.
    episode_nums=None means season pack (matches all episodes in season).
    season=None means no season info found.
    """
    # Strip site prefix first so "www.UIndex.org - Show S01E01" resolves correctly
    n = _strip_site_prefix(name or '').replace('.', ' ').replace('_', ' ')

    m = _EPISODE_RE.search(n)
    if m:
        season = int(m.group(1))
        e1     = int(m.group(2))
        e2     = int(m.group(3)) if m.group(3) else e1
        if e2 < e1 or e2 - e1 > 60:
            e2 = e1
        title  = _clean_title(n[:m.start()])
        return title, season, list(range(e1, e2 + 1))

    m2 = _SEASON_RE.search(n)
    if m2:
        season = int(m2.group(1) or m2.group(2) or 1)
        title  = _clean_title(n[:m2.start()])
        return title, season, None   # pack

    # No episode/season info — try to salvage a title anyway
    title = _clean_title(n)
    return title, None, None


def override_key_for(name: str, kind: str) -> str:
    """Derive the override key that should be used when setting `name`'s
    classification to `kind`.

    The key must match what classify() will see for OTHER transfers that
    should share this override — critically, future episodes of the same
    show, not just the one transfer the override was set on:

      kind='series' → key on the series title alone (via parse_episode),
                       so S01E05's override also matches S01E06, S02E01, a
                       season pack, etc. — anything parse_episode resolves
                       to the same title.
      kind='movie'  → key on title+year (via parse_movie), matching how
                       duplicate-movie detection already keys movies, so
                       the same release re-added later still matches.

    Falls back to the old literal-name key if title extraction comes back
    empty (e.g. a hash with no usable name), so something is still stored
    rather than silently doing nothing.
    """
    if kind == "series":
        title, _season, _eps = parse_episode(name)
        if title:
            return _norm(title)
    elif kind == "movie":
        title, year = parse_movie(name)
        if title:
            return _norm(title) + (year or "")
    return _norm(name)


def _get_overrides_safe() -> dict:
    """Get overrides without importing app — reads from fuse_mount's shared ref."""
    try:
        import fuse_mount as _fm
        return _fm._overrides
    except Exception:
        return {}

def _override_key_safe(name: str) -> str:
    try:
        import fuse_mount as _fm
        return _fm._override_key(name)
    except Exception:
        return re.sub(r'[^a-z0-9]', '', (name or '').lower())


def _find_override(name: str, ov: dict) -> dict | None:
    """Check both possible override keys for `name` — the series-title key
    (matches a 'series' override set on any episode of this show) and the
    movie title+year key (matches a 'movie' override) — plus the legacy
    literal-name key for overrides set before this lookup was fixed to be
    title-based. Returns the override dict if any match, else None.
    """
    if not ov:
        return None
    series_key = override_key_for(name, "series")
    if series_key in ov:
        return ov[series_key]
    movie_key = override_key_for(name, "movie")
    if movie_key in ov:
        return ov[movie_key]
    legacy_key = _override_key_safe(name)
    if legacy_key in ov:
        return ov[legacy_key]
    return None


def is_series(name: str) -> bool:
    ov  = _get_overrides_safe()
    hit = _find_override(name, ov)
    if hit:
        return hit["kind"] == "series"
    return bool(_SERIES_RE.search(name or ''))


# ── File-path based classification ───────────────────────────────────────────
# Patterns that definitively identify series content in actual file paths.
# These are checked against the real paths returned by Premiumize directdl,
# not just the torrent name — giving 100% accuracy for cached transfers.
_PATH_SERIES_RE = re.compile(
    r'S\d{1,2}E\d{1,3}'                              # S01E01
    r'|\bSeason[\s._-]*\d+'                           # Season 1/ or Season.1
    r'|\b\d{1,2}x\d{2}\b'                            # 1x01
    r'|\bEp(?:isode)?[\s._-]*\d+'                    # Episode 5 / Ep.05
    r'|(?:^|[\\/._\s-])E(\d{2,3})(?:[._\s-]|$)',    # bare .E01. (2+ digits, bounded)
    re.IGNORECASE
)

def classify_from_files(files: list) -> str | None:
    """Classify as 'series' or 'movie' from actual directdl file paths.
    Returns None if files list is empty or inconclusive.
    This is the most reliable classification method — uses ground truth
    from the actual file structure, not the torrent name.
    """
    if not files:
        return None
    for f in files:
        path = f.get("path") or f.get("name") or ""
        if _PATH_SERIES_RE.search(path):
            return "series"
    # No episode markers found in any file path → movie
    # Only conclude 'movie' if we actually have files (empty = inconclusive)
    return "movie"


def classify(name: str, files: list | None = None,
             stored_kind: str = "") -> str:
    """
    Single authoritative classification function. Returns 'series' or 'movie'.

    Priority order:
      1. Manual override (user-set, stored in config)
      2. stored_kind from DB (set from file paths on first directdl)
      3. File paths from directdl (ground truth)
      4. Name pattern matching (fallback for uncached transfers)
    """
    # Tier 1: manual override — via fuse_mount shared ref, no app import
    ov  = _get_overrides_safe()
    hit = _find_override(name, ov)
    if hit:
        return hit["kind"]  # 'movie' or 'series'

    # Tier 2: stored kind from DB (already classified from file paths)
    if stored_kind in ("movie", "series"):
        return stored_kind

    # Tier 3: classify from actual file paths (ground truth)
    if files:
        result = classify_from_files(files)
        if result:
            return result

    # Tier 4: name pattern fallback (for transfers not yet fetched)
    return "series" if bool(_SERIES_RE.search(name or "")) else "movie"
