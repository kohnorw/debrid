"""
AllDebrid client for DFS FUSE mounting.

Two endpoints matter:
  - v4.1/magnet/status  — list all ready torrents (IDs, names, hashes)
  - v4/magnet/files     — get the nested file tree for one or more magnet IDs
  - v4/link/unlock      — resolve an AllDebrid link to a CDN URL (called per-read by fuse_mount)

Files from magnet/files are nested dicts with an "e" key for sub-folders.
_flatten_files() recurses them into a flat list of {"n", "l", "s"} dicts,
which is the format fuse_mount.py expects.
"""
import logging
from pathlib import Path

import httpx

log = logging.getLogger("debridarr.alldebrid")

AD_BASE   = "https://api.alldebrid.com/v4"
AD_STATUS = "https://api.alldebrid.com/v4.1/magnet/status"
AD_FILES  = f"{AD_BASE}/magnet/files"
AD_UNLOCK = f"{AD_BASE}/link/unlock"
AGENT     = "debridarr"


class AllDebridClient:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self._client = httpx.AsyncClient(timeout=30)

    # ── Internal helpers ──────────────────────────────────────────────────────

    async def _get(self, url: str, params: dict) -> dict:
        params = {"agent": AGENT, "apikey": self.api_key, **params}
        r = await self._client.get(url, params=params)
        return r.json()

    async def _post_form(self, url: str, fields: list[tuple]) -> dict:
        """POST application/x-www-form-urlencoded with repeated keys (e.g. id[])."""
        from urllib.parse import urlencode
        pairs = [("agent", AGENT), ("apikey", self.api_key)] + list(fields)
        body  = urlencode(pairs).encode()
        r = await self._client.post(
            url,
            content=body,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        return r.json()

    def _flatten_files(self, files: list, depth: int = 0) -> list:
        """Recursively flatten AllDebrid's nested file tree.

        AllDebrid represents folders as {"n": "FolderName", "e": [...children]}.
        Leaf files are {"n": "filename.mkv", "l": "https://...", "s": 12345678}.
        fuse_mount.py expects a flat list of leaf dicts with keys n, l, s.
        """
        result = []
        for f in files:
            if "e" in f:
                result.extend(self._flatten_files(f["e"], depth + 1))
            else:
                result.append(f)
        return result

    # ── Public API ────────────────────────────────────────────────────────────

    async def unlock_file(self, link: str) -> str | None:
        """Resolve an AllDebrid link to a direct CDN URL.
        Called by fuse_mount.py on every cache miss to get a fresh download URL.
        """
        if not self.api_key or not link:
            return None
        try:
            data = await self._get(AD_UNLOCK, {"link": link})
            if data.get("status") == "success":
                return data["data"].get("link")
            log.warning("unlock_file error: %s", data.get("error", {}).get("message", data))
        except Exception as e:
            log.error("unlock_file: %s", e)
        return None

    async def get_all_torrents(self) -> list[dict]:
        """Return all ready AllDebrid torrents as a list of:
            {"id": str, "name": str, "hash": str, "files": [{"n", "l", "s"}, ...]}

        Uses two API calls:
          1. magnet/status?status=ready  — get IDs, names, hashes
          2. magnet/files (batched)      — get the actual nested file trees

        Only torrents with at least one video file are returned.
        The folder name is derived from the first video file's stem when it
        matches the torrent name, mirroring what the working version does.
        """
        if not self.api_key:
            return []

        try:
            # Step 1: list all ready magnets
            r = await self._get(AD_STATUS, {"status": "ready"})
            if r.get("status") != "success":
                log.warning("magnet/status failed: %s", r.get("error", r))
                return []

            magnets_raw = r.get("data", {}).get("magnets", {})
            magnets = (
                list(magnets_raw.values())
                if isinstance(magnets_raw, dict)
                else (magnets_raw if isinstance(magnets_raw, list) else [])
            )

            if not magnets:
                log.info("AllDebrid: no ready torrents")
                return []

            id_name = {str(m["id"]): m.get("filename", f"torrent_{m['id']}") for m in magnets if m.get("id")}
            id_hash = {str(m["id"]): (m.get("hash") or "").lower() for m in magnets if m.get("id")}
            ids = list(id_name.keys())

            # Step 2: fetch file trees in batches of 50
            video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
            result = []
            BATCH = 50

            for i in range(0, len(ids), BATCH):
                batch = ids[i : i + BATCH]
                fr = await self._post_form(AD_FILES, [("id[]", x) for x in batch])
                if not fr or fr.get("status") != "success":
                    log.warning("magnet/files batch failed: %s", fr.get("error", fr) if fr else "no response")
                    continue

                mfiles = fr.get("data", {}).get("magnets", [])
                if isinstance(mfiles, dict):
                    mfiles = list(mfiles.values())

                for mf in mfiles:
                    mid  = str(mf.get("id", ""))
                    name = id_name.get(mid, f"torrent_{mid}")
                    flat = self._flatten_files(mf.get("files", []))
                    videos = [f for f in flat if any(f.get("n", "").lower().endswith(e) for e in video_exts)]
                    if not videos:
                        continue
                    # Use the first video's stem as the folder name if it starts
                    # with the torrent name — keeps FUSE paths clean.
                    stem = Path(videos[0]["n"]).stem
                    folder = stem if (stem and stem.startswith(name.rstrip("-"))) else name
                    result.append({
                        "id":    mid,
                        "name":  folder,
                        "hash":  id_hash.get(mid, ""),
                        "files": videos,
                    })

            log.info("AllDebrid: %d torrent(s) ready for FUSE", len(result))
            return result

        except Exception as e:
            log.error("get_all_torrents: %s", e, exc_info=True)
            return []

    async def aclose(self):
        await self._client.aclose()
