"""
Built-in Torznab indexer backed by The Pirate Bay + AllDebrid cache checking.

Point Prowlarr (or Sonarr/Radarr directly) at Debridarr's /torznab endpoint and
it will only ever surface torrents that AllDebrid already has cached — so every
release the arr grabs is instantly available, which is exactly what Debridarr's
play-on-demand model needs.

Ported from the standalone "alldebrid-web" Flask app, using httpx to match
Debridarr's stack. The AllDebrid cache check uploads the magnets, reads each
magnet's `ready` flag, then immediately deletes them so nothing stays on the
account.
"""
import re
import logging
import urllib.parse
from datetime import datetime, timezone
from xml.sax.saxutils import escape as xml_escape

import httpx

log = logging.getLogger("debridarr.indexer")

# ── upstream endpoints ────────────────────────────────────────────────────────
APIBAY_URLS = [
    "https://apibay.org/q.php",
    "https://thepiratebay10.info/apibay/q.php",
    "https://piratebayproxy.live/apibay/q.php",
]
ALLDEBRID_UPLOAD = "https://api.alldebrid.com/v4/magnet/upload"
ALLDEBRID_DELETE = "https://api.alldebrid.com/v4/magnet/delete"

# ── category mapping ──────────────────────────────────────────────────────────
def tpb_to_newznab(tpb_cat, name: str = "") -> int:
    name_up = (name or "").upper()
    if re.search(r"S\d{2}E\d{2}|SEASON\s+\d+|\bS\d{2}\b", name_up):
        return 5000  # TV
    try:
        c = int(tpb_cat)
    except Exception:
        return 8000
    if 200 <= c < 300: return 2000   # Movies
    if 500 <= c < 600: return 5000   # TV
    if 300 <= c < 400: return 3000   # Audio
    return 8000

QUALITY_PATTERNS = re.compile(
    r"\b(2160p?|1080p?|720p?|480p?|4k|uhd|hdr|hdr10|dv|web-?dl|webrip|bluray|"
    r"blu-ray|hevc|x265|x264|h264|h265|remux|proper|repack)\b",
    re.IGNORECASE,
)

def fmt_size(b) -> int:
    try:
        return int(b)
    except Exception:
        return 0

def _sanitize(query: str) -> str:
    q = re.sub(r"[''`´]", "", query)
    q = re.sub(r"[^\w\s\-]", " ", q)
    return re.sub(r"\s+", " ", q).strip()

def parse_query(raw: str):
    """Return (clean_title_for_tpb, season, episode, [quality tokens]).

    SE tags and quality tokens are stripped from the returned query so TPB
    gets a clean title search (e.g. "Breaking Bad" not "Breaking Bad S01E01" —
    apibay returns nothing for the latter). Season/episode come back separately
    and are applied as a post-fetch filter instead.
    """
    season, episode = None, None
    quality = QUALITY_PATTERNS.findall(raw)
    search_raw = QUALITY_PATTERNS.sub("", raw).strip()
    m = re.search(r"\bseason\s+(\d+)\b", search_raw, re.IGNORECASE)
    if m:
        season = int(m.group(1))
        search_raw = re.sub(r"\bseason\s+\d+\b", "", search_raw, flags=re.IGNORECASE)
    m = re.search(r"(?<![a-zA-Z])S(\d{1,2})(?:E(\d{1,2}))?(?![a-zA-Z0-9])", search_raw, re.IGNORECASE)
    if m:
        season = int(m.group(1))
        if m.group(2):
            episode = int(m.group(2))
        # Drop the SE tag from the TPB query — it needs a clean title
        search_raw = search_raw[:m.start()] + search_raw[m.end():]
    return " ".join(search_raw.split()).strip(), season, episode, quality

def strip_season(query: str) -> str:
    t = re.sub(r"(?<![a-zA-Z])S\d{1,2}(?:E\d{1,2})?(?![a-zA-Z0-9])", "", query, flags=re.IGNORECASE)
    return " ".join(t.split())

def filter_by_season(torrents, season, episode):
    if season is None:
        return torrents
    s_str = f"S{season:02d}"
    s_alt = f"SEASON {season}"
    out = []
    for t in torrents:
        nu = (t.get("name", "") or "").upper()
        if s_str not in nu and s_alt not in nu:
            continue
        others = re.findall(r"S(\d{2})E\d{2}", nu)
        if others and not all(int(s) == season for s in others):
            continue
        if episode is not None and f"E{episode:02d}" not in nu:
            continue
        out.append(t)
    return out

def filter_by_quality(torrents, quality):
    if not quality:
        return torrents
    out = []
    for t in torrents:
        name_up = (t.get("name", "") or "").upper()
        for q in quality:
            if q.upper().rstrip("P") in name_up:
                out.append(t)
                break
    return out if out else torrents

# ── upstream fetch + AllDebrid cache check ────────────────────────────────────
def _fetch(query: str, limit: int = 40):
    queries = [query]
    sanitized = _sanitize(query)
    if sanitized.lower() != query.lower():
        queries.append(sanitized)
    for q in queries:
        for url in APIBAY_URLS:
            try:
                r = httpx.get(url, params={"q": q, "cat": 0}, timeout=10)
                if r.status_code != 200:
                    continue
                data = r.json()
                if not data or (isinstance(data, list) and data[0].get("id") == "0"):
                    continue
                valid = [
                    x for x in data
                    if isinstance(x, dict) and x.get("info_hash")
                    and re.fullmatch(r"[0-9a-fA-F]{40}", x["info_hash"])
                ]
                if valid:
                    return valid[:limit]
            except Exception:
                continue
    return []

def _make_magnet(torrent) -> str:
    h    = torrent["info_hash"].lower()
    name = urllib.parse.quote(torrent.get("name", ""), safe="")
    return f"magnet:?xt=urn:btih:{h}&dn={name}"

def _ad_post(api_key: str, torrents):
    if not torrents:
        return {}
    pairs = [("magnets[]", _make_magnet(t)) for t in torrents]
    body  = urllib.parse.urlencode(pairs)
    try:
        r = httpx.post(
            ALLDEBRID_UPLOAD,
            headers={"Authorization": f"Bearer {api_key}",
                     "Content-Type": "application/x-www-form-urlencoded"},
            params={"agent": "debridarr", "apikey": api_key},
            content=body, timeout=20,
        )
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.warning("AllDebrid upload failed: %s", e)
        return {}

def _delete_magnets(api_key: str, ids):
    for mid in ids:
        try:
            httpx.post(
                ALLDEBRID_DELETE,
                headers={"Authorization": f"Bearer {api_key}",
                         "Content-Type": "application/x-www-form-urlencoded"},
                params={"agent": "debridarr", "apikey": api_key},
                content=urllib.parse.urlencode({"id": mid}), timeout=10,
            )
        except Exception:
            pass

def check_cache(api_key: str, torrents) -> dict | None:
    """Return {hash: ready_bool}, or None if the check couldn't be performed
    (network/API error, auth failure, or no magnets echoed back).

    None vs {} matters: {} means "AllDebrid answered, nothing cached"; None
    means "we don't know" — and the caller must NOT filter everything out on
    None, or every search comes back empty whenever the cache check hiccups."""
    result = _ad_post(api_key, torrents)
    if not result:
        return None
    if result.get("status") == "error":
        log.warning("AllDebrid cache check error: %s", result.get("error"))
        return None
    magnets = result.get("data", {}).get("magnets", [])
    if not magnets:
        return None
    ready_map, ids_to_delete = {}, []
    for m in magnets:
        if m.get("error"):
            continue
        h = (m.get("hash") or "").lower()
        if h:
            ready = bool(m.get("ready", False)) or \
                    bool(m.get("instant", False)) or \
                    str(m.get("status", "")).lower() in ("ready", "cached", "downloaded")
            ready_map[h] = ready
        if m.get("id"):
            ids_to_delete.append(m["id"])
    _delete_magnets(api_key, ids_to_delete)
    return ready_map

def add_magnet(api_key: str, torrent) -> dict:
    """Add a magnet to AllDebrid for real (used by the manual 'Add' action)."""
    result  = _ad_post(api_key, [torrent])
    magnets = result.get("data", {}).get("magnets", [])
    if not magnets:
        return {"error": result.get("error", {}).get("message", "Unknown error")}
    m = magnets[0]
    if m.get("error"):
        return {"error": m["error"].get("message", "Unknown error")}
    return {"name": m.get("name", torrent.get("name", "?")),
            "ready": bool(m.get("ready", False)), "id": m.get("id")}

# ── search ────────────────────────────────────────────────────────────────────
def search(query, season=None, episode=None, quality=None,
           limit=40, ad_key=None, cached_only=True):
    """Search TPB, check the AllDebrid cache, and (by default) return only the
    releases AllDebrid already has cached, sorted by seeders."""
    torrents = _fetch(query, limit)
    if not torrents and season is not None:
        fallback = strip_season(query)
        if fallback and fallback.lower() != query.lower():
            torrents = _fetch(fallback, limit * 2)
    if not torrents:
        return []

    filtered = filter_by_season(torrents, season, episode)
    if not filtered and season is not None:
        filtered = torrents
    if quality:
        filtered = filter_by_quality(filtered, quality)

    # ready_map is {hash: bool} on success, or None when the check failed.
    ready_map = check_cache(ad_key, filtered) if ad_key else None
    cache_known = ready_map is not None
    if not cache_known:
        ready_map = {}
        if cached_only and ad_key:
            log.warning("AllDebrid cache check unavailable — returning seeded "
                        "results unfiltered so the feed isn't empty")

    results = []
    for t in filtered:
        h = t["info_hash"].lower()
        cached = ready_map.get(h, False)
        # Only filter on cache status when we actually know it.
        if cached_only and ad_key and cache_known and not cached:
            continue
        results.append({
            "hash":     h,
            "name":     t.get("name", "Unknown"),
            "size":     fmt_size(t.get("size", 0)),
            "seeders":  int(t.get("seeders", 0) or 0),
            "leechers": int(t.get("leechers", 0) or 0),
            "category": tpb_to_newznab(t.get("category", 0), t.get("name", "")),
            "cached":   cached,
        })
    # Cached first (matters when cached_only is off), then most seeded
    results.sort(key=lambda x: (not x["cached"], -x["seeders"]))
    return results

# ── Torznab XML ───────────────────────────────────────────────────────────────
def torznab_caps() -> str:
    return '''<?xml version="1.0" encoding="UTF-8"?>
<caps xmlns:torznab="http://torznab.com/schemas/2015/feed">
  <server title="Debridarr (AllDebrid cached)" />
  <limits default="40" max="100"/>
  <searching>
    <search available="yes" supportedParams="q"/>
    <tv-search available="yes" supportedParams="q,season,ep"/>
    <movie-search available="yes" supportedParams="q"/>
    <audio-search available="no" supportedParams="q"/>
    <book-search available="no" supportedParams="q"/>
  </searching>
  <categories>
    <category id="2000" name="Movies">
      <subcat id="2010" name="Movies/Foreign"/>
      <subcat id="2020" name="Movies/Other"/>
      <subcat id="2030" name="Movies/SD"/>
      <subcat id="2040" name="Movies/HD"/>
      <subcat id="2045" name="Movies/UHD"/>
      <subcat id="2050" name="Movies/BluRay"/>
      <subcat id="2060" name="Movies/3D"/>
      <subcat id="2070" name="Movies/DVD"/>
      <subcat id="2080" name="Movies/WEB-DL"/>
    </category>
    <category id="5000" name="TV">
      <subcat id="5010" name="TV/WEB-DL"/>
      <subcat id="5020" name="TV/Foreign"/>
      <subcat id="5030" name="TV/SD"/>
      <subcat id="5040" name="TV/HD"/>
      <subcat id="5045" name="TV/UHD"/>
      <subcat id="5050" name="TV/Other"/>
      <subcat id="5060" name="TV/Sport"/>
      <subcat id="5070" name="TV/Anime"/>
      <subcat id="5080" name="TV/Documentary"/>
    </category>
    <category id="8000" name="Other">
      <subcat id="8010" name="Other/Misc"/>
    </category>
  </categories>
</caps>'''

def torznab_results(results) -> str:
    now = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
    items = []
    for r in results:
        magnet   = f"magnet:?xt=urn:btih:{r['hash']}&dn={urllib.parse.quote(r['name'], safe='')}"
        seeders  = int(r.get("seeders", 0) or 0)
        leechers = int(r.get("leechers", 0) or 0)
        peers    = seeders + leechers
        # Flag cached releases as freeleech (downloadvolumefactor 0)
        cached_attr = '\n      <torznab:attr name="downloadvolumefactor" value="0"/>' if r["cached"] else ""
        items.append(f"""    <item>
      <title>{xml_escape(r['name'])}</title>
      <guid isPermaLink="false">{r['hash']}</guid>
      <link>{xml_escape(magnet)}</link>
      <comments></comments>
      <pubDate>{now}</pubDate>
      <size>{r['size']}</size>
      <category>{r['category']}</category>
      <enclosure url="{xml_escape(magnet)}" length="{r['size']}" type="application/x-bittorrent"/>
      <torznab:attr name="category" value="{r['category']}"/>
      <torznab:attr name="magneturl" value="{xml_escape(magnet)}"/>
      <torznab:attr name="infohash" value="{r['hash']}"/>
      <torznab:attr name="seeders" value="{seeders}"/>
      <torznab:attr name="leechers" value="{leechers}"/>
      <torznab:attr name="peers" value="{peers}"/>
      <torznab:attr name="size" value="{r['size']}"/>
      <torznab:attr name="uploadvolumefactor" value="1"/>{cached_attr}
    </item>""")
    items_xml = "\n".join(items)
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:torznab="http://torznab.com/schemas/2015/feed">
  <channel>
    <atom:link href="http://localhost" rel="self" type="application/rss+xml"/>
    <title>Debridarr (AllDebrid cached)</title>
    <description>The Pirate Bay filtered to AllDebrid-cached releases</description>
    <link>http://localhost</link>
    <language>en-US</language>
    <category>search</category>
{items_xml}
  </channel>
</rss>'''

def xml_error(code, description) -> str:
    return ('<?xml version="1.0" encoding="UTF-8"?>\n'
            f'<error code="{code}" description="{xml_escape(description)}"/>')

def build_query(q: str, season: str = "", ep: str = "") -> str:
    """Combine a base query with explicit season/ep params (Torznab tvsearch)."""
    query = q or ""
    if season:
        try:
            s = int(season)
            query = f"{q} S{s:02d}" if q else f"S{s:02d}"
            if ep:
                query += f"E{int(ep):02d}"
        except ValueError:
            pass
    return query.strip()
