"""
Streaming proxy for Debridarr.

THE PLEX s1001 PROBLEM:
  Plex fetches .strm URLs and has two separate timeouts:
    1. Response-start timeout (~10s): if no bytes arrive, s1001 immediately
    2. Read timeout: reset on every byte received

  Simply blocking inside an async generator (sleeping with no yield) hits
  timeout #1 — Plex gives up before we send anything.

THE SOLUTION:
  When a file isn't cached yet:
  1. Immediately send HTTP 200 + chunked headers (satisfies response-start)
  2. Yield a valid minimal MP4 header (ftyp+moov) within the first second —
     Plex sees a parseable video container and keeps waiting for more data
  3. Drip a single null byte every KEEPALIVE_EVERY seconds to reset timeout #2
  4. When resolve_and_cache finishes, stop the keepalive — Plex's player
     will re-request (it sees stream end) and hit the cached fast path

  The null bytes and fake header are discarded by Plex's demuxer because
  the moov box declares 0 tracks and 0 duration — Plex buffers them but
  plays nothing until the real stream starts on re-request.

ALREADY CACHED:
  Stream immediately with full range-request support. No tricks needed.
"""

import asyncio
import logging
import struct
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, AsyncIterator

import httpx
from fastapi import HTTPException, Request
from fastapi.responses import StreamingResponse
from starlette.responses import Response

log = logging.getLogger("debridarr.proxy")

RESOLVE_TIMEOUT = 120           # seconds to wait before giving up
KEEPALIVE_EVERY = 5             # seconds between null-byte keepalives
CHUNK_SIZE      = 256 * 1024    # 256 KB per real video chunk
LINK_MAX_AGE    = timedelta(hours=4)

_refresh_locks: dict[str, asyncio.Lock] = {}


def _get_lock(key: str) -> asyncio.Lock:
    if key not in _refresh_locks:
        _refresh_locks[key] = asyncio.Lock()
    return _refresh_locks[key]


def _minimal_mp4_header() -> bytes:
    """
    Minimal valid MP4 container — ftyp + empty moov.
    Sent immediately so Plex recognises a video stream and keeps waiting.
    Declares 0 tracks, 0 duration — produces no visible frames.
    """
    def box(t: bytes, payload: bytes) -> bytes:
        return struct.pack(">I", 8 + len(payload)) + t + payload

    ftyp = box(b"ftyp", b"mp42\x00\x00\x00\x00mp42isom")
    mvhd = box(b"mvhd",
        b"\x00" * 12
        + struct.pack(">I", 1000)           # timescale
        + struct.pack(">I", 0)              # duration = 0
        + struct.pack(">I", 0x00010000)     # rate
        + struct.pack(">H", 0x0100)         # volume
        + b"\x00" * 10
        + struct.pack(">9i", 0x00010000, 0, 0, 0, 0x00010000, 0, 0, 0, 0x40000000)
        + b"\x00" * 24
        + struct.pack(">I", 2)              # next track id
    )
    return ftyp + box(b"moov", mvhd)


# ── .strm file management ─────────────────────────────────────────────────────

def write_strm(
    cache_key: str, title: str, year: Optional[int],
    season: Optional[int], episode: Optional[int],
    media_type: str, debridarr_base_url: str, plex_root: str,
) -> Optional[Path]:
    if not plex_root:
        return None
    try:
        url = f"{debridarr_base_url.rstrip('/')}/proxy/{cache_key}"
        if media_type == "movie":
            yp   = f" ({year})" if year else ""
            name = f"{title}{yp}"
            path = Path(plex_root) / "movies" / name / f"{name}.strm"
        else:
            sf   = f"Season {season:02d}" if season else "Season 00"
            se   = f"S{season:02d}E{episode:02d}" if (season and episode) else "S00E00"
            path = Path(plex_root) / "tv" / title / sf / f"{title} - {se}.strm"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(url + "\n")
        log.info(f"📄 Wrote .strm → {path}")
        return path
    except Exception as e:
        log.error(f"write_strm {cache_key}: {e}", exc_info=True)
        return None


def delete_strm(
    cache_key: str, title: str, year: Optional[int],
    season: Optional[int], episode: Optional[int],
    media_type: str, plex_root: str,
) -> bool:
    if not plex_root:
        return False
    try:
        if media_type == "movie":
            yp   = f" ({year})" if year else ""
            name = f"{title}{yp}"
            path = Path(plex_root) / "movies" / name / f"{name}.strm"
        else:
            sf   = f"Season {season:02d}" if season else "Season 00"
            se   = f"S{season:02d}E{episode:02d}" if (season and episode) else "S00E00"
            path = Path(plex_root) / "tv" / title / sf / f"{title} - {se}.strm"
        if path.exists():
            path.unlink()
            log.info(f"🗑️  Deleted .strm → {path}")
            _rmdir_if_empty(path.parent)
            _rmdir_if_empty(path.parent.parent)
            return True
    except Exception as e:
        log.warning(f"delete_strm {cache_key}: {e}")
    return False


def _rmdir_if_empty(p: Path):
    try:
        if p.exists() and not any(p.iterdir()):
            p.rmdir()
    except Exception:
        pass


# ── Main proxy endpoint ───────────────────────────────────────────────────────

async def proxy_stream(
    request: Request, cache_key: str, db, alldebrid, app=None,
) -> Response:
    entry = db.get(cache_key)

    # Fast path — already cached, stream immediately
    if entry and entry["status"] == "cached":
        return _make_stream_response(request, cache_key, entry, db, alldebrid)

    # Slow path — not cached yet
    if app is None:
        raise HTTPException(503, "App context unavailable")

    # Fire resolve if not already running
    if entry is None or entry["status"] in ("not_found", "error"):
        try:
            from app.main import _resolve_for_proxy
            import threading
            log.info(f"▶️  On-play resolve: {cache_key}")
            threading.Thread(target=_resolve_for_proxy, args=(cache_key,),
                             daemon=True, name=f"resolve-{cache_key[:16]}").start()
        except Exception as e:
            log.error(f"Could not start resolve for {cache_key}: {e}")
            raise HTTPException(503, str(e))
    else:
        log.info(f"▶️  Waiting for in-progress resolve: {cache_key} (status={entry['status']})")

    # Return a response that:
    # a) starts immediately (satisfies Plex's response-start timeout)
    # b) sends a valid MP4 header so Plex treats this as a video stream
    # c) drips null bytes to keep the read timeout alive
    # d) stops when resolved — Plex re-requests and hits the fast path
    return StreamingResponse(
        _keepalive_stream(cache_key, db),
        status_code=200,
        media_type="video/mp4",
        headers={"Cache-Control": "no-store", "Accept-Ranges": "bytes"},
    )


async def _keepalive_stream(cache_key: str, db) -> AsyncIterator[bytes]:
    """
    1. Immediately yield a valid MP4 header so Plex sees a video container
       and doesn't hit its response-start timeout.
    2. Drip a null byte every KEEPALIVE_EVERY seconds to reset Plex's
       read timeout while resolve_and_cache runs.
    3. When status = 'cached', stop — Plex re-requests and streams for real.
    4. If resolve fails or timeout expires, stop — Plex shows an error,
       but only because something genuinely went wrong.
    """
    # Step 1: send valid MP4 header immediately
    yield _minimal_mp4_header()

    elapsed = 0
    while elapsed < RESOLVE_TIMEOUT:
        await asyncio.sleep(KEEPALIVE_EVERY)
        elapsed += KEEPALIVE_EVERY

        entry  = db.get(cache_key)
        status = entry["status"] if entry else "missing"
        log.debug(f"⏳ {cache_key}: {status} ({elapsed}s)")

        if status == "cached":
            log.info(f"✅ Resolved in {elapsed}s — Plex will re-request {cache_key}")
            return   # stream ends cleanly; Plex retries .strm → hits fast path

        if status in ("error", "unlock_failed"):
            log.warning(f"❌ Resolve failed for {cache_key}: {status}")
            return

        # Step 2: drip null byte to reset read timeout
        yield b"\x00"

    log.warning(f"⏰ Keepalive timed out for {cache_key} after {elapsed}s")


# ── Direct stream endpoint (/stream/<cache_key>) ──────────────────────────────

async def stream_direct(request: Request, cache_key: str, db, alldebrid) -> Response:
    entry = db.get(cache_key)
    if not entry or entry["status"] != "cached":
        raise HTTPException(503, "Not cached yet")
    return _make_stream_response(request, cache_key, entry, db, alldebrid)


# ── Streaming helpers ─────────────────────────────────────────────────────────

def _make_stream_response(request, cache_key, entry, db, alldebrid) -> StreamingResponse:
    range_hdr = request.headers.get("range")
    headers   = {"Range": range_hdr} if range_hdr else {}
    return StreamingResponse(
        _stream_entry(cache_key, entry, db, alldebrid, headers),
        status_code=206 if range_hdr else 200,
        media_type=_content_type(entry.get("torrent_name", "")),
        headers=_response_headers(entry),
    )


async def _stream_entry(cache_key, entry, db, alldebrid, headers) -> AsyncIterator[bytes]:
    url = await _fresh_url(entry, cache_key, db, alldebrid)
    async for chunk in _fetch(url, headers, cache_key, entry, db, alldebrid):
        yield chunk


async def _fresh_url(entry: dict, cache_key: str, db, alldebrid) -> str:
    async with _get_lock(cache_key):
        fresh = db.get(cache_key) or entry
        ts    = fresh.get("link_refreshed_at")
        if ts and (datetime.utcnow() - datetime.fromisoformat(ts)) < LINK_MAX_AGE:
            return fresh["stream_url"]
        log.info(f"🔄 Re-unlocking {cache_key}")
        try:
            new = await alldebrid.unlock_magnet(fresh["magnet_link"])
            if new:
                db.update_stream_url(cache_key, new)
                return new
        except Exception as e:
            log.error(f"Re-unlock failed {cache_key}: {e}")
        return fresh["stream_url"]


async def _fetch(
    url: str, headers: dict, cache_key: str, entry: dict, db, alldebrid,
) -> AsyncIterator[bytes]:
    client  = httpx.AsyncClient(timeout=None, follow_redirects=True)
    retried = False
    try:
        while True:
            try:
                async with client.stream("GET", url, headers=headers) as r:
                    if r.status_code in (403, 410) and not retried:
                        retried = True
                        new = await alldebrid.unlock_magnet(entry["magnet_link"])
                        if new:
                            db.update_stream_url(cache_key, new)
                            url = new
                        continue
                    if r.status_code not in (200, 206):
                        log.error(f"CDN HTTP {r.status_code} for {cache_key}")
                        return
                    async for chunk in r.aiter_bytes(CHUNK_SIZE):
                        yield chunk
                    return
            except (httpx.RemoteProtocolError, httpx.ReadError) as e:
                if not retried:
                    retried = True
                    log.warning(f"Stream interrupted {cache_key}: {e} — retrying")
                    new = await alldebrid.unlock_magnet(entry["magnet_link"])
                    if new:
                        db.update_stream_url(cache_key, new)
                        url = new
                    continue
                log.error(f"Stream failed {cache_key}: {e}")
                return
    finally:
        await client.aclose()


def _content_type(filename: str) -> str:
    n = filename.lower()
    if n.endswith(".mkv"):            return "video/x-matroska"
    if n.endswith((".mp4", ".m4v")): return "video/mp4"
    if n.endswith(".avi"):            return "video/x-msvideo"
    return "video/mp4"


def _response_headers(entry: dict) -> dict:
    h = {"Cache-Control": "no-store", "Accept-Ranges": "bytes"}
    name = entry.get("torrent_name", "")
    if name:
        h["Content-Disposition"] = f'inline; filename="{name.replace(chr(34), "")}"'
    return h
