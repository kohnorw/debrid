#!/usr/bin/env python3
"""
Read-only expiry diagnostic for debridarr.

Compares, for every active stream, the candidate "age anchors" so we can see
which timestamp actually carries the true age of an item:

  • db_created   — created_at stored in the DB (what expiry currently uses)
  • link_mtime   — mtime of the symlink itself (os.lstat — does NOT follow link)
  • link_btime   — birth time of the symlink, where the platform exposes it
  • target_mtime — mtime of the real file the symlink points at (FUSE/debrid side)

It writes NOTHING. Run it inside the debridarr container:

    python3 /app/diagnose_expiry.py            # or wherever main.py lives

Then paste the SUMMARY section back.
"""
import os
import sqlite3
import sys
from collections import Counter
from datetime import datetime, timezone

DB_PATH = os.getenv("DB_PATH", "/data/debridarr.db")
SAMPLE  = int(os.getenv("DIAG_SAMPLE", "15"))   # how many per-row examples to print


def _ts(path, follow):
    """Return (mtime_iso, btime_iso_or_None) for a path, or (None, None)."""
    try:
        st = os.stat(path) if follow else os.lstat(path)
    except OSError:
        return None, None
    m = datetime.fromtimestamp(st.st_mtime, tz=timezone.utc)
    b = getattr(st, "st_birthtime", None)
    b = datetime.fromtimestamp(b, tz=timezone.utc) if b else None
    return m, b


def _day(dt):
    return dt.date().isoformat() if dt else "—"


def main():
    if not os.path.exists(DB_PATH):
        sys.exit(f"DB not found at {DB_PATH} (set DB_PATH env var to override)")

    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    rows = db.execute(
        "SELECT title, season, episode, source_path, symlink_path, "
        "created_at, expires_at, status "
        "FROM streams WHERE status='active' ORDER BY created_at ASC"
    ).fetchall()

    if not rows:
        sys.exit("No active streams found.")

    print(f"\nInspecting {len(rows)} active streams from {DB_PATH}\n")
    print("=" * 78)
    print(f"{'TITLE':28} {'db_created':11} {'link_mtime':11} "
          f"{'link_btime':11} {'target_mtime':11}")
    print("-" * 78)

    db_days, link_days, tgt_days = Counter(), Counter(), Counter()
    link_missing = tgt_missing = 0

    for i, r in enumerate(rows):
        link_m, link_b = _ts(r["symlink_path"], follow=False)
        tgt_m,  _      = _ts(r["source_path"],  follow=True)

        try:
            dbc = datetime.fromisoformat(r["created_at"].replace("Z", "+00:00"))
        except Exception:
            dbc = None

        if dbc:   db_days[_day(dbc)]    += 1
        if link_m: link_days[_day(link_m)] += 1
        else:      link_missing += 1
        if tgt_m:  tgt_days[_day(tgt_m)]   += 1
        else:      tgt_missing += 1

        if i < SAMPLE:
            label = r["title"][:24]
            if r["season"] is not None:
                label = f"{label[:18]} S{r['season']:02}E{r['episode']:02}"
            print(f"{label:28} {_day(dbc):11} {_day(link_m):11} "
                  f"{_day(link_b):11} {_day(tgt_m):11}")

    def spread(name, counter, missing):
        print(f"\n  {name}: {len(counter)} distinct day(s)"
              + (f", {missing} unreadable" if missing else ""))
        for day, n in sorted(counter.items()):
            print(f"      {day}: {n}")

    print("\n" + "=" * 78)
    print("SUMMARY — how many distinct days each timestamp source spans")
    print("(1 distinct day = that source can't distinguish item ages)")
    spread("db_created  ", db_days, 0)
    spread("link_mtime  ", link_days, link_missing)
    spread("target_mtime", tgt_days, tgt_missing)
    print("\nWhichever source shows a real SPREAD of days is the true age anchor.")
    print("=" * 78 + "\n")


if __name__ == "__main__":
    main()
