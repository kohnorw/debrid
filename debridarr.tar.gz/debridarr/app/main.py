"""
Debridarr – rebuild
===================
Flow:
  1. Startup → scan Sonarr & Radarr → build library, create empty placeholder files for known media.
  2. Tautulli webhook fires when a user presses Play on a placeholder.
  3. Handler searches Sonarr/Radarr for the real file path on the FUSE mount.
  4. Symlink is created: placeholder path → real FUSE file.
  5. Sonarr/Radarr are notified (rescan) so they see the real file.
  6. After 30 days the symlink expires: symlink reverts to empty placeholder,
     Sonarr/Radarr are told the file is gone (manual unmonitor / rescan).
"""

import os, sqlite3, uuid, shutil, httpx, logging, json
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional, Literal, Any

from fastapi import FastAPI, HTTPException, Request, Header, Depends, BackgroundTasks
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel, Field

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s – %(message)s")
log = logging.getLogger("debridarr")

# ── Env config ────────────────────────────────────────────────────────────────
DB_PATH           = os.getenv("DB_PATH",          "/data/debridarr.db")
STREAMS_PATH      = Path(os.getenv("STREAMS_PATH", "/streams"))
FUSE_MOUNT_PATH   = Path(os.getenv("FUSE_MOUNT_PATH", "/mnt/debrid"))
SYMLINK_TTL_DAYS  = int(os.getenv("SYMLINK_TTL_DAYS", "30"))
PLACEHOLDER_EXT   = os.getenv("PLACEHOLDER_EXT", ".mp4")          # must be mp4 for Tautulli to trigger play
API_KEY           = os.getenv("API_KEY", "").strip()

SONARR_URL        = os.getenv("SONARR_URL", "").rstrip("/")
SONARR_API_KEY    = os.getenv("SONARR_API_KEY", "")
RADARR_URL        = os.getenv("RADARR_URL", "").rstrip("/")
RADARR_API_KEY    = os.getenv("RADARR_API_KEY", "")

TAUTULLI_URL      = os.getenv("TAUTULLI_URL", "").rstrip("/")
TAUTULLI_API_KEY  = os.getenv("TAUTULLI_API_KEY", "")

# ── DB helpers ────────────────────────────────────────────────────────────────
def get_conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    return c

def init_db():
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    STREAMS_PATH.mkdir(parents=True, exist_ok=True)
    FUSE_MOUNT_PATH.mkdir(parents=True, exist_ok=True)
    with get_conn() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS settings (
          key   TEXT PRIMARY KEY,
          value TEXT NOT NULL
        );

        -- Library: every known title from Sonarr/Radarr
        CREATE TABLE IF NOT EXISTS library (
          id            TEXT PRIMARY KEY,
          arr           TEXT NOT NULL,          -- 'sonarr' | 'radarr'
          arr_id        INTEGER NOT NULL,
          media_type    TEXT NOT NULL,           -- 'movie' | 'episode'
          title         TEXT NOT NULL,
          year          INTEGER,
          season        INTEGER,
          episode       INTEGER,
          placeholder   TEXT NOT NULL,          -- empty .mp4 file path
          synced_at     TEXT NOT NULL,
          UNIQUE(arr, arr_id, season, episode)
        );
        CREATE INDEX IF NOT EXISTS idx_lib_arr  ON library(arr, arr_id);

        -- Active streams: placeholder has been replaced by a real symlink
        CREATE TABLE IF NOT EXISTS streams (
          id              TEXT PRIMARY KEY,
          library_id      TEXT REFERENCES library(id),
          arr             TEXT NOT NULL,
          arr_id          INTEGER,
          media_type      TEXT NOT NULL,
          title           TEXT NOT NULL,
          year            INTEGER,
          season          INTEGER,
          episode         INTEGER,
          source_path     TEXT NOT NULL,        -- real file on FUSE
          symlink_path    TEXT NOT NULL,        -- path of the symlink (==placeholder)
          created_at      TEXT NOT NULL,
          expires_at      TEXT NOT NULL,
          last_seen_at    TEXT NOT NULL,
          status          TEXT NOT NULL DEFAULT 'active'
        );
        CREATE INDEX IF NOT EXISTS idx_streams_expires ON streams(expires_at);
        CREATE INDEX IF NOT EXISTS idx_streams_status  ON streams(status);
        """)

        defaults = {
            "streams_path":    str(STREAMS_PATH),
            "fuse_mount_path": str(FUSE_MOUNT_PATH),
            "symlink_ttl_days": str(SYMLINK_TTL_DAYS),
            "placeholder_ext": PLACEHOLDER_EXT,
            "sonarr_url":      SONARR_URL,
            "sonarr_api_key":  SONARR_API_KEY,
            "radarr_url":      RADARR_URL,
            "radarr_api_key":  RADARR_API_KEY,
            "tautulli_url":    TAUTULLI_URL,
            "tautulli_api_key": TAUTULLI_API_KEY,
        }
        for k, v in defaults.items():
            db.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v))

# ── Utility ───────────────────────────────────────────────────────────────────
def now_utc() -> datetime:
    return datetime.now(timezone.utc)

def iso(dt: datetime) -> str:
    return dt.isoformat()

def from_iso(s: str) -> datetime:
    return datetime.fromisoformat(s.replace("Z", "+00:00"))

def safe(value: str) -> str:
    keep = "".join(c if c.isalnum() or c in " ._-()[]" else " " for c in (value or "").strip())
    return " ".join(keep.split()) or "Unknown"

def get_setting(db, key: str, fallback: str = "") -> str:
    row = db.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row else fallback

# ── ARR HTTP helpers ──────────────────────────────────────────────────────────
def arr_headers(api_key: str) -> dict:
    return {"X-Api-Key": api_key, "Accept": "application/json"}

def sonarr_get(path: str, params: dict | None = None):
    url = SONARR_URL or get_setting(get_conn(), "sonarr_url")
    key = SONARR_API_KEY or get_setting(get_conn(), "sonarr_api_key")
    if not url or not key:
        return None
    try:
        r = httpx.get(f"{url}/api/v3{path}", headers=arr_headers(key), params=params, timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.warning("Sonarr GET %s failed: %s", path, e)
        return None

def radarr_get(path: str, params: dict | None = None):
    url = RADARR_URL or get_setting(get_conn(), "radarr_url")
    key = RADARR_API_KEY or get_setting(get_conn(), "radarr_api_key")
    if not url or not key:
        return None
    try:
        r = httpx.get(f"{url}/api/v3{path}", headers=arr_headers(key), params=params, timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.warning("Radarr GET %s failed: %s", path, e)
        return None

def sonarr_post(path: str, payload: dict):
    url = SONARR_URL or get_setting(get_conn(), "sonarr_url")
    key = SONARR_API_KEY or get_setting(get_conn(), "sonarr_api_key")
    if not url or not key:
        return None
    try:
        r = httpx.post(f"{url}/api/v3{path}", headers=arr_headers(key), json=payload, timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.warning("Sonarr POST %s failed: %s", path, e)
        return None

def radarr_post(path: str, payload: dict):
    url = RADARR_URL or get_setting(get_conn(), "radarr_url")
    key = RADARR_API_KEY or get_setting(get_conn(), "radarr_api_key")
    if not url or not key:
        return None
    try:
        r = httpx.post(f"{url}/api/v3{path}", headers=arr_headers(key), json=payload, timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.warning("Radarr POST %s failed: %s", path, e)
        return None

def sonarr_put(path: str, payload: dict):
    url = SONARR_URL or get_setting(get_conn(), "sonarr_url")
    key = SONARR_API_KEY or get_setting(get_conn(), "sonarr_api_key")
    if not url or not key:
        return None
    try:
        r = httpx.put(f"{url}/api/v3{path}", headers=arr_headers(key), json=payload, timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.warning("Sonarr PUT %s failed: %s", path, e)
        return None

def radarr_put(path: str, payload: dict):
    url = RADARR_URL or get_setting(get_conn(), "radarr_url")
    key = RADARR_API_KEY or get_setting(get_conn(), "radarr_api_key")
    if not url or not key:
        return None
    try:
        r = httpx.put(f"{url}/api/v3{path}", headers=arr_headers(key), json=payload, timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.warning("Radarr PUT %s failed: %s", path, e)
        return None

# ── Placeholder helpers ───────────────────────────────────────────────────────
def placeholder_path(arr: str, media_type: str, title: str, year: int | None,
                     season: int | None, episode: int | None) -> Path:
    t = safe(title)
    ext = PLACEHOLDER_EXT
    if media_type == "movie":
        folder = f"{t} ({year})" if year else t
        return STREAMS_PATH / "radarr" / folder / f"{folder}{ext}"
    s = int(season or 0)
    e = int(episode or 0)
    return STREAMS_PATH / "sonarr" / t / f"Season {s:02d}" / f"{t} - S{s:02d}E{e:02d}{ext}"

def ensure_placeholder(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists() and not path.is_symlink():
        path.write_bytes(b"")    # 0-byte mp4 → Plex/Tautulli will fire playback webhook

def revert_to_placeholder(path: Path):
    """Remove symlink and restore the empty placeholder file."""
    try:
        if path.is_symlink() or path.exists():
            path.unlink()
    except Exception:
        pass
    ensure_placeholder(path)

# ── NFO generation ────────────────────────────────────────────────────────────
# Plex NFO Agent (PMS ≥ 1.43.1) reads Kodi-format XML alongside the media file.
# By writing these, Plex skips the online metadata lookup and matches instantly,
# which dramatically speeds up library scans for placeholder files.
#
# File layout expected by Plex NFO Agent:
#   Movies  → <movie folder>/movie.nfo          (or <Filename>.nfo)
#   TV      → <show folder>/tvshow.nfo           (series-level, written once per show)
#             <season folder>/<Episode filename>.nfo  (episode-level)

def _xml_escape(s: str) -> str:
    return (str(s)
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;"))

def _write_nfo(path: Path, content: str):
    """Write NFO only if content has changed, to avoid Plex re-scanning unchanged files."""
    if path.exists():
        try:
            if path.read_text(encoding="utf-8").strip() == content.strip():
                return   # unchanged – don't touch mtime
        except Exception:
            pass
    try:
        path.write_text(content, encoding="utf-8")
    except Exception as exc:
        log.debug("NFO write failed %s: %s", path, exc)

def write_movie_nfo(movie_folder: Path, title: str, year: int | None,
                    tmdb_id: int | None, imdb_id: str | None,
                    plot: str = "", premiered: str = "", studio: str = "",
                    genres: list[str] | None = None):
    """Write movie.nfo in Kodi/Plex NFO Agent format."""
    uid_block = ""
    if tmdb_id:
        uid_block += f'  <uniqueid type="tmdb" default="true">{tmdb_id}</uniqueid>\n'
    if imdb_id:
        uid_block += f'  <uniqueid type="imdb">{_xml_escape(imdb_id)}</uniqueid>\n'
    genre_block = "".join(f"  <genre>{_xml_escape(g)}</genre>\n" for g in (genres or []))

    nfo = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>\n'
        "<movie>\n"
        f"  <title>{_xml_escape(title)}</title>\n"
        f"  <year>{year or ''}</year>\n"
        f"  <plot>{_xml_escape(plot)}</plot>\n"
        f"  <premiered>{_xml_escape(premiered)}</premiered>\n"
        f"  <studio>{_xml_escape(studio)}</studio>\n"
        + uid_block
        + genre_block
        + "</movie>\n"
    )
    _write_nfo(movie_folder / "movie.nfo", nfo)

def write_tvshow_nfo(show_folder: Path, title: str, year: int | None,
                     tvdb_id: int | None, tmdb_id: int | None, imdb_id: str | None,
                     plot: str = "", premiered: str = "", status: str = "",
                     studio: str = "", genres: list[str] | None = None):
    """Write tvshow.nfo – one per show folder, Plex reads it for series-level identity."""
    # Plex NFO Series agent prefers tmdb for TV, but accepts tvdb too.
    uid_block = ""
    if tmdb_id:
        uid_block += f'  <uniqueid type="tmdb" default="true">{tmdb_id}</uniqueid>\n'
    if tvdb_id:
        uid_block += f'  <uniqueid type="tvdb">{tvdb_id}</uniqueid>\n'
    if imdb_id:
        uid_block += f'  <uniqueid type="imdb">{_xml_escape(imdb_id)}</uniqueid>\n'
    genre_block = "".join(f"  <genre>{_xml_escape(g)}</genre>\n" for g in (genres or []))

    nfo = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>\n'
        "<tvshow>\n"
        f"  <title>{_xml_escape(title)}</title>\n"
        f"  <year>{year or ''}</year>\n"
        f"  <plot>{_xml_escape(plot)}</plot>\n"
        f"  <premiered>{_xml_escape(premiered)}</premiered>\n"
        f"  <status>{_xml_escape(status)}</status>\n"
        f"  <studio>{_xml_escape(studio)}</studio>\n"
        + uid_block
        + genre_block
        + "</tvshow>\n"
    )
    _write_nfo(show_folder / "tvshow.nfo", nfo)

def write_episode_nfo(episode_file: Path, title: str, show_title: str,
                      season: int, episode: int,
                      tvdb_ep_id: int | None, tmdb_ep_id: int | None,
                      plot: str = "", aired: str = ""):
    """Write <EpisodeFilename>.nfo alongside the placeholder for episode-level identity."""
    uid_block = ""
    if tvdb_ep_id:
        uid_block += f'  <uniqueid type="tvdb" default="true">{tvdb_ep_id}</uniqueid>\n'
    if tmdb_ep_id:
        uid_block += f'  <uniqueid type="tmdb">{tmdb_ep_id}</uniqueid>\n'

    nfo = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>\n'
        "<episodedetails>\n"
        f"  <title>{_xml_escape(title)}</title>\n"
        f"  <showtitle>{_xml_escape(show_title)}</showtitle>\n"
        f"  <season>{season}</season>\n"
        f"  <episode>{episode}</episode>\n"
        f"  <plot>{_xml_escape(plot)}</plot>\n"
        f"  <aired>{_xml_escape(aired)}</aired>\n"
        + uid_block
        + "</episodedetails>\n"
    )
    # NFO filename must match the video filename exactly (same stem, .nfo extension)
    nfo_path = episode_file.with_suffix(".nfo")
    _write_nfo(nfo_path, nfo)

# ── Library sync ──────────────────────────────────────────────────────────────
def sync_sonarr(db):
    series_list = sonarr_get("/series")
    if not series_list:
        return 0
    count = 0
    for series in series_list:
        sid       = series.get("id")
        title     = series.get("title", "")
        year      = series.get("year")
        plot      = series.get("overview", "")
        status    = series.get("status", "")
        studio    = (series.get("network") or "")
        genres    = series.get("genres", [])
        premiered = (series.get("firstAired") or "")[:10]
        tvdb_id   = series.get("tvdbId")
        imdb_id   = series.get("imdbId")
        tmdb_id   = series.get("tmdbId")

        # Write tvshow.nfo once per show folder (idempotent, only rewrites if changed)
        show_folder = STREAMS_PATH / "sonarr" / safe(title)
        show_folder.mkdir(parents=True, exist_ok=True)
        write_tvshow_nfo(show_folder, title, year, tvdb_id, tmdb_id, imdb_id,
                         plot=plot, premiered=premiered, status=status,
                         studio=studio, genres=genres)

        episodes = sonarr_get("/episode", {"seriesId": sid}) or []
        for ep in episodes:
            if not ep.get("monitored"):
                continue
            s        = ep.get("seasonNumber")
            e        = ep.get("episodeNumber")
            ep_title = ep.get("title", "")
            ep_plot  = ep.get("overview", "")
            ep_aired = (ep.get("airDate") or "")[:10]
            tvdb_ep  = ep.get("tvdbId")
            tmdb_ep  = ep.get("tmdbId")

            lib_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"sonarr:{sid}:{s}:{e}"))
            ph = placeholder_path("sonarr", "episode", title, year, s, e)
            ensure_placeholder(ph)
            write_episode_nfo(ph, ep_title, title, s, e,
                              tvdb_ep_id=tvdb_ep, tmdb_ep_id=tmdb_ep,
                              plot=ep_plot, aired=ep_aired)

            db.execute("""
                INSERT INTO library(id,arr,arr_id,media_type,title,year,season,episode,placeholder,synced_at)
                VALUES(?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(arr,arr_id,season,episode) DO UPDATE SET
                  title=excluded.title, year=excluded.year,
                  placeholder=excluded.placeholder, synced_at=excluded.synced_at
            """, (lib_id, "sonarr", sid, "episode", title, year, s, e, str(ph), iso(now_utc())))
            count += 1
    return count

def sync_radarr(db):
    movies = radarr_get("/movie")
    if not movies:
        return 0
    count = 0
    for movie in movies:
        mid       = movie.get("id")
        title     = movie.get("title", "")
        year      = movie.get("year")
        plot      = movie.get("overview", "")
        premiered = (movie.get("inCinemas") or movie.get("digitalRelease") or "")[:10]
        studio    = (movie.get("studio") or "")
        genres    = movie.get("genres", [])
        tmdb_id   = movie.get("tmdbId")
        imdb_id   = movie.get("imdbId")

        lib_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"radarr:{mid}"))
        ph = placeholder_path("radarr", "movie", title, year, None, None)
        ensure_placeholder(ph)
        write_movie_nfo(ph.parent, title, year, tmdb_id, imdb_id,
                        plot=plot, premiered=premiered, studio=studio, genres=genres)

        db.execute("""
            INSERT INTO library(id,arr,arr_id,media_type,title,year,season,episode,placeholder,synced_at)
            VALUES(?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(arr,arr_id,season,episode) DO UPDATE SET
              title=excluded.title, year=excluded.year,
              placeholder=excluded.placeholder, synced_at=excluded.synced_at
        """, (lib_id, "radarr", mid, "movie", title, year, None, None, str(ph), iso(now_utc())))
        count += 1
    return count


def full_library_sync():
    with get_conn() as db:
        s = sync_sonarr(db)
        r = sync_radarr(db)
    log.info("Library sync complete – sonarr:%d  radarr:%d", s, r)
    return {"sonarr": s, "radarr": r}

# ── Stream resolution (called on Tautulli play event) ────────────────────────
def find_fuse_file(arr: str, arr_id: int, season: int | None, episode: int | None,
                   title: str) -> Path | None:
    """Walk the FUSE mount to find the real video file."""
    # First: ask the arr for the file path it knows about
    if arr == "sonarr":
        ep_data = sonarr_get("/episode", {"seriesId": arr_id})
        if ep_data:
            for ep in ep_data:
                if ep.get("seasonNumber") == season and ep.get("episodeNumber") == episode:
                    ef = ep.get("episodeFile", {})
                    rel = ef.get("relativePath") or ""
                    series_path = sonarr_get(f"/series/{arr_id}") or {}
                    root = series_path.get("path", "")
                    if root and rel:
                        p = Path(root) / rel
                        if p.exists():
                            return p
        # Fallback: walk FUSE
        t = safe(title)
        candidates = list(FUSE_MOUNT_PATH.rglob(f"*{t}*S{int(season or 0):02d}E{int(episode or 0):02d}*"))
        candidates = [c for c in candidates if c.suffix.lower() in (".mp4", ".mkv", ".avi")]
        return candidates[0] if candidates else None

    elif arr == "radarr":
        movie_data = radarr_get(f"/movie/{arr_id}")
        if movie_data:
            mf = movie_data.get("movieFile", {})
            rel = mf.get("relativePath", "")
            root = movie_data.get("path", "")
            if root and rel:
                p = Path(root) / rel
                if p.exists():
                    return p
        # Fallback: walk FUSE
        t = safe(title)
        candidates = list(FUSE_MOUNT_PATH.rglob(f"*{t}*"))
        candidates = [c for c in candidates if c.suffix.lower() in (".mp4", ".mkv", ".avi")]
        return candidates[0] if candidates else None

    return None

def activate_stream(library_id: str) -> dict:
    """Replace placeholder with real symlink. Called on play event."""
    with get_conn() as db:
        lib = db.execute("SELECT * FROM library WHERE id=?", (library_id,)).fetchone()
        if not lib:
            return {"ok": False, "error": "Library item not found"}

        # Already have an active stream?
        existing = db.execute(
            "SELECT * FROM streams WHERE library_id=? AND status='active'", (library_id,)
        ).fetchone()
        if existing:
            # Bump last_seen
            db.execute("UPDATE streams SET last_seen_at=? WHERE id=?",
                       (iso(now_utc()), existing["id"]))
            return {"ok": True, "already_active": True, "stream_id": existing["id"]}

        ph = Path(lib["placeholder"])
        real = find_fuse_file(lib["arr"], lib["arr_id"], lib["season"], lib["episode"], lib["title"])
        if not real:
            return {"ok": False, "error": "Real file not found on FUSE mount"}

        # Swap placeholder → symlink
        try:
            if ph.exists() and not ph.is_symlink():
                ph.unlink()
            elif ph.is_symlink():
                ph.unlink()
            os.symlink(str(real), str(ph))
        except OSError as exc:
            return {"ok": False, "error": f"Symlink failed: {exc}"}

        ttl = SYMLINK_TTL_DAYS
        stream_id = str(uuid.uuid4())
        now = iso(now_utc())
        expires = iso(now_utc() + timedelta(days=ttl))

        db.execute("""
            INSERT INTO streams(id,library_id,arr,arr_id,media_type,title,year,season,episode,
                                source_path,symlink_path,created_at,expires_at,last_seen_at,status)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (stream_id, library_id, lib["arr"], lib["arr_id"], lib["media_type"],
              lib["title"], lib["year"], lib["season"], lib["episode"],
              str(real), str(ph), now, expires, now, "active"))

    # Notify arr to rescan so it sees the real file
    _notify_arr_rescan(lib["arr"], lib["arr_id"])

    log.info("Stream activated: %s → %s (expires %s)", ph, real, expires)
    return {"ok": True, "stream_id": stream_id, "symlink": str(ph), "source": str(real), "expires_at": expires}

def _notify_arr_rescan(arr: str, arr_id: int):
    if arr == "sonarr":
        sonarr_post("/command", {"name": "RescanSeries", "seriesId": arr_id})
    elif arr == "radarr":
        radarr_post("/command", {"name": "RescanMovie", "movieId": arr_id})

def _notify_arr_unlink(arr: str, arr_id: int, season: int | None, episode: int | None):
    """Tell the arr the file is gone so it can unmonitor / mark missing."""
    if arr == "sonarr":
        sonarr_post("/command", {"name": "RescanSeries", "seriesId": arr_id})
    elif arr == "radarr":
        radarr_post("/command", {"name": "RescanMovie", "movieId": arr_id})

# ── Expiry cleanup ────────────────────────────────────────────────────────────
def cleanup_expired() -> list[str]:
    expired_ids = []
    now = now_utc()
    with get_conn() as db:
        rows = db.execute("SELECT * FROM streams WHERE status='active'").fetchall()
        for row in rows:
            try:
                if from_iso(row["expires_at"]) > now:
                    continue
            except Exception:
                continue

            sym = Path(row["symlink_path"])
            revert_to_placeholder(sym)
            db.execute("UPDATE streams SET status='expired' WHERE id=?", (row["id"],))
            _notify_arr_unlink(row["arr"], row["arr_id"], row["season"], row["episode"])
            expired_ids.append(row["id"])
            log.info("Stream expired and reverted: %s (id=%s)", sym, row["id"])

    return expired_ids

# ── FastAPI app ───────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    cleanup_expired()
    full_library_sync()
    yield

app = FastAPI(title="Debridarr", version="2026.06", lifespan=lifespan)

# ── Auth ──────────────────────────────────────────────────────────────────────
async def require_api_key(
    authorization: Optional[str] = Header(default=None),
    x_api_key: Optional[str]    = Header(default=None),
):
    if not API_KEY:
        return True
    token = (x_api_key or "").strip()
    if authorization and authorization.lower().startswith("bearer "):
        token = authorization.split(" ", 1)[1].strip()
    if token != API_KEY:
        raise HTTPException(401, "Invalid API key")
    return True

# ── Models ────────────────────────────────────────────────────────────────────
class SettingsPatch(BaseModel):
    settings: dict[str, str]

class ManualStreamCreate(BaseModel):
    arr:        Literal["sonarr", "radarr"] = "sonarr"
    media_type: Literal["movie", "episode"] = "episode"
    title:      str
    year:       Optional[int] = None
    season:     Optional[int] = None
    episode:    Optional[int] = None
    source_path: str = Field(..., description="Real file path on FUSE mount")
    ttl_days:   Optional[int] = None

class TautulliWebhook(BaseModel):
    """
    Tautulli sends notification agent payloads.
    We accept either the native Tautulli JSON agent format or a simplified form.
    """
    event:          Optional[str] = None          # 'play', 'watched', etc.
    # Tautulli template fields (set these in the notification agent)
    media_type:     Optional[str] = None          # 'episode' or 'movie'
    file:           Optional[str] = None          # full file path Plex played
    grandparent_title: Optional[str] = None       # show title
    parent_media_index: Optional[int] = None      # season
    media_index:    Optional[int] = None          # episode
    title:          Optional[str] = None          # movie title or episode title
    year:           Optional[int] = None
    extra:          dict[str, Any] = {}

# ── Routes ────────────────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
def home():
    return HTMLResponse(UI)

@app.get("/health")
def health():
    return {
        "ok":               True,
        "version":          app.version,
        "streams_path":     str(STREAMS_PATH),
        "fuse_mount_path":  str(FUSE_MOUNT_PATH),
        "sonarr_connected": bool(SONARR_URL and SONARR_API_KEY),
        "radarr_connected": bool(RADARR_URL and RADARR_API_KEY),
    }

@app.get("/api/settings")
def get_settings(_: bool = Depends(require_api_key)):
    with get_conn() as db:
        return {"settings": {r["key"]: r["value"] for r in db.execute("SELECT key,value FROM settings ORDER BY key")}}

@app.patch("/api/settings")
def patch_settings(patch: SettingsPatch, _: bool = Depends(require_api_key)):
    with get_conn() as db:
        for k, v in patch.settings.items():
            db.execute(
                "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (k, str(v))
            )
    # Update globals if arr credentials changed
    global SONARR_URL, SONARR_API_KEY, RADARR_URL, RADARR_API_KEY
    if "sonarr_url"      in patch.settings: SONARR_URL      = patch.settings["sonarr_url"].rstrip("/")
    if "sonarr_api_key"  in patch.settings: SONARR_API_KEY  = patch.settings["sonarr_api_key"]
    if "radarr_url"      in patch.settings: RADARR_URL      = patch.settings["radarr_url"].rstrip("/")
    if "radarr_api_key"  in patch.settings: RADARR_API_KEY  = patch.settings["radarr_api_key"]
    return get_settings(True)

# ── FUSE ──────────────────────────────────────────────────────────────────────
@app.get("/api/fuse")
def fuse_status(_: bool = Depends(require_api_key)):
    try:
        has_files = FUSE_MOUNT_PATH.exists() and any(FUSE_MOUNT_PATH.iterdir())
    except Exception:
        has_files = False
    return {
        "mount_path": str(FUSE_MOUNT_PATH),
        "exists":     FUSE_MOUNT_PATH.exists(),
        "has_files":  has_files,
    }

# ── Library ───────────────────────────────────────────────────────────────────
@app.get("/api/library")
def list_library(arr: str = "all", _: bool = Depends(require_api_key)):
    with get_conn() as db:
        if arr == "all":
            rows = db.execute("SELECT * FROM library ORDER BY arr, title, season, episode").fetchall()
        else:
            rows = db.execute("SELECT * FROM library WHERE arr=? ORDER BY title,season,episode", (arr,)).fetchall()
        return {"library": [dict(r) for r in rows]}

@app.post("/api/library/sync")
def trigger_sync(background_tasks: BackgroundTasks, _: bool = Depends(require_api_key)):
    background_tasks.add_task(full_library_sync)
    return {"ok": True, "message": "Library sync started in background"}

# ── Streams ───────────────────────────────────────────────────────────────────
@app.get("/api/streams")
def list_streams(status: str = "active", _: bool = Depends(require_api_key)):
    cleanup_expired()
    with get_conn() as db:
        if status == "all":
            rows = db.execute("SELECT * FROM streams ORDER BY created_at DESC").fetchall()
        else:
            rows = db.execute("SELECT * FROM streams WHERE status=? ORDER BY created_at DESC", (status,)).fetchall()
        return {"streams": [dict(r) for r in rows]}

@app.post("/api/streams/manual")
def create_manual_stream(item: ManualStreamCreate, _: bool = Depends(require_api_key)):
    """Manually activate a stream without a Tautulli event."""
    source = Path(item.source_path)
    if not source.exists():
        raise HTTPException(400, f"Source path does not exist: {source}")

    ph = placeholder_path(item.arr, item.media_type, item.title, item.year, item.season, item.episode)
    ensure_placeholder(ph)

    try:
        if ph.is_symlink() or (ph.exists() and not ph.is_symlink()):
            ph.unlink()
        os.symlink(str(source), str(ph))
    except OSError as exc:
        raise HTTPException(500, f"Symlink failed: {exc}")

    ttl = item.ttl_days or SYMLINK_TTL_DAYS
    stream_id = str(uuid.uuid4())
    now = iso(now_utc())
    expires = iso(now_utc() + timedelta(days=ttl))

    with get_conn() as db:
        db.execute("""
            INSERT INTO streams(id,library_id,arr,arr_id,media_type,title,year,season,episode,
                                source_path,symlink_path,created_at,expires_at,last_seen_at,status)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (stream_id, None, item.arr, None, item.media_type,
              item.title, item.year, item.season, item.episode,
              str(source), str(ph), now, expires, now, "active"))

    return {"ok": True, "stream_id": stream_id, "symlink": str(ph), "expires_at": expires}

@app.delete("/api/streams/{stream_id}")
def delete_stream(stream_id: str, _: bool = Depends(require_api_key)):
    with get_conn() as db:
        row = db.execute("SELECT * FROM streams WHERE id=?", (stream_id,)).fetchone()
        if not row:
            raise HTTPException(404, "Stream not found")
        revert_to_placeholder(Path(row["symlink_path"]))
        db.execute("UPDATE streams SET status='removed' WHERE id=?", (stream_id,))
        _notify_arr_unlink(row["arr"], row["arr_id"], row["season"], row["episode"])
    return {"ok": True, "removed": stream_id}

@app.post("/api/streams/cleanup")
def run_cleanup(_: bool = Depends(require_api_key)):
    return {"ok": True, "expired_removed": cleanup_expired()}

# ── Library-driven activation ─────────────────────────────────────────────────
@app.post("/api/library/{library_id}/activate")
def activate(library_id: str, _: bool = Depends(require_api_key)):
    result = activate_stream(library_id)
    if not result.get("ok"):
        raise HTTPException(400, result.get("error", "Activation failed"))
    return result

# ── Tautulli webhook ──────────────────────────────────────────────────────────
@app.post("/webhook/tautulli")
async def tautulli_webhook(request: Request):
    """
    Configure Tautulli → Notification Agents → Script/Webhook.
    Trigger on: Playback Start.
    JSON payload (Custom Body) example:
      {
        "event":              "{action}",
        "media_type":         "{media_type}",
        "file":               "{file}",
        "grandparent_title":  "{grandparent_title}",
        "parent_media_index": {parent_media_index},
        "media_index":        {media_index},
        "title":              "{title}",
        "year":               {year}
      }
    """
    try:
        body = await request.json()
    except Exception:
        raise HTTPException(400, "Invalid JSON body")

    event      = body.get("event", "")
    media_type = body.get("media_type", "")
    file_path  = body.get("file", "")

    # Only act on play events
    if event not in ("play", "playback.start", ""):
        return {"ok": True, "skipped": True, "reason": f"event={event}"}

    # Find the library item by matching the placeholder path
    played = Path(file_path) if file_path else None

    with get_conn() as db:
        lib_row = None

        if played:
            # Direct match on placeholder path
            lib_row = db.execute(
                "SELECT * FROM library WHERE placeholder=?", (str(played),)
            ).fetchone()

        if not lib_row:
            # Match by title + season + episode
            series_title = body.get("grandparent_title") or body.get("title", "")
            season  = body.get("parent_media_index")
            episode = body.get("media_index")
            year    = body.get("year")

            if media_type == "episode" and series_title and season is not None and episode is not None:
                lib_row = db.execute(
                    "SELECT * FROM library WHERE media_type='episode' AND title=? AND season=? AND episode=?",
                    (series_title, int(season), int(episode))
                ).fetchone()
            elif media_type == "movie":
                movie_title = body.get("title", "")
                lib_row = db.execute(
                    "SELECT * FROM library WHERE media_type='movie' AND title=?",
                    (movie_title,)
                ).fetchone()

    if not lib_row:
        log.warning("Tautulli webhook: no library match for file=%s title=%s", file_path, body.get("title"))
        return {"ok": False, "error": "No library match found"}

    result = activate_stream(lib_row["id"])
    log.info("Tautulli play event → activate: %s", result)
    return result

# ── Sonarr / Radarr passthrough status ───────────────────────────────────────
@app.get("/api/arr/sonarr/status")
def sonarr_status(_: bool = Depends(require_api_key)):
    data = sonarr_get("/system/status")
    return {"connected": data is not None, "status": data}

@app.get("/api/arr/radarr/status")
def radarr_status(_: bool = Depends(require_api_key)):
    data = radarr_get("/system/status")
    return {"connected": data is not None, "status": data}

# ── UI ────────────────────────────────────────────────────────────────────────
UI = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Debridarr</title>
<style>
  :root {
    --bg:       #0d1117;
    --surface:  #161b22;
    --border:   #30363d;
    --accent:   #58a6ff;
    --green:    #3fb950;
    --orange:   #d29922;
    --red:      #f85149;
    --text:     #c9d1d9;
    --subtext:  #8b949e;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: var(--bg); color: var(--text); font-family: system-ui, -apple-system, sans-serif; font-size: 14px; }
  nav { background: var(--surface); border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 6px; padding: 12px 20px; position: sticky; top: 0; z-index: 10; }
  nav h1 { font-size: 16px; font-weight: 700; color: var(--accent); margin-right: 16px; }
  .tab-btn { background: transparent; color: var(--subtext); border: 1px solid transparent; border-radius: 6px; padding: 6px 14px; cursor: pointer; font-size: 13px; transition: .15s; }
  .tab-btn:hover { border-color: var(--border); color: var(--text); }
  .tab-btn.active { background: var(--accent); color: #fff; border-color: var(--accent); }
  .tab { display: none; padding: 20px; max-width: 1200px; margin: 0 auto; }
  .tab.active { display: block; }
  h2 { font-size: 18px; margin-bottom: 16px; }
  h3 { font-size: 14px; color: var(--subtext); margin-bottom: 10px; text-transform: uppercase; letter-spacing: .05em; }
  .row { display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 16px; }
  .card { background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 16px; flex: 1 1 300px; }
  .badge { display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 12px; font-weight: 600; }
  .badge-green  { background: #1a3a22; color: var(--green); }
  .badge-orange { background: #2d2200; color: var(--orange); }
  .badge-red    { background: #2d0f0f; color: var(--red); }
  .badge-blue   { background: #0d2547; color: var(--accent); }
  .badge-gray   { background: var(--border); color: var(--subtext); }
  table { width: 100%; border-collapse: collapse; }
  th { text-align: left; padding: 8px 10px; color: var(--subtext); font-weight: 600; font-size: 12px; border-bottom: 1px solid var(--border); }
  td { padding: 8px 10px; border-bottom: 1px solid var(--border); font-size: 13px; vertical-align: top; }
  tr:last-child td { border-bottom: none; }
  tr:hover td { background: rgba(255,255,255,.02); }
  .mono { font-family: ui-monospace, monospace; font-size: 12px; color: var(--subtext); word-break: break-all; }
  button { background: var(--accent); color: #fff; border: none; border-radius: 6px; padding: 7px 14px; cursor: pointer; font-size: 13px; transition: opacity .15s; }
  button:hover { opacity: .85; }
  button.danger { background: var(--red); }
  button.secondary { background: var(--border); color: var(--text); }
  input, select { background: var(--bg); color: var(--text); border: 1px solid var(--border); border-radius: 6px; padding: 7px 10px; font-size: 13px; width: 100%; margin-bottom: 8px; }
  label { font-size: 12px; color: var(--subtext); display: block; margin-bottom: 3px; }
  .sep { margin: 6px 0; }
  .status-dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 6px; }
  .dot-green  { background: var(--green); }
  .dot-red    { background: var(--red); }
  .dot-gray   { background: var(--subtext); }
  .empty { color: var(--subtext); text-align: center; padding: 30px; }
  .top-row { display: flex; align-items: center; gap: 10px; margin-bottom: 16px; flex-wrap: wrap; }
</style>
</head>
<body>
<nav>
  <h1>⚡ Debridarr</h1>
  <button class="tab-btn active" onclick="show('streams')">Streams</button>
  <button class="tab-btn" onclick="show('library')">Library</button>
  <button class="tab-btn" onclick="show('connections')">Connections</button>
  <button class="tab-btn" onclick="show('fuse')">FUSE</button>
</nav>

<!-- STREAMS TAB -->
<section id="streams" class="tab active">
  <div class="top-row">
    <h2 style="margin:0">Active Streams</h2>
    <button onclick="loadStreams('active')">Refresh</button>
    <button class="secondary" onclick="loadStreams('all')">Show All</button>
    <button class="danger" onclick="runCleanup()">Run Expiry Cleanup</button>
  </div>
  <div class="row">
    <div class="card" style="flex:1 1 100%">
      <div id="streamsTable"><div class="empty">Loading…</div></div>
    </div>
  </div>
</section>

<!-- LIBRARY TAB -->
<section id="library" class="tab">
  <div class="top-row">
    <h2 style="margin:0">Library</h2>
    <select id="libFilter" onchange="loadLibrary()" style="width:auto">
      <option value="all">All</option>
      <option value="sonarr">Sonarr</option>
      <option value="radarr">Radarr</option>
    </select>
    <button onclick="loadLibrary()">Refresh</button>
    <button onclick="triggerSync()">Sync Now</button>
  </div>
  <div class="card">
    <div id="libraryTable"><div class="empty">Loading…</div></div>
  </div>
</section>

<!-- CONNECTIONS TAB -->
<section id="connections" class="tab">
  <h2>Connections</h2>
  <div class="row">

    <div class="card">
      <h3>Sonarr</h3>
      <div id="sonarrStatus" class="sep"></div>
      <label>URL</label><input id="sonarrUrl" placeholder="http://sonarr:8989">
      <label>API Key</label><input id="sonarrKey" type="password" placeholder="••••••••">
      <button onclick="saveArr('sonarr')">Save & Test</button>
    </div>

    <div class="card">
      <h3>Radarr</h3>
      <div id="radarrStatus" class="sep"></div>
      <label>URL</label><input id="radarrUrl" placeholder="http://radarr:7878">
      <label>API Key</label><input id="radarrKey" type="password" placeholder="••••••••">
      <button onclick="saveArr('radarr')">Save & Test</button>
    </div>

    <div class="card">
      <h3>Tautulli</h3>
      <p style="color:var(--subtext);font-size:13px;margin-bottom:12px">
        In Tautulli → Notification Agents → Webhook, set the URL to:<br>
        <span class="mono" id="webhookUrl"></span><br><br>
        Trigger: <strong>Playback Start</strong>.<br>
        JSON body template is in the README.
      </p>
      <label>Tautulli URL (optional, for future use)</label>
      <input id="tautulliUrl" placeholder="http://tautulli:8181">
      <button onclick="saveTautulli()">Save</button>
    </div>

  </div>

  <div class="row">
    <div class="card" style="flex:1 1 100%">
      <h3>Stream TTL</h3>
      <label>Days before symlink expires and reverts to placeholder</label>
      <input id="ttlDays" type="number" min="1" max="365" value="30" style="width:120px">
      <div class="sep"></div>
      <button onclick="saveTtl()">Save TTL</button>
    </div>
  </div>
</section>

<!-- FUSE TAB -->
<section id="fuse" class="tab">
  <h2>FUSE Mount</h2>
  <div class="card" style="max-width:500px">
    <div id="fuseStatus"><div class="empty">Loading…</div></div>
    <div class="sep"></div>
    <button onclick="loadFuse()">Refresh</button>
  </div>
</section>

<script>
const API = '';

function show(id) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  document.querySelectorAll('.tab-btn').forEach(b => {
    if (b.textContent.toLowerCase().includes(id.slice(0,4))) b.classList.add('active');
  });
  if (id==='streams') loadStreams('active');
  if (id==='library') loadLibrary();
  if (id==='connections') loadConnections();
  if (id==='fuse') loadFuse();
}

async function api(url, opts) {
  try {
    const r = await fetch(API + url, opts || {});
    return await r.json();
  } catch(e) { return {error: String(e)}; }
}

function badge(status) {
  const map = {active:'badge-green',expired:'badge-orange',removed:'badge-red'};
  return `<span class="badge ${map[status]||'badge-gray'}">${status}</span>`;
}

function daysLeft(exp) {
  const d = (new Date(exp) - Date.now()) / 86400000;
  if (d < 0) return '<span style="color:var(--red)">expired</span>';
  if (d < 3) return `<span style="color:var(--orange)">${d.toFixed(1)}d</span>`;
  return `<span style="color:var(--green)">${Math.ceil(d)}d</span>`;
}

async function loadStreams(status='active') {
  const data = await api(`/api/streams?status=${status}`);
  const el = document.getElementById('streamsTable');
  if (!data.streams || !data.streams.length) { el.innerHTML='<div class="empty">No streams</div>'; return; }
  el.innerHTML = `<table>
    <tr><th>Title</th><th>Type</th><th>ARR</th><th>Status</th><th>Expires</th><th>Symlink</th><th></th></tr>
    ${data.streams.map(s=>`<tr>
      <td><strong>${esc(s.title)}</strong>${s.season!=null?' S'+pad(s.season)+'E'+pad(s.episode):''}</td>
      <td>${s.media_type}</td>
      <td><span class="badge badge-blue">${s.arr}</span></td>
      <td>${badge(s.status)}</td>
      <td>${s.status==='active'?daysLeft(s.expires_at):'-'}</td>
      <td class="mono">${esc(s.symlink_path)}</td>
      <td>${s.status==='active'?`<button class="danger" onclick="deleteStream('${s.id}')">Expire</button>`:''}</td>
    </tr>`).join('')}
  </table>`;
}

async function runCleanup() {
  const data = await api('/api/streams/cleanup', {method:'POST'});
  alert(`Cleanup done. Expired: ${(data.expired_removed||[]).length}`);
  loadStreams('active');
}

async function deleteStream(id) {
  if (!confirm('Expire this stream and revert to placeholder?')) return;
  await api(`/api/streams/${id}`, {method:'DELETE'});
  loadStreams('active');
}

async function loadLibrary() {
  const filter = document.getElementById('libFilter').value;
  const data = await api(`/api/library?arr=${filter}`);
  const el = document.getElementById('libraryTable');
  if (!data.library || !data.library.length) { el.innerHTML='<div class="empty">No library items. Try syncing.</div>'; return; }
  el.innerHTML = `<table>
    <tr><th>Title</th><th>Year</th><th>Type</th><th>ARR</th><th>Season</th><th>Episode</th><th>Placeholder</th><th></th></tr>
    ${data.library.map(l=>`<tr>
      <td><strong>${esc(l.title)}</strong></td>
      <td>${l.year||'-'}</td>
      <td>${l.media_type}</td>
      <td><span class="badge badge-blue">${l.arr}</span></td>
      <td>${l.season!=null?'S'+pad(l.season):'-'}</td>
      <td>${l.episode!=null?'E'+pad(l.episode):'-'}</td>
      <td class="mono">${esc(l.placeholder)}</td>
      <td><button onclick="activateItem('${l.id}')">Activate</button></td>
    </tr>`).join('')}
  </table>`;
}

async function triggerSync() {
  await api('/api/library/sync', {method:'POST'});
  setTimeout(loadLibrary, 2000);
}

async function activateItem(id) {
  const data = await api(`/api/library/${id}/activate`, {method:'POST'});
  if (data.ok) { alert('Stream activated! Symlink: ' + data.symlink); loadStreams('active'); }
  else alert('Failed: ' + (data.error||data.detail));
}

async function loadConnections() {
  document.getElementById('webhookUrl').textContent = location.origin + '/webhook/tautulli';
  const data = await api('/api/settings');
  const s = data.settings || {};
  document.getElementById('sonarrUrl').value  = s.sonarr_url  || '';
  document.getElementById('sonarrKey').value  = s.sonarr_api_key || '';
  document.getElementById('radarrUrl').value  = s.radarr_url  || '';
  document.getElementById('radarrKey').value  = s.radarr_api_key || '';
  document.getElementById('tautulliUrl').value = s.tautulli_url || '';
  document.getElementById('ttlDays').value    = s.symlink_ttl_days || 30;
  testArr('sonarr');
  testArr('radarr');
}

async function saveArr(arr) {
  const url = document.getElementById(arr+'Url').value.trim();
  const key = document.getElementById(arr+'Key').value.trim();
  await api('/api/settings', {
    method:'PATCH', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({settings:{[arr+'_url']:url,[arr+'_api_key']:key}})
  });
  testArr(arr);
}

async function testArr(arr) {
  const el = document.getElementById(arr+'Status');
  el.innerHTML = '<span class="status-dot dot-gray"></span>Testing…';
  const data = await api(`/api/arr/${arr}/status`);
  if (data.connected) {
    const v = data.status?.version || '';
    el.innerHTML = `<span class="status-dot dot-green"></span>Connected ${v?'v'+v:''}`;
  } else {
    el.innerHTML = `<span class="status-dot dot-red"></span>Not connected`;
  }
}

async function saveTautulli() {
  const url = document.getElementById('tautulliUrl').value.trim();
  await api('/api/settings', {
    method:'PATCH', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({settings:{tautulli_url:url}})
  });
  alert('Saved');
}

async function saveTtl() {
  const v = document.getElementById('ttlDays').value;
  await api('/api/settings', {
    method:'PATCH', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({settings:{symlink_ttl_days:v}})
  });
  alert('TTL saved');
}

async function loadFuse() {
  const data = await api('/api/fuse');
  const el = document.getElementById('fuseStatus');
  el.innerHTML = `
    <div><span class="status-dot ${data.exists?'dot-green':'dot-red'}"></span>
    Mount path: <span class="mono">${data.mount_path}</span></div>
    <div style="margin-top:8px">Files present: <strong>${data.has_files?'Yes':'No'}</strong></div>
  `;
}

function esc(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function pad(n) { return String(n||0).padStart(2,'0'); }

// Init
loadStreams('active');
</script>
</body>
</html>
"""
