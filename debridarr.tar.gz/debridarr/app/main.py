"""
Debridarr – rebuild
===================
Flow:
  1. Startup → scan Sonarr & Radarr → build library, create empty placeholder files for known media.
  2. Tautulli webhook fires when a user presses Play on a placeholder.
  3. Handler searches Sonarr/Radarr for the real file path on the FUSE mount.
  4. Symlink is created: placeholder path → real FUSE file.
  5. Sonarr/Radarr are notified (rescan) so they see the real file.
  6. After 30 days the symlink expires: symlink reverts to empty placeholder,
     Sonarr/Radarr are told the file is gone (manual unmonitor / rescan).
"""

import os, sqlite3, uuid, shutil, httpx, logging, json, time
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional, Literal, Any

from fastapi import FastAPI, HTTPException, Request, Header, Depends, BackgroundTasks
from fastapi.responses import HTMLResponse, JSONResponse

import asyncio
import os as _os

from app.proxy import proxy_stream, stream_direct, write_strm, delete_strm
from app.decypharr import (
    DecypharrClient,
    list_torrents, list_files,
    get_torrent_file,
    lookup_by_se_tag, lookup_by_stem,
    lookup_by_title_se, lookup_by_title_word,
    _load_index, _save_index,
)

# DFS FUSE mount point — AllDebrid chunk-cache filesystem


from pydantic import BaseModel, Field

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s – %(message)s")
log = logging.getLogger("debridarr")

# ── Env config ────────────────────────────────────────────────────────────────
DB_PATH           = os.getenv("DB_PATH",          "/data/debridarr.db")
STREAMS_PATH      = Path(os.getenv("STREAMS_PATH", "/streams"))
STRM_ROOT         = Path(os.getenv("STRM_ROOT", "/streams"))       # where .strm files are written for Plex
DEBRIDARR_BASE_URL= os.getenv("DEBRIDARR_BASE_URL", "http://debridarr:7474").rstrip("/")
SYMLINK_TTL_DAYS  = int(os.getenv("SYMLINK_TTL_DAYS", "30"))
PLACEHOLDER_EXT   = os.getenv("PLACEHOLDER_EXT", ".mp4")
API_KEY           = os.getenv("API_KEY", "").strip()

SONARR_URL        = os.getenv("SONARR_URL", "").rstrip("/")
SONARR_API_KEY    = os.getenv("SONARR_API_KEY", "")
RADARR_URL        = os.getenv("RADARR_URL", "").rstrip("/")
RADARR_API_KEY    = os.getenv("RADARR_API_KEY", "")

TAUTULLI_URL      = os.getenv("TAUTULLI_URL", "").rstrip("/")
TAUTULLI_API_KEY  = os.getenv("TAUTULLI_API_KEY", "")
PLEX_URL          = os.getenv("PLEX_URL", "").rstrip("/")
PLEX_TOKEN        = os.getenv("PLEX_TOKEN", "")


DECYPHARR_URL       = os.getenv("DECYPHARR_URL", "").rstrip("/")
DECYPHARR_API_TOKEN = os.getenv("DECYPHARR_API_TOKEN", "")
DECYPHARR_MOUNT     = os.getenv("DECYPHARR_MOUNT", "")  # e.g. /mnt/decypharr/__all__


# ── DB helpers ────────────────────────────────────────────────────────────────

import struct as _struct

def _load_placeholder() -> bytes:
    """Load the bundled placeholder.mp4, falling back to a minimal valid MP4 stub."""
    candidate = Path(__file__).parent / "placeholder.mp4"
    if candidate.exists():
        return candidate.read_bytes()
    # Fallback: minimal valid mp4 (silent, 1 s) so Plex/Tautulli recognise the file
    def box(t, p):
        return _struct.pack(">I", 8 + len(p)) + t + p
    ftyp = box(b"ftyp", b"mp42\x00\x00\x00\x00mp42isom")
    mvhd = box(b"mvhd",
        b"\x00" * 12
        + _struct.pack(">I", 1000) + _struct.pack(">I", 1000)
        + _struct.pack(">I", 0x00010000) + _struct.pack(">H", 0x0100)
        + b"\x00" * 10
        + _struct.pack(">9i", 0x00010000,0,0, 0,0x00010000,0, 0,0,0x40000000)
        + b"\x00" * 24 + _struct.pack(">I", 2)
    )
    return ftyp + box(b"moov", mvhd)

_FAKE_MP4 = _load_placeholder()

def get_conn():
    c = sqlite3.connect(DB_PATH, timeout=10)  # wait up to 10s if DB is locked
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    c.execute("PRAGMA wal_autocheckpoint=100")
    c.execute("PRAGMA synchronous=NORMAL")
    return c

def init_db():
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    STREAMS_PATH.mkdir(parents=True, exist_ok=True)
    with get_conn() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS settings (
          key   TEXT PRIMARY KEY,
          value TEXT NOT NULL
        );

        -- Library: every known title from Sonarr/Radarr
        CREATE TABLE IF NOT EXISTS library (
          id            TEXT PRIMARY KEY,
          arr           TEXT NOT NULL,          -- 'sonarr' | 'radarr'
          arr_id        INTEGER NOT NULL,
          media_type    TEXT NOT NULL,           -- 'movie' | 'episode'
          title         TEXT NOT NULL,
          year          INTEGER,
          season        INTEGER,
          episode       INTEGER,
          placeholder   TEXT NOT NULL,          -- empty .mp4 file or .strm file path
          strm_path     TEXT,                    -- .strm file path (new proxy mode)
          synced_at     TEXT NOT NULL,
          UNIQUE(arr, arr_id, season, episode)
        );
        CREATE INDEX IF NOT EXISTS idx_lib_arr  ON library(arr, arr_id);

        -- Active streams: placeholder has been replaced by a real symlink
        CREATE TABLE IF NOT EXISTS streams (
          id              TEXT PRIMARY KEY,
          library_id      TEXT REFERENCES library(id),
          arr             TEXT NOT NULL,
          arr_id          INTEGER,
          media_type      TEXT NOT NULL,
          title           TEXT NOT NULL,
          year            INTEGER,
          season          INTEGER,
          episode         INTEGER,
          source_path     TEXT NOT NULL,        -- real file on FUSE
          symlink_path    TEXT NOT NULL,        -- path of the symlink (==placeholder)
          stream_url      TEXT,                 -- AllDebrid CDN URL for proxy streaming
          cache_key       TEXT,                 -- proxy cache key
          created_at      TEXT NOT NULL,
          expires_at      TEXT NOT NULL,
          last_seen_at    TEXT NOT NULL,
          status          TEXT NOT NULL DEFAULT 'active'
        );
        CREATE INDEX IF NOT EXISTS idx_streams_expires ON streams(expires_at);

        -- Not-found items: spot check confirmed no release exists, skip on future syncs
        CREATE TABLE IF NOT EXISTS not_found (
          id         TEXT PRIMARY KEY,   -- same uuid5 as library id
          arr        TEXT NOT NULL,
          arr_id     INTEGER NOT NULL,
          media_type TEXT NOT NULL,
          title      TEXT NOT NULL,
          season     INTEGER,
          episode    INTEGER,
          checked_at TEXT NOT NULL,
          reason     TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_streams_status  ON streams(status);
        """)

        # Migrations: add new columns to existing DBs
        lib_cols     = {r[1] for r in db.execute("PRAGMA table_info(library)").fetchall()}
        streams_cols = {r[1] for r in db.execute("PRAGMA table_info(streams)").fetchall()}
        if "strm_path"   not in lib_cols:
            db.execute("ALTER TABLE library ADD COLUMN strm_path TEXT")
        if "stream_url"  not in streams_cols:
            db.execute("ALTER TABLE streams ADD COLUMN stream_url TEXT")
        if "cache_key"   not in streams_cols:
            db.execute("ALTER TABLE streams ADD COLUMN cache_key TEXT")

        defaults = {
            "streams_path":      str(STREAMS_PATH),
            "strm_root":         str(STRM_ROOT),
            "debridarr_base_url": DEBRIDARR_BASE_URL,
            "symlink_ttl_days":  str(SYMLINK_TTL_DAYS),
            "placeholder_ext":   PLACEHOLDER_EXT,
            "sonarr_url":        SONARR_URL,
            "sonarr_api_key":    SONARR_API_KEY,
            "radarr_url":        RADARR_URL,
            "radarr_api_key":    RADARR_API_KEY,
            "tautulli_url":      TAUTULLI_URL,
            "tautulli_api_key":  TAUTULLI_API_KEY,
            "plex_url":          PLEX_URL,
            "plex_token":        PLEX_TOKEN,
            # All-Debrid / DFS cache
            "decypharr_url":        DECYPHARR_URL,
            "decypharr_api_token":  DECYPHARR_API_TOKEN,
            "decypharr_mount":      DECYPHARR_MOUNT,

        }
        for k, v in defaults.items():
            if v:
                # Env var is set — seed/overwrite (env takes precedence)
                db.execute(
                    "INSERT INTO settings(key,value) VALUES(?,?) "
                    "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (k, v)
                )
            else:
                # Env var is blank — seed only if the row doesn't exist yet,
                # so a value saved through the UI is never overwritten with "".
                db.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v))

# ── Utility ───────────────────────────────────────────────────────────────────
def now_utc() -> datetime:
    return datetime.now(timezone.utc)

def iso(dt: datetime) -> str:
    return dt.isoformat()

def from_iso(s: str) -> datetime:
    return datetime.fromisoformat(s.replace("Z", "+00:00"))

def safe(value: str) -> str:
    import re as _rs
    # Remove apostrophes without splitting ("Grey's" → "Greys", "It's" → "Its")
    v = _rs.sub(r"[’‘'`]", "", (value or "").strip())
    keep = "".join(c if c.isalnum() or c in " ._-()[]" else " " for c in v)
    return " ".join(keep.split()) or "Unknown"

def get_setting(db, key: str, fallback: str = "") -> str:
    row = db.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row else fallback

# ── ARR HTTP helpers ──────────────────────────────────────────────────────────
def arr_headers(api_key: str) -> dict:
    return {"X-Api-Key": api_key, "Accept": "application/json"}

def sonarr_get(path: str, params: dict | None = None):
    with get_conn() as _db:
        url = SONARR_URL or get_setting(_db, "sonarr_url")
        key = SONARR_API_KEY or get_setting(_db, "sonarr_api_key")
    if not url or not key:
        return None
    try:
        r = httpx.get(f"{url}/api/v3{path}", headers=arr_headers(key), params=params, timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.warning("Sonarr GET %s failed: %s", path, e)
        return None

def radarr_get(path: str, params: dict | None = None):
    with get_conn() as _db:
        url = RADARR_URL or get_setting(_db, "radarr_url")
        key = RADARR_API_KEY or get_setting(_db, "radarr_api_key")
    if not url or not key:
        return None
    try:
        r = httpx.get(f"{url}/api/v3{path}", headers=arr_headers(key), params=params, timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.warning("Radarr GET %s failed: %s", path, e)
        return None

def sonarr_post(path: str, payload: dict):
    with get_conn() as _db:
        url = SONARR_URL or get_setting(_db, "sonarr_url")
        key = SONARR_API_KEY or get_setting(_db, "sonarr_api_key")
    if not url or not key:
        return None
    try:
        r = httpx.post(f"{url}/api/v3{path}", headers=arr_headers(key), json=payload, timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.warning("Sonarr POST %s failed: %s", path, e)
        return None

def radarr_post(path: str, payload: dict):
    with get_conn() as _db:
        url = RADARR_URL or get_setting(_db, "radarr_url")
        key = RADARR_API_KEY or get_setting(_db, "radarr_api_key")
    if not url or not key:
        return None
    try:
        r = httpx.post(f"{url}/api/v3{path}", headers=arr_headers(key), json=payload, timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.warning("Radarr POST %s failed: %s", path, e)
        return None

def sonarr_put(path: str, payload: dict):
    with get_conn() as _db:
        url = SONARR_URL or get_setting(_db, "sonarr_url")
        key = SONARR_API_KEY or get_setting(_db, "sonarr_api_key")
    if not url or not key:
        return None
    try:
        r = httpx.put(f"{url}/api/v3{path}", headers=arr_headers(key), json=payload, timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.warning("Sonarr PUT %s failed: %s", path, e)
        return None

def radarr_put(path: str, payload: dict):
    with get_conn() as _db:
        url = RADARR_URL or get_setting(_db, "radarr_url")
        key = RADARR_API_KEY or get_setting(_db, "radarr_api_key")
    if not url or not key:
        return None
    try:
        r = httpx.put(f"{url}/api/v3{path}", headers=arr_headers(key), json=payload, timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.warning("Radarr PUT %s failed: %s", path, e)
        return None

# ── Placeholder helpers ───────────────────────────────────────────────────────
def placeholder_path(arr: str, media_type: str, title: str, year: int | None,
                     season: int | None, episode: int | None) -> Path:
    """Return the .strm path for this item in STRM_ROOT."""
    t = safe(title)
    if media_type == "movie":
        folder = f"{t} ({year})" if year else t
        return STRM_ROOT / "movies" / folder / f"{folder}.strm"
    s = int(season or 0)
    e = int(episode or 0)
    return STRM_ROOT / "tv" / t / f"Season {s:02d}" / f"{t} - S{s:02d}E{e:02d}.strm"

def ensure_placeholder(path: Path, title: str = "", year=None,
                       season=None, episode=None, cache_key: str = ""):
    """Write a .strm file pointing to our proxy endpoint.
    Falls back to _FAKE_MP4 if STRM_ROOT/DEBRIDARR_BASE_URL not configured.
    The .strm file makes Plex hit /proxy/{cache_key} which:
      - immediately returns a valid MP4 header + null byte drip
      - resolves the file in the background
      - once found, Plex re-requests and streams the real file
    """
    path.parent.mkdir(parents=True, exist_ok=True)

    # Already a valid symlink or .strm (active stream) — leave it
    if path.is_symlink() and path.exists():
        return
    if path.exists() and path.suffix == ".strm":
        return

    # Remove dead symlink
    if path.is_symlink() and not path.exists():
        path.unlink(missing_ok=True)
    # Remove empty/zero-byte file
    elif path.exists() and path.stat().st_size == 0:
        path.unlink(missing_ok=True)

    if not path.exists():
        # Write .strm if we have a cache_key and base URL
        base_url = DEBRIDARR_BASE_URL
        if cache_key and base_url:
            strm = path.with_suffix(".strm")
            strm.parent.mkdir(parents=True, exist_ok=True)
            strm.write_text(f"{base_url}/proxy/{cache_key}\n")
            # If path had .mp4 ext, that's now been replaced by .strm
            if path != strm and path.exists():
                path.unlink(missing_ok=True)
        else:
            path.write_bytes(_FAKE_MP4)

def revert_to_placeholder(path: Path, library_id: str = ""):
    """Remove symlink/stream and restore .strm placeholder.
    Also clears the proxy cache so next play triggers a fresh resolve.
    """
    try:
        if path.is_symlink() or path.exists():
            path.unlink(missing_ok=True)
    except Exception:
        pass

    # Clear proxy cache so next play re-resolves
    if library_id and library_id in _proxy_db._data:
        del _proxy_db._data[library_id]
        _proxy_db._save()

    # Restore .strm if we have a base URL, otherwise fall back to MP4 placeholder
    if DEBRIDARR_BASE_URL and library_id:
        strm = path.with_suffix(".strm") if path.suffix != ".strm" else path
        try:
            strm.parent.mkdir(parents=True, exist_ok=True)
            strm.write_text(f"{DEBRIDARR_BASE_URL}/proxy/{library_id}\n")
            return
        except Exception:
            pass

    ensure_placeholder(path)

# ── NFO generation ────────────────────────────────────────────────────────────
# Plex NFO Agent (PMS ≥ 1.43.1) reads Kodi-format XML alongside the media file.
# By writing these, Plex skips the online metadata lookup and matches instantly,
# which dramatically speeds up library scans for placeholder files.
#
# File layout expected by Plex NFO Agent:
#   Movies  → <movie folder>/movie.nfo          (or <Filename>.nfo)
#   TV      → <show folder>/tvshow.nfo           (series-level, written once per show)
#             <season folder>/<Episode filename>.nfo  (episode-level)

def _xml_escape(s: str) -> str:
    return (str(s)
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;"))

def _write_nfo(path: Path, content: str):
    """Write NFO only if content has changed, to avoid Plex re-scanning unchanged files."""
    if path.exists():
        try:
            if path.read_text(encoding="utf-8").strip() == content.strip():
                return   # unchanged – don't touch mtime
        except Exception:
            pass
    try:
        path.write_text(content, encoding="utf-8")
    except Exception as exc:
        log.debug("NFO write failed %s: %s", path, exc)

def write_movie_nfo(movie_folder: Path, title: str, year: int | None,
                    tmdb_id: int | None, imdb_id: str | None,
                    plot: str = "", premiered: str = "", studio: str = "",
                    genres: list[str] | None = None):
    """Write movie.nfo in Kodi/Plex NFO Agent format."""
    uid_block = ""
    if tmdb_id:
        uid_block += f'  <uniqueid type="tmdb" default="true">{tmdb_id}</uniqueid>\n'
    if imdb_id:
        uid_block += f'  <uniqueid type="imdb">{_xml_escape(imdb_id)}</uniqueid>\n'
    genre_block = "".join(f"  <genre>{_xml_escape(g)}</genre>\n" for g in (genres or []))

    nfo = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>\n'
        "<movie>\n"
        f"  <title>{_xml_escape(title)}</title>\n"
        f"  <year>{year or ''}</year>\n"
        f"  <plot>{_xml_escape(plot)}</plot>\n"
        f"  <premiered>{_xml_escape(premiered)}</premiered>\n"
        f"  <studio>{_xml_escape(studio)}</studio>\n"
        + uid_block
        + genre_block
        + "</movie>\n"
    )
    _write_nfo(movie_folder / "movie.nfo", nfo)

def write_tvshow_nfo(show_folder: Path, title: str, year: int | None,
                     tvdb_id: int | None, tmdb_id: int | None, imdb_id: str | None,
                     plot: str = "", premiered: str = "", status: str = "",
                     studio: str = "", genres: list[str] | None = None):
    """Write tvshow.nfo – one per show folder, Plex reads it for series-level identity."""
    # Plex NFO Series agent prefers tmdb for TV, but accepts tvdb too.
    uid_block = ""
    if tmdb_id:
        uid_block += f'  <uniqueid type="tmdb" default="true">{tmdb_id}</uniqueid>\n'
    if tvdb_id:
        uid_block += f'  <uniqueid type="tvdb">{tvdb_id}</uniqueid>\n'
    if imdb_id:
        uid_block += f'  <uniqueid type="imdb">{_xml_escape(imdb_id)}</uniqueid>\n'
    genre_block = "".join(f"  <genre>{_xml_escape(g)}</genre>\n" for g in (genres or []))

    nfo = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>\n'
        "<tvshow>\n"
        f"  <title>{_xml_escape(title)}</title>\n"
        f"  <year>{year or ''}</year>\n"
        f"  <plot>{_xml_escape(plot)}</plot>\n"
        f"  <premiered>{_xml_escape(premiered)}</premiered>\n"
        f"  <status>{_xml_escape(status)}</status>\n"
        f"  <studio>{_xml_escape(studio)}</studio>\n"
        + uid_block
        + genre_block
        + "</tvshow>\n"
    )
    _write_nfo(show_folder / "tvshow.nfo", nfo)

def write_episode_nfo(episode_file: Path, title: str, show_title: str,
                      season: int, episode: int,
                      tvdb_ep_id: int | None, tmdb_ep_id: int | None,
                      plot: str = "", aired: str = ""):
    """Write <EpisodeFilename>.nfo alongside the placeholder for episode-level identity."""
    uid_block = ""
    if tvdb_ep_id:
        uid_block += f'  <uniqueid type="tvdb" default="true">{tvdb_ep_id}</uniqueid>\n'
    if tmdb_ep_id:
        uid_block += f'  <uniqueid type="tmdb">{tmdb_ep_id}</uniqueid>\n'

    nfo = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>\n'
        "<episodedetails>\n"
        f"  <title>{_xml_escape(title)}</title>\n"
        f"  <showtitle>{_xml_escape(show_title)}</showtitle>\n"
        f"  <season>{season}</season>\n"
        f"  <episode>{episode}</episode>\n"
        f"  <plot>{_xml_escape(plot)}</plot>\n"
        f"  <aired>{_xml_escape(aired)}</aired>\n"
        + uid_block
        + "</episodedetails>\n"
    )
    # NFO filename must match the video filename exactly (same stem, .nfo extension)
    nfo_path = episode_file.with_suffix(".nfo")
    _write_nfo(nfo_path, nfo)

# ── Library sync ──────────────────────────────────────────────────────────────
def sync_sonarr(db):
    series_list = sonarr_get("/series")
    if not series_list:
        return 0
    count = 0
    today = now_utc().date()

    # Fetch ALL episodes for ALL series in batches of 10 parallel requests
    # instead of one request per series
    import concurrent.futures as _cf

    # Filter series that have aired before fetching episodes
    eligible = []
    for series in series_list:
        premiered = (series.get("firstAired") or "")[:10]
        if premiered:
            try:
                if datetime.fromisoformat(premiered).date() > today:
                    continue
            except ValueError:
                pass
        elif series.get("status", "").lower() == "upcoming":
            continue
        eligible.append(series)

    # Fetch episodes in parallel — 20 workers for ~186 series ≈ 10 rounds
    def _fetch_eps(series):
        sid = series["id"]
        # Use seasonNumber filter to only fetch aired seasons
        # seasons array on series object tells us which seasons have aired
        aired_seasons = []
        for season in series.get("seasons", []):
            sn   = season.get("seasonNumber", 0)
            stat = season.get("statistics", {})
            # Skip season 0 (specials) and seasons with no aired episodes
            if sn == 0:
                continue
            # If previousAiring is set, at least one episode has aired
            if stat.get("previousAiring"):
                aired_seasons.append(sn)
            # Also include seasons where episodeFileCount > 0
            elif stat.get("episodeFileCount", 0) > 0:
                aired_seasons.append(sn)

        if not aired_seasons:
            # No aired seasons — still fetch to check air dates
            return series, sonarr_get("/episode", {"seriesId": sid}) or []

        # Fetch only aired seasons in parallel sub-requests
        eps = []
        for sn in aired_seasons:
            season_eps = sonarr_get("/episode", {"seriesId": sid, "seasonNumber": sn}) or []
            eps.extend(season_eps)
        return series, eps

    episodes_by_sid: dict = {}
    with _cf.ThreadPoolExecutor(max_workers=20) as pool:
        for series, eps in pool.map(_fetch_eps, eligible):
            episodes_by_sid[series["id"]] = (series, eps)

    for sid, (series, episodes) in episodes_by_sid.items():
        title     = series.get("title", "")
        year      = series.get("year")
        plot      = series.get("overview", "")
        status    = series.get("status", "")
        studio    = (series.get("network") or "")
        genres    = series.get("genres", [])
        premiered = (series.get("firstAired") or "")[:10]
        tvdb_id   = series.get("tvdbId")
        imdb_id   = series.get("imdbId")
        tmdb_id   = series.get("tmdbId")

        # Write tvshow.nfo once per show folder
        show_folder = STRM_ROOT / "tv" / safe(title)
        show_folder.mkdir(parents=True, exist_ok=True)
        write_tvshow_nfo(show_folder, title, year, tvdb_id, tmdb_id, imdb_id,
                         plot=plot, premiered=premiered, status=status,
                         studio=studio, genres=genres)

        today = now_utc().date()

        # Build a map of season → earliest air date to skip whole unreleased seasons
        season_premiere: dict[int, str] = {}
        for ep in episodes:
            sn = ep.get("seasonNumber")
            ad = (ep.get("airDate") or "")[:10]
            if sn and ad:
                if sn not in season_premiere or ad < season_premiere[sn]:
                    season_premiere[sn] = ad

        for ep in episodes:
            s        = ep.get("seasonNumber")
            e        = ep.get("episodeNumber")
            ep_title = ep.get("title", "")
            ep_plot  = ep.get("overview", "")
            ep_aired = (ep.get("airDate") or "")[:10]
            tvdb_ep  = ep.get("tvdbId")
            tmdb_ep  = ep.get("tmdbId")

            # Skip specials (season 0)
            if not s:
                continue

            # Skip entire season if its premiere date is in the future
            season_first = season_premiere.get(s, "")
            if season_first:
                try:
                    if datetime.fromisoformat(season_first).date() > today:
                        continue
                except ValueError:
                    pass

            # Skip individual unreleased episodes
            if ep_aired:
                try:
                    if datetime.fromisoformat(ep_aired).date() > today:
                        continue
                except ValueError:
                    pass
            elif not ep.get("hasFile"):
                # No air date and no file — skip
                continue

            lib_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"sonarr:{sid}:{s}:{e}"))
            # Skip if previously confirmed not found by spot check
            if db.execute("SELECT 1 FROM not_found WHERE id=?", (lib_id,)).fetchone():
                continue
            ph = placeholder_path("sonarr", "episode", title, year, s, e)
            ensure_placeholder(ph)
            write_episode_nfo(ph, ep_title, title, s, e,
                              tvdb_ep_id=tvdb_ep, tmdb_ep_id=tmdb_ep,
                              plot=ep_plot, aired=ep_aired)

            db.execute("""
                INSERT INTO library(id,arr,arr_id,media_type,title,year,season,episode,placeholder,synced_at)
                VALUES(?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET
                  title=excluded.title, year=excluded.year,
                  placeholder=excluded.placeholder, synced_at=excluded.synced_at
            """, (lib_id, "sonarr", sid, "episode", title, year, s, e, str(ph), iso(now_utc())))
            count += 1
    return count

def sync_radarr(db):
    movies = radarr_get("/movie")
    if not movies:
        return 0
    count = 0
    today = now_utc().date()
    for movie in movies:
        mid             = movie.get("id")
        title           = movie.get("title", "")
        year            = movie.get("year")
        plot            = movie.get("overview", "")
        digital_release = (movie.get("digitalRelease") or "")[:10]
        physical_release = (movie.get("physicalRelease") or "")[:10]
        in_cinemas      = (movie.get("inCinemas") or "")[:10]
        premiered       = digital_release or physical_release or in_cinemas
        studio          = (movie.get("studio") or "")
        genres          = movie.get("genres", [])
        tmdb_id         = movie.get("tmdbId")
        imdb_id         = movie.get("imdbId")

        # Only include movies after their digital release date
        # Fall back to physical release, then cinema date if digital not set
        release_date = digital_release or physical_release
        if release_date:
            try:
                if datetime.fromisoformat(release_date).date() > today:
                    continue  # not yet digitally released
            except ValueError:
                pass
        elif in_cinemas:
            # No digital/physical date — skip until we know it's available
            continue
        elif not movie.get("hasFile"):
            # No release dates and no file — skip
            continue

        lib_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"radarr:{mid}"))
        # Skip if previously confirmed not found by spot check
        with get_conn() as _nf_db:
            if _nf_db.execute("SELECT 1 FROM not_found WHERE id=?", (lib_id,)).fetchone():
                continue
        ph = placeholder_path("radarr", "movie", title, year, None, None)
        ensure_placeholder(ph)
        write_movie_nfo(ph.parent, title, year, tmdb_id, imdb_id,
                        plot=plot, premiered=premiered, studio=studio, genres=genres)

        db.execute("""
            INSERT INTO library(id,arr,arr_id,media_type,title,year,season,episode,placeholder,synced_at)
            VALUES(?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(id) DO UPDATE SET
              title=excluded.title, year=excluded.year,
              placeholder=excluded.placeholder, synced_at=excluded.synced_at
        """, (lib_id, "radarr", mid, "movie", title, year, None, None, str(ph), iso(now_utc())))
        count += 1
    return count


def _set_sonarr_all_unmonitored():
    """Set all Sonarr episodes unmonitored — Debridarr triggers downloads on play only."""
    series_list = sonarr_get("/series") or []
    for series in series_list:
        sid = series.get("id")
        if not sid:
            continue
        eps = sonarr_get("/episode", {"seriesId": sid}) or []
        ids = [ep["id"] for ep in eps if ep.get("monitored")]
        if ids:
            sonarr_put("/episode/monitor", {"episodeIds": ids, "monitored": False})
            log.info("Sonarr: set %d episodes unmonitored for series %s", len(ids), sid)


def _set_radarr_all_unmonitored():
    """Set all Radarr movies unmonitored — Debridarr triggers downloads on play only."""
    movies = radarr_get("/movie") or []
    ids    = [m["id"] for m in movies if m.get("monitored")]
    for movie in movies:
        if movie.get("monitored"):
            radarr_put(f"/movie/{movie['id']}", {**movie, "monitored": False})
    if ids:
        log.info("Radarr: set %d movies unmonitored", len(ids))


def _restore_active_streams():
    """On startup, repair broken symlinks for active streams.

    For each active stream:
      - Symlink resolves → leave it, still valid
      - Symlink is broken (FUSE not yet up or CDN expired) → re-create it
        pointing to the FUSE path using the stored source_path
      - If FUSE path can't be re-created → restore _FAKE_MP4 placeholder
        so Plex still shows the item and next play triggers a fresh search
    """
    with get_conn() as db:
        rows = db.execute(
            "SELECT * FROM streams WHERE status='active'"
        ).fetchall()

    repaired = valid = failed = 0
    for row in rows:
        row     = dict(row)
        sym     = Path(row["symlink_path"])
        source  = Path(row["source_path"]) if row.get("source_path") else None
        title   = row.get("title", "")
        season  = row.get("season")
        episode = row.get("episode")
        m_type  = row.get("media_type", "")

        # Already valid — leave it
        if sym.is_symlink() and sym.exists():
            valid += 1
            continue

        log.info("🔧 Repairing broken symlink [%s]: %s", m_type.upper(), sym.name)

        real = None

        # 1. Exact stored path — trust registry, don't call .exists() which hits CDN
        if source:
            src_torrent = source.parent.name
            src_fname   = source.name
            f = get_torrent_file(src_torrent, src_fname)
            if f:
                real = source
                log.info("   → found in registry (exact): %s/%s", src_torrent, src_fname)

        # 2. Stem index — filename without extension
        if not real and source:
            hits = lookup_by_stem(source.stem)
            if hits:
                torrent_name, fname = hits[0]
                real = (_dc_client.get_file_path(torrent_name, fname) if _dc_client else None) or None
                log.info("   → found via stem index: %s/%s", torrent_name, fname)

        # 3. S/E tag index for episodes
        if not real and season and episode:
            se_tag = f"S{int(season):02d}E{int(episode):02d}"
            hits   = lookup_by_se_tag(se_tag)
            if hits:
                # Score against title to pick best match
                best_score, best = 0.0, None
                for torrent_name, fname in hits:
                    score = _score_fuse_match(title, row.get("year"), torrent_name)
                    score = max(score, _score_fuse_match(title, row.get("year"), Path(fname).stem))
                    if score > best_score:
                        best_score, best = score, (torrent_name, fname)
                if best:
                    torrent_name, fname = best
                    real = (_dc_client.get_file_path(torrent_name, fname) if _dc_client else None)
                    log.info("   → found via S/E index (score=%.2f): %s/%s",
                             best_score, torrent_name, fname)

        # 4. Title + year search for movies
        if not real and m_type == "movie":
            fuse_match = _find_in_fuse(title, row.get("year"), None, None)
            if fuse_match:
                torrent_name, fname, _ = fuse_match
                real = (_dc_client.get_file_path(torrent_name, fname) if _dc_client else None)
                log.info("   → found via movie title search: %s/%s", torrent_name, fname)

        if real:
            try:
                sym.parent.mkdir(parents=True, exist_ok=True)
                if sym.is_symlink() or sym.exists():
                    sym.unlink(missing_ok=True)
                sym.symlink_to(str(real))
                # Update source_path in DB if it changed
                if str(real) != row.get("source_path"):
                    with get_conn() as db:
                        db.execute("UPDATE streams SET source_path=?, last_seen_at=? WHERE id=?",
                                   (str(real), iso(now_utc()), row["id"]))
                log.info("   ✅ Repaired: %s → %s", sym.name, real.name)
                repaired += 1
                continue
            except Exception as e:
                log.warning("   ❌ Repair failed: %s", e)

        # Nothing found — restore placeholder so Plex still shows the item
        log.warning("   ⚠️  Not in Decypharr — restoring placeholder for %s", title)
        try:
            sym.parent.mkdir(parents=True, exist_ok=True)
            if sym.is_symlink() or sym.exists():
                sym.unlink(missing_ok=True)
            sym.write_bytes(_FAKE_MP4)
        except Exception as e:
            log.warning("   ❌ Placeholder restore failed: %s", e)
        failed += 1

    log.info("Startup stream repair: ✅ %d valid  🔧 %d repaired  ⚠️  %d need re-play",
             valid, repaired, failed)


def _cleanup_stale_placeholders(sync_start: str) -> int:
    """Delete library rows not updated in this sync (unreleased/filtered items)
    and remove their placeholder files from disk if they are plain files (not symlinks).
    Active streams are never removed.
    """
    removed = 0
    with get_conn() as db:
        db.execute("PRAGMA foreign_keys=OFF")
        # Find rows not touched by this sync and not active streams
        stale = db.execute("""
            SELECT l.* FROM library l
            WHERE l.synced_at < ?
            AND NOT EXISTS (
                SELECT 1 FROM streams s
                WHERE s.library_id = l.id AND s.status = 'active'
            )
        """, (sync_start,)).fetchall()

        # Filter out rows whose placeholder is a valid symlink
        # (active streams that weren't recorded, or pre-linked FUSE files)
        stale = [r for r in stale
                 if not (Path(r["placeholder"]).is_symlink()
                         and Path(r["placeholder"]).exists())]

        for row in stale:
            ph = Path(row["placeholder"])
            # Only delete plain placeholder files — never touch active symlinks
            if ph.exists() and not ph.is_symlink():
                try:
                    ph.unlink(missing_ok=True)
                    # Remove empty parent dirs (Season XX folder)
                    try:
                        ph.parent.rmdir()
                    except OSError:
                        pass
                    log.info("Removed stale placeholder: %s", ph)
                except Exception as e:
                    log.warning("Could not remove stale placeholder %s: %s", ph, e)
            elif ph.is_symlink() and not ph.exists():
                # Dead symlink — remove it
                ph.unlink(missing_ok=True)
                log.info("Removed dead symlink: %s", ph)

            # Remove all stream references first to satisfy FK constraint
            # Active streams for stale items shouldn't exist (filtered above)
            # but delete all just to be safe
            db.execute("DELETE FROM streams WHERE library_id=?", (row["id"],))
            db.execute("DELETE FROM library WHERE id=?", (row["id"],))
            removed += 1

        db.execute("PRAGMA foreign_keys=ON")
    log.info("Cleaned up %d stale placeholder(s)", removed)
    return removed


def _presymlink_from_fuse():
    """After sync, symlink every library item that already exists in FUSE.
    Runs in background so plays are instant for content already in AllDebrid.
    Skips items already symlinked or with active streams.
    """
    import time as _time
    _time.sleep(3)  # wait for FUSE registry to settle after sync

    with get_conn() as db:
        rows = db.execute(
            """SELECT l.* FROM library l
               WHERE NOT EXISTS (
                 SELECT 1 FROM streams s
                 WHERE s.library_id = l.id AND s.status = 'active'
               )"""
        ).fetchall()

    log.info("Pre-symlink scan: checking %d library items against FUSE", len(rows))
    linked = skipped = 0

    for row in rows:
        ph = Path(row["placeholder"])
        # Already symlinked
        if ph.is_symlink() and ph.exists():
            skipped += 1
            continue

        lib    = dict(row)
        title  = lib["title"]
        year   = lib.get("year")
        season = lib.get("season")
        episode = lib.get("episode")

        fuse_match = _find_in_fuse(title, year, season, episode)
        if not fuse_match:
            skipped += 1
            continue

        torrent_name, fname, _ = fuse_match
        real = (_dc_client.get_file_path(torrent_name, fname) if _dc_client else None)

        # Create symlink and record stream
        try:
            ph.parent.mkdir(parents=True, exist_ok=True)
            if ph.is_symlink() or ph.exists():
                ph.unlink(missing_ok=True)
            ph.symlink_to(str(real))

            stream_id = str(uuid.uuid4())
            now       = iso(now_utc())
            expires   = iso(now_utc() + timedelta(days=SYMLINK_TTL_DAYS))
            with get_conn() as db:
                db.execute("""
                    INSERT OR IGNORE INTO streams
                    (id,library_id,arr,arr_id,media_type,title,year,season,episode,
                     source_path,symlink_path,created_at,expires_at,last_seen_at,status)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (stream_id, lib["id"], lib["arr"], lib["arr_id"], lib["media_type"],
                      title, year, season, episode,
                      str(real), str(ph), now, expires, now, "active"))
            # Mark as cached in proxy DB so proxy fast-paths immediately
            ad_link = fuse_match[2].get("l", "")
            if ad_link:
                _proxy_db.set_cached(lib["id"], ad_link, fuse_match[1])
            linked += 1
        except Exception as e:
            log.debug("Pre-symlink failed for %s: %s", title, e)
            skipped += 1

    log.info("Pre-symlink complete: %d linked, %d skipped", linked, skipped)


def full_library_sync():
    sync_start = iso(now_utc())
    with get_conn() as db:
        s = sync_sonarr(db)
        r = sync_radarr(db)
    # Remove placeholders for items that no longer qualify (unreleased, filtered out)
    cleaned = _cleanup_stale_placeholders(sync_start)
    # Ensure nothing auto-downloads — Debridarr owns the download trigger
    _set_sonarr_all_unmonitored()
    _set_radarr_all_unmonitored()
    log.info("Library sync complete – sonarr:%d  radarr:%d  cleaned:%d", s, r, cleaned)
    # Background: symlink anything already in FUSE so it plays instantly
    import threading
    threading.Thread(target=_presymlink_from_fuse, daemon=True,
                     name="presymlink").start()
    return {"sonarr": s, "radarr": r, "cleaned": cleaned}

# ── Stream resolution (called on Tautulli play event) ────────────────────────

import re as _re

def _norm(s: str) -> list:
    """Normalise a title/filename for fuzzy matching.

    Key rules:
      - Apostrophes/smart-quotes removed without splitting ("Grey's" → "greys")
      - Dot-separated acronyms joined into one token ("D.A.R.Y.L." → "daryl",
        "S.H.I.E.L.D." → "shield", "M*A*S*H" → "mash")
      - All other punctuation → space
      - Consecutive single-letter tokens merged (handles any remaining split acronyms)
    """
    s = s.lower()
    # Remove apostrophes without splitting
    s = _re.sub(r"[’‘'`]", "", s)
    # Join dot/star-separated acronyms before stripping punctuation
    # Handles 2-6 letter acronyms: D.A.R.Y.L. → daryl, S.H.I.E.L.D. → shield
    for n in (6, 5, 4, 3, 2):
        pattern = r"" + r"\.".join([r"([a-z])"] * n) + r"\."
        repl    = "".join([rf"\{i}" for i in range(1, n+1)])
        s = _re.sub(pattern, repl, s)
    # Handle star-separated acronyms like M*A*S*H
    s = _re.sub(r"([a-z])\*([a-z])\*([a-z])\*([a-z])", r"", s)
    s = _re.sub(r"([a-z])\*([a-z])\*([a-z])", r"", s)
    # Replace remaining non-alphanumeric with space
    s = _re.sub(r"[^a-z0-9\s]", " ", s)
    # Merge consecutive single-letter tokens (catches any remaining split acronyms)
    tokens = s.split()
    merged = []
    i = 0
    while i < len(tokens):
        if len(tokens[i]) == 1 and i + 1 < len(tokens) and len(tokens[i+1]) == 1:
            acc = tokens[i]
            while i + 1 < len(tokens) and len(tokens[i+1]) == 1:
                i += 1
                acc += tokens[i]
            merged.append(acc)
        else:
            merged.append(tokens[i])
        i += 1
    return [w for w in merged if w]

def _se_tag_str(season, episode) -> str | None:
    if season is not None and episode is not None:
        return f"S{int(season):02d}E{int(episode):02d}"
    return None


def _score_fuse_match(title: str, year, name: str) -> float:
    """Score how well a torrent/file name matches a title+year.

    Returns 0.0–1.0. Uses:
      - Word overlap ratio between normalised title and name
      - Year presence bonus
      - Length penalty for very short titles (avoids false positives)
    """
    title_words = _norm(title)
    name_words  = _norm(name)
    if not title_words or not name_words:
        return 0.0

    # Count how many title words appear in the name
    matched = sum(1 for w in title_words if w in name_words)
    ratio   = matched / len(title_words)

    # Year bonus
    if year and str(year) in name_words:
        ratio = min(1.0, ratio + 0.1)

    # Penalise if title is very short (1–2 words) to avoid false positives
    if len(title_words) <= 2 and matched < len(title_words):
        ratio *= 0.5

    return ratio


def _find_in_fuse(title: str, year, season, episode) -> tuple | None:
    """O(1) FUSE lookup using pre-built indexes.

    Episodes: title_word|S01E04 index → instant intersection
    Movies:   title_word index filtered by year → tiny candidate set
    """
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
    title_words = _norm(title)
    sig_words   = [w for w in title_words if len(w) > 2]
    se_tag      = f"S{int(season):02d}E{int(episode):02d}".upper() if (season and episode) else None
    year_str    = str(year) if year else ""
    THRESHOLD   = 0.6

    # ── Episodes: title+SE index gives exact intersection instantly ──────────
    if se_tag:
        candidate_set: dict = {}
        for w in sig_words:
            for entry in lookup_by_title_se(w, se_tag):
                candidate_set[entry] = candidate_set.get(entry, 0) + 1

        ranked = sorted(candidate_set.items(), key=lambda x: x[1], reverse=True)
        for (torrent_name, fname), word_hits in ranked:
            score = max(
                _score_fuse_match(title, year, torrent_name),
                _score_fuse_match(title, year, Path(fname).stem)
            )
            if score >= THRESHOLD:
                f = get_torrent_file(torrent_name, fname)
                if f:
                    log.info("_find_in_fuse ⚡ title+SE: score=%.2f hits=%d %s/%s",
                             score, word_hits, torrent_name, fname)
                    return torrent_name, fname, f

        # Fallback: pure S/E tag (any torrent with this ep)
        for torrent_name, fname in lookup_by_se_tag(se_tag):
            score = max(
                _score_fuse_match(title, year, torrent_name),
                _score_fuse_match(title, year, Path(fname).stem)
            )
            if score >= 0.3:
                f = get_torrent_file(torrent_name, fname)
                if f:
                    log.info("_find_in_fuse ⚡ SE fallback: score=%.2f %s/%s",
                             score, torrent_name, fname)
                    return torrent_name, fname, f

        log.warning("_find_in_fuse: no match for %r %s", title, se_tag)
        return None

    # ── Movies: title word index filtered by year ────────────────────────────
    candidate_set2: dict = {}
    for w in sig_words:
        for entry in lookup_by_title_word(w):
            torrent_name, fname = entry
            if not any(fname.lower().endswith(e) for e in video_exts):
                continue
            if year_str:
                t_words = _norm(torrent_name + " " + fname)
                if year_str not in t_words:
                    continue
            candidate_set2[entry] = candidate_set2.get(entry, 0) + 1

    ranked2 = sorted(candidate_set2.items(), key=lambda x: x[1], reverse=True)
    for (torrent_name, fname), _ in ranked2:
        score = max(
            _score_fuse_match(title, year, torrent_name),
            _score_fuse_match(title, year, Path(fname).stem)
        )
        if score >= THRESHOLD:
            f = get_torrent_file(torrent_name, fname)
            if f:
                log.info("_find_in_fuse ⚡ movie: score=%.2f %s/%s", score, torrent_name, fname)
                return torrent_name, fname, f

    # Movie fallback without year
    if year_str:
        candidate_set3: dict = {}
        for w in sig_words:
            for entry in lookup_by_title_word(w):
                torrent_name, fname = entry
                if any(fname.lower().endswith(e) for e in video_exts):
                    candidate_set3[entry] = candidate_set3.get(entry, 0) + 1
        for (torrent_name, fname), _ in sorted(candidate_set3.items(),
                                                key=lambda x: x[1], reverse=True):
            score = max(
                _score_fuse_match(title, year, torrent_name),
                _score_fuse_match(title, year, Path(fname).stem)
            ) * 0.8
            if score >= THRESHOLD:
                f = get_torrent_file(torrent_name, fname)
                if f:
                    log.info("_find_in_fuse ⚡ movie no-year: score=%.2f %s/%s",
                             score, torrent_name, fname)
                    return torrent_name, fname, f

    log.warning("_find_in_fuse: no match for movie %r year=%s", title, year)
    return None


# Cache series root paths to avoid repeated API calls
_series_root_cache: dict[int, str] = {}

def _get_series_root(arr_id: int) -> str:
    if arr_id not in _series_root_cache:
        series = sonarr_get(f"/series/{arr_id}") or {}
        _series_root_cache[arr_id] = series.get("path", "")
    return _series_root_cache[arr_id]

def _get_episode_file_path(arr_id: int, season: int, episode: int) -> Path | None:
    """Ask Sonarr for the file path using the episodes endpoint with season/episode filter."""
    # Use season/episode query params to avoid fetching all episodes
    eps = sonarr_get("/episode", {"seriesId": arr_id, "seasonNumber": season})
    if not eps:
        return None
    for ep in eps:
        if ep.get("episodeNumber") != episode:
            continue
        if not ep.get("hasFile"):
            return None
        ef = ep.get("episodeFile")
        # Get file details
        if isinstance(ef, dict):
            rel, size = ef.get("relativePath", ""), ef.get("size", 0)
        elif isinstance(ef, int):
            ef_data = sonarr_get(f"/episodefile/{ef}") or {}
            rel, size = ef_data.get("relativePath", ""), ef_data.get("size", 0)
        else:
            return None
        if not rel or not size:
            return None
        root = _get_series_root(arr_id)
        if root:
            return Path(root) / rel
    return None


def _get_movie_file_path(arr_id: int) -> Path | None:
    """Ask Radarr for the file path of a movie."""
    movie = radarr_get(f"/movie/{arr_id}")
    if not movie:
        return None
    mf = movie.get("movieFile") or {}
    if isinstance(mf, int):
        mf = radarr_get(f"/moviefile/{mf}") or {}
    rel, size = mf.get("relativePath", ""), mf.get("size", 0)
    root = movie.get("path", "")
    if root and rel and size:
        return Path(root) / rel
    return None


def sonarr_delete(path: str) -> bool:
    with get_conn() as _db:
        url = SONARR_URL or get_setting(_db, "sonarr_url")
        key = SONARR_API_KEY or get_setting(_db, "sonarr_api_key")
    if not url or not key:
        return False
    try:
        r = httpx.delete(f"{url}/api/v3{path}", headers=arr_headers(key), timeout=10)
        log.info("Sonarr DELETE %s → %s", path, r.status_code)
        return r.status_code in (200, 204)
    except Exception as e:
        log.warning("Sonarr DELETE %s failed: %s", path, e)
        return False

def radarr_delete(path: str) -> bool:
    with get_conn() as _db:
        url = RADARR_URL or get_setting(_db, "radarr_url")
        key = RADARR_API_KEY or get_setting(_db, "radarr_api_key")
    if not url or not key:
        return False
    try:
        r = httpx.delete(f"{url}/api/v3{path}", headers=arr_headers(key), timeout=10)
        log.info("Radarr DELETE %s → %s", path, r.status_code)
        return r.status_code in (200, 204)
    except Exception as e:
        log.warning("Radarr DELETE %s failed: %s", path, e)
        return False


def _get_episode_file_id(arr_id: int, season: int, episode: int) -> int | None:
    eps = sonarr_get("/episode", {"seriesId": arr_id}) or []
    for ep in eps:
        if ep.get("seasonNumber") == season and ep.get("episodeNumber") == episode:
            ef = ep.get("episodeFile")
            if isinstance(ef, dict): return ef.get("id")
            elif isinstance(ef, int): return ef
    return None


def _get_movie_file_id(arr_id: int) -> int | None:
    movie = radarr_get(f"/movie/{arr_id}") or {}
    mf    = movie.get("movieFile") or {}
    if isinstance(mf, dict): return mf.get("id")
    elif isinstance(mf, int): return mf
    return None


def _trigger_arr_search(arr: str, arr_id: int, season: int | None, episode: int | None):
    """Delete the arr file record then trigger a fresh search.

    We delete the Sonarr/Radarr file record (not the placeholder symlink in /streams)
    so arr treats the item as missing and will actually search + download it.
    The placeholder in Plex (/streams/...) is untouched — Plex keeps showing it.
    """
    if arr == "sonarr":
        eps     = sonarr_get("/episode", {"seriesId": arr_id}) or []
        matched = None
        for ep in eps:
            if ep.get("seasonNumber") == season and ep.get("episodeNumber") == episode:
                matched = ep
                break
        if not matched:
            log.warning("Sonarr: no episode for seriesId=%s s%se%s", arr_id, season, episode)
            return

        ep_id    = matched["id"]
        has_file = matched.get("hasFile", False)
        log.info("Sonarr: episode %s hasFile=%s — deleting file record and searching",
                 ep_id, has_file)

        # Delete the Sonarr file record so it will re-download
        # (This only removes the record in Sonarr, NOT the placeholder symlink in /streams)
        if has_file:
            ef    = matched.get("episodeFile")
            ef_id = ef.get("id") if isinstance(ef, dict) else (ef if isinstance(ef, int) else None)
            if not ef_id:
                # Fetch full episode to get file ID
                full  = sonarr_get(f"/episode/{ep_id}") or {}
                ef    = full.get("episodeFile") or {}
                ef_id = ef.get("id") if isinstance(ef, dict) else None
            if ef_id:
                ok = sonarr_delete(f"/episodefile/{ef_id}")
                log.info("Sonarr: deleted episodeFile %s → %s", ef_id, ok)

        # Clear cached series root so next poll gets fresh path
        _series_root_cache.pop(arr_id, None)
        result = sonarr_post("/command", {"name": "EpisodeSearch", "episodeIds": [ep_id]})
        log.info("Sonarr EpisodeSearch → %s", result)

    elif arr == "radarr":
        movie = radarr_get(f"/movie/{arr_id}") or {}
        mf    = movie.get("movieFile") or {}
        mf_id = mf.get("id") if isinstance(mf, dict) else (mf if isinstance(mf, int) else None)
        if mf_id:
            ok = radarr_delete(f"/moviefile/{mf_id}")
            log.info("Radarr: deleted movieFile %s → %s", mf_id, ok)

        result = radarr_post("/command", {"name": "MoviesSearch", "movieIds": [arr_id]})
        log.info("Radarr MoviesSearch → %s", result)


def _make_symlink(lib: dict, target: Path) -> Path | None:
    """Swap placeholder → symlink to target. Matches working version's logic exactly."""
    ph = Path(lib["placeholder"])
    media_type = lib["media_type"]
    title      = lib["title"]
    year       = lib["year"]
    season     = lib["season"]
    episode    = lib["episode"]

    folder = ph.parent
    try:
        folder.mkdir(parents=True, exist_ok=True)
        # Ensure placeholder exists (written with real MP4 bytes)
        if not ph.exists() and not ph.is_symlink():
            ph.write_bytes(_FAKE_MP4)
    except Exception as e:
        log.error("placeholder write: %s", e)

    try:
        # Replace placeholder with symlink AT THE SAME PATH
        # This keeps Plex's library entry valid — the filename never changes
        if ph.is_symlink() or ph.exists():
            ph.unlink(missing_ok=True)
        ph.symlink_to(str(target))

        if ph.is_symlink():
            log.info("🔗 Symlinked: %s → %s", ph.name, target)
            return ph
        else:
            # Symlink failed — restore placeholder
            if not ph.exists():
                ph.write_bytes(_FAKE_MP4)
            return None
    except Exception as e:
        log.error("symlink failed: %s", e)
        try:
            if not ph.exists() and not ph.is_symlink():
                ph.write_bytes(_FAKE_MP4)
        except Exception:
            pass
        return None


def _create_fuse_symlinks_for_arr(arr: str, arr_id: int, title: str, year,
                                   season: int | None, episode: int | None):
    """Create symlinks in arr's root download folder pointing to matching FUSE files.
    This lets Sonarr/Radarr auto-import the file from FUSE as if it were a real download.
    """

    video_exts  = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
    title_words = _norm(title)
    se_tag      = f"S{season:02d}E{episode:02d}".upper() if (season and episode) else None
    matches     = []

    for torrent_name in list_torrents():
        t_words = _norm(torrent_name)
        if not all(w in t_words for w in title_words):
            continue
        for fname in list_files(torrent_name):
            if not any(fname.lower().endswith(e) for e in video_exts):
                continue
            if se_tag and se_tag not in fname.upper():
                continue
            matches.append((torrent_name, fname))

    if not matches:
        log.debug("No FUSE matches to symlink for arr: %r", title)
        return

    if arr == "sonarr":
        roots = sonarr_get("/rootfolder") or []
    elif arr == "radarr":
        roots = radarr_get("/rootfolder") or []
    else:
        return

    root = roots[0].get("path", "") if roots else ""
    if not root:
        log.warning("No arr root folder found for %s", arr)
        return

    root_path = Path(root)
    for torrent_name, fname in matches:
        fuse_file   = (_dc_client.get_file_path(torrent_name, fname) if _dc_client else None)
        link_folder = root_path / torrent_name
        link_path   = link_folder / fname
        try:
            link_folder.mkdir(parents=True, exist_ok=True)
            if link_path.is_symlink() or link_path.exists():
                link_path.unlink(missing_ok=True)
            link_path.symlink_to(str(fuse_file))
            log.info("📁 arr import folder symlink: %s → %s", link_path, fuse_file)
        except Exception as e:
            log.warning("arr symlink failed %s: %s", link_path, e)


def activate_stream(library_id: str, session_key: str = "",
                    client_id: str = "", rating_key: str = "") -> dict:
    """Replace placeholder with symlink to the real file.

    Resolution order (matching working version):
      1. FUSE registry (instant — already in AllDebrid)
      2. Sonarr/Radarr file on disk (already downloaded)
      3. Trigger arr search + poll for new file (background download)
    """
    with get_conn() as db:
        lib = db.execute("SELECT * FROM library WHERE id=?", (library_id,)).fetchone()
        if not lib:
            return {"ok": False, "error": "Library item not found"}
        existing = db.execute(
            "SELECT * FROM streams WHERE library_id=? AND status='active'", (library_id,)
        ).fetchone()
        if existing:
            sym = Path(existing["symlink_path"])
            if sym.is_symlink() and sym.exists():
                db.execute("UPDATE streams SET last_seen_at=? WHERE id=?",
                           (iso(now_utc()), existing["id"]))
                return {"ok": True, "already_active": True, "stream_id": existing["id"],
                        "instant": True}
            else:
                log.info("activate_stream: broken symlink for %s — re-activating", library_id)
                db.execute("UPDATE streams SET status='expired' WHERE id=?", (existing["id"],))

    # Check if placeholder is already symlinked from pre-symlink pass
    with get_conn() as db:
        lib_check = db.execute("SELECT * FROM library WHERE id=?", (library_id,)).fetchone()
    if lib_check:
        ph = Path(lib_check["placeholder"])
        if ph.is_symlink() and ph.exists():
            # Already symlinked by presymlink — record stream and return instantly
            real      = Path(os.readlink(str(ph)))
            stream_id = str(uuid.uuid4())
            now       = iso(now_utc())
            expires   = iso(now_utc() + timedelta(days=SYMLINK_TTL_DAYS))
            with get_conn() as db:
                db.execute("""
                    INSERT OR IGNORE INTO streams
                    (id,library_id,arr,arr_id,media_type,title,year,season,episode,
                     source_path,symlink_path,created_at,expires_at,last_seen_at,status)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (stream_id, lib_check["id"], lib_check["arr"], lib_check["arr_id"],
                      lib_check["media_type"], lib_check["title"], lib_check["year"],
                      lib_check["season"], lib_check["episode"],
                      str(real), str(ph), now, expires, now, "active"))
            log.info("⚡ Instant play (pre-symlinked): %s", ph.name)
            return {"ok": True, "stream_id": stream_id, "symlink": str(ph),
                    "source": str(real), "instant": True}

    lib     = dict(lib)
    # Stash Plex session info so _immediate_symlink can interrupt the session
    lib["_session_key"] = session_key
    lib["_client_id"]   = client_id
    lib["_rating_key"]  = rating_key
    arr     = lib["arr"]
    arr_id  = lib["arr_id"]
    season  = lib["season"]
    episode = lib["episode"]
    title   = lib["title"]
    year    = lib["year"]
    ph      = Path(lib["placeholder"])

    real = None
    source = None

    # ── INSTANT PATH: check FUSE index first (sub-millisecond) ──────────────
    fuse_match = _find_in_fuse(title, year, season, episode)
    if fuse_match:
        torrent_name, fname, _ = fuse_match
        real   = (_dc_client.get_file_path(torrent_name, fname) if _dc_client else None)
        source = "fuse"
        log.info("⚡ Instant FUSE hit: %s / %s", torrent_name, fname)

    # ── SEARCH PATH: not in FUSE yet — trigger search then hammer the index ──
    if not real:
        log.info("Not in FUSE — triggering %s search for %s s%se%s", arr, title, season, episode)
        _trigger_arr_search(arr, arr_id, season, episode)

        # Poll aggressively: reload FUSE every 1s for up to 30s
        # As soon as AllDebrid receives the torrent it appears in the index → instant symlink
        deadline = time.time() + 30
        attempt  = 0
        while time.time() < deadline:
            attempt += 1
            # Incremental reload via Decypharr
            if _dc_client:
                n_new = _dc_client.reload_new()
                if n_new:
                    log.info("⚡ %d new torrent(s) on attempt %d", n_new, attempt)

            fuse_match = _find_in_fuse(title, year, season, episode)
            if fuse_match:
                torrent_name, fname, _ = fuse_match
                real   = (_dc_client.get_file_path(torrent_name, fname) if _dc_client else None)
                source = "fuse"
                log.info("✅ Found in FUSE on attempt %d (%.1fs): %s / %s",
                         attempt, 30 - (deadline - time.time()), torrent_name, fname)
                break

            time.sleep(0.5)

    if not real:
        return {"ok": False, "error": f"No file found for '{title}' after 30s"}

    # Symlink
    link = _make_symlink(lib, real)
    if not link:
        return {"ok": False, "error": f"Symlink creation failed for {real}"}

    stream_id = str(uuid.uuid4())
    now       = iso(now_utc())
    expires   = iso(now_utc() + timedelta(days=SYMLINK_TTL_DAYS))

    with get_conn() as db:
        db.execute("""
            INSERT INTO streams(id,library_id,arr,arr_id,media_type,title,year,season,episode,
                                source_path,symlink_path,created_at,expires_at,last_seen_at,status)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (stream_id, library_id, arr, arr_id, lib["media_type"],
              title, year, season, episode,
              str(real), str(link), now, expires, now, "active"))

    _notify_arr_rescan(arr, arr_id)
    log.info("✅ Stream activated [%s] via %s: %s → %s (expires %s)",
             lib["media_type"].upper(), source, link.name, real, expires)
    return {"ok": True, "stream_id": stream_id, "symlink": str(link),
            "source": str(real), "source_type": source, "expires_at": expires}


def _notify_arr_rescan(arr: str, arr_id: int):
    if arr == "sonarr":
        sonarr_post("/command", {"name": "RescanSeries", "seriesId": arr_id})
    elif arr == "radarr":
        radarr_post("/command", {"name": "RescanMovie", "movieId": arr_id})

def _notify_arr_unlink(arr: str, arr_id: int, season: int | None, episode: int | None):
    """Tell the arr the file is gone so it can unmonitor / mark missing."""
    if arr == "sonarr":
        sonarr_post("/command", {"name": "RescanSeries", "seriesId": arr_id})
    elif arr == "radarr":
        radarr_post("/command", {"name": "RescanMovie", "movieId": arr_id})

# ── Expiry cleanup ────────────────────────────────────────────────────────────
def cleanup_expired() -> list[str]:
    expired_ids = []
    now = now_utc()
    with get_conn() as db:
        rows = db.execute("SELECT * FROM streams WHERE status='active'").fetchall()
        for row in rows:
            try:
                if from_iso(row["expires_at"]) > now:
                    continue
            except Exception:
                continue
            sym        = Path(row["symlink_path"])
            library_id = row["library_id"] or ""
            revert_to_placeholder(sym, library_id=library_id)
            db.execute("UPDATE streams SET status='expired' WHERE id=?", (row["id"],))
            expired_ids.append(row["id"])
            log.info("Stream expired and reverted: %s (id=%s)", sym, row["id"])
            # Delete torrent from Decypharr/AllDebrid if not pinned
            source = row.get("source_path") or ""
            if source and not is_pinned_item(row["library_id"]):
                torrent_name = Path(source).parent.name
                if _dc_client and torrent_name:
                    _dc_client.delete_torrent(torrent_name)
            # Delete file from arr; re-trigger if pinned, set unmonitored otherwise
            _expire_arr_item(row["arr"], row["arr_id"], row["season"], row["episode"],
                             library_id=row["library_id"] or "")
    return expired_ids


def is_pinned_item(library_id: str) -> bool:
    """Check if a library item is in the pinned list."""
    if not library_id:
        return False
    with get_conn() as db:
        return bool(db.execute("SELECT 1 FROM pinned WHERE id=?", (library_id,)).fetchone())


def _expire_arr_item(arr: str, arr_id: int, season, episode, library_id: str = ""):
    """Delete the downloaded file from arr.
    If pinned, re-triggers search immediately. Otherwise sets unmonitored.
    """
    is_pinned = is_pinned_item(library_id)

    if arr == "sonarr":
        eps = sonarr_get("/episode", {"seriesId": arr_id}) or []
        for ep in eps:
            if ep.get("seasonNumber") == season and ep.get("episodeNumber") == episode:
                ep_id = ep["id"]
                ef    = ep.get("episodeFile")
                ef_id = ef.get("id") if isinstance(ef, dict) else (ef if isinstance(ef, int) else None)
                if ef_id:
                    sonarr_delete(f"/episodefile/{ef_id}")
                    log.info("Expired: deleted Sonarr episodeFile %s", ef_id)
                if is_pinned:
                    _trigger_arr_search(arr, arr_id, season, episode)
                    log.info("📌 Pinned: re-triggered search for s%se%s", season, episode)
                else:
                    sonarr_put("/episode/monitor", {"episodeIds": [ep_id], "monitored": False})
                    log.info("Expired: set Sonarr episode %s unmonitored", ep_id)
                return
    elif arr == "radarr":
        movie = radarr_get(f"/movie/{arr_id}") or {}
        mf    = movie.get("movieFile") or {}
        mf_id = mf.get("id") if isinstance(mf, dict) else (mf if isinstance(mf, int) else None)
        if mf_id:
            radarr_delete(f"/moviefile/{mf_id}")
            log.info("Expired: deleted Radarr movieFile %s", mf_id)
        if is_pinned:
            _trigger_arr_search(arr, arr_id, None, None)
            log.info("📌 Pinned: re-triggered search for Radarr movie %s", arr_id)
        else:
            radarr_put(f"/movie/{arr_id}", {**movie, "monitored": False})
            log.info("Expired: set Radarr movie %s unmonitored", arr_id)

# ── FastAPI app ───────────────────────────────────────────────────────────────
# Module-level AllDebrid client — set by lifespan, used by /api/fuse/reload
_dc_client: DecypharrClient | None = None

# ── Proxy state DB ───────────────────────────────────────────────────────────
import json as _json

_PROXY_CACHE_FILE = Path("/data/proxy_cache.json")

class _ProxyDB:
    """Dict-backed proxy state store matching CacheDB interface used by proxy.py."""
    def __init__(self):
        self._data: dict = {}
        self._load()

    def _load(self):
        try:
            if _PROXY_CACHE_FILE.exists():
                self._data = _json.loads(_PROXY_CACHE_FILE.read_text())
                log.info("Proxy cache loaded: %d entries", len(self._data))
        except Exception as e:
            log.warning("Proxy cache load failed: %s", e)

    def _save(self):
        try:
            _PROXY_CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
            _PROXY_CACHE_FILE.write_text(_json.dumps(self._data))
        except Exception as e:
            log.warning("Proxy cache save failed: %s", e)

    def get(self, cache_key: str) -> dict | None:
        return self._data.get(cache_key)

    def set_resolving(self, cache_key: str):
        self._data[cache_key] = {"status": "resolving"}

    def set_cached(self, cache_key: str, stream_url: str, torrent_name: str,
                   magnet_link: str = ""):
        self._data[cache_key] = {
            "status":       "cached",
            "stream_url":   stream_url,
            "torrent_name": torrent_name,
            "magnet_link":  magnet_link,
            "cached_at":    iso(now_utc()),
        }
        self._save()

    def set_error(self, cache_key: str, reason: str = "error"):
        self._data[cache_key] = {"status": reason}

    def update_stream_url(self, cache_key: str, url: str):
        if cache_key in self._data:
            self._data[cache_key]["stream_url"] = url
            self._save()


_proxy_db = _ProxyDB()


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    # Load persisted FUSE index instantly — no API calls needed
    n = _load_index()
    if n:
        log.info("⚡ FUSE index pre-loaded from disk: %d torrent(s)", n)
        # Restore active stream symlinks now that index is available
        _restore_active_streams()
    cleanup_expired()
    full_library_sync()

    # ── Decypharr client ──────────────────────────────────────────────────────
    global _dc_client
    _dc_client = None
    with get_conn() as _db:
        _dc_url   = get_setting(_db, "decypharr_url")   or DECYPHARR_URL
        _dc_token = get_setting(_db, "decypharr_api_token") or DECYPHARR_API_TOKEN

    if _dc_url:
        _dc_mount  = get_setting(_db, "decypharr_mount") or DECYPHARR_MOUNT
        _dc_client = DecypharrClient(_dc_url, _dc_token, _dc_mount)
        log.info("Decypharr client: %s", _dc_url)

        # Load persisted index first (instant — no API calls)
        n = _load_index()
        if n:
            log.info("⚡ Decypharr index pre-loaded: %d torrents", n)
            _restore_active_streams()

        # Full reload from Decypharr in background thread
        import threading as _th
        def _initial_load():
            n2 = _dc_client.reload_all()
            log.info("Decypharr: full load complete — %d torrents", n2)
            _restore_active_streams()
            _presymlink_from_fuse()
        _th.Thread(target=_initial_load, daemon=True, name="dc-init").start()

        # Background refresh every 30s — incremental, only new torrents
        # When new torrents appear, auto-match against library items
        async def _dc_refresh_loop():
            while True:
                await asyncio.sleep(30)
                try:
                    if _dc_client:
                        n3 = await asyncio.get_event_loop().run_in_executor(
                            None, _dc_client.reload_new)
                        if n3:
                            log.info("Decypharr: +%d new torrent(s) — running auto-match", n3)
                            # Run presymlink in thread so new torrents get matched immediately
                            await asyncio.get_event_loop().run_in_executor(
                                None, _presymlink_from_fuse)
                except Exception as _e:
                    log.warning("Decypharr refresh error: %s", _e)

        asyncio.create_task(_dc_refresh_loop())

        # Also run a full auto-match pass every 5 minutes to catch anything missed
        async def _auto_match_loop():
            while True:
                await asyncio.sleep(300)
                try:
                    await asyncio.get_event_loop().run_in_executor(
                        None, _presymlink_from_fuse)
                except Exception as _e:
                    log.warning("Auto-match error: %s", _e)

        asyncio.create_task(_auto_match_loop())
    else:
        log.info("Decypharr not configured — set DECYPHARR_URL")
    # ─────────────────────────────────────────────────────────────────────────

    yield

    # Shutdown — nothing to unmount

app = FastAPI(title="Debridarr", version="2026.06", lifespan=lifespan)

# ── Auth ──────────────────────────────────────────────────────────────────────
async def require_api_key(
    authorization: Optional[str] = Header(default=None),
    x_api_key: Optional[str]    = Header(default=None),
):
    if not API_KEY:
        return True
    token = (x_api_key or "").strip()
    if authorization and authorization.lower().startswith("bearer "):
        token = authorization.split(" ", 1)[1].strip()
    if token != API_KEY:
        raise HTTPException(401, "Invalid API key")
    return True

# ── Models ────────────────────────────────────────────────────────────────────
class SettingsPatch(BaseModel):
    settings: dict[str, str]

class ManualStreamCreate(BaseModel):
    arr:        Literal["sonarr", "radarr"] = "sonarr"
    media_type: Literal["movie", "episode"] = "episode"
    title:      str
    year:       Optional[int] = None
    season:     Optional[int] = None
    episode:    Optional[int] = None
    source_path: str = Field(..., description="Real file path on FUSE mount")
    ttl_days:   Optional[int] = None

class TautulliWebhook(BaseModel):
    """
    Tautulli sends notification agent payloads.
    We accept either the native Tautulli JSON agent format or a simplified form.
    """
    event:          Optional[str] = None          # 'play', 'watched', etc.
    # Tautulli template fields (set these in the notification agent)
    media_type:     Optional[str] = None          # 'episode' or 'movie'
    file:           Optional[str] = None          # full file path Plex played
    grandparent_title: Optional[str] = None       # show title
    parent_media_index: Optional[int] = None      # season
    media_index:    Optional[int] = None          # episode
    title:          Optional[str] = None          # movie title or episode title
    year:           Optional[int] = None
    extra:          dict[str, Any] = {}

# ── Setup helpers ─────────────────────────────────────────────────────────────
def is_setup_complete() -> bool:
    """Returns True if at least one arr is fully configured."""
    if (SONARR_URL and SONARR_API_KEY) or (RADARR_URL and RADARR_API_KEY):
        return True
    with get_conn() as db:
        s = get_setting(db, "sonarr_url") and get_setting(db, "sonarr_api_key")
        r = get_setting(db, "radarr_url") and get_setting(db, "radarr_api_key")
        return bool(s or r)

# ── Routes ────────────────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
def home():
    return HTMLResponse(UI)

@app.get("/api/setup/status")
def setup_status():
    """Returns which steps are complete so the wizard can show progress."""
    with get_conn() as db:
        sonarr_url   = SONARR_URL   or get_setting(db, "sonarr_url")
        sonarr_key   = SONARR_API_KEY or get_setting(db, "sonarr_api_key")
        radarr_url   = RADARR_URL   or get_setting(db, "radarr_url")
        radarr_key   = RADARR_API_KEY or get_setting(db, "radarr_api_key")
        tautulli_url = TAUTULLI_URL or get_setting(db, "tautulli_url")
        ttl          = get_setting(db, "symlink_ttl_days", str(SYMLINK_TTL_DAYS))
        streams_path = get_setting(db, "streams_path", str(STREAMS_PATH))

    sonarr_connected = radarr_connected = False
    if sonarr_url and sonarr_key:
        sonarr_connected = sonarr_get("/system/status") is not None
    if radarr_url and radarr_key:
        radarr_connected = radarr_get("/system/status") is not None

    # AllDebrid connectivity check
    ad_connected = False
    ad_username  = ""
    if ad_key:
        try:
            import httpx as _hx
            r = _hx.get(
                "https://api.alldebrid.com/v4/user",
                params={"agent": "debridarr", "apikey": ad_key},
                timeout=8,
            )
            d = r.json()
            if d.get("status") == "success":
                ad_connected = True
                ad_username  = d.get("data", {}).get("user", {}).get("username", "")
        except Exception:
            pass

    # DFS FUSE mount status
    dfs_mounted = False

    return {
        "setup_complete":   is_setup_complete(),
        "sonarr_url":       sonarr_url,
        "sonarr_connected": sonarr_connected,
        "radarr_url":       radarr_url,
        "radarr_connected": radarr_connected,
        "tautulli_url":     tautulli_url,
        "streams_path":     streams_path,
        "ttl_days":         ttl,
        "webhook_url":      "/webhook/tautulli",
        "ad_key_set":       bool(ad_key),
        "ad_connected":     ad_connected,
        "ad_username":      ad_username,
        "dfs_mounted":      dfs_mounted,
        "dfs_mount_path":   "",
    }


@app.post("/api/library/{arr_id}/reset-placeholders")
def reset_placeholders(arr_id: int, arr: str = "sonarr", season: int | None = None,
                       _: bool = Depends(require_api_key)):
    """Reset placeholders for all episodes of a series (or a specific season).
    Removes any active symlinks and restores the placeholder .mp4 file.
    Useful when a stream expires or files are deleted and Plex needs the placeholder back.
    """
    with get_conn() as db:
        if season is not None:
            rows = db.execute(
                "SELECT * FROM library WHERE arr=? AND arr_id=? AND season=?",
                (arr, arr_id, season)
            ).fetchall()
        else:
            rows = db.execute(
                "SELECT * FROM library WHERE arr=? AND arr_id=?",
                (arr, arr_id)
            ).fetchall()

    if not rows:
        raise HTTPException(404, f"No library entries found for {arr} id={arr_id}" +
                            (f" season={season}" if season is not None else ""))

    reset = 0
    skipped = 0
    for row in rows:
        ph = Path(row["placeholder"])
        try:
            # Remove symlink or existing file
            if ph.is_symlink() or ph.exists():
                ph.unlink(missing_ok=True)
            # Write fresh placeholder
            ph.parent.mkdir(parents=True, exist_ok=True)
            ph.write_bytes(_FAKE_MP4)
            # Mark any active streams as expired
            with get_conn() as db:
                db.execute(
                    "UPDATE streams SET status='reset' WHERE library_id=? AND status='active'",
                    (row["id"],)
                )
            reset += 1
        except Exception as e:
            log.warning("reset_placeholders: failed for %s: %s", ph, e)
            skipped += 1

    log.info("Reset placeholders: %d reset, %d skipped (arr=%s id=%s season=%s)",
             reset, skipped, arr, arr_id, season)
    return {"ok": True, "reset": reset, "skipped": skipped,
            "arr": arr, "arr_id": arr_id, "season": season}


@app.get("/api/debug/placeholders")
def debug_placeholders(_: bool = Depends(require_api_key)):
    """Scan the streams folder and compare against the library DB.
    Returns missing files, zero-byte files, and broken symlinks so
    you can diagnose why Plex cannot see placeholders.
    """
    with get_conn() as db:
        rows = db.execute("SELECT * FROM library ORDER BY arr,title,season,episode").fetchall()

    results = []
    for r in rows:
        ph   = Path(r["placeholder"])
        info = {
            "title":    r["title"],
            "arr":      r["arr"],
            "season":   r["season"],
            "episode":  r["episode"],
            "path":     str(ph),
            "exists":   ph.exists(),
            "is_symlink": ph.is_symlink(),
            "size":     ph.stat().st_size if ph.exists() else None,
            "problem":  None,
        }
        if ph.is_symlink() and not ph.exists():
            info["problem"] = "dead_symlink"
        elif not ph.exists():
            info["problem"] = "missing"
        elif ph.stat().st_size == 0:
            info["problem"] = "zero_bytes"
        results.append(info)

    problems = [r for r in results if r["problem"]]
    ok       = [r for r in results if not r["problem"]]
    return {
        "total":    len(results),
        "ok":       len(ok),
        "problems": problems,
        "streams_path": str(STREAMS_PATH),
    }

@app.post("/api/debug/placeholders/repair")
def repair_placeholders(_: bool = Depends(require_api_key)):
    """Re-write _FAKE_MP4 for every library entry whose placeholder is
    missing, zero-byte, or a dead symlink. Safe to call at any time."""
    with get_conn() as db:
        rows = db.execute("SELECT * FROM library").fetchall()
    fixed = skipped = 0
    for r in rows:
        ph = Path(r["placeholder"])
        if ph.is_symlink() and not ph.exists():
            ph.unlink(missing_ok=True)
        if not ph.exists() or ph.stat().st_size == 0:
            try:
                ph.parent.mkdir(parents=True, exist_ok=True)
                ph.write_bytes(_FAKE_MP4)
                fixed += 1
            except Exception as e:
                log.warning("repair placeholder %s: %s", ph, e)
        else:
            skipped += 1
    return {"fixed": fixed, "skipped": skipped}

# ── Spot check ───────────────────────────────────────────────────────────────

_spot_check_running = False

def _run_spot_check(limit: int = 0):
    """For each library item that is a plain placeholder (not yet a symlink):
      1. Trigger arr search
      2. Poll arr for import up to 3 minutes
      3. If found → symlink (activate_stream handles this via /webhook/arr)
      4. If not found → mark not_found in DB, delete placeholder
    Runs serially to avoid hammering arr with parallel searches.
    """
    global _spot_check_running
    if _spot_check_running:
        log.warning("Spot check already running — skipping")
        return {"skipped": True, "reason": "already running"}

    _spot_check_running = True
    try:
        with get_conn() as db:
            rows = db.execute(
                "SELECT * FROM library ORDER BY arr, title, season, episode"
            ).fetchall()

        if limit:
            rows = rows[:limit]

        checked = skipped = found = not_found_count = 0

        # Build list of items to check (skip symlinks, active streams, not_found)
        to_check = []
        with get_conn() as db:
            nf_ids = {r["id"] for r in db.execute("SELECT id FROM not_found").fetchall()}
            active_ids = {r["library_id"] for r in
                          db.execute("SELECT library_id FROM streams WHERE status='active'").fetchall()}

        for row in rows:
            lib_id = row["id"]
            ph     = Path(row["placeholder"])
            if ph.is_symlink() or lib_id in nf_ids or lib_id in active_ids:
                skipped += 1
                continue
            to_check.append(row)

        log.info("Spot check: %d items to check, %d skipped", len(to_check), skipped)

        # Phase 1: fire searches in batches of 5 with 2s between each
        # to avoid overwhelming Sonarr/Radarr API
        BATCH_SIZE  = 5
        BATCH_DELAY = 2  # seconds between batches

        checked = len(to_check)
        for i in range(0, len(to_check), BATCH_SIZE):
            batch = to_check[i:i + BATCH_SIZE]
            for row in batch:
                try:
                    _trigger_arr_search(row["arr"], row["arr_id"], row["season"], row["episode"])
                except Exception as e:
                    log.warning("Spot check search error for %s: %s", row["title"], e)
            log.info("Spot check: fired batch %d/%d",
                     min(i + BATCH_SIZE, len(to_check)), len(to_check))
            if i + BATCH_SIZE < len(to_check):
                time.sleep(BATCH_DELAY)

        log.info("Spot check: all %d searches fired — waiting 30s for imports", checked)

        # Phase 2: wait 30 seconds for arr to download + import
        time.sleep(30)

        # Phase 3: check each item once — arr webhook may have already symlinked them
        for row in to_check:
            lib_id  = row["id"]
            ph      = Path(row["placeholder"])
            arr     = row["arr"]
            arr_id  = row["arr_id"]
            season  = row["season"]
            episode = row["episode"]
            title   = row["title"]

            # Check if webhook already symlinked it
            if ph.is_symlink():
                found += 1
                continue

            # Check arr directly
            if arr == "sonarr":
                file_found = _get_episode_file_path(arr_id, season, episode)
            else:
                file_found = _get_movie_file_path(arr_id)

            if file_found:
                _immediate_symlink(lib_id, file_found)
                log.info("🔍 Spot check symlinked: %s → %s", title, file_found.name)
                found += 1
            else:
                # Not found — mark and remove placeholder
                with get_conn() as db:
                    db.execute("""
                        INSERT OR REPLACE INTO not_found
                        (id, arr, arr_id, media_type, title, season, episode, checked_at, reason)
                        VALUES (?,?,?,?,?,?,?,?,?)
                    """, (lib_id, arr, arr_id, row["media_type"], title,
                          season, episode, iso(now_utc()),
                          "No release found after search + 30s poll"))
                    db.execute("DELETE FROM streams WHERE library_id=?", (lib_id,))
                    db.execute("DELETE FROM library WHERE id=?", (lib_id,))
                try:
                    if ph.exists() or ph.is_symlink():
                        ph.unlink(missing_ok=True)
                except Exception as e:
                    log.warning("Spot check: could not delete placeholder %s: %s", ph, e)
                not_found_count += 1

        log.info("Spot check complete: checked=%d found=%d not_found=%d skipped=%d",
                 checked, found, not_found_count, skipped)
        return {
            "ok": True, "checked": checked, "found": found,
            "not_found": not_found_count, "skipped": skipped
        }
    finally:
        _spot_check_running = False


@app.post("/api/spot-check")
def spot_check(background_tasks: BackgroundTasks, limit: int = 0,
               _: bool = Depends(require_api_key)):
    """Run spot check in background. limit=0 means check all items."""
    if _spot_check_running:
        raise HTTPException(409, "Spot check already running")
    background_tasks.add_task(_run_spot_check, limit)
    return {"ok": True, "message": "Spot check started in background"}


@app.get("/api/spot-check/status")
def spot_check_status(_: bool = Depends(require_api_key)):
    return {"running": _spot_check_running}


@app.get("/api/not-found")
def list_not_found(_: bool = Depends(require_api_key)):
    with get_conn() as db:
        rows = db.execute(
            "SELECT * FROM not_found ORDER BY arr, title, season, episode"
        ).fetchall()
    return {"not_found": [dict(r) for r in rows]}


@app.delete("/api/not-found/{item_id}")
def clear_not_found(item_id: str, _: bool = Depends(require_api_key)):
    """Remove an item from the not_found list so it will be synced again."""
    with get_conn() as db:
        db.execute("DELETE FROM not_found WHERE id=?", (item_id,))
    return {"ok": True}


@app.delete("/api/not-found")
def clear_all_not_found(_: bool = Depends(require_api_key)):
    """Clear entire not_found list — all items will be re-synced."""
    with get_conn() as db:
        db.execute("DELETE FROM not_found")
    return {"ok": True}


# ── Pinned list ────────────────────────────────────────────────────────────────

@app.get("/api/pinned")
def list_pinned(_: bool = Depends(require_api_key)):
    with get_conn() as db:
        rows = db.execute("SELECT * FROM pinned ORDER BY title, season, episode").fetchall()
    return {"pinned": [dict(r) for r in rows]}


@app.post("/api/pinned/{library_id}")
def pin_item(library_id: str, note: str = "", _: bool = Depends(require_api_key)):
    """Pin a library item — auto re-adds to AllDebrid every 30 days on expiry."""
    with get_conn() as db:
        lib = db.execute("SELECT * FROM library WHERE id=?", (library_id,)).fetchone()
        if not lib:
            raise HTTPException(404, "Library item not found")
        db.execute("""
            INSERT OR REPLACE INTO pinned
            (id, arr, arr_id, media_type, title, season, episode, added_at, note)
            VALUES (?,?,?,?,?,?,?,?,?)
        """, (library_id, lib["arr"], lib["arr_id"], lib["media_type"],
              lib["title"], lib["season"], lib["episode"], iso(now_utc()), note))
    log.info("📌 Pinned: %s s%se%s", lib["title"], lib["season"], lib["episode"])
    return {"ok": True}


@app.delete("/api/pinned/{library_id}")
def unpin_item(library_id: str, _: bool = Depends(require_api_key)):
    with get_conn() as db:
        db.execute("DELETE FROM pinned WHERE id=?", (library_id,))
    return {"ok": True}


@app.delete("/api/pinned")
def unpin_all(_: bool = Depends(require_api_key)):
    with get_conn() as db:
        db.execute("DELETE FROM pinned")
    return {"ok": True}


# ── Decypharr API endpoints ───────────────────────────────────────────────────

@app.get("/api/decypharr/status")
def decypharr_status(_: bool = Depends(require_api_key)):
    with get_conn() as db:
        url   = get_setting(db, "decypharr_url")   or DECYPHARR_URL
        mount = get_setting(db, "decypharr_mount")  or DECYPHARR_MOUNT
    connected = False
    error = ""
    try:
        if _dc_client:
            torrents = _dc_client.list_all_torrents()
            connected = True
            count = len(list_torrents())
        else:
            count = len(list_torrents())
    except Exception as e:
        error = str(e)
        count = len(list_torrents())
    return {"url": url, "mount": mount, "connected": connected or bool(_dc_client),
            "torrents": count, "error": error}


@app.get("/api/decypharr/test")
def decypharr_test(_: bool = Depends(require_api_key)):
    if not _dc_client:
        return {"ok": False, "error": "Decypharr not configured — set DECYPHARR_URL"}
    try:
        torrents = _dc_client.list_all_torrents()
        return {"ok": True, "torrents": len(torrents)}
    except Exception as e:
        return {"ok": False, "error": str(e)}


@app.post("/api/decypharr/reload")
def decypharr_reload(_: bool = Depends(require_api_key)):
    if not _dc_client:
        raise HTTPException(503, "Decypharr not configured")
    count = _dc_client.reload_all()
    return {"ok": True, "count": count}


@app.post("/api/decypharr/reload/new")
def decypharr_reload_new(_: bool = Depends(require_api_key)):
    if not _dc_client:
        raise HTTPException(503, "Decypharr not configured")
    count = _dc_client.reload_new()
    return {"ok": True, "count": count}


# ── Rebuild placeholders ───────────────────────────────────────────────────────

@app.post("/api/library/rebuild-placeholders")
def rebuild_placeholders(arr: str = "all", _: bool = Depends(require_api_key)):
    """Re-write .strm placeholder files for all library items.
    Use after changing DEBRIDARR_BASE_URL or STRM_ROOT.
    """
    with get_conn() as db:
        if arr == "all":
            rows = db.execute("SELECT * FROM library").fetchall()
        else:
            rows = db.execute("SELECT * FROM library WHERE arr=?", (arr,)).fetchall()

    count = 0
    for row in rows:
        ph = Path(row["placeholder"])
        # Skip active symlinks — don't break live streams
        if ph.is_symlink() and ph.exists():
            continue
        try:
            ph.parent.mkdir(parents=True, exist_ok=True)
            if ph.exists() or ph.is_symlink():
                ph.unlink(missing_ok=True)
            if DEBRIDARR_BASE_URL:
                strm = ph.with_suffix(".strm")
                strm.write_text(f"{DEBRIDARR_BASE_URL}/proxy/{row['id']}\n")
                # Update DB if path changed
                if str(strm) != row["placeholder"]:
                    with get_conn() as db2:
                        db2.execute("UPDATE library SET placeholder=? WHERE id=?",
                                    (str(strm), row["id"]))
            else:
                ph.write_bytes(_FAKE_MP4)
            count += 1
        except Exception as e:
            log.warning("rebuild_placeholders: %s — %s", ph, e)

    log.info("Rebuilt %d placeholder(s) for arr=%s", count, arr)
    return {"ok": True, "count": count}


@app.get("/health")
def health():
    return {
        "ok":               True,
        "version":          app.version,
        "streams_path":     str(STREAMS_PATH),
        "sonarr_connected": bool(SONARR_URL and SONARR_API_KEY),
        "radarr_connected": bool(RADARR_URL and RADARR_API_KEY),
    }

@app.get("/api/settings")
def get_settings(_: bool = Depends(require_api_key)):
    with get_conn() as db:
        return {"settings": {r["key"]: r["value"] for r in db.execute("SELECT key,value FROM settings ORDER BY key")}}

@app.patch("/api/settings")
def patch_settings(patch: SettingsPatch, _: bool = Depends(require_api_key)):
    with get_conn() as db:
        for k, v in patch.settings.items():
            db.execute(
                "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (k, str(v))
            )
    # Update in-process globals so they take effect without a restart
    global SONARR_URL, SONARR_API_KEY, RADARR_URL, RADARR_API_KEY
    global TAUTULLI_URL, TAUTULLI_API_KEY
    global PLEX_URL, PLEX_TOKEN
    if "sonarr_url"        in patch.settings: SONARR_URL        = patch.settings["sonarr_url"].rstrip("/")
    if "sonarr_api_key"    in patch.settings: SONARR_API_KEY    = patch.settings["sonarr_api_key"]
    if "radarr_url"        in patch.settings: RADARR_URL        = patch.settings["radarr_url"].rstrip("/")
    if "radarr_api_key"    in patch.settings: RADARR_API_KEY    = patch.settings["radarr_api_key"]
    if "tautulli_url"      in patch.settings: TAUTULLI_URL      = patch.settings["tautulli_url"].rstrip("/")
    if "tautulli_api_key"  in patch.settings: TAUTULLI_API_KEY  = patch.settings["tautulli_api_key"]
    if "plex_url"          in patch.settings: PLEX_URL          = patch.settings["plex_url"].rstrip("/")
    if "plex_token"        in patch.settings: PLEX_TOKEN        = patch.settings["plex_token"]
    return get_settings(True)

# ── FUSE ──────────────────────────────────────────────────────────────────────
@app.get("/api/fuse")
def fuse_status(_: bool = Depends(require_api_key)):
    dfs_mounted  = False
    torrent_list = list_torrents()
    return {
        "dfs_mount":     "",
        "dfs_mounted":   dfs_mounted,
        "torrent_count": len(torrent_list),
        "torrents":      [{"name": t, "files": list_files(t)} for t in torrent_list],
    }



def _plex_stop_and_replay(session_key: str, rating_key: str, client_id: str):
    """Stop the current Plex session and tell the client to play the updated file.

    Called after a symlink is created mid-play so Plex picks up the real content.
    The client will re-open the file from the beginning — the symlink now points
    to the real file so it plays immediately.
    """
    with get_conn() as db:
        plex_url   = PLEX_URL   or get_setting(db, "plex_url")
        plex_token = PLEX_TOKEN or get_setting(db, "plex_token")
    if not plex_url or not plex_token:
        log.debug("Plex URL/token not configured — skipping session interrupt")
        return
    try:
        # Stop the current session
        stop_url = f"{plex_url}/player/playback/stop"
        r = httpx.get(stop_url, params={
            "X-Plex-Token": plex_token,
            "X-Plex-Client-Identifier": client_id,
            "commandID": "1",
        }, timeout=5)
        log.info("Plex stop session %s → %s", session_key, r.status_code)
        time.sleep(1)
        # Play the item again — Plex will re-read the symlink which now points to real file
        play_url = f"{plex_url}/player/playback/playMedia"
        r2 = httpx.get(play_url, params={
            "X-Plex-Token":             plex_token,
            "X-Plex-Client-Identifier": client_id,
            "key":                      f"/library/metadata/{rating_key}",
            "offset":                   "0",
            "commandID":                "2",
        }, timeout=5)
        log.info("Plex replay rating_key=%s → %s", rating_key, r2.status_code)
    except Exception as e:
        log.warning("Plex session interrupt failed: %s", e)


def _immediate_symlink(library_id: str, real: Path):
    """Replace placeholder with symlink to real file as fast as possible.
    Called from arr On Import webhook — the placeholder may already be playing
    in Plex, so replacing it at the same path causes Plex to serve real content
    mid-stream without the user needing to re-play.
    """
    try:
        with get_conn() as db:
            lib = db.execute("SELECT * FROM library WHERE id=?", (library_id,)).fetchone()
        if not lib:
            return
        lib = dict(lib)
        ph = Path(lib["placeholder"])
        # Atomic replace: unlink placeholder, symlink real file at same path
        if ph.is_symlink() or ph.exists():
            ph.unlink(missing_ok=True)
        ph.symlink_to(str(real))
        log.info("⚡ Immediate symlink [arr import]: %s → %s", ph.name, real.name)

        # Record stream
        stream_id = str(uuid.uuid4())
        now       = iso(now_utc())
        expires   = iso(now_utc() + timedelta(days=SYMLINK_TTL_DAYS))
        with get_conn() as db:
            existing = db.execute(
                "SELECT id FROM streams WHERE library_id=? AND status='active'",
                (library_id,)
            ).fetchone()
            if existing:
                db.execute("UPDATE streams SET source_path=?, symlink_path=?, last_seen_at=? WHERE id=?",
                           (str(real), str(ph), now, existing["id"]))
            else:
                db.execute("""
                    INSERT INTO streams(id,library_id,arr,arr_id,media_type,title,year,
                                       season,episode,source_path,symlink_path,
                                       created_at,expires_at,last_seen_at,status)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (stream_id, library_id, lib["arr"], lib["arr_id"], lib["media_type"],
                      lib["title"], lib["year"], lib["season"], lib["episode"],
                      str(real), str(ph), now, expires, now, "active"))
        _notify_arr_rescan(lib["arr"], lib["arr_id"])
        # Interrupt Plex session so it re-reads the symlink (now pointing to real file)
        session_key = lib.get("_session_key", "")
        rating_key  = lib.get("_rating_key", "")
        client_id   = lib.get("_client_id", "")
        if session_key and rating_key and client_id:
            _plex_stop_and_replay(session_key, rating_key, client_id)
    except Exception as e:
        log.error("_immediate_symlink failed: %s", e, exc_info=True)


def _background_symlink(library_id: str, real: Path):
    """Symlink a just-imported file immediately."""
    try:
        with get_conn() as db:
            lib = db.execute("SELECT * FROM library WHERE id=?", (library_id,)).fetchone()
            if not lib:
                return
            # Check if already active
            existing = db.execute(
                "SELECT * FROM streams WHERE library_id=? AND status='active'", (library_id,)
            ).fetchone()

        if existing:
            # Update symlink to new file
            ph = Path(lib["placeholder"])
            if ph.is_symlink() or ph.exists():
                ph.unlink(missing_ok=True)
            try:
                os.symlink(str(real), str(ph))
                with get_conn() as db:
                    db.execute("UPDATE streams SET source_path=?, last_seen_at=? WHERE id=?",
                               (str(real), iso(now_utc()), existing["id"]))
                log.info("🔄 Updated symlink [arr import]: %s → %s", ph.name, real.name)
            except OSError as e:
                log.error("arr import: symlink update failed: %s", e)
        else:
            lib_dict = dict(lib)
            link = _make_symlink(lib_dict, real)
            if link:
                stream_id = str(uuid.uuid4())
                now       = iso(now_utc())
                expires   = iso(now_utc() + timedelta(days=SYMLINK_TTL_DAYS))
                with get_conn() as db:
                    db.execute("""
                        INSERT INTO streams(id,library_id,arr,arr_id,media_type,title,year,
                                           season,episode,source_path,symlink_path,
                                           created_at,expires_at,last_seen_at,status)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    """, (stream_id, library_id, lib["arr"], lib["arr_id"], lib["media_type"],
                          lib["title"], lib["year"], lib["season"], lib["episode"],
                          str(real), str(link), now, expires, now, "active"))
                _notify_arr_rescan(lib["arr"], lib["arr_id"])
                log.info("✅ New symlink [arr import]: %s → %s", link.name, real.name)
            else:
                log.error("arr import: _make_symlink failed for %s", real)
    except Exception as e:
        log.error("_background_symlink failed: %s", e, exc_info=True)


@app.post("/webhook/tautulli")
async def tautulli_webhook(request: Request, background_tasks: BackgroundTasks):
    """Tautulli → Notification Agents → Webhook → Playback Start.

    Tautulli JSON body (Data tab):
      {"media_type":"{media_type}","title":"{title}","grandparent_title":"{grandparent_title}",
       "year":"{year}","grandparent_year":"{grandparent_year}",
       "parent_media_index":"{parent_media_index}","media_index":"{media_index}",
       "rating_key":"{rating_key}","themoviedb_id":"{themoviedb_id}",
       "thetvdb_id":"{thetvdb_id}","imdb_id":"{imdb_id}"}
    """
    try:
        payload = await request.json()
    except Exception:
        try:
            payload = dict(await request.form())
        except Exception:
            raise HTTPException(400, "Invalid payload")

    log.info("Tautulli webhook: %s", payload)

    if not payload:
        log.warning("Tautulli webhook: empty payload — check Tautulli JSON body configuration")
        return {"status": "ignored", "reason": "empty payload — check Tautulli webhook JSON body"}

    media_type = (payload.get("media_type") or "").strip().lower()
    title      = (payload.get("grandparent_title") or payload.get("title") or "").strip()
    year       = payload.get("year") or payload.get("grandparent_year")
    season     = payload.get("parent_media_index")
    episode    = payload.get("media_index")

    if media_type not in ("movie", "episode") or not title:
        log.warning("Tautulli webhook ignored — media_type=%r title=%r", media_type, title)
        return {"status": "ignored", "reason": f"media_type={media_type!r} title={title!r}"}

    try:
        year    = int(year)    if year    else None
        season  = int(season)  if season  else None
        episode = int(episode) if episode else None
    except (TypeError, ValueError):
        year = season = episode = None

    # Find matching library entry
    with get_conn() as db:
        lib_row = None
        if media_type == "episode" and title and season is not None and episode is not None:
            lib_row = db.execute(
                "SELECT * FROM library WHERE media_type='episode' AND title=? AND season=? AND episode=?",
                (title, season, episode)
            ).fetchone()
        elif media_type == "movie":
            lib_row = db.execute(
                "SELECT * FROM library WHERE media_type='movie' AND title=?",
                (title,)
            ).fetchone()
            if not lib_row and year:
                lib_row = db.execute(
                    "SELECT * FROM library WHERE media_type='movie' AND title=? AND year=?",
                    (title, year)
                ).fetchone()

    if not lib_row:
        # Try fuzzy match — Plex/Tautulli title may differ slightly from Sonarr title
        with get_conn() as db:
            if media_type == "episode" and season is not None and episode is not None:
                candidates = db.execute(
                    "SELECT * FROM library WHERE media_type='episode' AND season=? AND episode=?",
                    (season, episode)
                ).fetchall()
                # Match by normalised title
                title_n = "".join(c.lower() for c in title if c.isalnum())
                for c in candidates:
                    c_n = "".join(ch.lower() for ch in c["title"] if ch.isalnum())
                    if c_n == title_n or title_n in c_n or c_n in title_n:
                        lib_row = c
                        log.info("Tautulli webhook: fuzzy match %r → %r", title, c["title"])
                        break
            elif media_type == "movie":
                candidates = db.execute("SELECT * FROM library WHERE media_type='movie'").fetchall()
                title_n = "".join(c.lower() for c in title if c.isalnum())
                for c in candidates:
                    c_n = "".join(ch.lower() for ch in c["title"] if ch.isalnum())
                    if c_n == title_n:
                        lib_row = c
                        log.info("Tautulli webhook: fuzzy match %r → %r", title, c["title"])
                        break

    if not lib_row:
        log.warning("Tautulli webhook: no library match — media_type=%s title=%r s%se%s",
                    media_type, title, season, episode)
        return {"status": "ignored", "reason": f"no library match for {title!r}"}

    lib_id = lib_row["id"]

    # If already cached in proxy DB → nothing to do
    cached = _proxy_db.get(lib_id)
    if cached and cached.get("status") == "cached":
        log.info("Tautulli webhook: already cached for %r", title)
        return {"status": "cached", "library_id": lib_id}

    # Start background resolution — proxy keepalive stream is already running
    # (Plex opened the .strm, hit /proxy/{lib_id}, keepalive started)
    background_tasks.add_task(_resolve_for_proxy, lib_id)
    log.info("Tautulli webhook: queued proxy resolve for %r lib_id=%s", title, lib_id)
    return {"status": "resolving", "library_id": lib_id}


def _background_activate(library_id: str, session_key: str = "",
                         client_id: str = "", rating_key: str = ""):
    """Run activate_stream then pre-cache next 3 episodes for binging."""
    try:
        result = activate_stream(library_id,
                                 session_key=session_key,
                                 client_id=client_id,
                                 rating_key=rating_key)
        log.info("Background activation result: %s", result)
        _precache_next_episodes(library_id)
    except Exception as e:
        log.error("Background activation failed: %s", e, exc_info=True)


def _resolve_for_proxy(library_id: str):
    """Background resolution triggered when Plex opens a .strm file.
    Finds the file in FUSE, gets the AllDebrid CDN URL, marks proxy DB as
    cached so the keepalive stream stops and Plex re-requests to stream real content.
    """
    with get_conn() as db:
        lib = db.execute("SELECT * FROM library WHERE id=?", (library_id,)).fetchone()
    if not lib:
        _proxy_db.set_error(library_id, "not_found")
        return

    lib     = dict(lib)
    title   = lib["title"]
    year    = lib.get("year")
    season  = lib.get("season")
    episode = lib.get("episode")
    arr     = lib["arr"]
    arr_id  = lib["arr_id"]

    log.info("🔍 Resolving for proxy: %s s%se%s", title, season, episode)
    _proxy_db.set_resolving(library_id)

    # ── Instant path: already in Decypharr index ────────────────────────────
    fuse_match = _find_in_fuse(title, year, season, episode)
    if fuse_match:
        torrent_name, fname, fdata = fuse_match
        ad_link = fdata.get("l", "")
        if ad_link:
            _proxy_db.set_cached(library_id, ad_link, fname)
            log.info("⚡ Proxy resolved instantly: %s", fname)
            real = (_dc_client.get_file_path(torrent_name, fname) if _dc_client else None)
            _make_symlink(lib, real)
            _precache_next_episodes(library_id)
            return

    # ── Search path: trigger arr then poll FUSE every 0.5s ───────────────────
    _trigger_arr_search(arr, arr_id, season, episode)
    _create_fuse_symlinks_for_arr(arr, arr_id, title, year, season, episode)

    deadline = time.time() + 30
    while time.time() < deadline:
        time.sleep(0.5)
        # Prefer Decypharr incremental reload; fall back to AllDebrid FUSE
        if _dc_client:
            _dc_client.reload_new()

        fuse_match = _find_in_fuse(title, year, season, episode)
        if fuse_match:
            torrent_name, fname, fdata = fuse_match
            ad_link = fdata.get("l", "")
            if ad_link:
                _proxy_db.set_cached(library_id, ad_link, fname)
                log.info("✅ Proxy resolved after %.1fs: %s/%s",
                         30 - (deadline - time.time()), torrent_name, fname)
                real = (_dc_client.get_file_path(torrent_name, fname) if _dc_client else None)
                _make_symlink(lib, real)
                _precache_next_episodes(library_id)
                return

    log.warning("⏰ Proxy resolve timed out for %s", title)
    _proxy_db.set_error(library_id, "error")


def _precache_next_episodes(library_id: str, lookahead: int = 3):
    """After a play, pre-search and symlink the next N episodes.
    Spills into the next season if needed and it has been released.
    """
    with get_conn() as db:
        lib = db.execute("SELECT * FROM library WHERE id=?", (library_id,)).fetchone()
        if not lib or lib["media_type"] != "episode":
            return

        arr_id  = lib["arr_id"]
        season  = lib["season"]
        episode = lib["episode"]
        arr     = lib["arr"]

        # Find the next N episodes in the DB (same series, any season >= current)
        next_eps = db.execute("""
            SELECT * FROM library
            WHERE arr=? AND arr_id=? AND media_type='episode'
              AND (season > ? OR (season = ? AND episode > ?))
            ORDER BY season ASC, episode ASC
            LIMIT ?
        """, (arr, arr_id, season, season, episode, lookahead)).fetchall()

    if not next_eps:
        log.info("Pre-cache: no upcoming episodes found after s%se%s", season, episode)
        return

    log.info("Pre-cache: queuing %d episode(s) after s%se%s", len(next_eps), season, episode)

    for ep in next_eps:
        ep_id = ep["id"]
        ph    = Path(ep["placeholder"])

        # Skip if already symlinked
        if ph.is_symlink():
            log.debug("Pre-cache: s%se%s already symlinked — skipping",
                      ep["season"], ep["episode"])
            continue

        # Skip if already active
        with get_conn() as db:
            if db.execute("SELECT 1 FROM streams WHERE library_id=? AND status='active'",
                          (ep_id,)).fetchone():
                continue

        log.info("Pre-cache: activating s%se%s", ep["season"], ep["episode"])
        try:
            activate_stream(ep_id)
        except Exception as e:
            log.warning("Pre-cache: failed for s%se%s: %s",
                        ep["season"], ep["episode"], e)

# ── Sonarr / Radarr passthrough status ───────────────────────────────────────
@app.get("/api/arr/sonarr/status")
def sonarr_status(_: bool = Depends(require_api_key)):
    data = sonarr_get("/system/status")
    return {"connected": data is not None, "status": data}

@app.get("/api/arr/radarr/status")
def radarr_status(_: bool = Depends(require_api_key)):
    data = radarr_get("/system/status")
    return {"connected": data is not None, "status": data}

# ── Tautulli connection test ───────────────────────────────────────────────────
@app.get("/api/tautulli/status")
def tautulli_status(_: bool = Depends(require_api_key)):
    """
    Test the Tautulli connection by calling its API.
    Tautulli itself calls US (push webhook), so this only verifies
    we can reach Tautulli — not that the webhook is wired up.
    """
    with get_conn() as db:
        url = get_setting(db, "tautulli_url") or TAUTULLI_URL
        key = get_setting(db, "tautulli_api_key") or TAUTULLI_API_KEY

    if not url:
        return {"connected": False, "error": "Tautulli URL not configured"}

    try:
        params = {"apikey": key, "cmd": "get_server_info"} if key else {"cmd": "get_server_info"}
        r = httpx.get(f"{url}/api/v2", params=params, timeout=8)
        r.raise_for_status()
        data = r.json()
        # Tautulli wraps responses in {"response": {"result": "success", "data": {...}}}
        result = data.get("response", {})
        if result.get("result") == "success":
            info = result.get("data", {})
            return {
                "connected": True,
                "version":   info.get("tautulli_version") or info.get("version"),
                "server":    info.get("pms_name") or info.get("pms_identifier"),
            }
        else:
            # Got a response but result != success — likely wrong API key
            return {"connected": False, "error": result.get("message", "Unexpected response — check API key")}
    except httpx.ConnectError:
        return {"connected": False, "error": "Connection refused — is Tautulli running at that URL?"}
    except httpx.TimeoutException:
        return {"connected": False, "error": "Timed out — check URL and network"}
    except Exception as exc:
        return {"connected": False, "error": str(exc)}

@app.post("/api/webhook/test")
async def webhook_test(_: bool = Depends(require_api_key)):
    """
    Fire a synthetic Tautulli play event against our own webhook endpoint
    so the user can verify the inbound path works without needing Tautulli
    to actually trigger playback.
    Returns the result from the webhook handler.
    """
    # Use the first active library item we have as the test subject
    with get_conn() as db:
        row = db.execute(
            "SELECT * FROM library ORDER BY synced_at DESC LIMIT 1"
        ).fetchone()

    if not row:
        return {"ok": False, "error": "No library items yet — run a sync first"}

    # Build a realistic fake Tautulli payload
    if row["media_type"] == "episode":
        payload = {
            "event":              "play",
            "media_type":         "episode",
            "file":               row["placeholder"],
            "grandparent_title":  row["title"],
            "parent_media_index": row["season"],
            "media_index":        row["episode"],
            "title":              row["title"],
            "year":               row["year"],
        }
    else:
        payload = {
            "event":      "play",
            "media_type": "movie",
            "file":       row["placeholder"],
            "title":      row["title"],
            "year":       row["year"],
        }

    try:
        r = httpx.post(
            "http://127.0.0.1:" + str(os.getenv("PORT", "7474")) + "/webhook/tautulli",
            json=payload, timeout=15,
        )
        try:
            data = r.json()
        except Exception:
            data = {"raw": r.text[:300], "status_code": r.status_code}
        return {"ok": r.status_code < 400, "test_item": row["title"],
                "webhook_response": data, "status_code": r.status_code}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}

# ── Browse arr catalogues (without importing everything) ─────────────────────
@app.get("/api/arr/sonarr/series")
def sonarr_series(_: bool = Depends(require_api_key)):
    """Return all series from Sonarr, with a flag for whether each is in our library."""
    data = sonarr_get("/series") or []
    with get_conn() as db:
        imported = set(
            r["arr_id"] for r in db.execute("SELECT arr_id FROM library WHERE arr='sonarr'").fetchall()
        )
    result = []
    for s in sorted(data, key=lambda x: x.get("sortTitle") or x.get("title", "")):
        result.append({
            "id":        s.get("id"),
            "title":     s.get("title"),
            "year":      s.get("year"),
            "status":    s.get("status"),
            "seasons":   len([se for se in s.get("seasons", []) if se.get("seasonNumber", 0) > 0]),
            "overview":  (s.get("overview") or "")[:200],
            "imported":  s.get("id") in imported,
        })
    return {"series": result}

@app.get("/api/arr/radarr/movies")
def radarr_movies(_: bool = Depends(require_api_key)):
    """Return all movies from Radarr, with a flag for whether each is in our library."""
    data = radarr_get("/movie") or []
    with get_conn() as db:
        imported = set(
            r["arr_id"] for r in db.execute("SELECT arr_id FROM library WHERE arr='radarr'").fetchall()
        )
    result = []
    for m in sorted(data, key=lambda x: x.get("sortTitle") or x.get("title", "")):
        result.append({
            "id":       m.get("id"),
            "title":    m.get("title"),
            "year":     m.get("year"),
            "status":   m.get("status"),
            "overview": (m.get("overview") or "")[:200],
            "imported": m.get("id") in imported,
        })
    return {"movies": result}

class LibraryAddItem(BaseModel):
    arr:    Literal["sonarr", "radarr"]
    arr_id: int

@app.post("/api/library/add")
def library_add(item: LibraryAddItem, _: bool = Depends(require_api_key)):
    """Import a single series or movie from an arr into the library and create placeholders."""
    with get_conn() as db:
        if item.arr == "sonarr":
            series = sonarr_get(f"/series/{item.arr_id}")
            if not series:
                raise HTTPException(404, "Series not found in Sonarr")
            title     = series.get("title", "")
            year      = series.get("year")
            plot      = series.get("overview", "")
            status    = series.get("status", "")
            studio    = series.get("network") or ""
            genres    = series.get("genres", [])
            premiered = (series.get("firstAired") or "")[:10]
            tvdb_id   = series.get("tvdbId")
            imdb_id   = series.get("imdbId")
            tmdb_id   = series.get("tmdbId")

            show_folder = STREAMS_PATH / "sonarr" / safe(title)
            show_folder.mkdir(parents=True, exist_ok=True)
            write_tvshow_nfo(show_folder, title, year, tvdb_id, tmdb_id, imdb_id,
                             plot=plot, premiered=premiered, status=status,
                             studio=studio, genres=genres)

            episodes = sonarr_get("/episode", {"seriesId": item.arr_id}) or []
            count = 0
            for ep in episodes:
                if not ep.get("monitored"):
                    continue
                s        = ep.get("seasonNumber")
                e        = ep.get("episodeNumber")
                ep_title = ep.get("title", "")
                ep_plot  = ep.get("overview", "")
                ep_aired = (ep.get("airDate") or "")[:10]
                tvdb_ep  = ep.get("tvdbId")
                tmdb_ep  = ep.get("tmdbId")
                lib_id   = str(uuid.uuid5(uuid.NAMESPACE_URL, f"sonarr:{item.arr_id}:{s}:{e}"))
                ph       = placeholder_path("sonarr", "episode", title, year, s, e)
                ensure_placeholder(ph)
                write_episode_nfo(ph, ep_title, title, s, e,
                                  tvdb_ep_id=tvdb_ep, tmdb_ep_id=tmdb_ep,
                                  plot=ep_plot, aired=ep_aired)
                db.execute("""
                    INSERT INTO library(id,arr,arr_id,media_type,title,year,season,episode,placeholder,synced_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(id) DO UPDATE SET
                      title=excluded.title, year=excluded.year,
                      placeholder=excluded.placeholder, synced_at=excluded.synced_at
                """, (lib_id, "sonarr", item.arr_id, "episode", title, year, s, e, str(ph), iso(now_utc())))
                count += 1
            return {"ok": True, "arr": "sonarr", "title": title, "episodes_added": count}

        else:  # radarr
            movie = radarr_get(f"/movie/{item.arr_id}")
            if not movie:
                raise HTTPException(404, "Movie not found in Radarr")
            title     = movie.get("title", "")
            year      = movie.get("year")
            plot      = movie.get("overview", "")
            premiered = (movie.get("inCinemas") or movie.get("digitalRelease") or "")[:10]
            studio    = movie.get("studio") or ""
            genres    = movie.get("genres", [])
            tmdb_id   = movie.get("tmdbId")
            imdb_id   = movie.get("imdbId")
            lib_id    = str(uuid.uuid5(uuid.NAMESPACE_URL, f"radarr:{item.arr_id}"))
            ph        = placeholder_path("radarr", "movie", title, year, None, None)
            ensure_placeholder(ph)
            write_movie_nfo(ph.parent, title, year, tmdb_id, imdb_id,
                            plot=plot, premiered=premiered, studio=studio, genres=genres)
            db.execute("""
                INSERT INTO library(id,arr,arr_id,media_type,title,year,season,episode,placeholder,synced_at)
                VALUES(?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET
                  title=excluded.title, year=excluded.year,
                  placeholder=excluded.placeholder, synced_at=excluded.synced_at
            """, (lib_id, "radarr", item.arr_id, "movie", title, year, None, None, str(ph), iso(now_utc())))
            return {"ok": True, "arr": "radarr", "title": title, "episodes_added": 1}

UI = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Debridarr</title>
<style>
/* ── Design tokens (matches original Debridarr palette) ── */
:root {
  --bg:       #10131a;
  --surface:  #171b24;
  --surface2: #1e2330;
  --border:   #2b3242;
  --btn:      #2c3445;
  --input-bg: #0e1118;
  --input-bd: #343b4d;
  --accent:   #4f8ef7;
  --accent2:  #6ea8ff;
  --green:    #3fb950;
  --orange:   #e3a135;
  --red:      #f85149;
  --text:     #e8e8e8;
  --sub:      #8892a4;
  --radius:   12px;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { background: var(--bg); color: var(--text); font-family: system-ui, Arial, sans-serif; font-size: 14px; min-height: 100vh; }

/* ── NAV ── */
nav { display: flex; gap: 8px; padding: 14px 20px; background: var(--surface); position: sticky; top: 0; z-index: 50; border-bottom: 1px solid var(--border); align-items: center; }
nav .logo { font-size: 15px; font-weight: 700; color: var(--accent2); margin-right: 8px; letter-spacing: -.3px; }
.nav-btn { background: transparent; color: var(--sub); border: 1px solid transparent; border-radius: 8px; padding: 7px 13px; cursor: pointer; font-size: 13px; transition: .15s; }
.nav-btn:hover { background: var(--btn); color: var(--text); }
.nav-btn.active { background: var(--accent); color: #fff; border-color: transparent; }
.nav-wizard { margin-left: auto; }

/* ── WIZARD OVERLAY ── */
#wizardOverlay { position: fixed; inset: 0; background: rgba(0,0,0,.7); z-index: 100; display: flex; align-items: center; justify-content: center; padding: 16px; }
#wizardBox { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); width: 100%; max-width: 620px; overflow: hidden; }
.wiz-header { padding: 22px 24px 0; }
.wiz-header h2 { font-size: 17px; font-weight: 700; }
.wiz-header p { color: var(--sub); font-size: 13px; margin-top: 5px; }
.wiz-pills { display: flex; gap: 0; padding: 0 24px; margin-top: 18px; border-bottom: 1px solid var(--border); overflow-x: auto; }
.wiz-pill { padding: 9px 14px; font-size: 12px; font-weight: 600; color: var(--sub); border-bottom: 2px solid transparent; white-space: nowrap; }
.wiz-pill.done   { color: var(--green); }
.wiz-pill.active { color: var(--accent2); border-bottom-color: var(--accent2); }
.wiz-body { padding: 22px 24px; min-height: 210px; }
.wiz-footer { padding: 14px 24px; border-top: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; }

/* ── TABS ── */
.tab { display: none; padding: 22px 20px; max-width: 1300px; margin: 0 auto; }
.tab.active { display: block; }

/* ── GENERIC COMPONENTS ── */
.card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 16px; margin-bottom: 14px; }
.row  { display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 14px; }
h1 { font-size: 20px; font-weight: 700; margin-bottom: 16px; }
h2 { font-size: 16px; font-weight: 700; margin-bottom: 4px; }
h3 { font-size: 11px; color: var(--sub); text-transform: uppercase; letter-spacing: .07em; margin-bottom: 10px; font-weight: 600; }
.top-row { display: flex; align-items: center; gap: 10px; margin-bottom: 18px; flex-wrap: wrap; }
.top-row h1 { margin: 0; }
.empty { color: var(--sub); text-align: center; padding: 40px 20px; font-size: 13px; }

/* ── BUTTONS ── */
button { background: var(--btn); color: var(--text); border: 0; border-radius: 8px; padding: 8px 13px; cursor: pointer; font-size: 13px; transition: opacity .15s, background .15s; white-space: nowrap; }
button:hover { opacity: .85; }
button:disabled { opacity: .4; cursor: not-allowed; }
button.primary { background: var(--accent); color: #fff; }
button.danger  { background: #3a1a1a; color: var(--red); border: 1px solid #5a2020; }
button.danger:hover { background: var(--red); color: #fff; }
button.ghost   { background: transparent; color: var(--sub); border: 1px solid var(--border); }
button.ghost:hover { color: var(--text); }
button.sm { padding: 5px 10px; font-size: 12px; border-radius: 6px; }

/* ── INPUTS ── */
input, select, textarea {
  width: 100%; box-sizing: border-box;
  background: var(--input-bg); color: var(--text);
  border: 1px solid var(--input-bd); border-radius: 8px;
  padding: 9px 11px; font-size: 13px; margin: 4px 0 10px;
  font-family: inherit;
}
input:focus, select:focus { outline: none; border-color: var(--accent); }
label { font-size: 12px; color: var(--sub); display: block; margin-bottom: 1px; }
.field-row { display: flex; gap: 8px; align-items: flex-end; }
.field-row input { margin-bottom: 0; flex: 1; }

/* ── BADGES ── */
.badge { display: inline-block; padding: 2px 8px; border-radius: 20px; font-size: 11px; font-weight: 700; letter-spacing: .02em; }
.badge-green  { background: #152a1e; color: var(--green); }
.badge-orange { background: #2d2008; color: var(--orange); }
.badge-red    { background: #2a1010; color: var(--red); }
.badge-blue   { background: #0d1e38; color: var(--accent2); }
.badge-gray   { background: var(--btn); color: var(--sub); }

/* ── STREAMS TABLE ── */
table { width: 100%; border-collapse: collapse; }
th { text-align: left; padding: 8px 10px; color: var(--sub); font-weight: 600; font-size: 11px; text-transform: uppercase; letter-spacing: .05em; border-bottom: 1px solid var(--border); }
td { padding: 9px 10px; border-bottom: 1px solid var(--border); font-size: 13px; vertical-align: middle; }
tr:last-child td { border-bottom: none; }
tr:hover td { background: rgba(255,255,255,.018); }
.mono { font-family: ui-monospace, monospace; font-size: 11px; color: var(--sub); word-break: break-all; }

/* ── STATUS ── */
.dot { display: inline-block; width: 7px; height: 7px; border-radius: 50%; margin-right: 6px; flex-shrink: 0; }
.dot-green  { background: var(--green); box-shadow: 0 0 5px var(--green); }
.dot-red    { background: var(--red); }
.dot-orange { background: var(--orange); }
.dot-gray   { background: var(--sub); }

/* ── MISC ── */
.spinner { display: inline-block; width: 12px; height: 12px; border: 2px solid rgba(255,255,255,.2); border-top-color: #fff; border-radius: 50%; animation: spin .6s linear infinite; vertical-align: middle; margin-right: 6px; }
@keyframes spin { to { transform: rotate(360deg); } }
.info-box { background: #0d1e30; border: 1px solid #1a3550; border-radius: 8px; padding: 11px 14px; font-size: 13px; color: #7ab8f5; margin: 10px 0; line-height: 1.6; }
.info-box code { background: rgba(0,0,0,.35); padding: 1px 5px; border-radius: 4px; font-family: ui-monospace, monospace; font-size: 11px; }
.success-box { background: var(--surface2); border: 1px solid var(--border); border-radius: var(--radius); padding: 28px; text-align: center; }
.success-box .big-icon { font-size: 42px; margin-bottom: 10px; }
.success-box h2 { color: var(--green); font-size: 17px; margin-bottom: 8px; }
.check-row { display: flex; align-items: flex-start; gap: 10px; padding: 9px 0; border-bottom: 1px solid var(--border); }
.check-row:last-child { border-bottom: none; }
.check-icon { font-size: 16px; margin-top: 1px; }
.check-label strong { display: block; font-size: 13px; }
.check-label span { color: var(--sub); font-size: 12px; }

/* ── LIBRARY CARDS ── */
.lib-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 14px; }
.lib-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); overflow: hidden; display: flex; flex-direction: column; transition: border-color .15s; }
.lib-card:hover { border-color: #3d4d66; }
.lib-card-header { padding: 14px 16px 10px; border-bottom: 1px solid var(--border); display: flex; align-items: flex-start; gap: 10px; }
.lib-card-icon { font-size: 26px; flex-shrink: 0; margin-top: 1px; }
.lib-card-meta { flex: 1; min-width: 0; }
.lib-card-meta h2 { font-size: 14px; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.lib-card-meta .sub { color: var(--sub); font-size: 12px; margin-top: 2px; display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.season-list { padding: 0; }
.season-row { border-bottom: 1px solid var(--border); }
.season-row:last-child { border-bottom: none; }
.season-header { display: flex; align-items: center; padding: 9px 16px; cursor: pointer; user-select: none; gap: 8px; }
.season-header:hover { background: var(--surface2); }
.season-chevron { color: var(--sub); font-size: 11px; margin-left: auto; transition: transform .2s; }
.season-chevron.open { transform: rotate(90deg); }
.season-label { font-size: 13px; font-weight: 600; }
.season-eps-count { color: var(--sub); font-size: 12px; }
.ep-list { display: none; background: var(--input-bg); }
.ep-list.open { display: block; }
.ep-row { display: flex; align-items: center; gap: 8px; padding: 7px 16px 7px 28px; border-top: 1px solid var(--border); font-size: 12px; }
.ep-row:hover { background: rgba(255,255,255,.03); }
.ep-num { color: var(--sub); font-family: ui-monospace, monospace; font-size: 11px; min-width: 44px; flex-shrink: 0; }
.ep-title { flex: 1; color: var(--text); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ep-status { flex-shrink: 0; }
.lib-card-footer { padding: 10px 16px; margin-top: auto; display: flex; align-items: center; justify-content: space-between; border-top: 1px solid var(--border); background: var(--surface2); }
.lib-search { background: var(--input-bg); border: 1px solid var(--input-bd); border-radius: 8px; padding: 7px 11px; color: var(--text); font-size: 13px; width: 220px; margin: 0; }
.lib-search:focus { outline: none; border-color: var(--accent); }
.progress-bar { height: 3px; background: var(--border); border-radius: 2px; overflow: hidden; margin-top: 6px; }
.progress-fill { height: 100%; background: var(--accent); border-radius: 2px; transition: width .3s; }

/* ── PICKER MODAL ── */
#pickerOverlay { position: fixed; inset: 0; background: rgba(0,0,0,.7); z-index: 90; display: none; align-items: center; justify-content: center; padding: 16px; }
#pickerOverlay.open { display: flex; }
#pickerBox { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); width: 100%; max-width: 560px; max-height: 80vh; display: flex; flex-direction: column; overflow: hidden; }
.picker-header { padding: 16px 18px; border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 10px; }
.picker-header h2 { font-size: 15px; flex: 1; }
.picker-tabs { display: flex; border-bottom: 1px solid var(--border); }
.picker-tab { flex: 1; padding: 9px; text-align: center; font-size: 13px; font-weight: 600; color: var(--sub); cursor: pointer; border-bottom: 2px solid transparent; background: transparent; border-radius: 0; }
.picker-tab:hover { color: var(--text); background: var(--surface2); }
.picker-tab.active { color: var(--accent2); border-bottom-color: var(--accent2); }
.picker-search { padding: 10px 14px; border-bottom: 1px solid var(--border); }
.picker-search input { margin: 0; }
.picker-list { overflow-y: auto; flex: 1; }
.picker-item { display: flex; align-items: center; gap: 10px; padding: 10px 16px; border-bottom: 1px solid var(--border); cursor: pointer; transition: background .1s; }
.picker-item:last-child { border-bottom: none; }
.picker-item:hover { background: var(--surface2); }
.picker-item.imported { opacity: .5; cursor: default; }
.picker-item-icon { font-size: 20px; flex-shrink: 0; }
.picker-item-meta { flex: 1; min-width: 0; }
.picker-item-meta strong { display: block; font-size: 13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.picker-item-meta span { font-size: 11px; color: var(--sub); }
.picker-item-action { flex-shrink: 0; }
.picker-empty { color: var(--sub); text-align: center; padding: 30px; font-size: 13px; }
.picker-footer { padding: 12px 16px; border-top: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; font-size: 12px; color: var(--sub); }
</style>
</head>
<body>

<!-- ── WIZARD OVERLAY ── -->
<div id="wizardOverlay">
<div id="wizardBox">
  <div class="wiz-header">
    <h2>⚡ Welcome to Debridarr</h2>
    <p>Let's get you set up in a few quick steps.</p>
  </div>
  <div class="wiz-pills" id="wizPills"></div>
  <div class="wiz-body"   id="wizBody"></div>
  <div class="wiz-footer">
    <button class="ghost" id="wizBack" onclick="wizNav(-1)">← Back</button>
    <span id="wizHint"></span>
    <button class="primary" id="wizNext" onclick="wizNav(1)">Next →</button>
  </div>
</div>
</div>

<!-- ── NAV ── -->
<nav>
  <span class="logo">⚡ Debridarr</span>
  <button class="nav-btn active" onclick="show('streams')">Streams</button>
  <button class="nav-btn"        onclick="show('library')">Library</button>
  <button class="nav-btn"        onclick="show('connections')">Connections</button>
  <button class="nav-btn"        onclick="show('decypharr')">Decypharr</button>
  <button class="nav-btn nav-wizard" onclick="openWizard()">Setup Wizard</button>
</nav>

<!-- ══ STREAMS ══ -->
<section id="streams" class="tab active">
  <div class="top-row">
    <h1>Streams</h1>
    <button onclick="loadStreams('active')">Refresh</button>
    <button onclick="loadStreams('all')" class="ghost">Show All</button>
    <button onclick="runCleanup()" class="danger">Run Expiry Cleanup</button>
  </div>
  <div class="card" style="padding:0;overflow:hidden">
    <div id="streamsTable"><div class="empty">Loading…</div></div>
  </div>
</section>

<!-- ══ LIBRARY ══ -->
<!-- ══ PICKER MODAL ══ -->
<div id="pickerOverlay">
  <div id="pickerBox">
    <div class="picker-header">
      <h2>Add to Library</h2>
      <button class="ghost sm" onclick="closePicker()">✕ Close</button>
    </div>
    <div class="picker-tabs">
      <button class="picker-tab active" id="ptabSonarr" onclick="switchPickerTab('sonarr')">📺 TV Shows (Sonarr)</button>
      <button class="picker-tab"        id="ptabRadarr" onclick="switchPickerTab('radarr')">🎬 Movies (Radarr)</button>
    </div>
    <div class="picker-search">
      <input id="pickerSearch" placeholder="Filter…" oninput="filterPicker()" style="margin:0">
    </div>
    <div class="picker-list" id="pickerList"><div class="picker-empty">Loading…</div></div>
    <div class="picker-footer">
      <span id="pickerCount"></span>
      <span style="color:var(--sub)">Greyed = already in library</span>
    </div>
  </div>
</div>

<section id="library" class="tab">
  <div class="top-row">
    <h1>Library</h1>
    <input class="lib-search" id="libSearch" placeholder="Search titles…" oninput="filterLibrary()" style="margin:0">
    <select id="libFilter" onchange="loadLibrary()" style="width:auto;margin:0">
      <option value="all">All</option>
      <option value="sonarr">TV Shows</option>
      <option value="radarr">Movies</option>
    </select>
    <button onclick="loadLibrary()">Refresh</button>
    <button onclick="openPicker()" class="primary">+ Add Item</button>
    <button onclick="triggerSync()" class="ghost">Sync All</button>
  </div>
  <div id="libStats" style="color:var(--sub);font-size:12px;margin-bottom:14px"></div>
  <div id="libraryGrid"><div class="empty">Loading…</div></div>
</section>

<!-- ══ CONNECTIONS ══ -->
<section id="connections" class="tab">
  <h1>Connections</h1>
  <div class="row">
    <div class="card" style="flex:1 1 260px">
      <h3>Sonarr</h3>
      <div id="sonarrStatus" style="margin-bottom:10px;font-size:13px"></div>
      <label>URL</label><input id="sonarrUrl" placeholder="http://sonarr:8989">
      <label>API Key</label><input id="sonarrKey" type="password" placeholder="API key">
      <button class="primary" onclick="saveArr('sonarr')">Save &amp; Test</button>
    </div>
    <div class="card" style="flex:1 1 260px">
      <h3>Radarr</h3>
      <div id="radarrStatus" style="margin-bottom:10px;font-size:13px"></div>
      <label>URL</label><input id="radarrUrl" placeholder="http://radarr:7878">
      <label>API Key</label><input id="radarrKey" type="password" placeholder="API key">
      <button class="primary" onclick="saveArr('radarr')">Save &amp; Test</button>
    </div>
    <div class="card" style="flex:1 1 260px">
      <h3>Tautulli</h3>
      <div id="tautulliStatus" style="margin-bottom:10px;font-size:13px"></div>
      <label>Tautulli URL</label>
      <input id="tautulliUrl" placeholder="http://tautulli:8181">
      <label>API Key <span style="color:var(--sub);font-size:11px">(Settings → Web Interface)</span></label>
      <input id="tautulliApiKey" type="password" placeholder="API key">
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px">
        <button onclick="saveTautulli()">Save &amp; Test</button>
        <button class="ghost" onclick="testWebhook()" title="Fire a fake play event through the webhook to verify the full flow">Test Webhook Flow</button>
      </div>
      <div id="webhookTestResult" style="font-size:12px;min-height:16px"></div>
      <div style="border-top:1px solid var(--border);margin:10px 0 8px"></div>
      <p style="color:var(--sub);font-size:12px;margin-bottom:6px">Playback Start webhook URL — paste this into Tautulli:</p>
      <div style="display:flex;align-items:center;gap:6px">
        <div class="mono" id="webhookUrl2" style="font-size:11px;word-break:break-all;color:var(--accent2);flex:1"></div>
        <button class="sm ghost" id="copyWebhookBtn" onclick="copyWebhookUrl()">Copy</button>
      </div>
    </div>
  </div>
  <div class="card" style="max-width:340px">
    <h3>Stream TTL</h3>
    <label>Days before symlink expires and reverts to placeholder</label>
    <div class="field-row">
      <input id="ttlDays" type="number" min="1" max="365" value="30" style="width:100px">
      <button onclick="saveTtl()">Save</button>
    </div>
  </div>
</section>

<!-- ══ DECYPHARR ══ -->
<section id="decypharr" class="tab">
  <div class="top-row">
    <h1>Decypharr</h1>
    <button onclick="loadDecypharr()">Refresh</button>
  </div>
  <div class="card" style="max-width:500px">
    <h3>Connection</h3>
    <label>Decypharr URL</label>
    <input id="dcUrl" placeholder="http://decypharr:8282">
    <label style="margin-top:10px">API Token <span style="color:var(--sub);font-size:11px">(Settings → Auth in Decypharr)</span></label>
    <input id="dcToken" type="password" placeholder="leave blank if auth disabled">
    <label style="margin-top:10px">Mount Path <span style="color:var(--sub);font-size:11px">(e.g. /mnt/decypharr/__all__ — enables direct file access)</span></label>
    <input id="dcMount" placeholder="/mnt/decypharr/__all__">
    <div style="margin-top:14px;display:flex;gap:8px">
      <button onclick="saveDcSettings()">Save</button>
      <button onclick="testDcConnection()" class="ghost">Test Connection</button>
    </div>
    <div id="dcStatus" style="margin-top:10px;font-size:13px"></div>
  </div>
  <div class="card" style="max-width:500px;margin-top:16px">
    <h3>Torrent Index</h3>
    <div id="dcIndexStatus" style="font-size:13px;margin-bottom:12px;color:var(--sub)">Loading…</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button onclick="dcReload()">🔄 Reload All</button>
      <button onclick="dcReloadNew()" class="ghost">⚡ Reload New</button>
    </div>
  </div>
  <div class="card" style="max-width:500px;margin-top:16px">
    <h3>Placeholders</h3>
    <p style="color:var(--sub);font-size:13px;margin-bottom:12px">Rebuild .strm placeholder files for all library items. Use after changing STRM_ROOT or DEBRIDARR_BASE_URL.</p>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button onclick="rebuildPlaceholders('sonarr')" class="ghost">↺ Rebuild TV Placeholders</button>
      <button onclick="rebuildPlaceholders('radarr')" class="ghost">↺ Rebuild Movie Placeholders</button>
      <button onclick="rebuildPlaceholders('all')">↺ Rebuild All</button>
    </div>
    <div id="rebuildStatus" style="margin-top:10px;font-size:13px"></div>
  </div>
</section>


"""
