"""
Debridarr – rebuild
===================
Flow:
  1. Startup → scan Sonarr & Radarr → build library, create empty placeholder files for known media.
  2. Tautulli webhook fires when a user presses Play on a placeholder.
  3. Handler searches Sonarr/Radarr for the real file path on the FUSE mount.
  4. Symlink is created: placeholder path → real FUSE file.
  5. Sonarr/Radarr are notified (rescan) so they see the real file.
  6. After 30 days the symlink expires: symlink reverts to empty placeholder,
     Sonarr/Radarr are told the file is gone (manual unmonitor / rescan).
"""

import os, sqlite3, uuid, shutil, httpx, logging, json, time
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional, Literal, Any

from fastapi import FastAPI, HTTPException, Request, Header, Depends, BackgroundTasks
from fastapi.responses import HTMLResponse, JSONResponse

import asyncio
import os as _os

from app.alldebrid import AllDebridClient
from app.fuse_mount import (
    FUSE_AVAILABLE,
    start_fuse_mount, stop_fuse_mount,
    register_torrent,
    update_dfs_settings, get_dfs_settings,
)

# DFS FUSE mount point — AllDebrid chunk-cache filesystem
DFS_FUSE_MOUNT = _os.getenv("DFS_FUSE_MOUNT", "/mnt/alldebrid")

from pydantic import BaseModel, Field

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s – %(message)s")
log = logging.getLogger("debridarr")

# ── Env config ────────────────────────────────────────────────────────────────
DB_PATH           = os.getenv("DB_PATH",          "/data/debridarr.db")
STREAMS_PATH      = Path(os.getenv("STREAMS_PATH", "/streams"))
SYMLINK_TTL_DAYS  = int(os.getenv("SYMLINK_TTL_DAYS", "30"))
PLACEHOLDER_EXT   = os.getenv("PLACEHOLDER_EXT", ".mp4")          # must be mp4 for Tautulli to trigger play
API_KEY           = os.getenv("API_KEY", "").strip()

SONARR_URL        = os.getenv("SONARR_URL", "").rstrip("/")
SONARR_API_KEY    = os.getenv("SONARR_API_KEY", "")
RADARR_URL        = os.getenv("RADARR_URL", "").rstrip("/")
RADARR_API_KEY    = os.getenv("RADARR_API_KEY", "")

TAUTULLI_URL      = os.getenv("TAUTULLI_URL", "").rstrip("/")
TAUTULLI_API_KEY  = os.getenv("TAUTULLI_API_KEY", "")

ALLDEBRID_API_KEY = os.getenv("ALLDEBRID_API_KEY", "")
DFS_CACHE_DIR     = os.getenv("DFS_CACHE_DIR", "/cache/dfs")
DFS_CACHE_SIZE_GB = int(os.getenv("DFS_CACHE_SIZE_GB", "50"))
DFS_CACHE_TTL_H   = int(os.getenv("DFS_CACHE_TTL_H", "12"))
DFS_CHUNK_MB      = int(os.getenv("DFS_CHUNK_MB", "32"))
DFS_READ_AHEAD_MB = int(os.getenv("DFS_READ_AHEAD_MB", "128"))
DFS_CLEANUP_MIN   = int(os.getenv("DFS_CLEANUP_MIN", "20"))

# ── DB helpers ────────────────────────────────────────────────────────────────

import struct as _struct

def _load_placeholder() -> bytes:
    """Load the bundled placeholder.mp4, falling back to a minimal valid MP4 stub."""
    candidate = Path(__file__).parent / "placeholder.mp4"
    if candidate.exists():
        return candidate.read_bytes()
    # Fallback: minimal valid mp4 (silent, 1 s) so Plex/Tautulli recognise the file
    def box(t, p):
        return _struct.pack(">I", 8 + len(p)) + t + p
    ftyp = box(b"ftyp", b"mp42\x00\x00\x00\x00mp42isom")
    mvhd = box(b"mvhd",
        b"\x00" * 12
        + _struct.pack(">I", 1000) + _struct.pack(">I", 1000)
        + _struct.pack(">I", 0x00010000) + _struct.pack(">H", 0x0100)
        + b"\x00" * 10
        + _struct.pack(">9i", 0x00010000,0,0, 0,0x00010000,0, 0,0,0x40000000)
        + b"\x00" * 24 + _struct.pack(">I", 2)
    )
    return ftyp + box(b"moov", mvhd)

_FAKE_MP4 = _load_placeholder()

def get_conn():
    c = sqlite3.connect(DB_PATH, timeout=10)  # wait up to 10s if DB is locked
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    c.execute("PRAGMA wal_autocheckpoint=100")
    c.execute("PRAGMA synchronous=NORMAL")
    return c

def init_db():
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    STREAMS_PATH.mkdir(parents=True, exist_ok=True)
    with get_conn() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS settings (
          key   TEXT PRIMARY KEY,
          value TEXT NOT NULL
        );

        -- Library: every known title from Sonarr/Radarr
        CREATE TABLE IF NOT EXISTS library (
          id            TEXT PRIMARY KEY,
          arr           TEXT NOT NULL,          -- 'sonarr' | 'radarr'
          arr_id        INTEGER NOT NULL,
          media_type    TEXT NOT NULL,           -- 'movie' | 'episode'
          title         TEXT NOT NULL,
          year          INTEGER,
          season        INTEGER,
          episode       INTEGER,
          placeholder   TEXT NOT NULL,          -- empty .mp4 file path
          synced_at     TEXT NOT NULL,
          UNIQUE(arr, arr_id, season, episode)
        );
        CREATE INDEX IF NOT EXISTS idx_lib_arr  ON library(arr, arr_id);

        -- Active streams: placeholder has been replaced by a real symlink
        CREATE TABLE IF NOT EXISTS streams (
          id              TEXT PRIMARY KEY,
          library_id      TEXT REFERENCES library(id),
          arr             TEXT NOT NULL,
          arr_id          INTEGER,
          media_type      TEXT NOT NULL,
          title           TEXT NOT NULL,
          year            INTEGER,
          season          INTEGER,
          episode         INTEGER,
          source_path     TEXT NOT NULL,        -- real file on FUSE
          symlink_path    TEXT NOT NULL,        -- path of the symlink (==placeholder)
          created_at      TEXT NOT NULL,
          expires_at      TEXT NOT NULL,
          last_seen_at    TEXT NOT NULL,
          status          TEXT NOT NULL DEFAULT 'active'
        );
        CREATE INDEX IF NOT EXISTS idx_streams_expires ON streams(expires_at);
        CREATE INDEX IF NOT EXISTS idx_streams_status  ON streams(status);
        """)

        defaults = {
            "streams_path":      str(STREAMS_PATH),
            "symlink_ttl_days":  str(SYMLINK_TTL_DAYS),
            "placeholder_ext":   PLACEHOLDER_EXT,
            "sonarr_url":        SONARR_URL,
            "sonarr_api_key":    SONARR_API_KEY,
            "radarr_url":        RADARR_URL,
            "radarr_api_key":    RADARR_API_KEY,
            "tautulli_url":      TAUTULLI_URL,
            "tautulli_api_key":  TAUTULLI_API_KEY,
            # All-Debrid / DFS cache
            "alldebrid_api_key": ALLDEBRID_API_KEY,
            "dfs_cache_dir":     DFS_CACHE_DIR,
            "dfs_cache_size_gb": str(DFS_CACHE_SIZE_GB),
            "dfs_cache_ttl_h":   str(DFS_CACHE_TTL_H),
            "dfs_chunk_mb":      str(DFS_CHUNK_MB),
            "dfs_read_ahead_mb": str(DFS_READ_AHEAD_MB),
            "dfs_cleanup_min":   str(DFS_CLEANUP_MIN),
        }
        for k, v in defaults.items():
            if v:
                # Env var is set — seed/overwrite (env takes precedence)
                db.execute(
                    "INSERT INTO settings(key,value) VALUES(?,?) "
                    "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (k, v)
                )
            else:
                # Env var is blank — seed only if the row doesn't exist yet,
                # so a value saved through the UI is never overwritten with "".
                db.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v))

# ── Utility ───────────────────────────────────────────────────────────────────
def now_utc() -> datetime:
    return datetime.now(timezone.utc)

def iso(dt: datetime) -> str:
    return dt.isoformat()

def from_iso(s: str) -> datetime:
    return datetime.fromisoformat(s.replace("Z", "+00:00"))

def safe(value: str) -> str:
    keep = "".join(c if c.isalnum() or c in " ._-()[]" else " " for c in (value or "").strip())
    return " ".join(keep.split()) or "Unknown"

def get_setting(db, key: str, fallback: str = "") -> str:
    row = db.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row else fallback

# ── ARR HTTP helpers ──────────────────────────────────────────────────────────
def arr_headers(api_key: str) -> dict:
    return {"X-Api-Key": api_key, "Accept": "application/json"}

def sonarr_get(path: str, params: dict | None = None):
    with get_conn() as _db:
        url = SONARR_URL or get_setting(_db, "sonarr_url")
        key = SONARR_API_KEY or get_setting(_db, "sonarr_api_key")
    if not url or not key:
        return None
    try:
        r = httpx.get(f"{url}/api/v3{path}", headers=arr_headers(key), params=params, timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.warning("Sonarr GET %s failed: %s", path, e)
        return None

def radarr_get(path: str, params: dict | None = None):
    with get_conn() as _db:
        url = RADARR_URL or get_setting(_db, "radarr_url")
        key = RADARR_API_KEY or get_setting(_db, "radarr_api_key")
    if not url or not key:
        return None
    try:
        r = httpx.get(f"{url}/api/v3{path}", headers=arr_headers(key), params=params, timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.warning("Radarr GET %s failed: %s", path, e)
        return None

def sonarr_post(path: str, payload: dict):
    with get_conn() as _db:
        url = SONARR_URL or get_setting(_db, "sonarr_url")
        key = SONARR_API_KEY or get_setting(_db, "sonarr_api_key")
    if not url or not key:
        return None
    try:
        r = httpx.post(f"{url}/api/v3{path}", headers=arr_headers(key), json=payload, timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.warning("Sonarr POST %s failed: %s", path, e)
        return None

def radarr_post(path: str, payload: dict):
    with get_conn() as _db:
        url = RADARR_URL or get_setting(_db, "radarr_url")
        key = RADARR_API_KEY or get_setting(_db, "radarr_api_key")
    if not url or not key:
        return None
    try:
        r = httpx.post(f"{url}/api/v3{path}", headers=arr_headers(key), json=payload, timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.warning("Radarr POST %s failed: %s", path, e)
        return None

def sonarr_put(path: str, payload: dict):
    with get_conn() as _db:
        url = SONARR_URL or get_setting(_db, "sonarr_url")
        key = SONARR_API_KEY or get_setting(_db, "sonarr_api_key")
    if not url or not key:
        return None
    try:
        r = httpx.put(f"{url}/api/v3{path}", headers=arr_headers(key), json=payload, timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.warning("Sonarr PUT %s failed: %s", path, e)
        return None

def radarr_put(path: str, payload: dict):
    with get_conn() as _db:
        url = RADARR_URL or get_setting(_db, "radarr_url")
        key = RADARR_API_KEY or get_setting(_db, "radarr_api_key")
    if not url or not key:
        return None
    try:
        r = httpx.put(f"{url}/api/v3{path}", headers=arr_headers(key), json=payload, timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.warning("Radarr PUT %s failed: %s", path, e)
        return None

# ── Placeholder helpers ───────────────────────────────────────────────────────
def placeholder_path(arr: str, media_type: str, title: str, year: int | None,
                     season: int | None, episode: int | None) -> Path:
    t = safe(title)
    ext = PLACEHOLDER_EXT
    if media_type == "movie":
        folder = f"{t} ({year})" if year else t
        return STREAMS_PATH / "radarr" / folder / f"{folder}{ext}"
    s = int(season or 0)
    e = int(episode or 0)
    return STREAMS_PATH / "sonarr" / t / f"Season {s:02d}" / f"{t} - S{s:02d}E{e:02d}{ext}"

def ensure_placeholder(path: Path):
    """Write _FAKE_MP4 at path unless a real non-empty file already exists there.

    Handles three cases that would silently leave Plex with nothing to scan:
      - Path doesn't exist yet → create it.
      - Dead symlink (is_symlink() True but exists() False) → unlink then create.
      - Existing file that is 0 bytes (leftover from old code) → overwrite.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink() and not path.exists():
        # Dead / broken symlink — remove it so we can write the placeholder
        path.unlink(missing_ok=True)
    if not path.exists():
        path.write_bytes(_FAKE_MP4)
    elif path.stat().st_size == 0:
        # File exists but is empty (written by old code) — backfill with real bytes
        path.write_bytes(_FAKE_MP4)

def revert_to_placeholder(path: Path):
    """Remove symlink and restore the empty placeholder file."""
    try:
        if path.is_symlink() or path.exists():
            path.unlink()
    except Exception:
        pass
    ensure_placeholder(path)

# ── NFO generation ────────────────────────────────────────────────────────────
# Plex NFO Agent (PMS ≥ 1.43.1) reads Kodi-format XML alongside the media file.
# By writing these, Plex skips the online metadata lookup and matches instantly,
# which dramatically speeds up library scans for placeholder files.
#
# File layout expected by Plex NFO Agent:
#   Movies  → <movie folder>/movie.nfo          (or <Filename>.nfo)
#   TV      → <show folder>/tvshow.nfo           (series-level, written once per show)
#             <season folder>/<Episode filename>.nfo  (episode-level)

def _xml_escape(s: str) -> str:
    return (str(s)
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;"))

def _write_nfo(path: Path, content: str):
    """Write NFO only if content has changed, to avoid Plex re-scanning unchanged files."""
    if path.exists():
        try:
            if path.read_text(encoding="utf-8").strip() == content.strip():
                return   # unchanged – don't touch mtime
        except Exception:
            pass
    try:
        path.write_text(content, encoding="utf-8")
    except Exception as exc:
        log.debug("NFO write failed %s: %s", path, exc)

def write_movie_nfo(movie_folder: Path, title: str, year: int | None,
                    tmdb_id: int | None, imdb_id: str | None,
                    plot: str = "", premiered: str = "", studio: str = "",
                    genres: list[str] | None = None):
    """Write movie.nfo in Kodi/Plex NFO Agent format."""
    uid_block = ""
    if tmdb_id:
        uid_block += f'  <uniqueid type="tmdb" default="true">{tmdb_id}</uniqueid>\n'
    if imdb_id:
        uid_block += f'  <uniqueid type="imdb">{_xml_escape(imdb_id)}</uniqueid>\n'
    genre_block = "".join(f"  <genre>{_xml_escape(g)}</genre>\n" for g in (genres or []))

    nfo = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>\n'
        "<movie>\n"
        f"  <title>{_xml_escape(title)}</title>\n"
        f"  <year>{year or ''}</year>\n"
        f"  <plot>{_xml_escape(plot)}</plot>\n"
        f"  <premiered>{_xml_escape(premiered)}</premiered>\n"
        f"  <studio>{_xml_escape(studio)}</studio>\n"
        + uid_block
        + genre_block
        + "</movie>\n"
    )
    _write_nfo(movie_folder / "movie.nfo", nfo)

def write_tvshow_nfo(show_folder: Path, title: str, year: int | None,
                     tvdb_id: int | None, tmdb_id: int | None, imdb_id: str | None,
                     plot: str = "", premiered: str = "", status: str = "",
                     studio: str = "", genres: list[str] | None = None):
    """Write tvshow.nfo – one per show folder, Plex reads it for series-level identity."""
    # Plex NFO Series agent prefers tmdb for TV, but accepts tvdb too.
    uid_block = ""
    if tmdb_id:
        uid_block += f'  <uniqueid type="tmdb" default="true">{tmdb_id}</uniqueid>\n'
    if tvdb_id:
        uid_block += f'  <uniqueid type="tvdb">{tvdb_id}</uniqueid>\n'
    if imdb_id:
        uid_block += f'  <uniqueid type="imdb">{_xml_escape(imdb_id)}</uniqueid>\n'
    genre_block = "".join(f"  <genre>{_xml_escape(g)}</genre>\n" for g in (genres or []))

    nfo = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>\n'
        "<tvshow>\n"
        f"  <title>{_xml_escape(title)}</title>\n"
        f"  <year>{year or ''}</year>\n"
        f"  <plot>{_xml_escape(plot)}</plot>\n"
        f"  <premiered>{_xml_escape(premiered)}</premiered>\n"
        f"  <status>{_xml_escape(status)}</status>\n"
        f"  <studio>{_xml_escape(studio)}</studio>\n"
        + uid_block
        + genre_block
        + "</tvshow>\n"
    )
    _write_nfo(show_folder / "tvshow.nfo", nfo)

def write_episode_nfo(episode_file: Path, title: str, show_title: str,
                      season: int, episode: int,
                      tvdb_ep_id: int | None, tmdb_ep_id: int | None,
                      plot: str = "", aired: str = ""):
    """Write <EpisodeFilename>.nfo alongside the placeholder for episode-level identity."""
    uid_block = ""
    if tvdb_ep_id:
        uid_block += f'  <uniqueid type="tvdb" default="true">{tvdb_ep_id}</uniqueid>\n'
    if tmdb_ep_id:
        uid_block += f'  <uniqueid type="tmdb">{tmdb_ep_id}</uniqueid>\n'

    nfo = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>\n'
        "<episodedetails>\n"
        f"  <title>{_xml_escape(title)}</title>\n"
        f"  <showtitle>{_xml_escape(show_title)}</showtitle>\n"
        f"  <season>{season}</season>\n"
        f"  <episode>{episode}</episode>\n"
        f"  <plot>{_xml_escape(plot)}</plot>\n"
        f"  <aired>{_xml_escape(aired)}</aired>\n"
        + uid_block
        + "</episodedetails>\n"
    )
    # NFO filename must match the video filename exactly (same stem, .nfo extension)
    nfo_path = episode_file.with_suffix(".nfo")
    _write_nfo(nfo_path, nfo)

# ── Library sync ──────────────────────────────────────────────────────────────
def sync_sonarr(db):
    series_list = sonarr_get("/series")
    if not series_list:
        return 0
    count = 0
    for series in series_list:
        sid       = series.get("id")
        title     = series.get("title", "")
        year      = series.get("year")
        plot      = series.get("overview", "")
        status    = series.get("status", "")
        studio    = (series.get("network") or "")
        genres    = series.get("genres", [])
        premiered = (series.get("firstAired") or "")[:10]
        tvdb_id   = series.get("tvdbId")
        imdb_id   = series.get("imdbId")
        tmdb_id   = series.get("tmdbId")

        # Write tvshow.nfo once per show folder (idempotent, only rewrites if changed)
        show_folder = STREAMS_PATH / "sonarr" / safe(title)
        show_folder.mkdir(parents=True, exist_ok=True)
        write_tvshow_nfo(show_folder, title, year, tvdb_id, tmdb_id, imdb_id,
                         plot=plot, premiered=premiered, status=status,
                         studio=studio, genres=genres)

        episodes = sonarr_get("/episode", {"seriesId": sid}) or []
        for ep in episodes:
            if not ep.get("monitored"):
                continue
            s        = ep.get("seasonNumber")
            e        = ep.get("episodeNumber")
            ep_title = ep.get("title", "")
            ep_plot  = ep.get("overview", "")
            ep_aired = (ep.get("airDate") or "")[:10]
            tvdb_ep  = ep.get("tvdbId")
            tmdb_ep  = ep.get("tmdbId")

            lib_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"sonarr:{sid}:{s}:{e}"))
            ph = placeholder_path("sonarr", "episode", title, year, s, e)
            ensure_placeholder(ph)
            write_episode_nfo(ph, ep_title, title, s, e,
                              tvdb_ep_id=tvdb_ep, tmdb_ep_id=tmdb_ep,
                              plot=ep_plot, aired=ep_aired)

            db.execute("""
                INSERT INTO library(id,arr,arr_id,media_type,title,year,season,episode,placeholder,synced_at)
                VALUES(?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET
                  title=excluded.title, year=excluded.year,
                  placeholder=excluded.placeholder, synced_at=excluded.synced_at
            """, (lib_id, "sonarr", sid, "episode", title, year, s, e, str(ph), iso(now_utc())))
            count += 1
    return count

def sync_radarr(db):
    movies = radarr_get("/movie")
    if not movies:
        return 0
    count = 0
    for movie in movies:
        mid       = movie.get("id")
        title     = movie.get("title", "")
        year      = movie.get("year")
        plot      = movie.get("overview", "")
        premiered = (movie.get("inCinemas") or movie.get("digitalRelease") or "")[:10]
        studio    = (movie.get("studio") or "")
        genres    = movie.get("genres", [])
        tmdb_id   = movie.get("tmdbId")
        imdb_id   = movie.get("imdbId")

        lib_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"radarr:{mid}"))
        ph = placeholder_path("radarr", "movie", title, year, None, None)
        ensure_placeholder(ph)
        write_movie_nfo(ph.parent, title, year, tmdb_id, imdb_id,
                        plot=plot, premiered=premiered, studio=studio, genres=genres)

        db.execute("""
            INSERT INTO library(id,arr,arr_id,media_type,title,year,season,episode,placeholder,synced_at)
            VALUES(?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(id) DO UPDATE SET
              title=excluded.title, year=excluded.year,
              placeholder=excluded.placeholder, synced_at=excluded.synced_at
        """, (lib_id, "radarr", mid, "movie", title, year, None, None, str(ph), iso(now_utc())))
        count += 1
    return count


def _set_sonarr_all_unmonitored():
    """Set all Sonarr episodes unmonitored — Debridarr triggers downloads on play only."""
    series_list = sonarr_get("/series") or []
    for series in series_list:
        sid = series.get("id")
        if not sid:
            continue
        eps = sonarr_get("/episode", {"seriesId": sid}) or []
        ids = [ep["id"] for ep in eps if ep.get("monitored")]
        if ids:
            sonarr_put("/episode/monitor", {"episodeIds": ids, "monitored": False})
            log.info("Sonarr: set %d episodes unmonitored for series %s", len(ids), sid)


def _set_radarr_all_unmonitored():
    """Set all Radarr movies unmonitored — Debridarr triggers downloads on play only."""
    movies = radarr_get("/movie") or []
    ids    = [m["id"] for m in movies if m.get("monitored")]
    for movie in movies:
        if movie.get("monitored"):
            radarr_put(f"/movie/{movie['id']}", {**movie, "monitored": False})
    if ids:
        log.info("Radarr: set %d movies unmonitored", len(ids))


def full_library_sync():
    with get_conn() as db:
        s = sync_sonarr(db)
        r = sync_radarr(db)
    # Ensure nothing auto-downloads — Debridarr owns the download trigger
    _set_sonarr_all_unmonitored()
    _set_radarr_all_unmonitored()
    log.info("Library sync complete – sonarr:%d  radarr:%d", s, r)
    return {"sonarr": s, "radarr": r}

# ── Stream resolution (called on Tautulli play event) ────────────────────────

import re as _re

def _norm(s: str) -> list:
    """Normalise a title/filename for fuzzy matching."""
    s = s.lower().replace("'", "").replace("’", "")
    s = _re.sub(r"[._]", " ", s)
    return s.split()

def _find_in_fuse(title: str, year, season, episode) -> tuple | None:
    """Search FUSE registry. Returns (torrent_name, filename, file_dict) or None."""
    from app.fuse_mount import list_torrents, list_files, get_torrent_file
    video_exts  = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
    title_words = _norm(title)
    if not title_words:
        return None
    for torrent_name in list_torrents():
        t_words = _norm(torrent_name)
        if not all(w in t_words for w in title_words):
            continue
        for fname in list_files(torrent_name):
            if not any(fname.lower().endswith(e) for e in video_exts):
                continue
            if season and episode:
                if f"S{season:02d}E{episode:02d}".upper() not in fname.upper():
                    continue
            elif season:
                if f"S{season:02d}".upper() not in fname.upper():
                    continue
            f = get_torrent_file(torrent_name, fname)
            if f:
                return torrent_name, fname, f
    return None


def _get_episode_file_path(arr_id: int, season: int, episode: int) -> Path | None:
    """Ask Sonarr for the file path of a specific episode."""
    eps = sonarr_get("/episode", {"seriesId": arr_id})
    if not eps:
        return None
    for ep in eps:
        if ep.get("seasonNumber") == season and ep.get("episodeNumber") == episode:
            ef = ep.get("episodeFile")
            if not ef:
                return None
            if isinstance(ef, dict):
                rel, size = ef.get("relativePath", ""), ef.get("size", 0)
            else:
                ef_data = sonarr_get(f"/episodefile/{ef}") or {}
                rel, size = ef_data.get("relativePath", ""), ef_data.get("size", 0)
            if not rel or size == 0:
                return None
            series = sonarr_get(f"/series/{arr_id}") or {}
            root   = series.get("path", "")
            if root and rel:
                p = Path(root) / rel
                if p.exists():
                    return p
    return None


def _get_movie_file_path(arr_id: int) -> Path | None:
    """Ask Radarr for the file path of a movie."""
    movie = radarr_get(f"/movie/{arr_id}")
    if not movie:
        return None
    mf = movie.get("movieFile") or {}
    if isinstance(mf, int):
        mf = radarr_get(f"/moviefile/{mf}") or {}
    rel, size = mf.get("relativePath", ""), mf.get("size", 0)
    root = movie.get("path", "")
    if root and rel and size:
        p = Path(root) / rel
        if p.exists():
            return p
    return None


def sonarr_delete(path: str) -> bool:
    with get_conn() as _db:
        url = SONARR_URL or get_setting(_db, "sonarr_url")
        key = SONARR_API_KEY or get_setting(_db, "sonarr_api_key")
    if not url or not key:
        return False
    try:
        r = httpx.delete(f"{url}/api/v3{path}", headers=arr_headers(key), timeout=10)
        log.info("Sonarr DELETE %s → %s", path, r.status_code)
        return r.status_code in (200, 204)
    except Exception as e:
        log.warning("Sonarr DELETE %s failed: %s", path, e)
        return False

def radarr_delete(path: str) -> bool:
    with get_conn() as _db:
        url = RADARR_URL or get_setting(_db, "radarr_url")
        key = RADARR_API_KEY or get_setting(_db, "radarr_api_key")
    if not url or not key:
        return False
    try:
        r = httpx.delete(f"{url}/api/v3{path}", headers=arr_headers(key), timeout=10)
        log.info("Radarr DELETE %s → %s", path, r.status_code)
        return r.status_code in (200, 204)
    except Exception as e:
        log.warning("Radarr DELETE %s failed: %s", path, e)
        return False


def _get_episode_file_id(arr_id: int, season: int, episode: int) -> int | None:
    eps = sonarr_get("/episode", {"seriesId": arr_id}) or []
    for ep in eps:
        if ep.get("seasonNumber") == season and ep.get("episodeNumber") == episode:
            ef = ep.get("episodeFile")
            if isinstance(ef, dict): return ef.get("id")
            elif isinstance(ef, int): return ef
    return None


def _get_movie_file_id(arr_id: int) -> int | None:
    movie = radarr_get(f"/movie/{arr_id}") or {}
    mf    = movie.get("movieFile") or {}
    if isinstance(mf, dict): return mf.get("id")
    elif isinstance(mf, int): return mf
    return None


def _trigger_arr_search(arr: str, arr_id: int, season: int | None, episode: int | None):
    """Delete existing file, set monitored=True, trigger search via Prowlarr."""
    if arr == "sonarr":
        eps     = sonarr_get("/episode", {"seriesId": arr_id}) or []
        matched = None
        for ep in eps:
            if ep.get("seasonNumber") == season and ep.get("episodeNumber") == episode:
                matched = ep
                break
        if not matched:
            log.warning("Sonarr: no episode for seriesId=%s s%se%s", arr_id, season, episode)
            return
        ep_id = matched["id"]

        # Delete existing file so Sonarr will re-download
        ef    = matched.get("episodeFile")
        ef_id = ef.get("id") if isinstance(ef, dict) else (ef if isinstance(ef, int) else None)
        if not ef_id and matched.get("hasFile"):
            # File ID not inline — fetch full episode record
            full  = sonarr_get(f"/episode/{ep_id}") or {}
            ef    = full.get("episodeFile") or {}
            ef_id = ef.get("id") if isinstance(ef, dict) else None
        if ef_id:
            sonarr_delete(f"/episodefile/{ef_id}")
            log.info("Sonarr: deleted episodeFile %s before search", ef_id)

        result = sonarr_post("/command", {"name": "EpisodeSearch", "episodeIds": [ep_id]})
        log.info("Sonarr EpisodeSearch response: %s", result)

    elif arr == "radarr":
        movie = radarr_get(f"/movie/{arr_id}") or {}
        mf    = movie.get("movieFile") or {}
        mf_id = mf.get("id") if isinstance(mf, dict) else (mf if isinstance(mf, int) else None)
        if mf_id:
            radarr_delete(f"/moviefile/{mf_id}")
            log.info("Radarr: deleted movieFile %s before search", mf_id)

        result = radarr_post("/command", {"name": "MoviesSearch", "movieIds": [arr_id]})
        log.info("Radarr MoviesSearch response: %s", result)


def _make_symlink(lib: dict, target: Path) -> Path | None:
    """Swap placeholder → symlink to target. Matches working version's logic exactly."""
    ph = Path(lib["placeholder"])
    media_type = lib["media_type"]
    title      = lib["title"]
    year       = lib["year"]
    season     = lib["season"]
    episode    = lib["episode"]

    folder = ph.parent
    try:
        folder.mkdir(parents=True, exist_ok=True)
        # Ensure placeholder exists (written with real MP4 bytes)
        if not ph.exists() and not ph.is_symlink():
            ph.write_bytes(_FAKE_MP4)
    except Exception as e:
        log.error("placeholder write: %s", e)

    try:
        # Remove any stale symlinks for this item
        if media_type == "movie":
            for f in folder.iterdir():
                if f.is_symlink() and f.suffix in (".mkv", ".mp4", ".avi", ".mov", ".m4v"):
                    f.unlink(missing_ok=True)
        elif season and episode:
            se_pat = f"S{season:02d}E{episode:02d}".upper()
            for f in folder.iterdir():
                if f.is_symlink() and se_pat in f.name.upper():
                    f.unlink(missing_ok=True)

        # Create symlink with the target's filename
        link = folder / target.name
        if link.is_symlink() or link.exists():
            link.unlink(missing_ok=True)
        link.symlink_to(str(target))

        if link.is_symlink():
            # Remove the placeholder file now that symlink is live
            if ph.exists() and not ph.is_symlink():
                ph.unlink(missing_ok=True)
            log.info("Symlink: %s → %s", link.name, target)
            return link
        else:
            # Symlink failed — restore placeholder
            if not ph.exists():
                ph.write_bytes(_FAKE_MP4)
            return None
    except Exception as e:
        log.error("symlink failed: %s", e)
        try:
            if not ph.exists() and not ph.is_symlink():
                ph.write_bytes(_FAKE_MP4)
        except Exception:
            pass
        return None


def activate_stream(library_id: str) -> dict:
    """Replace placeholder with symlink to the real file.

    Resolution order (matching working version):
      1. FUSE registry (instant — already in AllDebrid)
      2. Sonarr/Radarr file on disk (already downloaded)
      3. Trigger arr search + poll for new file (background download)
    """
    with get_conn() as db:
        lib = db.execute("SELECT * FROM library WHERE id=?", (library_id,)).fetchone()
        if not lib:
            return {"ok": False, "error": "Library item not found"}
        existing = db.execute(
            "SELECT * FROM streams WHERE library_id=? AND status='active'", (library_id,)
        ).fetchone()
        if existing:
            db.execute("UPDATE streams SET last_seen_at=? WHERE id=?",
                       (iso(now_utc()), existing["id"]))
            return {"ok": True, "already_active": True, "stream_id": existing["id"]}

    lib     = dict(lib)
    arr     = lib["arr"]
    arr_id  = lib["arr_id"]
    season  = lib["season"]
    episode = lib["episode"]
    title   = lib["title"]
    year    = lib["year"]
    ph      = Path(lib["placeholder"])

    real = None
    source = None

    # 1. Check FUSE registry first — instant if already in AllDebrid
    fuse_match = _find_in_fuse(title, year, season, episode)
    if fuse_match:
        torrent_name, fname, _ = fuse_match
        from app.fuse_mount import get_fuse_path
        real   = get_fuse_path(torrent_name, fname, DFS_FUSE_MOUNT)
        source = "fuse"
        log.info("Found in FUSE: %s / %s", torrent_name, fname)

    # 2. Check arr disk
    if not real:
        if arr == "sonarr":
            real = _get_episode_file_path(arr_id, season, episode)
        else:
            real = _get_movie_file_path(arr_id)
        if real:
            source = arr

    # 3. Always trigger arr search — if we already have a file it grabs a better one,
    #    if not it downloads one and we poll for it
    if not real:
        # Nothing found yet — trigger search and wait for the file
        log.info("Nothing in FUSE or arr disk — triggering %s search for %s", arr, title)
        _trigger_arr_search(arr, arr_id, season, episode)
        # Poll for the new file
        deadline = time.time() + 120
        while time.time() < deadline:
            time.sleep(3)
            if arr == "sonarr":
                real = _get_episode_file_path(arr_id, season, episode)
            else:
                real = _get_movie_file_path(arr_id)
            if real:
                log.info("File appeared after search: %s", real)
                break
        if not real:
            return {"ok": False, "error": f"No file found in FUSE or {arr} for '{title}' after search"}
    else:
        # Already have a file — trigger search in background for a better version
        import threading
        threading.Thread(
            target=lambda: _trigger_arr_search(arr, arr_id, season, episode),
            name=f"arr-search-{library_id[:8]}",
            daemon=True,
        ).start()

    # Symlink
    link = _make_symlink(lib, real)
    if not link:
        return {"ok": False, "error": f"Symlink creation failed for {real}"}

    stream_id = str(uuid.uuid4())
    now       = iso(now_utc())
    expires   = iso(now_utc() + timedelta(days=SYMLINK_TTL_DAYS))

    with get_conn() as db:
        db.execute("""
            INSERT INTO streams(id,library_id,arr,arr_id,media_type,title,year,season,episode,
                                source_path,symlink_path,created_at,expires_at,last_seen_at,status)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (stream_id, library_id, arr, arr_id, lib["media_type"],
              title, year, season, episode,
              str(real), str(link), now, expires, now, "active"))

    _notify_arr_rescan(arr, arr_id)
    log.info("Stream activated via %s: %s → %s (expires %s)", source, link, real, expires)
    return {"ok": True, "stream_id": stream_id, "symlink": str(link),
            "source": str(real), "source_type": source, "expires_at": expires}


def _notify_arr_rescan(arr: str, arr_id: int):
    if arr == "sonarr":
        sonarr_post("/command", {"name": "RescanSeries", "seriesId": arr_id})
    elif arr == "radarr":
        radarr_post("/command", {"name": "RescanMovie", "movieId": arr_id})

def _notify_arr_unlink(arr: str, arr_id: int, season: int | None, episode: int | None):
    """Tell the arr the file is gone so it can unmonitor / mark missing."""
    if arr == "sonarr":
        sonarr_post("/command", {"name": "RescanSeries", "seriesId": arr_id})
    elif arr == "radarr":
        radarr_post("/command", {"name": "RescanMovie", "movieId": arr_id})

# ── Expiry cleanup ────────────────────────────────────────────────────────────
def cleanup_expired() -> list[str]:
    expired_ids = []
    now = now_utc()
    with get_conn() as db:
        rows = db.execute("SELECT * FROM streams WHERE status='active'").fetchall()
        for row in rows:
            try:
                if from_iso(row["expires_at"]) > now:
                    continue
            except Exception:
                continue
            sym = Path(row["symlink_path"])
            revert_to_placeholder(sym)
            db.execute("UPDATE streams SET status='expired' WHERE id=?", (row["id"],))
            expired_ids.append(row["id"])
            log.info("Stream expired and reverted: %s (id=%s)", sym, row["id"])
            # Delete file from arr and set back to unmonitored
            _expire_arr_item(row["arr"], row["arr_id"], row["season"], row["episode"])
    return expired_ids


def _expire_arr_item(arr: str, arr_id: int, season, episode):
    """Delete the downloaded file from arr and set unmonitored so it won't re-download."""
    if arr == "sonarr":
        eps = sonarr_get("/episode", {"seriesId": arr_id}) or []
        for ep in eps:
            if ep.get("seasonNumber") == season and ep.get("episodeNumber") == episode:
                ep_id = ep["id"]
                ef    = ep.get("episodeFile")
                ef_id = ef.get("id") if isinstance(ef, dict) else (ef if isinstance(ef, int) else None)
                if ef_id:
                    sonarr_delete(f"/episodefile/{ef_id}")
                    log.info("Expired: deleted Sonarr episodeFile %s", ef_id)
                sonarr_put("/episode/monitor", {"episodeIds": [ep_id], "monitored": False})
                log.info("Expired: set Sonarr episode %s unmonitored", ep_id)
                return
    elif arr == "radarr":
        movie = radarr_get(f"/movie/{arr_id}") or {}
        mf    = movie.get("movieFile") or {}
        mf_id = mf.get("id") if isinstance(mf, dict) else (mf if isinstance(mf, int) else None)
        if mf_id:
            radarr_delete(f"/moviefile/{mf_id}")
            log.info("Expired: deleted Radarr movieFile %s", mf_id)
        radarr_put(f"/movie/{arr_id}", {**movie, "monitored": False})
        log.info("Expired: set Radarr movie %s unmonitored", arr_id)

# ── FastAPI app ───────────────────────────────────────────────────────────────
# Module-level AllDebrid client — set by lifespan, used by /api/fuse/reload
_ad_client: AllDebridClient | None = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    cleanup_expired()
    full_library_sync()

    # ── DFS FUSE mount ────────────────────────────────────────────────────────
    # Apply DFS settings from DB into fuse_mount module
    global _ad_client
    _ad_client = None
    _fuse_thread = None
    with get_conn() as _db:
        _ad_key      = get_setting(_db, "alldebrid_api_key") or ALLDEBRID_API_KEY
        _cache_dir   = get_setting(_db, "dfs_cache_dir",     DFS_CACHE_DIR)
        _cache_gb    = int(get_setting(_db, "dfs_cache_size_gb", str(DFS_CACHE_SIZE_GB)))
        _cache_ttl   = int(get_setting(_db, "dfs_cache_ttl_h",   str(DFS_CACHE_TTL_H)))
        _chunk_mb    = int(get_setting(_db, "dfs_chunk_mb",       str(DFS_CHUNK_MB)))
        _rahead_mb   = int(get_setting(_db, "dfs_read_ahead_mb",  str(DFS_READ_AHEAD_MB)))
        _cleanup_min = int(get_setting(_db, "dfs_cleanup_min",    str(DFS_CLEANUP_MIN)))

    update_dfs_settings({
        "cache_dir":          _cache_dir,
        "disk_cache_size_gb": _cache_gb,
        "cache_expiry_h":     _cache_ttl,
        "chunk_size_mb":      _chunk_mb,
        "read_ahead_mb":      _rahead_mb,
        "cleanup_interval_m": _cleanup_min,
    })

    if FUSE_AVAILABLE and _ad_key:
        _ad_client = AllDebridClient(_ad_key)
        _loop = asyncio.get_event_loop()
        _fuse_thread = start_fuse_mount(DFS_FUSE_MOUNT, _ad_client, _loop)
        if _fuse_thread:
            log.info("DFS FUSE mounted at %s", DFS_FUSE_MOUNT)
            # Pre-register any existing AllDebrid torrents so files are accessible
            try:
                _torrents = await _ad_client.get_all_torrents()
                for _t in _torrents:
                    if _t.get("name") and _t.get("files"):
                        register_torrent(_t["name"], _t["files"])
                log.info("DFS FUSE: registered %d torrent(s)", len(_torrents))
            except Exception as _e:
                log.warning("DFS torrent pre-register: %s", _e)
        else:
            log.warning("DFS FUSE mount failed at %s", DFS_FUSE_MOUNT)
    elif not FUSE_AVAILABLE:
        log.warning("FUSE not available — DFS mount disabled (install fuse + fusepy)")
    else:
        log.info("DFS FUSE disabled — set ALLDEBRID_API_KEY or configure in FUSE tab")
    # ─────────────────────────────────────────────────────────────────────────

    yield

    # Shutdown: stop FUSE
    if _fuse_thread:
        stop_fuse_mount(DFS_FUSE_MOUNT)
    if _ad_client:
        await _ad_client._client.aclose()

app = FastAPI(title="Debridarr", version="2026.06", lifespan=lifespan)

# ── Auth ──────────────────────────────────────────────────────────────────────
async def require_api_key(
    authorization: Optional[str] = Header(default=None),
    x_api_key: Optional[str]    = Header(default=None),
):
    if not API_KEY:
        return True
    token = (x_api_key or "").strip()
    if authorization and authorization.lower().startswith("bearer "):
        token = authorization.split(" ", 1)[1].strip()
    if token != API_KEY:
        raise HTTPException(401, "Invalid API key")
    return True

# ── Models ────────────────────────────────────────────────────────────────────
class SettingsPatch(BaseModel):
    settings: dict[str, str]

class ManualStreamCreate(BaseModel):
    arr:        Literal["sonarr", "radarr"] = "sonarr"
    media_type: Literal["movie", "episode"] = "episode"
    title:      str
    year:       Optional[int] = None
    season:     Optional[int] = None
    episode:    Optional[int] = None
    source_path: str = Field(..., description="Real file path on FUSE mount")
    ttl_days:   Optional[int] = None

class TautulliWebhook(BaseModel):
    """
    Tautulli sends notification agent payloads.
    We accept either the native Tautulli JSON agent format or a simplified form.
    """
    event:          Optional[str] = None          # 'play', 'watched', etc.
    # Tautulli template fields (set these in the notification agent)
    media_type:     Optional[str] = None          # 'episode' or 'movie'
    file:           Optional[str] = None          # full file path Plex played
    grandparent_title: Optional[str] = None       # show title
    parent_media_index: Optional[int] = None      # season
    media_index:    Optional[int] = None          # episode
    title:          Optional[str] = None          # movie title or episode title
    year:           Optional[int] = None
    extra:          dict[str, Any] = {}

# ── Setup helpers ─────────────────────────────────────────────────────────────
def is_setup_complete() -> bool:
    """Returns True if at least one arr is fully configured."""
    if (SONARR_URL and SONARR_API_KEY) or (RADARR_URL and RADARR_API_KEY):
        return True
    with get_conn() as db:
        s = get_setting(db, "sonarr_url") and get_setting(db, "sonarr_api_key")
        r = get_setting(db, "radarr_url") and get_setting(db, "radarr_api_key")
        return bool(s or r)

# ── Routes ────────────────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
def home():
    return HTMLResponse(UI)

@app.get("/api/setup/status")
def setup_status():
    """Returns which steps are complete so the wizard can show progress."""
    with get_conn() as db:
        sonarr_url   = SONARR_URL   or get_setting(db, "sonarr_url")
        sonarr_key   = SONARR_API_KEY or get_setting(db, "sonarr_api_key")
        radarr_url   = RADARR_URL   or get_setting(db, "radarr_url")
        radarr_key   = RADARR_API_KEY or get_setting(db, "radarr_api_key")
        tautulli_url = TAUTULLI_URL or get_setting(db, "tautulli_url")
        ttl          = get_setting(db, "symlink_ttl_days", str(SYMLINK_TTL_DAYS))
        streams_path = get_setting(db, "streams_path", str(STREAMS_PATH))
        ad_key       = get_setting(db, "alldebrid_api_key") or ALLDEBRID_API_KEY

    sonarr_connected = radarr_connected = False
    if sonarr_url and sonarr_key:
        sonarr_connected = sonarr_get("/system/status") is not None
    if radarr_url and radarr_key:
        radarr_connected = radarr_get("/system/status") is not None

    # AllDebrid connectivity check
    ad_connected = False
    ad_username  = ""
    if ad_key:
        try:
            import httpx as _hx
            r = _hx.get(
                "https://api.alldebrid.com/v4/user",
                params={"agent": "debridarr", "apikey": ad_key},
                timeout=8,
            )
            d = r.json()
            if d.get("status") == "success":
                ad_connected = True
                ad_username  = d.get("data", {}).get("user", {}).get("username", "")
        except Exception:
            pass

    # DFS FUSE mount status
    from app.fuse_mount import _is_mounted
    dfs_mounted = _is_mounted(DFS_FUSE_MOUNT)

    return {
        "setup_complete":   is_setup_complete(),
        "sonarr_url":       sonarr_url,
        "sonarr_connected": sonarr_connected,
        "radarr_url":       radarr_url,
        "radarr_connected": radarr_connected,
        "tautulli_url":     tautulli_url,
        "streams_path":     streams_path,
        "ttl_days":         ttl,
        "webhook_url":      "/webhook/tautulli",
        "ad_key_set":       bool(ad_key),
        "ad_connected":     ad_connected,
        "ad_username":      ad_username,
        "dfs_mounted":      dfs_mounted,
        "dfs_mount_path":   DFS_FUSE_MOUNT,
    }


@app.get("/api/debug/placeholders")
def debug_placeholders(_: bool = Depends(require_api_key)):
    """Scan the streams folder and compare against the library DB.
    Returns missing files, zero-byte files, and broken symlinks so
    you can diagnose why Plex cannot see placeholders.
    """
    with get_conn() as db:
        rows = db.execute("SELECT * FROM library ORDER BY arr,title,season,episode").fetchall()

    results = []
    for r in rows:
        ph   = Path(r["placeholder"])
        info = {
            "title":    r["title"],
            "arr":      r["arr"],
            "season":   r["season"],
            "episode":  r["episode"],
            "path":     str(ph),
            "exists":   ph.exists(),
            "is_symlink": ph.is_symlink(),
            "size":     ph.stat().st_size if ph.exists() else None,
            "problem":  None,
        }
        if ph.is_symlink() and not ph.exists():
            info["problem"] = "dead_symlink"
        elif not ph.exists():
            info["problem"] = "missing"
        elif ph.stat().st_size == 0:
            info["problem"] = "zero_bytes"
        results.append(info)

    problems = [r for r in results if r["problem"]]
    ok       = [r for r in results if not r["problem"]]
    return {
        "total":    len(results),
        "ok":       len(ok),
        "problems": problems,
        "streams_path": str(STREAMS_PATH),
    }

@app.post("/api/debug/placeholders/repair")
def repair_placeholders(_: bool = Depends(require_api_key)):
    """Re-write _FAKE_MP4 for every library entry whose placeholder is
    missing, zero-byte, or a dead symlink. Safe to call at any time."""
    with get_conn() as db:
        rows = db.execute("SELECT * FROM library").fetchall()
    fixed = skipped = 0
    for r in rows:
        ph = Path(r["placeholder"])
        if ph.is_symlink() and not ph.exists():
            ph.unlink(missing_ok=True)
        if not ph.exists() or ph.stat().st_size == 0:
            try:
                ph.parent.mkdir(parents=True, exist_ok=True)
                ph.write_bytes(_FAKE_MP4)
                fixed += 1
            except Exception as e:
                log.warning("repair placeholder %s: %s", ph, e)
        else:
            skipped += 1
    return {"fixed": fixed, "skipped": skipped}

@app.get("/health")
def health():
    return {
        "ok":               True,
        "version":          app.version,
        "streams_path":     str(STREAMS_PATH),
        "sonarr_connected": bool(SONARR_URL and SONARR_API_KEY),
        "radarr_connected": bool(RADARR_URL and RADARR_API_KEY),
    }

@app.get("/api/settings")
def get_settings(_: bool = Depends(require_api_key)):
    with get_conn() as db:
        return {"settings": {r["key"]: r["value"] for r in db.execute("SELECT key,value FROM settings ORDER BY key")}}

@app.patch("/api/settings")
def patch_settings(patch: SettingsPatch, _: bool = Depends(require_api_key)):
    with get_conn() as db:
        for k, v in patch.settings.items():
            db.execute(
                "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (k, str(v))
            )
    # Update in-process globals so they take effect without a restart
    global SONARR_URL, SONARR_API_KEY, RADARR_URL, RADARR_API_KEY
    global TAUTULLI_URL, TAUTULLI_API_KEY, ALLDEBRID_API_KEY
    if "sonarr_url"        in patch.settings: SONARR_URL        = patch.settings["sonarr_url"].rstrip("/")
    if "sonarr_api_key"    in patch.settings: SONARR_API_KEY    = patch.settings["sonarr_api_key"]
    if "radarr_url"        in patch.settings: RADARR_URL        = patch.settings["radarr_url"].rstrip("/")
    if "radarr_api_key"    in patch.settings: RADARR_API_KEY    = patch.settings["radarr_api_key"]
    if "tautulli_url"      in patch.settings: TAUTULLI_URL      = patch.settings["tautulli_url"].rstrip("/")
    if "tautulli_api_key"  in patch.settings: TAUTULLI_API_KEY  = patch.settings["tautulli_api_key"]
    if "alldebrid_api_key" in patch.settings: ALLDEBRID_API_KEY = patch.settings["alldebrid_api_key"]
    return get_settings(True)

# ── FUSE ──────────────────────────────────────────────────────────────────────
@app.get("/api/fuse")
def fuse_status(_: bool = Depends(require_api_key)):
    from app.fuse_mount import _is_mounted, list_torrents, list_files
    dfs_mounted  = _is_mounted(DFS_FUSE_MOUNT)
    torrent_list = list_torrents()
    return {
        "dfs_mount":     DFS_FUSE_MOUNT,
        "dfs_mounted":   dfs_mounted,
        "torrent_count": len(torrent_list),
        "torrents":      [{"name": t, "files": list_files(t)} for t in torrent_list],
    }

@app.post("/api/fuse/reload")
async def fuse_reload(_: bool = Depends(require_api_key)):
    """Re-fetch all ready AllDebrid torrents and re-register them in the FUSE mount.
    Call this after adding new magnets to AllDebrid without restarting the container.
    """
    from app.fuse_mount import list_torrents
    if not _ad_client:
        raise HTTPException(503, "AllDebrid client not initialised — check API key in FUSE tab")
    before = len(list_torrents())
    try:
        torrents = await _ad_client.get_all_torrents()
        for t in torrents:
            if t.get("name") and t.get("files"):
                register_torrent(t["name"], t["files"])
        after = len(list_torrents())
        log.info("FUSE reload: %d → %d torrent(s)", before, after)
        return {"ok": True, "before": before, "after": after, "loaded": len(torrents)}
    except Exception as e:
        log.error("FUSE reload: %s", e)
        raise HTTPException(500, str(e))

# ── Library ───────────────────────────────────────────────────────────────────
@app.get("/api/library")
def list_library(arr: str = "all", _: bool = Depends(require_api_key)):
    with get_conn() as db:
        if arr == "all":
            rows = db.execute("SELECT * FROM library ORDER BY arr, title, season, episode").fetchall()
        else:
            rows = db.execute("SELECT * FROM library WHERE arr=? ORDER BY title,season,episode", (arr,)).fetchall()
        return {"library": [dict(r) for r in rows]}

@app.post("/api/library/sync")
def trigger_sync(background_tasks: BackgroundTasks, _: bool = Depends(require_api_key)):
    background_tasks.add_task(full_library_sync)
    return {"ok": True, "message": "Library sync started in background"}

# ── Streams ───────────────────────────────────────────────────────────────────
@app.get("/api/streams")
def list_streams(status: str = "active", _: bool = Depends(require_api_key)):
    cleanup_expired()
    with get_conn() as db:
        if status == "all":
            rows = db.execute("SELECT * FROM streams ORDER BY created_at DESC").fetchall()
        else:
            rows = db.execute("SELECT * FROM streams WHERE status=? ORDER BY created_at DESC", (status,)).fetchall()
        return {"streams": [dict(r) for r in rows]}

@app.post("/api/streams/manual")
def create_manual_stream(item: ManualStreamCreate, _: bool = Depends(require_api_key)):
    """Manually activate a stream without a Tautulli event."""
    source = Path(item.source_path)
    if not source.exists():
        raise HTTPException(400, f"Source path does not exist: {source}")

    ph = placeholder_path(item.arr, item.media_type, item.title, item.year, item.season, item.episode)
    ensure_placeholder(ph)

    try:
        if ph.is_symlink() or (ph.exists() and not ph.is_symlink()):
            ph.unlink()
        os.symlink(str(source), str(ph))
    except OSError as exc:
        raise HTTPException(500, f"Symlink failed: {exc}")

    ttl = item.ttl_days or SYMLINK_TTL_DAYS
    stream_id = str(uuid.uuid4())
    now = iso(now_utc())
    expires = iso(now_utc() + timedelta(days=ttl))

    with get_conn() as db:
        db.execute("""
            INSERT INTO streams(id,library_id,arr,arr_id,media_type,title,year,season,episode,
                                source_path,symlink_path,created_at,expires_at,last_seen_at,status)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (stream_id, None, item.arr, None, item.media_type,
              item.title, item.year, item.season, item.episode,
              str(source), str(ph), now, expires, now, "active"))

    return {"ok": True, "stream_id": stream_id, "symlink": str(ph), "expires_at": expires}

@app.delete("/api/streams/{stream_id}")
def delete_stream(stream_id: str, _: bool = Depends(require_api_key)):
    with get_conn() as db:
        row = db.execute("SELECT * FROM streams WHERE id=?", (stream_id,)).fetchone()
        if not row:
            raise HTTPException(404, "Stream not found")
        revert_to_placeholder(Path(row["symlink_path"]))
        db.execute("UPDATE streams SET status='removed' WHERE id=?", (stream_id,))
        _notify_arr_unlink(row["arr"], row["arr_id"], row["season"], row["episode"])
    return {"ok": True, "removed": stream_id}

@app.post("/api/streams/cleanup")
def run_cleanup(_: bool = Depends(require_api_key)):
    return {"ok": True, "expired_removed": cleanup_expired()}

# ── Library-driven activation ─────────────────────────────────────────────────
@app.post("/api/library/{library_id}/activate")
def activate(library_id: str, _: bool = Depends(require_api_key)):
    result = activate_stream(library_id)
    if not result.get("ok"):
        raise HTTPException(400, result.get("error", "Activation failed"))
    return result

# ── Tautulli webhook ──────────────────────────────────────────────────────────
@app.post("/webhook/tautulli")
async def tautulli_webhook(request: Request, background_tasks: BackgroundTasks):
    """Tautulli → Notification Agents → Webhook → Playback Start.

    Tautulli JSON body (Data tab):
      {"media_type":"{media_type}","title":"{title}","grandparent_title":"{grandparent_title}",
       "year":"{year}","grandparent_year":"{grandparent_year}",
       "parent_media_index":"{parent_media_index}","media_index":"{media_index}",
       "rating_key":"{rating_key}","themoviedb_id":"{themoviedb_id}",
       "thetvdb_id":"{thetvdb_id}","imdb_id":"{imdb_id}"}
    """
    try:
        payload = await request.json()
    except Exception:
        try:
            payload = dict(await request.form())
        except Exception:
            raise HTTPException(400, "Invalid payload")

    log.info("Tautulli webhook: %s", payload)

    if not payload:
        log.warning("Tautulli webhook: empty payload — check Tautulli JSON body configuration")
        return {"status": "ignored", "reason": "empty payload — check Tautulli webhook JSON body"}

    media_type = (payload.get("media_type") or "").strip().lower()
    title      = (payload.get("grandparent_title") or payload.get("title") or "").strip()
    year       = payload.get("year") or payload.get("grandparent_year")
    season     = payload.get("parent_media_index")
    episode    = payload.get("media_index")

    if media_type not in ("movie", "episode") or not title:
        log.warning("Tautulli webhook ignored — media_type=%r title=%r", media_type, title)
        return {"status": "ignored", "reason": f"media_type={media_type!r} title={title!r}"}

    try:
        year    = int(year)    if year    else None
        season  = int(season)  if season  else None
        episode = int(episode) if episode else None
    except (TypeError, ValueError):
        year = season = episode = None

    # Find matching library entry
    with get_conn() as db:
        lib_row = None
        if media_type == "episode" and title and season is not None and episode is not None:
            lib_row = db.execute(
                "SELECT * FROM library WHERE media_type='episode' AND title=? AND season=? AND episode=?",
                (title, season, episode)
            ).fetchone()
        elif media_type == "movie":
            lib_row = db.execute(
                "SELECT * FROM library WHERE media_type='movie' AND title=?",
                (title,)
            ).fetchone()
            if not lib_row and year:
                lib_row = db.execute(
                    "SELECT * FROM library WHERE media_type='movie' AND title=? AND year=?",
                    (title, year)
                ).fetchone()

    if not lib_row:
        log.warning("Tautulli webhook: no library match — media_type=%s title=%r s%se%s",
                    media_type, title, season, episode)
        return {"status": "ignored", "reason": f"no library match for {title!r}"}

    lib_id = lib_row["id"]
    background_tasks.add_task(_background_activate, lib_id)
    log.info("Tautulli webhook: queued activation for %r lib_id=%s", title, lib_id)
    return {"status": "accepted", "library_id": lib_id}


def _background_activate(library_id: str):
    """Run activate_stream in a background task thread."""
    try:
        result = activate_stream(library_id)
        log.info("Background activation result: %s", result)
    except Exception as e:
        log.error("Background activation failed: %s", e, exc_info=True)

# ── Sonarr / Radarr passthrough status ───────────────────────────────────────
@app.get("/api/arr/sonarr/status")
def sonarr_status(_: bool = Depends(require_api_key)):
    data = sonarr_get("/system/status")
    return {"connected": data is not None, "status": data}

@app.get("/api/arr/radarr/status")
def radarr_status(_: bool = Depends(require_api_key)):
    data = radarr_get("/system/status")
    return {"connected": data is not None, "status": data}

# ── Tautulli connection test ───────────────────────────────────────────────────
@app.get("/api/tautulli/status")
def tautulli_status(_: bool = Depends(require_api_key)):
    """
    Test the Tautulli connection by calling its API.
    Tautulli itself calls US (push webhook), so this only verifies
    we can reach Tautulli — not that the webhook is wired up.
    """
    with get_conn() as db:
        url = get_setting(db, "tautulli_url") or TAUTULLI_URL
        key = get_setting(db, "tautulli_api_key") or TAUTULLI_API_KEY

    if not url:
        return {"connected": False, "error": "Tautulli URL not configured"}

    try:
        params = {"apikey": key, "cmd": "get_server_info"} if key else {"cmd": "get_server_info"}
        r = httpx.get(f"{url}/api/v2", params=params, timeout=8)
        r.raise_for_status()
        data = r.json()
        # Tautulli wraps responses in {"response": {"result": "success", "data": {...}}}
        result = data.get("response", {})
        if result.get("result") == "success":
            info = result.get("data", {})
            return {
                "connected": True,
                "version":   info.get("tautulli_version") or info.get("version"),
                "server":    info.get("pms_name") or info.get("pms_identifier"),
            }
        else:
            # Got a response but result != success — likely wrong API key
            return {"connected": False, "error": result.get("message", "Unexpected response — check API key")}
    except httpx.ConnectError:
        return {"connected": False, "error": "Connection refused — is Tautulli running at that URL?"}
    except httpx.TimeoutException:
        return {"connected": False, "error": "Timed out — check URL and network"}
    except Exception as exc:
        return {"connected": False, "error": str(exc)}

@app.post("/api/webhook/test")
async def webhook_test(_: bool = Depends(require_api_key)):
    """
    Fire a synthetic Tautulli play event against our own webhook endpoint
    so the user can verify the inbound path works without needing Tautulli
    to actually trigger playback.
    Returns the result from the webhook handler.
    """
    # Use the first active library item we have as the test subject
    with get_conn() as db:
        row = db.execute(
            "SELECT * FROM library ORDER BY synced_at DESC LIMIT 1"
        ).fetchone()

    if not row:
        return {"ok": False, "error": "No library items yet — run a sync first"}

    # Build a realistic fake Tautulli payload
    if row["media_type"] == "episode":
        payload = {
            "event":              "play",
            "media_type":         "episode",
            "file":               row["placeholder"],
            "grandparent_title":  row["title"],
            "parent_media_index": row["season"],
            "media_index":        row["episode"],
            "title":              row["title"],
            "year":               row["year"],
        }
    else:
        payload = {
            "event":      "play",
            "media_type": "movie",
            "file":       row["placeholder"],
            "title":      row["title"],
            "year":       row["year"],
        }

    try:
        r = httpx.post(
            "http://127.0.0.1:" + str(os.getenv("PORT", "7474")) + "/webhook/tautulli",
            json=payload, timeout=15,
        )
        data = r.json()
        return {"ok": True, "test_item": row["title"], "webhook_response": data}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}

# ── Browse arr catalogues (without importing everything) ─────────────────────
@app.get("/api/arr/sonarr/series")
def sonarr_series(_: bool = Depends(require_api_key)):
    """Return all series from Sonarr, with a flag for whether each is in our library."""
    data = sonarr_get("/series") or []
    with get_conn() as db:
        imported = set(
            r["arr_id"] for r in db.execute("SELECT arr_id FROM library WHERE arr='sonarr'").fetchall()
        )
    result = []
    for s in sorted(data, key=lambda x: x.get("sortTitle") or x.get("title", "")):
        result.append({
            "id":        s.get("id"),
            "title":     s.get("title"),
            "year":      s.get("year"),
            "status":    s.get("status"),
            "seasons":   len([se for se in s.get("seasons", []) if se.get("seasonNumber", 0) > 0]),
            "overview":  (s.get("overview") or "")[:200],
            "imported":  s.get("id") in imported,
        })
    return {"series": result}

@app.get("/api/arr/radarr/movies")
def radarr_movies(_: bool = Depends(require_api_key)):
    """Return all movies from Radarr, with a flag for whether each is in our library."""
    data = radarr_get("/movie") or []
    with get_conn() as db:
        imported = set(
            r["arr_id"] for r in db.execute("SELECT arr_id FROM library WHERE arr='radarr'").fetchall()
        )
    result = []
    for m in sorted(data, key=lambda x: x.get("sortTitle") or x.get("title", "")):
        result.append({
            "id":       m.get("id"),
            "title":    m.get("title"),
            "year":     m.get("year"),
            "status":   m.get("status"),
            "overview": (m.get("overview") or "")[:200],
            "imported": m.get("id") in imported,
        })
    return {"movies": result}

class LibraryAddItem(BaseModel):
    arr:    Literal["sonarr", "radarr"]
    arr_id: int

@app.post("/api/library/add")
def library_add(item: LibraryAddItem, _: bool = Depends(require_api_key)):
    """Import a single series or movie from an arr into the library and create placeholders."""
    with get_conn() as db:
        if item.arr == "sonarr":
            series = sonarr_get(f"/series/{item.arr_id}")
            if not series:
                raise HTTPException(404, "Series not found in Sonarr")
            title     = series.get("title", "")
            year      = series.get("year")
            plot      = series.get("overview", "")
            status    = series.get("status", "")
            studio    = series.get("network") or ""
            genres    = series.get("genres", [])
            premiered = (series.get("firstAired") or "")[:10]
            tvdb_id   = series.get("tvdbId")
            imdb_id   = series.get("imdbId")
            tmdb_id   = series.get("tmdbId")

            show_folder = STREAMS_PATH / "sonarr" / safe(title)
            show_folder.mkdir(parents=True, exist_ok=True)
            write_tvshow_nfo(show_folder, title, year, tvdb_id, tmdb_id, imdb_id,
                             plot=plot, premiered=premiered, status=status,
                             studio=studio, genres=genres)

            episodes = sonarr_get("/episode", {"seriesId": item.arr_id}) or []
            count = 0
            for ep in episodes:
                if not ep.get("monitored"):
                    continue
                s        = ep.get("seasonNumber")
                e        = ep.get("episodeNumber")
                ep_title = ep.get("title", "")
                ep_plot  = ep.get("overview", "")
                ep_aired = (ep.get("airDate") or "")[:10]
                tvdb_ep  = ep.get("tvdbId")
                tmdb_ep  = ep.get("tmdbId")
                lib_id   = str(uuid.uuid5(uuid.NAMESPACE_URL, f"sonarr:{item.arr_id}:{s}:{e}"))
                ph       = placeholder_path("sonarr", "episode", title, year, s, e)
                ensure_placeholder(ph)
                write_episode_nfo(ph, ep_title, title, s, e,
                                  tvdb_ep_id=tvdb_ep, tmdb_ep_id=tmdb_ep,
                                  plot=ep_plot, aired=ep_aired)
                db.execute("""
                    INSERT INTO library(id,arr,arr_id,media_type,title,year,season,episode,placeholder,synced_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(id) DO UPDATE SET
                      title=excluded.title, year=excluded.year,
                      placeholder=excluded.placeholder, synced_at=excluded.synced_at
                """, (lib_id, "sonarr", item.arr_id, "episode", title, year, s, e, str(ph), iso(now_utc())))
                count += 1
            return {"ok": True, "arr": "sonarr", "title": title, "episodes_added": count}

        else:  # radarr
            movie = radarr_get(f"/movie/{item.arr_id}")
            if not movie:
                raise HTTPException(404, "Movie not found in Radarr")
            title     = movie.get("title", "")
            year      = movie.get("year")
            plot      = movie.get("overview", "")
            premiered = (movie.get("inCinemas") or movie.get("digitalRelease") or "")[:10]
            studio    = movie.get("studio") or ""
            genres    = movie.get("genres", [])
            tmdb_id   = movie.get("tmdbId")
            imdb_id   = movie.get("imdbId")
            lib_id    = str(uuid.uuid5(uuid.NAMESPACE_URL, f"radarr:{item.arr_id}"))
            ph        = placeholder_path("radarr", "movie", title, year, None, None)
            ensure_placeholder(ph)
            write_movie_nfo(ph.parent, title, year, tmdb_id, imdb_id,
                            plot=plot, premiered=premiered, studio=studio, genres=genres)
            db.execute("""
                INSERT INTO library(id,arr,arr_id,media_type,title,year,season,episode,placeholder,synced_at)
                VALUES(?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET
                  title=excluded.title, year=excluded.year,
                  placeholder=excluded.placeholder, synced_at=excluded.synced_at
            """, (lib_id, "radarr", item.arr_id, "movie", title, year, None, None, str(ph), iso(now_utc())))
            return {"ok": True, "arr": "radarr", "title": title, "episodes_added": 1}

# ── DFS / All-Debrid cache settings ──────────────────────────────────────────
DFS_KEYS = [
    "alldebrid_api_key", "dfs_cache_dir", "dfs_cache_size_gb",
    "dfs_cache_ttl_h", "dfs_chunk_mb", "dfs_read_ahead_mb", "dfs_cleanup_min",
]

@app.get("/api/dfs/settings")
def get_dfs_settings(_: bool = Depends(require_api_key)):
    with get_conn() as db:
        rows = db.execute(
            f"SELECT key,value FROM settings WHERE key IN ({','.join('?'*len(DFS_KEYS))})",
            DFS_KEYS
        ).fetchall()
    return {"settings": {r["key"]: r["value"] for r in rows}}

@app.patch("/api/dfs/settings")
def patch_dfs_settings(patch: SettingsPatch, _: bool = Depends(require_api_key)):
    with get_conn() as db:
        for k, v in patch.settings.items():
            if k in DFS_KEYS:
                db.execute(
                    "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (k, str(v))
                )
    return get_dfs_settings(True)

@app.get("/api/alldebrid/status")
def alldebrid_status(_: bool = Depends(require_api_key)):
    """Verify the All-Debrid API key by hitting their /user endpoint."""
    with get_conn() as db:
        key = ALLDEBRID_API_KEY or get_setting(db, "alldebrid_api_key")
    if not key:
        return {"connected": False, "error": "API key not set"}
    try:
        r = httpx.get(
            "https://api.alldebrid.com/v4/user",
            params={"agent": "debridarr", "apikey": key},
            timeout=10,
        )
        data = r.json()
        if data.get("status") == "success":
            u = data.get("data", {}).get("user", {})
            return {
                "connected": True,
                "username":  u.get("username"),
                "premium":   u.get("isPremium"),
                "expires":   u.get("premiumUntil"),
            }
        return {"connected": False, "error": data.get("error", {}).get("message", "Auth failed")}
    except httpx.TimeoutException:
        return {"connected": False, "error": "Timed out reaching All-Debrid"}
    except Exception as exc:
        return {"connected": False, "error": str(exc)}

# ── UI ────────────────────────────────────────────────────────────────────────
UI = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Debridarr</title>
<style>
/* ── Design tokens (matches original Debridarr palette) ── */
:root {
  --bg:       #10131a;
  --surface:  #171b24;
  --surface2: #1e2330;
  --border:   #2b3242;
  --btn:      #2c3445;
  --input-bg: #0e1118;
  --input-bd: #343b4d;
  --accent:   #4f8ef7;
  --accent2:  #6ea8ff;
  --green:    #3fb950;
  --orange:   #e3a135;
  --red:      #f85149;
  --text:     #e8e8e8;
  --sub:      #8892a4;
  --radius:   12px;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { background: var(--bg); color: var(--text); font-family: system-ui, Arial, sans-serif; font-size: 14px; min-height: 100vh; }

/* ── NAV ── */
nav { display: flex; gap: 8px; padding: 14px 20px; background: var(--surface); position: sticky; top: 0; z-index: 50; border-bottom: 1px solid var(--border); align-items: center; }
nav .logo { font-size: 15px; font-weight: 700; color: var(--accent2); margin-right: 8px; letter-spacing: -.3px; }
.nav-btn { background: transparent; color: var(--sub); border: 1px solid transparent; border-radius: 8px; padding: 7px 13px; cursor: pointer; font-size: 13px; transition: .15s; }
.nav-btn:hover { background: var(--btn); color: var(--text); }
.nav-btn.active { background: var(--accent); color: #fff; border-color: transparent; }
.nav-wizard { margin-left: auto; }

/* ── WIZARD OVERLAY ── */
#wizardOverlay { position: fixed; inset: 0; background: rgba(0,0,0,.7); z-index: 100; display: flex; align-items: center; justify-content: center; padding: 16px; }
#wizardBox { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); width: 100%; max-width: 620px; overflow: hidden; }
.wiz-header { padding: 22px 24px 0; }
.wiz-header h2 { font-size: 17px; font-weight: 700; }
.wiz-header p { color: var(--sub); font-size: 13px; margin-top: 5px; }
.wiz-pills { display: flex; gap: 0; padding: 0 24px; margin-top: 18px; border-bottom: 1px solid var(--border); overflow-x: auto; }
.wiz-pill { padding: 9px 14px; font-size: 12px; font-weight: 600; color: var(--sub); border-bottom: 2px solid transparent; white-space: nowrap; }
.wiz-pill.done   { color: var(--green); }
.wiz-pill.active { color: var(--accent2); border-bottom-color: var(--accent2); }
.wiz-body { padding: 22px 24px; min-height: 210px; }
.wiz-footer { padding: 14px 24px; border-top: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; }

/* ── TABS ── */
.tab { display: none; padding: 22px 20px; max-width: 1300px; margin: 0 auto; }
.tab.active { display: block; }

/* ── GENERIC COMPONENTS ── */
.card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 16px; margin-bottom: 14px; }
.row  { display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 14px; }
h1 { font-size: 20px; font-weight: 700; margin-bottom: 16px; }
h2 { font-size: 16px; font-weight: 700; margin-bottom: 4px; }
h3 { font-size: 11px; color: var(--sub); text-transform: uppercase; letter-spacing: .07em; margin-bottom: 10px; font-weight: 600; }
.top-row { display: flex; align-items: center; gap: 10px; margin-bottom: 18px; flex-wrap: wrap; }
.top-row h1 { margin: 0; }
.empty { color: var(--sub); text-align: center; padding: 40px 20px; font-size: 13px; }

/* ── BUTTONS ── */
button { background: var(--btn); color: var(--text); border: 0; border-radius: 8px; padding: 8px 13px; cursor: pointer; font-size: 13px; transition: opacity .15s, background .15s; white-space: nowrap; }
button:hover { opacity: .85; }
button:disabled { opacity: .4; cursor: not-allowed; }
button.primary { background: var(--accent); color: #fff; }
button.danger  { background: #3a1a1a; color: var(--red); border: 1px solid #5a2020; }
button.danger:hover { background: var(--red); color: #fff; }
button.ghost   { background: transparent; color: var(--sub); border: 1px solid var(--border); }
button.ghost:hover { color: var(--text); }
button.sm { padding: 5px 10px; font-size: 12px; border-radius: 6px; }

/* ── INPUTS ── */
input, select, textarea {
  width: 100%; box-sizing: border-box;
  background: var(--input-bg); color: var(--text);
  border: 1px solid var(--input-bd); border-radius: 8px;
  padding: 9px 11px; font-size: 13px; margin: 4px 0 10px;
  font-family: inherit;
}
input:focus, select:focus { outline: none; border-color: var(--accent); }
label { font-size: 12px; color: var(--sub); display: block; margin-bottom: 1px; }
.field-row { display: flex; gap: 8px; align-items: flex-end; }
.field-row input { margin-bottom: 0; flex: 1; }

/* ── BADGES ── */
.badge { display: inline-block; padding: 2px 8px; border-radius: 20px; font-size: 11px; font-weight: 700; letter-spacing: .02em; }
.badge-green  { background: #152a1e; color: var(--green); }
.badge-orange { background: #2d2008; color: var(--orange); }
.badge-red    { background: #2a1010; color: var(--red); }
.badge-blue   { background: #0d1e38; color: var(--accent2); }
.badge-gray   { background: var(--btn); color: var(--sub); }

/* ── STREAMS TABLE ── */
table { width: 100%; border-collapse: collapse; }
th { text-align: left; padding: 8px 10px; color: var(--sub); font-weight: 600; font-size: 11px; text-transform: uppercase; letter-spacing: .05em; border-bottom: 1px solid var(--border); }
td { padding: 9px 10px; border-bottom: 1px solid var(--border); font-size: 13px; vertical-align: middle; }
tr:last-child td { border-bottom: none; }
tr:hover td { background: rgba(255,255,255,.018); }
.mono { font-family: ui-monospace, monospace; font-size: 11px; color: var(--sub); word-break: break-all; }

/* ── STATUS ── */
.dot { display: inline-block; width: 7px; height: 7px; border-radius: 50%; margin-right: 6px; flex-shrink: 0; }
.dot-green  { background: var(--green); box-shadow: 0 0 5px var(--green); }
.dot-red    { background: var(--red); }
.dot-orange { background: var(--orange); }
.dot-gray   { background: var(--sub); }

/* ── MISC ── */
.spinner { display: inline-block; width: 12px; height: 12px; border: 2px solid rgba(255,255,255,.2); border-top-color: #fff; border-radius: 50%; animation: spin .6s linear infinite; vertical-align: middle; margin-right: 6px; }
@keyframes spin { to { transform: rotate(360deg); } }
.info-box { background: #0d1e30; border: 1px solid #1a3550; border-radius: 8px; padding: 11px 14px; font-size: 13px; color: #7ab8f5; margin: 10px 0; line-height: 1.6; }
.info-box code { background: rgba(0,0,0,.35); padding: 1px 5px; border-radius: 4px; font-family: ui-monospace, monospace; font-size: 11px; }
.success-box { background: var(--surface2); border: 1px solid var(--border); border-radius: var(--radius); padding: 28px; text-align: center; }
.success-box .big-icon { font-size: 42px; margin-bottom: 10px; }
.success-box h2 { color: var(--green); font-size: 17px; margin-bottom: 8px; }
.check-row { display: flex; align-items: flex-start; gap: 10px; padding: 9px 0; border-bottom: 1px solid var(--border); }
.check-row:last-child { border-bottom: none; }
.check-icon { font-size: 16px; margin-top: 1px; }
.check-label strong { display: block; font-size: 13px; }
.check-label span { color: var(--sub); font-size: 12px; }

/* ── LIBRARY CARDS ── */
.lib-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 14px; }
.lib-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); overflow: hidden; display: flex; flex-direction: column; transition: border-color .15s; }
.lib-card:hover { border-color: #3d4d66; }
.lib-card-header { padding: 14px 16px 10px; border-bottom: 1px solid var(--border); display: flex; align-items: flex-start; gap: 10px; }
.lib-card-icon { font-size: 26px; flex-shrink: 0; margin-top: 1px; }
.lib-card-meta { flex: 1; min-width: 0; }
.lib-card-meta h2 { font-size: 14px; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.lib-card-meta .sub { color: var(--sub); font-size: 12px; margin-top: 2px; display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.season-list { padding: 0; }
.season-row { border-bottom: 1px solid var(--border); }
.season-row:last-child { border-bottom: none; }
.season-header { display: flex; align-items: center; padding: 9px 16px; cursor: pointer; user-select: none; gap: 8px; }
.season-header:hover { background: var(--surface2); }
.season-chevron { color: var(--sub); font-size: 11px; margin-left: auto; transition: transform .2s; }
.season-chevron.open { transform: rotate(90deg); }
.season-label { font-size: 13px; font-weight: 600; }
.season-eps-count { color: var(--sub); font-size: 12px; }
.ep-list { display: none; background: var(--input-bg); }
.ep-list.open { display: block; }
.ep-row { display: flex; align-items: center; gap: 8px; padding: 7px 16px 7px 28px; border-top: 1px solid var(--border); font-size: 12px; }
.ep-row:hover { background: rgba(255,255,255,.03); }
.ep-num { color: var(--sub); font-family: ui-monospace, monospace; font-size: 11px; min-width: 44px; flex-shrink: 0; }
.ep-title { flex: 1; color: var(--text); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ep-status { flex-shrink: 0; }
.lib-card-footer { padding: 10px 16px; margin-top: auto; display: flex; align-items: center; justify-content: space-between; border-top: 1px solid var(--border); background: var(--surface2); }
.lib-search { background: var(--input-bg); border: 1px solid var(--input-bd); border-radius: 8px; padding: 7px 11px; color: var(--text); font-size: 13px; width: 220px; margin: 0; }
.lib-search:focus { outline: none; border-color: var(--accent); }
.progress-bar { height: 3px; background: var(--border); border-radius: 2px; overflow: hidden; margin-top: 6px; }
.progress-fill { height: 100%; background: var(--accent); border-radius: 2px; transition: width .3s; }

/* ── PICKER MODAL ── */
#pickerOverlay { position: fixed; inset: 0; background: rgba(0,0,0,.7); z-index: 90; display: none; align-items: center; justify-content: center; padding: 16px; }
#pickerOverlay.open { display: flex; }
#pickerBox { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); width: 100%; max-width: 560px; max-height: 80vh; display: flex; flex-direction: column; overflow: hidden; }
.picker-header { padding: 16px 18px; border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 10px; }
.picker-header h2 { font-size: 15px; flex: 1; }
.picker-tabs { display: flex; border-bottom: 1px solid var(--border); }
.picker-tab { flex: 1; padding: 9px; text-align: center; font-size: 13px; font-weight: 600; color: var(--sub); cursor: pointer; border-bottom: 2px solid transparent; background: transparent; border-radius: 0; }
.picker-tab:hover { color: var(--text); background: var(--surface2); }
.picker-tab.active { color: var(--accent2); border-bottom-color: var(--accent2); }
.picker-search { padding: 10px 14px; border-bottom: 1px solid var(--border); }
.picker-search input { margin: 0; }
.picker-list { overflow-y: auto; flex: 1; }
.picker-item { display: flex; align-items: center; gap: 10px; padding: 10px 16px; border-bottom: 1px solid var(--border); cursor: pointer; transition: background .1s; }
.picker-item:last-child { border-bottom: none; }
.picker-item:hover { background: var(--surface2); }
.picker-item.imported { opacity: .5; cursor: default; }
.picker-item-icon { font-size: 20px; flex-shrink: 0; }
.picker-item-meta { flex: 1; min-width: 0; }
.picker-item-meta strong { display: block; font-size: 13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.picker-item-meta span { font-size: 11px; color: var(--sub); }
.picker-item-action { flex-shrink: 0; }
.picker-empty { color: var(--sub); text-align: center; padding: 30px; font-size: 13px; }
.picker-footer { padding: 12px 16px; border-top: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; font-size: 12px; color: var(--sub); }
</style>
</head>
<body>

<!-- ── WIZARD OVERLAY ── -->
<div id="wizardOverlay">
<div id="wizardBox">
  <div class="wiz-header">
    <h2>⚡ Welcome to Debridarr</h2>
    <p>Let's get you set up in a few quick steps.</p>
  </div>
  <div class="wiz-pills" id="wizPills"></div>
  <div class="wiz-body"   id="wizBody"></div>
  <div class="wiz-footer">
    <button class="ghost" id="wizBack" onclick="wizNav(-1)">← Back</button>
    <span id="wizHint"></span>
    <button class="primary" id="wizNext" onclick="wizNav(1)">Next →</button>
  </div>
</div>
</div>

<!-- ── NAV ── -->
<nav>
  <span class="logo">⚡ Debridarr</span>
  <button class="nav-btn active" onclick="show('streams')">Streams</button>
  <button class="nav-btn"        onclick="show('library')">Library</button>
  <button class="nav-btn"        onclick="show('connections')">Connections</button>
  <button class="nav-btn"        onclick="show('fuse')">FUSE</button>
  <button class="nav-btn nav-wizard" onclick="openWizard()">Setup Wizard</button>
</nav>

<!-- ══ STREAMS ══ -->
<section id="streams" class="tab active">
  <div class="top-row">
    <h1>Streams</h1>
    <button onclick="loadStreams('active')">Refresh</button>
    <button onclick="loadStreams('all')" class="ghost">Show All</button>
    <button onclick="runCleanup()" class="danger">Run Expiry Cleanup</button>
  </div>
  <div class="card" style="padding:0;overflow:hidden">
    <div id="streamsTable"><div class="empty">Loading…</div></div>
  </div>
</section>

<!-- ══ LIBRARY ══ -->
<!-- ══ PICKER MODAL ══ -->
<div id="pickerOverlay">
  <div id="pickerBox">
    <div class="picker-header">
      <h2>Add to Library</h2>
      <button class="ghost sm" onclick="closePicker()">✕ Close</button>
    </div>
    <div class="picker-tabs">
      <button class="picker-tab active" id="ptabSonarr" onclick="switchPickerTab('sonarr')">📺 TV Shows (Sonarr)</button>
      <button class="picker-tab"        id="ptabRadarr" onclick="switchPickerTab('radarr')">🎬 Movies (Radarr)</button>
    </div>
    <div class="picker-search">
      <input id="pickerSearch" placeholder="Filter…" oninput="filterPicker()" style="margin:0">
    </div>
    <div class="picker-list" id="pickerList"><div class="picker-empty">Loading…</div></div>
    <div class="picker-footer">
      <span id="pickerCount"></span>
      <span style="color:var(--sub)">Greyed = already in library</span>
    </div>
  </div>
</div>

<section id="library" class="tab">
  <div class="top-row">
    <h1>Library</h1>
    <input class="lib-search" id="libSearch" placeholder="Search titles…" oninput="filterLibrary()" style="margin:0">
    <select id="libFilter" onchange="loadLibrary()" style="width:auto;margin:0">
      <option value="all">All</option>
      <option value="sonarr">TV Shows</option>
      <option value="radarr">Movies</option>
    </select>
    <button onclick="loadLibrary()">Refresh</button>
    <button onclick="openPicker()" class="primary">+ Add Item</button>
    <button onclick="triggerSync()" class="ghost">Sync All</button>
  </div>
  <div id="libStats" style="color:var(--sub);font-size:12px;margin-bottom:14px"></div>
  <div id="libraryGrid"><div class="empty">Loading…</div></div>
</section>

<!-- ══ CONNECTIONS ══ -->
<section id="connections" class="tab">
  <h1>Connections</h1>
  <div class="row">
    <div class="card" style="flex:1 1 260px">
      <h3>Sonarr</h3>
      <div id="sonarrStatus" style="margin-bottom:10px;font-size:13px"></div>
      <label>URL</label><input id="sonarrUrl" placeholder="http://sonarr:8989">
      <label>API Key</label><input id="sonarrKey" type="password" placeholder="API key">
      <button class="primary" onclick="saveArr('sonarr')">Save &amp; Test</button>
    </div>
    <div class="card" style="flex:1 1 260px">
      <h3>Radarr</h3>
      <div id="radarrStatus" style="margin-bottom:10px;font-size:13px"></div>
      <label>URL</label><input id="radarrUrl" placeholder="http://radarr:7878">
      <label>API Key</label><input id="radarrKey" type="password" placeholder="API key">
      <button class="primary" onclick="saveArr('radarr')">Save &amp; Test</button>
    </div>
    <div class="card" style="flex:1 1 260px">
      <h3>Tautulli</h3>
      <div id="tautulliStatus" style="margin-bottom:10px;font-size:13px"></div>
      <label>Tautulli URL</label>
      <input id="tautulliUrl" placeholder="http://tautulli:8181">
      <label>API Key <span style="color:var(--sub);font-size:11px">(Settings → Web Interface)</span></label>
      <input id="tautulliApiKey" type="password" placeholder="API key">
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px">
        <button onclick="saveTautulli()">Save &amp; Test</button>
        <button class="ghost" onclick="testWebhook()" title="Fire a fake play event through the webhook to verify the full flow">Test Webhook Flow</button>
      </div>
      <div id="webhookTestResult" style="font-size:12px;min-height:16px"></div>
      <div style="border-top:1px solid var(--border);margin:10px 0 8px"></div>
      <p style="color:var(--sub);font-size:12px;margin-bottom:6px">Playback Start webhook URL — paste this into Tautulli:</p>
      <div style="display:flex;align-items:center;gap:6px">
        <div class="mono" id="webhookUrl2" style="font-size:11px;word-break:break-all;color:var(--accent2);flex:1"></div>
        <button class="sm ghost" id="copyWebhookBtn" onclick="copyWebhookUrl()">Copy</button>
      </div>
    </div>
  </div>
  <div class="card" style="max-width:340px">
    <h3>Stream TTL</h3>
    <label>Days before symlink expires and reverts to placeholder</label>
    <div class="field-row">
      <input id="ttlDays" type="number" min="1" max="365" value="30" style="width:100px">
      <button onclick="saveTtl()">Save</button>
    </div>
  </div>
</section>

<!-- ══ FUSE ══ -->
<section id="fuse" class="tab">
  <h1>FUSE Mount</h1>

  <!-- Mount status -->
  <div class="card" style="margin-bottom:16px">
    <h3>Mount Status</h3>
    <div id="fuseStatus"><div class="empty">Loading…</div></div>
    <div style="margin-top:14px;display:flex;gap:8px">
      <button onclick="loadFuse()">Refresh</button>
      <button id="fuseReloadBtn" onclick="fuseReload()">🔄 Reload Torrents</button>
    </div>
  </div>

  <!-- All-Debrid credentials -->
  <div class="card" style="margin-bottom:16px">
    <h3 style="color:#f0a500">🔑 All-Debrid</h3>
    <div id="alldebridStatus" style="font-size:13px;margin-bottom:10px"></div>
    <label>All-Debrid API Key</label>
    <div class="field-row">
      <input id="adApiKey" type="password" placeholder="All-Debrid API key">
      <button class="primary" onclick="saveAndTestAD()">Save &amp; Test</button>
    </div>
    <p style="color:var(--sub);font-size:12px;margin-top:4px">
      Get your key at <span style="color:var(--accent2)">alldebrid.com → Account → API Keys</span>
    </p>
  </div>

  <!-- DFS Cache settings -->
  <div class="card">
    <h3 style="color:#f0a500">📦 DFS Cache (Streaming Performance)</h3>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px;margin-bottom:16px">
      <div>
        <label>Cache Directory</label>
        <input id="dfsCacheDir" placeholder="/cache/dfs">
        <p style="color:var(--sub);font-size:11px;margin-top:-6px">Directory for chunk cache files</p>
      </div>
      <div>
        <label>Disk Cache Size (GB)</label>
        <input id="dfsCacheSizeGb" type="number" min="1" placeholder="50">
        <p style="color:var(--sub);font-size:11px;margin-top:-6px">Maximum disk cache size</p>
      </div>
      <div>
        <label>Cache Expiry (hours)</label>
        <input id="dfsCacheTtlH" type="number" min="1" placeholder="12">
        <p style="color:var(--sub);font-size:11px;margin-top:-6px">How long to keep cached chunks</p>
      </div>
      <div>
        <label>Chunk Size (MB)</label>
        <input id="dfsChunkMb" type="number" min="1" placeholder="32">
        <p style="color:var(--sub);font-size:11px;margin-top:-6px">Fetch unit from CDN</p>
      </div>
      <div>
        <label>Read Ahead (MB)</label>
        <input id="dfsReadAheadMb" type="number" min="1" placeholder="128">
        <p style="color:var(--sub);font-size:11px;margin-top:-6px">Pre-fetch buffer size</p>
      </div>
      <div>
        <label>Cleanup Interval (min)</label>
        <input id="dfsCleanupMin" type="number" min="1" placeholder="20">
        <p style="color:var(--sub);font-size:11px;margin-top:-6px">How often to clean cache</p>
      </div>
    </div>
    <div style="display:flex;align-items:center;gap:10px">
      <button class="primary" onclick="saveDFS()">💾 Save DFS Settings</button>
      <span id="dfsSaveStatus" style="font-size:12px"></span>
    </div>
  </div>
</section>

<script>
// ─────────────────────────────────────────────────────────────────────────────
// WIZARD
// ─────────────────────────────────────────────────────────────────────────────
let wizStep = 1;
const WIZ_TOTAL = 6;
let _wst = {};

const STEPS = {
  1: {
    label: '1 · Sonarr',
    canSkip: true, skipLabel: 'Skip →',
    render: st => `
      <h3 style="margin-bottom:10px">Connect Sonarr</h3>
      <p style="color:var(--sub);font-size:13px;margin-bottom:14px">Debridarr scans Sonarr to build your TV library and create placeholders. Skip if you only use Radarr.</p>
      <label>Sonarr URL</label>
      <input id="wSonarrUrl" placeholder="http://sonarr:8989" value="${esc(st.sonarr_url||'')}">
      <label>API Key <span style="color:var(--sub);font-size:11px">(Settings → General → Security)</span></label>
      <div class="field-row">
        <input id="wSonarrKey" type="password" placeholder="${st.sonarr_connected ? '(key saved — leave blank to keep)' : '••••••••••••••••'}">
        <button onclick="wizTest('sonarr')">Test</button>
      </div>
      <div id="wSonarrResult" style="margin-top:8px;font-size:13px;min-height:20px">${st.sonarr_connected ? '<span class="dot dot-green"></span>Connected — re-enter key only if changing it.' : ''}</div>`,
    async onNext() {
      const u = v('wSonarrUrl'), k = v('wSonarrKey');
      if (u && k) await wizSave('sonarr', u, k);
      else if (u) await api('/api/settings',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({settings:{sonarr_url:u}})});
    }
  },
  2: {
    label: '2 · Radarr',
    canSkip: true, skipLabel: 'Skip →',
    render: st => `
      <h3 style="margin-bottom:10px">Connect Radarr</h3>
      <p style="color:var(--sub);font-size:13px;margin-bottom:14px">Debridarr scans Radarr to build your movie library. Skip if you only use Sonarr.</p>
      <label>Radarr URL</label>
      <input id="wRadarrUrl" placeholder="http://radarr:7878" value="${esc(st.radarr_url||'')}">
      <label>API Key <span style="color:var(--sub);font-size:11px">(Settings → General → Security)</span></label>
      <div class="field-row">
        <input id="wRadarrKey" type="password" placeholder="${st.radarr_connected ? '(key saved — leave blank to keep)' : '••••••••••••••••'}">
        <button onclick="wizTest('radarr')">Test</button>
      </div>
      <div id="wRadarrResult" style="margin-top:8px;font-size:13px;min-height:20px">${st.radarr_connected ? '<span class="dot dot-green"></span>Connected — re-enter key only if changing it.' : ''}</div>`,
    async onNext() {
      const u = v('wRadarrUrl'), k = v('wRadarrKey');
      if (u && k) await wizSave('radarr', u, k);
      else if (u) await api('/api/settings',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({settings:{radarr_url:u}})});
    }
  },
  3: {
    label: '3 · AllDebrid',
    canSkip: true, skipLabel: 'Skip →',
    render: st => `
      <h3 style="margin-bottom:10px">AllDebrid — DFS streaming mount</h3>
      <p style="color:var(--sub);font-size:13px;margin-bottom:14px">
        Debridarr uses AllDebrid to stream media directly via a DFS FUSE filesystem.
        When you press play, Debridarr resolves the CDN link and serves chunks from a local disk cache — no third-party mount needed.
      </p>
      <label>AllDebrid API Key <span style="color:var(--sub);font-size:11px">(<a href="https://alldebrid.com/apikeys" target="_blank" style="color:var(--accent2)">alldebrid.com/apikeys</a>)</span></label>
      <div class="field-row">
        <input id="wAdKey" type="password" placeholder="${st.ad_connected ? '(key saved — leave blank to keep)' : '••••••••••••••••'}">
        <button onclick="wizTestAD()">Test</button>
      </div>
      <div id="wAdResult" style="margin-top:8px;font-size:13px;min-height:20px">
        ${st.ad_connected ? '<span class="dot dot-green"></span>Connected' + (st.ad_username ? ' as <strong>' + esc(st.ad_username) + '</strong>' : '') : ''}
      </div>
      <div style="margin-top:14px;padding-top:12px;border-top:1px solid var(--border)">
        <div style="display:flex;align-items:center;gap:10px;font-size:13px">
          <span class="dot ${st.dfs_mounted ? 'dot-green' : 'dot-gray'}"></span>
          <span>DFS FUSE mount — <span class="mono" style="font-size:11px">${esc(st.dfs_mount_path)}</span></span>
          <span style="color:${st.dfs_mounted ? 'var(--green)' : 'var(--sub)'};font-size:12px">${st.dfs_mounted ? 'Active' : 'Starts on container boot once key is saved'}</span>
        </div>
        <div class="info-box" style="margin-top:10px">
          Add to <code>docker-compose.yml</code> so the DFS mount persists across restarts:<br>
          <code>devices:<br>&nbsp;&nbsp;- /dev/fuse:/dev/fuse<br>cap_add:<br>&nbsp;&nbsp;- SYS_ADMIN<br>security_opt:<br>&nbsp;&nbsp;- apparmor:unconfined</code>
        </div>
      </div>`,
    async onNext() {
      const k = v('wAdKey');
      if (k) await api('/api/settings',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({settings:{alldebrid_api_key:k}})});
    }
  },
  4: {
    label: '4 · Tautulli',
    canSkip: true, skipLabel: "I'll do this later",
    render: st => {
      const whUrl = location.origin + '/webhook/tautulli';
      const tplJson = '{"media_type":"{media_type}","title":"{title}","grandparent_title":"{grandparent_title}","year":"{year}","grandparent_year":"{grandparent_year}","parent_media_index":"{parent_media_index}","media_index":"{media_index}","rating_key":"{rating_key}","themoviedb_id":"{themoviedb_id}","thetvdb_id":"{thetvdb_id}","imdb_id":"{imdb_id}"}';
      return `
      <h3 style="margin-bottom:10px">Tautulli webhook</h3>
      <p style="color:var(--sub);font-size:13px;margin-bottom:14px">When a user presses Play on a placeholder, Tautulli tells Debridarr to swap the symlink to the real DFS-streamed file.</p>
      <div class="check-row"><div class="check-icon">1️⃣</div><div class="check-label"><strong>Tautulli → Settings → Notification Agents → Add → Webhook</strong></div></div>
      <div class="check-row">
        <div class="check-icon">2️⃣</div>
        <div class="check-label"><strong>Webhook URL</strong><span class="mono" style="color:var(--accent2)">${whUrl}</span></div>
        <button class="sm" id="wizCopyWebhook" onclick="(function(btn){navigator.clipboard.writeText('${whUrl}').then(()=>{btn.textContent='✓ Copied';setTimeout(()=>btn.textContent='Copy',1800);})})(this)">Copy</button>
      </div>
      <div class="check-row"><div class="check-icon">3️⃣</div><div class="check-label"><strong>Trigger: Playback Start only</strong></div></div>
      <div class="check-row"><div class="check-icon">4️⃣</div><div class="check-label"><strong>JSON body (Data tab)</strong><span class="mono" style="display:block;margin-top:4px;font-size:10px;white-space:pre-wrap">${tplJson}</span></div></div>
      <div style="margin-top:12px"><label>Tautulli URL (optional — for connection test)</label><input id="wTautulliUrl" placeholder="http://tautulli:8181" value="${esc(st.tautulli_url||'')}"></div>`;
    },
    async onNext() {
      const u = v('wTautulliUrl');
      if (u) await api('/api/settings',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({settings:{tautulli_url:u}})});
    }
  },
  5: {
    label: '5 · Plex NFO',
    canSkip: true, skipLabel: "Set up in Plex later",
    render: () => `
      <h3 style="margin-bottom:10px">Enable faster library scanning</h3>
      <p style="color:var(--sub);font-size:13px;margin-bottom:14px">Debridarr writes <code style="font-family:monospace;font-size:11px;background:var(--input-bg);padding:2px 5px;border-radius:4px">.nfo</code> files alongside every placeholder. Plex reads them and resolves metadata instantly — no API lookups needed.</p>
      <div class="check-row"><div class="check-icon">1️⃣</div><div class="check-label"><strong>Requires Plex Media Server ≥ 1.43.1</strong></div></div>
      <div class="check-row"><div class="check-icon">2️⃣</div><div class="check-label"><strong>Add Plex libraries pointing at</strong><span>TV: <code style="font-family:monospace;font-size:11px;background:var(--input-bg);padding:1px 4px;border-radius:3px">/streams/sonarr</code> &nbsp; Movies: <code style="font-family:monospace;font-size:11px;background:var(--input-bg);padding:1px 4px;border-radius:3px">/streams/radarr</code></span></div></div>
      <div class="check-row"><div class="check-icon">3️⃣</div><div class="check-label"><strong>In Plex: Edit Library → Advanced → Agent</strong><span>Select <strong>Plex NFO Series</strong> for TV, <strong>Plex NFO Movie</strong> for movies</span></div></div>
      <div class="check-row"><div class="check-icon">4️⃣</div><div class="check-label"><strong>Run a library scan in Plex</strong><span>NFOs provide instant metadata — no rate limits, no API calls.</span></div></div>`,
    async onNext() {}
  },
  6: {
    label: '6 · Done',
    canSkip: false,
    render: st => `
      <div class="success-box">
        <div class="big-icon">🎉</div>
        <h2>You're all set!</h2>
        <p style="color:var(--sub);font-size:13px;margin-bottom:18px">Library sync is running in the background. Placeholders will appear shortly.</p>
        <div style="text-align:left;max-width:340px;margin:0 auto 18px">
          ${chkRow(st.sonarr_connected,'Sonarr connected',st.sonarr_url||'not configured')}
          ${chkRow(st.radarr_connected,'Radarr connected',st.radarr_url||'not configured')}
          ${chkRow(st.ad_connected,'AllDebrid connected',st.ad_username||'not configured')}
          ${chkRow(st.dfs_mounted,'DFS FUSE mount active',st.dfs_mount_path||'')}
          ${chkRow(!!st.tautulli_url,'Tautulli URL saved',st.tautulli_url||'not set')}
        </div>
        <button class="primary" onclick="closeWizard()">Go to Dashboard →</button>
      </div>`,
    async onNext() { closeWizard(); }
  }
};

function chkRow(ok,lbl,sub){ return `<div class="check-row"><div class="check-icon">${ok?'✅':'⚠️'}</div><div class="check-label"><strong>${esc(lbl)}</strong><span>${esc(sub)}</span></div></div>`; }

async function openWizard() {
  _wst = await api('/api/setup/status');
  document.getElementById('wizardOverlay').style.display = 'flex';
  wizStep = 1; renderWiz();
}
function closeWizard() {
  document.getElementById('wizardOverlay').style.display = 'none';
  loadStreams('active');
}
async function wizNav(dir) {
  if (dir > 0 && STEPS[wizStep].onNext) {
    await STEPS[wizStep].onNext();
    // If we were on the last step, onNext() calls closeWizard() — stop here.
    if (wizStep === WIZ_TOTAL) return;
  }
  wizStep = Math.max(1, Math.min(WIZ_TOTAL, wizStep + dir));
  _wst = await api('/api/setup/status');
  renderWiz();
}
function wizSkip() { wizStep = Math.min(WIZ_TOTAL, wizStep + 1); renderWiz(); }
function renderWiz() {
  const s = STEPS[wizStep];
  if (!s) { console.error('renderWiz: bad step', wizStep); return; }
  // Pills
  document.getElementById('wizPills').innerHTML = Object.entries(STEPS)
    .map(([n, st]) => `<div class="wiz-pill ${+n < wizStep ? 'done' : +n === wizStep ? 'active' : ''}">${esc(st.label)}</div>`).join('');
  // Guard render against template crashes
  try {
    document.getElementById('wizBody').innerHTML = s.render(_wst || {});
  } catch(err) {
    document.getElementById('wizBody').innerHTML =
      '<div class="info-box" style="color:var(--red)">⚠️ Render error — check browser console. ' + esc(String(err)) + '</div>';
    console.error('renderWiz step ' + wizStep, err);
  }
  document.getElementById('wizBack').style.visibility = wizStep > 1 ? 'visible' : 'hidden';
  document.getElementById('wizNext').textContent = wizStep === WIZ_TOTAL ? 'Finish' : 'Next →';
  document.getElementById('wizHint').innerHTML = s.canSkip
    ? `<button class="ghost sm" onclick="wizSkip()">${esc(s.skipLabel||'Skip')}</button>` : '';
}
async function wizSave(arr, url, key) {
  await api('/api/settings',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({settings:{[arr+'_url']:url,[arr+'_api_key']:key}})});
}
async function wizTestAD() {
  const k = v('wAdKey');
  const res = document.getElementById('wAdResult');
  if (!k) { res.innerHTML='<span style="color:var(--red)">Enter your API key first.</span>'; return; }
  res.innerHTML='<span class="spinner"></span>Testing…';
  await api('/api/settings',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({settings:{alldebrid_api_key:k}})});
  const d = await api('/api/alldebrid/status');
  if (d.connected) {
    res.innerHTML='<span class="dot dot-green"></span>Connected'+(d.username?' as <strong>'+esc(d.username)+'</strong>':'');
    // Refresh status so DFS mount state updates
    _wst = await api('/api/setup/status');
    renderWiz();
  } else {
    res.innerHTML='<span style="color:var(--red)">❌ '+esc(d.error||'Connection failed')+'</span>';
  }
}
async function wizTest(arr) {
  const cap = arr[0].toUpperCase()+arr.slice(1);
  const url = v('w'+cap+'Url'), key = v('w'+cap+'Key');
  const res = document.getElementById('w'+cap+'Result');
  if (!url) { res.innerHTML='<span style="color:var(--red)">Enter the URL first.</span>'; return; }
  res.innerHTML='<span class="spinner"></span>Testing…';
  // Only save if both fields are filled; if key is blank, use whatever is already stored.
  if (key) await wizSave(arr, url, key);
  else if (url) await api('/api/settings',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({settings:{[arr+'_url']:url}})});
  const d = await api('/api/arr/'+arr+'/status');
  if (d.connected) {
    res.innerHTML=`<span class="dot dot-green"></span>Connected${d.status?.version?' — v'+d.status.version:''}`;
    api('/api/library/sync',{method:'POST'});
  } else {
    res.innerHTML='<span style="color:var(--red)">❌ Could not connect. Check URL and API key.</span>';
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN APP
// ─────────────────────────────────────────────────────────────────────────────
async function api(url, opts) {
  try { const r = await fetch(url, opts||{}); return await r.json(); }
  catch(e) { return {error:String(e)}; }
}
function v(id) { const el=document.getElementById(id); return el?el.value.trim():''; }
function esc(s){ return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function pad(n){ return String(n||0).padStart(2,'0'); }

function show(id) {
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b=>b.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  event.currentTarget.classList.add('active');
  if(id==='streams')     loadStreams('active');
  if(id==='library')     loadLibrary();
  if(id==='connections') loadConnections();
  if(id==='fuse')        loadFuse();
}

// ── STREAMS ──────────────────────────────────────────────────────────────────
function bStatus(s) {
  const m={active:'badge-green',expired:'badge-orange',removed:'badge-red'};
  return `<span class="badge ${m[s]||'badge-gray'}">${s}</span>`;
}
function daysLeft(exp) {
  const d=(new Date(exp)-Date.now())/86400000;
  if(d<0)  return '<span style="color:var(--red)">expired</span>';
  if(d<3)  return `<span style="color:var(--orange)">${d.toFixed(1)}d left</span>`;
  return `<span style="color:var(--green)">${Math.ceil(d)}d left</span>`;
}
async function loadStreams(status='active') {
  const data = await api('/api/streams?status='+status);
  const el = document.getElementById('streamsTable');
  if (!data.streams||!data.streams.length) { el.innerHTML='<div class="empty">No streams</div>'; return; }
  el.innerHTML=`<table>
    <tr><th>Title</th><th>Type</th><th>ARR</th><th>Status</th><th>Expires</th><th>Path</th><th></th></tr>
    ${data.streams.map(s=>`<tr>
      <td><strong>${esc(s.title)}</strong>${s.season!=null?' <span style="color:var(--sub)">S'+pad(s.season)+'E'+pad(s.episode)+'</span>':''}</td>
      <td>${esc(s.media_type)}</td>
      <td><span class="badge badge-blue">${esc(s.arr)}</span></td>
      <td>${bStatus(s.status)}</td>
      <td>${s.status==='active'?daysLeft(s.expires_at):'-'}</td>
      <td class="mono">${esc(s.symlink_path)}</td>
      <td>${s.status==='active'?`<button class="danger sm" onclick="deleteStream('${s.id}')">Expire</button>`:''}</td>
    </tr>`).join('')}
  </table>`;
}
async function runCleanup(){
  const d=await api('/api/streams/cleanup',{method:'POST'});
  alert('Cleanup done. Expired: '+(d.expired_removed||[]).length);
  loadStreams('active');
}
async function deleteStream(id){
  if(!confirm('Expire this stream and revert to placeholder?'))return;
  await api('/api/streams/'+id,{method:'DELETE'});
  loadStreams('active');
}

// ── LIBRARY ───────────────────────────────────────────────────────────────────
let _libData = [];

async function loadLibrary() {
  const filter = document.getElementById('libFilter').value;
  document.getElementById('libraryGrid').innerHTML = '<div class="empty">Loading…</div>';
  const data = await api('/api/library?arr='+filter);
  _libData = data.library || [];
  renderLibrary();
}

function filterLibrary() {
  renderLibrary();
}

function renderLibrary() {
  const query = (document.getElementById('libSearch').value || '').toLowerCase();
  const items = query ? _libData.filter(l => (l.title||'').toLowerCase().includes(query)) : _libData;
  const grid  = document.getElementById('libraryGrid');
  const stats = document.getElementById('libStats');

  if (!items.length) {
    grid.innerHTML = '<div class="empty">No library items. Try syncing.</div>';
    stats.textContent = '';
    return;
  }

  // Group: movies flat, TV shows grouped by title → season → episodes
  const shows  = {};   // title → { meta, seasons: { S → [episodes] } }
  const movies = [];

  for (const l of items) {
    if (l.media_type === 'movie') {
      movies.push(l);
    } else {
      if (!shows[l.title]) shows[l.title] = { title: l.title, year: l.year, arr: l.arr, seasons: {} };
      const s = l.season ?? 0;
      if (!shows[l.title].seasons[s]) shows[l.title].seasons[s] = [];
      shows[l.title].seasons[s].push(l);
    }
  }

  // Stats
  const tvCount    = Object.keys(shows).length;
  const epCount    = items.filter(l=>l.media_type==='episode').length;
  const movieCount = movies.length;
  stats.textContent = [
    tvCount    ? tvCount+' show'+(tvCount!==1?'s':'')+' · '+epCount+' episode'+(epCount!==1?'s':'') : '',
    movieCount ? movieCount+' movie'+(movieCount!==1?'s':'') : ''
  ].filter(Boolean).join(' · ');

  let html = '<div class="lib-grid">';

  // ── TV Show cards ──
  for (const [title, show] of Object.entries(shows).sort((a,b)=>a[0].localeCompare(b[0]))) {
    const seasonNums = Object.keys(show.seasons).map(Number).sort((a,b)=>a-b);
    const totalEps   = seasonNums.reduce((n,s)=>n+show.seasons[s].length, 0);
    const activeEps  = Object.values(show.seasons).flat().filter(e=>_isActive(e.id)).length;
    html += `
    <div class="lib-card">
      <div class="lib-card-header">
        <div class="lib-card-icon">📺</div>
        <div class="lib-card-meta">
          <h2 title="${esc(title)}">${esc(title)}</h2>
          <div class="sub">
            ${show.year ? `<span>${show.year}</span>` : ''}
            <span class="badge badge-blue">Sonarr</span>
            <span>${seasonNums.length} season${seasonNums.length!==1?'s':''}</span>
            <span>${totalEps} ep${totalEps!==1?'s':''}</span>
            ${activeEps ? `<span class="badge badge-green">${activeEps} active</span>` : ''}
          </div>
          <div class="progress-bar" style="margin-top:6px">
            <div class="progress-fill" style="width:${totalEps?Math.round(activeEps/totalEps*100):0}%"></div>
          </div>
        </div>
      </div>
      <div class="season-list">
        ${seasonNums.map(s => {
          const eps = show.seasons[s].slice().sort((a,b)=>(a.episode||0)-(b.episode||0));
          const sid = 'season_'+title.replace(/\W/g,'_')+'_'+s;
          return `
          <div class="season-row">
            <div class="season-header" onclick="toggleSeason('${sid}')">
              <span class="season-label">Season ${pad(s)}</span>
              <span class="season-eps-count">${eps.length} ep${eps.length!==1?'s':''}</span>
              <span class="season-chevron" id="chev_${sid}">›</span>
            </div>
            <div class="ep-list" id="${sid}">
              ${eps.map(ep=>`
              <div class="ep-row">
                <span class="ep-num">E${pad(ep.episode)}</span>
                <span class="ep-title" title="${esc(ep.title||'')}">${esc(ep.title||'Episode '+ep.episode)}</span>
                <span class="ep-status">${epStatusBadge(ep)}</span>
                <button class="sm" style="margin-left:6px" onclick="activateItem('${ep.id}')">▶</button>
              </div>`).join('')}
            </div>
          </div>`;
        }).join('')}
      </div>
      <div class="lib-card-footer">
        <span style="font-size:12px;color:var(--sub)">${totalEps} placeholder${totalEps!==1?'s':''}</span>
        <button class="sm primary" onclick="activateShow('${esc(title)}')">Activate All</button>
      </div>
    </div>`;
  }

  // ── Movie cards ──
  for (const m of movies.sort((a,b)=>(a.title||'').localeCompare(b.title||''))) {
    const active = _isActive(m.id);
    html += `
    <div class="lib-card">
      <div class="lib-card-header">
        <div class="lib-card-icon">🎬</div>
        <div class="lib-card-meta">
          <h2 title="${esc(m.title)}">${esc(m.title)}</h2>
          <div class="sub">
            ${m.year ? `<span>${m.year}</span>` : ''}
            <span class="badge badge-blue">Radarr</span>
            ${active ? '<span class="badge badge-green">active</span>' : ''}
          </div>
          <div class="mono" style="margin-top:5px;font-size:10px">${esc(m.placeholder)}</div>
        </div>
      </div>
      <div class="lib-card-footer">
        <span style="font-size:12px;color:var(--sub)">${active?'Streaming':'Placeholder'}</span>
        <button class="sm ${active?'':'primary'}" onclick="activateItem('${m.id}')" ${active?'disabled':''}>
          ${active ? '✓ Active' : '▶ Activate'}
        </button>
      </div>
    </div>`;
  }

  html += '</div>';
  grid.innerHTML = html;
}

// Track which library IDs currently have active streams (populated by loadStreams)
let _activeIds = new Set();
function _isActive(libId) { return _activeIds.has(libId); }

function toggleSeason(sid) {
  const list = document.getElementById(sid);
  const chev = document.getElementById('chev_'+sid);
  if (!list) return;
  const open = list.classList.toggle('open');
  chev.classList.toggle('open', open);
}

function epStatusBadge(ep) {
  if (_isActive(ep.id)) return '<span class="badge badge-green">active</span>';
  return '<span class="badge badge-gray">placeholder</span>';
}

// ── PICKER ───────────────────────────────────────────────────────────────────
let _pickerTab  = 'sonarr';
let _pickerData = { sonarr: null, radarr: null };

async function openPicker() {
  document.getElementById('pickerOverlay').classList.add('open');
  document.getElementById('pickerSearch').value = '';
  switchPickerTab('sonarr');
}

function closePicker() {
  document.getElementById('pickerOverlay').classList.remove('open');
}

async function switchPickerTab(tab) {
  _pickerTab = tab;
  document.getElementById('ptabSonarr').classList.toggle('active', tab === 'sonarr');
  document.getElementById('ptabRadarr').classList.toggle('active', tab === 'radarr');
  document.getElementById('pickerSearch').value = '';
  await loadPickerData(tab);
}

async function loadPickerData(tab) {
  document.getElementById('pickerList').innerHTML = '<div class="picker-empty"><span class="spinner"></span> Loading…</div>';
  if (!_pickerData[tab]) {
    const url = tab === 'sonarr' ? '/api/arr/sonarr/series' : '/api/arr/radarr/movies';
    const d   = await api(url);
    _pickerData[tab] = tab === 'sonarr' ? (d.series || []) : (d.movies || []);
  }
  renderPickerList();
}

function filterPicker() {
  renderPickerList();
}

function renderPickerList() {
  const q    = document.getElementById('pickerSearch').value.toLowerCase();
  const data = _pickerData[_pickerTab] || [];
  const items = q ? data.filter(i => (i.title||'').toLowerCase().includes(q)) : data;
  const list  = document.getElementById('pickerList');
  const count = document.getElementById('pickerCount');

  count.textContent = items.length + ' item' + (items.length !== 1 ? 's' : '');

  if (!items.length) {
    list.innerHTML = '<div class="picker-empty">No results</div>';
    return;
  }

  const icon = _pickerTab === 'sonarr' ? '📺' : '🎬';
  list.innerHTML = items.map(item => `
    <div class="picker-item ${item.imported ? 'imported' : ''}" id="pitem_${item.id}">
      <div class="picker-item-icon">${icon}</div>
      <div class="picker-item-meta">
        <strong>${esc(item.title)}</strong>
        <span>${item.year || ''}${item.year && (item.seasons || item.status) ? ' · ' : ''}${item.seasons ? item.seasons + ' season' + (item.seasons !== 1 ? 's' : '') : ''}${item.status ? (item.seasons ? ' · ' : '') + esc(item.status) : ''}</span>
        ${item.overview ? `<span style="display:block;margin-top:2px;color:var(--sub);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:340px">${esc(item.overview)}</span>` : ''}
      </div>
      <div class="picker-item-action">
        ${item.imported
          ? '<span class="badge badge-green">Added</span>'
          : `<button class="sm primary" onclick="addItem('${_pickerTab}', ${item.id}, '${esc(item.title).replace(/'/g,"\'")}', this)">Add</button>`
        }
      </div>
    </div>`).join('');
}

async function addItem(arr, arrId, title, btn) {
  btn.disabled = true;
  btn.textContent = '…';
  const d = await api('/api/library/add', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({arr, arr_id: arrId})
  });
  if (d.ok) {
    btn.textContent = '✓';
    btn.className = 'sm badge badge-green';
    // Mark as imported in local data
    const entry = (_pickerData[arr] || []).find(i => i.id === arrId);
    if (entry) entry.imported = true;
    // Refresh library in background
    _libData = [];
    loadLibrary();
  } else {
    btn.disabled = false;
    btn.textContent = 'Add';
    alert('Failed: ' + (d.error || d.detail || 'Unknown error'));
  }
}

// Close picker on overlay click
document.getElementById('pickerOverlay').addEventListener('click', function(e) {
  if (e.target === this) closePicker();
});

async function triggerSync() {
  await api('/api/library/sync',{method:'POST'});
  setTimeout(loadLibrary, 2500);
}

async function activateItem(id) {
  const d = await api('/api/library/'+id+'/activate',{method:'POST'});
  if (d.ok) {
    _activeIds.add(id);
    renderLibrary();
    // Switch to streams tab to show the result
    show_tab('streams');
    loadStreams('active');
  } else {
    alert('Failed: '+(d.error||d.detail||'Unknown error'));
  }
}

async function activateShow(title) {
  const eps = _libData.filter(l=>l.title===title && l.media_type==='episode');
  if (!eps.length) return;
  if (!confirm('Activate all '+eps.length+' episodes of '+title+'?\nThis will resolve '+eps.length+' files from the FUSE mount.')) return;
  let ok=0, fail=0;
  for (const ep of eps) {
    const d = await api('/api/library/'+ep.id+'/activate',{method:'POST'});
    if (d.ok) { _activeIds.add(ep.id); ok++; } else fail++;
  }
  renderLibrary();
  alert('Done. Activated: '+ok+(fail?' · Failed: '+fail:''));
}

// ── CONNECTIONS ───────────────────────────────────────────────────────────────
async function loadConnections() {
  document.getElementById('webhookUrl2').textContent = location.origin+'/webhook/tautulli';
  const data = await api('/api/settings');
  const s = data.settings||{};
  document.getElementById('sonarrUrl').value  = s.sonarr_url||'';
  document.getElementById('sonarrKey').value  = s.sonarr_api_key||'';
  document.getElementById('radarrUrl').value  = s.radarr_url||'';
  document.getElementById('radarrKey').value  = s.radarr_api_key||'';
  document.getElementById('tautulliUrl').value   = s.tautulli_url||'';
  document.getElementById('tautulliApiKey').value= s.tautulli_api_key||'';
  document.getElementById('ttlDays').value       = s.symlink_ttl_days||30;
  testArrConn('sonarr'); testArrConn('radarr'); testTautulliConn();
}
async function saveArr(arr) {
  const url = v(arr+'Url'), key = v(arr+'Key');
  await api('/api/settings',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({settings:{[arr+'_url']:url,[arr+'_api_key']:key}})});
  testArrConn(arr);
}
async function testArrConn(arr) {
  const el = document.getElementById(arr+'Status');
  el.innerHTML = '<span class="spinner"></span>Testing…';
  const d = await api('/api/arr/'+arr+'/status');
  el.innerHTML = d.connected
    ? `<span class="dot dot-green"></span>Connected${d.status?.version?' — v'+d.status.version:''}`
    : `<span class="dot dot-red"></span>Not connected`;
}
async function saveTautulli() {
  const url = v('tautulliUrl');
  const key = v('tautulliApiKey');
  const settings = {tautulli_url: url};
  if (key) settings.tautulli_api_key = key;
  await api('/api/settings',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({settings})});
  testTautulliConn();
}

async function testTautulliConn() {
  const el = document.getElementById('tautulliStatus');
  if (!el) return;
  el.innerHTML = '<span class="spinner"></span>Testing…';
  const d = await api('/api/tautulli/status');
  if (d.connected) {
    let label = 'Connected';
    if (d.version) label += ' — v' + d.version;
    if (d.server)  label += ' · ' + d.server;
    el.innerHTML = `<span class="dot dot-green"></span>${esc(label)}`;
  } else {
    el.innerHTML = `<span class="dot dot-red"></span>${esc(d.error || 'Not connected')}`;
  }
}

async function testWebhook() {
  const res = document.getElementById('webhookTestResult');
  res.innerHTML = '<span class="spinner"></span>Firing test play event…';
  const d = await api('/api/webhook/test', {method:'POST'});
  if (d.ok) {
    const wr = d.webhook_response || {};
    const msg = wr.ok
      ? `✅ Webhook flow OK — activated <strong>${esc(d.test_item)}</strong>`
      : `⚠️ Webhook reached but activation failed: ${esc(wr.error||'unknown')} (item: ${esc(d.test_item)})`;
    res.innerHTML = `<span style="color:var(--green)">${msg}</span>`;
  } else {
    res.innerHTML = `<span style="color:var(--red)">❌ ${esc(d.error||'Test failed')}</span>`;
  }
}

function copyWebhookUrl() {
  const url = location.origin + '/webhook/tautulli';
  navigator.clipboard.writeText(url).then(() => {
    const btn = document.getElementById('copyWebhookBtn');
    btn.textContent = '✓ Copied';
    setTimeout(() => btn.textContent = 'Copy', 1800);
  });
}
async function saveTtl() {
  await api('/api/settings',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({settings:{symlink_ttl_days:v('ttlDays')}})});
  alert('TTL saved');
}

// ── FUSE + ALL-DEBRID + DFS ───────────────────────────────────────────────────
async function loadFuse() {
  const d = await api('/api/fuse');

  // DFS FUSE mount
  const dfsColor = d.dfs_mounted ? 'dot-green' : 'dot-red';
  const dfsLabel = d.dfs_mounted ? 'Active' : 'Not mounted';

  // Torrent list
  let torrentHtml = '';
  if (d.torrent_count === 0) {
    torrentHtml = '<div style="color:var(--sub);font-size:12px;margin-top:8px">No torrents registered — make sure your AllDebrid API key is set and the account has ready magnets, then click Reload.</div>';
  } else {
    torrentHtml = `<div style="margin-top:10px">
      <div style="font-size:11px;color:var(--sub);text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px;font-weight:600">${d.torrent_count} torrent(s) registered</div>
      <div style="max-height:200px;overflow-y:auto;background:var(--input-bg);border:1px solid var(--border);border-radius:8px;padding:6px 0">
        ${(d.torrents||[]).map(t => `
          <div style="padding:5px 12px;border-bottom:1px solid var(--border);font-size:12px">
            <div style="font-weight:600;color:var(--text)">${esc(t.name)}</div>
            <div style="color:var(--sub);font-size:11px">${t.files.length} file(s)</div>
          </div>`).join('')}
      </div>
    </div>`;
  }

  document.getElementById('fuseStatus').innerHTML = `
    <div style="display:flex;flex-direction:column;gap:10px">
      <div style="display:flex;align-items:center;gap:8px">
        <span class="dot ${dfsColor}"></span>
        <span style="font-size:13px;font-weight:600">DFS FUSE — ${esc(d.dfs_mount||'')} — ${dfsLabel}</span>
      </div>
      ${torrentHtml}
    </div>`;
  testADStatus();
  loadDFSSettings();
}

async function fuseReload() {
  const btn = document.getElementById('fuseReloadBtn');
  btn.disabled = true; btn.textContent = '⏳ Reloading…';
  const d = await api('/api/fuse/reload', {method:'POST'});
  btn.disabled = false; btn.textContent = '🔄 Reload Torrents';
  if (d.ok) {
    loadFuse();
  } else {
    alert('Reload failed: ' + (d.detail || d.error || 'Unknown error'));
  }
}

async function saveAndTestAD() {
  const key = v('adApiKey');
  if (!key) { alert('Enter your All-Debrid API key first.'); return; }
  await api('/api/settings', {
    method: 'PATCH', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({settings: {alldebrid_api_key: key}})
  });
  testADStatus();
}

async function testADStatus() {
  const el = document.getElementById('alldebridStatus');
  if (!el) return;
  el.innerHTML = '<span class="spinner"></span>Checking…';
  const d = await api('/api/alldebrid/status');
  if (d.connected) {
    const exp = d.expires ? ' · expires ' + new Date(d.expires * 1000).toLocaleDateString() : '';
    el.innerHTML = `<span class="dot dot-green"></span><strong>${esc(d.username)}</strong>`
      + (d.premium ? ' <span class="badge badge-green">Premium</span>' : ' <span class="badge badge-orange">Free</span>')
      + `<span style="color:var(--sub);font-size:12px">${exp}</span>`;
  } else {
    el.innerHTML = `<span class="dot dot-red"></span><span style="color:var(--sub)">${esc(d.error || 'Not connected')}</span>`;
  }
}

async function loadDFSSettings() {
  const d = await api('/api/dfs/settings');
  const s = d.settings || {};
  const set = (id, key, fallback) => {
    const el = document.getElementById(id);
    if (el) el.value = s[key] !== undefined ? s[key] : fallback;
  };
  set('adApiKey',       'alldebrid_api_key', '');
  set('dfsCacheDir',    'dfs_cache_dir',     '/cache/dfs');
  set('dfsCacheSizeGb', 'dfs_cache_size_gb', '50');
  set('dfsCacheTtlH',   'dfs_cache_ttl_h',  '12');
  set('dfsChunkMb',     'dfs_chunk_mb',      '32');
  set('dfsReadAheadMb', 'dfs_read_ahead_mb', '128');
  set('dfsCleanupMin',  'dfs_cleanup_min',   '20');
}

async function saveDFS() {
  const status = document.getElementById('dfsSaveStatus');
  status.innerHTML = '<span class="spinner"></span>';
  await api('/api/dfs/settings', {
    method: 'PATCH', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({settings: {
      dfs_cache_dir:     v('dfsCacheDir'),
      dfs_cache_size_gb: v('dfsCacheSizeGb'),
      dfs_cache_ttl_h:   v('dfsCacheTtlH'),
      dfs_chunk_mb:      v('dfsChunkMb'),
      dfs_read_ahead_mb: v('dfsReadAheadMb'),
      dfs_cleanup_min:   v('dfsCleanupMin'),
    }})
  });
  status.innerHTML = '<span style="color:var(--green)">✓ Saved</span>';
  setTimeout(() => status.innerHTML = '', 2500);
}

// ── HELPERS ───────────────────────────────────────────────────────────────────
function show_tab(id) {
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b=>b.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  document.querySelectorAll('.nav-btn').forEach(b=>{
    if(b.textContent.toLowerCase().trim().startsWith(id.slice(0,3))) b.classList.add('active');
  });
}

// ── INIT ─────────────────────────────────────────────────────────────────────
(async()=>{
  // Retry on error — server may still be starting up (running library sync)
  let st = {};
  for (let attempt = 0; attempt < 5; attempt++) {
    st = await api('/api/setup/status');
    if (!st.error) break;
    await new Promise(r => setTimeout(r, 1200 * (attempt + 1)));
  }
  _wst = st;
  if (!st.setup_complete) {
    openWizard();
  } else {
    document.getElementById('wizardOverlay').style.display = 'none';
    // Prime active stream IDs
    const sd = await api('/api/streams?status=active');
    _activeIds = new Set((sd.streams||[]).map(s=>s.library_id).filter(Boolean));
    loadStreams('active');
  }
})();
</script>
</body>
</html>
"""
