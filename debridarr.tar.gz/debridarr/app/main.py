"""
Debridarr – rebuild
===================
Flow:
  1. Startup → scan Sonarr & Radarr → build library, create empty placeholder files for known media.
  2. Tautulli webhook fires when a user presses Play on a placeholder.
  3. Handler searches Sonarr/Radarr for the real file path on the FUSE mount.
  4. Symlink is created: placeholder path → real FUSE file.
  5. Sonarr/Radarr are notified (rescan) so they see the real file.
  6. After 30 days the symlink expires: symlink reverts to empty placeholder,
     Sonarr/Radarr are told the file is gone (manual unmonitor / rescan).
"""

import os, sqlite3, uuid, shutil, httpx, logging, json, time
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional, Literal, Any

from fastapi import FastAPI, HTTPException, Request, Header, Depends, BackgroundTasks
from fastapi.responses import HTMLResponse, JSONResponse

import asyncio
import os as _os

from app.proxy import proxy_stream, stream_direct, write_strm, delete_strm
from app.decypharr import (
    DecypharrClient,
    list_torrents, list_files,
    get_torrent_file,
    lookup_by_se_tag, lookup_by_stem,
    lookup_by_title_se, lookup_by_title_word,
    _load_index, _save_index,
    name_for_hash,
)

# DFS FUSE mount point — AllDebrid chunk-cache filesystem


from pydantic import BaseModel, Field

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s – %(message)s")
log = logging.getLogger("debridarr")

# ── Env config ────────────────────────────────────────────────────────────────
DB_PATH           = os.getenv("DB_PATH",          "/data/debridarr.db")
STREAMS_PATH      = Path(os.getenv("STREAMS_PATH", "/streams"))
STRM_ROOT         = Path(os.getenv("STRM_ROOT", "/streams"))       # where .strm files are written for Plex
DEBRIDARR_BASE_URL= os.getenv("DEBRIDARR_BASE_URL", "http://debridarr:7474").rstrip("/")
SYMLINK_TTL_DAYS  = int(os.getenv("SYMLINK_TTL_DAYS", "30"))
PLACEHOLDER_EXT   = os.getenv("PLACEHOLDER_EXT", ".mp4")
API_KEY           = os.getenv("API_KEY", "").strip()

SONARR_URL        = os.getenv("SONARR_URL", "").rstrip("/")
SONARR_API_KEY    = os.getenv("SONARR_API_KEY", "")
RADARR_URL        = os.getenv("RADARR_URL", "").rstrip("/")
RADARR_API_KEY    = os.getenv("RADARR_API_KEY", "")

TAUTULLI_URL      = os.getenv("TAUTULLI_URL", "").rstrip("/")
TAUTULLI_API_KEY  = os.getenv("TAUTULLI_API_KEY", "")
PLEX_URL          = os.getenv("PLEX_URL", "").rstrip("/")
PLEX_TOKEN        = os.getenv("PLEX_TOKEN", "")


DECYPHARR_URL       = os.getenv("DECYPHARR_URL", "").rstrip("/")
DECYPHARR_API_TOKEN = os.getenv("DECYPHARR_API_TOKEN", "")
DECYPHARR_MOUNT     = os.getenv("DECYPHARR_MOUNT", "")  # e.g. /mnt/decypharr/__all__


# ── DB helpers ────────────────────────────────────────────────────────────────

import struct as _struct

def _load_placeholder() -> bytes:
    """Load the bundled placeholder.mp4, falling back to a minimal valid MP4 stub."""
    candidate = Path(__file__).parent / "placeholder.mp4"
    if candidate.exists():
        return candidate.read_bytes()
    # Fallback: minimal valid mp4 (silent, 1 s) so Plex/Tautulli recognise the file
    def box(t, p):
        return _struct.pack(">I", 8 + len(p)) + t + p
    ftyp = box(b"ftyp", b"mp42\x00\x00\x00\x00mp42isom")
    mvhd = box(b"mvhd",
        b"\x00" * 12
        + _struct.pack(">I", 1000) + _struct.pack(">I", 1000)
        + _struct.pack(">I", 0x00010000) + _struct.pack(">H", 0x0100)
        + b"\x00" * 10
        + _struct.pack(">9i", 0x00010000,0,0, 0,0x00010000,0, 0,0,0x40000000)
        + b"\x00" * 24 + _struct.pack(">I", 2)
    )
    return ftyp + box(b"moov", mvhd)

_FAKE_MP4 = _load_placeholder()

def get_conn():
    c = sqlite3.connect(DB_PATH, timeout=30)
    c.row_factory = sqlite3.Row
    # busy_timeout FIRST so every subsequent statement (incl. the journal_mode
    # switch) waits for a lock instead of failing with "database is locked".
    c.execute("PRAGMA busy_timeout=30000")   # wait up to 30s for a lock
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    c.execute("PRAGMA wal_autocheckpoint=1000")
    c.execute("PRAGMA synchronous=NORMAL")
    return c

def init_db():
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    STREAMS_PATH.mkdir(parents=True, exist_ok=True)
    with get_conn() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS settings (
          key   TEXT PRIMARY KEY,
          value TEXT NOT NULL
        );

        -- Library: every known title from Sonarr/Radarr
        CREATE TABLE IF NOT EXISTS library (
          id            TEXT PRIMARY KEY,
          arr           TEXT NOT NULL,          -- 'sonarr' | 'radarr'
          arr_id        INTEGER NOT NULL,
          media_type    TEXT NOT NULL,           -- 'movie' | 'episode'
          title         TEXT NOT NULL,
          year          INTEGER,
          season        INTEGER,
          episode       INTEGER,
          placeholder   TEXT NOT NULL,          -- empty .mp4 file or .strm file path
          strm_path     TEXT,                    -- .strm file path (new proxy mode)
          synced_at     TEXT NOT NULL,
          UNIQUE(arr, arr_id, season, episode)
        );
        CREATE INDEX IF NOT EXISTS idx_lib_arr  ON library(arr, arr_id);

        -- Active streams: placeholder has been replaced by a real symlink
        CREATE TABLE IF NOT EXISTS streams (
          id              TEXT PRIMARY KEY,
          library_id      TEXT REFERENCES library(id),
          arr             TEXT NOT NULL,
          arr_id          INTEGER,
          media_type      TEXT NOT NULL,
          title           TEXT NOT NULL,
          year            INTEGER,
          season          INTEGER,
          episode         INTEGER,
          source_path     TEXT NOT NULL,        -- real file on FUSE
          symlink_path    TEXT NOT NULL,        -- path of the symlink (==placeholder)
          stream_url      TEXT,                 -- AllDebrid CDN URL for proxy streaming
          cache_key       TEXT,                 -- proxy cache key
          created_at      TEXT NOT NULL,
          expires_at      TEXT NOT NULL,
          last_seen_at    TEXT NOT NULL,
          status          TEXT NOT NULL DEFAULT 'active'
        );
        CREATE INDEX IF NOT EXISTS idx_streams_expires ON streams(expires_at);

        -- Not-found items: spot check confirmed no release exists, skip on future syncs
        CREATE TABLE IF NOT EXISTS not_found (
          id         TEXT PRIMARY KEY,   -- same uuid5 as library id
          arr        TEXT NOT NULL,
          arr_id     INTEGER NOT NULL,
          media_type TEXT NOT NULL,
          title      TEXT NOT NULL,
          season     INTEGER,
          episode    INTEGER,
          checked_at TEXT NOT NULL,
          reason     TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_streams_status  ON streams(status);
        """)

        # Migrations: add new columns to existing DBs
        lib_cols     = {r[1] for r in db.execute("PRAGMA table_info(library)").fetchall()}
        streams_cols = {r[1] for r in db.execute("PRAGMA table_info(streams)").fetchall()}
        if "strm_path"   not in lib_cols:
            db.execute("ALTER TABLE library ADD COLUMN strm_path TEXT")
        if "stream_url"  not in streams_cols:
            db.execute("ALTER TABLE streams ADD COLUMN stream_url TEXT")
        if "cache_key"   not in streams_cols:
            db.execute("ALTER TABLE streams ADD COLUMN cache_key TEXT")

        defaults = {
            "streams_path":      str(STREAMS_PATH),
            "strm_root":         str(STRM_ROOT),
            "debridarr_base_url": DEBRIDARR_BASE_URL,
            "symlink_ttl_days":  str(SYMLINK_TTL_DAYS),
            "placeholder_ext":   PLACEHOLDER_EXT,
            "sonarr_url":        SONARR_URL,
            "sonarr_api_key":    SONARR_API_KEY,
            "radarr_url":        RADARR_URL,
            "radarr_api_key":    RADARR_API_KEY,
            "tautulli_url":      TAUTULLI_URL,
            "tautulli_api_key":  TAUTULLI_API_KEY,
            "plex_url":          PLEX_URL,
            "plex_token":        PLEX_TOKEN,
            # All-Debrid / DFS cache
            "decypharr_url":        DECYPHARR_URL,
            "decypharr_api_token":  DECYPHARR_API_TOKEN,
            "decypharr_mount":      DECYPHARR_MOUNT,

        }
        for k, v in defaults.items():
            # Never overwrite a value the user saved through the UI.
            # Only insert if the row does not exist yet.
            # Env vars are the initial default — DB is the source of truth after first run.
            db.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v))

        # Seed the multi-instance registry on first run / upgrade. Existing
        # single-instance configs migrate to keys "sonarr"/"radarr"; a 4K pair
        # is added so it appears ready to configure in the wizard.
        if not get_setting(db, "arr_instances", ""):
            seed = [
                {"key": "sonarr", "name": "Sonarr", "type": "sonarr",
                 "url": get_setting(db, "sonarr_url", SONARR_URL),
                 "api_key": get_setting(db, "sonarr_api_key", SONARR_API_KEY),
                 "enabled": True},
                {"key": "radarr", "name": "Radarr", "type": "radarr",
                 "url": get_setting(db, "radarr_url", RADARR_URL),
                 "api_key": get_setting(db, "radarr_api_key", RADARR_API_KEY),
                 "enabled": True},
                {"key": "sonarr4k", "name": "Sonarr 4K", "type": "sonarr",
                 "url": "", "api_key": "", "enabled": True},
                {"key": "radarr4k", "name": "Radarr 4K", "type": "radarr",
                 "url": "", "api_key": "", "enabled": True},
            ]
            db.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('arr_instances',?)",
                       (json.dumps(seed),))

# ── Utility ───────────────────────────────────────────────────────────────────
def now_utc() -> datetime:
    return datetime.now(timezone.utc)

def iso(dt: datetime) -> str:
    return dt.isoformat()

def from_iso(s: str) -> datetime:
    return datetime.fromisoformat(s.replace("Z", "+00:00"))

def safe(value: str) -> str:
    import re as _rs
    # Remove apostrophes without splitting ("Grey's" → "Greys", "It's" → "Its")
    v = _rs.sub(r"[’‘'`]", "", (value or "").strip())
    keep = "".join(c if c.isalnum() or c in " ._-()[]" else " " for c in v)
    return " ".join(keep.split()) or "Unknown"

def get_setting(db, key: str, fallback: str = "") -> str:
    row = db.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row else fallback

# ── ARR HTTP helpers ──────────────────────────────────────────────────────────
def arr_headers(api_key: str) -> dict:
    return {"X-Api-Key": api_key, "Accept": "application/json"}

# ── ARR instance registry ─────────────────────────────────────────────────────
# Multiple Sonarr/Radarr instances are supported. They are stored as a JSON list
# in settings['arr_instances'], each entry shaped like:
#   {"key": str, "name": str, "type": "sonarr"|"radarr",
#    "url": str, "api_key": str, "enabled": bool}
#
#   key      immutable slug used in the library `arr` column and on-disk folder
#            paths (/streams/<key>/...). Must be unique.
#   name     free-form display label the user can set to anything in the wizard.
#   type     selects API behaviour (sonarr vs radarr); both speak the v3 API.
#
# The two original single instances migrate to keys "sonarr" and "radarr"; a 4K
# pair ("sonarr4k", "radarr4k") is seeded so they show up ready to configure.

import re as _re_inst

def slugify_key(name: str) -> str:
    s = _re_inst.sub(r"[^a-z0-9]+", "", (name or "").lower())
    return s or "instance"

def _default_instances() -> list[dict]:
    return [
        {"key": "sonarr",   "name": "Sonarr",    "type": "sonarr",
         "url": SONARR_URL, "api_key": SONARR_API_KEY, "enabled": True},
        {"key": "radarr",   "name": "Radarr",    "type": "radarr",
         "url": RADARR_URL, "api_key": RADARR_API_KEY, "enabled": True},
        {"key": "sonarr4k", "name": "Sonarr 4K", "type": "sonarr",
         "url": "", "api_key": "", "enabled": True},
        {"key": "radarr4k", "name": "Radarr 4K", "type": "radarr",
         "url": "", "api_key": "", "enabled": True},
    ]

def _coerce_instance(it: dict) -> dict | None:
    if not isinstance(it, dict):
        return None
    t = it.get("type")
    if t not in ("sonarr", "radarr"):
        return None
    key = (it.get("key") or slugify_key(it.get("name", ""))).strip()
    if not key:
        return None
    return {
        "key":     key,
        "name":    (it.get("name") or key).strip(),
        "type":    t,
        "url":     (it.get("url") or "").rstrip("/"),
        "api_key": it.get("api_key") or "",
        "enabled": bool(it.get("enabled", True)),
    }

def get_instances(db=None) -> list[dict]:
    own = db is None
    if own:
        db = get_conn()
    try:
        raw = get_setting(db, "arr_instances", "")
    finally:
        if own:
            db.close()
    if not raw:
        return _default_instances()
    try:
        data = json.loads(raw)
    except Exception:
        return _default_instances()
    out, seen = [], set()
    for it in data or []:
        ci = _coerce_instance(it)
        if ci and ci["key"] not in seen:
            seen.add(ci["key"])
            out.append(ci)
    return out or _default_instances()

def save_instances(instances: list[dict], db=None) -> list[dict]:
    own = db is None
    if own:
        db = get_conn()
    try:
        clean, seen = [], set()
        for it in instances or []:
            ci = _coerce_instance(it)
            if ci and ci["key"] not in seen:
                seen.add(ci["key"])
                clean.append(ci)
        db.execute(
            "INSERT INTO settings(key,value) VALUES('arr_instances',?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (json.dumps(clean),),
        )
        if own:
            db.commit()
    finally:
        if own:
            db.close()
    return clean

def get_instance(key: str, db=None) -> dict | None:
    for it in get_instances(db):
        if it["key"] == key:
            return it
    return None

def instance_type(key: str, db=None) -> str | None:
    it = get_instance(key, db)
    return it["type"] if it else None

def instances_of_type(t: str, only_enabled: bool = True, db=None) -> list[dict]:
    return [it for it in get_instances(db)
            if it["type"] == t and (it["enabled"] or not only_enabled)]

def primary_instance(t: str, db=None) -> dict | None:
    """First configured+enabled instance of a type, else first of that type."""
    insts = get_instances(db)
    for it in insts:
        if it["type"] == t and it["enabled"] and it["url"] and it["api_key"]:
            return it
    for it in insts:
        if it["type"] == t:
            return it
    return None

def primary_key(t: str) -> str:
    it = primary_instance(t)
    return it["key"] if it else t

# ── Generic ARR HTTP helpers (instance-aware) ─────────────────────────────────
def _inst_conn(key: str) -> tuple[str, str]:
    it = get_instance(key)
    if not it:
        return "", ""
    return it["url"], it["api_key"]

def arr_request(key: str, method: str, path: str,
                params: dict | None = None, payload: dict | None = None,
                timeout: int = 15):
    url, api = _inst_conn(key)
    if not url or not api:
        return None
    try:
        r = httpx.request(method, f"{url}/api/v3{path}",
                          headers=arr_headers(api), params=params,
                          json=payload, timeout=timeout)
        r.raise_for_status()
        if r.status_code == 204 or not r.content:
            return {}
        return r.json()
    except Exception as e:
        log.warning("%s %s %s failed: %s", key, method, path, e)
        return None

def arr_get(key: str, path: str, params: dict | None = None):
    return arr_request(key, "GET", path, params=params)

def arr_post(key: str, path: str, payload: dict):
    return arr_request(key, "POST", path, payload=payload)

def arr_put(key: str, path: str, payload: dict):
    return arr_request(key, "PUT", path, payload=payload)

def arr_delete(key: str, path: str) -> bool:
    url, api = _inst_conn(key)
    if not url or not api:
        return False
    try:
        r = httpx.delete(f"{url}/api/v3{path}", headers=arr_headers(api), timeout=10)
        log.info("%s DELETE %s → %s", key, path, r.status_code)
        return r.status_code in (200, 204)
    except Exception as e:
        log.warning("%s DELETE %s failed: %s", key, path, e)
        return False

# ── Legacy single-instance wrappers (operate on the primary instance) ─────────
# Kept so the many endpoints that still talk to "the" Sonarr/Radarr keep working.
def sonarr_get(path, params=None):  return arr_get(primary_key("sonarr"), path, params)
def sonarr_post(path, payload):     return arr_post(primary_key("sonarr"), path, payload)
def sonarr_put(path, payload):      return arr_put(primary_key("sonarr"), path, payload)
def radarr_get(path, params=None):  return arr_get(primary_key("radarr"), path, params)
def radarr_post(path, payload):     return arr_post(primary_key("radarr"), path, payload)
def radarr_put(path, payload):      return arr_put(primary_key("radarr"), path, payload)

# ── Placeholder helpers ───────────────────────────────────────────────────────
def instance_strm_root(key: str) -> Path:
    """Root folder for an instance's placeholder tree.

    The default `sonarr`/`radarr` instances keep the original flat layout
    (`/streams/tv`, `/streams/movies`) so existing Plex libraries keep working.
    Any additional instance (e.g. `sonarr4k`) is namespaced under its key
    (`/streams/sonarr4k/tv`) so a 1080p and a 4K copy never collide. Point a
    separate Plex library at each extra instance's folder.
    """
    if key in ("sonarr", "radarr"):
        return STRM_ROOT
    return STRM_ROOT / key

def placeholder_path(arr: str, media_type: str, title: str, year: int | None,
                     season: int | None, episode: int | None) -> Path:
    """Return the placeholder (.mp4) path for this item.

    Placeholders are real, playable .mp4 files (the bundled "please wait"
    video) so Plex always has something to show. On play, the file is swapped
    in place for a symlink to the real media.
    """
    t   = safe(title)
    ext = PLACEHOLDER_EXT or ".mp4"
    root = instance_strm_root(arr or "sonarr")
    if media_type == "movie":
        folder = f"{t} ({year})" if year else t
        return root / "movies" / folder / f"{folder}{ext}"
    s = int(season or 0)
    e = int(episode or 0)
    return root / "tv" / t / f"Season {s:02d}" / f"{t} - S{s:02d}E{e:02d}{ext}"

def _clear_stale_strm(path: Path):
    """Remove a leftover sibling .strm from the old proxy-mode layout so Plex
    doesn't index a broken duplicate next to the .mp4 placeholder."""
    try:
        if path.suffix != ".strm":
            sib = path.with_suffix(".strm")
            if sib.exists() or sib.is_symlink():
                sib.unlink(missing_ok=True)
    except Exception:
        pass

def ensure_placeholder(path: Path, title: str = "", year=None,
                       season=None, episode=None, cache_key: str = ""):
    """Ensure a real, playable .mp4 placeholder exists at `path`.

    Writes the bundled waiting video (`_FAKE_MP4`) so Plex can play it
    immediately. When the real file is resolved, `_make_symlink` replaces this
    placeholder in place with a symlink to the actual media.
    """
    path.parent.mkdir(parents=True, exist_ok=True)

    # Active symlink (live stream) — leave it
    if path.is_symlink() and path.exists():
        return

    # Remove dead symlink or empty/zero-byte file so we re-write a good one
    if path.is_symlink() and not path.exists():
        path.unlink(missing_ok=True)
    elif path.exists() and path.stat().st_size == 0:
        path.unlink(missing_ok=True)

    _clear_stale_strm(path)

    if not path.exists():
        path.write_bytes(_FAKE_MP4)

def revert_to_placeholder(path: Path, library_id: str = ""):
    """Remove an expired symlink/stream and restore the .mp4 waiting video."""
    try:
        if path.is_symlink() or path.exists():
            path.unlink(missing_ok=True)
    except Exception:
        pass

    # Clear proxy cache so a future resolve starts fresh
    if library_id and library_id in _proxy_db._data:
        del _proxy_db._data[library_id]
        _proxy_db._save()

    _clear_stale_strm(path)
    ensure_placeholder(path)


def sweep_strm_placeholders() -> int:
    """One-time migration: replace every leftover .strm placeholder (old proxy
    mode) with the .mp4 waiting video, and point library rows at the .mp4.

    This is what keeps Plex from ever opening a .strm (a network URL) — which is
    what produced the `s1001 (Network)` errors. After this runs, rescan the Plex
    libraries so they drop the old .strm items and index the .mp4 placeholders.
    """
    root = Path(STRM_ROOT)
    if not root.exists():
        return 0
    converted = 0
    for strm in root.rglob("*.strm"):
        try:
            mp4 = strm.with_suffix(".mp4")
            if not (mp4.exists() or mp4.is_symlink()):
                mp4.parent.mkdir(parents=True, exist_ok=True)
                mp4.write_bytes(_FAKE_MP4)
            strm.unlink(missing_ok=True)
            converted += 1
        except Exception as e:
            log.debug("sweep .strm %s: %s", strm, e)
    # Repoint any library rows that still reference a .strm path
    try:
        with get_conn() as db:
            db.execute(
                "UPDATE library SET placeholder = substr(placeholder,1,length(placeholder)-5) || '.mp4' "
                "WHERE placeholder LIKE '%.strm'"
            )
    except Exception as e:
        log.debug("sweep row repoint: %s", e)
    if converted:
        log.info("🧹 Converted %d leftover .strm placeholder(s) → .mp4 — rescan Plex to refresh",
                 converted)
    return converted

# ── NFO generation ────────────────────────────────────────────────────────────
# Plex NFO Agent (PMS ≥ 1.43.1) reads Kodi-format XML alongside the media file.
# By writing these, Plex skips the online metadata lookup and matches instantly,
# which dramatically speeds up library scans for placeholder files.
#
# File layout expected by Plex NFO Agent:
#   Movies  → <movie folder>/movie.nfo          (or <Filename>.nfo)
#   TV      → <show folder>/tvshow.nfo           (series-level, written once per show)
#             <season folder>/<Episode filename>.nfo  (episode-level)

def _xml_escape(s: str) -> str:
    return (str(s)
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;"))

def _write_nfo(path: Path, content: str):
    """Write NFO only if content has changed, to avoid Plex re-scanning unchanged files."""
    if path.exists():
        try:
            if path.read_text(encoding="utf-8").strip() == content.strip():
                return   # unchanged – don't touch mtime
        except Exception:
            pass
    try:
        path.write_text(content, encoding="utf-8")
    except Exception as exc:
        log.debug("NFO write failed %s: %s", path, exc)

def write_movie_nfo(movie_folder: Path, title: str, year: int | None,
                    tmdb_id: int | None, imdb_id: str | None,
                    plot: str = "", premiered: str = "", studio: str = "",
                    genres: list[str] | None = None):
    """Write movie.nfo in Kodi/Plex NFO Agent format."""
    uid_block = ""
    if tmdb_id:
        uid_block += f'  <uniqueid type="tmdb" default="true">{tmdb_id}</uniqueid>\n'
    if imdb_id:
        uid_block += f'  <uniqueid type="imdb">{_xml_escape(imdb_id)}</uniqueid>\n'
    genre_block = "".join(f"  <genre>{_xml_escape(g)}</genre>\n" for g in (genres or []))

    nfo = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>\n'
        "<movie>\n"
        f"  <title>{_xml_escape(title)}</title>\n"
        f"  <year>{year or ''}</year>\n"
        f"  <plot>{_xml_escape(plot)}</plot>\n"
        f"  <premiered>{_xml_escape(premiered)}</premiered>\n"
        f"  <studio>{_xml_escape(studio)}</studio>\n"
        + uid_block
        + genre_block
        + "</movie>\n"
    )
    _write_nfo(movie_folder / "movie.nfo", nfo)

def write_tvshow_nfo(show_folder: Path, title: str, year: int | None,
                     tvdb_id: int | None, tmdb_id: int | None, imdb_id: str | None,
                     plot: str = "", premiered: str = "", status: str = "",
                     studio: str = "", genres: list[str] | None = None):
    """Write tvshow.nfo – one per show folder, Plex reads it for series-level identity."""
    # Plex NFO Series agent prefers tmdb for TV, but accepts tvdb too.
    uid_block = ""
    if tmdb_id:
        uid_block += f'  <uniqueid type="tmdb" default="true">{tmdb_id}</uniqueid>\n'
    if tvdb_id:
        uid_block += f'  <uniqueid type="tvdb">{tvdb_id}</uniqueid>\n'
    if imdb_id:
        uid_block += f'  <uniqueid type="imdb">{_xml_escape(imdb_id)}</uniqueid>\n'
    genre_block = "".join(f"  <genre>{_xml_escape(g)}</genre>\n" for g in (genres or []))

    nfo = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>\n'
        "<tvshow>\n"
        f"  <title>{_xml_escape(title)}</title>\n"
        f"  <year>{year or ''}</year>\n"
        f"  <plot>{_xml_escape(plot)}</plot>\n"
        f"  <premiered>{_xml_escape(premiered)}</premiered>\n"
        f"  <status>{_xml_escape(status)}</status>\n"
        f"  <studio>{_xml_escape(studio)}</studio>\n"
        + uid_block
        + genre_block
        + "</tvshow>\n"
    )
    _write_nfo(show_folder / "tvshow.nfo", nfo)

def write_episode_nfo(episode_file: Path, title: str, show_title: str,
                      season: int, episode: int,
                      tvdb_ep_id: int | None, tmdb_ep_id: int | None,
                      plot: str = "", aired: str = ""):
    """Write <EpisodeFilename>.nfo alongside the placeholder for episode-level identity."""
    uid_block = ""
    if tvdb_ep_id:
        uid_block += f'  <uniqueid type="tvdb" default="true">{tvdb_ep_id}</uniqueid>\n'
    if tmdb_ep_id:
        uid_block += f'  <uniqueid type="tmdb">{tmdb_ep_id}</uniqueid>\n'

    nfo = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>\n'
        "<episodedetails>\n"
        f"  <title>{_xml_escape(title)}</title>\n"
        f"  <showtitle>{_xml_escape(show_title)}</showtitle>\n"
        f"  <season>{season}</season>\n"
        f"  <episode>{episode}</episode>\n"
        f"  <plot>{_xml_escape(plot)}</plot>\n"
        f"  <aired>{_xml_escape(aired)}</aired>\n"
        + uid_block
        + "</episodedetails>\n"
    )
    # NFO filename must match the video filename exactly (same stem, .nfo extension)
    nfo_path = episode_file.with_suffix(".nfo")
    _write_nfo(nfo_path, nfo)

# ── Library sync ──────────────────────────────────────────────────────────────
def sync_sonarr(db, inst: dict):
    key = inst["key"]
    series_list = arr_get(key, "/series")
    if not series_list:
        return 0
    count = 0
    today = now_utc().date()

    # Fetch episodes with ONE request per series. A single
    # /episode?seriesId=X returns every episode for the series; the loop below
    # already filters out unaired seasons/episodes by air date, so there is no
    # need to fan out a separate request per season (which multiplied a 17-season
    # show into 17 calls).
    import concurrent.futures as _cf

    # Filter series that have aired before fetching episodes
    eligible = []
    for series in series_list:
        premiered = (series.get("firstAired") or "")[:10]
        if premiered:
            try:
                if datetime.fromisoformat(premiered).date() > today:
                    continue
            except ValueError:
                pass
        elif series.get("status", "").lower() == "upcoming":
            continue
        eligible.append(series)

    def _fetch_eps(series):
        sid = series["id"]
        return series, (arr_get(key, "/episode", {"seriesId": sid}) or [])

    episodes_by_sid: dict = {}
    with _cf.ThreadPoolExecutor(max_workers=20) as pool:
        for series, eps in pool.map(_fetch_eps, eligible):
            episodes_by_sid[series["id"]] = (series, eps)

    for sid, (series, episodes) in episodes_by_sid.items():
        title     = series.get("title", "")
        year      = series.get("year")
        plot      = series.get("overview", "")
        status    = series.get("status", "")
        studio    = (series.get("network") or "")
        genres    = series.get("genres", [])
        premiered = (series.get("firstAired") or "")[:10]
        tvdb_id   = series.get("tvdbId")
        imdb_id   = series.get("imdbId")
        tmdb_id   = series.get("tmdbId")

        # Write tvshow.nfo once per show folder
        show_folder = instance_strm_root(key) / "tv" / safe(title)
        show_folder.mkdir(parents=True, exist_ok=True)
        write_tvshow_nfo(show_folder, title, year, tvdb_id, tmdb_id, imdb_id,
                         plot=plot, premiered=premiered, status=status,
                         studio=studio, genres=genres)

        today = now_utc().date()

        # Build a map of season → earliest air date to skip whole unreleased seasons
        season_premiere: dict[int, str] = {}
        for ep in episodes:
            sn = ep.get("seasonNumber")
            ad = (ep.get("airDate") or "")[:10]
            if sn and ad:
                if sn not in season_premiere or ad < season_premiere[sn]:
                    season_premiere[sn] = ad

        for ep in episodes:
            s        = ep.get("seasonNumber")
            e        = ep.get("episodeNumber")
            ep_title = ep.get("title", "")
            ep_plot  = ep.get("overview", "")
            ep_aired = (ep.get("airDate") or "")[:10]
            tvdb_ep  = ep.get("tvdbId")
            tmdb_ep  = ep.get("tmdbId")

            # Skip specials (season 0)
            if not s:
                continue

            # Skip entire season if its premiere date is in the future
            season_first = season_premiere.get(s, "")
            if season_first:
                try:
                    if datetime.fromisoformat(season_first).date() > today:
                        continue
                except ValueError:
                    pass

            # Skip individual unreleased episodes
            if ep_aired:
                try:
                    if datetime.fromisoformat(ep_aired).date() > today:
                        continue
                except ValueError:
                    pass
            elif not ep.get("hasFile"):
                # No air date and no file — skip
                continue

            lib_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"{key}:{sid}:{s}:{e}"))
            # Skip if previously confirmed not found by spot check
            if db.execute("SELECT 1 FROM not_found WHERE id=?", (lib_id,)).fetchone():
                continue
            ph = placeholder_path(key, "episode", title, year, s, e)
            ensure_placeholder(ph)
            write_episode_nfo(ph, ep_title, title, s, e,
                              tvdb_ep_id=tvdb_ep, tmdb_ep_id=tmdb_ep,
                              plot=ep_plot, aired=ep_aired)

            db.execute("""
                INSERT INTO library(id,arr,arr_id,media_type,title,year,season,episode,placeholder,synced_at)
                VALUES(?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET
                  title=excluded.title, year=excluded.year,
                  placeholder=excluded.placeholder, synced_at=excluded.synced_at
            """, (lib_id, key, sid, "episode", title, year, s, e, str(ph), iso(now_utc())))
            count += 1
        # Commit after each series so the write lock is released frequently —
        # otherwise the whole multi-minute sync is one transaction and other
        # writers (e.g. saving settings) fail with "database is locked".
        db.commit()
    return count

def sync_radarr(db, inst: dict):
    key = inst["key"]
    movies = arr_get(key, "/movie")
    if not movies:
        return 0
    count = 0
    today = now_utc().date()
    for movie in movies:
        mid             = movie.get("id")
        title           = movie.get("title", "")
        year            = movie.get("year")
        plot            = movie.get("overview", "")
        digital_release = (movie.get("digitalRelease") or "")[:10]
        physical_release = (movie.get("physicalRelease") or "")[:10]
        in_cinemas      = (movie.get("inCinemas") or "")[:10]
        premiered       = digital_release or physical_release or in_cinemas
        studio          = (movie.get("studio") or "")
        genres          = movie.get("genres", [])
        tmdb_id         = movie.get("tmdbId")
        imdb_id         = movie.get("imdbId")

        # Only include movies after their digital release date
        # Fall back to physical release, then cinema date if digital not set
        release_date = digital_release or physical_release
        if release_date:
            try:
                if datetime.fromisoformat(release_date).date() > today:
                    continue  # not yet digitally released
            except ValueError:
                pass
        elif in_cinemas:
            # No digital/physical date — skip until we know it's available
            continue
        elif not movie.get("hasFile"):
            # No release dates and no file — skip
            continue

        lib_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"{key}:{mid}"))
        # Skip if previously confirmed not found by spot check
        if db.execute("SELECT 1 FROM not_found WHERE id=?", (lib_id,)).fetchone():
            continue
        ph = placeholder_path(key, "movie", title, year, None, None)
        ensure_placeholder(ph)
        write_movie_nfo(ph.parent, title, year, tmdb_id, imdb_id,
                        plot=plot, premiered=premiered, studio=studio, genres=genres)

        db.execute("""
            INSERT INTO library(id,arr,arr_id,media_type,title,year,season,episode,placeholder,synced_at)
            VALUES(?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(id) DO UPDATE SET
              title=excluded.title, year=excluded.year,
              placeholder=excluded.placeholder, synced_at=excluded.synced_at
        """, (lib_id, key, mid, "movie", title, year, None, None, str(ph), iso(now_utc())))
        count += 1
        # Release the write lock periodically so other writers aren't starved
        if count % 25 == 0:
            db.commit()
    db.commit()
    return count


def _set_sonarr_all_unmonitored(key: str):
    """Set all Sonarr episodes unmonitored — Debridarr triggers downloads on play only."""
    series_list = arr_get(key, "/series") or []
    for series in series_list:
        sid = series.get("id")
        if not sid:
            continue
        eps = arr_get(key, "/episode", {"seriesId": sid}) or []
        ids = [ep["id"] for ep in eps if ep.get("monitored")]
        if ids:
            arr_put(key, "/episode/monitor", {"episodeIds": ids, "monitored": False})
            log.info("%s: set %d episodes unmonitored for series %s", key, len(ids), sid)


def _set_radarr_all_unmonitored(key: str):
    """Set all Radarr movies unmonitored — Debridarr triggers downloads on play only."""
    movies = arr_get(key, "/movie") or []
    ids    = [m["id"] for m in movies if m.get("monitored")]
    for movie in movies:
        if movie.get("monitored"):
            arr_put(key, f"/movie/{movie['id']}", {**movie, "monitored": False})
    if ids:
        log.info("%s: set %d movies unmonitored", key, len(ids))


def _restore_active_streams():
    """On startup, repair broken symlinks for active streams.

    For each active stream:
      - Symlink resolves → leave it, still valid
      - Symlink is broken (FUSE not yet up or CDN expired) → re-create it
        pointing to the FUSE path using the stored source_path
      - If FUSE path can't be re-created → restore _FAKE_MP4 placeholder
        so Plex still shows the item and next play triggers a fresh search
    """
    with get_conn() as db:
        rows = db.execute(
            "SELECT * FROM streams WHERE status='active'"
        ).fetchall()

    repaired = valid = failed = 0
    for row in rows:
        row     = dict(row)
        sym     = Path(row["symlink_path"])
        source  = Path(row["source_path"]) if row.get("source_path") else None
        title   = row.get("title", "")
        season  = row.get("season")
        episode = row.get("episode")
        m_type  = row.get("media_type", "")

        # Already valid — leave it
        if sym.is_symlink() and sym.exists():
            valid += 1
            continue

        log.info("🔧 Repairing broken symlink [%s]: %s", m_type.upper(), sym.name)

        real = None

        # 1. Exact stored path — trust registry, don't call .exists() which hits CDN
        if source:
            src_torrent = source.parent.name
            src_fname   = source.name
            f = get_torrent_file(src_torrent, src_fname)
            if f:
                real = source
                log.info("   → found in registry (exact): %s/%s", src_torrent, src_fname)

        # 2. Stem index — filename without extension
        if not real and source:
            hits = lookup_by_stem(source.stem)
            if hits:
                torrent_name, fname = hits[0]
                real = (_dc_client.get_file_path(torrent_name, fname) if _dc_client else None) or None
                log.info("   → found via stem index: %s/%s", torrent_name, fname)

        # 3. S/E tag index for episodes
        if not real and season and episode:
            se_tag = f"S{int(season):02d}E{int(episode):02d}"
            hits   = lookup_by_se_tag(se_tag)
            if hits:
                # Score against title to pick best match
                best_score, best = 0.0, None
                for torrent_name, fname in hits:
                    score = _score_fuse_match(title, row.get("year"), torrent_name)
                    score = max(score, _score_fuse_match(title, row.get("year"), Path(fname).stem))
                    if score > best_score:
                        best_score, best = score, (torrent_name, fname)
                if best:
                    torrent_name, fname = best
                    real = (_dc_client.get_file_path(torrent_name, fname) if _dc_client else None)
                    log.info("   → found via S/E index (score=%.2f): %s/%s",
                             best_score, torrent_name, fname)

        # 4. Title + year search for movies
        if not real and m_type == "movie":
            fuse_match = _find_in_fuse(title, row.get("year"), None, None)
            if fuse_match:
                torrent_name, fname, _ = fuse_match
                real = (_dc_client.get_file_path(torrent_name, fname) if _dc_client else None)
                log.info("   → found via movie title search: %s/%s", torrent_name, fname)

        if real:
            try:
                sym.parent.mkdir(parents=True, exist_ok=True)
                if sym.is_symlink() or sym.exists():
                    sym.unlink(missing_ok=True)
                sym.symlink_to(str(real))
                # Update source_path in DB if it changed
                if str(real) != row.get("source_path"):
                    with get_conn() as db:
                        db.execute("UPDATE streams SET source_path=?, last_seen_at=? WHERE id=?",
                                   (str(real), iso(now_utc()), row["id"]))
                log.info("   ✅ Repaired: %s → %s", sym.name, real.name)
                repaired += 1
                continue
            except Exception as e:
                log.warning("   ❌ Repair failed: %s", e)

        # Nothing found — restore placeholder so Plex still shows the item
        log.warning("   ⚠️  Not in Decypharr — restoring placeholder for %s", title)
        try:
            sym.parent.mkdir(parents=True, exist_ok=True)
            if sym.is_symlink() or sym.exists():
                sym.unlink(missing_ok=True)
            sym.write_bytes(_FAKE_MP4)
        except Exception as e:
            log.warning("   ❌ Placeholder restore failed: %s", e)
        failed += 1

    log.info("Startup stream repair: ✅ %d valid  🔧 %d repaired  ⚠️  %d need re-play",
             valid, repaired, failed)


def _cleanup_stale_placeholders(sync_start: str) -> int:
    """Delete library rows not updated in this sync (unreleased/filtered items)
    and remove their placeholder files from disk if they are plain files (not symlinks).
    Active streams are never removed.
    """
    removed = 0
    with get_conn() as db:
        db.execute("PRAGMA foreign_keys=OFF")
        # Find rows not touched by this sync and not active streams
        stale = db.execute("""
            SELECT l.* FROM library l
            WHERE l.synced_at < ?
            AND NOT EXISTS (
                SELECT 1 FROM streams s
                WHERE s.library_id = l.id AND s.status = 'active'
            )
        """, (sync_start,)).fetchall()

        # Filter out rows whose placeholder is a valid symlink
        # (active streams that weren't recorded, or pre-linked FUSE files)
        stale = [r for r in stale
                 if not (Path(r["placeholder"]).is_symlink()
                         and Path(r["placeholder"]).exists())]

        for row in stale:
            ph = Path(row["placeholder"])
            # Only delete plain placeholder files — never touch active symlinks
            if ph.exists() and not ph.is_symlink():
                try:
                    ph.unlink(missing_ok=True)
                    # Remove empty parent dirs (Season XX folder)
                    try:
                        ph.parent.rmdir()
                    except OSError:
                        pass
                    log.info("Removed stale placeholder: %s", ph)
                except Exception as e:
                    log.warning("Could not remove stale placeholder %s: %s", ph, e)
            elif ph.is_symlink() and not ph.exists():
                # Dead symlink — remove it
                ph.unlink(missing_ok=True)
                log.info("Removed dead symlink: %s", ph)

            # Remove all stream references first to satisfy FK constraint
            # Active streams for stale items shouldn't exist (filtered above)
            # but delete all just to be safe
            db.execute("DELETE FROM streams WHERE library_id=?", (row["id"],))
            db.execute("DELETE FROM library WHERE id=?", (row["id"],))
            removed += 1
            if removed % 50 == 0:
                db.commit()   # release the write lock periodically

        db.execute("PRAGMA foreign_keys=ON")
        db.commit()
    log.info("Cleaned up %d stale placeholder(s)", removed)
    return removed


def _presymlink_from_fuse():
    """After sync, symlink every library item that already exists in FUSE.
    Runs in background so plays are instant for content already in AllDebrid.
    Skips items already symlinked or with active streams.
    """
    import time as _time
    _time.sleep(3)  # wait for FUSE registry to settle after sync

    with get_conn() as db:
        rows = db.execute(
            """SELECT l.* FROM library l
               WHERE NOT EXISTS (
                 SELECT 1 FROM streams s
                 WHERE s.library_id = l.id AND s.status = 'active'
               )"""
        ).fetchall()

    log.info("Pre-symlink scan: checking %d library items against FUSE", len(rows))
    linked = skipped = 0

    for row in rows:
        ph = Path(row["placeholder"])
        # Already symlinked
        if ph.is_symlink() and ph.exists():
            skipped += 1
            continue

        lib    = dict(row)
        title  = lib["title"]
        year   = lib.get("year")
        season = lib.get("season")
        episode = lib.get("episode")

        fuse_match = _find_in_fuse(title, year, season, episode)
        if not fuse_match:
            skipped += 1
            continue

        torrent_name, fname, _ = fuse_match
        real = (_dc_client.get_file_path(torrent_name, fname) if _dc_client else None)

        # Create symlink and record stream
        try:
            ph.parent.mkdir(parents=True, exist_ok=True)
            if ph.is_symlink() or ph.exists():
                ph.unlink(missing_ok=True)
            ph.symlink_to(str(real))

            stream_id = str(uuid.uuid4())
            now       = iso(now_utc())
            expires   = iso(now_utc() + timedelta(days=SYMLINK_TTL_DAYS))
            with get_conn() as db:
                db.execute("""
                    INSERT OR IGNORE INTO streams
                    (id,library_id,arr,arr_id,media_type,title,year,season,episode,
                     source_path,symlink_path,created_at,expires_at,last_seen_at,status)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (stream_id, lib["id"], lib["arr"], lib["arr_id"], lib["media_type"],
                      title, year, season, episode,
                      str(real), str(ph), now, expires, now, "active"))
            # Mark as cached in proxy DB so proxy fast-paths immediately
            ad_link = fuse_match[2].get("l", "")
            if ad_link:
                _proxy_db.set_cached(lib["id"], ad_link, fuse_match[1])
            linked += 1
        except Exception as e:
            log.debug("Pre-symlink failed for %s: %s", title, e)
            skipped += 1

    log.info("Pre-symlink complete: %d linked, %d skipped", linked, skipped)


def full_library_sync():
    sync_start = iso(now_utc())
    totals = {"sonarr": 0, "radarr": 0}
    with get_conn() as db:
        instances = get_instances(db)
        for inst in instances:
            if not (inst["enabled"] and inst["url"] and inst["api_key"]):
                continue
            if inst["type"] == "sonarr":
                totals["sonarr"] += sync_sonarr(db, inst)
            else:
                totals["radarr"] += sync_radarr(db, inst)
    # Remove placeholders for items that no longer qualify (unreleased, filtered out)
    cleaned = _cleanup_stale_placeholders(sync_start)
    # Ensure nothing auto-downloads — Debridarr owns the download trigger
    for inst in instances:
        if not (inst["enabled"] and inst["url"] and inst["api_key"]):
            continue
        if inst["type"] == "sonarr":
            _set_sonarr_all_unmonitored(inst["key"])
        else:
            _set_radarr_all_unmonitored(inst["key"])
    log.info("Library sync complete – sonarr:%d  radarr:%d  cleaned:%d",
             totals["sonarr"], totals["radarr"], cleaned)
    # Background: symlink anything already in FUSE so it plays instantly
    import threading
    threading.Thread(target=_presymlink_from_fuse, daemon=True,
                     name="presymlink").start()
    return {"sonarr": totals["sonarr"], "radarr": totals["radarr"], "cleaned": cleaned}

# ── Stream resolution (called on Tautulli play event) ────────────────────────

import re as _re

def _norm(s: str) -> list:
    """Normalise a title/filename for fuzzy matching.

    Key rules:
      - Apostrophes/smart-quotes removed without splitting ("Grey's" → "greys")
      - Dot-separated acronyms joined into one token ("D.A.R.Y.L." → "daryl",
        "S.H.I.E.L.D." → "shield", "M*A*S*H" → "mash")
      - All other punctuation → space
      - Consecutive single-letter tokens merged (handles any remaining split acronyms)
    """
    s = s.lower()
    # Remove apostrophes without splitting
    s = _re.sub(r"[’‘'`]", "", s)
    # Join dot/star-separated acronyms before stripping punctuation
    # Handles 2-6 letter acronyms: D.A.R.Y.L. → daryl, S.H.I.E.L.D. → shield
    for n in (6, 5, 4, 3, 2):
        pattern = r"" + r"\.".join([r"([a-z])"] * n) + r"\."
        repl    = "".join([rf"\{i}" for i in range(1, n+1)])
        s = _re.sub(pattern, repl, s)
    # Handle star-separated acronyms like M*A*S*H
    s = _re.sub(r"([a-z])\*([a-z])\*([a-z])\*([a-z])", r"", s)
    s = _re.sub(r"([a-z])\*([a-z])\*([a-z])", r"", s)
    # Replace remaining non-alphanumeric with space
    s = _re.sub(r"[^a-z0-9\s]", " ", s)
    # Merge consecutive single-letter tokens (catches any remaining split acronyms)
    tokens = s.split()
    merged = []
    i = 0
    while i < len(tokens):
        if len(tokens[i]) == 1 and i + 1 < len(tokens) and len(tokens[i+1]) == 1:
            acc = tokens[i]
            while i + 1 < len(tokens) and len(tokens[i+1]) == 1:
                i += 1
                acc += tokens[i]
            merged.append(acc)
        else:
            merged.append(tokens[i])
        i += 1
    return [w for w in merged if w]

def _se_tag_str(season, episode) -> str | None:
    if season is not None and episode is not None:
        return f"S{int(season):02d}E{int(episode):02d}"
    return None


def _score_fuse_match(title: str, year, name: str) -> float:
    """Score how well a torrent/file name matches a title+year.

    Returns 0.0–1.0. Uses:
      - Word overlap ratio between normalised title and name
      - Year presence bonus
      - Length penalty for very short titles (avoids false positives)
    """
    title_words = _norm(title)
    name_words  = _norm(name)
    if not title_words or not name_words:
        return 0.0

    # Count how many title words appear in the name
    matched = sum(1 for w in title_words if w in name_words)
    ratio   = matched / len(title_words)

    # Year bonus
    if year and str(year) in name_words:
        ratio = min(1.0, ratio + 0.1)

    # Penalise if title is very short (1–2 words) to avoid false positives
    if len(title_words) <= 2 and matched < len(title_words):
        ratio *= 0.5

    return ratio


def _find_in_fuse(title: str, year, season, episode) -> tuple | None:
    """O(1) FUSE lookup using pre-built indexes.

    Episodes: title_word|S01E04 index → instant intersection
    Movies:   title_word index filtered by year → tiny candidate set
    """
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
    title_words = _norm(title)
    sig_words   = [w for w in title_words if len(w) > 2]
    se_tag      = f"S{int(season):02d}E{int(episode):02d}".upper() if (season and episode) else None
    year_str    = str(year) if year else ""
    THRESHOLD   = 0.6

    # ── Episodes: title+SE index gives exact intersection instantly ──────────
    if se_tag:
        candidate_set: dict = {}
        for w in sig_words:
            for entry in lookup_by_title_se(w, se_tag):
                candidate_set[entry] = candidate_set.get(entry, 0) + 1

        ranked = sorted(candidate_set.items(), key=lambda x: x[1], reverse=True)
        for (torrent_name, fname), word_hits in ranked:
            score = max(
                _score_fuse_match(title, year, torrent_name),
                _score_fuse_match(title, year, Path(fname).stem)
            )
            if score >= THRESHOLD:
                f = get_torrent_file(torrent_name, fname)
                if f:
                    log.info("_find_in_fuse ⚡ title+SE: score=%.2f hits=%d %s/%s",
                             score, word_hits, torrent_name, fname)
                    return torrent_name, fname, f

        # Fallback: pure S/E tag (any torrent with this ep)
        for torrent_name, fname in lookup_by_se_tag(se_tag):
            score = max(
                _score_fuse_match(title, year, torrent_name),
                _score_fuse_match(title, year, Path(fname).stem)
            )
            if score >= 0.3:
                f = get_torrent_file(torrent_name, fname)
                if f:
                    log.info("_find_in_fuse ⚡ SE fallback: score=%.2f %s/%s",
                             score, torrent_name, fname)
                    return torrent_name, fname, f

        log.warning("_find_in_fuse: no match for %r %s", title, se_tag)
        return None

    # ── Movies: title word index filtered by year ────────────────────────────
    candidate_set2: dict = {}
    for w in sig_words:
        for entry in lookup_by_title_word(w):
            torrent_name, fname = entry
            if not any(fname.lower().endswith(e) for e in video_exts):
                continue
            if year_str:
                t_words = _norm(torrent_name + " " + fname)
                if year_str not in t_words:
                    continue
            candidate_set2[entry] = candidate_set2.get(entry, 0) + 1

    ranked2 = sorted(candidate_set2.items(), key=lambda x: x[1], reverse=True)
    for (torrent_name, fname), _ in ranked2:
        score = max(
            _score_fuse_match(title, year, torrent_name),
            _score_fuse_match(title, year, Path(fname).stem)
        )
        if score >= THRESHOLD:
            f = get_torrent_file(torrent_name, fname)
            if f:
                log.info("_find_in_fuse ⚡ movie: score=%.2f %s/%s", score, torrent_name, fname)
                return torrent_name, fname, f

    # Movie fallback without year
    if year_str:
        candidate_set3: dict = {}
        for w in sig_words:
            for entry in lookup_by_title_word(w):
                torrent_name, fname = entry
                if any(fname.lower().endswith(e) for e in video_exts):
                    candidate_set3[entry] = candidate_set3.get(entry, 0) + 1
        for (torrent_name, fname), _ in sorted(candidate_set3.items(),
                                                key=lambda x: x[1], reverse=True):
            score = max(
                _score_fuse_match(title, year, torrent_name),
                _score_fuse_match(title, year, Path(fname).stem)
            ) * 0.8
            if score >= THRESHOLD:
                f = get_torrent_file(torrent_name, fname)
                if f:
                    log.info("_find_in_fuse ⚡ movie no-year: score=%.2f %s/%s",
                             score, torrent_name, fname)
                    return torrent_name, fname, f

    log.warning("_find_in_fuse: no match for movie %r year=%s", title, year)
    return None


# Cache series root paths to avoid repeated API calls
_series_root_cache: dict[tuple, str] = {}

def _get_series_root(inst: str, arr_id: int) -> str:
    ck = (inst, arr_id)
    if ck not in _series_root_cache:
        series = arr_get(inst, f"/series/{arr_id}") or {}
        _series_root_cache[ck] = series.get("path", "")
    return _series_root_cache[ck]

def _get_episode_file_path(inst: str, arr_id: int, season: int, episode: int) -> Path | None:
    """Ask Sonarr for the file path using the episodes endpoint with season/episode filter."""
    # Use season/episode query params to avoid fetching all episodes
    eps = arr_get(inst, "/episode", {"seriesId": arr_id, "seasonNumber": season})
    if not eps:
        return None
    for ep in eps:
        if ep.get("episodeNumber") != episode:
            continue
        if not ep.get("hasFile"):
            return None
        ef = ep.get("episodeFile")
        # Get file details
        if isinstance(ef, dict):
            rel, size = ef.get("relativePath", ""), ef.get("size", 0)
        elif isinstance(ef, int):
            ef_data = arr_get(inst, f"/episodefile/{ef}") or {}
            rel, size = ef_data.get("relativePath", ""), ef_data.get("size", 0)
        else:
            return None
        if not rel or not size:
            return None
        root = _get_series_root(inst, arr_id)
        if root:
            return Path(root) / rel
    return None


def _get_movie_file_path(inst: str, arr_id: int) -> Path | None:
    """Ask Radarr for the file path of a movie."""
    movie = arr_get(inst, f"/movie/{arr_id}")
    if not movie:
        return None
    mf = movie.get("movieFile") or {}
    if isinstance(mf, int):
        mf = arr_get(inst, f"/moviefile/{mf}") or {}
    rel, size = mf.get("relativePath", ""), mf.get("size", 0)
    root = movie.get("path", "")
    if root and rel and size:
        return Path(root) / rel
    return None


def sonarr_delete(path: str) -> bool:
    return arr_delete(primary_key("sonarr"), path)

def radarr_delete(path: str) -> bool:
    return arr_delete(primary_key("radarr"), path)


def _get_episode_file_id(inst: str, arr_id: int, season: int, episode: int) -> int | None:
    eps = arr_get(inst, "/episode", {"seriesId": arr_id}) or []
    for ep in eps:
        if ep.get("seasonNumber") == season and ep.get("episodeNumber") == episode:
            ef = ep.get("episodeFile")
            if isinstance(ef, dict): return ef.get("id")
            elif isinstance(ef, int): return ef
    return None


def _get_movie_file_id(inst: str, arr_id: int) -> int | None:
    movie = arr_get(inst, f"/movie/{arr_id}") or {}
    mf    = movie.get("movieFile") or {}
    if isinstance(mf, dict): return mf.get("id")
    elif isinstance(mf, int): return mf
    return None


def _trigger_arr_search(arr: str, arr_id: int, season: int | None, episode: int | None):
    """Delete the arr file record then trigger a fresh search.

    `arr` is the instance key (e.g. 'sonarr', 'radarr4k'). We delete the
    Sonarr/Radarr file record (not the placeholder symlink in /streams) so arr
    treats the item as missing and will actually search + download it.
    The placeholder in Plex (/streams/...) is untouched — Plex keeps showing it.
    """
    atype = instance_type(arr)
    if atype == "sonarr":
        eps     = arr_get(arr, "/episode", {"seriesId": arr_id}) or []
        matched = None
        for ep in eps:
            if ep.get("seasonNumber") == season and ep.get("episodeNumber") == episode:
                matched = ep
                break
        if not matched:
            log.warning("%s: no episode for seriesId=%s s%se%s", arr, arr_id, season, episode)
            return

        ep_id    = matched["id"]
        has_file = matched.get("hasFile", False)
        log.info("%s: episode %s hasFile=%s — deleting file record and searching",
                 arr, ep_id, has_file)

        # Delete the Sonarr file record so it will re-download
        # (This only removes the record in Sonarr, NOT the placeholder symlink in /streams)
        if has_file:
            ef    = matched.get("episodeFile")
            ef_id = ef.get("id") if isinstance(ef, dict) else (ef if isinstance(ef, int) else None)
            if not ef_id:
                # Fetch full episode to get file ID
                full  = arr_get(arr, f"/episode/{ep_id}") or {}
                ef    = full.get("episodeFile") or {}
                ef_id = ef.get("id") if isinstance(ef, dict) else None
            if ef_id:
                ok = arr_delete(arr, f"/episodefile/{ef_id}")
                log.info("%s: deleted episodeFile %s → %s", arr, ef_id, ok)

        # Clear cached series root so next poll gets fresh path
        _series_root_cache.pop((arr, arr_id), None)
        result = arr_post(arr, "/command", {"name": "EpisodeSearch", "episodeIds": [ep_id]})
        log.info("%s EpisodeSearch → %s", arr, result)

    elif atype == "radarr":
        movie = arr_get(arr, f"/movie/{arr_id}") or {}
        mf    = movie.get("movieFile") or {}
        mf_id = mf.get("id") if isinstance(mf, dict) else (mf if isinstance(mf, int) else None)
        if mf_id:
            ok = arr_delete(arr, f"/moviefile/{mf_id}")
            log.info("%s: deleted movieFile %s → %s", arr, mf_id, ok)

        result = arr_post(arr, "/command", {"name": "MoviesSearch", "movieIds": [arr_id]})
        log.info("%s MoviesSearch → %s", arr, result)


def _make_symlink(lib: dict, target: Path) -> Path | None:
    """Swap placeholder → symlink to target. Matches working version's logic exactly."""
    ph = Path(lib["placeholder"])
    media_type = lib["media_type"]
    title      = lib["title"]
    year       = lib["year"]
    season     = lib["season"]
    episode    = lib["episode"]

    folder = ph.parent
    try:
        folder.mkdir(parents=True, exist_ok=True)
        # Ensure placeholder exists (written with real MP4 bytes)
        if not ph.exists() and not ph.is_symlink():
            ph.write_bytes(_FAKE_MP4)
    except Exception as e:
        log.error("placeholder write: %s", e)

    try:
        # Replace placeholder with symlink AT THE SAME PATH
        # This keeps Plex's library entry valid — the filename never changes
        if ph.is_symlink() or ph.exists():
            ph.unlink(missing_ok=True)
        ph.symlink_to(str(target))

        if ph.is_symlink():
            log.info("🔗 Symlinked: %s → %s", ph.name, target)
            return ph
        else:
            # Symlink failed — restore placeholder
            if not ph.exists():
                ph.write_bytes(_FAKE_MP4)
            return None
    except Exception as e:
        log.error("symlink failed: %s", e)
        try:
            if not ph.exists() and not ph.is_symlink():
                ph.write_bytes(_FAKE_MP4)
        except Exception:
            pass
        return None


def _create_fuse_symlinks_for_arr(arr: str, arr_id: int, title: str, year,
                                   season: int | None, episode: int | None):
    """Create symlinks in arr's root download folder pointing to matching FUSE files.
    This lets Sonarr/Radarr auto-import the file from FUSE as if it were a real download.
    """

    video_exts  = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
    title_words = _norm(title)
    se_tag      = f"S{season:02d}E{episode:02d}".upper() if (season and episode) else None
    matches     = []

    for torrent_name in list_torrents():
        t_words = _norm(torrent_name)
        if not all(w in t_words for w in title_words):
            continue
        for fname in list_files(torrent_name):
            if not any(fname.lower().endswith(e) for e in video_exts):
                continue
            if se_tag and se_tag not in fname.upper():
                continue
            matches.append((torrent_name, fname))

    if not matches:
        log.debug("No FUSE matches to symlink for arr: %r", title)
        return

    atype = instance_type(arr)
    if atype == "sonarr":
        roots = arr_get(arr, "/rootfolder") or []
    elif atype == "radarr":
        roots = arr_get(arr, "/rootfolder") or []
    else:
        return

    root = roots[0].get("path", "") if roots else ""
    if not root:
        log.warning("No arr root folder found for %s", arr)
        return

    root_path = Path(root)
    for torrent_name, fname in matches:
        fuse_file   = (_dc_client.get_file_path(torrent_name, fname) if _dc_client else None)
        link_folder = root_path / torrent_name
        link_path   = link_folder / fname
        try:
            link_folder.mkdir(parents=True, exist_ok=True)
            if link_path.is_symlink() or link_path.exists():
                link_path.unlink(missing_ok=True)
            link_path.symlink_to(str(fuse_file))
            log.info("📁 arr import folder symlink: %s → %s", link_path, fuse_file)
        except Exception as e:
            log.warning("arr symlink failed %s: %s", link_path, e)


def activate_stream(library_id: str, session_key: str = "",
                    client_id: str = "", rating_key: str = "") -> dict:
    """Replace placeholder with symlink to the real file.

    Resolution order (matching working version):
      1. FUSE registry (instant — already in AllDebrid)
      2. Sonarr/Radarr file on disk (already downloaded)
      3. Trigger arr search + poll for new file (background download)
    """
    with get_conn() as db:
        lib = db.execute("SELECT * FROM library WHERE id=?", (library_id,)).fetchone()
        if not lib:
            return {"ok": False, "error": "Library item not found"}
        existing = db.execute(
            "SELECT * FROM streams WHERE library_id=? AND status='active'", (library_id,)
        ).fetchone()
        if existing:
            sym = Path(existing["symlink_path"])
            if sym.is_symlink() and sym.exists():
                db.execute("UPDATE streams SET last_seen_at=? WHERE id=?",
                           (iso(now_utc()), existing["id"]))
                return {"ok": True, "already_active": True, "stream_id": existing["id"],
                        "instant": True}
            else:
                log.info("activate_stream: broken symlink for %s — re-activating", library_id)
                db.execute("UPDATE streams SET status='expired' WHERE id=?", (existing["id"],))

    # Check if placeholder is already symlinked from pre-symlink pass
    with get_conn() as db:
        lib_check = db.execute("SELECT * FROM library WHERE id=?", (library_id,)).fetchone()
    if lib_check:
        ph = Path(lib_check["placeholder"])
        if ph.is_symlink() and ph.exists():
            # Already symlinked by presymlink — record stream and return instantly
            real      = Path(os.readlink(str(ph)))
            stream_id = str(uuid.uuid4())
            now       = iso(now_utc())
            expires   = iso(now_utc() + timedelta(days=SYMLINK_TTL_DAYS))
            with get_conn() as db:
                db.execute("""
                    INSERT OR IGNORE INTO streams
                    (id,library_id,arr,arr_id,media_type,title,year,season,episode,
                     source_path,symlink_path,created_at,expires_at,last_seen_at,status)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (stream_id, lib_check["id"], lib_check["arr"], lib_check["arr_id"],
                      lib_check["media_type"], lib_check["title"], lib_check["year"],
                      lib_check["season"], lib_check["episode"],
                      str(real), str(ph), now, expires, now, "active"))
            log.info("⚡ Instant play (pre-symlinked): %s", ph.name)
            return {"ok": True, "stream_id": stream_id, "symlink": str(ph),
                    "source": str(real), "instant": True}

    lib     = dict(lib)
    # Stash Plex session info so _immediate_symlink can interrupt the session
    lib["_session_key"] = session_key
    lib["_client_id"]   = client_id
    lib["_rating_key"]  = rating_key
    arr     = lib["arr"]
    arr_id  = lib["arr_id"]
    season  = lib["season"]
    episode = lib["episode"]
    title   = lib["title"]
    year    = lib["year"]
    ph      = Path(lib["placeholder"])

    real = None
    source = None

    # ── INSTANT PATH: check FUSE index first (sub-millisecond) ──────────────
    fuse_match = _find_in_fuse(title, year, season, episode)
    if fuse_match:
        torrent_name, fname, _ = fuse_match
        real   = (_dc_client.get_file_path(torrent_name, fname) if _dc_client else None)
        source = "fuse"
        log.info("⚡ Instant FUSE hit: %s / %s", torrent_name, fname)

    # ── SEARCH PATH: not in FUSE yet — trigger search then hammer the index ──
    if not real:
        log.info("Not in FUSE — triggering %s search for %s s%se%s", arr, title, season, episode)
        _trigger_arr_search(arr, arr_id, season, episode)

        # Poll aggressively: reload FUSE every 1s for up to 30s
        # As soon as AllDebrid receives the torrent it appears in the index → instant symlink
        deadline = time.time() + 30
        attempt  = 0
        while time.time() < deadline:
            attempt += 1
            # Incremental reload via Decypharr
            if _dc_client:
                n_new = _dc_client.reload_new()
                if n_new:
                    log.info("⚡ %d new torrent(s) on attempt %d", n_new, attempt)

            fuse_match = _find_in_fuse(title, year, season, episode)
            if fuse_match:
                torrent_name, fname, _ = fuse_match
                real   = (_dc_client.get_file_path(torrent_name, fname) if _dc_client else None)
                source = "fuse"
                log.info("✅ Found in FUSE on attempt %d (%.1fs): %s / %s",
                         attempt, 30 - (deadline - time.time()), torrent_name, fname)
                break

            time.sleep(0.5)

    if not real:
        return {"ok": False, "error": f"No file found for '{title}' after 30s"}

    # Symlink
    link = _make_symlink(lib, real)
    if not link:
        return {"ok": False, "error": f"Symlink creation failed for {real}"}

    stream_id = str(uuid.uuid4())
    now       = iso(now_utc())
    expires   = iso(now_utc() + timedelta(days=SYMLINK_TTL_DAYS))

    with get_conn() as db:
        db.execute("""
            INSERT INTO streams(id,library_id,arr,arr_id,media_type,title,year,season,episode,
                                source_path,symlink_path,created_at,expires_at,last_seen_at,status)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (stream_id, library_id, arr, arr_id, lib["media_type"],
              title, year, season, episode,
              str(real), str(link), now, expires, now, "active"))

    _notify_arr_rescan(arr, arr_id)
    _plex_refresh(lib["media_type"])
    log.info("✅ Stream activated [%s] via %s: %s → %s (expires %s)",
             lib["media_type"].upper(), source, link.name, real, expires)
    return {"ok": True, "stream_id": stream_id, "symlink": str(link),
            "source": str(real), "source_type": source, "expires_at": expires}


def _notify_arr_rescan(arr: str, arr_id: int):
    atype = instance_type(arr)
    if atype == "sonarr":
        arr_post(arr, "/command", {"name": "RescanSeries", "seriesId": arr_id})
    elif atype == "radarr":
        arr_post(arr, "/command", {"name": "RescanMovie", "movieId": arr_id})

def _notify_arr_unlink(arr: str, arr_id: int, season: int | None, episode: int | None):
    """Tell the arr the file is gone so it can unmonitor / mark missing."""
    atype = instance_type(arr)
    if atype == "sonarr":
        arr_post(arr, "/command", {"name": "RescanSeries", "seriesId": arr_id})
    elif atype == "radarr":
        arr_post(arr, "/command", {"name": "RescanMovie", "movieId": arr_id})

# ── Expiry cleanup ────────────────────────────────────────────────────────────
def cleanup_expired() -> list[str]:
    expired_ids = []
    now = now_utc()
    with get_conn() as db:
        rows = db.execute("SELECT * FROM streams WHERE status='active'").fetchall()
        for row in rows:
            try:
                if from_iso(row["expires_at"]) > now:
                    continue
            except Exception:
                continue
            sym        = Path(row["symlink_path"])
            library_id = row["library_id"] or ""
            revert_to_placeholder(sym, library_id=library_id)
            db.execute("UPDATE streams SET status='expired' WHERE id=?", (row["id"],))
            expired_ids.append(row["id"])
            log.info("Stream expired and reverted: %s (id=%s)", sym, row["id"])
            # Delete torrent from Decypharr/AllDebrid if not pinned
            source = row.get("source_path") or ""
            if source and not is_pinned_item(row["library_id"]):
                torrent_name = Path(source).parent.name
                if _dc_client and torrent_name:
                    _dc_client.delete_torrent(torrent_name)
            # Delete file from arr; re-trigger if pinned, set unmonitored otherwise
            _expire_arr_item(row["arr"], row["arr_id"], row["season"], row["episode"],
                             library_id=row["library_id"] or "")
    return expired_ids


def is_pinned_item(library_id: str) -> bool:
    """Check if a library item is in the pinned list."""
    if not library_id:
        return False
    with get_conn() as db:
        return bool(db.execute("SELECT 1 FROM pinned WHERE id=?", (library_id,)).fetchone())


def _expire_arr_item(arr: str, arr_id: int, season, episode, library_id: str = ""):
    """Delete the downloaded file from arr.
    If pinned, re-triggers search immediately. Otherwise sets unmonitored.
    """
    is_pinned = is_pinned_item(library_id)

    atype = instance_type(arr)
    if atype == "sonarr":
        eps = arr_get(arr, "/episode", {"seriesId": arr_id}) or []
        for ep in eps:
            if ep.get("seasonNumber") == season and ep.get("episodeNumber") == episode:
                ep_id = ep["id"]
                ef    = ep.get("episodeFile")
                ef_id = ef.get("id") if isinstance(ef, dict) else (ef if isinstance(ef, int) else None)
                if ef_id:
                    arr_delete(arr, f"/episodefile/{ef_id}")
                    log.info("Expired: deleted %s episodeFile %s", arr, ef_id)
                if is_pinned:
                    _trigger_arr_search(arr, arr_id, season, episode)
                    log.info("📌 Pinned: re-triggered search for s%se%s", season, episode)
                else:
                    arr_put(arr, "/episode/monitor", {"episodeIds": [ep_id], "monitored": False})
                    log.info("Expired: set %s episode %s unmonitored", arr, ep_id)
                return
    elif atype == "radarr":
        movie = arr_get(arr, f"/movie/{arr_id}") or {}
        mf    = movie.get("movieFile") or {}
        mf_id = mf.get("id") if isinstance(mf, dict) else (mf if isinstance(mf, int) else None)
        if mf_id:
            arr_delete(arr, f"/moviefile/{mf_id}")
            log.info("Expired: deleted %s movieFile %s", arr, mf_id)
        if is_pinned:
            _trigger_arr_search(arr, arr_id, None, None)
            log.info("📌 Pinned: re-triggered search for %s movie %s", arr, arr_id)
        else:
            arr_put(arr, f"/movie/{arr_id}", {**movie, "monitored": False})
            log.info("Expired: set %s movie %s unmonitored", arr, arr_id)

# ── FastAPI app ───────────────────────────────────────────────────────────────
# Module-level AllDebrid client — set by lifespan, used by /api/fuse/reload
_dc_client: DecypharrClient | None = None

# ── Proxy state DB ───────────────────────────────────────────────────────────
import json as _json

_PROXY_CACHE_FILE = Path("/data/proxy_cache.json")

class _ProxyDB:
    """Dict-backed proxy state store matching CacheDB interface used by proxy.py."""
    def __init__(self):
        self._data: dict = {}
        self._load()

    def _load(self):
        try:
            if _PROXY_CACHE_FILE.exists():
                self._data = _json.loads(_PROXY_CACHE_FILE.read_text())
                log.info("Proxy cache loaded: %d entries", len(self._data))
        except Exception as e:
            log.warning("Proxy cache load failed: %s", e)

    def _save(self):
        try:
            _PROXY_CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
            _PROXY_CACHE_FILE.write_text(_json.dumps(self._data))
        except Exception as e:
            log.warning("Proxy cache save failed: %s", e)

    def get(self, cache_key: str) -> dict | None:
        return self._data.get(cache_key)

    def set_resolving(self, cache_key: str):
        self._data[cache_key] = {"status": "resolving"}

    def set_cached(self, cache_key: str, stream_url: str, torrent_name: str,
                   magnet_link: str = ""):
        self._data[cache_key] = {
            "status":       "cached",
            "stream_url":   stream_url,
            "torrent_name": torrent_name,
            "magnet_link":  magnet_link,
            "cached_at":    iso(now_utc()),
        }
        self._save()

    def set_error(self, cache_key: str, reason: str = "error"):
        self._data[cache_key] = {"status": reason}

    def update_stream_url(self, cache_key: str, url: str):
        if cache_key in self._data:
            self._data[cache_key]["stream_url"] = url
            self._save()


_proxy_db = _ProxyDB()


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    # Load saved settings from DB into globals so they survive restarts
    global SONARR_URL, SONARR_API_KEY, RADARR_URL, RADARR_API_KEY
    global TAUTULLI_URL, TAUTULLI_API_KEY
    global DECYPHARR_URL, DECYPHARR_API_TOKEN, DECYPHARR_MOUNT
    with get_conn() as _sdb:
        def _gs(k, fallback=""): return get_setting(_sdb, k) or fallback
        SONARR_URL          = _gs("sonarr_url",          SONARR_URL)
        SONARR_API_KEY      = _gs("sonarr_api_key",      SONARR_API_KEY)
        RADARR_URL          = _gs("radarr_url",          RADARR_URL)
        RADARR_API_KEY      = _gs("radarr_api_key",      RADARR_API_KEY)
        TAUTULLI_URL        = _gs("tautulli_url",        TAUTULLI_URL)
        TAUTULLI_API_KEY    = _gs("tautulli_api_key",    TAUTULLI_API_KEY)
        DECYPHARR_URL       = _gs("decypharr_url",       DECYPHARR_URL)
        DECYPHARR_API_TOKEN = _gs("decypharr_api_token", DECYPHARR_API_TOKEN)
        DECYPHARR_MOUNT     = _gs("decypharr_mount",     DECYPHARR_MOUNT)
    # Load persisted FUSE index instantly — no API calls needed
    n = _load_index()
    if n:
        log.info("⚡ FUSE index pre-loaded from disk: %d torrent(s)", n)
        # Restore active stream symlinks now that index is available
        _restore_active_streams()
    # Heavy initial work runs in a background thread so the HTTP server starts
    # accepting requests immediately. Doing this synchronously here blocked the
    # event loop for the entire sync — making /health, /proxy and the Tautulli
    # webhook unresponsive (playback hung), and long syncs could trip the
    # container healthcheck into a restart loop (repeating sync bursts).
    import threading as _th_init
    def _startup_heavy():
        try:
            sweep_strm_placeholders()   # migrate off any old .strm/proxy placeholders
        except Exception as e:
            log.error("startup .strm sweep failed: %s", e, exc_info=True)
        try:
            cleanup_expired()
        except Exception as e:
            log.error("startup cleanup failed: %s", e, exc_info=True)
        try:
            full_library_sync()
        except Exception as e:
            log.error("startup library sync failed: %s", e, exc_info=True)
    _th_init.Thread(target=_startup_heavy, daemon=True, name="startup-init").start()

    # ── Decypharr client ──────────────────────────────────────────────────────
    global _dc_client
    _dc_client = None
    with get_conn() as _db:
        _dc_url   = get_setting(_db, "decypharr_url")   or DECYPHARR_URL
        _dc_token = get_setting(_db, "decypharr_api_token") or DECYPHARR_API_TOKEN

    if _dc_url:
        _dc_mount  = get_setting(_db, "decypharr_mount") or DECYPHARR_MOUNT
        _dc_client = DecypharrClient(_dc_url, _dc_token, _dc_mount)
        log.info("Decypharr client: %s", _dc_url)

        # Load persisted index first (instant — no API calls)
        n = _load_index()
        if n:
            log.info("⚡ Decypharr index pre-loaded: %d torrents", n)
            _restore_active_streams()

        # Full reload from Decypharr in background thread
        import threading as _th
        def _initial_load():
            n2 = _dc_client.reload_all()
            log.info("Decypharr: full load complete — %d torrents", n2)
            _restore_active_streams()
            _presymlink_from_fuse()
        _th.Thread(target=_initial_load, daemon=True, name="dc-init").start()

        # Background refresh every 30s — incremental, only new torrents
        # When new torrents appear, auto-match against library items
        async def _dc_refresh_loop():
            while True:
                await asyncio.sleep(30)
                try:
                    if _dc_client:
                        n3 = await asyncio.get_event_loop().run_in_executor(
                            None, _dc_client.reload_new)
                        if n3:
                            log.info("Decypharr: +%d new torrent(s) — running auto-match", n3)
                            # Run presymlink in thread so new torrents get matched immediately
                            await asyncio.get_event_loop().run_in_executor(
                                None, _presymlink_from_fuse)
                except Exception as _e:
                    log.warning("Decypharr refresh error: %s", _e)

        asyncio.create_task(_dc_refresh_loop())

        # Also run a full auto-match pass every 5 minutes to catch anything missed
        async def _auto_match_loop():
            while True:
                await asyncio.sleep(300)
                try:
                    await asyncio.get_event_loop().run_in_executor(
                        None, _presymlink_from_fuse)
                except Exception as _e:
                    log.warning("Auto-match error: %s", _e)

        asyncio.create_task(_auto_match_loop())
    else:
        log.info("Decypharr not configured — set DECYPHARR_URL")
    # ─────────────────────────────────────────────────────────────────────────

    yield

    # Shutdown — nothing to unmount

app = FastAPI(title="Debridarr", version="2026.06", lifespan=lifespan)

# ── Streaming proxy endpoint ──────────────────────────────────────────────────
# The .strm placeholders (proxy mode) point Plex at /proxy/{cache_key}. Without
# this route Plex gets nothing and shows "s1001 (Network)". proxy_stream serves
# a keepalive while resolving, then the real stream. Placeholders default to
# real .mp4 waiting videos now, so this mainly backstops any leftover .strm
# files and the on-play resolve path.
class _ProxyAllDebridShim:
    """Minimal stand-in so proxy.py's re-unlock fallbacks degrade gracefully
    when streaming a CDN URL that doesn't need re-unlocking."""
    async def unlock_magnet(self, *_args, **_kwargs):
        return None

_ad_shim = _ProxyAllDebridShim()

@app.api_route("/proxy/{cache_key}", methods=["GET", "HEAD"])
async def proxy_endpoint(cache_key: str, request: Request):
    return await proxy_stream(request, cache_key, _proxy_db, _ad_shim, app=app)

# ── Auth ──────────────────────────────────────────────────────────────────────
async def require_api_key(
    authorization: Optional[str] = Header(default=None),
    x_api_key: Optional[str]    = Header(default=None),
):
    if not API_KEY:
        return True
    token = (x_api_key or "").strip()
    if authorization and authorization.lower().startswith("bearer "):
        token = authorization.split(" ", 1)[1].strip()
    if token != API_KEY:
        raise HTTPException(401, "Invalid API key")
    return True

# ── Models ────────────────────────────────────────────────────────────────────
class SettingsPatch(BaseModel):
    settings: dict[str, str]

class ManualStreamCreate(BaseModel):
    arr:        str = "sonarr"   # instance key (e.g. "sonarr", "radarr4k")
    media_type: Literal["movie", "episode"] = "episode"
    title:      str
    year:       Optional[int] = None
    season:     Optional[int] = None
    episode:    Optional[int] = None
    source_path: str = Field(..., description="Real file path on FUSE mount")
    ttl_days:   Optional[int] = None

class TautulliWebhook(BaseModel):
    """
    Tautulli sends notification agent payloads.
    We accept either the native Tautulli JSON agent format or a simplified form.
    """
    event:          Optional[str] = None          # 'play', 'watched', etc.
    # Tautulli template fields (set these in the notification agent)
    media_type:     Optional[str] = None          # 'episode' or 'movie'
    file:           Optional[str] = None          # full file path Plex played
    grandparent_title: Optional[str] = None       # show title
    parent_media_index: Optional[int] = None      # season
    media_index:    Optional[int] = None          # episode
    title:          Optional[str] = None          # movie title or episode title
    year:           Optional[int] = None
    extra:          dict[str, Any] = {}

# ── Setup helpers ─────────────────────────────────────────────────────────────
def is_setup_complete() -> bool:
    """Returns True if at least one arr instance is fully configured."""
    if (SONARR_URL and SONARR_API_KEY) or (RADARR_URL and RADARR_API_KEY):
        return True
    for it in get_instances():
        if it["enabled"] and it["url"] and it["api_key"]:
            return True
    return False

# ── Routes ────────────────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
def home():
    return HTMLResponse(UI)

@app.get("/api/setup/status")
def setup_status():
    """Returns which steps are complete so the wizard can show progress."""
    with get_conn() as db:
        sonarr_url   = SONARR_URL   or get_setting(db, "sonarr_url")
        sonarr_key   = SONARR_API_KEY or get_setting(db, "sonarr_api_key")
        radarr_url   = RADARR_URL   or get_setting(db, "radarr_url")
        radarr_key   = RADARR_API_KEY or get_setting(db, "radarr_api_key")
        tautulli_url = TAUTULLI_URL or get_setting(db, "tautulli_url")
        ttl          = get_setting(db, "symlink_ttl_days", str(SYMLINK_TTL_DAYS))
        streams_path = get_setting(db, "streams_path", str(STREAMS_PATH))

    sonarr_connected = radarr_connected = False
    if sonarr_url and sonarr_key:
        sonarr_connected = sonarr_get("/system/status") is not None
    if radarr_url and radarr_key:
        radarr_connected = radarr_get("/system/status") is not None

    # AllDebrid check removed — using Decypharr instead
    ad_connected = False
    ad_username  = ""

    # DFS FUSE mount status
    dfs_mounted = False

    # Lightweight instance summary for the wizard (api keys masked)
    instances = [{
        "key": it["key"], "name": it["name"], "type": it["type"],
        "url": it["url"], "enabled": it["enabled"],
        "configured": bool(it["url"] and it["api_key"]),
    } for it in get_instances()]

    return {
        "setup_complete":   is_setup_complete(),
        "sonarr_url":       sonarr_url,
        "sonarr_connected": sonarr_connected,
        "radarr_url":       radarr_url,
        "radarr_connected": radarr_connected,
        "tautulli_url":     tautulli_url,
        "streams_path":     streams_path,
        "ttl_days":         ttl,
        "webhook_url":      "/webhook/tautulli",
        "sonarr_webhook_url": "/webhook/sonarr",
        "radarr_webhook_url": "/webhook/radarr",
        "instances":        instances,
        "ad_key_set":       False,
        "ad_connected":     False,
        "ad_username":      "",
        "dfs_mounted":      dfs_mounted,
        "dfs_mount_path":   "",
        "dc_connected":     bool(_dc_client),
        "decypharr_url":    get_setting(db, "decypharr_url")   or DECYPHARR_URL,
        "decypharr_mount":  get_setting(db, "decypharr_mount") or DECYPHARR_MOUNT,
    }


@app.post("/api/library/{arr_id}/reset-placeholders")
def reset_placeholders(arr_id: int, arr: str = "sonarr", season: int | None = None,
                       _: bool = Depends(require_api_key)):
    """Reset placeholders for all episodes of a series (or a specific season).
    Removes any active symlinks and restores the placeholder .mp4 file.
    Useful when a stream expires or files are deleted and Plex needs the placeholder back.
    """
    with get_conn() as db:
        if season is not None:
            rows = db.execute(
                "SELECT * FROM library WHERE arr=? AND arr_id=? AND season=?",
                (arr, arr_id, season)
            ).fetchall()
        else:
            rows = db.execute(
                "SELECT * FROM library WHERE arr=? AND arr_id=?",
                (arr, arr_id)
            ).fetchall()

    if not rows:
        raise HTTPException(404, f"No library entries found for {arr} id={arr_id}" +
                            (f" season={season}" if season is not None else ""))

    reset = 0
    skipped = 0
    for row in rows:
        ph = Path(row["placeholder"])
        try:
            # Remove symlink or existing file
            if ph.is_symlink() or ph.exists():
                ph.unlink(missing_ok=True)
            # Write fresh placeholder
            ph.parent.mkdir(parents=True, exist_ok=True)
            ph.write_bytes(_FAKE_MP4)
            # Mark any active streams as expired
            with get_conn() as db:
                db.execute(
                    "UPDATE streams SET status='reset' WHERE library_id=? AND status='active'",
                    (row["id"],)
                )
            reset += 1
        except Exception as e:
            log.warning("reset_placeholders: failed for %s: %s", ph, e)
            skipped += 1

    log.info("Reset placeholders: %d reset, %d skipped (arr=%s id=%s season=%s)",
             reset, skipped, arr, arr_id, season)
    return {"ok": True, "reset": reset, "skipped": skipped,
            "arr": arr, "arr_id": arr_id, "season": season}


@app.get("/api/debug/placeholders")
def debug_placeholders(_: bool = Depends(require_api_key)):
    """Scan the streams folder and compare against the library DB.
    Returns missing files, zero-byte files, and broken symlinks so
    you can diagnose why Plex cannot see placeholders.
    """
    with get_conn() as db:
        rows = db.execute("SELECT * FROM library ORDER BY arr,title,season,episode").fetchall()

    results = []
    for r in rows:
        ph   = Path(r["placeholder"])
        info = {
            "title":    r["title"],
            "arr":      r["arr"],
            "season":   r["season"],
            "episode":  r["episode"],
            "path":     str(ph),
            "exists":   ph.exists(),
            "is_symlink": ph.is_symlink(),
            "size":     ph.stat().st_size if ph.exists() else None,
            "problem":  None,
        }
        if ph.is_symlink() and not ph.exists():
            info["problem"] = "dead_symlink"
        elif not ph.exists():
            info["problem"] = "missing"
        elif ph.stat().st_size == 0:
            info["problem"] = "zero_bytes"
        results.append(info)

    problems = [r for r in results if r["problem"]]
    ok       = [r for r in results if not r["problem"]]
    return {
        "total":    len(results),
        "ok":       len(ok),
        "problems": problems,
        "streams_path": str(STREAMS_PATH),
    }

@app.post("/api/debug/placeholders/repair")
def repair_placeholders(_: bool = Depends(require_api_key)):
    """Re-write _FAKE_MP4 for every library entry whose placeholder is
    missing, zero-byte, or a dead symlink. Safe to call at any time."""
    with get_conn() as db:
        rows = db.execute("SELECT * FROM library").fetchall()
    fixed = skipped = 0
    for r in rows:
        ph = Path(r["placeholder"])
        if ph.is_symlink() and not ph.exists():
            ph.unlink(missing_ok=True)
        if not ph.exists() or ph.stat().st_size == 0:
            try:
                ph.parent.mkdir(parents=True, exist_ok=True)
                ph.write_bytes(_FAKE_MP4)
                fixed += 1
            except Exception as e:
                log.warning("repair placeholder %s: %s", ph, e)
        else:
            skipped += 1
    return {"fixed": fixed, "skipped": skipped}

# ── Spot check ───────────────────────────────────────────────────────────────

_spot_check_running = False

def _run_spot_check(limit: int = 0):
    """For each library item that is a plain placeholder (not yet a symlink):
      1. Trigger arr search
      2. Poll arr for import up to 3 minutes
      3. If found → symlink (activate_stream handles this via /webhook/arr)
      4. If not found → mark not_found in DB, delete placeholder
    Runs serially to avoid hammering arr with parallel searches.
    """
    global _spot_check_running
    if _spot_check_running:
        log.warning("Spot check already running — skipping")
        return {"skipped": True, "reason": "already running"}

    _spot_check_running = True
    try:
        with get_conn() as db:
            rows = db.execute(
                "SELECT * FROM library ORDER BY arr, title, season, episode"
            ).fetchall()

        if limit:
            rows = rows[:limit]

        checked = skipped = found = not_found_count = 0

        # Build list of items to check (skip symlinks, active streams, not_found)
        to_check = []
        with get_conn() as db:
            nf_ids = {r["id"] for r in db.execute("SELECT id FROM not_found").fetchall()}
            active_ids = {r["library_id"] for r in
                          db.execute("SELECT library_id FROM streams WHERE status='active'").fetchall()}

        for row in rows:
            lib_id = row["id"]
            ph     = Path(row["placeholder"])
            if ph.is_symlink() or lib_id in nf_ids or lib_id in active_ids:
                skipped += 1
                continue
            to_check.append(row)

        log.info("Spot check: %d items to check, %d skipped", len(to_check), skipped)

        # Phase 1: fire searches in batches of 5 with 2s between each
        # to avoid overwhelming Sonarr/Radarr API
        BATCH_SIZE  = 5
        BATCH_DELAY = 2  # seconds between batches

        checked = len(to_check)
        for i in range(0, len(to_check), BATCH_SIZE):
            batch = to_check[i:i + BATCH_SIZE]
            for row in batch:
                try:
                    _trigger_arr_search(row["arr"], row["arr_id"], row["season"], row["episode"])
                except Exception as e:
                    log.warning("Spot check search error for %s: %s", row["title"], e)
            log.info("Spot check: fired batch %d/%d",
                     min(i + BATCH_SIZE, len(to_check)), len(to_check))
            if i + BATCH_SIZE < len(to_check):
                time.sleep(BATCH_DELAY)

        log.info("Spot check: all %d searches fired — waiting 30s for imports", checked)

        # Phase 2: wait 30 seconds for arr to download + import
        time.sleep(30)

        # Phase 3: check each item once — arr webhook may have already symlinked them
        for row in to_check:
            lib_id  = row["id"]
            ph      = Path(row["placeholder"])
            arr     = row["arr"]
            arr_id  = row["arr_id"]
            season  = row["season"]
            episode = row["episode"]
            title   = row["title"]

            # Check if webhook already symlinked it
            if ph.is_symlink():
                found += 1
                continue

            # Check arr directly
            if instance_type(arr) == "sonarr":
                file_found = _get_episode_file_path(arr, arr_id, season, episode)
            else:
                file_found = _get_movie_file_path(arr, arr_id)

            if file_found:
                _immediate_symlink(lib_id, file_found)
                log.info("🔍 Spot check symlinked: %s → %s", title, file_found.name)
                found += 1
            else:
                # Not found — mark and remove placeholder
                with get_conn() as db:
                    db.execute("""
                        INSERT OR REPLACE INTO not_found
                        (id, arr, arr_id, media_type, title, season, episode, checked_at, reason)
                        VALUES (?,?,?,?,?,?,?,?,?)
                    """, (lib_id, arr, arr_id, row["media_type"], title,
                          season, episode, iso(now_utc()),
                          "No release found after search + 30s poll"))
                    db.execute("DELETE FROM streams WHERE library_id=?", (lib_id,))
                    db.execute("DELETE FROM library WHERE id=?", (lib_id,))
                try:
                    if ph.exists() or ph.is_symlink():
                        ph.unlink(missing_ok=True)
                except Exception as e:
                    log.warning("Spot check: could not delete placeholder %s: %s", ph, e)
                not_found_count += 1

        log.info("Spot check complete: checked=%d found=%d not_found=%d skipped=%d",
                 checked, found, not_found_count, skipped)
        return {
            "ok": True, "checked": checked, "found": found,
            "not_found": not_found_count, "skipped": skipped
        }
    finally:
        _spot_check_running = False


@app.post("/api/spot-check")
def spot_check(background_tasks: BackgroundTasks, limit: int = 0,
               _: bool = Depends(require_api_key)):
    """Run spot check in background. limit=0 means check all items."""
    if _spot_check_running:
        raise HTTPException(409, "Spot check already running")
    background_tasks.add_task(_run_spot_check, limit)
    return {"ok": True, "message": "Spot check started in background"}


@app.get("/api/spot-check/status")
def spot_check_status(_: bool = Depends(require_api_key)):
    return {"running": _spot_check_running}


@app.get("/api/not-found")
def list_not_found(_: bool = Depends(require_api_key)):
    with get_conn() as db:
        rows = db.execute(
            "SELECT * FROM not_found ORDER BY arr, title, season, episode"
        ).fetchall()
    return {"not_found": [dict(r) for r in rows]}


@app.delete("/api/not-found/{item_id}")
def clear_not_found(item_id: str, _: bool = Depends(require_api_key)):
    """Remove an item from the not_found list so it will be synced again."""
    with get_conn() as db:
        db.execute("DELETE FROM not_found WHERE id=?", (item_id,))
    return {"ok": True}


@app.delete("/api/not-found")
def clear_all_not_found(_: bool = Depends(require_api_key)):
    """Clear entire not_found list — all items will be re-synced."""
    with get_conn() as db:
        db.execute("DELETE FROM not_found")
    return {"ok": True}


# ── Pinned list ────────────────────────────────────────────────────────────────

@app.get("/api/pinned")
def list_pinned(_: bool = Depends(require_api_key)):
    with get_conn() as db:
        rows = db.execute("SELECT * FROM pinned ORDER BY title, season, episode").fetchall()
    return {"pinned": [dict(r) for r in rows]}


@app.post("/api/pinned/{library_id}")
def pin_item(library_id: str, note: str = "", _: bool = Depends(require_api_key)):
    """Pin a library item — auto re-adds to AllDebrid every 30 days on expiry."""
    with get_conn() as db:
        lib = db.execute("SELECT * FROM library WHERE id=?", (library_id,)).fetchone()
        if not lib:
            raise HTTPException(404, "Library item not found")
        db.execute("""
            INSERT OR REPLACE INTO pinned
            (id, arr, arr_id, media_type, title, season, episode, added_at, note)
            VALUES (?,?,?,?,?,?,?,?,?)
        """, (library_id, lib["arr"], lib["arr_id"], lib["media_type"],
              lib["title"], lib["season"], lib["episode"], iso(now_utc()), note))
    log.info("📌 Pinned: %s s%se%s", lib["title"], lib["season"], lib["episode"])
    return {"ok": True}


@app.delete("/api/pinned/{library_id}")
def unpin_item(library_id: str, _: bool = Depends(require_api_key)):
    with get_conn() as db:
        db.execute("DELETE FROM pinned WHERE id=?", (library_id,))
    return {"ok": True}


@app.delete("/api/pinned")
def unpin_all(_: bool = Depends(require_api_key)):
    with get_conn() as db:
        db.execute("DELETE FROM pinned")
    return {"ok": True}


# ── Decypharr API endpoints ───────────────────────────────────────────────────

@app.get("/api/decypharr/status")
def decypharr_status(_: bool = Depends(require_api_key)):
    with get_conn() as db:
        url   = get_setting(db, "decypharr_url")   or DECYPHARR_URL
        mount = get_setting(db, "decypharr_mount")  or DECYPHARR_MOUNT
    connected = False
    error = ""
    try:
        if _dc_client:
            torrents = _dc_client.list_all_torrents()
            connected = True
            count = len(list_torrents())
        else:
            count = len(list_torrents())
    except Exception as e:
        error = str(e)
        count = len(list_torrents())
    return {"url": url, "mount": mount, "connected": connected or bool(_dc_client),
            "torrents": count, "error": error}


@app.get("/api/decypharr/test")
def decypharr_test(_: bool = Depends(require_api_key)):
    if not _dc_client:
        return {"ok": False, "error": "Decypharr not configured — set DECYPHARR_URL"}
    try:
        torrents = _dc_client.list_all_torrents()
        return {"ok": True, "torrents": len(torrents)}
    except Exception as e:
        return {"ok": False, "error": str(e)}


@app.post("/api/decypharr/reload")
def decypharr_reload(_: bool = Depends(require_api_key)):
    if not _dc_client:
        raise HTTPException(503, "Decypharr not configured")
    count = _dc_client.reload_all()
    return {"ok": True, "count": count}


@app.post("/api/decypharr/reload/new")
def decypharr_reload_new(_: bool = Depends(require_api_key)):
    if not _dc_client:
        raise HTTPException(503, "Decypharr not configured")
    count = _dc_client.reload_new()
    return {"ok": True, "count": count}


# ── Rebuild placeholders ───────────────────────────────────────────────────────

@app.post("/api/library/rebuild-placeholders")
def rebuild_placeholders(arr: str = "all", _: bool = Depends(require_api_key)):
    """Re-write the .mp4 waiting-video placeholder for every library item and
    fix up any rows still pointing at the old .strm/proxy or namespaced paths.
    Use after upgrading, or after changing STRM_ROOT / instance layout.
    """
    with get_conn() as db:
        if arr == "all":
            rows = db.execute("SELECT * FROM library").fetchall()
        else:
            rows = db.execute("SELECT * FROM library WHERE arr=?", (arr,)).fetchall()

    count = 0
    for row in rows:
        old = Path(row["placeholder"])
        # Skip active symlinks — don't break live streams
        if old.is_symlink() and old.exists():
            continue
        # Recompute the canonical placeholder path for this item (flat for the
        # default instances, namespaced for extras, always .mp4).
        new = placeholder_path(row["arr"], row["media_type"], row["title"],
                               row["year"], row["season"], row["episode"])
        try:
            # Remove the stale placeholder (and any sibling .strm) at the old path
            if str(old) != str(new):
                if old.exists() or old.is_symlink():
                    old.unlink(missing_ok=True)
                _clear_stale_strm(old)
            ensure_placeholder(new)
            if str(new) != row["placeholder"]:
                with get_conn() as db2:
                    db2.execute("UPDATE library SET placeholder=? WHERE id=?",
                                (str(new), row["id"]))
            count += 1
        except Exception as e:
            log.warning("rebuild_placeholders: %s — %s", new, e)

    log.info("Rebuilt %d placeholder(s) for arr=%s", count, arr)
    return {"ok": True, "count": count}


@app.get("/api/library")
def list_library(arr: str = "all", _: bool = Depends(require_api_key)):
    with get_conn() as db:
        if arr == "all":
            rows = db.execute("SELECT * FROM library ORDER BY arr, title, season, episode").fetchall()
        else:
            rows = db.execute("SELECT * FROM library WHERE arr=? ORDER BY title,season,episode", (arr,)).fetchall()
        return {"library": [dict(r) for r in rows]}


@app.post("/api/library/sync")
def trigger_sync(background_tasks: BackgroundTasks, _: bool = Depends(require_api_key)):
    background_tasks.add_task(full_library_sync)
    return {"ok": True, "message": "Library sync started in background"}

# ── Streams ───────────────────────────────────────────────────────────────────
@app.get("/api/streams")
def list_streams(status: str = "active", _: bool = Depends(require_api_key)):
    cleanup_expired()
    with get_conn() as db:
        if status == "all":
            rows = db.execute("SELECT * FROM streams ORDER BY created_at DESC").fetchall()
        else:
            rows = db.execute("SELECT * FROM streams WHERE status=? ORDER BY created_at DESC", (status,)).fetchall()
        return {"streams": [dict(r) for r in rows]}


@app.post("/api/library/{library_id}/activate")
def activate(library_id: str, _: bool = Depends(require_api_key)):
    result = activate_stream(library_id)
    if not result.get("ok"):
        raise HTTPException(400, result.get("error", "Activation failed"))
    return result

# ── Tautulli webhook ──────────────────────────────────────────────────────────
@app.post("/webhook/tautulli")
async def tautulli_webhook(request: Request, background_tasks: BackgroundTasks):
    """Tautulli -> Notification Agents -> Webhook, Trigger: Playback Start.

    Returns immediately and resolves in the background: hash-matches the grabbed
    release in Decypharr (sending the Sonarr/Radarr search command if the item
    isn't downloaded yet) and symlinks the real file in place of the .mp4
    placeholder. Press Play again once it resolves to start the real file.
    """
    try:
        body = await request.json()
    except Exception:
        try:
            body = dict(await request.form())
        except Exception:
            raise HTTPException(400, "Invalid payload")

    log.info("Tautulli webhook: %s", body)

    event      = (body.get("event") or "").strip().lower()
    media_type = (body.get("media_type") or "").strip().lower()
    file_path  = (body.get("file") or "").strip()

    if event not in ("play", "playback.start", "playback_start", ""):
        return {"ok": True, "skipped": True, "reason": f"event={event}"}

    title   = (body.get("grandparent_title") or body.get("title") or "").strip()
    season  = body.get("parent_media_index")
    episode = body.get("media_index")
    year    = body.get("year")
    try:
        season  = int(season)  if season  not in (None, "") else None
        episode = int(episode) if episode not in (None, "") else None
        year    = int(year)    if year    not in (None, "") else None
    except (TypeError, ValueError):
        season = episode = year = None

    with get_conn() as db:
        lib_row = None
        if file_path:
            lib_row = db.execute("SELECT * FROM library WHERE placeholder=?",
                                 (file_path,)).fetchone()
        # Match by filename when the full path differs (Plex/Tautulli reports the
        # host path, which may not equal Debridarr's container path). The
        # placeholder basename (e.g. "Show - S01E01.mp4") is unique enough.
        if not lib_row and file_path:
            base = os.path.basename(file_path)
            if base:
                lib_row = db.execute("SELECT * FROM library WHERE placeholder LIKE ?",
                                     ("%/" + base,)).fetchone()
        if not lib_row and media_type == "episode" and title \
                and season is not None and episode is not None:
            lib_row = db.execute(
                "SELECT * FROM library WHERE media_type='episode' AND title=? AND season=? AND episode=?",
                (title, season, episode)).fetchone()
        if not lib_row and media_type == "movie":
            mt = (body.get("title") or title).strip()
            lib_row = db.execute("SELECT * FROM library WHERE media_type='movie' AND title=?",
                                 (mt,)).fetchone()
            if not lib_row and year:
                lib_row = db.execute(
                    "SELECT * FROM library WHERE media_type='movie' AND title=? AND year=?",
                    (mt, year)).fetchone()
        if not lib_row and title:
            if media_type == "episode" and season is not None and episode is not None:
                cands = db.execute(
                    "SELECT * FROM library WHERE media_type='episode' AND season=? AND episode=?",
                    (season, episode)).fetchall()
            elif media_type == "movie":
                cands = db.execute("SELECT * FROM library WHERE media_type='movie'").fetchall()
            else:
                cands = []
            tn = "".join(c.lower() for c in (body.get("title") or title) if c.isalnum())
            for c in cands:
                cn = "".join(ch.lower() for ch in c["title"] if ch.isalnum())
                if cn == tn or (media_type == "episode" and (tn in cn or cn in tn)):
                    lib_row = c
                    log.info("Tautulli webhook: fuzzy match -> %r [%s]", c["title"], c["arr"])
                    break

    if not lib_row:
        log.warning("Tautulli webhook: no library match - media=%s title=%r s%se%s file=%s",
                    media_type, title, season, episode, file_path)
        return {"ok": False, "error": f"No library match for {title!r}"}

    lib_id = lib_row["id"]
    ph     = Path(lib_row["placeholder"])

    try:
        if ph.is_symlink() and ph.exists():
            log.info("Tautulli webhook: already linked for %r", lib_row["title"])
            return {"ok": True, "status": "linked", "library_id": lib_id}
    except OSError:
        pass

    if lib_id in _proxy_db._data:
        _proxy_db._data.pop(lib_id, None)
        _proxy_db._save()

    background_tasks.add_task(_resolve_for_proxy, lib_id)
    log.info("\u25b6\ufe0f  Tautulli play -> queued resolve for %r lib_id=%s (media=%s)",
             lib_row["title"], lib_id, media_type)
    return {"ok": True, "status": "resolving", "library_id": lib_id}

# ── Sonarr / Radarr passthrough status ───────────────────────────────────────
@app.get("/api/arr/sonarr/status")
def sonarr_status(_: bool = Depends(require_api_key)):
    data = sonarr_get("/system/status")
    return {"connected": data is not None, "status": data}


@app.get("/api/streams")
def list_streams(status: str = "active", _: bool = Depends(require_api_key)):
    cleanup_expired()
    with get_conn() as db:
        if status == "all":
            rows = db.execute("SELECT * FROM streams ORDER BY created_at DESC").fetchall()
        else:
            rows = db.execute("SELECT * FROM streams WHERE status=? ORDER BY created_at DESC", (status,)).fetchall()
        return {"streams": [dict(r) for r in rows]}


@app.post("/api/streams/cleanup")
def run_cleanup(_: bool = Depends(require_api_key)):
    return {"ok": True, "expired_removed": cleanup_expired()}

# ── Library-driven activation ─────────────────────────────────────────────────
@app.post("/api/library/{library_id}/activate")
def activate(library_id: str, _: bool = Depends(require_api_key)):
    result = activate_stream(library_id)
    if not result.get("ok"):
        raise HTTPException(400, result.get("error", "Activation failed"))
    return result


# ── Sonarr / Radarr passthrough status ───────────────────────────────────────
@app.get("/api/arr/sonarr/status")
def sonarr_status(_: bool = Depends(require_api_key)):
    data = sonarr_get("/system/status")
    return {"connected": data is not None, "status": data}


@app.post("/api/streams/manual")
def create_manual_stream(item: ManualStreamCreate, _: bool = Depends(require_api_key)):
    """Manually activate a stream without a Tautulli event."""
    if instance_type(item.arr) is None:
        raise HTTPException(400, f"Unknown instance {item.arr!r}")
    source = Path(item.source_path)
    if not source.exists():
        raise HTTPException(400, f"Source path does not exist: {source}")

    ph = placeholder_path(item.arr, item.media_type, item.title, item.year, item.season, item.episode)
    ensure_placeholder(ph)

    try:
        if ph.is_symlink() or (ph.exists() and not ph.is_symlink()):
            ph.unlink()
        os.symlink(str(source), str(ph))
    except OSError as exc:
        raise HTTPException(500, f"Symlink failed: {exc}")

    ttl = item.ttl_days or SYMLINK_TTL_DAYS
    stream_id = str(uuid.uuid4())
    now = iso(now_utc())
    expires = iso(now_utc() + timedelta(days=ttl))

    with get_conn() as db:
        db.execute("""
            INSERT INTO streams(id,library_id,arr,arr_id,media_type,title,year,season,episode,
                                source_path,symlink_path,created_at,expires_at,last_seen_at,status)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (stream_id, None, item.arr, None, item.media_type,
              item.title, item.year, item.season, item.episode,
              str(source), str(ph), now, expires, now, "active"))

    return {"ok": True, "stream_id": stream_id, "symlink": str(ph), "expires_at": expires}


@app.delete("/api/streams/{stream_id}")
def delete_stream(stream_id: str, _: bool = Depends(require_api_key)):
    with get_conn() as db:
        row = db.execute("SELECT * FROM streams WHERE id=?", (stream_id,)).fetchone()
        if not row:
            raise HTTPException(404, "Stream not found")
        revert_to_placeholder(Path(row["symlink_path"]))
        db.execute("UPDATE streams SET status='removed' WHERE id=?", (stream_id,))
        _notify_arr_unlink(row["arr"], row["arr_id"], row["season"], row["episode"])
    return {"ok": True, "removed": stream_id}


@app.get("/api/decypharr/debug")
def decypharr_debug(_: bool = Depends(require_api_key)):
    """Raw responses from all Decypharr endpoints — for debugging."""
    if not _dc_client:
        return {"error": "Decypharr not configured"}
    import httpx as _hx
    results = {}
    for path in ("/api/v2/torrents/info", "/api/torrents", "/api/browse/__all__"):
        try:
            r = _hx.get(f"{_dc_client.base_url}{path}",
                        headers=_dc_client._hdrs(), timeout=10)
            data = r.json()
            t = type(data).__name__
            if isinstance(data, list):
                results[path] = {"status": r.status_code, "type": t,
                                 "count": len(data),
                                 "first": data[0] if data else None}
            elif isinstance(data, dict):
                results[path] = {"status": r.status_code, "type": t,
                                 "keys": list(data.keys()),
                                 "sample": str(data)[:300]}
            else:
                results[path] = {"status": r.status_code, "type": t, "raw": str(data)[:200]}
        except Exception as e:
            results[path] = {"error": str(e)}
    return results


@app.get("/health")
def health():
    return {
        "ok":               True,
        "version":          app.version,
        "streams_path":     str(STREAMS_PATH),
        "sonarr_connected": bool(SONARR_URL and SONARR_API_KEY),
        "radarr_connected": bool(RADARR_URL and RADARR_API_KEY),
    }

@app.get("/api/settings")
def get_settings(_: bool = Depends(require_api_key)):
    with get_conn() as db:
        return {"settings": {r["key"]: r["value"] for r in db.execute("SELECT key,value FROM settings ORDER BY key")}}

@app.patch("/api/settings")
def patch_settings(patch: SettingsPatch, _: bool = Depends(require_api_key)):
    with get_conn() as db:
        for k, v in patch.settings.items():
            db.execute(
                "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (k, str(v))
            )
    # Update in-process globals so they take effect without a restart
    global SONARR_URL, SONARR_API_KEY, RADARR_URL, RADARR_API_KEY
    global TAUTULLI_URL, TAUTULLI_API_KEY
    global PLEX_URL, PLEX_TOKEN
    global DECYPHARR_URL, DECYPHARR_API_TOKEN, DECYPHARR_MOUNT
    if "sonarr_url"          in patch.settings: SONARR_URL          = patch.settings["sonarr_url"].rstrip("/")
    if "sonarr_api_key"      in patch.settings: SONARR_API_KEY      = patch.settings["sonarr_api_key"]
    if "radarr_url"          in patch.settings: RADARR_URL          = patch.settings["radarr_url"].rstrip("/")
    if "radarr_api_key"      in patch.settings: RADARR_API_KEY      = patch.settings["radarr_api_key"]
    if "tautulli_url"        in patch.settings: TAUTULLI_URL        = patch.settings["tautulli_url"].rstrip("/")
    if "tautulli_api_key"    in patch.settings: TAUTULLI_API_KEY    = patch.settings["tautulli_api_key"]
    if "plex_url"            in patch.settings: PLEX_URL            = patch.settings["plex_url"].rstrip("/")
    if "plex_token"          in patch.settings: PLEX_TOKEN          = patch.settings["plex_token"]
    if "decypharr_url"       in patch.settings: DECYPHARR_URL       = patch.settings["decypharr_url"].rstrip("/")
    if "decypharr_api_token" in patch.settings: DECYPHARR_API_TOKEN = patch.settings["decypharr_api_token"]
    if "decypharr_mount"     in patch.settings: DECYPHARR_MOUNT     = patch.settings["decypharr_mount"]

    # Mirror legacy single-instance settings into the "sonarr"/"radarr" registry
    # entries so the multi-instance view and the old wizard steps stay consistent.
    _legacy_map = {
        "sonarr": ("sonarr_url", "sonarr_api_key"),
        "radarr": ("radarr_url", "radarr_api_key"),
    }
    if any(k in patch.settings for pair in _legacy_map.values() for k in pair):
        insts = get_instances()
        changed = False
        for key, (uk, kk) in _legacy_map.items():
            if uk in patch.settings or kk in patch.settings:
                found = next((i for i in insts if i["key"] == key), None)
                if found:
                    if uk in patch.settings:
                        found["url"] = patch.settings[uk].rstrip("/")
                    if kk in patch.settings:
                        found["api_key"] = patch.settings[kk]
                    changed = True
        if changed:
            save_instances(insts)
    return get_settings(True)


# ── ARR instance management ───────────────────────────────────────────────────
class InstanceModel(BaseModel):
    key:     Optional[str] = None    # omit on create → derived from name
    name:    str
    type:    Literal["sonarr", "radarr"]
    url:     str = ""
    api_key: str = ""
    enabled: bool = True

@app.get("/api/instances")
def list_instances(_: bool = Depends(require_api_key)):
    out = []
    for it in get_instances():
        connected = bool(it["url"] and it["api_key"]) and \
            (arr_get(it["key"], "/system/status") is not None)
        out.append({**it, "connected": connected})
    return {"instances": out}

@app.post("/api/instances")
def create_instance(item: InstanceModel, _: bool = Depends(require_api_key)):
    insts = get_instances()
    key = (item.key or slugify_key(item.name)).strip()
    # Ensure uniqueness — append a numeric suffix if taken
    existing = {i["key"] for i in insts}
    if key in existing:
        base, n = key, 2
        while f"{base}{n}" in existing:
            n += 1
        key = f"{base}{n}"
    insts.append({
        "key": key, "name": item.name.strip() or key, "type": item.type,
        "url": item.url.rstrip("/"), "api_key": item.api_key, "enabled": item.enabled,
    })
    save_instances(insts)
    return {"ok": True, "key": key, "instances": get_instances()}

@app.patch("/api/instances/{key}")
def update_instance(key: str, item: InstanceModel, _: bool = Depends(require_api_key)):
    insts = get_instances()
    found = next((i for i in insts if i["key"] == key), None)
    if not found:
        raise HTTPException(404, f"Unknown instance {key!r}")
    # key is immutable (it anchors library rows + on-disk paths); name is free-form
    found["name"]    = item.name.strip() or found["name"]
    found["type"]    = item.type
    found["url"]     = item.url.rstrip("/")
    found["api_key"] = item.api_key
    found["enabled"] = item.enabled
    save_instances(insts)
    # Mirror into legacy settings for the default pair
    if key in ("sonarr", "radarr"):
        with get_conn() as db:
            db.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                       (f"{key}_url", found["url"]))
            db.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                       (f"{key}_api_key", found["api_key"]))
    return {"ok": True, "instances": get_instances()}

@app.delete("/api/instances/{key}")
def delete_instance(key: str, purge: bool = False, _: bool = Depends(require_api_key)):
    insts = get_instances()
    if not any(i["key"] == key for i in insts):
        raise HTTPException(404, f"Unknown instance {key!r}")
    insts = [i for i in insts if i["key"] != key]
    save_instances(insts)
    removed = 0
    if purge:
        # Remove this instance's library rows, streams, and on-disk tree
        with get_conn() as db:
            for r in db.execute("SELECT placeholder FROM library WHERE arr=?", (key,)).fetchall():
                try:
                    p = Path(r["placeholder"])
                    if p.is_symlink() or p.exists():
                        p.unlink(missing_ok=True)
                except Exception:
                    pass
            cur = db.execute("DELETE FROM library WHERE arr=?", (key,))
            removed = cur.rowcount or 0
            db.execute("DELETE FROM streams WHERE arr=?", (key,))
            db.execute("DELETE FROM not_found WHERE arr=?", (key,))
        try:
            tree = Path(STRM_ROOT) / key
            if tree.exists():
                shutil.rmtree(tree, ignore_errors=True)
        except Exception:
            pass
    return {"ok": True, "purged": purge, "library_removed": removed, "instances": get_instances()}

@app.get("/api/instances/{key}/status")
def instance_status(key: str, _: bool = Depends(require_api_key)):
    if instance_type(key) is None:
        raise HTTPException(404, f"Unknown instance {key!r}")
    data = arr_get(key, "/system/status")
    return {"connected": data is not None, "status": data}

# ── FUSE ──────────────────────────────────────────────────────────────────────
@app.get("/api/fuse")
def fuse_status(_: bool = Depends(require_api_key)):
    dfs_mounted  = False
    torrent_list = list_torrents()
    return {
        "dfs_mount":     "",
        "dfs_mounted":   dfs_mounted,
        "torrent_count": len(torrent_list),
        "torrents":      [{"name": t, "files": list_files(t)} for t in torrent_list],
    }



def _plex_refresh(media_type: str = ""):
    """Ask Plex to rescan the relevant library so a freshly swapped symlink is
    picked up without a manual Retry — this is placeholdarr's key mechanism.

    We refresh by section *type* (show/movie) rather than by path, so it works
    even when Plex's library path differs from Debridarr's container path
    (the usual host-vs-container mismatch).
    """
    with get_conn() as db:
        plex_url   = PLEX_URL   or get_setting(db, "plex_url")
        plex_token = PLEX_TOKEN or get_setting(db, "plex_token")
    if not plex_url or not plex_token:
        return
    want = {"episode": "show", "movie": "movie"}.get(media_type)
    try:
        r = httpx.get(f"{plex_url}/library/sections",
                      headers={"X-Plex-Token": plex_token, "Accept": "application/json"},
                      timeout=8)
        r.raise_for_status()
        sections = r.json().get("MediaContainer", {}).get("Directory", [])
        for sec in sections:
            if want and sec.get("type") != want:
                continue
            key = sec.get("key")
            if not key:
                continue
            httpx.get(f"{plex_url}/library/sections/{key}/refresh",
                      headers={"X-Plex-Token": plex_token}, timeout=8)
            log.info("🔄 Plex refresh: section %r (%s)", sec.get("title"), sec.get("type"))
    except Exception as e:
        log.debug("Plex refresh failed: %s", e)


def _plex_stop_and_replay(session_key: str, rating_key: str, client_id: str):
    """Stop the current Plex session and tell the client to play the updated file.

    Called after a symlink is created mid-play so Plex picks up the real content.
    The client will re-open the file from the beginning — the symlink now points
    to the real file so it plays immediately.
    """
    with get_conn() as db:
        plex_url   = PLEX_URL   or get_setting(db, "plex_url")
        plex_token = PLEX_TOKEN or get_setting(db, "plex_token")
    if not plex_url or not plex_token:
        log.debug("Plex URL/token not configured — skipping session interrupt")
        return
    try:
        # Stop the current session
        stop_url = f"{plex_url}/player/playback/stop"
        r = httpx.get(stop_url, params={
            "X-Plex-Token": plex_token,
            "X-Plex-Client-Identifier": client_id,
            "commandID": "1",
        }, timeout=5)
        log.info("Plex stop session %s → %s", session_key, r.status_code)
        time.sleep(1)
        # Play the item again — Plex will re-read the symlink which now points to real file
        play_url = f"{plex_url}/player/playback/playMedia"
        r2 = httpx.get(play_url, params={
            "X-Plex-Token":             plex_token,
            "X-Plex-Client-Identifier": client_id,
            "key":                      f"/library/metadata/{rating_key}",
            "offset":                   "0",
            "commandID":                "2",
        }, timeout=5)
        log.info("Plex replay rating_key=%s → %s", rating_key, r2.status_code)
    except Exception as e:
        log.warning("Plex session interrupt failed: %s", e)


def _immediate_symlink(library_id: str, real: Path):
    """Replace placeholder with symlink to real file as fast as possible.
    Called from arr On Import webhook — the placeholder may already be playing
    in Plex, so replacing it at the same path causes Plex to serve real content
    mid-stream without the user needing to re-play.
    """
    try:
        with get_conn() as db:
            lib = db.execute("SELECT * FROM library WHERE id=?", (library_id,)).fetchone()
        if not lib:
            return
        lib = dict(lib)
        ph = Path(lib["placeholder"])
        # Atomic replace: unlink placeholder, symlink real file at same path
        if ph.is_symlink() or ph.exists():
            ph.unlink(missing_ok=True)
        ph.symlink_to(str(real))
        log.info("⚡ Immediate symlink [arr import]: %s → %s", ph.name, real.name)

        # Record stream
        stream_id = str(uuid.uuid4())
        now       = iso(now_utc())
        expires   = iso(now_utc() + timedelta(days=SYMLINK_TTL_DAYS))
        with get_conn() as db:
            existing = db.execute(
                "SELECT id FROM streams WHERE library_id=? AND status='active'",
                (library_id,)
            ).fetchone()
            if existing:
                db.execute("UPDATE streams SET source_path=?, symlink_path=?, last_seen_at=? WHERE id=?",
                           (str(real), str(ph), now, existing["id"]))
            else:
                db.execute("""
                    INSERT INTO streams(id,library_id,arr,arr_id,media_type,title,year,
                                       season,episode,source_path,symlink_path,
                                       created_at,expires_at,last_seen_at,status)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (stream_id, library_id, lib["arr"], lib["arr_id"], lib["media_type"],
                      lib["title"], lib["year"], lib["season"], lib["episode"],
                      str(real), str(ph), now, expires, now, "active"))
        _notify_arr_rescan(lib["arr"], lib["arr_id"])
        # Interrupt Plex session so it re-reads the symlink (now pointing to real file)
        session_key = lib.get("_session_key", "")
        rating_key  = lib.get("_rating_key", "")
        client_id   = lib.get("_client_id", "")
        if session_key and rating_key and client_id:
            _plex_stop_and_replay(session_key, rating_key, client_id)
        # Always nudge Plex to rescan so the swap shows even without session info
        _plex_refresh(lib["media_type"])
    except Exception as e:
        log.error("_immediate_symlink failed: %s", e, exc_info=True)


def _background_symlink(library_id: str, real: Path):
    """Symlink a just-imported file immediately."""
    try:
        with get_conn() as db:
            lib = db.execute("SELECT * FROM library WHERE id=?", (library_id,)).fetchone()
            if not lib:
                return
            # Check if already active
            existing = db.execute(
                "SELECT * FROM streams WHERE library_id=? AND status='active'", (library_id,)
            ).fetchone()

        if existing:
            # Update symlink to new file
            ph = Path(lib["placeholder"])
            if ph.is_symlink() or ph.exists():
                ph.unlink(missing_ok=True)
            try:
                os.symlink(str(real), str(ph))
                with get_conn() as db:
                    db.execute("UPDATE streams SET source_path=?, last_seen_at=? WHERE id=?",
                               (str(real), iso(now_utc()), existing["id"]))
                log.info("🔄 Updated symlink [arr import]: %s → %s", ph.name, real.name)
                _plex_refresh(lib["media_type"])
            except OSError as e:
                log.error("arr import: symlink update failed: %s", e)
        else:
            lib_dict = dict(lib)
            link = _make_symlink(lib_dict, real)
            if link:
                stream_id = str(uuid.uuid4())
                now       = iso(now_utc())
                expires   = iso(now_utc() + timedelta(days=SYMLINK_TTL_DAYS))
                with get_conn() as db:
                    db.execute("""
                        INSERT INTO streams(id,library_id,arr,arr_id,media_type,title,year,
                                           season,episode,source_path,symlink_path,
                                           created_at,expires_at,last_seen_at,status)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    """, (stream_id, library_id, lib["arr"], lib["arr_id"], lib["media_type"],
                          lib["title"], lib["year"], lib["season"], lib["episode"],
                          str(real), str(link), now, expires, now, "active"))
                _notify_arr_rescan(lib["arr"], lib["arr_id"])
                log.info("✅ New symlink [arr import]: %s → %s", link.name, real.name)
                _plex_refresh(lib["media_type"])
            else:
                log.error("arr import: _make_symlink failed for %s", real)
    except Exception as e:
        log.error("_background_symlink failed: %s", e, exc_info=True)




def _background_activate(library_id: str, session_key: str = "",
                         client_id: str = "", rating_key: str = ""):
    """Run activate_stream then pre-cache next 3 episodes for binging."""
    try:
        result = activate_stream(library_id,
                                 session_key=session_key,
                                 client_id=client_id,
                                 rating_key=rating_key)
        log.info("Background activation result: %s", result)
        _precache_next_episodes(library_id)
    except Exception as e:
        log.error("Background activation failed: %s", e, exc_info=True)


def _get_arr_download_hash(arr: str, arr_id: int,
                           season: int | None, episode: int | None) -> str:
    """Return the torrent infohash (the arr's 'downloadId') for the release that
    Sonarr/Radarr grabbed for this item. Decypharr indexes torrents by this same
    hash, so it lets us match the exact file instead of guessing by title.
    Checks history (grabbed/imported) first, then the active queue.
    """
    atype = instance_type(arr)
    try:
        if atype == "sonarr":
            eps = arr_get(arr, "/episode",
                          {"seriesId": arr_id, "seasonNumber": season}) or []
            ep_id = next((e["id"] for e in eps
                          if e.get("episodeNumber") == episode), None)
            if not ep_id:
                return ""
            hist = arr_get(arr, "/history", {
                "episodeId": ep_id, "page": 1, "pageSize": 50,
                "sortKey": "date", "sortDirection": "descending",
            }) or {}
            for rec in (hist.get("records") or []):
                dl = (rec.get("downloadId") or "").strip()
                if dl:
                    return dl
            q = arr_get(arr, "/queue", {"page": 1, "pageSize": 200,
                                        "includeEpisode": True}) or {}
            for rec in (q.get("records") or []):
                if rec.get("episodeId") == ep_id and (rec.get("downloadId") or "").strip():
                    return rec["downloadId"].strip()

        elif atype == "radarr":
            recs = arr_get(arr, "/history/movie", {"movieId": arr_id})
            if isinstance(recs, list):
                for rec in recs:
                    dl = (rec.get("downloadId") or "").strip()
                    if dl:
                        return dl
            hist = arr_get(arr, "/history", {
                "page": 1, "pageSize": 50, "movieId": arr_id,
                "sortKey": "date", "sortDirection": "descending",
            }) or {}
            for rec in (hist.get("records") or []):
                dl = (rec.get("downloadId") or "").strip()
                if dl:
                    return dl
            q = arr_get(arr, "/queue", {"page": 1, "pageSize": 200}) or {}
            for rec in (q.get("records") or []):
                if rec.get("movieId") == arr_id and (rec.get("downloadId") or "").strip():
                    return rec["downloadId"].strip()
    except Exception as e:
        log.debug("download-hash lookup failed for %s/%s: %s", arr, arr_id, e)
    return ""


def _dc_name_for_hash(h: str) -> str:
    """Case-insensitive Decypharr lookup that reloads the index if the hash isn't
    known yet (the torrent may have just been added)."""
    if not h or not _dc_client:
        return ""
    for cand in (h, h.lower(), h.upper()):
        n = name_for_hash(cand)
        if n:
            return n
    _dc_client.reload_new()
    for cand in (h, h.lower(), h.upper()):
        n = name_for_hash(cand)
        if n:
            return n
    # Last resort: ask Decypharr directly (handles a not-yet-indexed torrent)
    try:
        name, _files = _dc_client.files_for_hash(h)
        return name or ""
    except Exception:
        return ""


_VIDEO_EXTS = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts", ".wmv"}

def _pick_decypharr_file(torrent_name: str, media_type: str,
                         season: int | None, episode: int | None) -> str:
    """Pick the right file inside a matched torrent: the SE-tagged video for an
    episode, or the largest non-sample video for a movie / single-file torrent."""
    files = list_files(torrent_name)
    vids  = [f for f in files if any(f.lower().endswith(e) for e in _VIDEO_EXTS)] or files

    def _size(f: str) -> int:
        return (get_torrent_file(torrent_name, f) or {}).get("s", 0) or 0

    if media_type == "episode" and season and episode:
        se = f"S{int(season):02d}E{int(episode):02d}".upper()
        tagged = [f for f in vids if se in f.upper()]
        if tagged:
            tagged.sort(key=_size, reverse=True)
            return tagged[0]

    non_sample = [f for f in vids if "sample" not in f.lower()] or vids
    non_sample.sort(key=_size, reverse=True)
    return non_sample[0] if non_sample else ""


def _cache_and_link(lib: dict, torrent_name: str, fname: str) -> bool:
    """Mark the proxy cache and swap the placeholder for a symlink to the real
    Decypharr file. Works whether or not the mount is locally visible:
      - mount visible  → real path → direct symlink (Plex plays the file)
      - mount not visible → stream URL only → proxy streams it
    """
    fdata   = get_torrent_file(torrent_name, fname) or {}
    ad_link = fdata.get("l", "")
    real    = _dc_client.get_file_path(torrent_name, fname) if _dc_client else None
    if not real and not ad_link:
        return False
    _proxy_db.set_cached(lib["id"], ad_link or "", fname)
    if real:
        _make_symlink(lib, real)
        # placeholdarr-style: nudge Plex to rescan so it picks up the real file
        # immediately instead of continuing to show the placeholder.
        _plex_refresh(lib.get("media_type", ""))
    _precache_next_episodes(lib["id"])
    return True


def _try_resolve_by_hash(lib: dict) -> bool:
    """Resolve via the exact download hash: arr downloadId → Decypharr torrent →
    exact file → symlink. The reliable path. Returns True on success."""
    if not _dc_client:
        return False
    h = _get_arr_download_hash(lib["arr"], lib["arr_id"],
                               lib.get("season"), lib.get("episode"))
    if not h:
        return False
    torrent_name = _dc_name_for_hash(h)
    if not torrent_name:
        log.info("⏳ download hash %s… not in Decypharr yet", h[:8])
        return False
    fname = _pick_decypharr_file(torrent_name, lib["media_type"],
                                 lib.get("season"), lib.get("episode"))
    if not fname:
        log.warning("hash %s… matched torrent %r but found no playable file",
                    h[:8], torrent_name)
        return False
    if _cache_and_link(lib, torrent_name, fname):
        log.info("🎯 hash-matched %s… → %s/%s", h[:8], torrent_name, fname)
        return True
    return False


def _try_resolve_by_title(lib: dict) -> bool:
    """Fallback: fuzzy title+SE match against the current Decypharr index."""
    fm = _find_in_fuse(lib["title"], lib.get("year"),
                       lib.get("season"), lib.get("episode"))
    if not fm:
        return False
    torrent_name, fname, _fdata = fm
    return _cache_and_link(lib, torrent_name, fname)


def _resolve_for_proxy(library_id: str):
    """Background resolution triggered when Plex opens a placeholder.

    Order of preference:
      1. Exact match by the arr's grabbed download hash (precise).
      2. Fuzzy title+SE match against whatever Decypharr already has.
      3. Trigger an arr search, then poll Decypharr — hash first, title fallback.
    On success the proxy cache is set (so the keepalive ends) and the placeholder
    is swapped for a symlink to the real file.
    """
    with get_conn() as db:
        lib = db.execute("SELECT * FROM library WHERE id=?", (library_id,)).fetchone()
    if not lib:
        _proxy_db.set_error(library_id, "not_found")
        return

    lib     = dict(lib)
    title   = lib["title"]
    year    = lib.get("year")
    season  = lib.get("season")
    episode = lib.get("episode")
    arr     = lib["arr"]
    arr_id  = lib["arr_id"]

    log.info("🔍 Resolving for proxy: %s s%se%s", title, season, episode)
    _proxy_db.set_resolving(library_id)

    # 1) Exact hash match — already grabbed and present in Decypharr
    if _try_resolve_by_hash(lib):
        return

    # 2) Fuzzy match against the current index
    if _try_resolve_by_title(lib):
        log.info("⚡ Proxy resolved by title match: %s s%se%s", title, season, episode)
        return

    # 3) Trigger a search, then poll (hash first, title fallback)
    _trigger_arr_search(arr, arr_id, season, episode)
    _create_fuse_symlinks_for_arr(arr, arr_id, title, year, season, episode)

    deadline        = time.time() + 45
    last_hash_check = 0.0
    known_hash      = ""
    while time.time() < deadline:
        time.sleep(0.5)
        if _dc_client:
            _dc_client.reload_new()

        # Learn the grabbed download hash once (it appears after the grab lands),
        # then stop re-querying the arr — just watch Decypharr's index for it.
        now = time.time()
        if not known_hash and now - last_hash_check >= 2:
            last_hash_check = now
            known_hash = _get_arr_download_hash(arr, arr_id, season, episode)

        if known_hash:
            tname = name_for_hash(known_hash) or name_for_hash(known_hash.lower()) \
                    or name_for_hash(known_hash.upper())
            if tname:
                fname = _pick_decypharr_file(tname, lib["media_type"], season, episode)
                if fname and _cache_and_link(lib, tname, fname):
                    log.info("✅ Proxy hash-resolved after %.1fs → %s/%s",
                             45 - (deadline - now), tname, fname)
                    return

        if _try_resolve_by_title(lib):
            log.info("✅ Proxy resolved by title after %.1fs", 45 - (deadline - time.time()))
            return

    log.warning("⏰ Proxy resolve timed out for %s s%se%s", title, season, episode)
    _proxy_db.set_error(library_id, "error")


def _precache_next_episodes(library_id: str, lookahead: int = 3):
    """After a play, pre-search and symlink the next N episodes.
    Spills into the next season if needed and it has been released.
    """
    with get_conn() as db:
        lib = db.execute("SELECT * FROM library WHERE id=?", (library_id,)).fetchone()
        if not lib or lib["media_type"] != "episode":
            return

        arr_id  = lib["arr_id"]
        season  = lib["season"]
        episode = lib["episode"]
        arr     = lib["arr"]

        # Find the next N episodes in the DB (same series, any season >= current)
        next_eps = db.execute("""
            SELECT * FROM library
            WHERE arr=? AND arr_id=? AND media_type='episode'
              AND (season > ? OR (season = ? AND episode > ?))
            ORDER BY season ASC, episode ASC
            LIMIT ?
        """, (arr, arr_id, season, season, episode, lookahead)).fetchall()

    if not next_eps:
        log.info("Pre-cache: no upcoming episodes found after s%se%s", season, episode)
        return

    log.info("Pre-cache: queuing %d episode(s) after s%se%s", len(next_eps), season, episode)

    for ep in next_eps:
        ep_id = ep["id"]
        ph    = Path(ep["placeholder"])

        # Skip if already symlinked
        if ph.is_symlink():
            log.debug("Pre-cache: s%se%s already symlinked — skipping",
                      ep["season"], ep["episode"])
            continue

        # Skip if already active
        with get_conn() as db:
            if db.execute("SELECT 1 FROM streams WHERE library_id=? AND status='active'",
                          (ep_id,)).fetchone():
                continue

        log.info("Pre-cache: activating s%se%s", ep["season"], ep["episode"])
        try:
            activate_stream(ep_id)
        except Exception as e:
            log.warning("Pre-cache: failed for s%se%s: %s",
                        ep["season"], ep["episode"], e)

# ── Sonarr / Radarr passthrough status ───────────────────────────────────────
@app.get("/api/arr/sonarr/status")
def sonarr_status(_: bool = Depends(require_api_key)):
    data = sonarr_get("/system/status")
    return {"connected": data is not None, "status": data}

@app.get("/api/arr/radarr/status")
def radarr_status(_: bool = Depends(require_api_key)):
    data = radarr_get("/system/status")
    return {"connected": data is not None, "status": data}

# ── Tautulli connection test ───────────────────────────────────────────────────
@app.get("/api/tautulli/status")
def tautulli_status(_: bool = Depends(require_api_key)):
    """
    Test the Tautulli connection by calling its API.
    Tautulli itself calls US (push webhook), so this only verifies
    we can reach Tautulli — not that the webhook is wired up.
    """
    with get_conn() as db:
        url = get_setting(db, "tautulli_url") or TAUTULLI_URL
        key = get_setting(db, "tautulli_api_key") or TAUTULLI_API_KEY

    if not url:
        return {"connected": False, "error": "Tautulli URL not configured"}

    try:
        params = {"apikey": key, "cmd": "get_server_info"} if key else {"cmd": "get_server_info"}
        r = httpx.get(f"{url}/api/v2", params=params, timeout=8)
        r.raise_for_status()
        data = r.json()
        # Tautulli wraps responses in {"response": {"result": "success", "data": {...}}}
        result = data.get("response", {})
        if result.get("result") == "success":
            info = result.get("data", {})
            return {
                "connected": True,
                "version":   info.get("tautulli_version") or info.get("version"),
                "server":    info.get("pms_name") or info.get("pms_identifier"),
            }
        else:
            # Got a response but result != success — likely wrong API key
            return {"connected": False, "error": result.get("message", "Unexpected response — check API key")}
    except httpx.ConnectError:
        return {"connected": False, "error": "Connection refused — is Tautulli running at that URL?"}
    except httpx.TimeoutException:
        return {"connected": False, "error": "Timed out — check URL and network"}
    except Exception as exc:
        return {"connected": False, "error": str(exc)}

@app.post("/api/webhook/test")
async def webhook_test(_: bool = Depends(require_api_key)):
    """
    Fire a synthetic Tautulli play event against our own webhook endpoint
    so the user can verify the inbound path works without needing Tautulli
    to actually trigger playback.
    Returns the result from the webhook handler.
    """
    # Use the first active library item we have as the test subject
    with get_conn() as db:
        row = db.execute(
            "SELECT * FROM library ORDER BY synced_at DESC LIMIT 1"
        ).fetchone()

    if not row:
        return {"ok": False, "error": "No library items yet — run a sync first"}

    # Build a realistic fake Tautulli payload
    if row["media_type"] == "episode":
        payload = {
            "event":              "play",
            "media_type":         "episode",
            "file":               row["placeholder"],
            "grandparent_title":  row["title"],
            "parent_media_index": row["season"],
            "media_index":        row["episode"],
            "title":              row["title"],
            "year":               row["year"],
        }
    else:
        payload = {
            "event":      "play",
            "media_type": "movie",
            "file":       row["placeholder"],
            "title":      row["title"],
            "year":       row["year"],
        }

    try:
        r = httpx.post(
            "http://127.0.0.1:" + str(os.getenv("PORT", "7474")) + "/webhook/tautulli",
            json=payload, timeout=15,
        )
        try:
            data = r.json()
        except Exception:
            data = {"raw": r.text[:300], "status_code": r.status_code}
        return {"ok": r.status_code < 400, "test_item": row["title"],
                "webhook_response": data, "status_code": r.status_code}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}

# ── Sonarr / Radarr import webhooks ──────────────────────────────────────────
#
# Configure in Sonarr/Radarr:
#   Configure in Sonarr AND Radarr:
#   Settings -> Connect -> Webhook
#   URL: http://debridarr:7474/webhook/arr   (works for both)
#   Triggers: On Import, On Upgrade, On Episode/Movie File Delete
#

async def _handle_sonarr_payload(payload: dict, background_tasks: BackgroundTasks,
                                 inst: str | None = None):
    inst = inst or primary_key("sonarr")
    event = payload.get("eventType", "")
    log.info("Sonarr webhook [%s]: eventType=%s", inst, event)

    if event == "Test":
        return {"ok": True, "message": "Sonarr webhook is working"}

    if event == "EpisodeFileDelete":
        series_id = (payload.get("series") or {}).get("id")
        for ep in payload.get("episodes") or []:
            season  = ep.get("seasonNumber")
            episode = ep.get("episodeNumber")
            if not series_id or season is None or episode is None:
                continue
            lib_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"{inst}:{series_id}:{season}:{episode}"))
            with get_conn() as db:
                lib = db.execute("SELECT * FROM library WHERE id=?", (lib_id,)).fetchone()
            if lib:
                revert_to_placeholder(Path(lib["placeholder"]), library_id=lib_id)
                with get_conn() as db:
                    db.execute("UPDATE streams SET status='expired' WHERE library_id=? AND status='active'", (lib_id,))
                log.info("Sonarr webhook: reverted placeholder for %s s%se%s", lib["title"], season, episode)
        return {"ok": True}

    if event not in ("Download",):
        return {"ok": True, "skipped": True, "reason": f"eventType={event}"}

    series      = payload.get("series") or {}
    series_id   = series.get("id")
    episodes    = payload.get("episodes") or []
    ep_file     = payload.get("episodeFile") or {}
    download_id = (payload.get("downloadId") or "").strip()
    rel_path    = ep_file.get("relativePath", "")
    series_path = series.get("path", "")

    if not series_id or not episodes:
        return {"ok": False, "error": "Missing series id or episodes in payload"}

    results = []
    for ep in episodes:
        season  = ep.get("seasonNumber")
        episode = ep.get("episodeNumber")
        if season is None or episode is None:
            continue
        lib_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"{inst}:{series_id}:{season}:{episode}"))
        real = None

        if download_id and _dc_client:
            torrent_name = name_for_hash(download_id.lower())
            if not torrent_name:
                _dc_client.reload_new()
                torrent_name = name_for_hash(download_id.lower())
            if torrent_name:
                se_tag  = f"S{int(season):02d}E{int(episode):02d}"
                files   = list_files(torrent_name)
                matched = [f for f in files if se_tag.upper() in f.upper()]
                if not matched:
                    matched = [f for f in files if any(f.lower().endswith(e) for e in {".mkv",".mp4",".avi",".mov",".m4v"})]
                if matched:
                    real = _dc_client.get_file_path(torrent_name, matched[0])
                    log.info("Sonarr webhook: hash match %s -> %s/%s", download_id[:8], torrent_name, matched[0])

        if not real and series_path and rel_path:
            candidate = Path(series_path) / rel_path
            if candidate.exists():
                real = candidate

        if not real:
            real = _get_episode_file_path(inst, series_id, season, episode)

        if not real:
            log.warning("Sonarr webhook: no file for s%se%s hash=%s", season, episode, download_id)
            results.append({"season": season, "episode": episode, "ok": False, "error": "File not found"})
            continue

        background_tasks.add_task(_immediate_symlink, lib_id, real)
        log.info("Sonarr webhook: queued symlink s%se%s -> %s", season, episode, real)
        results.append({"season": season, "episode": episode, "ok": True, "path": str(real)})

    return {"ok": True, "results": results}


async def _handle_radarr_payload(payload: dict, background_tasks: BackgroundTasks,
                                 inst: str | None = None):
    inst = inst or primary_key("radarr")
    event = payload.get("eventType", "")
    log.info("Radarr webhook [%s]: eventType=%s", inst, event)

    if event == "Test":
        return {"ok": True, "message": "Radarr webhook is working"}

    if event == "MovieFileDelete":
        movie_id = (payload.get("movie") or {}).get("id")
        if movie_id:
            lib_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"{inst}:{movie_id}"))
            with get_conn() as db:
                lib = db.execute("SELECT * FROM library WHERE id=?", (lib_id,)).fetchone()
            if lib:
                revert_to_placeholder(Path(lib["placeholder"]), library_id=lib_id)
                with get_conn() as db:
                    db.execute("UPDATE streams SET status='expired' WHERE library_id=? AND status='active'", (lib_id,))
                log.info("Radarr webhook: reverted placeholder for %s", lib["title"])
        return {"ok": True}

    if event not in ("Download",):
        return {"ok": True, "skipped": True, "reason": f"eventType={event}"}

    movie       = payload.get("movie") or {}
    movie_id    = movie.get("id")
    movie_file  = payload.get("movieFile") or {}
    download_id = (payload.get("downloadId") or "").strip()
    rel_path    = movie_file.get("relativePath", "")
    movie_path  = movie.get("folderPath") or movie.get("path", "")

    if not movie_id:
        return {"ok": False, "error": "Missing movie id in payload"}

    lib_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"{inst}:{movie_id}"))
    real   = None

    if download_id and _dc_client:
        torrent_name = name_for_hash(download_id.lower())
        if not torrent_name:
            _dc_client.reload_new()
            torrent_name = name_for_hash(download_id.lower())
        if torrent_name:
            files = list_files(torrent_name)
            video = [f for f in files if any(f.lower().endswith(e) for e in {".mkv",".mp4",".avi",".mov",".m4v"})]
            if video:
                def file_size(f):
                    fd = get_torrent_file(torrent_name, f)
                    return fd.get("s", 0) if fd else 0
                best = max(video, key=file_size)
                real = _dc_client.get_file_path(torrent_name, best)
                log.info("Radarr webhook: hash match %s -> %s/%s", download_id[:8], torrent_name, best)

    if not real and movie_path and rel_path:
        candidate = Path(movie_path) / rel_path
        if candidate.exists():
            real = candidate

    if not real:
        real = _get_movie_file_path(inst, movie_id)

    if not real:
        log.warning("Radarr webhook: no file for movie_id=%s hash=%s", movie_id, download_id)
        return {"ok": False, "error": "File not found"}

    background_tasks.add_task(_immediate_symlink, lib_id, real)
    log.info("Radarr webhook: queued symlink movie_id=%s -> %s", movie_id, real)
    return {"ok": True, "path": str(real)}


@app.post("/webhook/arr")
async def arr_webhook(request: Request, background_tasks: BackgroundTasks):
    body = await request.body()
    try:
        payload = json.loads(body)
    except Exception:
        log.warning("arr webhook: unparseable body: %r", body[:200])
        return JSONResponse(status_code=200, content={"ok": True, "skipped": True})
    log.info("arr webhook: keys=%s eventType=%s", list(payload.keys()), payload.get("eventType"))
    if "series" in payload or "episodes" in payload:
        return await _handle_sonarr_payload(payload, background_tasks)
    if "movie" in payload:
        return await _handle_radarr_payload(payload, background_tasks)
    return JSONResponse(status_code=200, content={"ok": True, "message": "webhook received"})


@app.post("/webhook/sonarr")
async def sonarr_webhook(request: Request, background_tasks: BackgroundTasks):
    body = await request.body()
    try:
        payload = json.loads(body)
    except Exception:
        return JSONResponse(status_code=200, content={"ok": True})
    return await _handle_sonarr_payload(payload, background_tasks)


@app.post("/webhook/radarr")
async def radarr_webhook(request: Request, background_tasks: BackgroundTasks):
    body = await request.body()
    try:
        payload = json.loads(body)
    except Exception:
        return JSONResponse(status_code=200, content={"ok": True})
    return await _handle_radarr_payload(payload, background_tasks)


@app.post("/webhook/sonarr/{inst}")
async def sonarr_webhook_inst(inst: str, request: Request, background_tasks: BackgroundTasks):
    """Per-instance Sonarr webhook. Point a specific Sonarr instance here
    (e.g. /webhook/sonarr/sonarr4k) so imports map to the right library tree."""
    if instance_type(inst) != "sonarr":
        return JSONResponse(status_code=404, content={"ok": False, "error": "unknown sonarr instance"})
    body = await request.body()
    try:
        payload = json.loads(body)
    except Exception:
        return JSONResponse(status_code=200, content={"ok": True})
    return await _handle_sonarr_payload(payload, background_tasks, inst=inst)


@app.post("/webhook/radarr/{inst}")
async def radarr_webhook_inst(inst: str, request: Request, background_tasks: BackgroundTasks):
    """Per-instance Radarr webhook (e.g. /webhook/radarr/radarr4k)."""
    if instance_type(inst) != "radarr":
        return JSONResponse(status_code=404, content={"ok": False, "error": "unknown radarr instance"})
    body = await request.body()
    try:
        payload = json.loads(body)
    except Exception:
        return JSONResponse(status_code=200, content={"ok": True})
    return await _handle_radarr_payload(payload, background_tasks, inst=inst)



# ── Browse arr catalogues (without importing everything) ─────────────────────
@app.get("/api/arr/sonarr/series")
def sonarr_series(inst: str | None = None, _: bool = Depends(require_api_key)):
    """Return all series from a Sonarr instance with per-season episode counts."""
    key = inst or primary_key("sonarr")
    if instance_type(key) != "sonarr":
        raise HTTPException(404, f"Unknown sonarr instance {key!r}")
    data = arr_get(key, "/series") or []
    with get_conn() as db:
        imported = set(
            r["arr_id"] for r in db.execute("SELECT arr_id FROM library WHERE arr=?", (key,)).fetchall()
        )
    result = []
    for s in sorted(data, key=lambda x: x.get("sortTitle") or x.get("title", "")):
        seasons = {}
        for se in s.get("seasons", []):
            sn = se.get("seasonNumber", 0)
            if sn == 0:
                continue
            stats = se.get("statistics", {})
            seasons[str(sn)] = stats.get("totalEpisodeCount") or stats.get("episodeCount") or 0
        result.append({
            "id":        s.get("id"),
            "title":     s.get("title"),
            "year":      s.get("year"),
            "status":    s.get("status"),
            "seasons":   seasons,
            "overview":  (s.get("overview") or "")[:200],
            "imported":  s.get("id") in imported,
        })
    return {"series": result, "instance": key}

@app.get("/api/arr/radarr/movies")
def radarr_movies(inst: str | None = None, _: bool = Depends(require_api_key)):
    """Return all movies from a Radarr instance, flagged by library membership."""
    key = inst or primary_key("radarr")
    if instance_type(key) != "radarr":
        raise HTTPException(404, f"Unknown radarr instance {key!r}")
    data = arr_get(key, "/movie") or []
    with get_conn() as db:
        imported = set(
            r["arr_id"] for r in db.execute("SELECT arr_id FROM library WHERE arr=?", (key,)).fetchall()
        )
    result = []
    for m in sorted(data, key=lambda x: x.get("sortTitle") or x.get("title", "")):
        result.append({
            "id":       m.get("id"),
            "title":    m.get("title"),
            "year":     m.get("year"),
            "status":   m.get("status"),
            "overview": (m.get("overview") or "")[:200],
            "imported": m.get("id") in imported,
        })
    return {"movies": result, "instance": key}

class LibraryAddItem(BaseModel):
    arr:    str   # instance key (e.g. "sonarr", "radarr4k")
    arr_id: int

@app.post("/api/library/add")
def library_add(item: LibraryAddItem, _: bool = Depends(require_api_key)):
    """Import a single series or movie from an arr into the library and create placeholders."""
    key   = item.arr
    atype = instance_type(key)
    if atype is None:
        raise HTTPException(404, f"Unknown instance {key!r}")
    with get_conn() as db:
        if atype == "sonarr":
            series = arr_get(key, f"/series/{item.arr_id}")
            if not series:
                raise HTTPException(404, "Series not found in Sonarr")
            title     = series.get("title", "")
            year      = series.get("year")
            plot      = series.get("overview", "")
            status    = series.get("status", "")
            studio    = series.get("network") or ""
            genres    = series.get("genres", [])
            premiered = (series.get("firstAired") or "")[:10]
            tvdb_id   = series.get("tvdbId")
            imdb_id   = series.get("imdbId")
            tmdb_id   = series.get("tmdbId")

            show_folder = instance_strm_root(key) / "tv" / safe(title)
            show_folder.mkdir(parents=True, exist_ok=True)
            write_tvshow_nfo(show_folder, title, year, tvdb_id, tmdb_id, imdb_id,
                             plot=plot, premiered=premiered, status=status,
                             studio=studio, genres=genres)

            episodes = arr_get(key, "/episode", {"seriesId": item.arr_id}) or []
            count = 0
            for ep in episodes:
                if not ep.get("monitored"):
                    continue
                s        = ep.get("seasonNumber")
                e        = ep.get("episodeNumber")
                ep_title = ep.get("title", "")
                ep_plot  = ep.get("overview", "")
                ep_aired = (ep.get("airDate") or "")[:10]
                tvdb_ep  = ep.get("tvdbId")
                tmdb_ep  = ep.get("tmdbId")
                lib_id   = str(uuid.uuid5(uuid.NAMESPACE_URL, f"{key}:{item.arr_id}:{s}:{e}"))
                ph       = placeholder_path(key, "episode", title, year, s, e)
                ensure_placeholder(ph)
                write_episode_nfo(ph, ep_title, title, s, e,
                                  tvdb_ep_id=tvdb_ep, tmdb_ep_id=tmdb_ep,
                                  plot=ep_plot, aired=ep_aired)
                db.execute("""
                    INSERT INTO library(id,arr,arr_id,media_type,title,year,season,episode,placeholder,synced_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(id) DO UPDATE SET
                      title=excluded.title, year=excluded.year,
                      placeholder=excluded.placeholder, synced_at=excluded.synced_at
                """, (lib_id, key, item.arr_id, "episode", title, year, s, e, str(ph), iso(now_utc())))
                count += 1
            return {"ok": True, "arr": key, "title": title, "episodes_added": count}

        else:  # radarr
            movie = arr_get(key, f"/movie/{item.arr_id}")
            if not movie:
                raise HTTPException(404, "Movie not found in Radarr")
            title     = movie.get("title", "")
            year      = movie.get("year")
            plot      = movie.get("overview", "")
            premiered = (movie.get("inCinemas") or movie.get("digitalRelease") or "")[:10]
            studio    = movie.get("studio") or ""
            genres    = movie.get("genres", [])
            tmdb_id   = movie.get("tmdbId")
            imdb_id   = movie.get("imdbId")
            lib_id    = str(uuid.uuid5(uuid.NAMESPACE_URL, f"{key}:{item.arr_id}"))
            ph        = placeholder_path(key, "movie", title, year, None, None)
            ensure_placeholder(ph)
            write_movie_nfo(ph.parent, title, year, tmdb_id, imdb_id,
                            plot=plot, premiered=premiered, studio=studio, genres=genres)
            db.execute("""
                INSERT INTO library(id,arr,arr_id,media_type,title,year,season,episode,placeholder,synced_at)
                VALUES(?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET
                  title=excluded.title, year=excluded.year,
                  placeholder=excluded.placeholder, synced_at=excluded.synced_at
            """, (lib_id, key, item.arr_id, "movie", title, year, None, None, str(ph), iso(now_utc())))
            return {"ok": True, "arr": key, "title": title, "episodes_added": 1}

UI = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Debridarr</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#0d0f18;--surface:#13151f;--card:#1a1d2e;--border:#252838;
  --text:#e2e4ef;--sub:#6b7280;--muted:#3d4057;
  --accent:#6366f1;--accent2:#818cf8;--accent-dim:rgba(99,102,241,.12);
  --green:#22c55e;--green-dim:rgba(34,197,94,.12);
  --red:#ef4444;--red-dim:rgba(239,68,68,.12);
  --orange:#f97316;--yellow:#eab308;
  --radius:10px;--radius-sm:6px;
}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
  background:var(--bg);color:var(--text);font-size:14px;line-height:1.5;min-height:100vh}

/* ── Nav ── */
nav{
  display:flex;align-items:center;gap:4px;padding:10px 20px;
  border-bottom:1px solid var(--border);background:var(--surface);
  position:sticky;top:0;z-index:50;backdrop-filter:blur(8px)
}
.logo{font-weight:800;font-size:16px;color:var(--accent2);margin-right:12px;
  display:flex;align-items:center;gap:6px}
.nav-btn{background:none;border:none;color:var(--sub);padding:6px 12px;
  border-radius:var(--radius-sm);cursor:pointer;font-size:13px;font-weight:500;
  transition:all .15s}
.nav-btn:hover{color:var(--text);background:var(--border)}
.nav-btn.active{color:#fff;background:var(--accent)}
.nav-right{margin-left:auto}

/* ── Layout ── */
.page{padding:24px;max-width:1200px;margin:0 auto}
.tab{display:none}.tab.active{display:block}
section h1{font-size:22px;font-weight:700;margin-bottom:4px}
.page-desc{color:var(--sub);font-size:13px;margin-bottom:20px}

/* ── Cards ── */
.card{background:var(--card);border:1px solid var(--border);
  border-radius:var(--radius);padding:20px;margin-bottom:16px}
.card-title{font-size:13px;font-weight:600;color:var(--sub);
  text-transform:uppercase;letter-spacing:.05em;margin-bottom:14px}

/* ── Buttons ── */
button{background:var(--accent);color:#fff;border:none;padding:7px 14px;
  border-radius:var(--radius-sm);cursor:pointer;font-size:13px;font-weight:500;
  transition:opacity .15s;white-space:nowrap}
button:hover{opacity:.85}
button:disabled{opacity:.45;cursor:not-allowed}
button.ghost{background:none;border:1px solid var(--border);color:var(--text)}
button.ghost:hover{border-color:var(--accent2);color:var(--accent2)}
button.danger{background:var(--red)}
button.sm{padding:4px 10px;font-size:12px}
button.icon{padding:5px 8px;font-size:14px;background:none;
  border:1px solid var(--border);color:var(--sub)}
button.icon:hover{color:var(--text);border-color:var(--text)}

/* ── Forms ── */
input,select{
  background:var(--surface);border:1px solid var(--border);color:var(--text);
  padding:8px 12px;border-radius:var(--radius-sm);font-size:13px;
  outline:none;transition:border-color .15s;width:100%}
input:focus,select:focus{border-color:var(--accent2)}
label{display:block;font-size:12px;color:var(--sub);font-weight:500;margin-bottom:5px}
.field{margin-bottom:14px}
.row{display:flex;gap:8px;align-items:flex-end}
.row input{flex:1}

/* ── Toolbar ── */
.toolbar{display:flex;align-items:center;gap:8px;margin-bottom:18px;flex-wrap:wrap}
.toolbar h1{margin-right:auto;margin-bottom:0}
.search-box{
  position:relative;flex:0 0 220px}
.search-box input{padding-left:30px}
.search-box::before{
  content:'⌕';position:absolute;left:10px;top:50%;transform:translateY(-50%);
  color:var(--sub);font-size:15px;pointer-events:none}

/* ── Media sections ── */
.media-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}
@media(max-width:800px){.media-grid{grid-template-columns:1fr}}
.media-section{}
.section-head{
  display:flex;align-items:center;gap:10px;margin-bottom:10px}
.section-title{font-size:14px;font-weight:700}
.section-count{
  background:var(--accent-dim);color:var(--accent2);
  padding:2px 8px;border-radius:20px;font-size:11px;font-weight:700}
.section-search{
  margin-left:auto;position:relative;width:160px}
.section-search input{padding:5px 10px 5px 28px;font-size:12px}
.section-search::before{
  content:'⌕';position:absolute;left:8px;top:50%;transform:translateY(-50%);
  color:var(--sub);font-size:13px;pointer-events:none}

/* ── Table ── */
.tbl-wrap{background:var(--card);border:1px solid var(--border);
  border-radius:var(--radius);overflow:hidden}
table{width:100%;border-collapse:collapse;font-size:13px}
th{text-align:left;padding:10px 14px;color:var(--sub);font-size:11px;
  font-weight:600;text-transform:uppercase;letter-spacing:.05em;
  background:var(--surface);border-bottom:1px solid var(--border)}
td{padding:9px 14px;border-bottom:1px solid var(--border);vertical-align:middle}
tr:last-child td{border-bottom:none}
tr:hover td{background:rgba(255,255,255,.02)}

/* ── Pagination ── */
.pagination{
  display:flex;align-items:center;gap:4px;padding:10px 14px;
  border-top:1px solid var(--border);background:var(--surface);
  border-radius:0 0 var(--radius) var(--radius);flex-wrap:wrap}
.pagination .info{color:var(--sub);font-size:12px;margin-right:auto}
.pg-btn{
  width:30px;height:30px;padding:0;display:flex;align-items:center;
  justify-content:center;font-size:12px;font-weight:600;
  background:none;border:1px solid var(--border);color:var(--sub);
  border-radius:var(--radius-sm)}
.pg-btn:hover{border-color:var(--accent2);color:var(--accent2)}
.pg-btn.active{background:var(--accent);border-color:var(--accent);color:#fff}
.pg-btn.ellipsis{border:none;cursor:default;color:var(--sub)}
.pg-btn.ellipsis:hover{color:var(--sub);border:none}

/* ── Badges & pills ── */
.badge{display:inline-flex;align-items:center;gap:4px;padding:2px 8px;
  border-radius:20px;font-size:11px;font-weight:600}
.badge-blue{background:var(--accent-dim);color:var(--accent2)}
.badge-green{background:var(--green-dim);color:var(--green)}
.badge-red{background:var(--red-dim);color:var(--red)}
.badge-gray{background:rgba(107,114,128,.15);color:var(--sub)}
.dot{width:6px;height:6px;border-radius:50%;display:inline-block}
.dot-green{background:var(--green)}.dot-red{background:var(--red)}
.dot-gray{background:var(--muted)}.dot-yellow{background:var(--yellow)}

/* ── Connection cards ── */
.conn-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px}
.status-bar{margin-top:10px;font-size:13px;min-height:22px;
  display:flex;align-items:center;gap:6px}

/* ── Toast ── */
.toast{position:fixed;bottom:20px;left:50%;transform:translateX(-50%) translateY(10px);
  background:var(--card);border:1px solid var(--border);border-radius:8px;
  padding:10px 18px;font-size:13px;z-index:999;
  box-shadow:0 8px 32px rgba(0,0,0,.5);opacity:0;
  transition:opacity .2s,transform .2s;pointer-events:none;white-space:nowrap}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0)}

/* ── Empty state ── */
.empty{text-align:center;padding:40px 20px;color:var(--sub)}
.empty-icon{font-size:32px;margin-bottom:8px}

/* ── Spinner ── */
@keyframes spin{to{transform:rotate(360deg)}}
.spin{display:inline-block;width:13px;height:13px;border:2px solid var(--border);
  border-top-color:var(--accent2);border-radius:50%;animation:spin .6s linear infinite}

/* ── Library tree ── */
.lib-wrap{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden;margin-bottom:4px}
.show-row{display:flex;align-items:center;gap:12px;padding:12px 16px;cursor:pointer;border-bottom:1px solid var(--border);transition:background .1s;user-select:none}
.show-row:hover{background:rgba(255,255,255,.03)}
.show-row:last-child{border-bottom:none}
.show-chevron{color:var(--sub);font-size:10px;width:14px;flex-shrink:0;transition:transform .15s}
.show-chevron.open{transform:rotate(90deg)}
.show-title{font-weight:600;font-size:14px;flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.show-meta{display:flex;align-items:center;gap:8px;flex-shrink:0}
.show-meta span{font-size:12px;color:var(--sub)}
.link-bar{display:flex;align-items:center;gap:4px;flex-shrink:0}
.link-bar-track{width:60px;height:4px;background:var(--border);border-radius:2px;overflow:hidden}
.link-bar-fill{height:100%;background:var(--green);border-radius:2px;transition:width .3s}
.link-bar-fill.partial{background:var(--orange)}
.link-bar-fill.none{background:var(--muted)}
.link-bar-label{font-size:11px;color:var(--sub);min-width:32px;text-align:right}

.season-block{border-bottom:1px solid var(--border)}
.season-block:last-child{border-bottom:none}
.season-row{display:flex;align-items:center;gap:12px;padding:9px 16px 9px 36px;cursor:pointer;background:rgba(0,0,0,.15);transition:background .1s;user-select:none}
.season-row:hover{background:rgba(0,0,0,.25)}
.season-label{font-size:13px;font-weight:600;flex:1}
.season-tmdb{font-size:11px;color:var(--sub);margin-left:4px}

.ep-table{width:100%;border-collapse:collapse}
.ep-table td{padding:7px 16px 7px 52px;border-bottom:1px solid rgba(255,255,255,.04);font-size:13px;vertical-align:middle}
.ep-table tr:last-child td{border-bottom:none}
.ep-table tr:hover td{background:rgba(255,255,255,.02)}
.ep-tag{color:var(--sub);font-size:11px;font-weight:600;font-family:monospace;min-width:60px;display:inline-block}
.ep-name{color:var(--text);flex:1}
.ep-status{display:inline-flex;align-items:center;gap:6px}
.ep-exp{font-size:11px;color:var(--sub)}
.ep-missing{color:var(--muted);font-size:12px;font-style:italic}

.lib-filter-bar{display:flex;align-items:center;gap:8px;margin-bottom:10px;flex-wrap:wrap}
.lib-filter-bar input{flex:1;min-width:160px}
.filter-btn{padding:5px 12px;font-size:12px;border-radius:20px;border:1px solid var(--border);background:none;color:var(--sub);cursor:pointer;transition:all .15s;white-space:nowrap}
.filter-btn:hover{border-color:var(--accent2);color:var(--accent2)}
.filter-btn.on{background:var(--accent);border-color:var(--accent);color:#fff}

.sonarr-total{font-size:11px;color:var(--muted);font-style:italic}
#wizOverlay{position:fixed;inset:0;background:rgba(0,0,0,.75);
  z-index:200;display:none;align-items:center;justify-content:center;padding:16px}
#wizOverlay.open{display:flex}
#wizBox{background:var(--card);border:1px solid var(--border);
  border-radius:14px;width:100%;max-width:560px;display:flex;flex-direction:column;
  max-height:90vh;overflow:hidden}
.wiz-top{padding:22px 24px 0;flex-shrink:0}
.wiz-top-row{display:flex;justify-content:space-between;align-items:flex-start}
.wiz-top h2{font-size:18px;font-weight:700}
.wiz-top p{color:var(--sub);font-size:13px;margin-top:4px}
.wiz-close{background:none;border:none;color:var(--sub);font-size:24px;
  cursor:pointer;padding:0;line-height:1;transition:color .15s}
.wiz-close:hover{color:var(--text)}
.wiz-steps{display:flex;gap:4px;padding:16px 24px 0;overflow-x:auto}
.wiz-step{
  padding:5px 12px;border-radius:20px;font-size:11px;font-weight:700;
  background:var(--border);color:var(--sub);white-space:nowrap;cursor:default}
.wiz-step.active{background:var(--accent);color:#fff}
.wiz-step.done{background:var(--green-dim);color:var(--green)}
.wiz-body{padding:22px 24px;overflow-y:auto;flex:1}
.wiz-foot{
  padding:16px 24px;border-top:1px solid var(--border);flex-shrink:0;
  display:flex;justify-content:space-between;align-items:center;gap:8px}
.wiz-hint{color:var(--sub);font-size:12px}
</style>
</head>
<body>

<!-- NAV -->
<nav>
  <span class="logo">⚡ Debridarr</span>
  <button class="nav-btn active" data-tab="streams" onclick="showTab(this)">Streams</button>
  <button class="nav-btn" data-tab="library" onclick="showTab(this)">Library</button>
  <button class="nav-btn" data-tab="connections" onclick="showTab(this)">Connections</button>
  <button class="nav-btn" data-tab="decypharr" onclick="showTab(this)">Decypharr</button>
  <button class="nav-btn ghost sm nav-right" onclick="openWizard()">Setup Wizard</button>
</nav>

<div class="page">

<!-- ══ STREAMS ══ -->
<section id="streams" class="tab active">
  <div class="toolbar">
    <h1>Streams</h1>
    <button class="ghost" onclick="loadStreams('active')">Refresh</button>
    <button class="ghost" onclick="loadStreams('all')">Show All</button>
    <button class="danger" onclick="runCleanup()">Run Expiry Cleanup</button>
  </div>

  <div class="media-grid">
    <!-- Movies -->
    <div class="media-section">
      <div class="section-head">
        <span class="section-title">🎬 Movies</span>
        <span class="section-count" id="movieCount">0</span>
        <div class="section-search">
          <input id="movieSearch" placeholder="Search movies..." oninput="renderMovies()">
        </div>
      </div>
      <div id="moviesWrap">
        <div class="tbl-wrap"><div class="empty"><div class="empty-icon">🎬</div>Loading...</div></div>
      </div>
    </div>

    <!-- TV -->
    <div class="media-section">
      <div class="section-head">
        <span class="section-title">📺 TV Series</span>
        <span class="section-count" id="tvCount">0</span>
        <div class="section-search">
          <input id="tvSearch" placeholder="Search TV..." oninput="renderTV()">
        </div>
      </div>
      <div id="tvWrap">
        <div class="tbl-wrap"><div class="empty"><div class="empty-icon">📺</div>Loading...</div></div>
      </div>
    </div>
  </div>
</section>

<!-- ══ LIBRARY ══ -->
<section id="library" class="tab">
  <div class="toolbar">
    <h1>Library</h1>
    <button class="ghost" onclick="loadLibrary()">Refresh</button>
    <button class="ghost" onclick="triggerSync()" id="syncBtn">Sync All</button>
    <button class="ghost" onclick="runSpotCheck()" id="spotBtn">Spot Check</button>
    <button class="ghost" onclick="toggleNF()">Not Found</button>
  </div>
  <p class="page-desc" id="libDesc">Loading library...</p>

  <div class="media-grid">

    <!-- Movies -->
    <div class="media-section">
      <div class="section-head">
        <span class="section-title">Movies</span>
        <span class="section-count" id="libMovieCount">0</span>
      </div>
      <div class="lib-filter-bar">
        <input id="libMovieSearch" placeholder="Search movies..." oninput="onMovieSearch()">
        <button class="filter-btn" id="mfAll" onclick="setMovieFilter('all')">All</button>
        <button class="filter-btn" id="mfLinked" onclick="setMovieFilter('linked')">Linked</button>
        <button class="filter-btn" id="mfPlaceholder" onclick="setMovieFilter('placeholder')">Placeholder</button>
      </div>
      <div id="libMoviesWrap">
        <div class="tbl-wrap"><div class="empty">Loading...</div></div>
      </div>
    </div>

    <!-- TV -->
    <div class="media-section">
      <div class="section-head">
        <span class="section-title">TV Series</span>
        <span class="section-count" id="libTVCount">0</span>
      </div>
      <div class="lib-filter-bar">
        <input id="libTVSearch" placeholder="Search shows..." oninput="onTVSearch()">
        <button class="filter-btn" id="tfAll" onclick="setTVFilter('all')">All</button>
        <button class="filter-btn" id="tfLinked" onclick="setTVFilter('linked')">Linked</button>
        <button class="filter-btn" id="tfPlaceholder" onclick="setTVFilter('placeholder')">Placeholder</button>
      </div>
      <div id="libTVWrap">
        <div class="tbl-wrap"><div class="empty">Loading...</div></div>
      </div>
    </div>

  </div>

  <!-- Not Found -->
  <div id="nfSection" style="display:none;margin-top:20px">
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
        <span class="card-title" style="margin:0">Not Found Items</span>
        <button class="danger sm" onclick="clearAllNF()">Clear All</button>
      </div>
      <div id="nfList"><div class="empty">Loading...</div></div>
    </div>
  </div>
</section>

<!-- ══ CONNECTIONS ══ -->
<section id="connections" class="tab">
  <div class="toolbar"><h1>Connections</h1></div>

  <div class="card" style="margin-bottom:16px">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
      <div class="card-title" style="margin:0">Sonarr &amp; Radarr instances</div>
      <div style="display:flex;gap:8px">
        <button class="ghost sm" onclick="cAddInstance('sonarr')">+ Sonarr</button>
        <button class="ghost sm" onclick="cAddInstance('radarr')">+ Radarr</button>
      </div>
    </div>
    <p style="color:var(--sub);font-size:13px;margin-bottom:12px">
      Name instances anything (e.g. a 4K pair). Each has its own library tree under
      <code>/streams/&lt;key&gt;</code> and its own webhook URL.</p>
    <div id="connInstList"></div>
  </div>

  <div class="conn-grid">

    <div class="card">
      <div class="card-title">Sonarr</div>
      <div class="field"><label>URL</label><input id="sonarrUrl" placeholder="http://sonarr:8989"></div>
      <div class="field"><label>API Key</label>
        <div class="row"><input id="sonarrKey" type="password" placeholder="Settings → General → Security">
        <button onclick="testConn('sonarr')">Test</button></div>
      </div>
      <div class="status-bar" id="sonarrStat"></div>
      <button onclick="saveConn('sonarr')" style="margin-top:12px;width:100%">Save Sonarr</button>
    </div>

    <div class="card">
      <div class="card-title">Radarr</div>
      <div class="field"><label>URL</label><input id="radarrUrl" placeholder="http://radarr:7878"></div>
      <div class="field"><label>API Key</label>
        <div class="row"><input id="radarrKey" type="password" placeholder="Settings → General → Security">
        <button onclick="testConn('radarr')">Test</button></div>
      </div>
      <div class="status-bar" id="radarrStat"></div>
      <button onclick="saveConn('radarr')" style="margin-top:12px;width:100%">Save Radarr</button>
    </div>

    <div class="card">
      <div class="card-title">Tautulli</div>
      <div class="field"><label>URL</label><input id="tautulliUrl" placeholder="http://tautulli:8181"></div>
      <div class="field"><label>API Key</label>
        <div class="row"><input id="tautulliKey" type="password" placeholder="Settings → Web Interface → API key">
        <button onclick="testConn('tautulli')">Test</button></div>
      </div>
      <div class="status-bar" id="tautulliStat"></div>
      <button onclick="saveConn('tautulli')" style="margin-top:12px;width:100%">Save Tautulli</button>
    </div>

    <div class="card">
      <div class="card-title">Tautulli Webhook</div>
      <p style="color:var(--sub);font-size:13px;margin-bottom:12px">Add to Tautulli: Notification Agents -> Webhook -> Playback Start</p>
      <div id="whUrl" style="font-family:monospace;font-size:11px;color:var(--accent2);word-break:break-all;margin-bottom:10px"></div>
      <button class="ghost" onclick="copyWebhook('whUrl')">Copy URL</button>
    </div>

    <div class="card">
      <div class="card-title">Sonarr Webhook</div>
      <p style="color:var(--sub);font-size:13px;margin-bottom:12px">Add to Sonarr: Settings -> Connect -> Webhook. Triggers: <strong>On Import</strong>, <strong>On Upgrade</strong>, <strong>On Episode File Delete</strong></p>
      <div id="whSonarr" style="font-family:monospace;font-size:11px;color:var(--accent2);word-break:break-all;margin-bottom:10px"></div>
      <button class="ghost" onclick="copyWebhook('whSonarr')">Copy URL</button>
    </div>

    <div class="card">
      <div class="card-title">Radarr Webhook</div>
      <p style="color:var(--sub);font-size:13px;margin-bottom:12px">Add to Radarr: Settings -> Connect -> Webhook. Triggers: <strong>On Import</strong>, <strong>On Upgrade</strong>, <strong>On Movie File Delete</strong></p>
      <div id="whRadarr" style="font-family:monospace;font-size:11px;color:var(--accent2);word-break:break-all;margin-bottom:10px"></div>
      <button class="ghost" onclick="copyWebhook('whRadarr')">Copy URL</button>
    </div>

    <div class="card">
      <div class="card-title">Stream TTL</div>
      <div class="field"><label>Days before symlink expires</label>
        <div class="row"><input id="ttlInput" type="number" min="1" max="365" value="30">
        <button onclick="saveTTL()">Save</button></div>
      </div>
    </div>

  </div>
</section>

<!-- ══ DECYPHARR ══ -->
<section id="decypharr" class="tab">
  <div class="toolbar"><h1>Decypharr</h1><button class="ghost" onclick="loadDC()">Refresh</button></div>
  <div class="conn-grid">

    <div class="card">
      <div class="card-title">Connection</div>
      <div class="field"><label>URL</label><input id="dcUrl" placeholder="http://decypharr:8282"></div>
      <div class="field"><label>API Token <span style="font-size:11px;color:var(--sub)">(optional)</span></label>
        <input id="dcToken" type="password" placeholder="leave blank if auth disabled"></div>
      <div class="field"><label>Mount Path <span style="font-size:11px;color:var(--sub)">(optional — enables direct file access)</span></label>
        <input id="dcMount" placeholder="/mnt/decypharr/__all__"></div>
      <div style="display:flex;gap:8px;margin-top:4px">
        <button onclick="saveDC()" style="flex:1">Save</button>
        <button class="ghost" onclick="testDC()">Test Connection</button>
      </div>
      <div class="status-bar" id="dcStat"></div>
    </div>

    <div class="card">
      <div class="card-title">Torrent Index</div>
      <div id="dcIndexInfo" style="font-size:13px;color:var(--sub);margin-bottom:14px">Loading...</div>
      <div style="display:flex;gap:8px">
        <button onclick="dcReload()">Reload All</button>
        <button class="ghost" onclick="dcReloadNew()">+ Reload New</button>
      </div>
    </div>

    <div class="card">
      <div class="card-title">Rebuild Placeholders</div>
      <p style="color:var(--sub);font-size:13px;margin-bottom:14px">Re-write all .strm placeholder files. Use after changing the base URL or STRM root.</p>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="ghost" onclick="rebuildPH('sonarr')">↺ TV</button>
        <button class="ghost" onclick="rebuildPH('radarr')">↺ Movies</button>
        <button onclick="rebuildPH('all')">↺ Rebuild All</button>
      </div>
      <div id="rebuildStat" style="font-size:13px;margin-top:10px"></div>
    </div>

  </div>
</section>

</div><!-- /page -->

<!-- ══ WIZARD ══ -->
<div id="wizOverlay">
<div id="wizBox">
  <div class="wiz-top">
    <div class="wiz-top-row">
      <div><h2>⚡ Welcome to Debridarr</h2><p>Set up in a few steps — everything can be skipped and configured later.</p></div>
      <button class="wiz-close" onclick="closeWizard()">✕</button>
    </div>
    <div class="wiz-steps" id="wizSteps"></div>
  </div>
  <div class="wiz-body" id="wizBody"></div>
  <div class="wiz-foot">
    <button class="ghost" id="wizBack" onclick="wNav(-1)">← Back</button>
    <span class="wiz-hint" id="wizHint"></span>
    <button id="wizNext" onclick="wNav(1)">Next →</button>
  </div>
</div>
</div>

<div class="toast" id="toast"></div>

<script>
// ===========================================================================
// CORE UTILS
// ===========================================================================
async function api(url, opts) {
  try {
    const r = await fetch(url, opts || {});
    const t = await r.text();
    try { return JSON.parse(t); } catch { return {ok:false,error:t.slice(0,300)}; }
  } catch(e) { return {ok:false,error:String(e)}; }
}
function v(id) { const e=document.getElementById(id); return e?e.value.trim():''; }
function esc(s) {
  return String(s==null?'':s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
function pad2(n) { return String(n||0).padStart(2,'0'); }
function toast(msg,ms) {
  const el=document.getElementById('toast');
  el.textContent=msg; el.classList.add('show');
  clearTimeout(el._t); el._t=setTimeout(()=>el.classList.remove('show'),ms||2600);
}
function daysLeft(ts) {
  if(!ts) return '<span style="color:var(--sub)">--</span>';
  const d=Math.ceil((new Date(ts)-Date.now())/864e5);
  if(d<0) return '<span style="color:var(--red)">Expired</span>';
  if(d<3) return `<span style="color:var(--orange)">${d}d</span>`;
  return `<span style="color:var(--sub)">${d}d</span>`;
}
function seTag(s) {
  if(s.season==null) return '';
  return `<span style="color:var(--sub);font-size:11px"> S${pad2(s.season)}E${pad2(s.episode)}</span>`;
}

// ===========================================================================
// PAGINATION HELPER
// ===========================================================================
const PG = 20;
function paginate(items, page) {
  return items.slice((page-1)*PG, page*PG);
}
function pgBar(total, cur, onPage) {
  const pages = Math.ceil(total/PG);
  if(pages<=1) return '';
  let btns='';
  const add=(i,label,cls)=>{ btns+=`<button class="pg-btn${cls?' '+cls:''}" onclick="(${onPage})(${i})">${label||i}</button>`; };
  add(1,'<<',cur===1?'active':'');
  // Smart page list
  const show=new Set([1,pages,cur,cur-1,cur+1].filter(x=>x>=1&&x<=pages));
  let last=0;
  [...show].sort((a,b)=>a-b).forEach(p=>{
    if(last&&p-last>1) btns+=`<button class="pg-btn ellipsis" disabled>...</button>`;
    add(p,p,p===cur?'active':'');
    last=p;
  });
  add(pages,'>>',cur===pages?'active':'');
  return `<div class="pagination"><span class="info">${total} total . page ${cur}/${pages}</span>${btns}</div>`;
}

// ===========================================================================
// STREAMS
// ===========================================================================
let _streams=[], _moviePg=1, _tvPg=1;

async function loadStreams(status) {
  status=status||'active';
  document.getElementById('moviesWrap').innerHTML='<div class="tbl-wrap"><div class="empty"><span class="spin"></span> Loading...</div></div>';
  document.getElementById('tvWrap').innerHTML='<div class="tbl-wrap"><div class="empty"><span class="spin"></span> Loading...</div></div>';
  const d=await api('/api/streams?status='+status);
  _streams=d.streams||[];
  _moviePg=1; _tvPg=1;
  renderMovies(); renderTV();
}

function renderMovies() {
  const q=v('movieSearch').toLowerCase();
  const all=_streams.filter(s=>s.media_type==='movie'&&(!q||s.title.toLowerCase().includes(q)));
  document.getElementById('movieCount').textContent=all.length;
  document.getElementById('moviesWrap').innerHTML=streamSection(all,_moviePg,p=>{ _moviePg=p; renderMovies(); });
}
function renderTV() {
  const q=v('tvSearch').toLowerCase();
  const all=_streams.filter(s=>s.media_type==='episode'&&(!q||s.title.toLowerCase().includes(q)));
  document.getElementById('tvCount').textContent=all.length;
  document.getElementById('tvWrap').innerHTML=streamSection(all,_tvPg,p=>{ _tvPg=p; renderTV(); });
}

function streamSection(all, pg, onPage) {
  if(!all.length) return '<div class="tbl-wrap"><div class="empty"><div class="empty-icon"></div>No streams found</div></div>';
  const rows=paginate(all,pg);
  let t='<div class="tbl-wrap"><table>';
  t+='<tr><th>Title</th><th>Expires</th><th>Status</th><th style="width:80px"></th></tr>';
  rows.forEach(s=>{
    const isActive=s.status==='active';
    t+=`<tr>
      <td><strong>${esc(s.title)}</strong>${seTag(s)}</td>
      <td>${daysLeft(s.expires_at)}</td>
      <td><span class="badge ${isActive?'badge-green':'badge-gray'}">${esc(s.status)}</span></td>
      <td style="display:flex;gap:4px">
        ${isActive?`<button class="sm danger" onclick="expireStream('${s.id}')">Expire</button>`:''}
        <button class="sm icon" onclick="togglePin('${s.library_id}',this)" title="Pin (re-add every 30 days)">Pin</button>
      </td>
    </tr>`;
  });
  t+='</table>'+pgBar(all.length,pg,onPage)+'</div>';
  return t;
}

async function expireStream(id) {
  if(!confirm('Expire this stream? The file will be removed from AllDebrid.')) return;
  await api('/api/streams/'+id,{method:'DELETE'});
  toast('Stream expired');
  loadStreams('active');
}
async function runCleanup() {
  toast('Running cleanup...');
  await api('/api/streams/cleanup',{method:'POST'});
  toast('Cleanup complete');
  loadStreams('active');
}
async function togglePin(lid,btn) {
  const on=btn.dataset.pin==='1';
  if(on){await api('/api/pinned/'+lid,{method:'DELETE'}); btn.dataset.pin='0'; btn.style.opacity='.4'; toast('Unpinned');}
  else  {await api('/api/pinned/'+lid,{method:'POST'});   btn.dataset.pin='1'; btn.style.opacity='1';  toast('Pin Pinned -- will re-add every 30 days');}
}

// ===========================================================================
// LIBRARY
// ===========================================================================
let _library=[], _activeStreams={}, _sonarrSeries={}, _libMoviePg=1, _libTVPg=1;
let _expandedShows={}, _expandedSeasons={};
let _movieFilter='all', _tvFilter='all';

async function loadLibrary() {
  document.getElementById('libDesc').textContent='Loading...';
  const [ld, sd, sr] = await Promise.all([
    api('/api/library'),
    api('/api/streams?status=active'),
    api('/api/arr/sonarr/series'),
  ]);
  _library = ld.library||[];
  _activeStreams = {};
  (sd.streams||[]).forEach(s=>{ if(s.library_id) _activeStreams[s.library_id]=s; });
  _sonarrSeries = {};
  (sr.series||[]).forEach(s=>{ _sonarrSeries[s.id]=s; });
  _libMoviePg=1; _libTVPg=1;
  document.getElementById('libDesc').textContent=_library.length+' total items';
  setMovieFilter('all');
  setTVFilter('all');
}

// == Filter helpers ==========================================================
function onMovieSearch() {
  _libMoviePg=1;
  renderLibMovies();
}
function onTVSearch() {
  _libTVPg=1;
  // Auto-expand all shows when searching so results are visible
  const q = v('libTVSearch').toLowerCase();
  if(q) {
    _library.filter(i=>i.media_type==='episode' && i.title.toLowerCase().includes(q))
      .forEach(e=>{ _expandedShows[e.arr+'|'+e.arr_id]=true; });
  }
  renderLibTV();
}

function setMovieFilter(f) {
  _movieFilter=f; _libMoviePg=1;
  ['mfAll','mfLinked','mfPlaceholder'].forEach(id=>document.getElementById(id).classList.remove('on'));
  document.getElementById(f==='all'?'mfAll':f==='linked'?'mfLinked':'mfPlaceholder').classList.add('on');
  renderLibMovies();
}
function setTVFilter(f) {
  _tvFilter=f; _libTVPg=1;
  ['tfAll','tfLinked','tfPlaceholder'].forEach(id=>document.getElementById(id).classList.remove('on'));
  document.getElementById(f==='all'?'tfAll':f==='linked'?'tfLinked':'tfPlaceholder').classList.add('on');
  renderLibTV();
}

// == Progress bar HTML =======================================================
function linkBar(linked, total) {
  if(!total) return '';
  const pct = Math.round(linked/total*100);
  const cls = pct===0?'none':pct===100?'':'partial';
  return `<div class="link-bar">
    <div class="link-bar-track"><div class="link-bar-fill ${cls}" style="width:${pct}%"></div></div>
    <span class="link-bar-label">${linked}/${total}</span>
  </div>`;
}

// == Movies ==================================================================
function renderLibMovies() {
  const q = v('libMovieSearch').toLowerCase();
  let all = _library.filter(i=>i.media_type==='movie' && (!q||i.title.toLowerCase().includes(q)));
  if(_movieFilter==='linked')      all=all.filter(i=>!!_activeStreams[i.id]);
  if(_movieFilter==='placeholder') all=all.filter(i=>!_activeStreams[i.id]);
  document.getElementById('libMovieCount').textContent=all.length;
  if(!all.length){
    document.getElementById('libMoviesWrap').innerHTML='<div class="tbl-wrap"><div class="empty">No movies found</div></div>';
    return;
  }
  const rows=paginate(all,_libMoviePg);
  let t='<div class="tbl-wrap"><table>';
  t+='<tr><th>Title</th><th>Year</th><th>Status</th><th></th></tr>';
  rows.forEach(i=>{
    const linked=!!_activeStreams[i.id];
    const stream=_activeStreams[i.id];
    t+=`<tr>
      <td><strong>${esc(i.title)}</strong></td>
      <td style="color:var(--sub)">${i.year||'--'}</td>
      <td>
        <span class="badge ${linked?'badge-green':'badge-gray'}">${linked?'Linked':'Placeholder'}</span>
        ${linked&&stream?`<span class="ep-exp" style="margin-left:6px">exp ${daysLeft(stream.expires_at)}</span>`:''}
      </td>
      <td style="text-align:right"><button class="sm ghost" onclick="activateLib('${i.id}')">Play</button></td>
    </tr>`;
  });
  t+='</table>'+pgBar(all.length,_libMoviePg,p=>{_libMoviePg=p;renderLibMovies();})+'</div>';
  document.getElementById('libMoviesWrap').innerHTML=t;
}

// == TV =======================================================================
function renderLibTV() {
  const q = v('libTVSearch').toLowerCase();
  let eps = _library.filter(i=>i.media_type==='episode' && (!q||i.title.toLowerCase().includes(q)));

  // Apply linked/placeholder filter at show level
  // Group first, then filter shows based on whether they have any linked eps
  const showMap={};
  eps.forEach(e=>{
    const key=e.arr+'|'+e.arr_id;
    if(!showMap[key]) showMap[key]={title:e.title,year:e.year,arr:e.arr,arr_id:e.arr_id,seasons:{}};
    const sn=e.season||0;
    if(!showMap[key].seasons[sn]) showMap[key].seasons[sn]=[];
    showMap[key].seasons[sn].push(e);
  });

  let showList=Object.entries(showMap).sort((a,b)=>a[1].title.localeCompare(b[1].title));

  if(_tvFilter==='linked') {
    showList=showList.filter(([,s])=>Object.values(s.seasons).flat().some(e=>!!_activeStreams[e.id]));
  } else if(_tvFilter==='placeholder') {
    showList=showList.filter(([,s])=>Object.values(s.seasons).flat().some(e=>!_activeStreams[e.id]));
  }

  document.getElementById('libTVCount').textContent=showList.length+' shows';

  if(!showList.length){
    document.getElementById('libTVWrap').innerHTML='<div class="tbl-wrap"><div class="empty">No shows found</div></div>';
    return;
  }

  const paged=paginate(showList,_libTVPg);
  let t='<div>';

  paged.forEach(([key,show])=>{
    const allEps=Object.values(show.seasons).flat();
    const linkedCount=allEps.filter(e=>!!_activeStreams[e.id]).length;
    const totalCount=allEps.length;
    const seasons=Object.keys(show.seasons).map(Number).sort((a,b)=>a-b);
    const isOpen=!!_expandedShows[key];
    const sonarr=_sonarrSeries[show.arr_id];
    const sonarrSeasons=sonarr&&sonarr.seasons||{};
    const sonarrTotal=Object.values(sonarrSeasons).reduce((a,b)=>a+b,0);

    t+=`<div class="lib-wrap">
      <div class="show-row" onclick="toggleShow('${key}')">
        <span class="show-chevron ${isOpen?'open':''}">&#9654;</span>
        <span class="show-title">${esc(show.title)}</span>
        <div class="show-meta">
          ${show.year?`<span>${show.year}</span>`:''}
          <span>${seasons.length} season${seasons.length!==1?'s':''}</span>
          ${sonarrTotal?`<span class="sonarr-total">${sonarrTotal} total</span>`:''}
          <span class="badge badge-blue">${esc(show.arr)}</span>
        </div>
        ${linkBar(linkedCount,totalCount)}
      </div>`;

    if(isOpen) {
      seasons.forEach(sn=>{
        const snKey=key+'|s'+sn;
        const snEps=show.seasons[sn].sort((a,b)=>a.episode-b.episode);
        const snLinked=snEps.filter(e=>!!_activeStreams[e.id]).length;
        const snOpen=!!_expandedSeasons[snKey];
        const sonarrEpCount=sonarrSeasons[String(sn)]||null;

        t+=`<div class="season-block">
          <div class="season-row" onclick="event.stopPropagation();toggleSeason('${snKey}')">
            <span class="show-chevron ${snOpen?'open':''}">&#9654;</span>
            <span class="season-label">Season ${sn}</span>
            <span style="font-size:12px;color:var(--sub);margin-left:auto">
              ${snEps.length} in lib${sonarrEpCount?` / ${sonarrEpCount} in Sonarr`:''}
            </span>
            ${linkBar(snLinked,snEps.length)}
          </div>`;

        if(snOpen) {
          // If we have Sonarr data, show all expected episodes including missing ones
          const epNums=sonarrEpCount
            ? Array.from({length:sonarrEpCount},(_,i)=>i+1)
            : snEps.map(e=>e.episode);
          const epMap={};
          snEps.forEach(e=>epMap[e.episode]=e);

          t+='<table class="ep-table">';
          epNums.forEach(epNum=>{
            const e=epMap[epNum];
            if(e) {
              const linked=!!_activeStreams[e.id];
              const stream=_activeStreams[e.id];
              t+=`<tr>
                <td style="width:70px"><span class="ep-tag">S${pad2(sn)}E${pad2(epNum)}</span></td>
                <td>
                  <span class="ep-status">
                    <span class="badge ${linked?'badge-green':'badge-gray'}">${linked?'Linked':'Placeholder'}</span>
                    ${linked&&stream?`<span class="ep-exp">exp ${daysLeft(stream.expires_at)}</span>`:''}
                  </span>
                </td>
                <td style="text-align:right;padding-right:16px">
                  <button class="sm ghost" onclick="event.stopPropagation();activateLib('${e.id}')">Play</button>
                </td>
              </tr>`;
            } else {
              t+=`<tr>
                <td style="width:70px"><span class="ep-tag" style="opacity:.4">S${pad2(sn)}E${pad2(epNum)}</span></td>
                <td><span class="ep-missing">Not in library</span></td>
                <td></td>
              </tr>`;
            }
          });
          t+='</table>';
        }
        t+='</div>'; // season-block
      });
    }
    t+='</div>'; // lib-wrap
  });

  t+=pgBar(showList.length,_libTVPg,p=>{_libTVPg=p;renderLibTV();});
  t+='</div>';
  document.getElementById('libTVWrap').innerHTML=t;
}

function toggleShow(key){
  _expandedShows[key]=!_expandedShows[key];
  renderLibTV();
}
function toggleSeason(key){
  _expandedSeasons[key]=!_expandedSeasons[key];
  renderLibTV();
}

async function activateLib(id) {
  toast('Activating...');
  const d=await api('/api/library/'+id+'/activate',{method:'POST'});
  if(d.ok) toast('OK Stream activated'); else toast('X '+(d.error||'Failed'));
}
async function triggerSync() {
  const btn=document.getElementById('syncBtn');
  btn.disabled=true; btn.textContent='Syncing...';
  await api('/api/library/sync',{method:'POST'});
  toast('Library sync started');
  setTimeout(()=>{btn.disabled=false;btn.textContent='Sync All';loadLibrary();},3000);
}
async function runSpotCheck() {
  const btn=document.getElementById('spotBtn');
  btn.disabled=true; btn.textContent=' Running...';
  await api('/api/spot-check',{method:'POST'});
  const poll=setInterval(async()=>{
    const s=await api('/api/spot-check/status');
    if(!s.running){clearInterval(poll);btn.disabled=false;btn.textContent=' Spot Check';toast('Spot check complete');loadLibrary();}
  },3000);
}
let _nfOpen=false;
async function toggleNF() {
  _nfOpen=!_nfOpen;
  const sec=document.getElementById('nfSection');
  sec.style.display=_nfOpen?'block':'none';
  if(!_nfOpen) return;
  const d=await api('/api/not-found');
  const rows=d.not_found||[];
  if(!rows.length){document.getElementById('nfList').innerHTML='<div class="empty">No not-found items</div>';return;}
  let t='<table><tr><th>Title</th><th>Type</th><th>S/E</th><th>Checked</th><th></th></tr>';
  rows.forEach(r=>{
    t+=`<tr>
      <td><strong>${esc(r.title)}</strong></td>
      <td>${esc(r.media_type)}</td>
      <td>${r.season!=null?'S'+pad2(r.season)+'E'+pad2(r.episode):'--'}</td>
      <td style="font-size:11px;color:var(--sub)">${(r.checked_at||'').slice(0,10)}</td>
      <td><button class="sm ghost" onclick="clearNF('${r.id}')">R Re-add</button></td>
    </tr>`;
  });
  document.getElementById('nfList').innerHTML=t+'</table>';
}
async function clearNF(id){await api('/api/not-found/'+id,{method:'DELETE'});_nfOpen=false;toggleNF();}
async function clearAllNF(){if(!confirm('Clear all not-found items?'))return;await api('/api/not-found',{method:'DELETE'});toast('Cleared');_nfOpen=false;toggleNF();}

// ===========================================================================
// CONNECTIONS
// ===========================================================================
async function loadConnections() {
  const d=await api('/api/settings');
  const s=d.settings||{};
  ['sonarr','radarr','tautulli'].forEach(a=>{
    const el=document.getElementById(a+'Url');
    if(el) el.value=s[a+'_url']||'';
  });
  const ttl=document.getElementById('ttlInput');
  if(ttl) ttl.value=s.symlink_ttl_days||30;
  const wh=document.getElementById('whUrl');
  if(wh) wh.textContent=location.origin+'/webhook/tautulli';
  const whs=document.getElementById('whSonarr');
  if(whs) whs.textContent=location.origin+'/webhook/sonarr';
  const whr=document.getElementById('whRadarr');
  if(whr) whr.textContent=location.origin+'/webhook/radarr';
  await cRenderInstances(true);
}

// ── Connections-tab instance management (shares the wizard's model + API) ─────
async function cRenderInstances(reload){
  const host=document.getElementById('connInstList');
  if(!host) return;
  if(reload || !_wInstLoaded) await wLoadInstances(true);
  if(!_wInstances.length){ host.innerHTML='<p style="color:var(--sub);font-size:13px">No instances yet.</p>'; return; }
  host.innerHTML=_wInstances.map((it,idx)=>{
    const ph=DEFAULT_PORTS[it.type]||'8989';
    const isDefault=it._key==='sonarr'||it._key==='radarr';
    const wh=it._key?`${location.origin}/webhook/${it.type}/${it._key}`:'(save first)';
    return `
    <div class="inst-card" style="border:1px solid var(--border);border-radius:10px;padding:12px;margin-bottom:10px">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <span class="pill" style="font-size:10px;background:var(--accent);color:#fff;padding:2px 7px;border-radius:6px">${it.type}</span>
        <input style="flex:1;font-weight:600" value="${esc(it.name||'')}"
               oninput="_wInstances[${idx}].name=this.value" placeholder="Instance name (anything)">
        ${isDefault?'':`<button class="ghost sm" title="Remove" onclick="cDeleteInstance(${idx})">✕</button>`}
      </div>
      <div class="field" style="margin-bottom:6px"><label>URL</label>
        <input value="${esc(it.url||'')}" placeholder="http://${it.type}:${ph}"
               oninput="_wInstances[${idx}].url=this.value"></div>
      <div class="field" style="margin-bottom:6px"><label>API Key</label>
        <div class="row">
          <input type="password" placeholder="${it.configured?'•••••••• (saved — blank keeps it)':'Settings → General → Security'}"
                 oninput="_wInstances[${idx}].api_key=this.value">
          <button class="sm" onclick="cTestInstance(${idx})">Test</button>
        </div></div>
      <div class="status-bar" id="cInstRes${idx}"></div>
      <div style="display:flex;gap:8px;align-items:center;margin-top:8px">
        <button class="sm" onclick="cSaveInstance(${idx})">Save</button>
        <span style="flex:1;font-family:monospace;font-size:10px;color:var(--accent2);word-break:break-all">${wh}</span>
        ${it._key?`<button class="ghost sm" onclick="navigator.clipboard.writeText('${wh}').then(()=>toast('Copied!'))">Copy webhook</button>`:''}
      </div>
    </div>`;
  }).join('');
}
function cAddInstance(type){ wAddInstance(type); cRenderInstances(false); }
async function cSaveInstance(idx){
  try{ await wPersistInstance(idx); toast('Saved'); await cRenderInstances(true); }
  catch(e){ toast('Save failed'); }
}
async function cTestInstance(idx){
  const el=document.getElementById('cInstRes'+idx), it=_wInstances[idx];
  if(!it.url){el.innerHTML='<span style="color:var(--red)">Enter a URL first</span>';return;}
  el.innerHTML='<span class="spin"></span> Saving &amp; testing...';
  try{
    const key=await wPersistInstance(idx);
    const d=await api('/api/instances/'+encodeURIComponent(key)+'/status');
    el.innerHTML=d.connected
      ? '<span class="dot dot-green"></span> Connected'+(d.status?.version?' — v'+d.status.version:'')
      : '<span style="color:var(--red)">✕ Could not connect</span>';
    it.configured=true;
    await cRenderInstances(true);
  }catch(e){ el.innerHTML='<span style="color:var(--red)">✕ '+esc(e.message||'Failed')+'</span>'; }
}
async function cDeleteInstance(idx){
  const it=_wInstances[idx];
  if(!it._key){ _wInstances.splice(idx,1); cRenderInstances(false); return; }
  if(!confirm(`Remove "${it.name}"? Its library entries and /streams/${it._key} tree will be deleted.`)) return;
  await api('/api/instances/'+encodeURIComponent(it._key)+'?purge=true',{method:'DELETE'});
  toast('Removed '+it.name);
  await cRenderInstances(true);
}
async function saveConn(arr) {
  const url=v(arr+'Url'), key=v(arr+'Key');
  if(!url){toast('Enter a URL');return;}
  const s={[arr+'_url']:url};
  if(key) s[arr+'_api_key']=key;
  await api('/api/settings',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({settings:s})});
  toast(arr.charAt(0).toUpperCase()+arr.slice(1)+' saved');
}
async function testConn(arr) {
  const url=v(arr+'Url'), key=v(arr==='tautulli'?'tautulliKey':arr+'Key');
  const el=document.getElementById(arr+'Stat');
  if(!url||!key){el.innerHTML='<span style="color:var(--red)">Enter URL and key first</span>';return;}
  el.innerHTML='<span class="spin"></span> Testing...';
  await saveConn(arr);
  const d=await api('/api/arr/'+arr+'/status');
  el.innerHTML=d.connected
    ?'<span class="dot dot-green"></span> Connected'+(d.status?.version?' -- v'+d.status.version:'')
    :'<span style="color:var(--red)">X Could not connect</span>';
}
async function saveTTL(){
  const days=v('ttlInput');
  await api('/api/settings',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({settings:{symlink_ttl_days:days}})});
  toast('TTL saved -- '+days+' days');
}
function copyWebhook(id){navigator.clipboard.writeText(document.getElementById(id||'whUrl').textContent).then(()=>toast('Copied!'));}

// ===========================================================================
// DECYPHARR
// ===========================================================================
async function loadDC() {
  const d=await api('/api/decypharr/status');
  if(document.getElementById('dcUrl')) document.getElementById('dcUrl').value=d.url||'';
  if(document.getElementById('dcMount')) document.getElementById('dcMount').value=d.mount||'';
  const el=document.getElementById('dcIndexInfo');
  if(el) el.innerHTML=d.connected
    ?`<span class="dot dot-green"></span> Connected -- <strong>${d.torrents}</strong> torrent(s) in index`
    :'<span class="dot dot-gray"></span> Not connected -- configure URL above';
}
async function saveDC() {
  const s={decypharr_mount:v('dcMount')};
  const u=v('dcUrl'),t=v('dcToken');
  if(u) s.decypharr_url=u; if(t) s.decypharr_api_token=t;
  await api('/api/settings',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({settings:s})});
  toast('Decypharr settings saved');
  loadDC();
}
async function testDC() {
  const el=document.getElementById('dcStat');
  el.innerHTML='<span class="spin"></span> Testing...';
  await saveDC();
  const d=await api('/api/decypharr/test');
  el.innerHTML=d.ok
    ?`<span class="dot dot-green"></span> Connected -- ${d.torrents} torrent(s)`
    :`<span style="color:var(--red)">X ${esc(d.error||'Connection failed')}</span>`;
}
async function dcReload(){toast('Reloading all torrents...');const d=await api('/api/decypharr/reload',{method:'POST'});toast('Reloaded: '+d.count+' torrents');loadDC();}
async function dcReloadNew(){const d=await api('/api/decypharr/reload/new',{method:'POST'});toast('+'+d.count+' new torrents');loadDC();}
async function rebuildPH(arr){
  document.getElementById('rebuildStat').textContent='Rebuilding...';
  const d=await api('/api/library/rebuild-placeholders?arr='+arr,{method:'POST'});
  document.getElementById('rebuildStat').textContent=d.ok?'OK Rebuilt '+d.count+' placeholder(s)':'X '+(d.error||'Failed');
}

// ===========================================================================
// NAVIGATION
// ===========================================================================
function showTab(btn) {
  const id=btn.dataset.tab;
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  document.querySelectorAll('.nav-btn[data-tab]').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  if(id==='streams')     loadStreams('active');
  if(id==='library')     loadLibrary();
  if(id==='connections') loadConnections();
  if(id==='decypharr')   loadDC();
}

// ===========================================================================
// WIZARD
// ===========================================================================
let _wst={}, _wStep=1;
const WSTEPS=[null,
  {
    label:'1 . Instances',
    render:()=>wInstancesHtml(),
    save:async()=>{ await wSaveAllInstances(); }
  },
  {
    label:'2 . Decypharr',
    render:()=>`
      <h3 style="margin-bottom:8px">Connect Decypharr</h3>
      <p style="color:var(--sub);font-size:13px;margin-bottom:16px">Decypharr acts as a qBittorrent client for Sonarr/Radarr, downloading via AllDebrid. Can be skipped.</p>
      <div class="field"><label>Decypharr URL</label><input id="wDUrl" placeholder="http://decypharr:8282" value="${esc(_wst.decypharr_url||'')}"></div>
      <div class="field"><label>API Token <span style="font-size:11px;color:var(--sub)">(optional)</span></label><input id="wDTok" type="password" placeholder="leave blank if auth disabled"></div>
      <div class="field"><label>Mount Path <span style="font-size:11px;color:var(--sub)">(optional)</span></label><input id="wDMnt" placeholder="/mnt/decypharr/__all__" value="${esc(_wst.decypharr_mount||'')}"></div>
      <div style="display:flex;gap:8px;margin-top:4px">
        <button onclick="wSaveDC()">Save &amp; Test</button>
      </div>
      <div class="status-bar" id="wDRes"></div>`,
    save:async()=>{await wSaveDC();}
  },
  {
    label:'3 . Tautulli',
    render:()=>`
      <h3 style="margin-bottom:8px">Connect Tautulli</h3>
      <p style="color:var(--sub);font-size:13px;margin-bottom:16px">Tautulli notifies Debridarr when you press Play in Plex so it can activate the stream.</p>
      <div class="field"><label>Tautulli URL</label><input id="wTUrl" placeholder="http://tautulli:8181" value="${esc(_wst.tautulli_url||'')}"></div>
      <div class="field"><label>API Key</label>
        <div class="row"><input id="wTKey" type="password" placeholder="Settings -> Web Interface -> API key"><button onclick="wTest('tautulli','wTUrl','wTKey','wTRes')">Test</button></div>
      </div>
      <div class="status-bar" id="wTRes"></div>
      <div style="border-top:1px solid var(--border);margin:18px 0 12px"></div>
      <p style="color:var(--sub);font-size:12px;margin-bottom:8px">Add this URL as a Tautulli Webhook Notification Agent (Playback Start):</p>
      <div style="display:flex;gap:8px;align-items:center">
        <span style="font-family:monospace;font-size:11px;color:var(--accent2);flex:1;word-break:break-all">${location.origin}/webhook/tautulli</span>
        <button class="sm ghost" onclick="navigator.clipboard.writeText(location.origin+'/webhook/tautulli').then(()=>toast('Copied!'))">Copy</button>
      </div>`,
    save:async()=>{const u=v('wTUrl'),k=v('wTKey');if(u&&k) await patchSettings({tautulli_url:u,tautulli_api_key:k});}
  }
];
const WTOTAL=WSTEPS.length-1;

async function patchSettings(s){return api('/api/settings',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({settings:s})});}

// ── Instances (multi Sonarr/Radarr) ─────────────────────────────────────────
let _wInstances=[];      // working copy edited in the wizard
let _wInstLoaded=false;

const DEFAULT_PORTS={sonarr:'8989',radarr:'7878'};

async function wLoadInstances(force){
  if(_wInstLoaded && !force) return;
  const d=await api('/api/instances');
  _wInstances=(d.instances||[]).map(i=>({...i, _key:i.key||null}));
  _wInstLoaded=true;
}

function wInstancesHtml(){
  // Render asynchronously: kick off a load then paint into the container.
  setTimeout(async()=>{
    await wLoadInstances();
    wRenderInstances();
  },0);
  return `
    <h3 style="margin-bottom:8px">Sonarr &amp; Radarr instances</h3>
    <p style="color:var(--sub);font-size:13px;margin-bottom:14px">
      Add as many instances as you like and name them anything — e.g. a 4K
      Sonarr alongside your 1080p one. Each gets its own library tree under
      <code>/streams/&lt;key&gt;</code>. Can be skipped and configured later.</p>
    <div id="wInstList"></div>
    <div style="display:flex;gap:8px;margin-top:10px">
      <button class="ghost sm" onclick="wAddInstance('sonarr')">+ Add Sonarr</button>
      <button class="ghost sm" onclick="wAddInstance('radarr')">+ Add Radarr</button>
    </div>`;
}

function wAddInstance(type){
  const base=type==='sonarr'?'Sonarr':'Radarr';
  let n=2, name=base;
  const names=new Set(_wInstances.map(i=>i.name));
  while(names.has(name)) name=`${base} ${n++}`;
  _wInstances.push({key:null,_key:null,name,type,url:'',api_key:'',enabled:true,configured:false,_new:true});
  wRenderInstances();
}

function wRemoveInstance(idx){
  const it=_wInstances[idx];
  if(it && it._key && (it._key==='sonarr'||it._key==='radarr')){
    toast('The default Sonarr/Radarr cannot be removed — clear its URL to disable.');
    return;
  }
  _wInstances.splice(idx,1);
  wRenderInstances();
}

function wRenderInstances(){
  const host=document.getElementById('wInstList');
  if(!host) return;
  host.innerHTML=_wInstances.map((it,idx)=>{
    const ph=DEFAULT_PORTS[it.type]||'8989';
    const isDefault=it._key==='sonarr'||it._key==='radarr';
    const badge=it.type==='sonarr'?'TV':'Movies';
    return `
    <div class="inst-card" style="border:1px solid var(--border);border-radius:10px;padding:12px;margin-bottom:10px">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <span class="pill" style="font-size:10px;background:var(--accent);color:#fff;padding:2px 7px;border-radius:6px">${it.type}</span>
        <span style="font-size:11px;color:var(--sub)">${badge}</span>
        <input style="flex:1;font-weight:600" value="${esc(it.name||'')}"
               oninput="_wInstances[${idx}].name=this.value"
               placeholder="Instance name (anything)">
        ${isDefault?'':`<button class="ghost sm" title="Remove" onclick="wRemoveInstance(${idx})">✕</button>`}
      </div>
      <div class="field" style="margin-bottom:6px"><label>URL</label>
        <input value="${esc(it.url||'')}" placeholder="http://${it.type}:${ph}"
               oninput="_wInstances[${idx}].url=this.value"></div>
      <div class="field" style="margin-bottom:6px"><label>API Key</label>
        <div class="row">
          <input type="password" placeholder="${it.configured?'•••••••• (saved — leave blank to keep)':'Settings → General → Security'}"
                 oninput="_wInstances[${idx}].api_key=this.value">
          <button class="sm" onclick="wTestInstance(${idx})">Test</button>
        </div></div>
      <div class="status-bar" id="wInstRes${idx}"></div>
    </div>`;
  }).join('');
}

// Persist one instance (create or update). Returns the saved key.
async function wPersistInstance(idx){
  const it=_wInstances[idx];
  const payload={name:it.name,type:it.type,url:it.url||'',api_key:it.api_key||'',enabled:it.enabled!==false};
  if(it._key){
    // For updates, an empty api_key means "keep existing" — only send if changed.
    if(!it.api_key) delete payload.api_key;
    const d=await api('/api/instances/'+encodeURIComponent(it._key),
      {method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    return it._key;
  } else {
    const d=await api('/api/instances',
      {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    it._key=d.key; it.key=d.key; it._new=false;
    return d.key;
  }
}

async function wTestInstance(idx){
  const el=document.getElementById('wInstRes'+idx);
  const it=_wInstances[idx];
  if(!it.url){el.innerHTML='<span style="color:var(--red)">Enter a URL first</span>';return;}
  el.innerHTML='<span class="spin"></span> Saving &amp; testing...';
  try{
    const key=await wPersistInstance(idx);
    const d=await api('/api/instances/'+encodeURIComponent(key)+'/status');
    el.innerHTML=d.connected
      ? '<span class="dot dot-green"></span> Connected'+(d.status?.version?' — v'+d.status.version:'')
      : '<span style="color:var(--red)">✕ Could not connect</span>';
    it.configured=true;
  }catch(e){
    el.innerHTML='<span style="color:var(--red)">✕ '+esc(e.message||'Failed')+'</span>';
  }
}

async function wSaveAllInstances(){
  for(let i=0;i<_wInstances.length;i++){
    const it=_wInstances[i];
    // Only persist rows that have a URL or are brand-new named instances.
    if(it.url || it._new || it._key) {
      try{ await wPersistInstance(i); }catch(e){ /* skip failures, keep wizard moving */ }
    }
  }
}

async function wSaveDC(){
  const s={decypharr_mount:v('wDMnt')};
  const u=v('wDUrl'),t=v('wDTok');
  if(u) s.decypharr_url=u; if(t) s.decypharr_api_token=t;
  await patchSettings(s);
  const el=document.getElementById('wDRes');
  if(el){
    el.innerHTML='<span class="spin"></span> Testing...';
    const d=await api('/api/decypharr/test');
    el.innerHTML=d.ok
      ?`<span class="dot dot-green"></span> Connected -- ${d.torrents} torrent(s)`
      :`<span style="color:var(--red)">X ${esc(d.error||'Failed')}</span>`;
  }
}
async function wTest(arr,urlId,keyId,resId){
  const url=v(urlId),key=v(keyId),el=document.getElementById(resId);
  if(!url||!key){el.innerHTML='<span style="color:var(--red)">Enter URL and key first</span>';return;}
  el.innerHTML='<span class="spin"></span> Testing...';
  await patchSettings({[arr+'_url']:url,[arr+'_api_key']:key});
  const d=await api('/api/arr/'+arr+'/status');
  el.innerHTML=d.connected
    ?'<span class="dot dot-green"></span> Connected'+(d.status?.version?' -- v'+d.status.version:'')
    :'<span style="color:var(--red)">X Could not connect</span>';
}

function wizRender(){
  const s=WSTEPS[_wStep];
  // Steps pills
  let pills='';
  for(let i=1;i<=WTOTAL;i++)
    pills+=`<div class="wiz-step${i<_wStep?' done':i===_wStep?' active':''}">${WSTEPS[i].label}</div>`;
  document.getElementById('wizSteps').innerHTML=pills;
  document.getElementById('wizBody').innerHTML=s.render();
  document.getElementById('wizBack').style.visibility=_wStep>1?'visible':'hidden';
  document.getElementById('wizNext').textContent=_wStep===WTOTAL?'Finish':'Next ->';
  document.getElementById('wizHint').innerHTML=`<button class="ghost sm" onclick="wSkip()">Skip this step</button>`;
}
function openWizard(){document.getElementById('wizOverlay').classList.add('open');wizRender();}
function closeWizard(){document.getElementById('wizOverlay').classList.remove('open');}
function wSkip(){if(_wStep>=WTOTAL){closeWizard();return;}_wStep++;wizRender();}
async function wNav(dir){
  if(dir>0&&WSTEPS[_wStep].save) await WSTEPS[_wStep].save();
  if(dir>0&&_wStep>=WTOTAL){closeWizard();toast('Setup complete -- syncing library...');api('/api/library/sync',{method:'POST'});return;}
  _wStep=Math.max(1,Math.min(WTOTAL,_wStep+dir));
  wizRender();
}

// ===========================================================================
// INIT
// ===========================================================================
(async()=>{
  const st=await api('/api/setup/status');
  _wst=st||{};
  if(!st||!st.setup_complete){
    openWizard();
  } else {
    loadStreams('active');
  }
})();
</script>
</body>
</html>

"""

