"""
Decypharr client — replaces AllDebrid FUSE mount and alldebrid.py.

Uses Decypharr's Browse API to:
  - List all torrents via GET /api/browse/__all__
  - List files in a torrent via GET /api/browse/__all__/{torrent}
  - Get stream URL via GET /api/browse/download/{torrent}/{file}

Also maintains the same in-memory index as fuse_mount.py so _find_in_fuse
and all index lookups work without changes to the rest of the codebase.
"""

import logging
import re
import threading
import json
from pathlib import Path
from typing import Optional

import httpx

log = logging.getLogger("debridarr.decypharr")

# ── Index structures (same as fuse_mount.py) ──────────────────────────────────
_torrents:       dict[str, dict] = {}   # torrent_name → {files: {fname: {n,s,l}}}
_torrents_lock   = threading.Lock()
_se_tag_index:   dict[str, list] = {}
_stem_index:     dict[str, list] = {}
_title_se_index: dict[str, list] = {}
_title_index:    dict[str, list] = {}
_known_ids:      set              = set()
_known_ids_lock  = threading.Lock()

_INDEX_FILE = Path("/data/decypharr_index.json")

_re_d = re.compile(r"[^a-z0-9\s]")
_se_pat = re.compile(r"[Ss](\d{1,2})[Ee](\d{1,2})")


def _stem_norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", s.lower())


def _title_words(s: str) -> list:
    s = s.lower()
    s = re.sub(r"[\u2019\u2018'`]", "", s)
    for n in (6, 5, 4, 3, 2):
        pat = r"\b" + r"\.".join([r"([a-z])"] * n) + r"\."
        rep = "".join([rf"\{i}" for i in range(1, n + 1)])
        s = re.sub(pat, rep, s)
    s = re.sub(r"[^a-z0-9\s]", " ", s)
    return [w for w in s.split() if len(w) > 2 and (not w.isdigit() or len(w) == 4)]


def _build_indexes():
    """Rebuild all indexes from _torrents. Must be called under _torrents_lock."""
    global _se_tag_index, _stem_index, _title_se_index, _title_index
    se:  dict = {}
    st:  dict = {}
    tse: dict = {}
    ti:  dict = {}
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}

    for torrent_name, tdata in _torrents.items():
        t_words = _title_words(torrent_name)
        for fname in tdata.get("files", {}):
            if not any(fname.lower().endswith(e) for e in video_exts):
                continue
            entry = (torrent_name, fname)
            m = _se_pat.search(fname)
            tag = None
            if m:
                tag = f"S{int(m.group(1)):02d}E{int(m.group(2)):02d}"
                se.setdefault(tag, []).append(entry)
            stem = _stem_norm(fname.rsplit(".", 1)[0] if "." in fname else fname)
            if stem:
                st.setdefault(stem, []).append(entry)
            if tag:
                for w in t_words:
                    tse.setdefault(f"{w}|{tag}", []).append(entry)
            for w in t_words:
                ti.setdefault(w, []).append(entry)

    _se_tag_index   = se
    _stem_index     = st
    _title_se_index = tse
    _title_index    = ti


def register_torrent(name: str, files: list):
    with _torrents_lock:
        _torrents[name] = {"files": {f["n"]: f for f in files}}
        _build_indexes()


def clear_torrents():
    global _se_tag_index, _stem_index, _title_se_index, _title_index
    with _torrents_lock:
        _torrents.clear()
        _se_tag_index.clear()
        _stem_index.clear()
        _title_se_index.clear()
        _title_index.clear()


def list_torrents() -> list:
    with _torrents_lock:
        return list(_torrents.keys())


def list_files(torrent_name: str) -> list:
    with _torrents_lock:
        return list(_torrents.get(torrent_name, {}).get("files", {}).keys())


def get_torrent_file(torrent_name: str, filename: str) -> Optional[dict]:
    with _torrents_lock:
        t = _torrents.get(torrent_name)
        return t["files"].get(filename) if t else None


def lookup_by_se_tag(tag: str) -> list:
    with _torrents_lock:
        return list(_se_tag_index.get(tag.upper(), []))


def lookup_by_stem(stem: str) -> list:
    with _torrents_lock:
        return list(_stem_index.get(_stem_norm(stem), []))


def lookup_by_title_se(word: str, tag: str) -> list:
    key = f"{word.lower()}|{tag.upper()}"
    with _torrents_lock:
        return list(_title_se_index.get(key, []))


def lookup_by_title_word(word: str) -> list:
    with _torrents_lock:
        return list(_title_index.get(word.lower(), []))


# ── Persistence ────────────────────────────────────────────────────────────────

def _save_index():
    try:
        _INDEX_FILE.parent.mkdir(parents=True, exist_ok=True)
        with _torrents_lock:
            data = {
                "known_ids": list(_known_ids),
                "torrents": {
                    name: {"files": {
                        fname: {"n": fname, "s": f.get("s", 0), "l": f.get("l", "")}
                        for fname, f in tdata.get("files", {}).items()
                    }}
                    for name, tdata in _torrents.items()
                }
            }
        _INDEX_FILE.write_text(json.dumps(data))
        log.debug("Index saved: %d torrents", len(data["torrents"]))
    except Exception as e:
        log.warning("Index save failed: %s", e)


def _load_index() -> int:
    global _known_ids
    if not _INDEX_FILE.exists():
        return 0
    try:
        data = json.loads(_INDEX_FILE.read_text())
        clear_torrents()
        with _torrents_lock:
            for name, tdata in data.get("torrents", {}).items():
                _torrents[name] = {"files": tdata.get("files", {})}
            _build_indexes()
        with _known_ids_lock:
            _known_ids = set(data.get("known_ids", []))
        n = len(data.get("torrents", {}))
        log.info("Decypharr index loaded: %d torrents, %d known IDs", n, len(_known_ids))
        return n
    except Exception as e:
        log.warning("Index load failed: %s", e)
        return 0


# ── HTTP client ────────────────────────────────────────────────────────────────

class DecypharrClient:
    """Talks to Decypharr's Browse API to list and stream torrents."""

    def __init__(self, base_url: str, api_token: str = "", mount_path: str = ""):
        self.base_url   = base_url.rstrip("/")
        self.api_token  = api_token
        self.mount_path = mount_path.rstrip("/") if mount_path else ""
        self._client    = httpx.Client(timeout=30, follow_redirects=True)

    def _headers(self) -> dict:
        h = {}
        if self.api_token:
            h["Authorization"] = f"Bearer {self.api_token}"
        return h

    def list_all_torrents(self) -> list[dict]:
        """GET /api/browse/__all__ — returns list of {name, size, ...}"""
        try:
            r = self._client.get(f"{self.base_url}/api/browse/__all__",
                                 headers=self._headers())
            r.raise_for_status()
            return r.json() if isinstance(r.json(), list) else r.json().get("items", [])
        except Exception as e:
            log.error("list_all_torrents failed: %s", e)
            return []

    def list_torrent_files(self, torrent_name: str) -> list[dict]:
        """GET /api/browse/__all__/{torrent} — returns list of {name, size, ...}"""
        try:
            import urllib.parse
            encoded = urllib.parse.quote(torrent_name, safe="")
            r = self._client.get(
                f"{self.base_url}/api/browse/__all__/{encoded}",
                headers=self._headers())
            r.raise_for_status()
            data = r.json()
            return data if isinstance(data, list) else data.get("items", [])
        except Exception as e:
            log.error("list_torrent_files(%r) failed: %s", torrent_name, e)
            return []

    def get_stream_url(self, torrent_name: str, filename: str) -> str:
        """Returns the best available URL/path for this file.
        Prefers direct mount path (no HTTP overhead) over Browse API download URL.
        """
        if self.mount_path:
            p = Path(self.mount_path) / torrent_name / filename
            if p.exists():
                return str(p)
        import urllib.parse
        t = urllib.parse.quote(torrent_name, safe="")
        f = urllib.parse.quote(filename, safe="")
        return f"{self.base_url}/api/browse/download/{t}/{f}"

    def get_file_path(self, torrent_name: str, filename: str) -> Optional[Path]:
        """Return direct filesystem path if mount is available."""
        if self.mount_path:
            p = Path(self.mount_path) / torrent_name / filename
            if p.exists():
                return p
        return None

    def delete_torrent(self, torrent_name: str) -> bool:
        """DELETE /api/torrents — remove torrent from Decypharr/AllDebrid.
        Accepts torrent name; Decypharr matches by name or hash.
        """
        try:
            import urllib.parse
            # Try by name first (Decypharr accepts category/hash/name params)
            r = self._client.delete(
                f"{self.base_url}/api/torrents",
                params={"name": torrent_name},
                headers=self._headers())
            if r.status_code in (200, 204):
                log.info("Decypharr: deleted torrent %r", torrent_name)
                # Remove from local index
                with _torrents_lock:
                    _torrents.pop(torrent_name, None)
                    _build_indexes()
                return True
            # Fallback: try hash lookup from index
            with _torrents_lock:
                tdata = _torrents.get(torrent_name, {})
            for fname, fdata in tdata.get("files", {}).items():
                stream_url = fdata.get("l", "")
                # Extract hash from stream URL if possible
                # URL format: http://decypharr:8282/api/browse/download/{torrent}/{file}
                pass
            log.warning("Decypharr: delete failed for %r: %s %s",
                        torrent_name, r.status_code, r.text[:100])
            return False
        except Exception as e:
            log.error("Decypharr delete_torrent(%r): %s", torrent_name, e)
            return False

    def reload_all(self) -> int:
        """Full reload — fetch all torrents and their files, rebuild index."""
        global _known_ids
        video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
        torrents = self.list_all_torrents()
        if not torrents:
            return 0

        clear_torrents()
        new_ids = set()
        count = 0
        for t in torrents:
            name = t.get("name") or t.get("Name", "")
            tid  = str(t.get("id") or t.get("hash") or name)
            if not name:
                continue
            files_raw = self.list_torrent_files(name)
            files = []
            for f in files_raw:
                fname = f.get("name") or f.get("Name", "")
                if not any(fname.lower().endswith(e) for e in video_exts):
                    continue
                stream_url = self.get_stream_url(name, fname)
                files.append({"n": fname, "s": f.get("size", 0), "l": stream_url})
            if files:
                register_torrent(name, files)
                count += 1
            new_ids.add(tid)

        with _known_ids_lock:
            _known_ids = new_ids
        _save_index()
        log.info("Decypharr: loaded %d torrents", count)
        return count

    def reload_new(self) -> int:
        """Incremental reload — only fetch files for new torrent IDs."""
        global _known_ids
        video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
        torrents = self.list_all_torrents()
        if not torrents:
            return 0

        with _known_ids_lock:
            current = set(_known_ids)

        new_torrents = [t for t in torrents
                        if str(t.get("id") or t.get("hash") or t.get("name", "")) not in current]
        if not new_torrents:
            return 0

        count = 0
        new_ids = set()
        for t in new_torrents:
            name = t.get("name") or t.get("Name", "")
            tid  = str(t.get("id") or t.get("hash") or name)
            if not name:
                continue
            files_raw = self.list_torrent_files(name)
            files = []
            for f in files_raw:
                fname = f.get("name") or f.get("Name", "")
                if not any(fname.lower().endswith(e) for e in video_exts):
                    continue
                stream_url = self.get_stream_url(name, fname)
                files.append({"n": fname, "s": f.get("size", 0), "l": stream_url})
            if files:
                register_torrent(name, files)
                count += 1
            new_ids.add(tid)

        with _known_ids_lock:
            _known_ids |= new_ids
        if count:
            _save_index()
        log.info("Decypharr: +%d new torrents", count)
        return count


# Public aliases matching fuse_mount.py interface
FUSE_AVAILABLE = True  # Decypharr is always "mounted"
