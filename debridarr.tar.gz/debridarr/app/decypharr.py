"""
Decypharr client — indexes torrents by hash for O(1) lookup.

Torrent list:  GET /api/v2/torrents/info  (qBit, plain list, fields: hash, name)
               GET /api/torrents          (native, plain list)
               GET /api/browse/__all__    (browse, plain list)
File list:     GET /api/browse/__all__/{name}
Stream:        GET /api/browse/download/{name}/{file}
Delete:        DELETE /api/torrents?hash={hash}
"""

import json, logging, re, threading
from pathlib import Path
from typing import Optional
import httpx

log = logging.getLogger("debridarr.decypharr")

# ── Indexes ───────────────────────────────────────────────────────────────────
_torrents: dict[str, dict] = {}   # name  → {hash, files:{fname:{n,s,l}}}
_by_hash:  dict[str, str]  = {}   # hash  → name
_lock      = threading.Lock()
_se_tag_index:   dict[str, list] = {}
_stem_index:     dict[str, list] = {}
_title_se_index: dict[str, list] = {}
_title_index:    dict[str, list] = {}
_known_hashes: set = set()
_INDEX_FILE = Path("/data/decypharr_index.json")

VIDEO_EXTS = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts", ".wmv"}
_se_pat = re.compile(r"[Ss](\d{1,2})[Ee](\d{1,2})")


# ── Normalisation ─────────────────────────────────────────────────────────────
def _stem_norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", s.lower())

def _title_words(s: str) -> list:
    s = s.lower()
    s = re.sub(r"[\u2019\u2018'\`]", "", s)
    for n in (6, 5, 4, 3, 2):
        pat = r"\b" + r"\.".join([r"([a-z])"] * n) + r"\."
        rep = "".join([rf"\{i}" for i in range(1, n + 1)])
        s = re.sub(pat, rep, s)
    s = re.sub(r"[^a-z0-9\s]", " ", s)
    return [w for w in s.split() if len(w) > 2 and (not w.isdigit() or len(w) == 4)]


# ── Index build ───────────────────────────────────────────────────────────────
def _build_indexes():
    global _se_tag_index, _stem_index, _title_se_index, _title_index
    se: dict = {}; st: dict = {}; tse: dict = {}; ti: dict = {}
    for name, tdata in _torrents.items():
        t_words = _title_words(name)
        for fname in tdata.get("files", {}):
            if not any(fname.lower().endswith(e) for e in VIDEO_EXTS):
                continue
            entry = (name, fname)
            m = _se_pat.search(fname)
            tag = None
            if m:
                tag = f"S{int(m.group(1)):02d}E{int(m.group(2)):02d}"
                se.setdefault(tag, []).append(entry)
            stem = _stem_norm(fname.rsplit(".", 1)[0] if "." in fname else fname)
            if stem:
                st.setdefault(stem, []).append(entry)
            if tag:
                for w in t_words:
                    tse.setdefault(f"{w}|{tag}", []).append(entry)
            for w in t_words:
                ti.setdefault(w, []).append(entry)
    _se_tag_index = se; _stem_index = st
    _title_se_index = tse; _title_index = ti


# ── Public accessors ──────────────────────────────────────────────────────────
def register_torrent(name: str, files: list, hash_: str = ""):
    with _lock:
        _torrents[name] = {"hash": hash_, "files": {f["n"]: f for f in files}}
        if hash_:
            _by_hash[hash_] = name
        _build_indexes()

def clear_torrents():
    global _se_tag_index, _stem_index, _title_se_index, _title_index
    with _lock:
        _torrents.clear(); _by_hash.clear()
        _se_tag_index.clear(); _stem_index.clear()
        _title_se_index.clear(); _title_index.clear()

def list_torrents() -> list:
    with _lock: return list(_torrents.keys())

def list_files(name: str) -> list:
    with _lock: return list(_torrents.get(name, {}).get("files", {}).keys())

def get_torrent_file(name: str, fname: str) -> Optional[dict]:
    with _lock:
        t = _torrents.get(name)
        return t["files"].get(fname) if t else None

def name_for_hash(hash_: str) -> Optional[str]:
    with _lock: return _by_hash.get(hash_)

def lookup_by_se_tag(tag: str) -> list:
    with _lock: return list(_se_tag_index.get(tag.upper(), []))

def lookup_by_stem(stem: str) -> list:
    with _lock: return list(_stem_index.get(_stem_norm(stem), []))

def lookup_by_title_se(word: str, tag: str) -> list:
    with _lock: return list(_title_se_index.get(f"{word.lower()}|{tag.upper()}", []))

def lookup_by_title_word(word: str) -> list:
    with _lock: return list(_title_index.get(word.lower(), []))


# ── Persistence ───────────────────────────────────────────────────────────────
def _save_index():
    try:
        _INDEX_FILE.parent.mkdir(parents=True, exist_ok=True)
        with _lock:
            data = {
                "known_hashes": list(_known_hashes),
                "torrents": {
                    name: {
                        "hash": tdata.get("hash", ""),
                        "files": {
                            fname: {"n": fname, "s": f.get("s", 0), "l": f.get("l", "")}
                            for fname, f in tdata.get("files", {}).items()
                        }
                    }
                    for name, tdata in _torrents.items()
                }
            }
        _INDEX_FILE.write_text(json.dumps(data))
    except Exception as e:
        log.warning("Index save failed: %s", e)

def _load_index() -> int:
    global _known_hashes
    if not _INDEX_FILE.exists():
        return 0
    try:
        data = json.loads(_INDEX_FILE.read_text())
        clear_torrents()
        with _lock:
            for name, tdata in data.get("torrents", {}).items():
                h = tdata.get("hash", "")
                _torrents[name] = {"hash": h, "files": tdata.get("files", {})}
                if h:
                    _by_hash[h] = name
            _build_indexes()
        _known_hashes = set(data.get("known_hashes", []))
        n = len(_torrents)
        log.info("Decypharr index loaded: %d torrents", n)
        return n
    except Exception as e:
        log.warning("Index load failed: %s", e)
        return 0


# ── HTTP client ───────────────────────────────────────────────────────────────
class DecypharrClient:
    def __init__(self, base_url: str, api_token: str = "", mount_path: str = ""):
        self.base_url   = base_url.rstrip("/")
        self.api_token  = api_token
        self.mount_path = mount_path.rstrip("/") if mount_path else ""
        self._http      = httpx.Client(timeout=15, follow_redirects=True)

    def _hdrs(self) -> dict:
        h = {"Accept": "application/json"}
        if self.api_token:
            h["Authorization"] = f"Bearer {self.api_token}"
        return h

    def _get_json(self, path: str) -> Optional[list | dict]:
        try:
            r = self._http.get(f"{self.base_url}{path}",
                               headers=self._hdrs(), timeout=15)
            if r.status_code == 404:
                return None
            r.raise_for_status()
            return r.json()
        except Exception as e:
            log.warning("GET %s: %s", path, e)
            return None

    # ── Torrent list ──────────────────────────────────────────────────────────
    def fetch_torrents(self) -> list[dict]:
        """
        Try each endpoint in order until we get a non-empty list.
        Per docs, all return a plain JSON array.
        qBit fields:   hash, name, size, ...
        Native fields: hash (or id), name, ...
        Browse fields: name, (no hash)
        """
        for path in ("/api/v2/torrents/info", "/api/torrents"):
            data = self._get_json(path)
            if isinstance(data, list) and data:
                log.info("Decypharr %s → %d torrents", path, len(data))
                return data
            if data is not None:
                log.debug("Decypharr %s returned: %s (empty/unexpected)", path, type(data).__name__)

        # Last resort: browse endpoint lists torrent folder names
        data = self._get_json("/api/browse/__all__")
        if isinstance(data, list) and data:
            log.info("Decypharr /api/browse/__all__ → %d entries", len(data))
            return data
        return []

    # ── File list ─────────────────────────────────────────────────────────────
    def fetch_files(self, torrent_name: str) -> list[dict]:
        """GET /api/browse/__all__/{name} → list of file entries."""
        import urllib.parse
        enc  = urllib.parse.quote(torrent_name, safe="")
        data = self._get_json(f"/api/browse/__all__/{enc}")
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            for k in ("files", "items", "data"):
                if isinstance(data.get(k), list):
                    return data[k]
        return []

    # ── Lookup by hash ────────────────────────────────────────────────────────
    def files_for_hash(self, hash_: str) -> tuple[str, list[dict]]:
        """
        Given a torrent hash, return (torrent_name, files).
        First checks in-memory index, then fetches directly from API.
        """
        # Already indexed
        name = name_for_hash(hash_)
        if name:
            return name, list_files(name)

        # Not in index — find by hash in torrent list
        torrents = self.fetch_torrents()
        for t in torrents:
            h = t.get("hash") or t.get("Hash") or t.get("id") or ""
            if str(h).lower() == hash_.lower():
                name = t.get("name") or t.get("Name") or ""
                if name:
                    files = self.fetch_files(name)
                    return name, files
        return "", []

    # ── Stream URL ────────────────────────────────────────────────────────────
    def get_stream_url(self, torrent_name: str, filename: str) -> str:
        if self.mount_path:
            p = Path(self.mount_path) / torrent_name / filename
            if p.exists():
                return str(p)
        import urllib.parse
        t = urllib.parse.quote(torrent_name, safe="")
        f = urllib.parse.quote(filename, safe="")
        return f"{self.base_url}/api/browse/download/{t}/{f}"

    def get_file_path(self, torrent_name: str, filename: str) -> Optional[Path]:
        if self.mount_path:
            p = Path(self.mount_path) / torrent_name / filename
            if p.exists():
                return p
        return None

    # ── Delete ────────────────────────────────────────────────────────────────
    def delete_torrent(self, torrent_name: str) -> bool:
        with _lock:
            h = _torrents.get(torrent_name, {}).get("hash", "")
        params = {"name": torrent_name}
        if h:
            params["hash"] = h
        try:
            r = self._http.delete(f"{self.base_url}/api/torrents",
                                  params=params, headers=self._hdrs())
            if r.status_code in (200, 204):
                with _lock:
                    _torrents.pop(torrent_name, None)
                    if h: _by_hash.pop(h, None)
                    _build_indexes()
                return True
        except Exception as e:
            log.warning("delete_torrent: %s", e)
        return False

    # ── Full reload ───────────────────────────────────────────────────────────
    def reload_all(self) -> int:
        global _known_hashes
        raw = self.fetch_torrents()
        log.info("Decypharr reload_all: %d raw entries", len(raw))
        if not raw:
            return 0

        clear_torrents()
        new_hashes: set = set()
        count = 0

        for t in raw:
            name = (t.get("name") or t.get("Name") or
                    t.get("title") or t.get("filename") or "")
            hash_ = str(t.get("hash") or t.get("Hash") or
                        t.get("id")   or name)
            if not name:
                continue

            files_raw = self.fetch_files(name)
            files = []
            for f in files_raw:
                fname = (f.get("name") or f.get("Name") or
                         f.get("filename") or "")
                if not fname or not any(fname.lower().endswith(e) for e in VIDEO_EXTS):
                    continue
                files.append({"n": fname, "s": f.get("size", 0),
                              "l": self.get_stream_url(name, fname)})
            if files:
                register_torrent(name, files, hash_)
                count += 1
            new_hashes.add(hash_)

        _known_hashes = new_hashes
        _save_index()
        log.info("Decypharr reload_all done: %d/%d with video files", count, len(raw))
        return count

    # ── Incremental reload ────────────────────────────────────────────────────
    def reload_new(self) -> int:
        global _known_hashes
        raw = self.fetch_torrents()
        if not raw:
            return 0

        new_entries = [
            t for t in raw
            if str(t.get("hash") or t.get("Hash") or t.get("id") or
                   t.get("name") or "") not in _known_hashes
        ]
        if not new_entries:
            return 0

        count = 0
        new_hashes: set = set()
        for t in new_entries:
            name  = (t.get("name") or t.get("Name") or "")
            hash_ = str(t.get("hash") or t.get("Hash") or t.get("id") or name)
            if not name:
                continue
            files_raw = self.fetch_files(name)
            files = []
            for f in files_raw:
                fname = (f.get("name") or f.get("Name") or f.get("filename") or "")
                if not fname or not any(fname.lower().endswith(e) for e in VIDEO_EXTS):
                    continue
                files.append({"n": fname, "s": f.get("size", 0),
                              "l": self.get_stream_url(name, fname)})
            if files:
                register_torrent(name, files, hash_)
                count += 1
            new_hashes.add(hash_)

        _known_hashes |= new_hashes
        if count:
            _save_index()
        log.info("Decypharr reload_new: +%d", count)
        return count


FUSE_AVAILABLE = True
