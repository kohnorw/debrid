"""
Decypharr client — uses Decypharr's API to list torrents and files.

Primary:  GET /api/torrents          — list all torrents
Fallback: GET /api/browse/__all__    — browse virtual filesystem
Files:    GET /api/browse/__all__/{torrent}
Stream:   GET /api/browse/download/{torrent}/{file}
"""

import json
import logging
import re
import threading
from pathlib import Path
from typing import Optional

import httpx

log = logging.getLogger("debridarr.decypharr")

# ── In-memory indexes ─────────────────────────────────────────────────────────
_torrents: dict[str, dict] = {}   # torrent_name → {files: {fname: {n,s,l}}}
_lock = threading.Lock()
_se_tag_index:   dict[str, list] = {}
_stem_index:     dict[str, list] = {}
_title_se_index: dict[str, list] = {}
_title_index:    dict[str, list] = {}
_known_ids: set = set()
_INDEX_FILE = Path("/data/decypharr_index.json")


# ── Normalisation ─────────────────────────────────────────────────────────────
_se_pat = re.compile(r"[Ss](\d{1,2})[Ee](\d{1,2})")

def _stem_norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", s.lower())

def _title_words(s: str) -> list:
    s = s.lower()
    s = re.sub(r"[\u2019\u2018'\`]", "", s)
    for n in (6, 5, 4, 3, 2):
        pat = r"\b" + r"\.".join([r"([a-z])"] * n) + r"\."
        rep = "".join([rf"\{i}" for i in range(1, n + 1)])
        s = re.sub(pat, rep, s)
    s = re.sub(r"[^a-z0-9\s]", " ", s)
    return [w for w in s.split() if len(w) > 2 and (not w.isdigit() or len(w) == 4)]


# ── Index build ───────────────────────────────────────────────────────────────
def _build_indexes():
    """Rebuild all in-memory indexes from _torrents. Must hold _lock."""
    global _se_tag_index, _stem_index, _title_se_index, _title_index
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
    se: dict = {}; st: dict = {}; tse: dict = {}; ti: dict = {}
    for torrent_name, tdata in _torrents.items():
        t_words = _title_words(torrent_name)
        for fname in tdata.get("files", {}):
            if not any(fname.lower().endswith(e) for e in video_exts):
                continue
            entry = (torrent_name, fname)
            m = _se_pat.search(fname)
            tag = None
            if m:
                tag = f"S{int(m.group(1)):02d}E{int(m.group(2)):02d}"
                se.setdefault(tag, []).append(entry)
            stem = _stem_norm(fname.rsplit(".", 1)[0] if "." in fname else fname)
            if stem:
                st.setdefault(stem, []).append(entry)
            if tag:
                for w in t_words:
                    tse.setdefault(f"{w}|{tag}", []).append(entry)
            for w in t_words:
                ti.setdefault(w, []).append(entry)
    _se_tag_index = se; _stem_index = st; _title_se_index = tse; _title_index = ti


# ── Public index accessors ────────────────────────────────────────────────────
def register_torrent(name: str, files: list):
    with _lock:
        _torrents[name] = {"files": {f["n"]: f for f in files}}
        _build_indexes()

def clear_torrents():
    global _se_tag_index, _stem_index, _title_se_index, _title_index
    with _lock:
        _torrents.clear()
        _se_tag_index.clear(); _stem_index.clear()
        _title_se_index.clear(); _title_index.clear()

def list_torrents() -> list:
    with _lock: return list(_torrents.keys())

def list_files(torrent_name: str) -> list:
    with _lock: return list(_torrents.get(torrent_name, {}).get("files", {}).keys())

def get_torrent_file(torrent_name: str, filename: str) -> Optional[dict]:
    with _lock:
        t = _torrents.get(torrent_name)
        return t["files"].get(filename) if t else None

def lookup_by_se_tag(tag: str) -> list:
    with _lock: return list(_se_tag_index.get(tag.upper(), []))

def lookup_by_stem(stem: str) -> list:
    with _lock: return list(_stem_index.get(_stem_norm(stem), []))

def lookup_by_title_se(word: str, tag: str) -> list:
    with _lock: return list(_title_se_index.get(f"{word.lower()}|{tag.upper()}", []))

def lookup_by_title_word(word: str) -> list:
    with _lock: return list(_title_index.get(word.lower(), []))


# ── Persistence ───────────────────────────────────────────────────────────────
def _save_index():
    try:
        _INDEX_FILE.parent.mkdir(parents=True, exist_ok=True)
        with _lock:
            data = {
                "known_ids": list(_known_ids),
                "torrents": {
                    name: {"files": {
                        fname: {"n": fname, "s": f.get("s", 0), "l": f.get("l", "")}
                        for fname, f in tdata.get("files", {}).items()
                    }}
                    for name, tdata in _torrents.items()
                }
            }
        _INDEX_FILE.write_text(json.dumps(data))
    except Exception as e:
        log.warning("Index save failed: %s", e)

def _load_index() -> int:
    global _known_ids
    if not _INDEX_FILE.exists():
        return 0
    try:
        data = json.loads(_INDEX_FILE.read_text())
        clear_torrents()
        with _lock:
            for name, tdata in data.get("torrents", {}).items():
                _torrents[name] = {"files": tdata.get("files", {})}
            _build_indexes()
        with threading.Lock():
            _known_ids = set(data.get("known_ids", []))
        n = len(data.get("torrents", {}))
        log.info("Decypharr index loaded from disk: %d torrents", n)
        return n
    except Exception as e:
        log.warning("Index load failed: %s", e)
        return 0


# ── HTTP client ───────────────────────────────────────────────────────────────
class DecypharrClient:
    def __init__(self, base_url: str, api_token: str = "", mount_path: str = ""):
        self.base_url   = base_url.rstrip("/")
        self.api_token  = api_token
        self.mount_path = mount_path.rstrip("/") if mount_path else ""
        self._http = httpx.Client(timeout=15, follow_redirects=True)

    def _hdrs(self) -> dict:
        h = {"Accept": "application/json"}
        if self.api_token:
            h["Authorization"] = f"Bearer {self.api_token}"
        return h

    def _get(self, path: str) -> Optional[dict | list]:
        """Make a GET request, return parsed JSON or None on failure."""
        url = f"{self.base_url}{path}"
        try:
            r = self._http.get(url, headers=self._hdrs())
            r.raise_for_status()
            return r.json()
        except Exception as e:
            log.warning("GET %s failed: %s", url, e)
            return None

    def _extract_list(self, data) -> list:
        """Extract a list from whatever shape the API returns."""
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            for key in ("data", "torrents", "items", "results", "content"):
                v = data.get(key)
                if isinstance(v, list):
                    return v
        return []

    def _torrent_name(self, t: dict) -> str:
        return (t.get("name") or t.get("Name") or
                t.get("filename") or t.get("title") or
                t.get("hash") or t.get("id") or "")

    def _torrent_id(self, t: dict) -> str:
        return str(t.get("id") or t.get("hash") or t.get("Hash") or self._torrent_name(t))

    # ── Torrent list ──────────────────────────────────────────────────────────
    def list_all_torrents(self) -> list[dict]:
        """Try /api/torrents, fall back to /api/browse/__all__."""
        # Primary: qBit-compatible torrent list
        data = self._get("/api/torrents")
        if data is not None:
            items = self._extract_list(data)
            if items:
                log.debug("Decypharr /api/torrents: %d items", len(items))
                return items

        # Fallback: browse virtual filesystem
        data = self._get("/api/browse/__all__")
        if data is not None:
            raw = self._extract_list(data)
            # Browse returns folder/file entries — convert to torrent-like dicts
            result = []
            for item in raw:
                name = (item.get("name") or item.get("Name") or
                        item.get("filename") or str(item))
                if name:
                    result.append({"name": name, "id": name, "hash": name})
            if result:
                log.debug("Decypharr /api/browse/__all__ fallback: %d items", len(result))
            return result

        return []

    # ── File list ─────────────────────────────────────────────────────────────
    def list_torrent_files(self, torrent_name: str) -> list[dict]:
        """GET /api/browse/__all__/{torrent}"""
        import urllib.parse
        encoded = urllib.parse.quote(torrent_name, safe="")
        data = self._get(f"/api/browse/__all__/{encoded}")
        if data is None:
            return []
        return self._extract_list(data)

    # ── Stream URL ────────────────────────────────────────────────────────────
    def get_stream_url(self, torrent_name: str, filename: str) -> str:
        if self.mount_path:
            p = Path(self.mount_path) / torrent_name / filename
            if p.exists():
                return str(p)
        import urllib.parse
        t = urllib.parse.quote(torrent_name, safe="")
        f = urllib.parse.quote(filename, safe="")
        return f"{self.base_url}/api/browse/download/{t}/{f}"

    def get_file_path(self, torrent_name: str, filename: str) -> Optional[Path]:
        if self.mount_path:
            p = Path(self.mount_path) / torrent_name / filename
            if p.exists():
                return p
        return None

    # ── Delete ────────────────────────────────────────────────────────────────
    def delete_torrent(self, torrent_name: str) -> bool:
        try:
            r = self._http.delete(
                f"{self.base_url}/api/torrents",
                params={"name": torrent_name},
                headers=self._hdrs())
            if r.status_code in (200, 204):
                with _lock:
                    _torrents.pop(torrent_name, None)
                    _build_indexes()
                log.info("Decypharr: deleted torrent %r", torrent_name)
                return True
            log.warning("Decypharr delete %r: %s %s", torrent_name, r.status_code, r.text[:100])
            return False
        except Exception as e:
            log.warning("Decypharr delete_torrent: %s", e)
            return False

    # ── Full reload ───────────────────────────────────────────────────────────
    def reload_all(self) -> int:
        global _known_ids
        video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
        torrents = self.list_all_torrents()
        log.info("Decypharr reload_all: %d raw torrents from API", len(torrents))
        if not torrents:
            return 0

        clear_torrents()
        new_ids: set = set()
        count = 0
        for t in torrents:
            name = self._torrent_name(t)
            tid  = self._torrent_id(t)
            if not name:
                continue
            files_raw = self.list_torrent_files(name)
            files = []
            for f in files_raw:
                fname = (f.get("name") or f.get("Name") or
                         f.get("filename") or "")
                if not fname:
                    continue
                if not any(fname.lower().endswith(e) for e in video_exts):
                    continue
                stream_url = self.get_stream_url(name, fname)
                files.append({"n": fname, "s": f.get("size", 0), "l": stream_url})
            if files:
                register_torrent(name, files)
                count += 1
            new_ids.add(tid)

        with threading.Lock():
            _known_ids = new_ids
        _save_index()
        log.info("Decypharr reload_all complete: %d/%d torrents with video files", count, len(torrents))
        return count

    # ── Incremental reload ────────────────────────────────────────────────────
    def reload_new(self) -> int:
        global _known_ids
        video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
        torrents = self.list_all_torrents()
        if not torrents:
            return 0

        current_ids = set(_known_ids)
        new_torrents = [t for t in torrents
                        if self._torrent_id(t) not in current_ids]
        if not new_torrents:
            return 0

        count = 0
        new_ids: set = set()
        for t in new_torrents:
            name = self._torrent_name(t)
            tid  = self._torrent_id(t)
            if not name:
                continue
            files_raw = self.list_torrent_files(name)
            files = []
            for f in files_raw:
                fname = (f.get("name") or f.get("Name") or
                         f.get("filename") or "")
                if not fname:
                    continue
                if not any(fname.lower().endswith(e) for e in video_exts):
                    continue
                stream_url = self.get_stream_url(name, fname)
                files.append({"n": fname, "s": f.get("size", 0), "l": stream_url})
            if files:
                register_torrent(name, files)
                count += 1
            new_ids.add(tid)

        with threading.Lock():
            _known_ids |= new_ids
        if count:
            _save_index()
        log.info("Decypharr reload_new: +%d torrents", count)
        return count


# Public alias
FUSE_AVAILABLE = True
