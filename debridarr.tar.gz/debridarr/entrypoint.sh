#!/usr/bin/env sh
set -eu
mkdir -p /data /streams /mnt/debrid
exec uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-7474}"
