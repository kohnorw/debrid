#!/bin/sh
set -e

# Ensure data/symlink dirs exist (Decypharr provides the media mount externally).
mkdir -p /data /streams

export USER=root
export HOME=/root
exec "$@"
