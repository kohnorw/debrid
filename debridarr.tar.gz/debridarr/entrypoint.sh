#!/bin/sh
set -e

if ! grep -q "^user_allow_other" /etc/fuse.conf 2>/dev/null; then
    echo "user_allow_other" >> /etc/fuse.conf
fi

DFS_MOUNT="${DFS_FUSE_MOUNT:-/docker/debridarr/mnt-alldebrid}"

# Clean up stale FUSE mount from previous run
if mountpoint -q "$DFS_MOUNT" 2>/dev/null; then
    echo "[entrypoint] Stale mount at $DFS_MOUNT — cleaning up"
    fusermount -uz "$DFS_MOUNT" 2>/dev/null || \
    umount -l "$DFS_MOUNT" 2>/dev/null || true
    sleep 0.5
fi

mkdir -p "$DFS_MOUNT" /data /streams /cache/dfs

# Make the parent directory a shared mount so FUSE propagates to the host
# and other containers can access the mount via allow_other
nsenter --mount=/proc/1/ns/mnt -- sh -c \
    "mountpoint -q '$DFS_MOUNT' || (mount --bind '$DFS_MOUNT' '$DFS_MOUNT' && mount --make-shared '$DFS_MOUNT')" \
    2>/dev/null || \
    mount --bind "$DFS_MOUNT" "$DFS_MOUNT" && mount --make-shared "$DFS_MOUNT" 2>/dev/null || true

export USER=root
export HOME=/root
exec "$@"
