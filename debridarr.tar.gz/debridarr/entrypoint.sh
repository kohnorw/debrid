#!/bin/sh
set -e

FUSE_MOUNT=${DFS_FUSE_MOUNT:-/docker/debridarr/mnt-alldebrid}

if ! grep -q "^user_allow_other" /etc/fuse.conf 2>/dev/null; then
    echo "user_allow_other" >> /etc/fuse.conf
fi

# Clean up stale FUSE mount from previous run
if mountpoint -q "$FUSE_MOUNT" 2>/dev/null; then
    echo "[entrypoint] Stale mount at $FUSE_MOUNT — cleaning up"
    fusermount -uz "$FUSE_MOUNT" 2>/dev/null || \
    umount -l "$FUSE_MOUNT" 2>/dev/null || true
    sleep 0.5
fi

mkdir -p "$FUSE_MOUNT" /data /streams /cache/dfs

export USER=root
export HOME=/root
exec "$@"
