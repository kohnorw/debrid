#!/usr/bin/env sh
set -eu

if ! grep -q "^user_allow_other" /etc/fuse.conf 2>/dev/null; then
    echo "user_allow_other" >> /etc/fuse.conf
fi

DFS_MOUNT="${DFS_FUSE_MOUNT:-/mnt-alldebrid}"

if mountpoint -q "$DFS_MOUNT" 2>/dev/null; then
    echo "[entrypoint] Stale DFS mount at $DFS_MOUNT — cleaning up"
    fusermount -uz "$DFS_MOUNT" 2>/dev/null || \
    umount -l "$DFS_MOUNT" 2>/dev/null || true
    sleep 0.5
fi

mkdir -p /data /streams /cache/dfs "$DFS_MOUNT"

export USER=root
export HOME=/root
exec uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-7474}"
