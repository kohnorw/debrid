#!/usr/bin/env sh
set -eu

if ! grep -q "^user_allow_other" /etc/fuse.conf 2>/dev/null; then
    echo "user_allow_other" >> /etc/fuse.conf
fi

# Copy fuse.conf to host namespace so fusermount can read it
nsenter --mount=/proc/1/ns/mnt -- sh -c \
    'grep -q "^user_allow_other" /etc/fuse.conf 2>/dev/null || echo "user_allow_other" >> /etc/fuse.conf' \
    2>/dev/null || true

DFS_MOUNT="${DFS_FUSE_MOUNT:-/mnt-alldebrid}"

# Clean up stale mount in HOST namespace
nsenter --mount=/proc/1/ns/mnt -- sh -c \
    "mountpoint -q '$DFS_MOUNT' 2>/dev/null && fusermount -uz '$DFS_MOUNT' 2>/dev/null || true" \
    2>/dev/null || true

# Ensure the mount point exists on the host
nsenter --mount=/proc/1/ns/mnt -- mkdir -p "$DFS_MOUNT" 2>/dev/null || \
    mkdir -p "$DFS_MOUNT"

mkdir -p /data /streams /cache/dfs "$DFS_MOUNT"

export USER=root
export HOME=/root
exec uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-7474}"
