#!/usr/bin/env python3
"""
Run this directly on the host (outside Docker) to mount AllDebrid via FUSE.
It talks to the debridarr container API to get torrents, then mounts the
FUSE filesystem at /docker/debridarr/mnt-alldebrid (or any path you choose).

Usage:
    pip3 install fusepy httpx
    python3 mount-alldebrid.py

Requirements on host:
    apt install fuse
    echo "user_allow_other" >> /etc/fuse.conf
"""

import asyncio
import errno
import hashlib
import logging
import os
import stat
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Optional

import httpx

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s – %(message)s")
log = logging.getLogger("alldebrid-fuse")

# ── Config ────────────────────────────────────────────────────────────────────
DEBRIDARR_URL  = os.getenv("DEBRIDARR_URL",  "http://localhost:7474")
ALLDEBRID_KEY  = os.getenv("ALLDEBRID_API_KEY", "")
MOUNT_POINT    = os.getenv("DFS_FUSE_MOUNT", "/docker/debridarr/mnt-alldebrid")
CACHE_DIR      = os.getenv("DFS_CACHE_DIR",  "/docker/debridarr/cache/dfs")
CACHE_SIZE_GB  = int(os.getenv("DFS_CACHE_SIZE_GB",  "50"))
CACHE_TTL_H    = int(os.getenv("DFS_CACHE_TTL_H",    "12"))
CHUNK_MB       = int(os.getenv("DFS_CHUNK_MB",        "32"))
READ_AHEAD_MB  = int(os.getenv("DFS_READ_AHEAD_MB",   "128"))
AD_BASE        = "https://api.alldebrid.com/v4"
AD_STATUS      = "https://api.alldebrid.com/v4.1/magnet/status"
AD_FILES       = f"{AD_BASE}/magnet/files"
AD_UNLOCK      = f"{AD_BASE}/link/unlock"
AGENT          = "debridarr"

try:
    from fuse import FUSE, FuseOSError, Operations
except ImportError:
    sys.exit("fusepy not installed — run: pip3 install fusepy")

# ── Torrent registry ──────────────────────────────────────────────────────────
_torrents: dict = {}
_torrents_lock  = threading.Lock()
_cdn_cache: dict = {}
_cdn_lock       = threading.Lock()
_size_cache: dict = {}
_prefetch_pool  = ThreadPoolExecutor(max_workers=4)

def register_torrent(name, files):
    with _torrents_lock:
        _torrents[name] = {"files": {f["n"]: f for f in files}}

def list_torrents():
    with _torrents_lock:
        return list(_torrents.keys())

def list_files(name):
    with _torrents_lock:
        return list(_torrents.get(name, {}).get("files", {}).keys())

def get_file(torrent, filename):
    with _torrents_lock:
        t = _torrents.get(torrent)
        return t["files"].get(filename) if t else None

# ── AllDebrid API ─────────────────────────────────────────────────────────────
_http_async = httpx.AsyncClient(timeout=30, follow_redirects=True)

async def _ad_get(path, params=None):
    p = {"agent": AGENT, "apikey": ALLDEBRID_KEY, **(params or {})}
    r = await _http_async.get(path, params=p)
    return r.json()

async def _ad_post_form(url, fields):
    from urllib.parse import urlencode
    pairs = [("agent", AGENT), ("apikey", ALLDEBRID_KEY)] + list(fields)
    r = await _http_async.post(url, content=urlencode(pairs).encode(),
                               headers={"Content-Type": "application/x-www-form-urlencoded"})
    return r.json()

def _flatten(files):
    out = []
    for f in files:
        if "e" in f:
            out.extend(_flatten(f["e"]))
        else:
            out.append(f)
    return out

async def fetch_torrents():
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
    r = await _ad_get(AD_STATUS, {"status": "ready"})
    if r.get("status") != "success":
        log.error("magnet/status failed: %s", r)
        return []
    raw = r.get("data", {}).get("magnets", {})
    magnets = list(raw.values()) if isinstance(raw, dict) else (raw if isinstance(raw, list) else [])
    if not magnets:
        log.info("No ready torrents")
        return []
    ids     = [str(m["id"]) for m in magnets if m.get("id")]
    names   = {str(m["id"]): m.get("filename", f"torrent_{m['id']}") for m in magnets}
    result  = []
    for i in range(0, len(ids), 50):
        batch = ids[i:i+50]
        fr = await _ad_post_form(AD_FILES, [("id[]", x) for x in batch])
        if not fr or fr.get("status") != "success":
            continue
        mfiles = fr.get("data", {}).get("magnets", [])
        if isinstance(mfiles, dict):
            mfiles = list(mfiles.values())
        for mf in mfiles:
            mid   = str(mf.get("id", ""))
            name  = names.get(mid, f"torrent_{mid}")
            flat  = _flatten(mf.get("files", []))
            vids  = [f for f in flat if any(f.get("n","").lower().endswith(e) for e in video_exts)]
            if vids:
                stem = Path(vids[0]["n"]).stem
                folder = stem if stem.startswith(name.rstrip("-")) else name
                result.append({"name": folder, "files": vids})
    log.info("Fetched %d torrents", len(result))
    return result

def _get_cdn_url(ad_link):
    with _cdn_lock:
        c = _cdn_cache.get(ad_link)
        if c and time.time() - c[1] < 4*3600:
            return c[0]
    try:
        r = httpx.get(AD_UNLOCK, params={"agent": AGENT, "apikey": ALLDEBRID_KEY, "link": ad_link}, timeout=15)
        d = r.json()
        if d.get("status") == "success":
            url = d["data"]["link"]
            with _cdn_lock:
                _cdn_cache[ad_link] = (url, time.time())
            return url
    except Exception as e:
        log.error("unlock_file: %s", e)
    return None

# ── Chunk cache ───────────────────────────────────────────────────────────────
_http_sync = httpx.Client(timeout=120, follow_redirects=True)

def _chunk_path(link, idx):
    Path(CACHE_DIR).mkdir(parents=True, exist_ok=True)
    h = hashlib.md5(link.encode()).hexdigest()[:16]
    return Path(CACHE_DIR) / f"{h}_{idx}"

def _read_chunk(link, idx):
    p = _chunk_path(link, idx)
    if p.exists():
        p.touch()
        return p.read_bytes()
    return None

def _write_chunk(link, idx, data):
    try: _chunk_path(link, idx).write_bytes(data)
    except: pass

def _get_chunk(link, idx):
    chunk_bytes = CHUNK_MB * 1024 * 1024
    cached = _read_chunk(link, idx)
    if cached is not None:
        return cached
    url = _get_cdn_url(link)
    if not url:
        return None
    start, end = idx * chunk_bytes, idx * chunk_bytes + chunk_bytes - 1
    for attempt in range(2):
        try:
            r = _http_sync.get(url, headers={"Range": f"bytes={start}-{end}"})
            if r.status_code in (200, 206):
                _write_chunk(link, idx, r.content)
                return r.content
            if r.status_code == 416:
                return b""
            if r.status_code in (403, 410) and attempt == 0:
                with _cdn_lock: _cdn_cache.pop(link, None)
                url = _get_cdn_url(link) or url
                continue
            return None
        except Exception:
            if attempt == 0: continue
            return None
    return None

# ── FUSE filesystem ───────────────────────────────────────────────────────────
class AllDebridFS(Operations):
    def getattr(self, path, fh=None):
        now = int(time.time())
        parts = [p for p in path.split("/") if p]
        if not parts:
            return self._dstat(now)
        if len(parts) == 1:
            if parts[0] in list_torrents():
                return self._dstat(now)
            raise FuseOSError(errno.ENOENT)
        if len(parts) == 2:
            f = get_file(parts[0], parts[1])
            if f:
                return self._fstat(now, f.get("s", 0) or 0)
            raise FuseOSError(errno.ENOENT)
        raise FuseOSError(errno.ENOENT)

    def readdir(self, path, fh):
        parts = [p for p in path.split("/") if p]
        yield "."; yield ".."
        if not parts:
            yield from list_torrents()
        elif len(parts) == 1:
            yield from list_files(parts[0])

    def open(self, path, flags): return 0

    def read(self, path, size, offset, fh):
        parts = [p for p in path.split("/") if p]
        if len(parts) != 2: raise FuseOSError(errno.ENOENT)
        f = get_file(parts[0], parts[1])
        if not f: raise FuseOSError(errno.ENOENT)
        link = f.get("l", "")
        if not link: raise FuseOSError(errno.EIO)
        chunk_bytes = CHUNK_MB * 1024 * 1024
        chunk_idx   = offset // chunk_bytes
        chunk_off   = offset % chunk_bytes
        result      = b""
        while len(result) < size:
            chunk = _get_chunk(link, chunk_idx)
            if chunk is None: raise FuseOSError(errno.EIO)
            if chunk == b"": break
            piece = chunk[chunk_off: chunk_off + (size - len(result))]
            result += piece
            if len(piece) < len(chunk) - chunk_off: break
            chunk_idx += 1; chunk_off = 0
        ahead = (READ_AHEAD_MB * 1024 * 1024) // chunk_bytes
        _prefetch_pool.submit(_prefetch, link, chunk_idx, ahead)
        return result

    def access(self, path, mode): return 0
    def statfs(self, path):
        b = CACHE_SIZE_GB * 1024**3 // 4096
        return {"f_bsize": 4096, "f_blocks": b, "f_bfree": b, "f_bavail": b, "f_files": 0, "f_ffree": 0}

    def _dstat(self, now):
        return {"st_mode": stat.S_IFDIR|0o755, "st_nlink": 2, "st_size": 4096,
                "st_ctime": now, "st_mtime": now, "st_atime": now,
                "st_uid": os.getuid(), "st_gid": os.getgid()}
    def _fstat(self, now, size):
        return {"st_mode": stat.S_IFREG|0o444, "st_nlink": 1, "st_size": size,
                "st_ctime": now, "st_mtime": now, "st_atime": now,
                "st_uid": os.getuid(), "st_gid": os.getgid()}

def _prefetch(link, start, num):
    for i in range(num):
        if _read_chunk(link, start + i) is None:
            _get_chunk(link, start + i)

# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    if not ALLDEBRID_KEY:
        sys.exit("Set ALLDEBRID_API_KEY env var")

    Path(MOUNT_POINT).mkdir(parents=True, exist_ok=True)
    Path(CACHE_DIR).mkdir(parents=True, exist_ok=True)

    log.info("Fetching torrents from AllDebrid...")
    torrents = asyncio.run(fetch_torrents())
    for t in torrents:
        register_torrent(t["name"], t["files"])
    log.info("Registered %d torrents", len(torrents))

    log.info("Mounting at %s", MOUNT_POINT)
    FUSE(AllDebridFS(), MOUNT_POINT,
         nothreads=False, foreground=True, ro=True,
         allow_other=True, big_writes=True, max_read=131072)
