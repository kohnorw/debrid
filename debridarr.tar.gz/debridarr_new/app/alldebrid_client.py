"""
Minimal AllDebrid client for DFS FUSE mounting.
Provides unlock_file() used by fuse_mount.py to resolve CDN URLs.
"""
import logging
import httpx

log = logging.getLogger("debridarr.alldebrid")

AD_BASE = "https://api.alldebrid.com/v4"
AGENT   = "debridarr"


class AllDebridClient:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self._client = httpx.AsyncClient(timeout=30)

    async def unlock_file(self, link: str) -> str | None:
        """Unlock an AllDebrid link and return the CDN URL."""
        if not self.api_key or not link:
            return None
        try:
            r = await self._client.get(
                f"{AD_BASE}/link/unlock",
                params={"agent": AGENT, "apikey": self.api_key, "link": link},
            )
            data = r.json()
            if data.get("status") == "success":
                return data["data"].get("link")
            log.warning("unlock_file error: %s", data.get("error", {}).get("message"))
        except Exception as e:
            log.error("unlock_file exception: %s", e)
        return None

    async def get_all_torrents(self) -> list[dict]:
        """Return all active torrents (for FUSE registration on startup)."""
        if not self.api_key:
            return []
        try:
            r = await self._client.get(
                f"{AD_BASE}/magnet/status",
                params={"agent": AGENT, "apikey": self.api_key, "status": "ready"},
            )
            data = r.json()
            if data.get("status") != "success":
                return []
            magnets = data.get("data", {}).get("magnets", {})
            if isinstance(magnets, dict):
                magnets = list(magnets.values())
            result = []
            for m in magnets:
                files = [
                    {"n": f.get("n", ""), "l": f.get("l", ""), "s": f.get("s", 0)}
                    for f in (m.get("links") or [])
                ]
                result.append({
                    "id":    m.get("id"),
                    "name":  m.get("filename", ""),
                    "hash":  m.get("hash", ""),
                    "files": files,
                })
            return result
        except Exception as e:
            log.error("get_all_torrents: %s", e)
            return []

    async def aclose(self):
        await self._client.aclose()
