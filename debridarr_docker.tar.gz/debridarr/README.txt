Debridarr lightweight metadata + fast Plex build
Includes:
- lightweight NFO metadata cache
- no heavy artwork downloads by default
- stable symlink retention
- active AllDebrid downloads only view
- rebuilt: Mon Jun  8 15:33:47 2026
