Debridarr build
- Never delete symlinks before 30-day expiry
- Startup repair preserves symlinks
- Stable Plex paths
- rebuilt: Mon Jun  8 17:17:40 2026
