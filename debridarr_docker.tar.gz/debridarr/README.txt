Debridarr build: Hash Index TV detail season/episode coverage UI

Added:
- TV detail modal styled like provided screenshot
- Seasons tab with season cards
- Episode rows showing cached/missing state
- Season pack and series pack cache indicators
- Search whole series button
- Search season button
- Search individual episode button
- Uses hash index + pack coverage to mark cached episodes
- Keeps existing strict cached/coverage placeholder rules

Built: Mon Jun  8 17:54:07 2026
