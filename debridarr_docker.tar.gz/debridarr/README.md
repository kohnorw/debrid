# Debridarr

On-the-fly AllDebrid streaming for Plex. Add a title to your library and Debridarr indexes it against AllDebrid's cache. When you press play in Plex, it mounts the torrent via FUSE and symlinks it directly into your Plex library — no downloading, no local storage required.

---

## How It Works

```
Add to library
  → Prowlarr searches Torznab indexers for hashes
  → AllDebrid instant availability check (no account changes)
  → Confirmed hashes stored in Hash Index with scored ranking
  → .mp4 placeholder written to Plex only if a cached hash exists

User presses Play in Plex
  → Tautulli webhook fires → Debridarr
  → Hash Index lookup (scored: series pack > season pack > episode)
  → Hash Index hit → add_magnet() to AllDebrid → FUSE mount
  → Symlink plex-strm/movies|tv/... → FUSE file
  → Plex streams bytes from AllDebrid CDN via HTTP Range

Hash Index miss
  → Live Prowlarr search → AllDebrid cache check → index updated
  → If found: resolve and stream
  → If not found: no placeholder, Plex shows nothing
```

**Key principle:** `add_magnet()` is called exactly once — when the user presses play and the Hash Index has a confirmed cached hit. Nothing is added to your AllDebrid account during indexing.

---

## Requirements

- Docker + Docker Compose
- AllDebrid account with API key
- Prowlarr (aggregate Torznab source for hash indexing)
- Overseerr (library browsing and request management)
- Sonarr + Radarr (optional — for direct import)
- Tautulli (detects Plex playback, triggers resolution)
- Plex Media Server

---

## Install

Upload `debridarr_docker.tar.gz` to `/docker/debridarr/`, then:

```bash
cd /docker/debridarr
mkdir -p /tmp/debridarr_extract && \
tar -xzf debridarr_docker.tar.gz -C /tmp/debridarr_extract && \
cp -r /tmp/debridarr_extract/debridarr/. /docker/debridarr/ && \
rm -rf /tmp/debridarr_extract && \
mkdir -p /docker/debridarr/tmp/cache && \
docker compose build --no-cache && \
docker compose up -d && \
docker logs debridarr -f
```

Then open `http://<your-ip>:7474` and complete the setup wizard.

---

## Update

Upload new `debridarr_docker.tar.gz` to `/docker/debridarr/`, then:

```bash
cd /docker/debridarr
mkdir -p /tmp/debridarr_extract && \
tar -xzf debridarr_docker.tar.gz -C /tmp/debridarr_extract && \
cp -r /tmp/debridarr_extract/debridarr/. /docker/debridarr/ && \
rm -rf /tmp/debridarr_extract && \
docker compose down && \
docker compose build --no-cache && \
docker compose up -d && \
docker logs debridarr -f
```

---

## Plex Setup

Add two libraries pointing to the bind-mounted `plex-strm` folders:

| Library | Folder path |
|---------|-------------|
| Movies  | `/docker/debridarr/plex-strm/movies` |
| TV Shows | `/docker/debridarr/plex-strm/tv` |

Plex must be able to follow symlinks into `/docker/debridarr/mnt-alldebrid`. Mount that path into your Plex container with the same absolute path.

---

## Tautulli Setup

1. Settings → Notification Agents → Add → **Webhook**
2. **Webhook URL:** `http://debridarr:7474/webhook/tautulli`
3. **Method:** POST
4. **Triggers:** Playback Start only
5. **Data → Playback Start**, paste:

```json
{
  "media_type": "{media_type}",
  "title": "{title}",
  "grandparent_title": "{grandparent_title}",
  "year": "{year}",
  "grandparent_year": "{grandparent_year}",
  "parent_media_index": "{parent_media_index}",
  "media_index": "{media_index}",
  "rating_key": "{rating_key}",
  "imdb_id": "{imdb_id}",
  "themoviedb_id": "{themoviedb_id}",
  "thetvdb_id": "{thetvdb_id}"
}
```

---

## Web UI

| Page | URL | Description |
|------|-----|-------------|
| Add to Library | `/library` | Browse Overseerr requests and add titles |
| Import | `/import` | Import directly from Sonarr / Radarr |
| Streams | `/streams` | View resolved streams and cached entries |
| Hash Indexer | `/hash-indexer` | See all indexed titles, cached vs missing |
| Hash Log | `/hash-index/log` | Live log of index ADD / HIT / MISS / EVICT events |
| Jobs | `/jobs` | Running and completed resolve jobs |
| Settings | `/settings` | All configuration |

---

## Hash Index

The Hash Index is the source of truth for all media resolution. It maps every Movie, TV Show, Season, and Episode to a ranked list of confirmed-cached AllDebrid hashes.

### Scoring pipeline

Each hash is scored across three stages. Higher score = preferred candidate on play.

| Stage | Max pts | What it checks |
|-------|---------|----------------|
| 1 — Metadata match | 40 | Title in torrent name, year present, quality preference |
| 2 — Pack intelligence | 30 | Series pack > season pack > single episode |
| 3 — File verification | 50 | Confirmed cached on AllDebrid, file size > 4 GB |

### Placeholder rule

A `.mp4` placeholder is written to Plex **only** when the Hash Index has at least one confirmed cached hash for that title. No cached hash = no placeholder = title invisible in Plex until a hash is found.

### Background growth

- On add: Prowlarr is searched immediately, results checked against AllDebrid
- Every 6 hours: stale hashes are re-verified against AllDebrid (newly cached → score boosted, evicted → marked uncached)
- On play miss: live Prowlarr search runs, index updated, resolve retried

---

## Directory Structure

```
/docker/debridarr/
├── app/                    # Application code
├── data/                   # SQLite database + config
│   ├── debridarr.db        # Cache, library, hash index, settings
│   └── .env                # Runtime config (written by setup wizard)
├── plex-strm/
│   ├── movies/             # Movie .mp4 placeholders + symlinks
│   └── tv/                 # TV .mp4 placeholders + symlinks
├── mnt-alldebrid/          # FUSE virtual filesystem
│   └── <torrent>/
│       └── <file.mkv>      # Streamed on-demand from AllDebrid CDN
├── tmp/
│   └── cache/              # DFS chunk cache
├── config/tautulli/
├── docker-compose.yml
├── Dockerfile
└── entrypoint.sh
```

---

## Settings Reference

All settings are configured through the web UI at `/settings` and stored in the database. Environment variables are seeded into the database on first run only.

### Connections

| Setting | Description |
|---------|-------------|
| AllDebrid API Key | From [alldebrid.com/apikeys](https://alldebrid.com/apikeys) |
| Prowlarr URL | e.g. `http://prowlarr:9696` — aggregate Torznab source |
| Prowlarr API Key | Prowlarr → Settings → General → API Key |
| Overseerr URL | e.g. `http://overseerr:5055` |
| Overseerr API Key | Overseerr → Settings → General → API Key |
| Sonarr URL + Key | Optional — enables Import page |
| Radarr URL + Key | Optional — enables Import page |
| TMDB API Key | Optional — used for poster images |
| Debridarr Base URL | URL Plex uses to reach Debridarr, e.g. `http://192.168.1.x:7474` |
| Plex Library Path | Path inside container, default `/plex-strm` |

### Library behaviour

| Setting | Default | Description |
|---------|---------|-------------|
| Pre-cache on add | On | Search Prowlarr and check AllDebrid when a title is added. Off = index only on play miss. |
| Auto-add approved requests | Off | Automatically add Overseerr approved requests to the library |
| Auto-add interval | 60 min | How often to poll Overseerr for new approved requests |
| Include unreleased episodes | Off | Create placeholders for unaired episodes |
| Include unreleased movies | Off | Add movies before their release date |

### Torrent search

| Setting | Default | Options |
|---------|---------|---------|
| Completed series strategy | Series pack | Series pack, Season pack, Per episode |
| Ongoing series strategy | Season pack | Season pack, Per episode, Series pack |
| Series preferred quality | 1080p | 1080p, 720p, Any |
| Movie preferred quality | 1080p | 1080p, 720p, Any |
| Series quality fallback | Yes | Fall back to any quality if preferred not found |
| Movie quality fallback | Yes | Fall back to any quality if preferred not found |
| Cache TTL | 30 days | Days before a resolved stream expires |
| Hash Index TTL | 6 months | Remove hashes unused for playback after this period |

### DFS chunk cache

| Setting | Default | Description |
|---------|---------|-------------|
| Cache directory | `/docker/debridarr/tmp/cache` | Where CDN chunks are stored locally |
| Disk cache size | 30 GB | Maximum cache size before cleanup |
| Cache expiry | 24 h | How long to keep chunks |
| Chunk size | 8 MB | Fetch unit from AllDebrid CDN |
| Read ahead | 500 MB | Pre-fetch buffer for smooth playback |
| Cleanup interval | 20 min | How often to enforce size limits |

---

## Environment Variables

These are read on first run to seed the database. After that, use the Settings UI.

| Variable | Description |
|----------|-------------|
| `ALLDEBRID_API_KEY` | AllDebrid API key |
| `OVERSEERR_URL` | e.g. `http://192.168.1.x:5055` |
| `OVERSEERR_API_KEY` | Overseerr API key |
| `DEBRIDARR_BASE_URL` | URL Plex uses to reach Debridarr |
| `PLEX_ROOT` | Library path inside container (default `/plex-strm`) |
| `FUSE_MOUNT` | FUSE mount point (default `/docker/debridarr/mnt-alldebrid`) |
| `FUSE_SYMLINK_ROOT` | Host path for FUSE symlinks (default `/docker/debridarr/mnt-alldebrid`) |
| `CACHE_TTL_DAYS` | Stream cache TTL in days (default `30`) |
| `LOG_LEVEL` | `INFO` or `DEBUG` (default `INFO`) |
| `TZ` | Timezone, e.g. `America/New_York` |
| `PUID` / `PGID` | User/group ID for file permissions (default `1000`) |

---

## Ports

| Port | Service |
|------|---------|
| 7474 | Debridarr UI and webhook |
| 8181 | Tautulli |

---

## Troubleshooting

**Title added but not appearing in Plex**
The Hash Index found no cached hash on AllDebrid for this title. Check the Hash Indexer page (`/hash-indexer`) — it will show as Missing. Either the torrent isn't cached on AllDebrid yet, or Prowlarr couldn't find it. Try Re-index from the Hash Indexer detail view.

**Pressing play does nothing / immediate error**
The Hash Index has no hit and the live Prowlarr search also found nothing. Check `/hash-index/log` for MISS events. Verify Prowlarr URL and API key in Settings.

**FUSE not available**
The container needs `cap_add: SYS_ADMIN` and `/dev/fuse` device access. Check `docker-compose.yml` — both are included by default. Some hosts require `security_opt: apparmor:unconfined`.

**Symlinks broken after restart**
Debridarr automatically restores symlinks on startup by matching existing DB entries to the FUSE mount. If a torrent was removed from AllDebrid during downtime it will re-resolve on next play.

**Hash Index empty after adding titles**
Check that Prowlarr URL and API key are set in Settings. Pre-cache must be enabled. Check `/hash-index/log` for errors.
