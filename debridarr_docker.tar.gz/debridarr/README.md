# Debridarr minimal rebuild

This build intentionally contains only:

- Streams page/API
- Settings page/API
- FUSE mount status page/API

## Key behavior

- Sonarr/Radarr can create symlinks through `POST /api/streams`.
- Symlinks expire after `SYMLINK_TTL_DAYS` days, default `30`.
- Expired symlinks are removed by `POST /api/streams/cleanup` and also on startup/list.
- Placeholders are only created by `POST /api/interactive-search/placeholders` when the request includes at least one interactive search result.
- No hash index, no old dashboard, no cached index files.

## Example create symlink

```bash
curl -X POST http://localhost:7474/api/streams \
  -H 'Content-Type: application/json' \
  -d '{
    "arr":"sonarr",
    "media_type":"episode",
    "title":"Friends",
    "season":1,
    "episode":1,
    "source_path":"/mnt/debrid/Friends/S01E01.mkv"
  }'
```

## Example interactive placeholder

No placeholder is created unless `results` is non-empty.

```bash
curl -X POST http://localhost:7474/api/interactive-search/placeholders \
  -H 'Content-Type: application/json' \
  -d '{
    "arr":"sonarr",
    "media_type":"episode",
    "title":"Friends",
    "season":1,
    "episode":1,
    "results":[{"title":"Friends S01E01 1080p", "guid":"example"}]
  }'
```
