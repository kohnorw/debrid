"""Setup wizard helpers for Debridarr."""
import logging
from pathlib import Path
import httpx

log = logging.getLogger("debridarr.setup")

DATA_DIR   = Path("/data")
ENV_PATH   = DATA_DIR / ".env"
SETUP_FLAG = DATA_DIR / ".setup_complete"

STEPS = ["welcome", "alldebrid", "overseerr", "plex", "confirm"]


def is_setup_complete() -> bool:
    try:
        return SETUP_FLAG.exists()
    except Exception:
        return False


def mark_setup_complete():
    try:
        SETUP_FLAG.parent.mkdir(parents=True, exist_ok=True)
        SETUP_FLAG.touch()
    except Exception as e:
        log.error(f"Could not write setup flag: {e}")


def load_saved_config() -> dict:
    cfg = {}
    try:
        if ENV_PATH.exists():
            for line in ENV_PATH.read_text().splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, _, v = line.partition("=")
                cfg[k.strip()] = v.strip()
    except Exception:
        pass
    return cfg


def write_env(config: dict):
    try:
        ENV_PATH.parent.mkdir(parents=True, exist_ok=True)
        lines = [
            f"ALLDEBRID_API_KEY={config.get('ALLDEBRID_API_KEY', '')}",
            f"OVERSEERR_URL={config.get('OVERSEERR_URL', '')}",
            f"OVERSEERR_API_KEY={config.get('OVERSEERR_API_KEY', '')}",
            f"PLEX_ROOT={config.get('PLEX_ROOT', '/plex-strm')}",
            f"DEBRIDARR_BASE_URL={config.get('DEBRIDARR_BASE_URL', '')}",
            f"CACHE_TTL_DAYS={config.get('CACHE_TTL_DAYS', '30')}",
            f"FUSE_MOUNT={config.get('FUSE_MOUNT', '/docker/debridarr/mnt-alldebrid')}",
            f"FUSE_SYMLINK_ROOT={config.get('FUSE_SYMLINK_ROOT', '/docker/debridarr/mnt-alldebrid')}",
        ]
        ENV_PATH.write_text("\n".join(lines) + "\n")
        log.info(f"Wrote config to {ENV_PATH}")
    except Exception as e:
        log.error(f"Failed to write .env: {e}")


async def test_alldebrid(api_key: str) -> tuple[bool, str]:
    try:
        async with httpx.AsyncClient(timeout=10) as c:
            r = await c.get(
                "https://api.alldebrid.com/v4/user",
                params={"agent": "debridarr", "apikey": api_key},
            )
            d = r.json()
            if d.get("status") == "success":
                username = d["data"]["user"].get("username", "")
                return True, f"Connected as {username}"
            return False, d.get("error", {}).get("message", "Invalid API key")
    except Exception as e:
        return False, str(e)


async def test_overseerr(url: str, api_key: str) -> tuple[bool, str]:
    try:
        async with httpx.AsyncClient(timeout=10) as c:
            r = await c.get(
                f"{url.rstrip('/')}/api/v1/auth/me",
                headers={"X-Api-Key": api_key},
            )
            if r.status_code == 200:
                d = r.json()
                return True, f"Connected as {d.get('displayName', d.get('email', 'user'))}"
            return False, f"HTTP {r.status_code}"
    except Exception as e:
        return False, str(e)


async def test_plex_root(path: str) -> tuple[bool, str]:
    try:
        p = Path(path)
        p.mkdir(parents=True, exist_ok=True)
        if p.is_dir():
            return True, f"Directory ready: {path}"
        return False, f"Not a directory: {path}"
    except Exception as e:
        return False, str(e)

