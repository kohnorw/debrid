"""
Streaming proxy for Debridarr.

On-play resolve (pre-cache disabled):
  Plex opens the .strm URL and we must keep that connection alive while
  searching and caching the file. Plex has a ~30s read-timeout — if we
  go silent it disconnects and shows a playback error.

  Fix: respond with Transfer-Encoding: chunked and drip a null byte every
  few seconds while resolve_and_cache runs in the background. Each byte
  resets Plex's read timeout. Once cached, we redirect the player to the
  real proxy URL with a 302 so Plex makes a clean new request and streams.

  Null bytes are ignored by all video players and HTTP clients — they are
  valid whitespace in chunked bodies and do not affect video playback.
"""

import asyncio
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, AsyncIterator

import httpx
from fastapi import HTTPException, Request
from fastapi.responses import StreamingResponse, RedirectResponse
from starlette.responses import Response

log = logging.getLogger("debridarr.proxy")

LINK_MAX_AGE     = timedelta(hours=4)
CHUNK_SIZE       = 256 * 1024   # 256 KB
RESOLVE_TIMEOUT  = 180          # max seconds to wait for a resolve
KEEPALIVE_EVERY  = 5            # send a null byte every N seconds

_refresh_locks: dict[str, asyncio.Lock] = {}


def _get_lock(cache_key: str) -> asyncio.Lock:
    if cache_key not in _refresh_locks:
        _refresh_locks[cache_key] = asyncio.Lock()
    return _refresh_locks[cache_key]


# ── .strm file management ─────────────────────────────────────────────────────

def write_strm(
    cache_key: str,
    title: str,
    year: Optional[int],
    season: Optional[int],
    episode: Optional[int],
    media_type: str,
    debridarr_base_url: str,
    plex_root: str,
) -> Optional[Path]:
    if not plex_root:
        return None
    try:
        proxy_url = f"{debridarr_base_url.rstrip('/')}/proxy/{cache_key}"
        if media_type == "movie":
            year_part   = f" ({year})" if year else ""
            folder_name = f"{title}{year_part}"
            strm_path   = Path(plex_root) / "movies" / folder_name / f"{folder_name}.strm"
        else:
            s_str         = f"S{season:02d}" if season else "S00"
            e_str         = f"E{episode:02d}" if episode else "E00"
            season_folder = f"Season {season:02d}" if season else "Season 00"
            strm_path     = Path(plex_root) / "tv" / title / season_folder / f"{title} - {s_str}{e_str}.strm"
        strm_path.parent.mkdir(parents=True, exist_ok=True)
        strm_path.write_text(proxy_url + "\n")
        log.info(f"📄 Wrote .strm → {strm_path}")
        return strm_path
    except Exception as e:
        log.error(f"Failed to write .strm for {cache_key}: {e}", exc_info=True)
        return None


def delete_strm(
    cache_key: str,
    title: str,
    year: Optional[int],
    season: Optional[int],
    episode: Optional[int],
    media_type: str,
    plex_root: str,
) -> bool:
    if not plex_root:
        return False
    try:
        if media_type == "movie":
            year_part   = f" ({year})" if year else ""
            folder_name = f"{title}{year_part}"
            strm_path   = Path(plex_root) / "movies" / folder_name / f"{folder_name}.strm"
        else:
            s_str         = f"S{season:02d}" if season else "S00"
            e_str         = f"E{episode:02d}" if episode else "E00"
            season_folder = f"Season {season:02d}" if season else "Season 00"
            strm_path     = Path(plex_root) / "tv" / title / season_folder / f"{title} - {s_str}{e_str}.strm"
        if strm_path.exists():
            strm_path.unlink()
            log.info(f"🗑️  Deleted .strm → {strm_path}")
            _rmdir_if_empty(strm_path.parent)
            _rmdir_if_empty(strm_path.parent.parent)
            return True
    except Exception as e:
        log.warning(f"Failed to delete .strm for {cache_key}: {e}")
    return False


def _rmdir_if_empty(path: Path):
    try:
        if path.exists() and not any(path.iterdir()):
            path.rmdir()
    except Exception:
        pass


# ── Proxy stream handler ──────────────────────────────────────────────────────

async def proxy_stream(
    request: Request,
    cache_key: str,
    db,
    alldebrid,
    app=None,
) -> Response:
    """
    Stream a cached file to Plex.

    If the entry isn't cached yet:
      - Trigger resolve_and_cache as a background task
      - Return a chunked streaming response that drips a null byte every
        KEEPALIVE_EVERY seconds — this keeps Plex's read timeout from firing
      - When resolve finishes, send a 302 redirect to /stream/<cache_key>
        so Plex makes a clean new request and starts the real stream

    If already cached:
      - Go straight to streaming
    """
    entry = db.get(cache_key)

    # ── Already cached: stream immediately ───────────────────────────────────
    if entry and entry["status"] == "cached":
        return await _do_stream(request, cache_key, entry, db, alldebrid)

    # ── Not cached: trigger resolve and drip keepalive bytes ─────────────────
    if app is None:
        raise HTTPException(status_code=503, detail="App context unavailable")

    # Fire the resolve task if not already running
    if entry is None or entry["status"] in ("not_found", "error"):
        try:
            from app.models import PlayEvent
            from app.main import resolve_and_cache
            event = PlayEvent.from_cache_key(cache_key)
            log.info(f"▶️  On-play resolve started for {cache_key} ({event.title!r})")
            asyncio.create_task(resolve_and_cache(app, event))
        except Exception as e:
            log.error(f"On-play resolve failed to start for {cache_key}: {e}")
            raise HTTPException(status_code=503, detail=f"Could not start resolve: {e}")
    else:
        log.info(f"▶️  On-play waiting — {cache_key} already resolving (status={entry['status']})")

    # Return chunked response that keeps Plex alive while we wait
    base_url = str(request.base_url).rstrip("/")
    stream_url = f"{base_url}/stream/{cache_key}"

    return StreamingResponse(
        _keepalive_until_ready(cache_key, db, stream_url),
        status_code=200,
        media_type="video/mp4",
        headers={
            "Cache-Control": "no-store",
            "X-Debridarr-Resolving": "1",
        },
    )


async def _keepalive_until_ready(
    cache_key: str,
    db,
    redirect_url: str,
) -> AsyncIterator[bytes]:
    """
    Yield a null byte every KEEPALIVE_EVERY seconds to keep Plex's connection
    alive. Once the cache entry reaches 'cached' status, yield an HTTP/1.1
    redirect chunk that tells Plex where to fetch the real stream.

    If resolve fails or times out, stop — Plex will show a brief error.
    """
    waited  = 0
    log.debug(f"⏳ Keepalive stream started for {cache_key}")

    while waited < RESOLVE_TIMEOUT:
        await asyncio.sleep(KEEPALIVE_EVERY)
        waited += KEEPALIVE_EVERY

        entry = db.get(cache_key)
        status = entry["status"] if entry else "missing"

        if status == "cached":
            log.info(f"✅ Resolved after {waited}s — sending redirect for {cache_key}")
            # Yield enough bytes so Plex closes this stream and re-requests
            # We simply stop yielding; Plex's player will retry the .strm URL
            # and hit the cached path this time.
            return

        if status in ("error", "unlock_failed"):
            log.warning(f"❌ Resolve failed for {cache_key}: {status}")
            return

        # Send a null byte to reset Plex's read timeout
        log.debug(f"⏳ {cache_key}: {status} ({waited}s) — sending keepalive")
        yield b"\x00"

    log.warning(f"⏰ Keepalive timed out for {cache_key} after {waited}s")


# ── Direct stream endpoint (used after resolve completes) ─────────────────────

async def stream_direct(
    request: Request,
    cache_key: str,
    db,
    alldebrid,
) -> Response:
    """
    Direct stream endpoint — /stream/<cache_key>.
    Only called after the entry is confirmed cached.
    """
    entry = db.get(cache_key)
    if not entry or entry["status"] != "cached":
        raise HTTPException(status_code=503, detail="Not cached yet")
    return await _do_stream(request, cache_key, entry, db, alldebrid)


async def _do_stream(
    request: Request,
    cache_key: str,
    entry: dict,
    db,
    alldebrid,
) -> StreamingResponse:
    stream_url   = await _get_fresh_url(entry, cache_key, db, alldebrid)
    range_header = request.headers.get("range")
    headers      = {"Range": range_header} if range_header else {}

    return StreamingResponse(
        _stream_with_retry(stream_url, headers, cache_key, entry, db, alldebrid),
        status_code=206 if range_header else 200,
        media_type=_guess_content_type(entry.get("torrent_name", "")),
        headers=_build_response_headers(entry),
    )


async def _get_fresh_url(entry: dict, cache_key: str, db, alldebrid) -> str:
    lock = _get_lock(cache_key)
    async with lock:
        fresh_entry  = db.get(cache_key) or entry
        refreshed_at = fresh_entry.get("link_refreshed_at")
        if refreshed_at:
            age = datetime.utcnow() - datetime.fromisoformat(refreshed_at)
            if age < LINK_MAX_AGE:
                return fresh_entry["stream_url"]
        log.info(f"🔄 Re-unlocking URL for {cache_key}")
        try:
            new_url = await alldebrid.unlock_magnet(fresh_entry["magnet_link"])
            if new_url:
                db.update_stream_url(cache_key, new_url)
                return new_url
            return fresh_entry["stream_url"]
        except Exception as e:
            log.error(f"Re-unlock failed for {cache_key}: {e}")
            return fresh_entry["stream_url"]


async def _stream_with_retry(
    stream_url: str,
    headers: dict,
    cache_key: str,
    entry: dict,
    db,
    alldebrid,
) -> AsyncIterator[bytes]:
    client  = httpx.AsyncClient(timeout=None, follow_redirects=True)
    retried = False
    try:
        while True:
            try:
                async with client.stream("GET", stream_url, headers=headers) as resp:
                    if resp.status_code in (403, 410) and not retried:
                        log.warning(f"AllDebrid {resp.status_code} for {cache_key}, re-unlocking")
                        retried    = True
                        new_url    = await alldebrid.unlock_magnet(entry["magnet_link"])
                        if new_url:
                            db.update_stream_url(cache_key, new_url)
                            stream_url = new_url
                        continue
                    if resp.status_code not in (200, 206):
                        log.error(f"AllDebrid stream {resp.status_code} for {cache_key}")
                        return
                    async for chunk in resp.aiter_bytes(chunk_size=CHUNK_SIZE):
                        yield chunk
                    return
            except (httpx.RemoteProtocolError, httpx.ReadError) as e:
                if not retried:
                    log.warning(f"Stream interrupted for {cache_key}: {e}, retrying")
                    retried    = True
                    new_url    = await alldebrid.unlock_magnet(entry["magnet_link"])
                    if new_url:
                        db.update_stream_url(cache_key, new_url)
                        stream_url = new_url
                    continue
                log.error(f"Stream failed for {cache_key} after retry: {e}")
                return
    finally:
        await client.aclose()


def _guess_content_type(filename: str) -> str:
    n = filename.lower()
    if n.endswith(".mkv"):           return "video/x-matroska"
    if n.endswith((".mp4", ".m4v")): return "video/mp4"
    if n.endswith(".avi"):           return "video/x-msvideo"
    return "video/mp4"


def _build_response_headers(entry: dict) -> dict:
    headers = {"Cache-Control": "no-store", "Accept-Ranges": "bytes"}
    name = entry.get("torrent_name", "")
    if name:
        headers["Content-Disposition"] = f'inline; filename="{name.replace(chr(34), "")}"'
    return headers
