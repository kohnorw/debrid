"""
indexer.py — Hash index population pipeline.

Two paths feed the index:

1. Background growth — polls Prowlarr/Torznab RSS feeds on a schedule,
   extracts infohashes, checks AllDebrid instant availability, scores
   each result, and upserts into the hash index.

2. Miss-triggered search — called from resolve_on_play() when the index
   has no cached hit. Runs a targeted Prowlarr query for the specific
   media item, populates the index, then the play path retries.

The index is the ONLY consumer of these results. No placeholders are
created here. No torrents are added to AllDebrid here.
"""

from __future__ import annotations

import asyncio
import logging
import re
import time
import xml.etree.ElementTree as ET
from typing import Optional

import httpx

from .hash_index import HashIndex, score_candidate, _norm

log = logging.getLogger("debridarr.indexer")

# ── Helpers ───────────────────────────────────────────────────────────────────

_HASH_RE = re.compile(r"btih:([a-fA-F0-9]{40})", re.I)
_VIDEO_QUALITY_RE = re.compile(r"(2160p|4k|uhd|1080p|720p|480p)", re.I)


def _extract_hash(text: str) -> Optional[str]:
    m = _HASH_RE.search(text or "")
    return m.group(1).lower() if m else None


def _detect_quality(name: str) -> str:
    m = _VIDEO_QUALITY_RE.search(name or "")
    return m.group(1).lower() if m else "unknown"


def _is_pack(name: str) -> tuple[bool, bool]:
    """Return (is_season_pack, is_series_pack)."""
    n = name.upper()
    has_episode = bool(re.search(r"S\d{2}E\d{2}", n))
    has_season  = bool(re.search(r"S\d{2}", n))
    is_series   = not has_season and not has_episode
    is_season   = has_season and not has_episode
    return is_season, is_series


def _media_type_from_torrent(name: str, requested_media_type: str) -> str:
    is_season, is_series = _is_pack(name)
    if requested_media_type == "movie":
        return "movie"
    if is_series:
        return "series"
    if is_season:
        return "season"
    return "episode"


# ── AllDebrid instant availability ────────────────────────────────────────────

async def check_alldebrid_cache(
    client: httpx.AsyncClient,
    api_key: str,
    hashes: list[str],
    *,
    batch_size: int = 50,
) -> set[str]:
    """
    Submit hashes to AllDebrid instant availability endpoint.
    Returns the set of hashes that are confirmed cached.
    No torrents are added to the account.
    """
    cached: set[str] = set()
    for i in range(0, len(hashes), batch_size):
        batch = hashes[i : i + batch_size]
        try:
            params = [("agent", "debridarr"), ("apikey", api_key)]
            for h in batch:
                params.append(("hashes[]", h))
            r = await client.get(
                "https://api.alldebrid.com/v4/magnet/instant",
                params=params,
                timeout=15,
            )
            if r.status_code != 200:
                log.warning(f"AllDebrid instant check HTTP {r.status_code}")
                continue
            data = r.json().get("data", {})
            magnets = data.get("magnets", [])
            for m in magnets:
                if m.get("instant") or m.get("cachedOn") or m.get("magnet", {}).get("instant"):
                    h = (m.get("hash") or "").lower()
                    if h:
                        cached.add(h)
        except Exception as e:
            log.warning(f"AllDebrid instant check batch error: {e}")
        await asyncio.sleep(0.3)
    return cached


# ── Prowlarr / Torznab RSS feed scraping ──────────────────────────────────────

async def query_prowlarr(
    client: httpx.AsyncClient,
    prowlarr_url: str,
    prowlarr_key: str,
    query: str,
    *,
    cat: str = "2000,5000",  # Prowlarr: Movies + TV
    limit: int = 100,
) -> list[dict]:
    """
    Query a Prowlarr/Torznab endpoint. Returns a list of torrent dicts:
        {name, info_hash, magnet, size, seeders, quality}
    """
    results = []
    url = f"{prowlarr_url.rstrip("/")}/api/v1/indexers/all/newznab"
    try:
        r = await client.get(
            url,
            params={
                "apikey": prowlarr_key,
                "t": "search",
                "q": query,
                "cat": cat,
                "limit": limit,
            },
            timeout=20,
        )
        if r.status_code != 200:
            log.warning(f"Prowlarr HTTP {r.status_code} for query {query!r}")
            return []

        root = ET.fromstring(r.content)
        ns   = {"torznab": "http://torznab.com/schemas/2015/feed"}

        for item in root.iter("item"):
            title_el  = item.find("title")
            name      = title_el.text.strip() if title_el is not None and title_el.text else ""
            if not name:
                continue

            # Extract infohash from enclosure url or torznab attr
            info_hash = None
            enclosure = item.find("enclosure")
            if enclosure is not None:
                info_hash = _extract_hash(enclosure.get("url", ""))

            # torznab:attr name="infohash"
            if not info_hash:
                for attr in item.findall("torznab:attr", ns):
                    if attr.get("name") == "infohash":
                        info_hash = (attr.get("value") or "").lower()
                    if attr.get("name") == "magneturl":
                        info_hash = info_hash or _extract_hash(attr.get("value", ""))

            # Magnet link
            magnet = ""
            for attr in item.findall("torznab:attr", ns):
                if attr.get("name") == "magneturl":
                    magnet = attr.get("value", "")
                    break
            if not magnet and info_hash:
                magnet = f"magnet:?xt=urn:btih:{info_hash}&dn={name}"

            if not info_hash or not magnet:
                continue

            # File size
            size = 0
            size_el = item.find("size")
            if size_el is not None and size_el.text:
                try:
                    size = int(size_el.text)
                except ValueError:
                    pass
            if not size and enclosure is not None:
                try:
                    size = int(enclosure.get("length", 0))
                except ValueError:
                    pass

            # Seeders
            seeders = 0
            for attr in item.findall("torznab:attr", ns):
                if attr.get("name") == "seeders":
                    try:
                        seeders = int(attr.get("value", 0))
                    except ValueError:
                        pass

            results.append({
                "name":      name,
                "info_hash": info_hash.lower(),
                "magnet":    magnet,
                "size":      size,
                "seeders":   seeders,
                "quality":   _detect_quality(name),
            })

    except ET.ParseError as e:
        log.warning(f"Prowlarr XML parse error ({query!r}): {e}")
    except Exception as e:
        log.warning(f"Prowlarr query error ({query!r}): {e}")

    return results


# ── Index a movie ─────────────────────────────────────────────────────────────

async def index_movie(
    hi: HashIndex,
    *,
    prowlarr_url: str,
    prowlarr_key: str,
    api_key: str,
    title: str,
    year: Optional[int],
    preferred_quality: str = "1080p",
) -> int:
    """
    Search Prowlarr for a movie, check AllDebrid cache, upsert scored entries.
    Returns the count of cached hashes stored.
    """
    queries = [f"{title} {year}" if year else title]
    if year:
        queries.append(title)  # fallback without year

    async with httpx.AsyncClient() as client:
        seen_hashes: set[str] = set()
        candidates = []

        for q in queries:
            results = await query_prowlarr(client, prowlarr_url, prowlarr_key, q)
            for r in results:
                h = r["info_hash"]
                if h not in seen_hashes:
                    seen_hashes.add(h)
                    candidates.append(r)
            if candidates:
                break  # first query gave results
            await asyncio.sleep(0.5)

        if not candidates:
            log.debug(f"[MOVIE] No Prowlarr results for {title!r}")
            return 0

        # AllDebrid instant availability check
        hashes     = [c["info_hash"] for c in candidates]
        cached_set = await check_alldebrid_cache(client, api_key, hashes)

        stored = 0
        for c in candidates:
            h = c["info_hash"]
            is_cached = h in cached_set
            pts = hi.upsert(
                media_type="movie",
                title=title,
                year=year,
                season=None,
                episode=None,
                info_hash=h,
                magnet=c["magnet"],
                torrent_name=c["name"],
                quality=c["quality"],
                strategy="movie",
                is_cached=is_cached,
                file_size=c["size"],
                preferred_quality=preferred_quality,
            )
            if is_cached:
                stored += 1
            log.debug(f"  [MOVIE] {c['name'][:60]} cached={is_cached} score={pts}")

        return stored


# ── Index a series ────────────────────────────────────────────────────────────

async def index_series(
    hi: HashIndex,
    *,
    prowlarr_url: str,
    prowlarr_key: str,
    api_key: str,
    title: str,
    year: Optional[int],
    season_count: int,
    is_ended: bool,
    preferred_quality: str = "1080p",
) -> dict:
    """
    Search Prowlarr for series packs and each season pack.
    Check AllDebrid cache, upsert scored entries.
    Returns {"series_packs": N, "season_packs": N, "episodes": N}.
    """
    counts = {"series_packs": 0, "season_packs": 0, "episodes": 0}

    async with httpx.AsyncClient() as client:
        # Series pack first (highest value)
        sp_results = await query_prowlarr(
            client, prowlarr_url, prowlarr_key,
            f"{title} complete series" if year is None else f"{title} {year} complete",
        )
        if not sp_results:
            sp_results = await query_prowlarr(
                client, prowlarr_url, prowlarr_key, f"{title} complete",
            )

        series_hashes = [r["info_hash"] for r in sp_results]
        series_cached = await check_alldebrid_cache(client, api_key, series_hashes) if series_hashes else set()
        for r in sp_results:
            mt   = _media_type_from_torrent(r["name"], "episode")
            is_c = r["info_hash"] in series_cached
            hi.upsert(
                media_type=mt,
                title=title, year=year,
                season=None, episode=None,
                info_hash=r["info_hash"], magnet=r["magnet"],
                torrent_name=r["name"], quality=r["quality"],
                strategy="series_pack", is_cached=is_c,
                file_size=r["size"], preferred_quality=preferred_quality,
            )
            if is_c and mt == "series":
                counts["series_packs"] += 1

        await asyncio.sleep(0.5)

        # Season packs
        for sn in range(1, min(season_count + 1, 30)):
            sn_results = await query_prowlarr(
                client, prowlarr_url, prowlarr_key,
                f"{title} season {sn}",
            )
            if not sn_results:
                sn_results = await query_prowlarr(
                    client, prowlarr_url, prowlarr_key,
                    f"{title} S{sn:02d}",
                )

            sn_hashes = [r["info_hash"] for r in sn_results]
            sn_cached = await check_alldebrid_cache(client, api_key, sn_hashes) if sn_hashes else set()
            for r in sn_results:
                mt   = _media_type_from_torrent(r["name"], "episode")
                is_c = r["info_hash"] in sn_cached
                hi.upsert(
                    media_type=mt,
                    title=title, year=year,
                    season=sn, episode=None,
                    info_hash=r["info_hash"], magnet=r["magnet"],
                    torrent_name=r["name"], quality=r["quality"],
                    strategy="season_pack", is_cached=is_c,
                    file_size=r["size"], preferred_quality=preferred_quality,
                )
                if is_c and mt == "season":
                    counts["season_packs"] += 1

            await asyncio.sleep(0.3)

    log.info(f"[SERIES] {title!r} indexed: {counts}")
    return counts


# ── Miss-triggered targeted search ───────────────────────────────────────────

async def search_and_index(
    hi: HashIndex,
    *,
    prowlarr_url: str,
    prowlarr_key: str,
    api_key: str,
    title: str,
    year: Optional[int],
    media_type: str,
    season: Optional[int] = None,
    episode: Optional[int] = None,
    preferred_quality: str = "1080p",
) -> int:
    """
    Targeted search triggered when the index misses on a play request.
    Populates the index then returns the count of cached hits found.
    The caller retries lookup() after this returns.
    """
    if media_type == "movie":
        return await index_movie(
            hi,
            prowlarr_url=prowlarr_url,
            prowlarr_key=prowlarr_key,
            api_key=api_key,
            title=title,
            year=year,
            preferred_quality=preferred_quality,
        )

    # Episode — try season pack first, then series pack, then episode
    queries = []
    if season:
        queries.append((f"{title} S{season:02d}", season, None, "season_pack"))
        queries.append((f"{title} season {season}", season, None, "season_pack"))
    queries.append((f"{title} complete", None, None, "series_pack"))
    if season and episode:
        queries.append((f"{title} S{season:02d}E{episode:02d}", season, episode, "episode"))

    total_cached = 0
    async with httpx.AsyncClient() as client:
        seen: set[str] = set()
        for query, sn, ep, strategy in queries:
            results = await query_prowlarr(client, prowlarr_url, prowlarr_key, query)
            if not results:
                await asyncio.sleep(0.3)
                continue

            new = [r for r in results if r["info_hash"] not in seen]
            if not new:
                continue
            for r in new:
                seen.add(r["info_hash"])

            hashes = [r["info_hash"] for r in new]
            cached_set = await check_alldebrid_cache(client, api_key, hashes)
            for r in new:
                is_c = r["info_hash"] in cached_set
                mt   = _media_type_from_torrent(r["name"], "episode")
                hi.upsert(
                    media_type=mt,
                    title=title, year=year,
                    season=sn, episode=ep,
                    info_hash=r["info_hash"], magnet=r["magnet"],
                    torrent_name=r["name"], quality=r["quality"],
                    strategy=strategy, is_cached=is_c,
                    file_size=r["size"], preferred_quality=preferred_quality,
                )
                if is_c:
                    total_cached += 1

            if total_cached > 0:
                break  # found cached content — stop searching
            await asyncio.sleep(0.4)

    return total_cached


# ── Background recheck loop ───────────────────────────────────────────────────

async def recheck_stale(
    hi: HashIndex,
    api_key: str,
    limit: int = 200,
    older_than_hours: int = 6,
) -> dict:
    """
    Re-verify stale hashes against AllDebrid. Updates is_cached and score.
    Called by the background recheck loop every 6 hours.
    Returns {rechecked, now_cached, evicted}.
    """
    stale = hi.get_stale(older_than_hours=older_than_hours, limit=limit)
    if not stale:
        return {"rechecked": 0, "now_cached": 0, "evicted": 0}

    hashes = [r["info_hash"] for r in stale]
    async with httpx.AsyncClient() as client:
        cached_set = await check_alldebrid_cache(client, api_key, hashes)

    now_cached = 0
    evicted    = 0
    for row in stale:
        h          = row["info_hash"]
        was_cached = bool(row["is_cached"])
        is_cached  = h in cached_set
        if is_cached and not was_cached:
            hi.mark_cached(h)
            now_cached += 1
        elif was_cached and not is_cached:
            hi.mark_uncached(h)
            evicted += 1
        else:
            # Just refresh the last_checked timestamp
            hi.upsert(
                media_type=row["media_type"],
                title=row["title"],
                year=row["year"],
                season=row["season"],
                episode=row["episode"],
                info_hash=h,
                magnet=row["magnet"],
                torrent_name=row["torrent_name"] or "",
                quality=row["quality"] or "unknown",
                strategy=row["strategy"] or "unknown",
                is_cached=is_cached,
                file_count=row.get("file_count", 1),
                file_size=row.get("file_size", 0),
            )

    log.info(
        f"[RECHECK] {len(stale)} stale hashes: "
        f"{now_cached} newly cached, {evicted} evicted"
    )
    return {"rechecked": len(stale), "now_cached": now_cached, "evicted": evicted}
