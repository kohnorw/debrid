"""
indexer.py — Hash index population pipeline.

Two paths feed the index:

1. Background growth — polls Prowlarr/Torznab RSS feeds on a schedule,
   extracts infohashes, checks AllDebrid instant availability, scores
   each result, and upserts into the hash index.

2. Miss-triggered search — called from resolve_on_play() when the index
   has no cached hit. Runs a targeted Prowlarr query for the specific
   media item, populates the index, then the play path retries.

The index is the ONLY consumer of these results. No placeholders are
created here. No torrents are added to AllDebrid here.
"""

from __future__ import annotations

import asyncio
import logging
import re
import time
from typing import Optional

import httpx

from .hash_index import HashIndex, score_candidate, _norm

log = logging.getLogger("debridarr.indexer")

# ── Helpers ───────────────────────────────────────────────────────────────────

_HASH_RE = re.compile(r"btih:([a-fA-F0-9]{40})", re.I)
_VIDEO_QUALITY_RE = re.compile(r"(2160p|4k|uhd|1080p|720p|480p)", re.I)


def _extract_hash(text: str) -> Optional[str]:
    m = _HASH_RE.search(text or "")
    return m.group(1).lower() if m else None


def _detect_quality(name: str) -> str:
    m = _VIDEO_QUALITY_RE.search(name or "")
    return m.group(1).lower() if m else "unknown"


def _is_pack(name: str) -> tuple[bool, bool]:
    """Return (is_season_pack, is_series_pack)."""
    n = name.upper()
    has_episode = bool(re.search(r"S\d{2}E\d{2}", n))
    has_season  = bool(re.search(r"S\d{2}", n))
    is_series   = not has_season and not has_episode
    is_season   = has_season and not has_episode
    return is_season, is_series


_TRACKERS = (
    "udp://open.tracker.cl:1337/announce",
    "udp://tracker.opentrackr.org:1337/announce",
    "udp://tracker.openbittorrent.com:6969/announce",
    "udp://exodus.desync.com:6969/announce",
    "udp://tracker.torrent.eu.org:451/announce",
)


def _build_magnet(info_hash: str, name: str, existing_magnet: str = "") -> str:
    """
    Return a valid magnet URI for the given infohash.

    If `existing_magnet` already starts with 'magnet:?xt=urn:btih:' it is
    returned as-is (it's a real magnet, not a proxy URL).
    Otherwise we construct one from the hash + name + standard trackers so
    AllDebrid can always resolve it.
    """
    if existing_magnet and existing_magnet.startswith("magnet:?xt=urn:btih:"):
        return existing_magnet
    # Construct from scratch — proxy/download URLs are not valid magnets
    import urllib.parse as _up
    dn      = _up.quote(name, safe="")
    tr_part = "".join(f"&tr={_up.quote(t, safe='')}" for t in _TRACKERS)
    return f"magnet:?xt=urn:btih:{info_hash}&dn={dn}{tr_part}"


def _media_type_from_torrent(name: str, requested_media_type: str) -> str:
    is_season, is_series = _is_pack(name)
    if requested_media_type == "movie":
        return "movie"
    if is_series:
        return "series"
    if is_season:
        return "season"
    return "episode"


# ── AllDebrid instant availability ────────────────────────────────────────────

async def check_alldebrid_cache(
    client: httpx.AsyncClient,
    api_key: str,
    hashes: list[str],
    *,
    batch_size: int = 50,
) -> set[str]:
    """
    Check which hashes are cached on AllDebrid using the upload→ready→delete pattern.

    Uses the same proven approach as alldebrid.py:
      1. POST hashes as magnets to /magnet/upload with Bearer auth
      2. AllDebrid returns ready=true/false instantly for each hash
      3. DELETE all probe IDs immediately — nothing left in the account

    /magnet/instant does not exist. /magnet/upload is the correct endpoint.
    """
    import urllib.parse as _ul

    ad_upload = "https://api.alldebrid.com/v4/magnet/upload"
    ad_delete = "https://api.alldebrid.com/v4/magnet/delete"
    headers   = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type":  "application/x-www-form-urlencoded",
    }

    cached: set[str] = set()

    for i in range(0, len(hashes), batch_size):
        batch = hashes[i : i + batch_size]
        try:
            # Build magnet URIs from raw hashes
            magnets = [_build_magnet(h, "") for h in batch]
            body    = _ul.urlencode([("magnets[]", m) for m in magnets])

            r = await client.post(ad_upload, headers=headers, content=body, timeout=20)
            if r.status_code != 200:
                log.warning(f"AllDebrid upload HTTP {r.status_code} — body: {r.text[:200]!r}")
                continue

            result   = r.json()
            if result.get("status") != "success":
                log.warning(f"AllDebrid upload error: {result.get('error', {})}")
                continue

            ids_to_delete = []
            for m in result.get("data", {}).get("magnets", []):
                if m.get("error"):
                    continue
                h = (m.get("hash") or "").lower()
                if h and m.get("ready"):
                    cached.add(h)
                if m.get("id"):
                    ids_to_delete.append(str(m["id"]))

            # Delete all probe IDs — keep account clean
            for mid in ids_to_delete:
                try:
                    del_body = _ul.urlencode({"id": mid})
                    await client.post(ad_delete, headers=headers, content=del_body, timeout=10)
                except Exception:
                    pass

            log.debug(
                f"AllDebrid cache check: {len(cached)}/{len(batch)} cached in batch, "
                f"{len(ids_to_delete)} probe IDs deleted"
            )

        except Exception as e:
            log.warning(f"AllDebrid cache check batch error: {e}")

        await asyncio.sleep(0.3)

    return cached


# ── Prowlarr / Torznab RSS feed scraping ──────────────────────────────────────

_PROWLARR_INDEXER_CACHE: dict[str, tuple[float, list[int]]] = {}
_PROWLARR_INDEXER_TTL = 3600  # refresh hourly


async def get_prowlarr_indexer_ids(
    client: httpx.AsyncClient,
    prowlarr_url: str,
    prowlarr_key: str,
    *,
    force_refresh: bool = False,
) -> list[int]:
    """
    Return the list of enabled indexer IDs from Prowlarr.

    Why this exists: passing `indexerIds=[-1]` to /api/v1/search means
    "indexer with id -1" — which is no indexer — so newer Prowlarr versions
    return zero or a 400 "all indexers being unavailable". Older versions
    accepted -1 as a "wildcard"; that was an accident, not a contract.
    The correct API contract is to pass actual enabled indexer IDs.

    Cached for 1 h. Force-refresh on auth errors / config changes.
    """
    cache_key = f"{prowlarr_url}|{prowlarr_key[:8]}"
    now = time.time()
    if not force_refresh:
        hit = _PROWLARR_INDEXER_CACHE.get(cache_key)
        if hit and now - hit[0] < _PROWLARR_INDEXER_TTL:
            return list(hit[1])

    url = f"{prowlarr_url.rstrip('/')}/api/v1/indexer"
    try:
        r = await client.get(
            url, headers={"X-Api-Key": prowlarr_key}, timeout=15,
        )
        if r.status_code != 200:
            log.warning(
                f"Prowlarr /indexer returned HTTP {r.status_code}: "
                f"{r.text[:200]!r} — cannot enumerate indexers"
            )
            _PROWLARR_INDEXER_CACHE[cache_key] = (now, [])
            return []
        indexers = r.json() or []
    except Exception as e:
        log.warning(f"Prowlarr /indexer fetch failed: {e}")
        return []

    enabled_ids: list[int] = []
    for ix in indexers:
        # `enable` is the master toggle; older Prowlarr used `enableRss`/
        # `enableAutomaticSearch`/`enableInteractiveSearch` separately —
        # accept the indexer if ANY search-related flag is on.
        on = (
            ix.get("enable", True)
            and (
                ix.get("enableAutomaticSearch", True)
                or ix.get("enableInteractiveSearch", True)
                or ix.get("enableRss", True)
            )
        )
        iid = ix.get("id")
        if on and isinstance(iid, int):
            enabled_ids.append(iid)

    log.info(
        f"Prowlarr: {len(enabled_ids)} enabled indexer(s) — "
        f"ids={enabled_ids[:10]}{'…' if len(enabled_ids) > 10 else ''}"
    )
    _PROWLARR_INDEXER_CACHE[cache_key] = (now, enabled_ids)
    return enabled_ids


async def query_prowlarr(
    client: httpx.AsyncClient,
    prowlarr_url: str,
    prowlarr_key: str,
    query: str,
    *,
    cat: str = "2000,5000",  # Prowlarr: Movies + TV (NewzNab category codes)
    limit: int = 100,
) -> list[dict]:
    """
    Query Prowlarr's native /api/v1/search JSON endpoint (aggregate across all
    ENABLED indexers).

    Returns a list of torrent dicts: {name, info_hash, magnet, size, seeders, quality}.

    The previous version passed `indexerIds=[-1]` which Prowlarr (newer versions)
    interprets as "indexer with id -1" — no indexers, no results, sometimes a
    400 "all indexers being unavailable" instead of an honest empty list. We
    now resolve the actual enabled indexer IDs via /api/v1/indexer (cached
    hourly) and pass those, with one auto-retry if the cache went stale and
    the search comes back unavailable.
    """
    results = []
    url = f"{prowlarr_url.rstrip('/')}/api/v1/search"

    async def _run_search(indexer_ids: list[int], attempt: int) -> tuple[int, str, list]:
        """Return (status_code, body_snippet, parsed_data) for one attempt."""
        params = {
            "query":      query,
            "categories": [int(c) for c in cat.split(",") if c.strip().isdigit()],
            "type":       "search",
            "limit":      limit,
            "offset":     0,
        }
        if indexer_ids:
            params["indexerIds"] = indexer_ids
        # If indexer_ids is empty we deliberately OMIT the param so Prowlarr
        # uses its default (all enabled). Don't send [-1] — that was the bug.
        log.debug(
            f"Prowlarr search (attempt {attempt}): {url} q={query!r} "
            f"cat={cat} indexer_ids={indexer_ids[:5]}{'…' if len(indexer_ids)>5 else ''}"
        )
        r = await client.get(
            url,
            headers={"X-Api-Key": prowlarr_key},
            params=params,
            timeout=30,
        )
        if r.status_code == 200:
            data = r.json()
            return 200, "", data if isinstance(data, list) else []
        return r.status_code, r.text[:200], []

    try:
        indexer_ids = await get_prowlarr_indexer_ids(client, prowlarr_url, prowlarr_key)
        status, body, data = await _run_search(indexer_ids, attempt=1)

        # Retry once with a fresh indexer list if we got an unavailable error
        # and we'd been targeting specific ids. Common cause: an indexer was
        # disabled in Prowlarr after we cached its id.
        if (status == 400 and "indexers being unavailable" in body and indexer_ids):
            log.info(
                f"Prowlarr: 'indexers unavailable' on attempt 1 — refreshing "
                f"indexer list and retrying"
            )
            indexer_ids = await get_prowlarr_indexer_ids(
                client, prowlarr_url, prowlarr_key, force_refresh=True,
            )
            status, body, data = await _run_search(indexer_ids, attempt=2)

        # And one more retry omitting indexerIds entirely, in case the user's
        # Prowlarr expects the default-all behavior.
        if (status == 400 and "indexers being unavailable" in body and indexer_ids):
            log.info(
                f"Prowlarr: still unavailable with explicit ids — retrying "
                f"with default (no indexerIds filter)"
            )
            status, body, data = await _run_search([], attempt=3)

        if status != 200:
            if status == 400 and "indexers being unavailable" in body:
                log.info(f"Prowlarr: all indexers unavailable for {query!r} — skipping")
                setattr(client, "_last_prowlarr_empty_reason", "indexers_unavailable")
            else:
                log.warning(
                    f"Prowlarr HTTP {status} for query {query!r} "
                    f"— URL: {url} — body: {body!r}"
                )
                setattr(client, "_last_prowlarr_empty_reason", f"http_{status}")
            return []

        if not isinstance(data, list):
            log.warning(f"Prowlarr unexpected response type: {type(data)} — body: {str(data)[:200]}")
            setattr(client, "_last_prowlarr_empty_reason", "bad_response_type")
            return []

        log.info(f"Prowlarr raw results: {len(data)} items for {query!r}")
        if data:
            sample = data[0]
            log.info(f"  First result fields: {list(sample.keys())}")
            log.info(f"  First result: title={sample.get('title')!r} infoHash={sample.get('infoHash')!r} magnetUrl={str(sample.get('magnetUrl',''))[:60]!r}")

        for item in data:
            name = item.get("title", "").strip()
            if not name:
                continue

            # Quality — try title first, then Prowlarr's quality object
            prowlarr_quality = item.get("quality") or {}
            if isinstance(prowlarr_quality, dict):
                prowlarr_quality_name = (
                    prowlarr_quality.get("name") or
                    prowlarr_quality.get("quality", {}).get("name") or ""
                ).lower()
            else:
                prowlarr_quality_name = ""

            # Extract info_hash
            info_hash = (item.get("infoHash") or "").lower()
            if not info_hash:
                # Try to pull from magnet or download URL
                magnet_url = item.get("magnetUrl") or item.get("downloadUrl") or ""
                info_hash  = _extract_hash(magnet_url) or ""

            # Magnet link — always ensure it's a real magnet:?xt=urn:btih: URI.
            # Prowlarr sometimes returns a proxy downloadUrl instead of a magnetUrl.
            # AllDebrid rejects anything that isn't a proper magnet URI.
            raw_magnet = item.get("magnetUrl") or ""
            magnet     = _build_magnet(info_hash, name, raw_magnet)

            if not info_hash or not magnet:
                log.info(f"Prowlarr: skipping {name!r} — no hash or magnet")
                continue

            size    = item.get("size") or 0
            seeders = item.get("seeders") or 0

            # Detect quality: regex on title first, then Prowlarr quality name
            quality = _detect_quality(name)
            if quality == "unknown" and prowlarr_quality_name:
                # Map Prowlarr quality names → our standard strings
                for q in ("2160p", "4k", "uhd", "1080p", "720p", "480p"):
                    if q in prowlarr_quality_name:
                        quality = q
                        break

            results.append({
                "name":      name,
                "info_hash": info_hash,
                "magnet":    magnet,
                "size":      int(size),
                "seeders":   int(seeders),
                "quality":   quality,
            })

        log.info(f"Prowlarr: {len(results)} results for {query!r} via {url}")

    except Exception as e:
        log.warning(f"Prowlarr query error ({query!r}): {e}")
        setattr(client, "_last_prowlarr_empty_reason", f"exception:{type(e).__name__}")

    return results


# ── TPB (apibay) fallback search ──────────────────────────────────────────────
#
# When Prowlarr's indexers are all unavailable (rate-limited, blocked, or
# temporarily down) we fall back to a direct query against The Pirate Bay's
# public JSON API at apibay.org. apibay returns the same kind of data
# Prowlarr would aggregate (name, info_hash, size, seeders), so we can
# normalize it into the same result shape and feed it straight into the
# index pipeline.

_APIBAY_HOSTS = (
    "https://apibay.org",
    # Add mirrors here if apibay.org itself ever blocks; same q.php API.
)


async def query_tpb(
    client: httpx.AsyncClient,
    query: str,
    *,
    limit: int = 100,
) -> list[dict]:
    """
    Direct search against TPB's public JSON API (apibay.org/q.php).

    Returns the same result shape as query_prowlarr so callers don't need to
    branch: {name, info_hash, magnet, size, seeders, quality}.

    apibay returns [{"id":"0","name":"No results returned",...}] on empty
    matches — we detect that sentinel and return [].
    """
    results: list[dict] = []
    if not query:
        return results

    import urllib.parse as _up
    q = _up.quote(query, safe="")

    for host in _APIBAY_HOSTS:
        url = f"{host}/q.php?q={q}&cat=0"
        try:
            log.debug(f"TPB search: {url}")
            r = await client.get(url, timeout=20)
            if r.status_code != 200:
                log.info(f"TPB {host} HTTP {r.status_code} for {query!r}")
                continue
            data = r.json()
        except Exception as e:
            log.info(f"TPB {host} error for {query!r}: {e}")
            continue

        if not isinstance(data, list) or not data:
            continue
        # Empty-result sentinel — single row with id="0" / name like
        # "No results returned" / info_hash all zeros.
        if (len(data) == 1
                and (data[0].get("id") in ("0", 0)
                     or "No results" in (data[0].get("name") or ""))):
            log.info(f"TPB: 0 results for {query!r}")
            return []

        for item in data[:limit]:
            name      = (item.get("name") or "").strip()
            info_hash = (item.get("info_hash") or "").lower().strip()
            if not name or not info_hash or len(info_hash) != 40:
                continue
            try:
                size    = int(item.get("size") or 0)
                seeders = int(item.get("seeders") or 0)
            except (TypeError, ValueError):
                size, seeders = 0, 0

            magnet = _build_magnet(info_hash, name, "")
            results.append({
                "name":      name,
                "info_hash": info_hash,
                "magnet":    magnet,
                "size":      size,
                "seeders":   seeders,
                "quality":   _detect_quality(name),
            })

        log.info(f"TPB: {len(results)} results for {query!r} via {host}")
        return results

    return results


async def search_prowlarr_or_tpb(
    client: httpx.AsyncClient,
    prowlarr_url: str,
    prowlarr_key: str,
    query: str,
    *,
    cat: str = "2000,5000",
    limit: int = 100,
) -> list[dict]:
    """
    Try Prowlarr first. If it returns nothing AND its failure was the
    "all indexers unavailable" 400 response (or Prowlarr is unconfigured),
    fall back to TPB. This keeps user searches working when Prowlarr is
    technically up but its indexers are dry.

    Tracks the reason for an empty Prowlarr result via a sentinel set on
    the client by query_prowlarr (`_last_prowlarr_empty_reason`). Falls
    back on "all indexers unavailable" or HTTP/transport failures.
    """
    used_fallback_reason = None

    if prowlarr_url and prowlarr_key:
        # Reset sentinel for this call
        setattr(client, "_last_prowlarr_empty_reason", None)
        results = await query_prowlarr(
            client, prowlarr_url, prowlarr_key, query, cat=cat, limit=limit,
        )
        if results:
            return results
        used_fallback_reason = getattr(client, "_last_prowlarr_empty_reason", None)
        if used_fallback_reason is None:
            # Prowlarr gave a clean empty result (200 OK, 0 items) — no need
            # to bother TPB. The query just doesn't exist.
            return results
    else:
        used_fallback_reason = "prowlarr_unconfigured"

    log.info(
        f"🌊 TPB fallback engaged for {query!r} "
        f"(prowlarr reason: {used_fallback_reason})"
    )
    return await query_tpb(client, query, limit=limit)


# ── Index a movie ─────────────────────────────────────────────────────────────

async def index_movie(
    hi: HashIndex,
    *,
    prowlarr_url: str,
    prowlarr_key: str,
    api_key: str,
    title: str,
    year: Optional[int],
    preferred_quality: str = "1080p",
) -> int:
    """
    Search Prowlarr for a movie, check AllDebrid cache, upsert scored entries.
    Returns the count of cached hashes stored.
    """
    queries = [f"{title} {year}" if year else title]
    if year:
        queries.append(title)  # fallback without year

    async with httpx.AsyncClient() as client:
        seen_hashes: set[str] = set()
        candidates = []

        for q in queries:
            results = await search_prowlarr_or_tpb(client, prowlarr_url, prowlarr_key, q)
            for r in results:
                h = r["info_hash"]
                if h not in seen_hashes:
                    seen_hashes.add(h)
                    candidates.append(r)
            if candidates:
                break  # first query gave results
            await asyncio.sleep(0.5)

        if not candidates:
            log.info(f"[MOVIE] No Prowlarr results for {title!r}")
            return 0

        # AllDebrid instant availability check
        hashes     = [c["info_hash"] for c in candidates]
        cached_set = await check_alldebrid_cache(client, api_key, hashes)

        stored = 0
        for c in candidates:
            h = c["info_hash"]
            is_cached = h in cached_set
            pts = hi.upsert(
                media_type="movie",
                title=title,
                year=year,
                season=None,
                episode=None,
                info_hash=h,
                magnet=c["magnet"],
                torrent_name=c["name"],
                quality=c["quality"],
                strategy="movie",
                is_cached=is_cached,
                file_size=c["size"],
                seeders=c.get("seeders", 0),
                preferred_quality=preferred_quality,
            )
            if is_cached:
                stored += 1
            log.info(f"  [MOVIE] {c['name'][:60]} cached={is_cached} score={pts}")

        return stored


# ── Index a series ────────────────────────────────────────────────────────────

async def index_series(
    hi: HashIndex,
    *,
    prowlarr_url: str,
    prowlarr_key: str,
    api_key: str,
    title: str,
    year: Optional[int],
    season_count: int,
    is_ended: bool,
    preferred_quality: str = "1080p",
) -> dict:
    """
    Search Prowlarr for series packs and each season pack.
    Check AllDebrid cache, upsert scored entries.
    Returns {"series_packs": N, "season_packs": N, "episodes": N}.
    """
    counts = {"series_packs": 0, "season_packs": 0, "episodes": 0}

    async with httpx.AsyncClient() as client:
        # Series pack first (highest value)
        sp_results = await search_prowlarr_or_tpb(
            client, prowlarr_url, prowlarr_key,
            f"{title} complete series" if year is None else f"{title} {year} complete",
        )
        if not sp_results:
            sp_results = await search_prowlarr_or_tpb(
                client, prowlarr_url, prowlarr_key, f"{title} complete",
            )

        series_hashes = [r["info_hash"] for r in sp_results]
        series_cached = await check_alldebrid_cache(client, api_key, series_hashes) if series_hashes else set()
        for r in sp_results:
            mt   = _media_type_from_torrent(r["name"], "episode")
            is_c = r["info_hash"] in series_cached
            hi.upsert(
                media_type=mt,
                title=title, year=year,
                season=None, episode=None,
                info_hash=r["info_hash"], magnet=r["magnet"],
                torrent_name=r["name"], quality=r["quality"],
                strategy="series_pack", is_cached=is_c,
                seeders=r.get("seeders", 0),
                file_size=r["size"], preferred_quality=preferred_quality,
            )
            if is_c and mt == "series":
                counts["series_packs"] += 1

        await asyncio.sleep(0.5)

        # Season packs
        for sn in range(1, min(season_count + 1, 30)):
            sn_results = await search_prowlarr_or_tpb(
                client, prowlarr_url, prowlarr_key,
                f"{title} season {sn}",
            )
            if not sn_results:
                sn_results = await search_prowlarr_or_tpb(
                    client, prowlarr_url, prowlarr_key,
                    f"{title} S{sn:02d}",
                )

            sn_hashes = [r["info_hash"] for r in sn_results]
            sn_cached = await check_alldebrid_cache(client, api_key, sn_hashes) if sn_hashes else set()
            for r in sn_results:
                mt   = _media_type_from_torrent(r["name"], "episode")
                is_c = r["info_hash"] in sn_cached
                hi.upsert(
                    media_type=mt,
                    title=title, year=year,
                    season=sn, episode=None,
                    info_hash=r["info_hash"], magnet=r["magnet"],
                    torrent_name=r["name"], quality=r["quality"],
                    strategy="season_pack", is_cached=is_c,
                    seeders=r.get("seeders", 0),
                    file_size=r["size"], preferred_quality=preferred_quality,
                )
                if is_c and mt == "season":
                    counts["season_packs"] += 1

            await asyncio.sleep(0.3)

    log.info(f"[SERIES] {title!r} indexed: {counts}")
    return counts


# ── Miss-triggered targeted search ───────────────────────────────────────────

async def search_and_index(
    hi: HashIndex,
    *,
    prowlarr_url: str,
    prowlarr_key: str,
    api_key: str,
    title: str,
    year: Optional[int],
    media_type: str,
    season: Optional[int] = None,
    episode: Optional[int] = None,
    preferred_quality: str = "1080p",
) -> int:
    """
    Targeted search triggered when the index misses on a play request.
    Populates the index then returns the count of cached hits found.
    The caller retries lookup() after this returns.
    """
    if media_type == "movie":
        return await index_movie(
            hi,
            prowlarr_url=prowlarr_url,
            prowlarr_key=prowlarr_key,
            api_key=api_key,
            title=title,
            year=year,
            preferred_quality=preferred_quality,
        )

    # Episode — try season pack first, then series pack, then episode
    queries = []
    if season:
        queries.append((f"{title} S{season:02d}", season, None, "season_pack"))
        queries.append((f"{title} season {season}", season, None, "season_pack"))
    queries.append((f"{title} complete", None, None, "series_pack"))
    if season and episode:
        queries.append((f"{title} S{season:02d}E{episode:02d}", season, episode, "episode"))

    total_cached = 0
    async with httpx.AsyncClient() as client:
        seen: set[str] = set()
        for query, sn, ep, strategy in queries:
            results = await search_prowlarr_or_tpb(client, prowlarr_url, prowlarr_key, query)
            if not results:
                await asyncio.sleep(0.3)
                continue

            new = [r for r in results if r["info_hash"] not in seen]
            if not new:
                continue
            for r in new:
                seen.add(r["info_hash"])

            hashes = [r["info_hash"] for r in new]
            cached_set = await check_alldebrid_cache(client, api_key, hashes)
            for r in new:
                is_c = r["info_hash"] in cached_set
                mt   = _media_type_from_torrent(r["name"], "episode")
                hi.upsert(
                    media_type=mt,
                    title=title, year=year,
                    season=sn, episode=ep,
                    info_hash=r["info_hash"], magnet=r["magnet"],
                    torrent_name=r["name"], quality=r["quality"],
                    strategy=strategy, is_cached=is_c,
                    seeders=r.get("seeders", 0),
                    file_size=r["size"], preferred_quality=preferred_quality,
                )
                if is_c:
                    total_cached += 1

            if total_cached > 0:
                break  # found cached content — stop searching
            await asyncio.sleep(0.4)

    return total_cached


# ── Background recheck loop ───────────────────────────────────────────────────

async def recheck_stale(
    hi: HashIndex,
    api_key: str,
    limit: int = 200,
    older_than_hours: int = 6,
) -> dict:
    """
    Re-verify stale hashes against AllDebrid. Updates is_cached and score.
    Called by the background recheck loop every 6 hours.
    Returns {rechecked, now_cached, evicted}.
    """
    stale = hi.get_stale(older_than_hours=older_than_hours, limit=limit)
    if not stale:
        return {"rechecked": 0, "now_cached": 0, "evicted": 0}

    hashes = [r["info_hash"] for r in stale]
    async with httpx.AsyncClient() as client:
        cached_set = await check_alldebrid_cache(client, api_key, hashes)

    now_cached = 0
    evicted    = 0
    for row in stale:
        h          = row["info_hash"]
        was_cached = bool(row["is_cached"])
        is_cached  = h in cached_set
        if is_cached and not was_cached:
            hi.mark_cached(h)
            now_cached += 1
        elif was_cached and not is_cached:
            hi.mark_uncached(h)
            evicted += 1
        else:
            # Just refresh the last_checked timestamp
            hi.upsert(
                media_type=row["media_type"],
                title=row["title"],
                year=row["year"],
                season=row["season"],
                episode=row["episode"],
                info_hash=h,
                magnet=row["magnet"],
                torrent_name=row["torrent_name"] or "",
                quality=row["quality"] or "unknown",
                strategy=row["strategy"] or "unknown",
                is_cached=is_cached,
                file_count=row.get("file_count", 1),
                file_size=row.get("file_size", 0),
            )

    log.info(
        f"[RECHECK] {len(stale)} stale hashes: "
        f"{now_cached} newly cached, {evicted} evicted"
    )
    return {"rechecked": len(stale), "now_cached": now_cached, "evicted": evicted}
