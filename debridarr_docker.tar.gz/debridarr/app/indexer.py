"""
indexer.py — Hash index population pipeline.

Two paths feed the index:

1. Background growth — polls Prowlarr/Torznab RSS feeds on a schedule,
   extracts infohashes, checks AllDebrid instant availability, scores
   each result, and upserts into the hash index.

2. Miss-triggered search — called from resolve_on_play() when the index
   has no cached hit. Runs a targeted Prowlarr query for the specific
   media item, populates the index, then the play path retries.

The index is the ONLY consumer of these results. No placeholders are
created here. No torrents are added to AllDebrid here.
"""

from __future__ import annotations

import asyncio
import logging
import os
import re
import sqlite3
import time
from email.utils import parsedate_to_datetime
from typing import Optional

import httpx

from .hash_index import HashIndex, score_candidate, _norm

log = logging.getLogger("debridarr.indexer")


# ── Prowlarr safety / anti-ban guardrails ─────────────────────────────────────
# These defaults are intentionally conservative. Prowlarr aggregates many
# upstream indexers; firing a search for every movie/episode can quickly trip
# tracker/indexer limits. We serialize Prowlarr searches, add a minimum spacing
# between calls, cap returned results, and pause Prowlarr after rate-limit style
# responses. The TPB fallback can still be used while Prowlarr is cooling down.

_PROWLARR_LOCK = asyncio.Lock()
_PROWLARR_LAST_SEARCH_AT = 0.0
_PROWLARR_COOLDOWN_UNTIL: dict[str, float] = {}


def _db_setting(key: str, default: str = "") -> str:
    """Read app_settings directly so Settings UI values affect indexer.py."""
    val = os.environ.get(key)
    if val not in (None, ""):
        return str(val)
    db_path = os.environ.get("DB_PATH", "/data/debridarr.db")
    try:
        with sqlite3.connect(db_path) as conn:
            row = conn.execute("SELECT value FROM app_settings WHERE key=?", (key,)).fetchone()
            if row and row[0] not in (None, ""):
                return str(row[0])
    except Exception:
        pass
    return default


def _setting_int(key: str, default: int, *, min_value: int = 0, max_value: int | None = None) -> int:
    try:
        value = int(float(_db_setting(key, str(default))))
    except Exception:
        value = default
    value = max(min_value, value)
    if max_value is not None:
        value = min(max_value, value)
    return value


def _prowlarr_key(prowlarr_url: str) -> str:
    return prowlarr_url.rstrip('/').lower()


def _retry_after_seconds(value: str | None, default: int) -> int:
    if not value:
        return default
    try:
        return max(0, int(float(value)))
    except Exception:
        pass
    try:
        dt = parsedate_to_datetime(value)
        return max(0, int(dt.timestamp() - time.time()))
    except Exception:
        return default


def _set_prowlarr_cooldown(prowlarr_url: str, seconds: int, reason: str) -> None:
    seconds = max(30, seconds)
    key = _prowlarr_key(prowlarr_url)
    until = time.time() + seconds
    if until > _PROWLARR_COOLDOWN_UNTIL.get(key, 0):
        _PROWLARR_COOLDOWN_UNTIL[key] = until
    log.warning(f"Prowlarr safety: cooling down for {seconds}s ({reason})")


def _prowlarr_cooldown_remaining(prowlarr_url: str) -> int:
    until = _PROWLARR_COOLDOWN_UNTIL.get(_prowlarr_key(prowlarr_url), 0)
    return max(0, int(until - time.time()))


async def _prowlarr_safety_wait(prowlarr_url: str) -> bool:
    """
    Return False if Prowlarr is in cooldown. Otherwise wait until it is safe
    to send exactly one more aggregate search.
    """
    global _PROWLARR_LAST_SEARCH_AT

    remaining = _prowlarr_cooldown_remaining(prowlarr_url)
    if remaining > 0:
        log.info(f"Prowlarr safety: skipping search; cooldown has {remaining}s remaining")
        return False

    min_gap = _setting_int("PROWLARR_MIN_SECONDS_BETWEEN_SEARCHES", 3, min_value=0, max_value=300)
    async with _PROWLARR_LOCK:
        now = time.time()
        wait_for = (_PROWLARR_LAST_SEARCH_AT + min_gap) - now
        if wait_for > 0:
            log.info(f"Prowlarr safety: spacing searches by {wait_for:.1f}s")
            await asyncio.sleep(wait_for)
        _PROWLARR_LAST_SEARCH_AT = time.time()
        return True

# ── Helpers ───────────────────────────────────────────────────────────────────

_HASH_RE = re.compile(r"btih:([a-fA-F0-9]{40})", re.I)
_VIDEO_QUALITY_RE = re.compile(r"(2160p|4k|uhd|1080p|720p|480p)", re.I)

# Hard-banned source types. These are rejected before cache probing and before
# any hash is written, from both Prowlarr and TPB fallback. Keep this separate
# from quality preferences so CAM/TS never sneaks in through "fallback any".
_BANNED_RELEASE_RE = re.compile(
    r"(?ix)"
    r"(?:^|[\s._\-\[\]()])"
    r"("
    r"cam(?:rip)?|hdcam|camrip|"
    r"ts|hdts|telesync|tele[._\- ]?sync|ts[._\- ]?rip|"
    r"tc|telecine|r5|"
    r"dvdscr|dvd[._\- ]?scr|screener|scr|"
    r"workprint|wp"
    r")"
    r"(?:$|[\s._\-\[\]()])"
)


def _is_banned_release(name: str) -> bool:
    return bool(_BANNED_RELEASE_RE.search(name or ""))


def _extract_hash(text: str) -> Optional[str]:
    m = _HASH_RE.search(text or "")
    return m.group(1).lower() if m else None


def _detect_quality(name: str) -> str:
    m = _VIDEO_QUALITY_RE.search(name or "")
    return m.group(1).lower() if m else "unknown"


def _is_pack(name: str) -> tuple[bool, bool]:
    """Return (is_season_pack, is_series_pack)."""
    n = name.upper()
    has_episode = bool(re.search(r"S\d{2}E\d{2}", n))
    has_season  = bool(re.search(r"S\d{2}", n))
    is_series   = not has_season and not has_episode
    is_season   = has_season and not has_episode
    return is_season, is_series


_TRACKERS = (
    "udp://open.tracker.cl:1337/announce",
    "udp://tracker.opentrackr.org:1337/announce",
    "udp://tracker.openbittorrent.com:6969/announce",
    "udp://exodus.desync.com:6969/announce",
    "udp://tracker.torrent.eu.org:451/announce",
)


def _build_magnet(info_hash: str, name: str, existing_magnet: str = "") -> str:
    """
    Return a valid magnet URI for the given infohash.

    If `existing_magnet` already starts with 'magnet:?xt=urn:btih:' it is
    returned as-is (it's a real magnet, not a proxy URL).
    Otherwise we construct one from the hash + name + standard trackers so
    AllDebrid can always resolve it.
    """
    if existing_magnet and existing_magnet.startswith("magnet:?xt=urn:btih:"):
        return existing_magnet
    # Construct from scratch — proxy/download URLs are not valid magnets
    import urllib.parse as _up
    dn      = _up.quote(name, safe="")
    tr_part = "".join(f"&tr={_up.quote(t, safe='')}" for t in _TRACKERS)
    return f"magnet:?xt=urn:btih:{info_hash}&dn={dn}{tr_part}"


def _media_type_from_torrent(name: str, requested_media_type: str) -> str:
    is_season, is_series = _is_pack(name)
    if requested_media_type == "movie":
        return "movie"
    if is_series:
        return "series"
    if is_season:
        return "season"
    return "episode"




# ── Strict media matching ─────────────────────────────────────────────────────
# Indexers can return look-alikes (for example "Ted Lasso" when the movie is
# "Ted", wrong years, wrong seasons, specials, samples, etc.).  These helpers
# run before AllDebrid cache probing and before writing to the hash index so the
# resolver only learns hashes that actually belong to the requested movie/show.

_STOP_TITLE_TOKENS = {
    "the", "a", "an", "and", "of", "to", "in", "for", "on", "with",
}
_CUT_TOKENS_RE = re.compile(
    r"\b(19\d{2}|20\d{2}|s\d{1,2}(?:e\d{1,2})?|season\s*\d{1,2}|"
    r"complete|series|2160p|1080p|720p|480p|4k|uhd|hdr|dv|dovi|web[ ._-]?dl|"
    r"webrip|bluray|brrip|bdrip|hdtv|x264|x265|h264|h265|hevc|av1)\b",
    re.I,
)
_YEAR_RE = re.compile(r"\b(19\d{2}|20\d{2})\b")

_REGION_ALIASES = {
    "usa": {"usa", "us", "united states", "america"},
    "us": {"usa", "us", "united states", "america"},
    "uk": {"uk", "gb", "great britain", "britain", "united kingdom"},
    "aus": {"aus", "au", "australia"},
    "au": {"aus", "au", "australia"},
    "canada": {"canada", "ca"},
    "ca": {"canada", "ca"},
    "nz": {"nz", "new zealand"},
}
_REGION_CANON = {alias: canon for canon, aliases in _REGION_ALIASES.items() for alias in aliases}
_REGION_WORDS = set(_REGION_CANON) | {"usa", "uk", "us", "au", "aus", "ca", "nz", "europe", "eu"}
_FOREIGN_LANGUAGE_RE = re.compile(
    r"\b(german|french|spanish|italian|dutch|polish|swedish|norwegian|danish|"
    r"flemish|russian|hindi|korean|japanese|chinese|multi(?:[ ._-]?subs?)?|"
    r"sub(?:bed)?|dub(?:bed)?)\b",
    re.I,
)


def _release_title_norm(name: str) -> str:
    """Best-effort extraction of just the release title from a torrent name."""
    n = re.sub(r"[._\-\[\]\(\)]+", " ", name or " ")
    m = _CUT_TOKENS_RE.search(n)
    if m:
        n = n[:m.start()]
    return _norm(n)




def _search_title_variants(title: str) -> list[str]:
    variants: list[str] = []
    seen: set[str] = set()
    def add(v: str):
        v = re.sub(r"\s+", " ", (v or "")).strip()
        k = v.lower()
        if v and k not in seen:
            seen.add(k); variants.append(v)
    add(title)
    add(re.sub(r"\s*\((?:us|usa|uk|gb|ca|canada|au|aus|nz)\)\s*", " ", title, flags=re.I))
    add(re.sub(r"['’`´]", "", title))
    if title.lower().startswith("the "):
        add(title[4:])
    for v in list(variants):
        add(re.sub(r"['’`´]", "", v))
        if v.lower().startswith("the "):
            add(v[4:])
    return variants


def _match_title_for_release(title: str) -> str:
    return re.sub(r"\s*\((?:us|usa|uk|gb|ca|canada|au|aus|nz)\)\s*", " ", title, flags=re.I).strip() or title


def _important_title_tokens(title: str) -> list[str]:
    return [t for t in _norm(title).split() if t not in _STOP_TITLE_TOKENS]


def _region_tokens(text: str) -> set[str]:
    n = _norm(text)
    tokens = set(n.split())
    found: set[str] = set()
    for raw, canon in _REGION_CANON.items():
        if " " in raw:
            if raw in n:
                found.add(canon)
        elif raw in tokens:
            found.add(canon)
    if "europe" in tokens or "eu" in tokens:
        found.add("europe")
    return found


def _title_region_is_ok(requested_title: str, torrent_name: str) -> bool:
    """Keep regional spin-offs exact: Love Island USA must not match UK/AU/etc."""
    want_regions = _region_tokens(requested_title)
    if not want_regions:
        return True
    got_regions = _region_tokens(_release_title_norm(torrent_name)) | _region_tokens(torrent_name)
    # Only require a region check when the requested title itself names one.
    # Accept aliases like US/USA, but reject a different regional spin-off.
    return bool(want_regions & got_regions)


def _foreign_release_is_ok(requested_title: str, torrent_name: str) -> bool:
    """Avoid grabbing foreign/Europe releases for ambiguous English titles like From."""
    # Allow normal regional titles such as Love Island UK/USA, but reject releases
    # tagged only as foreign-language/Europe when the requested title has no such
    # region/language intent.
    if _region_tokens(requested_title):
        return True
    if _FOREIGN_LANGUAGE_RE.search(torrent_name or ""):
        return False
    toks = _region_tokens(torrent_name)
    return not ({"europe"} & toks)



def _tokens_equal_with_regions(want_tokens: list[str], got_tokens: list[str]) -> bool:
    if len(want_tokens) != len(got_tokens):
        return False
    for w, g in zip(want_tokens, got_tokens):
        if w == g:
            continue
        if _REGION_CANON.get(w) and _REGION_CANON.get(w) == _REGION_CANON.get(g):
            continue
        return False
    return True


def _token_in_with_regions(token: str, tokens: list[str]) -> bool:
    if token in tokens:
        return True
    canon = _REGION_CANON.get(token)
    return bool(canon and any(_REGION_CANON.get(t) == canon for t in tokens))

def _title_is_strict_match(requested_title: str, torrent_name: str) -> bool:
    want = _norm(requested_title)
    got = _release_title_norm(torrent_name)
    if not want or not got:
        return False

    if not _title_region_is_ok(requested_title, torrent_name):
        return False
    if not _foreign_release_is_ok(requested_title, torrent_name):
        return False

    if got == want:
        return True

    want_tokens = want.split()
    got_tokens = got.split()

    # For tiny/one-word titles, never allow prefix/contains matching. This stops
    # "Ted" from matching "Ted Lasso" and similar false positives.
    if len(want_tokens) <= 1:
        return False

    # Multi-word titles must match at the start of the parsed release title, or
    # contain all important tokens. This handles punctuation/alternate separators
    # while still rejecting unrelated releases.
    if _tokens_equal_with_regions(want_tokens, got_tokens[:len(want_tokens)]):
        return True

    important = _important_title_tokens(requested_title)
    return bool(important) and all(_token_in_with_regions(t, got_tokens) for t in important)


def _year_is_ok(year: Optional[int], torrent_name: str, *, media_type: str) -> bool:
    if not year:
        return True
    years = {int(y) for y in _YEAR_RE.findall(torrent_name or "")}
    if not years:
        return True
    if int(year) in years:
        return True
    # TV releases often include a release year that is not the first-air year;
    # don't reject those as hard as movies.
    return media_type != "movie"


def _season_episode_is_ok(
    torrent_name: str,
    *,
    media_type: str,
    season: Optional[int],
    episode: Optional[int],
    strategy: str = "",
) -> bool:
    name = torrent_name or ""
    if media_type == "movie":
        # Movie searches should not accept TV episode/season releases.
        return not re.search(r"\bS\d{1,2}(?:E\d{1,2})?\b|\bseason\s+\d{1,2}\b", name, re.I)

    if season is None:
        return True

    # Series packs are allowed to have no season marker. If they do include a
    # season marker, it still has to be the requested season.
    if strategy == "series_pack":
        sm = re.search(r"\bS(\d{1,2})(?:E\d{1,2})?\b|\bseason\s+(\d{1,2})\b", name, re.I)
        return not sm or int(sm.group(1) or sm.group(2)) == int(season)

    # Season/episode searches must explicitly identify the requested season.
    sm = re.search(r"\bS(\d{1,2})(?:E(\d{1,2}))?\b|\bseason\s+(\d{1,2})\b", name, re.I)
    if not sm:
        return False
    found_season = int(sm.group(1) or sm.group(3))
    if found_season != int(season):
        return False

    if episode is not None:
        em = re.search(r"\bS\d{1,2}E(\d{1,2})\b", name, re.I)
        if not em:
            return False
        return int(em.group(1)) == int(episode)

    return True


def _filter_strict_results(
    results: list[dict],
    *,
    title: str,
    year: Optional[int],
    media_type: str,
    season: Optional[int] = None,
    episode: Optional[int] = None,
    strategy: str = "",
) -> list[dict]:
    """Drop wrong-title/year/season/episode results before probing or storing."""
    kept: list[dict] = []
    rejected = 0
    for r in results or []:
        name = r.get("name", "")
        if _is_banned_release(name):
            rejected += 1
            log.info(f"Search rejected banned CAM/TS-style release: {name!r}")
            continue
        if not _title_is_strict_match(_match_title_for_release(title), name):
            rejected += 1
            log.debug(f"Strict search rejected title mismatch: want={title!r} got={name!r}")
            continue
        if not _year_is_ok(year, name, media_type=media_type):
            rejected += 1
            log.debug(f"Strict search rejected year mismatch: want={year!r} got={name!r}")
            continue
        if not _season_episode_is_ok(name, media_type=media_type, season=season, episode=episode, strategy=strategy):
            rejected += 1
            log.debug(
                f"Strict search rejected S/E mismatch: want S{season}E{episode} got={name!r}"
            )
            continue
        kept.append(r)
    if rejected:
        log.info(f"Strict search kept {len(kept)}/{len(results or [])} result(s) for {title!r}; rejected {rejected}")
    return kept


async def search_strict_with_tpb_fallback(
    client: httpx.AsyncClient,
    prowlarr_url: str,
    prowlarr_key: str,
    query: str,
    *,
    title: str,
    year: Optional[int],
    media_type: str,
    season: Optional[int] = None,
    episode: Optional[int] = None,
    strategy: str = "",
    cat: str = "2000,5000",
    limit: int = 100,
) -> list[dict]:
    """
    Search Prowlarr, strict-filter the results, then fall back to the existing
    TPB API if Prowlarr fails OR returns no usable strict matches.
    """
    # Use the narrowest Prowlarr category possible. Movies should not search TV
    # and TV should not search movies; this reduces bad matches before scoring.
    if cat == "2000,5000":
        cat = "2000" if media_type == "movie" else "5000"

    raw: list[dict] = []
    reason = None
    if prowlarr_url and prowlarr_key:
        setattr(client, "_last_prowlarr_empty_reason", None)
        raw = await query_prowlarr(client, prowlarr_url, prowlarr_key, query, cat=cat, limit=limit)
        strict = _filter_strict_results(
            raw, title=title, year=year, media_type=media_type,
            season=season, episode=episode, strategy=strategy,
        )
        if strict:
            return strict
        reason = getattr(client, "_last_prowlarr_empty_reason", None) or "no_strict_matches"
    else:
        reason = "prowlarr_unconfigured"

    log.info(f"🌊 TPB fallback engaged for {query!r} (reason: {reason})")
    tpb_raw = await query_tpb(client, query, limit=limit)
    return _filter_strict_results(
        tpb_raw, title=title, year=year, media_type=media_type,
        season=season, episode=episode, strategy=strategy,
    )


# ── AllDebrid instant availability ────────────────────────────────────────────

async def check_alldebrid_cache(
    client: httpx.AsyncClient,
    api_key: str,
    hashes: list[str],
    *,
    batch_size: int = 50,
) -> set[str]:
    """
    Check which hashes are cached on AllDebrid using the upload→ready→delete pattern.

    Uses the same proven approach as alldebrid.py:
      1. POST hashes as magnets to /magnet/upload with Bearer auth
      2. AllDebrid returns ready=true/false instantly for each hash
      3. DELETE all probe IDs immediately — nothing left in the account

    /magnet/instant does not exist. /magnet/upload is the correct endpoint.
    """
    import urllib.parse as _ul

    ad_upload = "https://api.alldebrid.com/v4/magnet/upload"
    ad_delete = "https://api.alldebrid.com/v4/magnet/delete"
    headers   = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type":  "application/x-www-form-urlencoded",
    }

    cached: set[str] = set()

    for i in range(0, len(hashes), batch_size):
        batch = hashes[i : i + batch_size]
        try:
            # Build magnet URIs from raw hashes
            magnets = [_build_magnet(h, "") for h in batch]
            body    = _ul.urlencode([("magnets[]", m) for m in magnets])

            r = await client.post(ad_upload, headers=headers, content=body, timeout=20)
            if r.status_code != 200:
                log.warning(f"AllDebrid upload HTTP {r.status_code} — body: {r.text[:200]!r}")
                continue

            result   = r.json()
            if result.get("status") != "success":
                log.warning(f"AllDebrid upload error: {result.get('error', {})}")
                continue

            ids_to_delete = []
            for m in result.get("data", {}).get("magnets", []):
                if m.get("error"):
                    continue
                h = (m.get("hash") or "").lower()
                if h and m.get("ready"):
                    cached.add(h)
                if m.get("id"):
                    ids_to_delete.append(str(m["id"]))

            # Delete all probe IDs — keep account clean
            for mid in ids_to_delete:
                try:
                    del_body = _ul.urlencode({"id": mid})
                    await client.post(ad_delete, headers=headers, content=del_body, timeout=10)
                except Exception:
                    pass

            log.debug(
                f"AllDebrid cache check: {len(cached)}/{len(batch)} cached in batch, "
                f"{len(ids_to_delete)} probe IDs deleted"
            )

        except Exception as e:
            log.warning(f"AllDebrid cache check batch error: {e}")

        await asyncio.sleep(0.3)

    return cached


# ── Prowlarr / Torznab RSS feed scraping ──────────────────────────────────────

_PROWLARR_INDEXER_CACHE: dict[str, tuple[float, list[int]]] = {}
_PROWLARR_INDEXER_TTL = 3600  # refresh hourly


async def get_prowlarr_indexer_ids(
    client: httpx.AsyncClient,
    prowlarr_url: str,
    prowlarr_key: str,
    *,
    force_refresh: bool = False,
) -> list[int]:
    """
    Return the list of enabled indexer IDs from Prowlarr.

    Why this exists: passing `indexerIds=[-1]` to /api/v1/search means
    "indexer with id -1" — which is no indexer — so newer Prowlarr versions
    return zero or a 400 "all indexers being unavailable". Older versions
    accepted -1 as a "wildcard"; that was an accident, not a contract.
    The correct API contract is to pass actual enabled indexer IDs.

    Cached for 1 h. Force-refresh on auth errors / config changes.
    """
    cache_key = f"{prowlarr_url}|{prowlarr_key[:8]}"
    now = time.time()
    if not force_refresh:
        hit = _PROWLARR_INDEXER_CACHE.get(cache_key)
        if hit and now - hit[0] < _PROWLARR_INDEXER_TTL:
            return list(hit[1])

    url = f"{prowlarr_url.rstrip('/')}/api/v1/indexer"
    try:
        r = await client.get(
            url, headers={"X-Api-Key": prowlarr_key}, timeout=15,
        )
        if r.status_code != 200:
            log.warning(
                f"Prowlarr /indexer returned HTTP {r.status_code}: "
                f"{r.text[:200]!r} — cannot enumerate indexers"
            )
            _PROWLARR_INDEXER_CACHE[cache_key] = (now, [])
            return []
        indexers = r.json() or []
    except Exception as e:
        log.warning(f"Prowlarr /indexer fetch failed: {e}")
        return []

    enabled_ids: list[int] = []
    for ix in indexers:
        # `enable` is the master toggle; older Prowlarr used `enableRss`/
        # `enableAutomaticSearch`/`enableInteractiveSearch` separately —
        # accept the indexer if ANY search-related flag is on.
        on = (
            ix.get("enable", True)
            and (
                ix.get("enableAutomaticSearch", True)
                or ix.get("enableInteractiveSearch", True)
                or ix.get("enableRss", True)
            )
        )
        iid = ix.get("id")
        if on and isinstance(iid, int):
            enabled_ids.append(iid)

    log.info(
        f"Prowlarr: {len(enabled_ids)} enabled indexer(s) — "
        f"ids={enabled_ids[:10]}{'…' if len(enabled_ids) > 10 else ''}"
    )
    _PROWLARR_INDEXER_CACHE[cache_key] = (now, enabled_ids)
    return enabled_ids


async def query_prowlarr(
    client: httpx.AsyncClient,
    prowlarr_url: str,
    prowlarr_key: str,
    query: str,
    *,
    cat: str = "2000,5000",  # Prowlarr: Movies + TV (NewzNab category codes)
    limit: int = 100,
) -> list[dict]:
    """
    Query Prowlarr's native /api/v1/search JSON endpoint (aggregate across all
    ENABLED indexers).

    Returns a list of torrent dicts: {name, info_hash, magnet, size, seeders, quality}.

    The previous version passed `indexerIds=[-1]` which Prowlarr (newer versions)
    interprets as "indexer with id -1" — no indexers, no results, sometimes a
    400 "all indexers being unavailable" instead of an honest empty list. We
    now resolve the actual enabled indexer IDs via /api/v1/indexer (cached
    hourly) and pass those, with one auto-retry if the cache went stale and
    the search comes back unavailable.
    """
    results = []
    url = f"{prowlarr_url.rstrip('/')}/api/v1/search"

    # Hard cap results so one search does not fan out into huge AllDebrid probes.
    configured_limit = _setting_int("PROWLARR_SEARCH_LIMIT", 50, min_value=1, max_value=100)
    limit = min(limit, configured_limit)

    if not await _prowlarr_safety_wait(prowlarr_url):
        setattr(client, "_last_prowlarr_empty_reason", "prowlarr_cooldown")
        return []

    async def _run_search(indexer_ids: list[int], attempt: int) -> tuple[int, str, list]:
        """Return (status_code, body_snippet, parsed_data) for one attempt."""
        params = {
            "query":      query,
            "categories": [int(c) for c in cat.split(",") if c.strip().isdigit()],
            "type":       "search",
            "limit":      limit,
            "offset":     0,
        }
        if indexer_ids:
            params["indexerIds"] = indexer_ids
        # If indexer_ids is empty we deliberately OMIT the param so Prowlarr
        # uses its default (all enabled). Don't send [-1] — that was the bug.
        log.debug(
            f"Prowlarr search (attempt {attempt}): {url} q={query!r} "
            f"cat={cat} indexer_ids={indexer_ids[:5]}{'…' if len(indexer_ids)>5 else ''}"
        )
        r = await client.get(
            url,
            headers={"X-Api-Key": prowlarr_key},
            params=params,
            timeout=30,
        )
        if r.status_code == 200:
            data = r.json()
            return 200, "", data if isinstance(data, list) else []

        # Treat rate-limit/ban-ish responses as a stop signal. Do not retry
        # immediately; Prowlarr/indexers need time to recover.
        if r.status_code in (401, 403, 418, 429, 500, 502, 503, 504):
            default_cd = _setting_int("PROWLARR_RATE_LIMIT_COOLDOWN_SECONDS", 900, min_value=60, max_value=86400)
            retry_after = _retry_after_seconds(r.headers.get("Retry-After"), default_cd)
            _set_prowlarr_cooldown(prowlarr_url, retry_after, f"HTTP {r.status_code}")
        return r.status_code, r.text[:200], []

    try:
        indexer_ids = await get_prowlarr_indexer_ids(client, prowlarr_url, prowlarr_key)
        status, body, data = await _run_search(indexer_ids, attempt=1)

        # If Prowlarr says indexers are unavailable, do NOT retry the search
        # immediately. A retry often hits the same upstream indexers again and
        # can worsen temporary bans/rate limits. Refresh the cached indexer list
        # for the next future search, then place Prowlarr into a short cooldown.
        if (status == 400 and "indexers being unavailable" in body):
            await get_prowlarr_indexer_ids(
                client, prowlarr_url, prowlarr_key, force_refresh=True,
            )
            cd = _setting_int("PROWLARR_UNAVAILABLE_COOLDOWN_SECONDS", 300, min_value=30, max_value=3600)
            _set_prowlarr_cooldown(prowlarr_url, cd, "indexers unavailable")

        if status != 200:
            if status == 400 and "indexers being unavailable" in body:
                log.info(f"Prowlarr: all indexers unavailable for {query!r} — skipping")
                setattr(client, "_last_prowlarr_empty_reason", "indexers_unavailable")
            elif status in (401, 403, 418, 429, 500, 502, 503, 504):
                log.warning(f"Prowlarr safety: HTTP {status} for {query!r}; skipping until cooldown expires")
                setattr(client, "_last_prowlarr_empty_reason", f"rate_limited_http_{status}")
            else:
                log.warning(
                    f"Prowlarr HTTP {status} for query {query!r} "
                    f"— URL: {url} — body: {body!r}"
                )
                setattr(client, "_last_prowlarr_empty_reason", f"http_{status}")
            return []

        if not isinstance(data, list):
            log.warning(f"Prowlarr unexpected response type: {type(data)} — body: {str(data)[:200]}")
            setattr(client, "_last_prowlarr_empty_reason", "bad_response_type")
            return []

        log.info(f"Prowlarr raw results: {len(data)} items for {query!r}")
        if data:
            sample = data[0]
            log.info(f"  First result fields: {list(sample.keys())}")
            log.info(f"  First result: title={sample.get('title')!r} infoHash={sample.get('infoHash')!r} magnetUrl={str(sample.get('magnetUrl',''))[:60]!r}")

        for item in data:
            name = item.get("title", "").strip()
            if not name:
                continue

            # Quality — try title first, then Prowlarr's quality object
            prowlarr_quality = item.get("quality") or {}
            if isinstance(prowlarr_quality, dict):
                prowlarr_quality_name = (
                    prowlarr_quality.get("name") or
                    prowlarr_quality.get("quality", {}).get("name") or ""
                ).lower()
            else:
                prowlarr_quality_name = ""

            # Extract info_hash
            info_hash = (item.get("infoHash") or "").lower()
            if not info_hash:
                # Try to pull from magnet or download URL
                magnet_url = item.get("magnetUrl") or item.get("downloadUrl") or ""
                info_hash  = _extract_hash(magnet_url) or ""

            # Magnet link — always ensure it's a real magnet:?xt=urn:btih: URI.
            # Prowlarr sometimes returns a proxy downloadUrl instead of a magnetUrl.
            # AllDebrid rejects anything that isn't a proper magnet URI.
            raw_magnet = item.get("magnetUrl") or ""
            magnet     = _build_magnet(info_hash, name, raw_magnet)

            if not info_hash or not magnet:
                log.info(f"Prowlarr: skipping {name!r} — no hash or magnet")
                continue

            size    = item.get("size") or 0
            seeders = item.get("seeders") or 0

            # Detect quality: regex on title first, then Prowlarr quality name
            quality = _detect_quality(name)
            if quality == "unknown" and prowlarr_quality_name:
                # Map Prowlarr quality names → our standard strings
                for q in ("2160p", "4k", "uhd", "1080p", "720p", "480p"):
                    if q in prowlarr_quality_name:
                        quality = q
                        break

            results.append({
                "name":      name,
                "info_hash": info_hash,
                "magnet":    magnet,
                "size":      int(size),
                "seeders":   int(seeders),
                "quality":   quality,
            })

        log.info(f"Prowlarr: {len(results)} results for {query!r} via {url}")

    except Exception as e:
        log.warning(f"Prowlarr query error ({query!r}): {e}")
        setattr(client, "_last_prowlarr_empty_reason", f"exception:{type(e).__name__}")

    return results


# ── TPB (apibay) fallback search ──────────────────────────────────────────────
#
# When Prowlarr's indexers are all unavailable (rate-limited, blocked, or
# temporarily down) we fall back to a direct query against The Pirate Bay's
# public JSON API at apibay.org. apibay returns the same kind of data
# Prowlarr would aggregate (name, info_hash, size, seeders), so we can
# normalize it into the same result shape and feed it straight into the
# index pipeline.

_APIBAY_HOSTS = (
    "https://apibay.org",
    # Add mirrors here if apibay.org itself ever blocks; same q.php API.
)


async def query_tpb(
    client: httpx.AsyncClient,
    query: str,
    *,
    limit: int = 100,
) -> list[dict]:
    """
    Direct search against TPB's public JSON API (apibay.org/q.php).

    Returns the same result shape as query_prowlarr so callers don't need to
    branch: {name, info_hash, magnet, size, seeders, quality}.

    apibay returns [{"id":"0","name":"No results returned",...}] on empty
    matches — we detect that sentinel and return [].
    """
    results: list[dict] = []
    if not query:
        return results

    import urllib.parse as _up
    q = _up.quote(query, safe="")

    for host in _APIBAY_HOSTS:
        url = f"{host}/q.php?q={q}&cat=0"
        try:
            log.debug(f"TPB search: {url}")
            r = await client.get(url, timeout=20)
            if r.status_code != 200:
                log.info(f"TPB {host} HTTP {r.status_code} for {query!r}")
                continue
            data = r.json()
        except Exception as e:
            log.info(f"TPB {host} error for {query!r}: {e}")
            continue

        if not isinstance(data, list) or not data:
            continue
        # Empty-result sentinel — single row with id="0" / name like
        # "No results returned" / info_hash all zeros.
        if (len(data) == 1
                and (data[0].get("id") in ("0", 0)
                     or "No results" in (data[0].get("name") or ""))):
            log.info(f"TPB: 0 results for {query!r}")
            return []

        for item in data[:limit]:
            name      = (item.get("name") or "").strip()
            info_hash = (item.get("info_hash") or "").lower().strip()
            if not name or not info_hash or len(info_hash) != 40:
                continue
            try:
                size    = int(item.get("size") or 0)
                seeders = int(item.get("seeders") or 0)
            except (TypeError, ValueError):
                size, seeders = 0, 0

            magnet = _build_magnet(info_hash, name, "")
            results.append({
                "name":      name,
                "info_hash": info_hash,
                "magnet":    magnet,
                "size":      size,
                "seeders":   seeders,
                "quality":   _detect_quality(name),
            })

        log.info(f"TPB: {len(results)} results for {query!r} via {host}")
        return results

    return results


async def search_prowlarr_or_tpb(
    client: httpx.AsyncClient,
    prowlarr_url: str,
    prowlarr_key: str,
    query: str,
    *,
    cat: str = "2000,5000",
    limit: int = 100,
) -> list[dict]:
    """
    Try Prowlarr first. If it returns nothing AND its failure was the
    "all indexers unavailable" 400 response (or Prowlarr is unconfigured),
    fall back to TPB. This keeps user searches working when Prowlarr is
    technically up but its indexers are dry.

    Tracks the reason for an empty Prowlarr result via a sentinel set on
    the client by query_prowlarr (`_last_prowlarr_empty_reason`). Falls
    back on "all indexers unavailable" or HTTP/transport failures.
    """
    used_fallback_reason = None

    if prowlarr_url and prowlarr_key:
        # Reset sentinel for this call
        setattr(client, "_last_prowlarr_empty_reason", None)
        results = await query_prowlarr(
            client, prowlarr_url, prowlarr_key, query, cat=cat, limit=limit,
        )
        if results:
            return results
        used_fallback_reason = getattr(client, "_last_prowlarr_empty_reason", None)
        if used_fallback_reason is None:
            # Prowlarr gave a clean empty result (200 OK, 0 items) — no need
            # to bother TPB. The query just doesn't exist.
            return results
    else:
        used_fallback_reason = "prowlarr_unconfigured"

    log.info(
        f"🌊 TPB fallback engaged for {query!r} "
        f"(prowlarr reason: {used_fallback_reason})"
    )
    return await query_tpb(client, query, limit=limit)


# ── Index a movie ─────────────────────────────────────────────────────────────

async def index_movie(
    hi: HashIndex,
    *,
    prowlarr_url: str,
    prowlarr_key: str,
    api_key: str,
    title: str,
    year: Optional[int],
    preferred_quality: str = "1080p",
) -> int:
    """
    Search Prowlarr for a movie, check AllDebrid cache, upsert scored entries.
    Returns the count of cached hashes stored.
    """
    queries = [f"{title} {year}" if year else title]
    if year:
        queries.append(title)  # fallback without year

    async with httpx.AsyncClient() as client:
        seen_hashes: set[str] = set()
        candidates = []

        for q in queries:
            results = await search_strict_with_tpb_fallback(
                client, prowlarr_url, prowlarr_key, q,
                title=title, year=year, media_type="movie", strategy="movie",
            )
            for r in results:
                h = r["info_hash"]
                if h not in seen_hashes:
                    seen_hashes.add(h)
                    candidates.append(r)
            if candidates:
                break  # first query gave results
            await asyncio.sleep(0.5)

        if not candidates:
            log.info(f"[MOVIE] No Prowlarr results for {title!r}")
            return 0

        # AllDebrid instant availability check
        hashes     = [c["info_hash"] for c in candidates]
        cached_set = await check_alldebrid_cache(client, api_key, hashes)

        stored = 0
        for c in candidates:
            h = c["info_hash"]
            is_cached = h in cached_set
            pts = hi.upsert(
                media_type="movie",
                title=title,
                year=year,
                season=None,
                episode=None,
                info_hash=h,
                magnet=c["magnet"],
                torrent_name=c["name"],
                quality=c["quality"],
                strategy="movie",
                is_cached=is_cached,
                file_size=c["size"],
                seeders=c.get("seeders", 0),
                preferred_quality=preferred_quality,
            )
            if is_cached:
                stored += 1
            log.info(f"  [MOVIE] {c['name'][:60]} cached={is_cached} score={pts}")

        return stored


# ── Index a series ────────────────────────────────────────────────────────────

async def index_series(
    hi: HashIndex,
    *,
    prowlarr_url: str,
    prowlarr_key: str,
    api_key: str,
    title: str,
    year: Optional[int],
    season_count: int,
    is_ended: bool,
    preferred_quality: str = "1080p",
) -> dict:
    """
    Search Prowlarr for series packs and each season pack.
    Check AllDebrid cache, upsert scored entries.
    Returns {"series_packs": N, "season_packs": N, "episodes": N}.
    """
    counts = {"series_packs": 0, "season_packs": 0, "episodes": 0}

    async with httpx.AsyncClient() as client:
        # Series pack first (highest value)
        sp_results = await search_strict_with_tpb_fallback(
            client, prowlarr_url, prowlarr_key,
            f"{title} complete series" if year is None else f"{title} {year} complete",
            title=title, year=year, media_type="episode", strategy="series_pack",
        )
        if not sp_results:
            sp_results = await search_strict_with_tpb_fallback(
                client, prowlarr_url, prowlarr_key, f"{title} complete",
                title=title, year=year, media_type="episode", strategy="series_pack",
            )

        series_hashes = [r["info_hash"] for r in sp_results]
        series_cached = await check_alldebrid_cache(client, api_key, series_hashes) if series_hashes else set()
        for r in sp_results:
            mt   = _media_type_from_torrent(r["name"], "episode")
            is_c = r["info_hash"] in series_cached
            hi.upsert(
                media_type=mt,
                title=title, year=year,
                season=None, episode=None,
                info_hash=r["info_hash"], magnet=r["magnet"],
                torrent_name=r["name"], quality=r["quality"],
                strategy="series_pack", is_cached=is_c,
                seeders=r.get("seeders", 0),
                file_size=r["size"], preferred_quality=preferred_quality,
            )
            if is_c and mt == "series":
                counts["series_packs"] += 1

        await asyncio.sleep(0.5)

        # Season packs
        for sn in range(1, min(season_count + 1, 30)):
            sn_results = await search_strict_with_tpb_fallback(
                client, prowlarr_url, prowlarr_key,
                f"{title} season {sn}",
                title=title, year=year, media_type="episode", season=sn, strategy="season_pack",
            )
            if not sn_results:
                sn_results = await search_strict_with_tpb_fallback(
                    client, prowlarr_url, prowlarr_key,
                    f"{title} S{sn:02d}",
                    title=title, year=year, media_type="episode", season=sn, strategy="season_pack",
                )

            sn_hashes = [r["info_hash"] for r in sn_results]
            sn_cached = await check_alldebrid_cache(client, api_key, sn_hashes) if sn_hashes else set()
            for r in sn_results:
                mt   = _media_type_from_torrent(r["name"], "episode")
                is_c = r["info_hash"] in sn_cached
                hi.upsert(
                    media_type=mt,
                    title=title, year=year,
                    season=sn, episode=None,
                    info_hash=r["info_hash"], magnet=r["magnet"],
                    torrent_name=r["name"], quality=r["quality"],
                    strategy="season_pack", is_cached=is_c,
                    seeders=r.get("seeders", 0),
                    file_size=r["size"], preferred_quality=preferred_quality,
                )
                if is_c and mt == "season":
                    counts["season_packs"] += 1

            await asyncio.sleep(0.3)

    log.info(f"[SERIES] {title!r} indexed: {counts}")
    return counts


# ── Miss-triggered targeted search ───────────────────────────────────────────

async def search_and_index(
    hi: HashIndex,
    *,
    prowlarr_url: str,
    prowlarr_key: str,
    api_key: str,
    title: str,
    year: Optional[int],
    media_type: str,
    season: Optional[int] = None,
    episode: Optional[int] = None,
    preferred_quality: str = "1080p",
) -> int:
    """
    Targeted search triggered when the index misses on a play request.
    Populates the index then returns the count of cached hits found.
    The caller retries lookup() after this returns.
    """
    if media_type == "movie":
        return await index_movie(
            hi,
            prowlarr_url=prowlarr_url,
            prowlarr_key=prowlarr_key,
            api_key=api_key,
            title=title,
            year=year,
            preferred_quality=preferred_quality,
        )

    # Episode — try title variants and cached packs before exact episodes.
    # This fixes titles like Euphoria (US), That '70s Show, and The Simpsons
    # without allowing look-alikes such as Ted Lasso or Love Island UK.
    queries = []
    for tv_title in _search_title_variants(title):
        if season:
            queries.append((f"{tv_title} S{season:02d}", season, None, "season_pack"))
            queries.append((f"{tv_title} season {season}", season, None, "season_pack"))
        queries.append((f"{tv_title} complete series", None, None, "series_pack"))
        queries.append((f"{tv_title} complete", None, None, "series_pack"))
        if season and episode:
            queries.append((f"{tv_title} S{season:02d}E{episode:02d}", season, episode, "episode"))
            queries.append((f"{tv_title} {season}x{episode:02d}", season, episode, "episode"))

    total_cached = 0
    async with httpx.AsyncClient() as client:
        seen: set[str] = set()
        for query, sn, ep, strategy in queries:
            results = await search_strict_with_tpb_fallback(
                client, prowlarr_url, prowlarr_key, query,
                title=title, year=year, media_type="episode",
                season=sn, episode=ep, strategy=strategy,
            )
            if not results:
                await asyncio.sleep(0.3)
                continue

            new = [r for r in results if r["info_hash"] not in seen]
            if not new:
                continue
            for r in new:
                seen.add(r["info_hash"])

            hashes = [r["info_hash"] for r in new]
            cached_set = await check_alldebrid_cache(client, api_key, hashes)
            for r in new:
                is_c = r["info_hash"] in cached_set
                mt   = _media_type_from_torrent(r["name"], "episode")
                hi.upsert(
                    media_type=mt,
                    title=title, year=year,
                    season=sn, episode=ep,
                    info_hash=r["info_hash"], magnet=r["magnet"],
                    torrent_name=r["name"], quality=r["quality"],
                    strategy=strategy, is_cached=is_c,
                    seeders=r.get("seeders", 0),
                    file_size=r["size"], preferred_quality=preferred_quality,
                )
                if is_c:
                    total_cached += 1

            if total_cached > 0:
                break  # found cached content — stop searching
            await asyncio.sleep(0.4)

    return total_cached


# ── Background recheck loop ───────────────────────────────────────────────────

async def recheck_stale(
    hi: HashIndex,
    api_key: str,
    limit: int = 200,
    older_than_hours: int = 6,
) -> dict:
    """
    Re-verify stale hashes against AllDebrid. Updates is_cached and score.
    Called by the background recheck loop every 6 hours.
    Returns {rechecked, now_cached, evicted}.
    """
    stale = hi.get_stale(older_than_hours=older_than_hours, limit=limit)
    if not stale:
        return {"rechecked": 0, "now_cached": 0, "evicted": 0}

    hashes = [r["info_hash"] for r in stale]
    async with httpx.AsyncClient() as client:
        cached_set = await check_alldebrid_cache(client, api_key, hashes)

    now_cached = 0
    evicted    = 0
    for row in stale:
        h          = row["info_hash"]
        was_cached = bool(row["is_cached"])
        is_cached  = h in cached_set
        if is_cached and not was_cached:
            hi.mark_cached(h)
            now_cached += 1
        elif was_cached and not is_cached:
            hi.mark_uncached(h)
            evicted += 1
        else:
            # Just refresh the last_checked timestamp
            hi.upsert(
                media_type=row["media_type"],
                title=row["title"],
                year=row["year"],
                season=row["season"],
                episode=row["episode"],
                info_hash=h,
                magnet=row["magnet"],
                torrent_name=row["torrent_name"] or "",
                quality=row["quality"] or "unknown",
                strategy=row["strategy"] or "unknown",
                is_cached=is_cached,
                file_count=row.get("file_count", 1),
                file_size=row.get("file_size", 0),
            )

    log.info(
        f"[RECHECK] {len(stale)} stale hashes: "
        f"{now_cached} newly cached, {evicted} evicted"
    )
    return {"rechecked": len(stale), "now_cached": now_cached, "evicted": evicted}
