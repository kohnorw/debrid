"""
Debridarr - On-the-fly AllDebrid streaming for Plex
"""

import asyncio
import html as _html
import logging
import re
import sys
import time
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
from urllib.parse import quote

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from app.alldebrid import AllDebridClient, configure_search
from app.cache import CacheDB
from app.config import settings
from app.hash_index import HashIndex, _norm
from app.indexer import index_movie, index_series, recheck_stale, search_and_index
from app.library import LibraryManager, _FAKE_MP4
from app.models import MediaType, PlayEvent
from app.proxy import proxy_stream, stream_direct, write_strm
from app.fuse_mount import (
    start_fuse_mount, stop_fuse_mount,
    register_torrent, unregister_torrent, get_fuse_path,
    list_torrents, list_files, get_torrent_file, get_torrent_files,
    FUSE_AVAILABLE, update_dfs_settings, get_dfs_settings,
)
from app.setup import (
    is_setup_complete, mark_setup_complete,
    load_saved_config, write_env,
    test_alldebrid, test_overseerr, test_plex_root,
)

logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("debridarr")


# ── Helpers ───────────────────────────────────────────────────────────────────

def _schedule_restart(delay: float = 2.0):
    import threading, subprocess, time
    def _do():
        time.sleep(delay)
        log.info("🔄 Restarting...")
        try: subprocess.run(["kill", "-TERM", "1"], check=False)
        except Exception as e: log.error(f"Restart failed: {e}")
    threading.Thread(target=_do, daemon=True).start()




def _btih_from_magnet(magnet: str) -> str:
    """Extract a normalized BitTorrent info hash from a magnet URI."""
    m = re.search(r"(?:^|[?&])xt=urn:btih:([A-Fa-f0-9]{40}|[A-Za-z2-7]{32})", magnet or "")
    return (m.group(1).lower() if m else "")

def _existing_download_payload(row: dict | None) -> dict:
    if not row:
        return {}
    return {
        "ok": True,
        "duplicate": True,
        "message": "Release is already in Downloads; not adding duplicate magnet.",
        "download": row,
        "info_hash": row.get("info_hash") or "",
        "ready": str(row.get("status") or "").lower() in ("ready", "cached", "done", "finished"),
    }


# Per-release add locks prevent double-click / parallel request races from
# uploading the same magnet to AllDebrid twice before the local Downloads row
# has been written.
_DOWNLOAD_ADD_LOCKS: dict[str, asyncio.Lock] = {}

def _download_dedupe_key(info_hash: str = "", magnet: str = "", name: str = "", size: object = None) -> str:
    ih = (info_hash or _btih_from_magnet(magnet) or "").lower().strip()
    if ih:
        return f"hash:{ih}"
    if magnet:
        return "magnet:" + re.sub(r"(&|\?)dn=[^&]+", "", magnet.strip().lower())
    return "name:" + _norm(f"{name or ''}:{size or ''}")

def _download_media_key(media_type: str = "", title: str = "", year=None, season=None, episode=None) -> str:
    """Stable lock/dedupe key for the requested movie or TV item.

    This prevents adding two different releases for the same movie/episode, even
    when their torrent hashes differ.
    """
    mt = (media_type or "movie").lower().strip()
    t = _norm(title or "")
    if not t:
        return ""
    def _num(v):
        try:
            return int(v) if v not in (None, "", 0, "0") else 0
        except Exception:
            return 0
    if mt == "movie":
        return f"media:movie:{t}:{_num(year)}"
    return f"media:tv:{t}:s{_num(season):02d}:e{_num(episode):02d}"

def _get_download_add_lock(key: str) -> asyncio.Lock:
    key = key or "unknown"
    lock = _DOWNLOAD_ADD_LOCKS.get(key)
    if lock is None:
        lock = asyncio.Lock()
        _DOWNLOAD_ADD_LOCKS[key] = lock
    return lock

def _ad_magnet_matches(m: dict, info_hash: str = "", magnet: str = "", name: str = "", size: object = None) -> bool:
    ih = (info_hash or "").lower().strip()
    mh = str(m.get("hash") or m.get("info_hash") or "").lower().strip()
    if ih and mh and ih == mh:
        return True
    mmag = str(m.get("magnet") or m.get("magnetLink") or "")
    if magnet and mmag and magnet.strip().lower() == mmag.strip().lower():
        return True
    # Some AllDebrid status responses do not include the original magnet. As a
    # last-resort dedupe guard, compare normalized filename plus exact size.
    if name:
        mn = str(m.get("filename") or m.get("name") or "")
        ms = m.get("size") or m.get("bytes") or m.get("totalSize")
        try:
            same_size = int(ms or 0) == int(size or 0) and int(size or 0) > 0
        except Exception:
            same_size = False
        if same_size and _norm(mn) == _norm(name):
            return True
    return False

async def _find_existing_alldebrid_magnet(ad: AllDebridClient, *, info_hash: str = "", magnet: str = "", name: str = "", size: object = None) -> dict | None:
    if not hasattr(ad, "list_magnets"):
        return None
    try:
        for m in await ad.list_magnets():
            if _ad_magnet_matches(m, info_hash=info_hash, magnet=magnet, name=name, size=size):
                return m
    except Exception as e:
        log.debug(f"AllDebrid duplicate pre-check failed: {e}")
    return None

def _payload_from_ad_existing(m: dict, info_hash: str = "") -> dict:
    status = str(m.get("status") or m.get("statusCode") or "downloading").lower()
    ready = bool(m.get("ready")) or status in ("ready", "finished", "completed")
    return {
        "ok": True,
        "duplicate": True,
        "message": "Release already exists in AllDebrid; not adding duplicate magnet.",
        "ready": ready,
        "info_hash": (m.get("hash") or m.get("info_hash") or info_hash or ""),
        "download": m,
    }

def _on_play_symlinks_only(app: FastAPI | None) -> bool:
    """Return True when on-play symlink mode is enabled.

    In this mode normal startup/health repair does not mass-create symlinks.
    User playback still creates the requested symlink immediately, and binge
    lookahead is allowed to pre-symlink the next episodes.
    """
    try:
        db = getattr(app.state, "db", None) if app is not None else None
        if db:
            return (db.get_setting("on_play_symlinks_only", "false") or "").lower() in ("1", "true", "yes", "on")
    except Exception:
        pass
    return False



async def _canonical_series_year(app: FastAPI, title: str, year=None) -> Optional[int]:
    """Return the authoritative first-air year for a TV series.

    Search/index/playback must use the series year from the requested
    TMDB/Overseerr title, not an episode air year.  Example: Friends must
    search as 1994 even if the requested season/episode aired in 2002.
    """
    def _int_year(v):
        try:
            y = int(v) if v not in (None, "") else None
            return y if y and 1900 <= y <= 2100 else None
        except Exception:
            return None

    db = getattr(app.state, "db", None) if app is not None else None
    tmdb_key = ""
    lib_entry = None
    if db:
        try:
            tmdb_key = db.get_setting("tmdb_api_key", "") or db.get_setting("TMDB_API_KEY", "") or ""
            rows = db.fake_library_list(media_type="series")
            tl = (title or "").strip().lower()
            lib_entry = next((r for r in rows if (r.get("title") or "").strip().lower() == tl), None)
        except Exception:
            lib_entry = None

    # Prefer the stored TMDB id from Overseerr/TMDB. The id is the strongest
    # signal that this is the exact requested series.
    tmdb_id = (lib_entry or {}).get("tmdb_id") if lib_entry else None
    if tmdb_key and tmdb_id:
        try:
            import httpx as _hx
            async with _hx.AsyncClient(timeout=10) as c:
                r = await c.get(f"https://api.themoviedb.org/3/tv/{tmdb_id}", params={"api_key": tmdb_key})
                if r.status_code == 200:
                    first_air = (r.json() or {}).get("first_air_date") or (r.json() or {}).get("firstAirDate") or ""
                    cy = _int_year(str(first_air)[:4])
                    if cy:
                        if _int_year(year) and _int_year(year) != cy:
                            log.info(f"📺 Corrected series search year for {title!r}: {year} → {cy} from TMDB id={tmdb_id}")
                        return cy
        except Exception as e:
            log.debug(f"_canonical_series_year TMDB id lookup {title!r}: {e}")

    # Fall back to the library year from Overseerr/TMDB if present.
    ly = _int_year((lib_entry or {}).get("year") if lib_entry else None)
    if ly:
        if _int_year(year) and _int_year(year) != ly:
            log.info(f"📺 Corrected series search year for {title!r}: {year} → {ly} from library metadata")
        return ly

    # Last resort: search TMDB by title WITHOUT the supplied year. This avoids
    # baking an episode year into searches for shows like Friends.
    if tmdb_key and title:
        try:
            import httpx as _hx
            async with _hx.AsyncClient(timeout=10) as c:
                r = await c.get("https://api.themoviedb.org/3/search/tv", params={"api_key": tmdb_key, "query": title})
                if r.status_code == 200:
                    results = (r.json() or {}).get("results", []) or []
                    tl = (title or "").strip().lower()
                    picked = next((x for x in results if (x.get("name") or "").strip().lower() == tl), results[0] if results else None)
                    first_air = (picked or {}).get("first_air_date") or ""
                    cy = _int_year(str(first_air)[:4])
                    if cy:
                        if _int_year(year) and _int_year(year) != cy:
                            log.info(f"📺 Corrected series search year for {title!r}: {year} → {cy} from TMDB search")
                        return cy
        except Exception as e:
            log.debug(f"_canonical_series_year TMDB search {title!r}: {e}")

    return _int_year(year)

def _init_clients(app: FastAPI):
    import os
    db: CacheDB = getattr(app.state, "db", None)

    def _cfg(key: str, env_key: str = None, default: str = "") -> str:
        """Read from DB first, fall back to env var, then hardcoded default."""
        if db:
            val = db.get_setting(key, "")
            if val:
                return val
        env_key = env_key or key
        return os.environ.get(env_key, default)

    class _S:
        ALLDEBRID_API_KEY  = _cfg("ALLDEBRID_API_KEY")
        OVERSEERR_URL      = _cfg("OVERSEERR_URL")
        OVERSEERR_API_KEY  = _cfg("OVERSEERR_API_KEY")
        PLEX_ROOT          = _cfg("PLEX_ROOT", default="/plex-strm")
        DEBRIDARR_BASE_URL = _cfg("DEBRIDARR_BASE_URL")
        DB_PATH            = os.environ.get("DB_PATH", "/data/debridarr.db")
        PORT               = int(os.environ.get("PORT", "7474"))
        LOG_LEVEL          = os.environ.get("LOG_LEVEL", "INFO")
        FUSE_MOUNT         = os.environ.get("FUSE_MOUNT", "/mnt/alldebrid")
        FUSE_SYMLINK_ROOT  = os.environ.get("FUSE_SYMLINK_ROOT", "/docker/debridarr/mnt-alldebrid")

    s = _S()
    tmdb_key = db.get_setting("tmdb_api_key", "") if db else ""

    if db:
        configure_search(db.get_all_settings())
    app.state.alldebrid = AllDebridClient(s.ALLDEBRID_API_KEY)
    app.state.library   = LibraryManager(
        overseerr_url=s.OVERSEERR_URL,
        overseerr_key=s.OVERSEERR_API_KEY,
        plex_root=s.PLEX_ROOT,
        tmdb_api_key=tmdb_key,
    )
    app.state.settings  = s
    app.state.fuse_thread = getattr(app.state, "fuse_thread", None)
    log.info(f"✅ Clients initialised — overseerr={s.OVERSEERR_URL or 'not set'}")


async def _index_worker(app: FastAPI):
    """
    Persistent background worker that processes the index queue.
    Runs for the entire lifespan of the app — never cancelled by a request.
    Items are (coro_fn, args) tuples pushed by api_library_add and _run_auto_add.
    """
    global _index_queue
    # Use app.state queue — same object as global, but reliable reference
    q = getattr(app.state, "index_queue", None) or _index_queue
    log.info(f"🗄️  Index worker started — queue={q}")
    while True:
        try:
            coro_fn, args = await q.get()
            fn_name = getattr(coro_fn, "__name__", str(coro_fn))
            title_hint = args[1] if len(args) > 1 else "?"
            log.info(f"🗄️  Index worker picked up: {fn_name}({title_hint!r})")
            try:
                await coro_fn(*args)
            except asyncio.CancelledError:
                pass
            except Exception as e:
                log.error(f"Index worker error in {fn_name}: {e}", exc_info=True)
            finally:
                q.task_done()
        except asyncio.CancelledError:
            break
        except Exception as e:
            log.error(f"Index worker loop error: {e}")
            await asyncio.sleep(1)


def _queue_index(app: FastAPI, coro_fn, *args):
    """
    Fire-and-forget indexing anchored to app.state.index_queue.
    Uses app.state so it's immune to Python global variable scoping issues.
    Falls back to asyncio.ensure_future if the queue isn't ready yet.
    """
    fn_name    = getattr(coro_fn, "__name__", str(coro_fn))
    title_hint = args[1] if len(args) > 1 else "?"

    # Primary: use app.state.index_queue (set in lifespan, same object always)
    q = getattr(app.state, "index_queue", None)
    if q is not None:
        q.put_nowait((coro_fn, args))
        log.info(f"🗄️  Queued: {fn_name}({title_hint!r}) — qsize={q.qsize()}")
        return

    # Fallback: global queue (belt-and-suspenders)
    global _index_queue
    if _index_queue is not None:
        _index_queue.put_nowait((coro_fn, args))
        log.info(f"🗄️  Queued (global): {fn_name}({title_hint!r}) — qsize={_index_queue.qsize()}")
        return

    # Last resort: schedule directly on the running event loop
    log.warning(f"🗄️  No queue available — scheduling {fn_name}({title_hint!r}) directly")
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            asyncio.ensure_future(coro_fn(*args), loop=loop)
            log.info(f"🗄️  Scheduled via ensure_future: {fn_name}({title_hint!r})")
        else:
            log.error(f"🗄️  No running event loop for {fn_name}({title_hint!r})")
    except Exception as e:
        log.error(f"🗄️  Failed to schedule {fn_name}({title_hint!r}): {e}", exc_info=True)




async def _downloads_status_loop(app: FastAPI):
    """Background tracker for uncached AllDebrid downloads.

    The Downloads feature can queue uncached magnets and save their AllDebrid
    magnet id in the downloads table.  A previous merge started this loop from
    lifespan() but dropped the function definition, which caused startup to
    crash with NameError.  Keep this loop defensive: if the table or API is not
    ready yet, it logs and retries instead of taking the app down.
    """
    await asyncio.sleep(5)
    while True:
        try:
            db: CacheDB = getattr(app.state, "db", None)
            alldebrid: AllDebridClient = getattr(app.state, "alldebrid", None)
            hi: HashIndex = getattr(app.state, "hash_index", None)
            if not db or not alldebrid:
                await asyncio.sleep(60)
                continue

            rows = db.list_downloads() if hasattr(db, "list_downloads") else []
            active = [r for r in rows if (r.get("status") or "").lower() not in (
                "ready", "cached", "done", "complete", "completed", "error", "failed", "deleted"
            )]

            for row in active:
                magnet_id = str(row.get("magnet_id") or "").strip()
                info_hash = (row.get("info_hash") or "").lower().strip()
                if not magnet_id:
                    continue
                try:
                    st = await alldebrid.get_magnet_status(magnet_id)
                except Exception as e:
                    log.debug(f"Downloads status check failed for {magnet_id}: {e}")
                    continue

                name = st.get("filename") or st.get("name") or row.get("torrent_name") or ""
                ready = bool(st.get("ready") or st.get("status") in ("Ready", "ready", "completed", "done"))
                error = st.get("error") or ""

                progress = row.get("progress") or 0
                for key in ("progress", "downloaded", "downloadPercent", "percent"):
                    val = st.get(key)
                    if val is None:
                        continue
                    try:
                        progress = float(val)
                        # Some APIs return 0-1; store 0-100 for the UI.
                        if 0 <= progress <= 1:
                            progress *= 100
                        break
                    except Exception:
                        pass

                if error:
                    db.update_download(info_hash=info_hash, magnet_id=magnet_id,
                                       status="error", error=str(error), progress=progress)
                    continue

                if ready:
                    db.update_download(info_hash=info_hash, magnet_id=magnet_id,
                                       status="cached", progress=100, error="")
                    if hi and info_hash:
                        try:
                            hi.mark_cached(info_hash)
                        except Exception as e:
                            log.debug(f"HashIndex mark_cached failed for download {info_hash[:8]}: {e}")
                    log.info(f"⬇️  Download ready/cached: {name or info_hash or magnet_id}")
                else:
                    db.update_download(info_hash=info_hash, magnet_id=magnet_id,
                                       status="downloading", progress=progress, error="")
        except asyncio.CancelledError:
            break
        except Exception as e:
            log.error(f"Downloads status loop error: {e}", exc_info=True)

        # DB setting is optional; default keeps API hits low.
        try:
            db = getattr(app.state, "db", None)
            interval = int(db.get_setting("downloads_status_interval_seconds", "300") if db else "300")
        except Exception:
            interval = 300
        await asyncio.sleep(max(60, interval))


@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info("🚀 Debridarr starting up...")
    for noisy in ("httpx", "httpcore", "multipart", "uvicorn.access"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    import os
    _data_env = Path("/data/.env")
    if _data_env.exists():
        log.info(f"📂 Loading config from {_data_env}")
        for line in _data_env.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            k, v = k.strip(), v.strip()
            if k and v and not os.environ.get(k):
                os.environ[k] = v

    db = CacheDB(settings.DB_PATH)
    db.init()
    db.bootstrap_from_env()   # seed DB from env vars on first run
    app.state.db = db

    # Initialise hash index (table created inside CacheDB.init already)
    hi = HashIndex(settings.DB_PATH)
    app.state.hash_index = hi
    log.info(f"🗄️  HashIndex attached — stats: {hi.stats()}")

    app.state.setup_complete = is_setup_complete()

    # Sync any previously resolved streams into the hash index immediately
    # This ensures the index is populated even if add-time indexing failed
    try:
        asyncio.create_task(_sync_streams_to_index(app))
    except Exception:
        pass  # lifespan hasn't yielded yet — will run once loop starts

    # Log clearly which settings are active and where they came from
    ss = db.get_all_settings()
    log.info(f"📦 DB path: {settings.DB_PATH}")
    log.info(f"📦 Settings loaded from DB — "
             f"api_key={'set' if ss.get('ALLDEBRID_API_KEY') else 'NOT SET'}, "
             f"overseerr={'set' if ss.get('OVERSEERR_URL') else 'NOT SET'}, "
             f"plex_root={ss.get('PLEX_ROOT') or 'NOT SET'}, "
             f"precache={ss.get('precache_enabled','true')}")

    # Reset any entries stuck in "resolving" from a previous crashed run
    # Also recover entries that had symlinks (were cached) but got stuck
    stuck = 0
    recovered_symlinks = 0
    with db._connect() as conn:
        result = conn.execute(
            "UPDATE cache SET status='not_found' WHERE status='resolving'"
        )
        stuck = result.rowcount
        # Any not_found entry that still has a valid symlink path → restore to cached
        # These are entries that were cached, then something went wrong on restart
        not_found = conn.execute(
            "SELECT cache_key, strm_path FROM cache WHERE status='not_found' AND strm_path IS NOT NULL"
        ).fetchall()
        for row in not_found:
            strm = row[1]
            if strm and Path(strm).is_symlink():
                conn.execute(
                    "UPDATE cache SET status='cached' WHERE cache_key=?", (row[0],)
                )
                recovered_symlinks += 1
    if stuck:
        log.info(f"🔄 Reset {stuck} stuck 'resolving' entries → 'not_found'")
    if recovered_symlinks:
        log.info(f"🔄 Recovered {recovered_symlinks} entries with existing symlinks → 'cached'")

    _init_clients(app)
    s = app.state.settings
    log.info(f"✅ Debridarr ready — plex_root={s.PLEX_ROOT or 'NOT SET'}")

    # Load DFS settings
    try:
        import json as _json
        saved_dfs = db.get_setting("dfs_settings")
        if saved_dfs:
            update_dfs_settings(_json.loads(saved_dfs))
        else:
            cache_dir = s.FUSE_SYMLINK_ROOT.replace("mnt-alldebrid", "tmp/cache") if s.FUSE_SYMLINK_ROOT else "/docker/debridarr/tmp/cache"
            update_dfs_settings({"cache_dir": cache_dir})
    except Exception as e:
        log.debug(f"DFS settings: {e}")

    try:
        Path(get_dfs_settings()["cache_dir"]).mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

    # Start FUSE
    if FUSE_AVAILABLE:
        _loop = asyncio.get_event_loop()
        _t = start_fuse_mount(s.FUSE_MOUNT, app.state.alldebrid, _loop)
        app.state.fuse_thread = _t
        if _t:
            log.info(f"🗂️  FUSE at {s.FUSE_MOUNT}")
            asyncio.create_task(_load_all_torrents(app))
    else:
        app.state.fuse_thread = None
        log.warning("⚠️  FUSE unavailable")

    global _index_queue
    _index_queue = asyncio.Queue()
    app.state.index_queue = _index_queue   # also on app.state for reliable access
    asyncio.create_task(_index_worker(app))
    asyncio.create_task(_cleanup_loop(app))
    asyncio.create_task(_symlink_health_loop(app))
    asyncio.create_task(_plex_strm_watcher(app))
    asyncio.create_task(_episode_sync_loop(app))
    asyncio.create_task(_upcoming_episode_watcher(app))
    asyncio.create_task(_auto_add_loop(app))
    asyncio.create_task(_hash_index_recheck_loop(app))
    asyncio.create_task(_verify_symlinks_loop(app))
    asyncio.create_task(_downloads_status_loop(app))

    yield

    if getattr(app.state, "fuse_thread", None):
        stop_fuse_mount(app.state.settings.FUSE_MOUNT)


app = FastAPI(title="Debridarr", version="0.5.0", lifespan=lifespan)


def _needs_setup(request: Request) -> bool:
    return not getattr(request.app.state, "setup_complete", False)

def _setup_redirect():
    return RedirectResponse("/setup", status_code=302)


# ── Job registry ──────────────────────────────────────────────────────────────
import uuid as _uuid
from collections import deque

_jobs: dict[str, dict] = {}          # job_id → job dict
_jobs_history: deque   = deque(maxlen=200)  # completed jobs (capped)
_resolve_semaphore: Optional[asyncio.Semaphore] = None  # set at startup
_precache_tasks: dict[str, asyncio.Task] = {}           # title.lower() → running precache Task
_index_queue: asyncio.Queue = None                          # type: ignore  # set at startup

def _get_semaphore(app=None) -> asyncio.Semaphore:
    global _resolve_semaphore
    if _resolve_semaphore is None:
        count = 3  # default worker count
        if app:
            try:
                db = getattr(app.state, "db", None)
                if db:
                    count = int(db.get_setting("resolve_workers", str(count)))
            except Exception:
                pass
        _resolve_semaphore = asyncio.Semaphore(count)
    return _resolve_semaphore


def _reset_semaphore(count: int):
    global _resolve_semaphore
    _resolve_semaphore = asyncio.Semaphore(count)


def _job_start(name: str, job_type: str = "resolve", cancellable: bool = True) -> tuple[str, asyncio.Event]:
    jid   = _uuid.uuid4().hex[:8]
    event = asyncio.Event()
    _jobs[jid] = {
        "id":          jid,
        "name":        name,
        "type":        job_type,
        "status":      "running",
        "started_at":  datetime.utcnow().isoformat(),
        "finished_at": None,
        "error":       None,
        "cancel_event": event,
        "cancellable": cancellable,
    }
    return jid, event


def _job_done(jid: str, error: str = None):
    if jid not in _jobs:
        return
    job = _jobs.pop(jid)
    job["status"]      = "error" if error else "done"
    job["finished_at"] = datetime.utcnow().isoformat()
    job["error"]       = error
    job.pop("cancel_event", None)
    _jobs_history.appendleft(job)


# ── Styles ────────────────────────────────────────────────────────────────────
_CSS = """
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
       background: #0f0f13; color: #e0e0e0; min-height: 100vh; }
header { background: #1a1a24; border-bottom: 1px solid #2a2a3a;
         padding: 14px 28px; display: flex; align-items: center; gap: 16px; }
header h1 { font-size: 1.3rem; color: #fff; }
header .ver { font-size: 0.75rem; background: #f97316; color: #fff;
              border-radius: 4px; padding: 2px 8px; }
nav { display: flex; gap: 4px; margin-left: auto; }
nav a { color: #aaa; text-decoration: none; padding: 6px 14px; border-radius: 6px;
        font-size: 0.85rem; transition: background .15s; }
nav a:hover, nav a.active { background: #2a2a3a; color: #fff; }
main { padding: 28px; max-width: 1400px; margin: 0 auto; }
h2 { font-size: 1.05rem; color: #ccc; margin-bottom: 18px; }
.card-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 14px; }
.card { background: #1a1a24; border: 1px solid #2a2a3a; border-radius: 10px; overflow: hidden; }
.card img { width: 100%; aspect-ratio: 2/3; object-fit: cover; background: #111; display: block; }
.card .no-poster { width: 100%; aspect-ratio: 2/3; background: #1a1a2e;
                   display: flex; align-items: center; justify-content: center;
                   font-size: 2rem; color: #333; }
.card .info { padding: 10px 12px; }
.card .title { font-size: 0.85rem; font-weight: 600; color: #e0e0e0;
               white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.card .meta  { font-size: 0.72rem; color: #555; margin-top: 3px; }
.card .actions { padding: 0 10px 10px; display: flex; gap: 6px; flex-wrap: wrap; }
.btn { display: inline-block; padding: 5px 12px; border-radius: 6px; font-size: 0.78rem;
       font-weight: 600; border: none; cursor: pointer; text-decoration: none; transition: opacity .15s; }
.btn-add  { background: #f97316; color: #fff; }
.btn-add:hover { opacity: .85; }
.btn-rem  { background: #3b1f00; color: #fb923c; }
.btn-sec  { background: #1e3a5f; color: #60a5fa; }
.badge-in { display: inline-block; background: #14532d; color: #4ade80;
            font-size: 0.68rem; font-weight: 700; padding: 2px 7px; border-radius: 20px; }
.badge-grey { display: inline-block; background: #1a1a24; color: #555;
              font-size: 0.68rem; padding: 2px 7px; border-radius: 20px; border: 1px solid #2a2a3a; }
.search-bar { display: flex; gap: 10px; margin-bottom: 20px; }
.search-bar input { flex: 1; background: #1a1a24; border: 1px solid #2a2a3a;
                    border-radius: 8px; padding: 9px 14px; color: #e0e0e0; font-size: 0.9rem; outline: none; }
.search-bar input:focus { border-color: #f97316; }
.tabs { display: flex; gap: 2px; margin-bottom: 20px; }
.tab { padding: 8px 20px; border-radius: 8px; cursor: pointer; font-size: 0.85rem;
       font-weight: 600; border: 1px solid #2a2a3a; background: #1a1a24; color: #888; }
.pg-bar { display:flex;gap:4px;align-items:center;justify-content:center;margin:24px 0 8px;flex-wrap:wrap; }
.pg-btn { display:inline-flex;align-items:center;justify-content:center;min-width:34px;height:34px;
  padding:0 8px;border-radius:6px;border:1px solid #2a2a3a;background:#1a1a24;color:#aaa;
  font-size:0.82rem;font-weight:600;text-decoration:none;cursor:pointer; }
.pg-btn:hover { border-color:#f97316;color:#f97316; }
.pg-cur { background:#f97316;border-color:#f97316;color:#fff;cursor:default; }
.pg-dis { opacity:0.35;cursor:default; }
.tab.active { background: #f97316; color: #fff; border-color: #f97316; }
.empty { text-align: center; padding: 60px; color: #444; font-size: 0.9rem; }
.toast { position: fixed; bottom: 24px; right: 24px; background: #1a1a24;
         border: 1px solid #2a2a3a; border-radius: 10px; padding: 12px 20px;
         font-size: 0.85rem; opacity: 0; transition: opacity .3s; z-index: 999; }
.toast.show { opacity: 1; }
table { width: 100%; border-collapse: collapse; background: #1a1a24;
        border-radius: 10px; overflow: hidden; }
th { text-align: left; padding: 11px 14px; font-size: 0.72rem; text-transform: uppercase;
     color: #555; border-bottom: 1px solid #2a2a3a; }
td { padding: 10px 14px; border-bottom: 1px solid #1e1e2e; font-size: 0.85rem; }
tr:last-child td { border-bottom: none; }
.pill { padding: 2px 9px; border-radius: 20px; font-size: 0.72rem; font-weight: 600; }
.pill-ok   { background: #14532d; color: #4ade80; }
.pill-res  { background: #1e3a5f; color: #60a5fa; }
.pill-err  { background: #3b0000; color: #f87171; }
.pill-pend { background: #2d2d00; color: #facc15; }
.pill-nf   { background: #3b1f00; color: #fb923c; }
"""

_NAV = lambda active: f"""
<nav>
  <a href="/library"      class="{'active' if active=='library'     else ''}">📚 Add to Library</a>
  <a href="/import"       class="{'active' if active=='import'      else ''}">⬇️ Import</a>
  <a href="/streams"      class="{'active' if active=='streams'     else ''}">⚡ Streams</a>
  <a href="/downloads"    class="{'active' if active=='downloads'   else ''}">⬇️ Downloads</a>
  <a href="/hash-indexer" class="{'active' if active=='hashindexer' else ''}">🔎 Hash Indexer</a>
  <a href="/jobs"         class="{'active' if active=='jobs'        else ''}">⚙️ Jobs</a>
  <a href="/pins"         class="{'active' if active=='pins'        else ''}">📌 Pinned</a>
  <a href="/settings"     class="{'active' if active=='settings'    else ''}">⚙️ Settings</a>
</nav>"""

_TOAST_JS = """
function toast(msg, ok=true) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.style.borderColor = ok ? '#4ade80' : '#f87171';
  t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 3500);
}"""

_GLOBAL_UI_JS = r"""
(function(){
  'use strict';
  if (window.__debridarrGlobalButtonsLoaded) return;
  window.__debridarrGlobalButtonsLoaded = true;

  function notify(msg, ok){
    if (typeof window.toast === 'function') return window.toast(msg, ok !== false);
    var box = document.getElementById('result-msg') || document.getElementById('toast');
    if (box){ box.textContent = msg; box.style.display='block'; box.classList && box.classList.add('show'); setTimeout(function(){ box.classList && box.classList.remove('show'); if(box.id==='result-msg') box.style.display='none'; }, 3500); }
    else console.log(msg);
  }
  function decodeBtn(btn, key, fallback){
    fallback = fallback || '';
    if (!btn) return fallback;
    var enc = btn.dataset ? btn.dataset[key + 'Enc'] : '';
    if (enc){ try { return decodeURIComponent(enc); } catch(e){} }
    return (btn.dataset && btn.dataset[key]) || fallback;
  }
  function jsonFetch(url, opts){
    opts = opts || {};
    return fetch(url, opts).then(function(r){
      return r.text().then(function(t){
        var d = {}; try { d = t ? JSON.parse(t) : {}; } catch(e){ d = {detail:t}; }
        if (!r.ok) throw new Error(d.detail || d.message || ('HTTP '+r.status));
        return d;
      });
    });
  }
  function lock(btn, text){
    if (!btn) return function(){};
    var old = btn.textContent;
    btn.disabled = true;
    if (text) btn.textContent = text;
    return function(){ btn.disabled = false; btn.textContent = old; };
  }

  window.go = window.go || function(){
    var q = document.getElementById('q');
    var tab = new URLSearchParams(location.search).get('tab') || 'all';
    location.href = location.pathname + '?tab=' + encodeURIComponent(tab) + '&q=' + encodeURIComponent(q ? q.value : '');
  };

  window.triggerReindex = window.triggerReindex || function(){
    var tab = new URLSearchParams(location.search).get('tab') || 'all';
    return jsonFetch('/api/hash-index/reindex', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({category:tab})
    }).then(function(d){ notify(d.message || 'Re-index started'); }).catch(function(e){ notify('❌ '+e.message, false); });
  };
  window.triggerRecheck = window.triggerRecheck || function(){
    return jsonFetch('/api/hash-index/recheck', {method:'POST'}).then(function(d){ notify(d.message || 'Recheck queued'); }).catch(function(e){ notify('❌ '+e.message, false); });
  };
  window.syncStreams = window.syncStreams || function(){
    return jsonFetch('/api/hash-index/sync-streams', {method:'POST'}).then(function(d){ notify(d.message || 'Sync complete'); }).catch(function(e){ notify('❌ '+e.message, false); });
  };

  window.reindexTitleFromBtn = function(btn){
    var title = decodeBtn(btn, 'title', '');
    if (!title) return notify('❌ Missing title', false);
    var unlock = lock(btn, '⏳');
    jsonFetch('/api/hash-index/reindex-title', {
      method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({title:title})
    }).then(function(d){ notify(d.message || ('Re-indexing '+title)); })
      .catch(function(e){ notify('❌ '+e.message, false); })
      .finally(unlock);
  };

  function esc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  function fmtHash(h){ h=String(h||''); return h ? h.slice(0,12)+'…'+h.slice(-8) : '—'; }

  window.showDetailFromBtn = function(btn){
    var title = decodeBtn(btn, 'title', '');
    var kind  = decodeBtn(btn, 'kind', (btn && btn.dataset && btn.dataset.kind) || 'movie');
    return openHashDetail(title, kind);
  };
  window.showDetail = window.showDetail || function(title, kind){ return openHashDetail(title, kind || 'movie'); };

  function ensureDrawer(){
    var d = document.getElementById('detail-drawer');
    var o = document.getElementById('detail-overlay');
    if (!d){
      d = document.createElement('div');
      d.id = 'detail-drawer';
      d.style.cssText = 'display:none;position:fixed;right:0;top:0;bottom:0;width:520px;max-width:92vw;background:#111118;border-left:1px solid #2a2a3a;z-index:1001;overflow:auto;padding:20px;box-shadow:-10px 0 30px #0008';
      d.innerHTML = '<div style="display:flex;justify-content:space-between;gap:10px;align-items:center;margin-bottom:14px"><h3 id="detail-title" style="margin:0;color:#eee">Details</h3><button type="button" class="btn btn-sec" data-global-close-detail>✕</button></div><div id="detail-body"></div>';
      document.body.appendChild(d);
    }
    if (!o){
      o = document.createElement('div');
      o.id = 'detail-overlay';
      o.style.cssText = 'display:none;position:fixed;inset:0;background:#0008;z-index:1000';
      o.setAttribute('data-global-close-detail','1');
      document.body.appendChild(o);
    }
    return {drawer:d, overlay:o};
  }
  function closeDetail(){
    var d=document.getElementById('detail-drawer'), o=document.getElementById('detail-overlay');
    if(d) d.style.display='none'; if(o) o.style.display='none';
  }
  window.closeDetail = window.closeDetail || closeDetail;

  function openHashDetail(title, kind){
    if (!title) return notify('❌ Missing title for detail', false);
    var ui = ensureDrawer();
    ui.drawer.dataset.title = title;
    ui.drawer.dataset.kind = kind || 'movie';
    var tt = document.getElementById('detail-title');
    var body = document.getElementById('detail-body');
    if (tt) tt.textContent = title;
    if (body) body.innerHTML = '<div style="color:#777;padding:20px 0">Loading…</div>';
    ui.drawer.style.display='block'; ui.overlay.style.display='block';
    return jsonFetch('/api/hash-index/detail?title=' + encodeURIComponent(title))
      .then(function(d){ renderHashDetail(title, kind, d); })
      .catch(function(e){ if(body) body.innerHTML='<div style="color:#f87171">Detail failed: '+esc(e.message)+'</div>'; notify('❌ Detail failed: '+e.message, false); });
  }

  function renderHashDetail(title, kind, data){
    var body = document.getElementById('detail-body'); if (!body) return;
    var rows = data.hashes || data.results || [];
    var html = '<div style="font-size:.78rem;color:#777;margin-bottom:12px">'+rows.length+' indexed torrent'+(rows.length===1?'':'s')+'</div>';
    if (!rows.length){ body.innerHTML = html + '<div class="empty" style="padding:30px 0">No hashes indexed for this title.</div>'; return; }
    rows.forEach(function(h){
      var cached = !!(h.is_cached || h.cached || h.ready);
      var black = !!h.blacklisted;
      var hash = h.info_hash || h.hash || '';
      var name = h.name || h.torrent_name || h.release_title || '';
      html += '<div style="background:'+(black?'#1c0f0f':'#1a1a24')+';border:1px solid '+(cached?'#14532d':black?'#5a2020':'#2a2a3a')+';border-radius:10px;padding:12px;margin-bottom:10px">'
        + '<div style="font-weight:700;color:#e0e0e0;word-break:break-word">'+esc(name || title)+'</div>'
        + '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:7px;font-size:.72rem;color:#777">'
        + '<span>'+(cached?'✅ cached':'⬇ uncached')+'</span>'
        + (h.quality ? '<span>'+esc(h.quality)+'</span>' : '')
        + (h.season ? '<span>S'+String(h.season).padStart(2,'0')+(h.episode?'E'+String(h.episode).padStart(2,'0'):'')+'</span>' : '')
        + '<span>'+esc(fmtHash(hash))+'</span>'
        + '</div><div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:10px">'
        + '<button type="button" class="btn btn-sec hi-copy-btn" data-hash="'+esc(hash)+'">copy</button>'
        + '<button type="button" class="btn btn-add hi-add-download-btn" data-hash="'+esc(hash)+'" data-title="'+esc(title)+'" data-name="'+esc(name)+'" data-cached="'+(cached?'1':'0')+'">'+(cached?'Add':'Download')+'</button>'
        + '<button type="button" class="btn btn-rem hi-remove-btn" data-hash="'+esc(hash)+'" data-title="'+esc(title)+'" data-name="'+esc(name)+'">Remove</button>'
        + '<button type="button" class="btn btn-rem hi-blacklist-btn" data-hash="'+esc(hash)+'" data-title="'+esc(title)+'" data-name="'+esc(name)+'">Blacklist</button>'
        + '</div></div>';
    });
    body.innerHTML = html;
  }

  function addHashToDownloads(btn){
    var h = btn.dataset.hash || ''; if (!h) return notify('❌ Missing hash', false);
    var cached = btn.dataset.cached === '1';
    var unlock = lock(btn, cached ? 'Adding…' : 'Starting…');
    jsonFetch('/api/hash-index/add-to-downloads', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({info_hash:h})})
      .then(function(d){ notify(d.ready ? '✅ Added cached torrent' : '⬇ Download started'); btn.textContent = d.ready ? 'Added' : 'Downloading'; setTimeout(function(){ var dr=document.getElementById('detail-drawer'); if(dr && dr.dataset.title) openHashDetail(dr.dataset.title, dr.dataset.kind || 'tv'); }, 700); })
      .catch(function(e){ notify('❌ '+e.message, false); unlock(); });
  }
  function postHash(btn, url, label){
    var h = btn.dataset.hash || ''; if (!h) return notify('❌ Missing hash', false);
    if (!confirm(label + ' this hash?')) return;
    var unlock = lock(btn, '⏳');
    jsonFetch(url, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({info_hash:h})})
      .then(function(){ notify('✅ '+label+' complete'); var dr=document.getElementById('detail-drawer'); if(dr && dr.dataset.title) openHashDetail(dr.dataset.title, dr.dataset.kind || 'tv'); })
      .catch(function(e){ notify('❌ '+e.message, false); })
      .finally(unlock);
  }
  function copyText(txt){
    if (navigator.clipboard && navigator.clipboard.writeText && window.isSecureContext) return navigator.clipboard.writeText(txt);
    var ta=document.createElement('textarea'); ta.value=txt; ta.style.position='fixed'; ta.style.left='-9999px'; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta); return Promise.resolve();
  }

  document.addEventListener('click', function(e){
    var b;
    if ((b=e.target.closest('[data-global-close-detail]'))){ e.preventDefault(); e.stopPropagation(); closeDetail(); return; }
    if ((b=e.target.closest('.hi-detail'))){ e.preventDefault(); e.stopPropagation(); window.showDetailFromBtn(b); return; }
    if ((b=e.target.closest('.hi-reindex'))){ e.preventDefault(); e.stopPropagation(); window.reindexTitleFromBtn(b); return; }
    if ((b=e.target.closest('.hi-copy-btn'))){ e.preventDefault(); e.stopPropagation(); copyText(b.dataset.hash || '').then(function(){ notify('Copied'); }); return; }
    if ((b=e.target.closest('.hi-add-download-btn'))){ e.preventDefault(); e.stopPropagation(); addHashToDownloads(b); return; }
    if ((b=e.target.closest('.hi-remove-btn'))){ e.preventDefault(); e.stopPropagation(); postHash(b, '/api/hash-index/delete-entry', 'Remove'); return; }
    if ((b=e.target.closest('.hi-blacklist-btn'))){ e.preventDefault(); e.stopPropagation(); postHash(b, '/api/hash-index/blacklist', 'Blacklist'); return; }
  }, true);

  document.addEventListener('keydown', function(e){
    if (e.key === 'Enter' && e.target && e.target.id === 'q' && location.pathname === '/hash-indexer') { e.preventDefault(); window.go(); }
  }, true);
})();
"""

def _pagination(base_url: str, params: dict, current: int, total: int) -> str:
    """Render a pagination bar. Preserves existing query params."""
    if total <= 1:
        return ""
    def url(p):
        q = "&".join(f"{k}={v}" for k, v in params.items() if v) + f"&page={p}"
        return f"{base_url}?{q}"

    buttons = []
    # Prev
    if current > 1:
        buttons.append(f'<a class="pg-btn" href="{url(current-1)}">‹</a>')
    else:
        buttons.append('<span class="pg-btn pg-dis">‹</span>')

    # Page numbers — show up to 7, with ellipsis
    pages = []
    if total <= 7:
        pages = list(range(1, total+1))
    else:
        pages = [1]
        if current > 3:  pages.append("…")
        for p in range(max(2,current-1), min(total, current+2)):
            pages.append(p)
        if current < total - 2: pages.append("…")
        if total not in pages:  pages.append(total)

    for p in pages:
        if p == "…":
            buttons.append('<span class="pg-btn pg-dis">…</span>')
        elif p == current:
            buttons.append(f'<span class="pg-btn pg-cur">{p}</span>')
        else:
            buttons.append(f'<a class="pg-btn" href="{url(p)}">{p}</a>')

    # Next
    if current < total:
        buttons.append(f'<a class="pg-btn" href="{url(current+1)}">›</a>')
    else:
        buttons.append('<span class="pg-btn pg-dis">›</span>')

    inner = "".join(buttons)
    return f'<div class="pg-bar">{inner}</div>'


def _page(title, nav_active, body, extra=""):
    return HTMLResponse(f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>{title} — Debridarr</title>
  <style>{_CSS}</style>
</head>
<body>
  <header>
    <h1>🎬 Debridarr</h1><span class="ver">v0.5.0</span>
    {_NAV(nav_active)}
  </header>
  <main>{body}</main>
  <div id="toast" class="toast"></div>
  <script>{_TOAST_JS}</script>
  <script>{_GLOBAL_UI_JS}</script>
  {extra}
</body>
</html>""")



# ── Downloads Page ────────────────────────────────────────────────────────────

def _fmt_bytes(n) -> str:
    try:
        n = float(n or 0)
        for unit in ("B", "KB", "MB", "GB", "TB"):
            if n < 1024 or unit == "TB":
                return f"{n:.1f} {unit}" if unit != "B" else f"{int(n)} B"
            n /= 1024
    except Exception:
        return "—"


def _status_pill(status: str) -> str:
    st = (status or "queued").lower()
    cls = "pill-pend"
    if st in ("ready", "cached", "done", "finished"):
        cls = "pill-ok"
    elif st in ("downloading", "queued", "processing"):
        cls = "pill-res"
    elif st in ("error", "failed"):
        cls = "pill-err"
    return f'<span class="pill {cls}">{_html.escape(st)}</span>'


def _visible_downloads(rows: list[dict]) -> list[dict]:
    """Return only downloads that are active right now.

    This intentionally does NOT mean Debridarr's local download history. The
    Downloads tab is a live queue view, so completed/ready/cached/failed/stale
    rows are hidden. The API now prefers the current AllDebrid magnet list and
    only falls back to this filter when AllDebrid is unreachable.
    """
    hidden = {"ready", "cached", "done", "finished", "complete", "completed", "deleted", "expired", "error", "failed"}
    out = []
    for r in rows or []:
        st = str((r or {}).get("status") or "").lower().strip()
        try:
            progress = float((r or {}).get("progress") or 0)
        except Exception:
            progress = 0
        if st in hidden or progress >= 100:
            continue
        out.append(r)
    return out


def _is_active_alldebrid_magnet(m: dict) -> bool:
    """True only for current in-progress AllDebrid magnets.

    AllDebrid's magnet/status lists can include old ready/history items. The
    Downloads page should show the live queue only, so any ready/completed item
    is excluded even if it still exists in the user's AllDebrid account.
    """
    if not m:
        return False
    status = str(m.get("status") or m.get("statusCode") or "").lower().strip()
    status_code = str(m.get("statusCode") or "").strip()
    ready = bool(m.get("ready")) or status in {"ready", "finished", "complete", "completed", "cached", "done"} or status_code == "4"
    if ready:
        return False
    try:
        progress = float(m.get("downloadedPercent") or m.get("progress") or 0)
    except Exception:
        progress = 0
    if progress >= 100:
        return False
    if status in {"deleted", "expired", "error", "failed"}:
        return False
    return True


def _download_row_from_ad_magnet(m: dict) -> dict:
    mid = str(m.get("id") or "")
    info_hash = str(m.get("hash") or m.get("info_hash") or "").lower().strip()
    name = m.get("filename") or m.get("name") or m.get("torrent_name") or f"AllDebrid magnet {mid}"
    try:
        progress = float(m.get("downloadedPercent") or m.get("progress") or 0)
    except Exception:
        progress = 0
    raw_status = str(m.get("status") or "").lower().strip() or "downloading"
    return {
        "magnet_id": mid,
        "info_hash": info_hash or (f"ad-{mid}" if mid else ""),
        "torrent_name": name,
        "title": name,
        "media_type": "unknown",
        "quality": "unknown",
        "seeders": int(m.get("seeders") or 0),
        "size": int(m.get("size") or m.get("totalSize") or 0),
        "status": raw_status,
        "progress": progress,
        "source": "alldebrid_live",
        "created_at": int(m.get("created_at") or m.get("added") or m.get("date") or time.time()),
        "error": str(m.get("error") or ""),
    }


async def _current_alldebrid_download_rows(app: FastAPI) -> list[dict]:
    """Read current active downloads directly from AllDebrid.

    This is the source of truth for the Downloads page. Local DB rows are only
    used for tracking/add metadata and must not make old downloads reappear.
    """
    ad: AllDebridClient = app.state.alldebrid
    db: CacheDB = app.state.db
    if not hasattr(ad, "list_magnets"):
        return []
    magnets = await ad.list_magnets()
    rows = [_download_row_from_ad_magnet(m) for m in magnets if _is_active_alldebrid_magnet(m)]
    # Keep local DB in sync for active rows only, but never use DB history for display.
    if hasattr(db, "upsert_download"):
        for r in rows:
            try:
                ih = r.get("info_hash") or ""
                name = r.get("torrent_name") or r.get("title") or ""
                magnet = f"magnet:?xt=urn:btih:{ih}&dn={quote(name)}" if ih and not ih.startswith("ad-") else f"alldebrid:magnet:{r.get('magnet_id') or ih}"
                db.upsert_download(
                    magnet=magnet, info_hash=ih, magnet_id=r.get("magnet_id") or "",
                    torrent_name=name, title=name, media_type=r.get("media_type") or "unknown",
                    quality=r.get("quality") or "unknown", seeders=r.get("seeders") or 0,
                    size=r.get("size") or 0, status=r.get("status") or "downloading",
                    progress=r.get("progress") or 0, source="alldebrid_live", error=r.get("error") or "",
                )
            except Exception as e:
                log.debug(f"Active AllDebrid download sync skipped: {e}")
    return rows


@app.get("/downloads", response_class=HTMLResponse)
async def downloads_page(request: Request):
    try:
        rows = await _current_alldebrid_download_rows(request.app)
    except Exception as e:
        log.warning(f"AllDebrid live downloads unavailable, using local active fallback: {e}")
        db: CacheDB = request.app.state.db
        rows = _visible_downloads(db.list_downloads() if hasattr(db, "list_downloads") else [])

    def row_html(r: dict) -> str:
        title = r.get("title") or r.get("torrent_name") or "Unknown"
        meta = []
        if r.get("media_type"):
            meta.append(str(r.get("media_type")).upper())
        if r.get("year"):
            meta.append(str(r.get("year")))
        if r.get("season"):
            ep = f"E{int(r.get('episode') or 0):02d}" if r.get("episode") else ""
            meta.append(f"S{int(r.get('season')):02d}{ep}")
        quality = r.get("quality") or ""
        if quality:
            meta.append(str(quality))
        h = (r.get("info_hash") or "").lower()
        return f'''
        <tr data-title="{_html.escape((title or '').lower())}" data-status="{_html.escape((r.get('status') or '').lower())}" data-category="{_html.escape((r.get('media_type') or '').lower())}" data-added="{int(r.get('created_at') or 0)}">
          <td>
            <div style="font-weight:700;color:#e0e0e0">{_html.escape(title)}</div>
            <div style="font-size:.74rem;color:#555;margin-top:3px">{_html.escape(' • '.join(meta) or 'Download')}</div>
            <div style="font-size:.68rem;color:#444;margin-top:3px;font-family:monospace">{_html.escape(h[:16])}{'…' if h else ''}</div>
          </td>
          <td>{_status_pill(r.get('status') or 'queued')}</td>
          <td>{float(r.get('progress') or 0):.0f}%</td>
          <td>{int(r.get('seeders') or 0)}</td>
          <td>{_fmt_bytes(r.get('size'))}</td>
          <td style="text-align:right">
            <button class="btn btn-sec" data-hash="{_html.escape(h)}" onclick="refreshOne(this)">↻ Refresh</button>
            <button class="btn btn-rem" data-hash="{_html.escape(h)}" onclick="deleteDownload(this)">Remove</button>
          </td>
        </tr>'''

    rows_html = "".join(row_html(r) for r in rows)
    empty_display = "none" if rows else "block"

    body = f'''
    <div class="search-bar" style="align-items:center">
      <button class="btn btn-sec" style="padding:10px 18px" onclick="loadDownloads()">↻ Refresh</button>
      <input id="download-filter" placeholder="Search queues..." oninput="filterDownloads()">
      <select id="state-filter" class="tab" style="height:40px" onchange="filterDownloads()">
        <option value="all">All States</option><option value="queued">Queued</option><option value="downloading">Downloading</option><option value="ready">Ready</option><option value="error">Error</option>
      </select>
      <select id="cat-filter" class="tab" style="height:40px" onchange="filterDownloads()">
        <option value="all">All Categories</option><option value="movie">Movies</option><option value="episode">TV Episodes</option><option value="tv">TV</option><option value="series">Series</option>
      </select>
      <select id="sort-filter" class="tab" style="height:40px" onchange="filterDownloads()">
        <option value="newest">Date Added (Newest First)</option><option value="oldest">Date Added (Oldest First)</option><option value="seeders">Seeders</option><option value="title">Title</option>
      </select>
    </div>

    <div class="empty" id="downloads-empty" style="display:{empty_display};background:#1a1a24;border:1px solid #2a2a3a;border-radius:12px;margin-top:18px">
      <div style="font-size:3rem;color:#333;margin-bottom:18px">▱</div>
      <h2 style="color:#e0e0e0;margin:0 0 10px;font-size:1.4rem">No Queues Found</h2>
      <div style="color:#777;margin-bottom:26px">You haven't added any items yet. Start by adding your first download!</div>
      <button class="btn btn-add" style="width:100%;padding:14px;font-size:.95rem" onclick="showAddDownload()">⊕ Add New Download</button>
    </div>

    <div id="downloads-table-wrap" style="display:{'block' if rows else 'none'}">
      <table id="downloads-table">
        <thead><tr><th>Name</th><th>Status</th><th>Progress</th><th>Seeders</th><th>Size</th><th></th></tr></thead>
        <tbody>{rows_html}</tbody>
      </table>
      <div style="margin-top:14px"><button class="btn btn-add" onclick="showAddDownload()">⊕ Add New Download</button></div>
    </div>

    <div id="add-card" style="display:none;background:#1a1a24;border:1px solid #2a2a3a;border-radius:12px;padding:18px;margin-top:18px">
      <div style="font-size:.8rem;color:#f97316;font-weight:700;text-transform:uppercase;margin-bottom:12px">Add Download</div>
      <div class="search-bar" style="margin-bottom:12px">
        <input id="dl-title" placeholder="Movie or show title...">
        <input id="dl-year" placeholder="Year" style="max-width:100px">
        <input id="dl-season" placeholder="Season" style="max-width:90px">
        <input id="dl-episode" placeholder="Episode" style="max-width:90px">
        <select id="dl-type" class="tab" style="height:40px"><option value="movie">Movie</option><option value="episode">TV Episode</option><option value="series">TV Series / Pack</option></select>
        <button class="btn btn-add" onclick="searchDownloads()">Search</button>
      </div>
      <div class="hint" style="font-size:.75rem;color:#555;margin-bottom:10px">Cached torrents are shown first. Uncached torrents can still be added and tracked here.</div>
      <div id="dl-search-results"></div>
    </div>'''

    extra = '''
<script>
function showAddDownload(){ document.getElementById('add-card').style.display='block'; document.getElementById('dl-title').focus(); }
function esc(s){return (s||'').toString().replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
function fmtBytes(n){n=Number(n||0); const u=['B','KB','MB','GB','TB']; let i=0; while(n>=1024&&i<u.length-1){n/=1024;i++;} return i? n.toFixed(1)+' '+u[i] : Math.round(n)+' B';}
function pill(st){st=(st||'queued').toLowerCase(); let cls='pill-pend'; if(['ready','cached','done','finished'].includes(st)) cls='pill-ok'; else if(['downloading','queued','processing'].includes(st)) cls='pill-res'; else if(['error','failed'].includes(st)) cls='pill-err'; return `<span class="pill ${cls}">${esc(st)}</span>`;}
function rowHtml(r){
  const title=r.title||r.torrent_name||'Unknown'; const h=(r.info_hash||'').toLowerCase();
  const meta=[(r.media_type||'').toUpperCase(), r.year||'', r.season?('S'+String(r.season).padStart(2,'0')+(r.episode?'E'+String(r.episode).padStart(2,'0'):'')):'', r.quality||''].filter(Boolean).join(' • ');
  return `<tr data-title="${esc(title.toLowerCase())}" data-status="${esc((r.status||'').toLowerCase())}" data-category="${esc((r.media_type||'').toLowerCase())}" data-added="${Number(r.created_at||0)}">
    <td><div style="font-weight:700;color:#e0e0e0">${esc(title)}</div><div style="font-size:.74rem;color:#555;margin-top:3px">${esc(meta||'Download')}</div><div style="font-size:.68rem;color:#444;margin-top:3px;font-family:monospace">${esc(h.slice(0,16))}${h?'…':''}</div></td>
    <td>${pill(r.status||'queued')}</td><td>${Number(r.progress||0).toFixed(0)}%</td><td>${Number(r.seeders||0)}</td><td>${fmtBytes(r.size)}</td>
    <td style="text-align:right"><button class="btn btn-sec" data-hash="${esc(h)}" onclick="refreshOne(this)">↻ Refresh</button> <button class="btn btn-rem" data-hash="${esc(h)}" onclick="deleteDownload(this)">Remove</button></td>
  </tr>`;
}

async function syncAllDebridDownloads(){
  const r=await fetch('/api/downloads/sync-alldebrid',{method:'POST'});
  const d=await r.json();
  if(!r.ok || d.ok===false){toast('AllDebrid sync failed',false);return;}
  const tb=document.querySelector('#downloads-table tbody'); if(tb) tb.innerHTML=(d.downloads||[]).map(rowHtml).join('');
  document.getElementById('downloads-empty').style.display=(d.downloads||[]).length?'none':'block';
  document.getElementById('downloads-table-wrap').style.display=(d.downloads||[]).length?'block':'none';
  toast('Synced '+(d.synced||0)+' AllDebrid download(s)');
}

async function loadDownloads(){
  const r=await fetch('/api/downloads'); if(!r.ok){toast('Downloads API not found', false); return;} const d=await r.json();
  const tb=document.querySelector('#downloads-table tbody'); if(tb) tb.innerHTML=(d.downloads||[]).map(rowHtml).join('');
  document.getElementById('downloads-empty').style.display=(d.downloads||[]).length?'none':'block';
  document.getElementById('downloads-table-wrap').style.display=(d.downloads||[]).length?'block':'none';
  filterDownloads();
}
function filterDownloads(){
  const q=(document.getElementById('download-filter').value||'').toLowerCase(); const st=document.getElementById('state-filter').value; const cat=document.getElementById('cat-filter').value; const sort=document.getElementById('sort-filter').value;
  const rows=[...document.querySelectorAll('#downloads-table tbody tr')];
  rows.forEach(r=>{ const ok=(!q||r.dataset.title.includes(q))&&(st==='all'||r.dataset.status===st)&&(cat==='all'||r.dataset.category===cat); r.style.display=ok?'':'none'; });
  rows.sort((a,b)=> sort==='oldest'?a.dataset.added-b.dataset.added: sort==='seeders'?(Number(b.children[3].textContent)-Number(a.children[3].textContent)): sort==='title'?a.dataset.title.localeCompare(b.dataset.title):(b.dataset.added-a.dataset.added));
  const tb=document.querySelector('#downloads-table tbody'); rows.forEach(r=>tb.appendChild(r));
}
async function searchDownloads(){
  const title=document.getElementById('dl-title').value.trim(); if(!title){toast('Enter a title',false);return;}
  const p=new URLSearchParams({q:title, media_type:document.getElementById('dl-type').value, year:document.getElementById('dl-year').value, season:document.getElementById('dl-season').value, episode:document.getElementById('dl-episode').value});
  const el=document.getElementById('dl-search-results'); el.innerHTML='<div class="empty" style="padding:24px">Searching…</div>';
  const r=await fetch('/api/downloads/search?'+p); const d=await r.json();
  if(!r.ok){el.innerHTML='<div class="empty" style="padding:24px;color:#f87171">'+esc(d.detail||'Search failed')+'</div>';return;}
  if(!d.results.length){el.innerHTML='<div class="empty" style="padding:24px">No torrents found</div>';return;}
  el.innerHTML=`<table><thead><tr><th>Name</th><th>Cache</th><th>Quality</th><th>Seeders</th><th>Size</th><th></th></tr></thead><tbody>${d.results.map((x,i)=>`<tr><td>${esc(x.name)}</td><td>${x.cached?'<span class="pill pill-ok">cached</span>':'<span class="pill pill-pend">download</span>'}</td><td>${esc(x.quality||'')}</td><td>${Number(x.seeders||0)}</td><td>${fmtBytes(x.size)}</td><td style="text-align:right"><button class="btn btn-add" onclick="addDownload(${i})">Add</button></td></tr>`).join('')}</tbody></table>`;
  window._downloadResults=d.results; window._downloadQuery=d.query;
}
async function addDownload(i){
  const btn=event && event.target ? event.target.closest('button') : null;
  if(btn && btn.dataset.busy==='1') return;
  if(btn){btn.dataset.busy='1'; btn.disabled=true; btn.textContent='Adding...';}
  try{
    const x=window._downloadResults[i]; const q=window._downloadQuery||{};
    const r=await fetch('/api/downloads/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...q,...x})});
    const d=await r.json(); if(!r.ok){toast(d.detail||'Add failed',false);return;} toast(d.duplicate?'Already added':'Download added'); await loadDownloads();
  } finally { if(btn){btn.dataset.busy='0'; btn.disabled=false; btn.textContent='Add';} }
}
async function refreshOne(btn){ await fetch('/api/downloads/'+btn.dataset.hash+'/refresh',{method:'POST'}); await loadDownloads(); }
async function deleteDownload(btn){ if(!confirm('Remove this download from Debridarr queue?'))return; const r=await fetch('/api/downloads/'+btn.dataset.hash,{method:'DELETE'}); if(r.ok){btn.closest('tr')?.remove();toast('Removed');} else toast('Remove failed',false); }
</script>'''
    return _page("Downloads", "downloads", body, extra)


async def _sync_downloads_from_alldebrid(app: FastAPI) -> int:
    """Mirror current AllDebrid magnets into the local downloads table.

    This makes the Downloads page show torrents that already exist in
    AllDebrid, even if they were added outside Debridarr or before the local
    Downloads table existed.
    """
    db: CacheDB = app.state.db
    ad: AllDebridClient = app.state.alldebrid
    if not hasattr(ad, "list_magnets") or not hasattr(db, "upsert_download"):
        return 0

    magnets = await ad.list_magnets()
    synced = 0
    for m in magnets:
        mid = str(m.get("id") or "")
        info_hash = str(m.get("hash") or m.get("info_hash") or "").lower().strip()
        name = (m.get("filename") or m.get("name") or m.get("torrent_name") or f"AllDebrid magnet {mid}")
        ready = bool(m.get("ready")) or str(m.get("status") or "").lower() in {"ready", "finished", "completed"} or int(m.get("statusCode") or 0) == 4
        raw_status = str(m.get("status") or "").lower().strip()
        if ready:
            status = "ready"
            progress = 100
        else:
            status = raw_status or "downloading"
            progress = float(m.get("downloadedPercent") or m.get("progress") or 0)
        magnet = ""
        if info_hash:
            magnet = f"magnet:?xt=urn:btih:{info_hash}&dn={quote(name)}"
        elif mid:
            magnet = f"alldebrid:magnet:{mid}"
            info_hash = f"ad-{mid}"
        else:
            continue
        try:
            db.upsert_download(
                magnet=magnet,
                info_hash=info_hash,
                magnet_id=mid,
                torrent_name=name,
                title=name,
                media_type="unknown",
                quality="unknown",
                seeders=0,
                size=int(m.get("size") or m.get("totalSize") or 0),
                status=status,
                progress=progress,
                source="alldebrid_sync",
                error=str(m.get("error") or ""),
            )
            synced += 1
        except Exception as e:
            log.debug(f"AllDebrid download sync skipped {mid or info_hash}: {e}")
    return synced

@app.get("/api/downloads")
async def api_downloads(request: Request, sync_ad: bool = True):
    """Live Downloads API.

    Returns only current active AllDebrid downloads. It intentionally ignores
    completed local history rows so the Downloads tab does not become a history
    page.
    """
    try:
        rows = await _current_alldebrid_download_rows(request.app)
        return {"downloads": rows, "synced": len(rows), "source": "alldebrid_live"}
    except Exception as e:
        log.warning(f"AllDebrid live downloads failed, using local active fallback: {e}")
        db: CacheDB = request.app.state.db
        rows = _visible_downloads(db.list_downloads() if hasattr(db, "list_downloads") else [])
        return {"downloads": rows, "synced": 0, "source": "local_active_fallback"}


@app.post("/api/downloads/sync-alldebrid")
async def api_downloads_sync_alldebrid(request: Request):
    rows = await _current_alldebrid_download_rows(request.app)
    return {"ok": True, "synced": len(rows), "downloads": rows, "source": "alldebrid_live"}

@app.get("/api/downloads/search")
async def api_downloads_search(request: Request, q: str, media_type: str = "movie", year: str = "", season: str = "", episode: str = ""):
    if not q.strip():
        raise HTTPException(400, "Missing search title")
    ad: AllDebridClient = request.app.state.alldebrid
    rows = await ad.search_torrents(
        q.strip(), media_type=media_type,
        year=int(year) if str(year).isdigit() else None,
        season=int(season) if str(season).isdigit() else None,
        episode=int(episode) if str(episode).isdigit() else None,
        limit=80,
    )
    return {"query": {"title": q.strip(), "media_type": media_type, "year": year or None, "season": season or None, "episode": episode or None}, "results": rows}


@app.post("/api/downloads/add")
async def api_downloads_add(request: Request):
    data = await request.json()
    magnet = data.get("magnet") or ""
    info_hash = (data.get("hash") or data.get("info_hash") or "").lower().strip()
    if not info_hash:
        info_hash = _btih_from_magnet(magnet)
    if not magnet:
        raise HTTPException(400, "Missing magnet")
    ad: AllDebridClient = request.app.state.alldebrid
    db: CacheDB = request.app.state.db

    name = data.get("name") or data.get("title") or ""
    size = data.get("size") or 0
    media_type = data.get("media_type") or "movie"
    title = data.get("title") or name
    year = data.get("year") or None
    season = data.get("season") or None
    episode = data.get("episode") or None
    media_key = _download_media_key(media_type=media_type, title=title, year=year, season=season, episode=episode)
    lock_key = media_key or _download_dedupe_key(info_hash=info_hash, magnet=magnet, name=name, size=size)
    async with _get_download_add_lock(lock_key):
        # First prevent multiple releases for the same movie / TV item.
        existing_media = db.get_existing_media_download(media_type=media_type, title=title, year=year, season=season, episode=episode) if hasattr(db, "get_existing_media_download") else None
        if existing_media:
            return _existing_download_payload(existing_media)

        # Then prevent the exact same hash/magnet.
        existing = db.get_existing_download(info_hash=info_hash, magnet=magnet) if hasattr(db, "get_existing_download") else None
        if existing:
            return _existing_download_payload(existing)

        # Then check AllDebrid before uploading. This prevents duplicate magnets
        # that were created outside Debridarr or by a racing request.
        ad_existing = await _find_existing_alldebrid_magnet(ad, info_hash=info_hash, magnet=magnet, name=name, size=size)
        if ad_existing:
            final_hash = (ad_existing.get("hash") or ad_existing.get("info_hash") or info_hash or "").lower()
            if hasattr(db, "upsert_download"):
                status = str(ad_existing.get("status") or ad_existing.get("statusCode") or "downloading").lower()
                ready = bool(ad_existing.get("ready")) or status in ("ready", "finished", "completed")
                db.upsert_download(
                    magnet=magnet,
                    info_hash=final_hash,
                    magnet_id=str(ad_existing.get("id") or ""),
                    torrent_name=ad_existing.get("filename") or ad_existing.get("name") or name,
                    title=title,
                    media_type=media_type,
                    year=year,
                    season=season,
                    episode=episode,
                    quality=data.get("quality") or "unknown",
                    seeders=int(data.get("seeders") or 0),
                    size=int(size or 0),
                    status="ready" if ready else "downloading",
                    progress=100 if ready else 0,
                    source="downloads_page_existing_ad",
                )
            return _payload_from_ad_existing(ad_existing, info_hash=final_hash)

        added = await ad.add_download(magnet)
        if not added or not added.get("ok"):
            raise HTTPException(400, added.get("error") if isinstance(added, dict) else "AllDebrid add failed")
        db.upsert_download(
            magnet=magnet,
            info_hash=(added.get("hash") or info_hash),
            magnet_id=added.get("id") or "",
            torrent_name=name or added.get("filename") or "",
            title=title or name or "",
            media_type=media_type,
            year=year,
            season=season,
            episode=episode,
            quality=data.get("quality") or "unknown",
            seeders=int(data.get("seeders") or 0),
            size=int(size or 0),
            status="ready" if added.get("ready") else "downloading",
            progress=100 if added.get("ready") else 0,
            source="downloads_page",
        )
        return {"ok": True, "download": added}


@app.post("/api/hash-index/add-to-downloads")
async def api_hash_index_add_to_downloads(request: Request):
    """Add a hash-index torrent to AllDebrid from the Hash Indexer detail drawer.

    Cached hashes are added and marked ready immediately. Uncached hashes are
    added as normal AllDebrid downloads and tracked on the Downloads page until
    they become ready/cached.
    """
    data = await request.json()
    info_hash = (data.get("info_hash") or data.get("hash") or "").lower().strip()
    if not info_hash:
        raise HTTPException(400, "Missing info_hash")

    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    db: CacheDB = request.app.state.db
    ad: AllDebridClient = request.app.state.alldebrid
    if not hi:
        raise HTTPException(503, "Hash index not initialised")

    row = hi.get_by_info_hash(info_hash) if hasattr(hi, "get_by_info_hash") else None
    if not row:
        raise HTTPException(404, "Hash not found in index")
    if row.get("blacklisted"):
        raise HTTPException(400, "This hash is blacklisted")

    magnet = row.get("magnet") or ""
    if not magnet:
        raise HTTPException(400, "Hash index row has no magnet")

    name = row.get("torrent_name") or row.get("title") or ""
    size = row.get("file_size") or row.get("size") or 0
    media_type = row.get("media_type") or "movie"
    title = row.get("title") or name
    year = row.get("year")
    season = row.get("season")
    episode = row.get("episode")
    media_key = _download_media_key(media_type=media_type, title=title, year=year, season=season, episode=episode)
    lock_key = media_key or _download_dedupe_key(info_hash=info_hash, magnet=magnet, name=name, size=size)
    async with _get_download_add_lock(lock_key):
        existing_media = db.get_existing_media_download(media_type=media_type, title=title, year=year, season=season, episode=episode) if hasattr(db, "get_existing_media_download") else None
        if existing_media:
            return _existing_download_payload(existing_media)

        existing = db.get_existing_download(info_hash=info_hash, magnet=magnet) if hasattr(db, "get_existing_download") else None
        if existing:
            return _existing_download_payload(existing)

        ad_existing = await _find_existing_alldebrid_magnet(ad, info_hash=info_hash, magnet=magnet, name=name, size=size)
        if ad_existing:
            final_hash = (ad_existing.get("hash") or ad_existing.get("info_hash") or info_hash or "").lower()
            status = str(ad_existing.get("status") or ad_existing.get("statusCode") or "downloading").lower()
            ready = bool(ad_existing.get("ready") or row.get("is_cached")) or status in ("ready", "finished", "completed")
            db.upsert_download(
                magnet=magnet,
                info_hash=final_hash,
                magnet_id=str(ad_existing.get("id") or ""),
                torrent_name=ad_existing.get("filename") or ad_existing.get("name") or name,
                title=row.get("title") or "",
                media_type=row.get("media_type") or "movie",
                year=row.get("year"),
                season=row.get("season"),
                episode=row.get("episode"),
                quality=row.get("quality") or "unknown",
                seeders=0,
                size=int(size or 0),
                status="ready" if ready else "downloading",
                progress=100 if ready else 0,
                source="hash_indexer_existing_ad",
            )
            if ready:
                try:
                    hi.mark_cached(final_hash)
                except Exception:
                    pass
            return _payload_from_ad_existing(ad_existing, info_hash=final_hash)

        added = await ad.add_download(magnet)
        if not added or not added.get("ok"):
            raise HTTPException(400, added.get("error") if isinstance(added, dict) else "AllDebrid add failed")

        ready = bool(added.get("ready") or row.get("is_cached"))
        final_hash = (added.get("hash") or info_hash).lower()
        db.upsert_download(
            magnet=magnet,
            info_hash=final_hash,
            magnet_id=added.get("id") or "",
            torrent_name=name or added.get("filename") or "",
            title=row.get("title") or "",
            media_type=row.get("media_type") or "movie",
            year=row.get("year"),
            season=row.get("season"),
            episode=row.get("episode"),
            quality=row.get("quality") or "unknown",
            seeders=0,
            size=int(size or 0),
            status="ready" if ready else "downloading",
            progress=100 if ready else 0,
            source="hash_indexer",
        )
        if ready:
            try:
                hi.mark_cached(final_hash)
            except Exception:
                pass
        return {"ok": True, "ready": ready, "download": added, "info_hash": final_hash}


@app.post("/api/downloads/{info_hash}/refresh")
async def api_downloads_refresh(request: Request, info_hash: str):
    db: CacheDB = request.app.state.db
    row = db.get_download(info_hash) if hasattr(db, "get_download") else None
    if not row:
        raise HTTPException(404, "Download not found")
    magnet_id = row.get("magnet_id") or ""
    if not magnet_id:
        return {"ok": True, "message": "No AllDebrid magnet id saved"}
    ad: AllDebridClient = request.app.state.alldebrid
    info = await ad.get_magnet_status(magnet_id)
    status = str(info.get("status") or info.get("statusCode") or row.get("status") or "downloading").lower()
    progress = float(info.get("downloadedPercent") or info.get("progress") or row.get("progress") or 0)
    if info.get("ready") or status in ("ready", "finished", "completed"):
        status = "ready"; progress = 100
    db.update_download(info_hash=info_hash, status=status, progress=progress)
    return {"ok": True, "status": status, "progress": progress}


@app.delete("/api/downloads/{info_hash}")
async def api_downloads_delete(request: Request, info_hash: str):
    db: CacheDB = request.app.state.db
    n = db.delete_download(info_hash=info_hash) if hasattr(db, "delete_download") else 0
    return {"ok": True, "deleted": n}

# ── Setup ─────────────────────────────────────────────────────────────────────
_SETUP_CSS = _CSS + """
.wizard { max-width: 620px; margin: 60px auto; }
.wizard-card { background: #1a1a24; border: 1px solid #2a2a3a; border-radius: 14px; padding: 36px; }
.wizard h2 { font-size: 1.4rem; color: #fff; margin-bottom: 6px; }
.wizard .sub { color: #666; font-size: 0.88rem; margin-bottom: 28px; line-height: 1.5; }
.steps { display: flex; gap: 0; margin-bottom: 32px; }
.step { flex: 1; text-align: center; font-size: 0.7rem; color: #444; padding-bottom: 8px;
        border-bottom: 2px solid #2a2a3a; }
.step.done   { color: #4ade80; border-color: #4ade80; }
.step.active { color: #f97316; border-color: #f97316; font-weight: 700; }
.field { margin-bottom: 20px; }
.field label { display: block; font-size: 0.8rem; color: #888; margin-bottom: 6px; font-weight: 600; }
.field input { width: 100%; background: #0f0f13; border: 1px solid #2a2a3a; border-radius: 8px;
               padding: 10px 14px; color: #e0e0e0; font-size: 0.9rem; outline: none; font-family: monospace; }
.field input:focus { border-color: #f97316; }
.field .hint { font-size: 0.75rem; color: #555; margin-top: 5px; line-height: 1.4; }
.field .hint a { color: #f97316; }
.test-result { margin-top: 10px; padding: 8px 12px; border-radius: 6px; font-size: 0.82rem; display: none; }
.test-result.ok      { background: #14532d; color: #4ade80; display: block; }
.test-result.err     { background: #3b0000; color: #f87171; display: block; }
.test-result.testing { background: #1e1e2e; color: #aaa; display: block; }
.row { display: flex; gap: 10px; }
.row .field { flex: 1; }
.actions { display: flex; gap: 10px; margin-top: 28px; justify-content: flex-end; }
.btn-primary { background: #f97316; color: #fff; padding: 10px 24px; border-radius: 8px;
               font-size: 0.9rem; font-weight: 600; border: none; cursor: pointer; }
.btn-primary:hover { opacity: .85; }
.btn-primary:disabled { opacity: .4; cursor: not-allowed; }
.btn-ghost { background: transparent; color: #666; padding: 10px 16px; border-radius: 8px;
             font-size: 0.9rem; border: 1px solid #2a2a3a; cursor: pointer; }
.btn-ghost:hover { color: #ccc; border-color: #444; }
.confirm-row { display: flex; justify-content: space-between; padding: 10px 0;
               border-bottom: 1px solid #1e1e2e; font-size: 0.875rem; }
.confirm-row:last-child { border-bottom: none; }
.confirm-row .lbl { color: #666; }
.confirm-row .val { color: #e0e0e0; font-family: monospace; font-size: 0.82rem; }
"""

def _setup_page(body, step):
    step_names = ["Welcome", "AllDebrid", "Overseerr", "Plex", "Confirm"]
    step_keys  = ["welcome", "alldebrid", "overseerr", "plex", "confirm"]
    idx = step_keys.index(step) if step in step_keys else 0
    steps_html = "".join(
        f'<div class="step {"done" if i < idx else "active" if i == idx else ""}">{n}</div>'
        for i, n in enumerate(step_names)
    )
    return HTMLResponse(f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Debridarr Setup</title>
  <style>{_SETUP_CSS}</style>
</head>
<body>
  <header>
    <h1>🎬 Debridarr</h1><span class="ver">v0.5.0</span>
    <span style="margin-left:auto;color:#555;font-size:0.8rem">First-run setup</span>
  </header>
  <div class="wizard">
    <div class="steps">{steps_html}</div>
    <div class="wizard-card">{body}</div>
  </div>
  <div id="toast" class="toast"></div>
  <script>{_TOAST_JS}</script>
</body>
</html>""")


@app.get("/setup", response_class=HTMLResponse)
async def setup_get(request: Request, step: str = "welcome"):
    cfg = load_saved_config()

    if step == "welcome":
        return _setup_page("""
        <div style="font-size:4rem;text-align:center;margin-bottom:20px">🎬</div>
        <h2>Welcome to Debridarr</h2>
        <p class="sub">Connect Debridarr to AllDebrid and Overseerr. Takes ~2 minutes.</p>
        <div class="actions">
          <a href="/setup?step=alldebrid" class="btn-primary" style="text-decoration:none;display:inline-block;padding:10px 24px">Get Started →</a>
        </div>""", "welcome")

    if step == "alldebrid":
        val = cfg.get("ALLDEBRID_API_KEY", "")
        return _setup_page(f"""
        <h2>AllDebrid</h2>
        <p class="sub">Debridarr uses AllDebrid to stream cached torrents instantly.</p>
        <div class="field">
          <label>API Key</label>
          <input id="api_key" type="password" value="{val}" placeholder="Paste your AllDebrid API key">
          <div class="hint">Get yours at <a href="https://alldebrid.com/apikeys" target="_blank">alldebrid.com/apikeys</a></div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="actions">
          <a href="/setup?step=welcome" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="btn" onclick="go()">Test & Continue →</button>
        </div>
        <script>
        async function go() {{
          const key = document.getElementById('api_key').value.trim();
          const res = document.getElementById('test-result');
          const btn = document.getElementById('btn');
          if (!key) {{ res.className='test-result err'; res.textContent='API key required'; return; }}
          res.className='test-result testing'; res.textContent='Testing...'; btn.disabled=true;
          const r = await fetch('/setup/test', {{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{step:'alldebrid',api_key:key}})}});
          const d = await r.json(); btn.disabled=false;
          if (d.ok) {{ res.className='test-result ok'; res.textContent='✅ '+d.message;
            setTimeout(()=>window.location='/setup?step=overseerr&akey='+encodeURIComponent(key),800); }}
          else {{ res.className='test-result err'; res.textContent='❌ '+d.message; }}
        }}
        document.getElementById('api_key').addEventListener('keydown',e=>{{if(e.key==='Enter')go();}});
        </script>""", "alldebrid")

    if step == "overseerr":
        url_val = cfg.get("OVERSEERR_URL", "http://192.168.1.x:5055")
        key_val = cfg.get("OVERSEERR_API_KEY", "")
        akey    = request.query_params.get("akey", cfg.get("ALLDEBRID_API_KEY", ""))
        return _setup_page(f"""
        <h2>Overseerr</h2>
        <p class="sub">Connect to your Overseerr instance to browse your request library.</p>
        <div class="field">
          <label>Overseerr URL</label>
          <input id="url" type="text" value="{url_val}" placeholder="http://192.168.1.x:5055">
        </div>
        <div class="field">
          <label>API Key</label>
          <input id="key" type="password" value="{key_val}" placeholder="Overseerr API key">
          <div class="hint">Overseerr → Settings → General → API Key</div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="actions">
          <a href="/setup?step=alldebrid" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="btn" onclick="go()">Test & Continue →</button>
        </div>
        <input type="hidden" id="akey" value="{akey}">
        <script>
        async function go() {{
          const url=document.getElementById('url').value.trim();
          const key=document.getElementById('key').value.trim();
          const akey=document.getElementById('akey').value;
          const res=document.getElementById('test-result'); const btn=document.getElementById('btn');
          res.className='test-result testing'; res.textContent='Testing...'; btn.disabled=true;
          const r=await fetch('/setup/test',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{step:'overseerr',url,api_key:key}})}});
          const d=await r.json(); btn.disabled=false;
          if(d.ok){{res.className='test-result ok';res.textContent='✅ '+d.message;
            setTimeout(()=>window.location='/setup?step=plex&akey='+encodeURIComponent(akey)+'&ourl='+encodeURIComponent(url)+'&okey='+encodeURIComponent(key),800);}}
          else{{res.className='test-result err';res.textContent='❌ '+d.message;}}
        }}
        </script>""", "overseerr")

    if step == "plex":
        qs = dict(request.query_params)
        hidden = "".join(f'<input type="hidden" id="{k}" value="{v}">' for k, v in qs.items() if k != "step")
        tz_val   = cfg.get("TZ", "America/Edmonton")
        puid_val = cfg.get("PUID", "1000")
        pgid_val = cfg.get("PGID", "1000")
        base_url = cfg.get("DEBRIDARR_BASE_URL", "http://192.168.1.x:7474")
        return _setup_page(f"""
        <h2>Plex Integration</h2>
        <p class="sub">Where to write library files and how Plex reaches Debridarr.</p>
        <div class="field">
          <label>Plex Library Path (inside container)</label>
          <input id="plex_root" type="text" value="/plex-strm" placeholder="/plex-strm">
          <div class="hint">Must be bind-mounted into both Debridarr and Plex.</div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="field">
          <label>Debridarr Base URL (as seen by Plex)</label>
          <input id="base_url" type="text" value="{base_url}" placeholder="http://192.168.1.x:7474">
        </div>
        <div class="row">
          <div class="field"><label>Timezone</label><input id="tz" value="{tz_val}"></div>
          <div class="field"><label>PUID</label><input id="puid" value="{puid_val}"></div>
          <div class="field"><label>PGID</label><input id="pgid" value="{pgid_val}"></div>
        </div>
        {hidden}
        <div class="actions">
          <a href="/setup?step=overseerr" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="btn" onclick="go()">Test & Continue →</button>
        </div>
        <script>
        async function go(){{
          const plex_root=document.getElementById('plex_root').value.trim();
          const res=document.getElementById('test-result'); const btn=document.getElementById('btn');
          res.className='test-result testing'; res.textContent='Checking...'; btn.disabled=true;
          const r=await fetch('/setup/test',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{step:'plex',plex_root}})}});
          const d=await r.json(); btn.disabled=false;
          if(d.ok){{res.className='test-result ok';res.textContent='✅ '+d.message;
            const prev={{}};
            document.querySelectorAll('input[type=hidden]').forEach(i=>prev[i.id]=i.value);
            const p=new URLSearchParams({{...prev,step:'confirm',plex_root,
              base_url:document.getElementById('base_url').value.trim(),
              tz:document.getElementById('tz').value.trim(),
              puid:document.getElementById('puid').value.trim(),
              pgid:document.getElementById('pgid').value.trim()}});
            setTimeout(()=>window.location='/setup?'+p.toString(),800);}}
          else{{res.className='test-result err';res.textContent='❌ '+d.message;}}
        }}
        </script>""", "plex")

    if step == "confirm":
        qs = dict(request.query_params)
        def row(lbl, key, mask=False):
            val = qs.get(key, "—")
            display = ("•" * 8 + val[-4:]) if mask and val and val != "—" else val
            return f'<div class="confirm-row"><span class="lbl">{lbl}</span><span class="val">{display}</span></div>'
        hidden = "".join(f'<input type="hidden" name="{k}" value="{v}">' for k, v in qs.items() if k != "step")
        return _setup_page(f"""
        <h2>Confirm & Save</h2>
        <p class="sub">Review settings and click Save to finish.</p>
        <div style="margin-bottom:24px">
          {row("AllDebrid API Key", "akey", mask=True)}
          {row("Overseerr URL", "ourl")}
          {row("Overseerr API Key", "okey", mask=True)}
          {row("Plex Library Path", "plex_root")}
          {row("Debridarr Base URL", "base_url")}
          {row("Timezone", "tz")}
        </div>
        <form method="POST" action="/setup/save">
          {hidden}
          <div class="actions">
            <a href="/setup?step=plex" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
            <button type="submit" class="btn-primary">💾 Save & Finish</button>
          </div>
        </form>""", "confirm")

    return RedirectResponse("/setup")


@app.post("/setup/test")
async def setup_test(request: Request):
    body = await request.json()
    step = body.get("step")
    if step == "alldebrid":  ok, msg = await test_alldebrid(body.get("api_key", ""))
    elif step == "overseerr": ok, msg = await test_overseerr(body.get("url", ""), body.get("api_key", ""))
    elif step == "plex":      ok, msg = await test_plex_root(body.get("plex_root", ""))
    else:                     ok, msg = False, "Unknown step"
    return JSONResponse({"ok": ok, "message": msg})


@app.post("/setup/save")
async def setup_save(request: Request):
    form = dict(await request.form())
    config = {
        "ALLDEBRID_API_KEY":  form.get("akey", ""),
        "OVERSEERR_URL":      form.get("ourl", ""),
        "OVERSEERR_API_KEY":  form.get("okey", ""),
        "DEBRIDARR_BASE_URL": form.get("base_url", ""),
        "TZ":                 form.get("tz", "America/Edmonton"),
        "PUID":               form.get("puid", "1000"),
        "PGID":               form.get("pgid", "1000"),
    }
    write_env(config)
    import os
    for k, v in config.items(): os.environ[k] = v
    os.environ["PLEX_ROOT"] = form.get("plex_root", "/plex-strm")
    mark_setup_complete()
    request.app.state.setup_complete = True
    _init_clients(request.app)
    log.info("✅ Setup complete — restarting...")
    _schedule_restart(delay=2.0)
    return HTMLResponse(f"""<!DOCTYPE html><html><head><meta charset="UTF-8">
<meta http-equiv="refresh" content="6;url=/library">
<style>{_SETUP_CSS}</style></head><body>
<header><h1>🎬 Debridarr</h1><span class="ver">v0.5.0</span></header>
<div class="wizard"><div class="wizard-card" style="text-align:center;padding:48px">
<div style="font-size:3rem;margin-bottom:16px">🎉</div>
<h2 style="color:#4ade80;margin-bottom:12px">Setup Complete!</h2>
<p style="color:#888;margin-bottom:24px">Redirecting to library...</p>
<a href="/library" style="color:#f97316">Click here if not redirected</a>
</div></div></body></html>""")


# ── / redirect ────────────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    if _needs_setup(request): return _setup_redirect()
    return RedirectResponse("/library")


# ── /jobs ─────────────────────────────────────────────────────────────────────
@app.get("/pins", response_class=HTMLResponse)
async def pins_page(request: Request):
    if _needs_setup(request):
        return _setup_redirect()
    import datetime as _dt
    db: CacheDB = request.app.state.db
    pins        = db.list_pin_exemptions()
    pinned_set  = {p["title"] for p in pins}
    lib_all     = db.fake_library_list()

    # Library dropdown options (exclude already-pinned)
    lib_options = ""
    for r in sorted(lib_all, key=lambda x: x["title"]):
        if r["title"] in pinned_set:
            continue
        t  = _html.escape(r["title"])
        mt = r["media_type"]
        lib_options += f'<option value="{t}" data-mt="{mt}">{t} ({mt})</option>'

    # Pin rows
    rows = ""
    for p in pins:
        t    = _html.escape(p["title"])
        mt   = _html.escape(p.get("media_type") or "")
        note = _html.escape(p.get("note") or "")
        try:
            pinned_date = _dt.datetime.fromtimestamp(int(p["created_at"])).strftime("%Y-%m-%d")
        except Exception:
            pinned_date = "-"
        rows += (
            "<tr>"
            f'<td style="color:#e0e0e0;font-weight:600">{t}</td>'
            f'<td style="color:#888">{mt}</td>'
            f'<td style="color:#555;font-size:0.78rem">{note}</td>'
            f'<td style="color:#555;font-size:0.72rem">{pinned_date}</td>'
            "<td>"
            f'<button class="btn btn-rem" style="padding:3px 10px;font-size:0.75rem"'
            f' data-title="{t}" onclick="unpinBtn(this)">Unpin</button>'
            "</td>"
            "</tr>"
        )

    empty = ('<tr><td colspan="5" class="empty" style="padding:20px">'
             "No pinned titles yet.</td></tr>") if not pins else ""

    body = "\n".join([
        '<h2 style="margin:0 0 6px;color:#e0e0e0">Pinned Exemptions</h2>',
        '<p style="color:#555;font-size:0.82rem;margin:0 0 20px">',
        'Pinned titles are re-resolved every 30 days instead of expiring.',
        'This keeps them permanently cached on AllDebrid.',
        '</p>',
        '<div style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:10px;padding:16px;margin-bottom:24px">',
        '<div style="font-weight:600;color:#e0e0e0;margin-bottom:12px">Pin a title</div>',
        '<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">',
        '<div style="flex:1;min-width:200px">',
        '<label style="font-size:0.75rem;color:#666;display:block;margin-bottom:4px">From library</label>',
        '<select id="pin-select" style="width:100%;background:#111;border:1px solid #333;border-radius:6px;color:#e0e0e0;padding:8px 10px;font-size:0.85rem">',
        f'<option value="">-- choose --</option>{lib_options}',
        '</select></div>',
        '<div style="flex:1;min-width:200px">',
        '<label style="font-size:0.75rem;color:#666;display:block;margin-bottom:4px">Or enter manually</label>',
        '<input id="pin-manual" placeholder="Title..." style="width:100%;background:#111;border:1px solid #333;border-radius:6px;color:#e0e0e0;padding:8px 10px;font-size:0.85rem;box-sizing:border-box">',
        '</div>',
        '<div>',
        '<label style="font-size:0.75rem;color:#666;display:block;margin-bottom:4px">Note (optional)</label>',
        '<input id="pin-note" placeholder="e.g. Family favourite" style="background:#111;border:1px solid #333;border-radius:6px;color:#e0e0e0;padding:8px 10px;font-size:0.85rem">',
        '</div>',
        '<button class="btn btn-add" style="padding:8px 18px" onclick="addPin()">Pin</button>',
        '</div>',
        '<div id="pin-msg" style="margin-top:10px;font-size:0.8rem;color:#4ade80;display:none"></div>',
        '</div>',
        '<table><thead><tr>',
        '<th>Title</th><th>Type</th><th>Note</th><th>Pinned</th><th></th>',
        f'</tr></thead><tbody>{rows}{empty}</tbody></table>',
    ])


    extra = (
        "<script>"
        "document.getElementById('pin-select').addEventListener('change',function(){"
        "document.getElementById('pin-manual').value=this.value;});"
        "async function addPin(){"
        "const sel=document.getElementById('pin-select');"
        "const title=(document.getElementById('pin-manual').value.trim()||sel.value).trim();"
        "const note=document.getElementById('pin-note').value.trim();"
        "const mt=sel.options[sel.selectedIndex]?.dataset?.mt||'movie';"
        "if(!title){showPinMsg('Enter a title',false);return;}"
        "const r=await fetch('/api/pins',{method:'POST',"
        "headers:{'Content-Type':'application/json'},"
        "body:JSON.stringify({title,media_type:mt,note})});"
        "const d=await r.json();"
        "if(r.ok){showPinMsg('Added: '+title,true);setTimeout(()=>location.reload(),1000);}"
        "else showPinMsg('Error: '+(d.detail||'failed'),false);}"
        "async function unpinBtn(btn){"
        "const title=btn.dataset.title;"
        "if(!confirm('Unpin '+title+'?'))return;"
        "const r=await fetch('/api/pins',{method:'DELETE',"
        "headers:{'Content-Type':'application/json'},"
        "body:JSON.stringify({title})});"
        "if(r.ok)location.reload();}"
        "function showPinMsg(msg,ok){"
        "const el=document.getElementById('pin-msg');"
        "el.textContent=msg;el.style.color=ok?'#4ade80':'#f87171';"
        "el.style.display='block';}"
        "</script>"
    )

    return _page("Pinned Exemptions", "pins", body, extra)


@app.get("/jobs", response_class=HTMLResponse)
async def jobs_page(request: Request):
    if _needs_setup(request): return _setup_redirect()
    db: CacheDB = request.app.state.db
    workers = int(db.get_setting("resolve_workers", "3"))

    def fmt_duration(start_iso: str) -> str:
        try:
            secs = int((datetime.utcnow() - datetime.fromisoformat(start_iso)).total_seconds())
            if secs < 60:  return f"{secs}s"
            if secs < 3600: return f"{secs//60}m {secs%60}s"
            return f"{secs//3600}h {(secs%3600)//60}m"
        except Exception:
            return "?"

    def job_row(j: dict, running: bool) -> str:
        dur    = fmt_duration(j["started_at"]) if running else fmt_duration(j.get("finished_at", j["started_at"]))
        status = j.get("status", "running")
        dot    = {"running": "#22c55e", "done": "#555", "error": "#ef4444", "cancelled": "#f97316"}.get(status, "#888")
        cancel = f'<button class="btn btn-rem" style="padding:3px 10px;font-size:0.72rem" onclick="cancelJob(\'{j["id"]}\')">✕ Cancel</button>' if running and j.get("cancellable") else ""
        err    = f'<span style="color:#f87171;font-size:0.72rem">{j.get("error","")}</span>' if j.get("error") else ""
        return f"""<tr>
          <td style="font-family:monospace;font-size:0.75rem;color:#555">{j["id"]}</td>
          <td><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:{dot};margin-right:6px"></span>{j["name"]}</td>
          <td style="color:#888;font-size:0.78rem">{j["type"]}</td>
          <td style="color:#888;font-size:0.78rem">{"⏱ "+dur if running else dur}</td>
          <td>{cancel}{err}</td>
        </tr>"""

    running_rows  = "".join(job_row(j, True)  for j in _jobs.values())
    history_rows  = "".join(job_row(j, False) for j in list(_jobs_history)[:50])

    running_table = f"""<table><thead><tr>
      <th>ID</th><th>Job</th><th>Type</th><th>Running</th><th></th>
    </tr></thead><tbody>{running_rows}</tbody></table>""" if running_rows else \
    '<div class="empty">No jobs running.</div>'

    history_table = f"""<table><thead><tr>
      <th>ID</th><th>Job</th><th>Type</th><th>Duration</th><th>Status</th>
    </tr></thead><tbody>{history_rows}</tbody></table>""" if history_rows else \
    '<div class="empty">No completed jobs yet.</div>'

    body = f"""
    <h2 style="margin-bottom:20px">⚙️ Jobs</h2>

    <div class="s-sect">
      <div class="s-title">Worker Settings</div>
      <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap">
        <div class="field" style="max-width:220px;margin:0">
          <label>Max concurrent resolve workers</label>
          <input id="worker-count" type="number" min="1" max="10" value="{workers}"
                 style="background:#0f0f13;border:1px solid #2a2a3a;border-radius:7px;padding:8px 12px;color:#e0e0e0;font-size:0.875rem;width:100%">
          <div class="hint">How many resolve_and_cache tasks run in parallel. Higher = faster but more AllDebrid API load.</div>
        </div>
        <button class="btn btn-add" style="padding:8px 20px;margin-top:14px" onclick="saveWorkers()">Save</button>
        <div id="worker-result" class="test-result" style="margin-top:14px;flex:1"></div>
      </div>
    </div>

    <div class="s-sect">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
        <div class="s-title" style="margin:0">Running Jobs ({len(_jobs)})</div>
        <div style="display:flex;gap:8px">
          <button class="btn btn-sec" style="padding:5px 12px;font-size:0.8rem" onclick="location.reload()">🔄 Refresh</button>
          <button class="btn btn-rem" style="padding:5px 12px;font-size:0.8rem" onclick="cancelAll()">✕ Cancel All</button>
        </div>
      </div>
      {running_table}
    </div>

    <div class="s-sect">
      <div class="s-title">Recent Jobs (last {min(len(_jobs_history),50)})</div>
      {history_table}
    </div>"""

    extra = """<script>
async function cancelJob(id) {
  const r = await fetch('/api/jobs/'+id+'/cancel', {method:'POST'});
  const d = await r.json();
  toast(r.ok ? '🚫 Job cancelled' : '❌ '+(d.detail||'Error'), r.ok);
  setTimeout(()=>location.reload(), 800);
}
async function cancelAll() {
  if (!confirm('Cancel all running jobs?')) return;
  const r = await fetch('/api/jobs/cancel-all', {method:'POST'});
  const d = await r.json();
  toast('🚫 Cancelled '+d.cancelled+' jobs');
  setTimeout(()=>location.reload(), 800);
}
async function saveWorkers() {
  const n   = parseInt(document.getElementById('worker-count').value);
  const res = document.getElementById('worker-result');
  if (!n || n < 1 || n > 10) { res.className='test-result err'; res.style.display='block'; res.textContent='❌ Must be 1–10'; return; }
  const r = await fetch('/api/jobs/workers', {method:'POST',
    headers:{'Content-Type':'application/json'}, body:JSON.stringify({count:n})});
  const d = await r.json();
  res.className = 'test-result '+(r.ok?'ok':'err');
  res.style.display = 'block';
  res.textContent = r.ok ? '✅ Workers set to '+d.workers+' (takes effect immediately)' : '❌ '+(d.detail||'Error');
}
// Auto-refresh every 3s when jobs are running
if (document.querySelector('tbody tr')) {
  setTimeout(()=>location.reload(), 3000);
}
</script>"""
    return _page("Jobs", "jobs", body, extra)


@app.post("/api/jobs/{job_id}/cancel")
async def api_job_cancel(job_id: str):
    job = _jobs.get(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    if not job.get("cancellable"):
        raise HTTPException(400, "Job is not cancellable")
    job["cancel_event"].set()
    job["status"] = "cancelling"
    return {"status": "ok", "message": f"Cancelling job {job_id}"}


@app.post("/api/jobs/cancel-all")
async def api_jobs_cancel_all():
    count = 0
    for job in list(_jobs.values()):
        if job.get("cancellable") and not job["cancel_event"].is_set():
            job["cancel_event"].set()
            job["status"] = "cancelling"
            count += 1
    return {"status": "ok", "cancelled": count}


@app.post("/api/jobs/workers")
async def api_jobs_workers(request: Request):
    body    = await request.json()
    count   = int(body.get("count", 3))
    count   = max(1, min(10, count))
    db: CacheDB = request.app.state.db
    db.set_setting("resolve_workers", str(count))
    _reset_semaphore(count)
    log.info(f"⚙️  Resolve workers set to {count}")
    return {"status": "ok", "workers": count}


@app.get("/api/jobs")
async def api_jobs_list():
    def serialise(j: dict) -> dict:
        return {k: v for k, v in j.items() if k != "cancel_event"}
    return {
        "running":  [serialise(j) for j in _jobs.values()],
        "history":  [serialise(j) for j in list(_jobs_history)[:50]],
        "workers":  _resolve_semaphore._value if _resolve_semaphore else 3,
    }


# ── /import — Sonarr / Radarr direct import ───────────────────────────────────
@app.get("/import", response_class=HTMLResponse)
async def import_page(request: Request, tab: str = "radarr", q: str = "", page: int = 1):
    if _needs_setup(request): return _setup_redirect()
    lm: LibraryManager = request.app.state.library
    db: CacheDB = request.app.state.db

    radarr_url = db.get_setting("RADARR_URL", "")
    radarr_key = db.get_setting("RADARR_API_KEY", "")
    sonarr_url = db.get_setting("SONARR_URL", "")
    sonarr_key = db.get_setting("SONARR_API_KEY", "")

    already_added = {(r["media_type"], r["title"].lower()) for r in db.fake_library_list()}

    if tab == "radarr":
        items = await lm.get_radarr_direct(radarr_url, radarr_key)
        source_name = "Radarr"
        not_configured = not radarr_url or not radarr_key
    else:
        items = await lm.get_sonarr_direct(sonarr_url, sonarr_key)
        source_name = "Sonarr"
        not_configured = not sonarr_url or not sonarr_key

    if q:
        ql = q.lower()
        items = [i for i in items if ql in i["title"].lower()]

    mtype = "movie" if tab == "radarr" else "series"

    IMP_PER_PAGE   = 24
    total_imp      = len(items)
    total_imp_pages = max(1, (total_imp + IMP_PER_PAGE - 1) // IMP_PER_PAGE)
    page           = max(1, min(page, total_imp_pages))
    not_added      = [i for i in items if (mtype, i["title"].lower()) not in already_added]
    items          = items[(page-1)*IMP_PER_PAGE : page*IMP_PER_PAGE]
    not_added_page = [i for i in items if (mtype, i["title"].lower()) not in already_added]

    cards = ""
    for item in items:
        in_lib = (mtype, item["title"].lower()) in already_added
        poster = item.get("poster", "")
        year   = item.get("year", "")
        safe   = item["title"].replace("'", "&#39;").replace('"', "&quot;")
        img    = f'<img src="{poster}" onerror="this.style.display=\'none\'" loading="lazy">' if poster \
                 else f'<div class="no-poster">{"".join(w[0].upper() for w in item["title"].split()[:2])}</div>'

        if tab == "radarr":
            meta = str(year or "")
            has_file = item.get("has_file", False)
            meta += ' <span style="color:#22c55e;font-size:0.7rem">●&nbsp;Downloaded</span>' if has_file else \
                    ' <span style="color:#888;font-size:0.7rem">○&nbsp;Not downloaded</span>'
        else:
            sc   = item.get("season_count", 0)
            meta = f"{year or ''} · {sc} season{'s' if sc!=1 else ''}"
            st   = item.get("status", "")
            col  = "#ef4444" if item.get("is_ended") else "#22c55e"
            meta += f' <span style="color:{col};font-size:0.7rem">({st})</span>'

        sc = item.get("season_count", 0)
        if in_lib:
            action = f'<span class="badge-in">✓ In Library</span>'
        else:
            action = (
                f'<button class="btn btn-add" style="padding:4px 10px;font-size:0.78rem"'
                f' data-mtype="{mtype}" data-id="{item.get("id","")}"'
                f' data-title="{safe}" data-year="{year or ""}" data-sc="{sc}"'
                f' onclick="addCard(this)">+ Add</button>'
            )

        cards += f"""<div class="card" data-title="{safe.lower()}" data-in-lib="{'1' if in_lib else '0'}">
          {img}
          <div class="info"><div class="title" title="{safe}">{item["title"]}</div>
          <div class="meta">{meta}</div></div>
          <div class="actions">{action}</div>
        </div>"""

    if not cards:
        if not_configured:
            cards = f'<div class="empty">Configure {source_name} URL and API key in <a href="/settings" style="color:#f97316">Settings</a>.</div>'
        else:
            cards = f'<div class="empty">{"No results for &quot;"+q+"&quot;" if q else "Nothing found in "+source_name}</div>'

    radarr_count = len(await lm.get_radarr_direct(radarr_url, radarr_key)) if radarr_url and radarr_key else 0
    sonarr_count = len(await lm.get_sonarr_direct(sonarr_url, sonarr_key)) if sonarr_url and sonarr_key else 0
    not_added_count = len(not_added)

    body = f"""
    <h2>Import from Sonarr / Radarr</h2>
    <div class="tabs">
      <div class="tab {'active' if tab=='radarr' else ''}" onclick="switchTab('radarr')">🎬 Radarr ({radarr_count})</div>
      <div class="tab {'active' if tab=='sonarr' else ''}" onclick="switchTab('sonarr')">📺 Sonarr ({sonarr_count})</div>
    </div>
    <div class="search-bar">
      <input id="q" type="text" placeholder="Search {source_name}..." value="{q}" oninput="filterCards()">
      <button class="btn btn-sec" onclick="clearSearch()">Clear</button>
      <button class="btn btn-sec" onclick="refreshSource()">🔄 Refresh</button>
      {f'<button class="btn btn-add" onclick="addAllServer()" style="margin-left:auto" id="add-all-btn">+ Add All ({len(not_added)})</button>' if not_added else ''}
    </div>
    <div id="card-grid" class="card-grid">{cards}</div>
    {_pagination("/import", {"tab": tab, "q": q}, page, total_imp_pages)}
    <div id="add-progress" style="display:none;margin-top:16px;padding:12px;background:#1a1a24;border-radius:8px;font-size:0.85rem"></div>"""

    import json as _ijson
    _not_added_json = _ijson.dumps([{
        "title": i["title"], "year": i.get("year"),
        "id": i.get("id"), "sc": i.get("season_count", 0)
    } for i in not_added])

    extra = f"""<script>
const CURRENT_TAB = '{tab}';
const ALL_NOT_ADDED = {_not_added_json};

function switchTab(t) {{
  window.location.href = '/import?tab=' + t;
}}

function filterCards() {{
  const q = document.getElementById('q').value.toLowerCase();
  document.querySelectorAll('#card-grid .card').forEach(c => {{
    c.style.display = q === '' || c.dataset.title.includes(q) ? '' : 'none';
  }});
}}

function clearSearch() {{
  document.getElementById('q').value = '';
  filterCards();
}}

async function refreshSource() {{
  window.location.href = '/import?tab=' + CURRENT_TAB + '&_=' + Date.now();
}}

async function addCard(btn) {{
  btn.disabled = true;
  btn.textContent = '⏳';
  const type  = btn.dataset.mtype;
  const id    = parseInt(btn.dataset.id) || null;
  const title = btn.dataset.title.replace(/&#39;/g,"'").replace(/&quot;/g,'"');
  const year  = btn.dataset.year ? parseInt(btn.dataset.year) : null;
  const sc    = parseInt(btn.dataset.sc) || 0;
  const r = await fetch('/api/library/add', {{method:'POST',
    headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{media_type:type, arr_id:id, title, year, season_count:sc}})}});
  const d = await r.json();
  if (r.ok && d.status !== 'skipped') {{
    btn.textContent = '✓ Added';
    btn.className = 'btn';
    btn.style.background = '#14532d';
    btn.disabled = true;
    btn.closest('.card').dataset.inLib = '1';
    toast('✅ ' + title + ' added');
  }} else if (d.status === 'skipped') {{
    btn.textContent = '🎬 Not out yet';
    btn.style.background = '#78350f';
    btn.style.color = '#fcd34d';
    btn.disabled = true;
    toast('⏭️ ' + title + ' is not released yet', false);
  }} else {{
    btn.textContent = '❌ Error';
    btn.disabled = false;
    toast('❌ ' + (d.detail || d.message || 'Error'), false);
  }}
}}

async function addAllServer() {{
  const btn  = document.getElementById('add-all-btn');
  const prog = document.getElementById('add-progress');
  if (!ALL_NOT_ADDED || !ALL_NOT_ADDED.length) {{ toast('Nothing to add', false); return; }}
  btn.disabled  = true;
  btn.textContent = '⏳ Starting...';
  prog.style.display = 'block';
  prog.textContent = `Queuing ${{ALL_NOT_ADDED.length}} item(s)...`;

  const r = await fetch('/api/import/add-all', {{
    method: 'POST',
    headers: {{'Content-Type': 'application/json'}},
    body: JSON.stringify({{ tab: CURRENT_TAB, items: ALL_NOT_ADDED }}),
  }});
  const d = await r.json();

  if (!r.ok) {{
    prog.textContent = '❌ Error: ' + (d.detail || 'Failed');
    btn.disabled = false;
    btn.textContent = '+ Add All';
    return;
  }}

  if (d.queued === 0) {{
    prog.textContent = '✅ ' + (d.message || 'All already in library');
    btn.textContent = '+ Add All (0)';
    return;
  }}

  prog.textContent = `✅ ${{d.queued}} item(s) queued — adding in background (job: ${{d.job_id}})`;
  btn.textContent  = `⏳ Adding ${{d.queued}}...`;

  // Poll the job until done
  let polls = 0;
  const poll = setInterval(async () => {{
    polls++;
    const jr = await fetch('/api/jobs');
    const jd = await jr.json();
    const running  = jd.running  || [];
    const history  = jd.history  || [];
    const job = running.find(j => j.id === d.job_id) ||
                history.find(j => j.id === d.job_id);

    if (!job || job.status === 'done') {{
      clearInterval(poll);
      prog.textContent = `✅ Done — ${{d.queued}} item(s) added. Refreshing...`;
      btn.textContent  = '✅ Done';
      setTimeout(() => location.href = '/import?tab=' + CURRENT_TAB, 1500);
    }} else if (job.status === 'error') {{
      clearInterval(poll);
      prog.textContent = '❌ Import error: ' + (job.error || 'Unknown');
      btn.disabled = false;
      btn.textContent = '+ Add All';
    }} else if (polls > 600) {{
      clearInterval(poll);
      prog.textContent = '⏰ Still running in background — check Jobs page';
    }} else {{
      prog.textContent = `⏳ Adding... (job ${{d.job_id}} running)`;
    }}
  }}, 2000);
}}

// Keep old addAll as alias for page-level cards (used nowhere now but kept for safety)
async function addAll() {{ return addAllServer(); }}
</script>"""

    return _page("Import", "import", body, extra)


@app.get("/api/test-prowlarr")
async def api_test_prowlarr(request: Request):
    """Test Prowlarr connectivity and return the first few indexer names."""
    db: CacheDB = request.app.state.db
    url = db.get_setting("PROWLARR_URL", "").rstrip("/")
    key = db.get_setting("PROWLARR_API_KEY", "")
    if not url or not key:
        return {"ok": False, "message": "PROWLARR_URL or PROWLARR_API_KEY not set in Settings"}
    import httpx as _hx
    try:
        # Test 1: hit the indexers list endpoint
        async with _hx.AsyncClient(timeout=10) as c:
            r = await c.get(
                f"{url}/api/v1/indexer",
                headers={"X-Api-Key": key},
            )
        if r.status_code == 200:
            indexers    = r.json()
            names       = [i.get("name", "?") for i in indexers[:5]]
            search_url  = f"{url}/api/v1/search"
            return {
                "ok":           True,
                "message":      f"{len(indexers)} indexer(s): {', '.join(names)}",
                "torznab_url":  search_url,
                "indexer_count": len(indexers),
            }
        elif r.status_code == 401:
            return {"ok": False, "message": f"Unauthorized — check API key (HTTP 401)"}
        elif r.status_code == 404:
            return {
                "ok":     False,
                "message": (
                    f"HTTP 404 — URL may be wrong. "
                    f"Tried: {url}/api/v1/indexer. "
                    f"Expected format: http://prowlarr:9696 or http://host:9696/prowlarr"
                ),
            }
        else:
            return {"ok": False, "message": f"HTTP {r.status_code} from {url}"}
    except Exception as e:
        return {"ok": False, "message": str(e)}


@app.post("/api/import/refresh")
async def api_import_refresh(request: Request):
    lm: LibraryManager = request.app.state.library
    lm.invalidate_direct_cache()
    return {"status": "ok"}


@app.post("/api/import/add-all")
async def api_import_add_all(request: Request, background_tasks: BackgroundTasks):
    """
    Add every not-yet-added item from Sonarr or Radarr in one call.
    The client sends the full list (title, year, id, media_type, season_count)
    for every item it wants added. Processing happens in a background task so
    the HTTP response returns immediately with a job_id to poll.
    """
    body     = await request.json()
    tab      = body.get("tab", "radarr")          # "radarr" | "sonarr"
    items    = body.get("items", [])              # [{title, year, id, sc}, ...]
    mtype    = "movie" if tab == "radarr" else "series"

    if not items:
        return {"status": "ok", "queued": 0, "message": "Nothing to add"}

    db: CacheDB         = request.app.state.db
    lm: LibraryManager  = request.app.state.library

    # Filter out already-added items server-side (race-safe)
    already = {(r["media_type"], r["title"].lower()) for r in db.fake_library_list()}
    to_add  = [i for i in items if (mtype, i["title"].lower()) not in already]

    if not to_add:
        return {"status": "ok", "queued": 0, "message": "All items already in library"}

    jid, cancel_event = _job_start(
        f"Bulk import {len(to_add)} {mtype}(s) from {'Radarr' if tab=='radarr' else 'Sonarr'}",
        job_type="bulk_import",
        cancellable=True,
    )

    async def _do_bulk():
        added = skipped = errors = 0
        for item in to_add:
            if cancel_event.is_set():
                break
            try:
                # Re-use the same logic as /api/library/add
                title        = item.get("title", "").strip()
                year         = item.get("year")
                arr_id       = item.get("id")
                season_count = item.get("sc", 0)
                if not title:
                    continue

                tmdb_key = db.get_setting("tmdb_api_key", "")

                if mtype == "movie":
                    movies     = await lm.get_radarr_movies()
                    movie      = next((m for m in movies if m.get("id") == arr_id
                                       or m["title"].lower() == title.lower()), None)
                    poster_url = movie.get("poster", "") if movie else ""
                    tmdb_id    = movie.get("tmdb_id") if movie else None
                    imdb_id    = movie.get("imdb_id") if movie else None
                    overview   = movie.get("overview", "") if movie else ""

                    include_unreleased = db.get_setting("include_unreleased_movies", "false") == "true"
                    if not include_unreleased:
                        from datetime import date
                        release_date = movie.get("release_date", "") if movie else ""
                        if release_date and release_date > date.today().isoformat():
                            skipped += 1
                            continue

                    if not poster_url and tmdb_key and tmdb_id:
                        poster_url = await _fetch_tmdb_poster(tmdb_id, title, True, tmdb_key)

                    db.fake_library_add({
                        "media_type": "movie", "title": title, "year": year,
                        "radarr_id": arr_id, "tmdb_id": tmdb_id, "imdb_id": imdb_id,
                        "poster_url": poster_url, "overview": overview,
                        "status": "movie", "fake_path": None,
                    })
                    if db.get_setting("precache_enabled", "true") != "false":
                        _queue_index(request.app, _precache_movie, request.app, title, year, tmdb_id, imdb_id)
                    added += 1
                    log.info(f"📦 Bulk import movie: {title} ({year})")

                else:
                    series_list = await lm.get_sonarr_series()
                    series      = next((s for s in series_list if s.get("id") == arr_id), None)
                    sc          = series.get("season_count", season_count) if series else season_count
                    tvdb_id     = series.get("tvdb_id") if series else None
                    tmdb_id     = series.get("tmdb_id") if series else None
                    imdb_id     = series.get("imdb_id") if series else None
                    poster_url  = series.get("poster", "") if series else ""
                    overview    = series.get("overview", "") if series else ""
                    is_ended    = series.get("is_ended", False) if series else False
                    req_seasons = series.get("requested_seasons", []) if series else []

                    if not poster_url and tmdb_key and tmdb_id:
                        poster_url = await _fetch_tmdb_poster(tmdb_id, title, False, tmdb_key)

                    include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"
                    episodes = await lm.get_episodes(
                        arr_id, include_unreleased=False,
                        requested_seasons=req_seasons if req_seasons else None,
                    )

                    db.fake_library_add({
                        "media_type": "series", "title": title, "year": year,
                        "sonarr_id": arr_id, "tvdb_id": tvdb_id, "tmdb_id": tmdb_id,
                        "imdb_id": imdb_id, "season_count": sc, "poster_url": poster_url,
                        "overview": overview,
                        "status": "ended" if is_ended else "continuing",
                        "fake_path": None,
                    })
                    if db.get_setting("precache_enabled", "true") != "false":
                        _queue_index(request.app, _precache_series, request.app, title, year, episodes)
                    added += 1
                    log.info(f"📦 Bulk import series: {title} ({year})")

                # Small yield so other tasks aren't starved
                await asyncio.sleep(0.1)

            except asyncio.CancelledError:
                break
            except Exception as e:
                log.error(f"Bulk import '{item.get('title')}': {e}")
                errors += 1

        summary = f"Bulk import done: {added} added, {skipped} skipped, {errors} errors"
        log.info(f"📦 {summary}")
        _job_done(jid)

    background_tasks.add_task(_do_bulk)
    return {"status": "ok", "job_id": jid, "queued": len(to_add)}


# ── /library — browse Overseerr ───────────────────────────────────────────────
@app.get("/library", response_class=HTMLResponse)
async def library_browse(request: Request, tab: str = "movies", q: str = "", page: int = 1):
    if _needs_setup(request): return _setup_redirect()
    lm: LibraryManager = request.app.state.library
    db: CacheDB = request.app.state.db

    PER_PAGE = 24
    already_added = {(r["media_type"], r["title"].lower()) for r in db.fake_library_list()}

    if tab == "movies":
        all_items = await lm.get_radarr_movies()
    else:
        all_items = await lm.get_sonarr_series()

    if q:
        ql = q.lower()
        all_items = [i for i in all_items if ql in i["title"].lower()]

    total_items = len(all_items)
    total_pages = max(1, (total_items + PER_PAGE - 1) // PER_PAGE)
    page        = max(1, min(page, total_pages))
    items       = all_items[(page-1)*PER_PAGE : page*PER_PAGE]

    cards = ""
    for item in items:
        mtype = "movie" if tab == "movies" else "series"
        year  = item.get("year")
        in_lib = (mtype, item["title"].lower()) in already_added
        poster = item.get("poster", "")
        img = f'<img src="{poster}" onerror="this.style.display=\'none\'" loading="lazy">' if poster else f'<div class="no-poster">{item["title"][:1]}</div>'
        safe = item["title"].replace("'", "\\'").replace('"', '&quot;')
        sc  = item.get("season_count", 0)
        meta = str(year or "")
        if tab != "movies" and sc:
            meta += f" · {sc} season{'s' if sc != 1 else ''}"
        badge = '<div class="actions"><span class="badge-in">✓ In Library</span>' if in_lib else ""

        if in_lib:
            t = item["title"].replace('"', '&quot;')
            action = f'<button class="btn btn-rem" data-mtype="{mtype}" data-title="{t}" data-year="{year or ""}" onclick="removeCard(this)">Remove</button>'
        else:
            t = item["title"].replace('"', '&quot;')
            action = f'<button class="btn btn-add" data-mtype="{mtype}" data-id="{item.get("id","")}" data-title="{t}" data-year="{year or ""}" data-sc="{sc}" onclick="addCard(this)">+ Add</button>'

        cards += f"""<div class="card">
          {img}
          <div class="info">
            <div class="title" title="{item['title']}">{item['title']}</div>
            <div class="meta">{meta}</div>
          </div>
          <div class="actions">{action}</div>
        </div>"""

    if not cards:
        cards = f'<div class="empty">{"No results for &quot;"+q+"&quot;" if q else "Nothing found — check Overseerr settings"}</div>'

    movie_count = len(await lm.get_radarr_movies())
    tv_count    = len(await lm.get_sonarr_series())

    body = f"""
    <h2>Browse Library</h2>
    <div class="tabs">
      <div class="tab {'active' if tab=='movies' else ''}" onclick="location.href='/library?tab=movies&q={q}'">🎬 Movies ({movie_count})</div>
      <div class="tab {'active' if tab=='tv'     else ''}" onclick="location.href='/library?tab=tv&q={q}'">📺 TV Shows ({tv_count})</div>
    </div>
    <div class="search-bar">
      <input id="q" type="text" placeholder="Search..." value="{q}"
             onkeydown="if(event.key==='Enter')location.href='/library?tab={tab}&q='+encodeURIComponent(this.value)">
      <button class="btn btn-add" onclick="location.href='/library?tab={tab}&q='+encodeURIComponent(document.getElementById('q').value)">Search</button>
      {'<button class="btn btn-sec" onclick="location.href=\'/library?tab='+tab+'\'">Clear</button>' if q else ''}
      <button class="btn btn-sec" onclick="refreshLib()">🔄 Refresh</button>
    </div>
    <div class="card-grid">{cards}</div>
    {_pagination("/library", {"tab": tab, "q": q}, page, total_pages)}"""

    extra = """<script>
function addCard(btn) {
  const type  = btn.dataset.mtype;
  const id    = parseInt(btn.dataset.id) || null;
  const title = btn.dataset.title;
  const year  = btn.dataset.year ? parseInt(btn.dataset.year) : null;
  const sc    = parseInt(btn.dataset.sc) || 0;
  addItem(type, id, title, year, sc);
}
function removeCard(btn) {
  const type  = btn.dataset.mtype;
  const title = btn.dataset.title;
  const year  = btn.dataset.year ? parseInt(btn.dataset.year) : null;
  removeItem(type, title, year);
}
async function addItem(type, id, title, year, sc) {
  const r = await fetch('/api/library/add', {method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({media_type:type,arr_id:id,title,year,season_count:sc})});
  const d = await r.json();
  if (r.ok && d.status !== 'skipped') { toast('✅ '+title+' added'); setTimeout(()=>location.reload(),1200); }
  else if (d.status === 'skipped') { toast('⏭️ '+title+' is not released yet — enable "Include unreleased movies" in Settings', false); }
  else { toast('❌ '+(d.detail||d.message||'Error'), false); }
}
async function removeItem(type, title, year) {
  if (!confirm('Remove "'+title+'" from library?')) return;
  const r = await fetch('/api/library/remove',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({media_type:type,title,year})});
  if (r.ok) { toast('🗑️ Removed'); setTimeout(()=>location.reload(),1200); }
  else { toast('❌ Error', false); }
}
async function refreshLib() {
  const r = await fetch('/api/library/refresh',{method:'POST'});
  const d = await r.json();
  toast('✅ Refreshed — '+d.synced+' series updated');
  setTimeout(()=>location.reload(),1200);
}
</script>"""
    return _page("Browse Library", "library", body, extra)


# ── /api/library/add ─────────────────────────────────────────────────────────
@app.post("/api/library/add")
async def api_library_add(request: Request, background_tasks: BackgroundTasks):
    body = await request.json()
    media_type   = body.get("media_type", "movie")
    arr_id       = body.get("arr_id")
    title        = body.get("title", "").strip()
    year         = body.get("year")
    season_count = body.get("season_count", 0)

    if not title:
        raise HTTPException(400, "title required")

    lm: LibraryManager = request.app.state.library
    db: CacheDB         = request.app.state.db
    tmdb_key            = db.get_setting("tmdb_api_key", "")

    if media_type == "movie":
        # Fetch full movie details from Overseerr to get poster/overview/tmdb_id
        movies = await lm.get_radarr_movies()
        movie  = next((m for m in movies if m.get("id") == arr_id or m["title"].lower() == title.lower()), None)

        poster_url = movie.get("poster", "") if movie else ""
        tmdb_id    = movie.get("tmdb_id") if movie else None
        imdb_id    = movie.get("imdb_id") if movie else None
        overview   = movie.get("overview", "") if movie else ""

        # Filter unreleased movies if setting is off
        include_unreleased_movies = db.get_setting("include_unreleased_movies", "false") == "true"
        if not include_unreleased_movies:
            from datetime import date
            today = date.today().isoformat()
            release_date = movie.get("release_date", "") if movie else ""
            if release_date and release_date > today:
                log.info(f"⏭️  Skipping unreleased movie: {title!r} (release_date={release_date!r})")
                return {"status": "skipped", "message": f"{title} is not yet released — enable 'Include unreleased movies' in Settings to add it"}

        # Fetch poster from TMDB if not from Overseerr
        if not poster_url and tmdb_key and tmdb_id:
            poster_url = await _fetch_tmdb_poster(tmdb_id, title, True, tmdb_key)

        db.fake_library_add({
            "media_type": "movie",
            "title":      title,
            "year":       year,
            "radarr_id":  arr_id,
            "tmdb_id":    tmdb_id,
            "imdb_id":    imdb_id,
            "poster_url": poster_url,
            "overview":   overview,
            "status":     "movie",
            "fake_path":  None,
        })
        log.info(f"🎬 Added movie: {title} ({year})")
        _queue_index(request.app, _precache_movie, request.app, title, year, tmdb_id, imdb_id)

        return {"status": "ok", "message": f"Added {title}"}

    else:
        # Series — fetch details synchronously so we can return a useful response
        series_list = await lm.get_sonarr_series()
        series = next((s for s in series_list if s.get("id") == arr_id), None)

        # Trust Overseerr/TMDB for the exact requested series title/year. The
        # client payload can contain a stale/episode-derived year.
        if series:
            title = series.get("title") or title
            year  = series.get("year") or await _canonical_series_year(request.app, title, year)
        else:
            year  = await _canonical_series_year(request.app, title, year)

        sc                = series.get("season_count", season_count) if series else season_count
        tvdb_id           = series.get("tvdb_id") if series else None
        tmdb_id           = series.get("tmdb_id") if series else None
        imdb_id           = series.get("imdb_id") if series else None
        poster_url        = series.get("poster", "") if series else ""
        overview          = series.get("overview", "") if series else ""
        is_ended          = series.get("is_ended", False) if series else False
        requested_seasons = series.get("requested_seasons", []) if series else []

        # Block unreleased series unless setting allows it
        include_unreleased_series = db.get_setting("include_unreleased_episodes", "false") == "true"
        if not include_unreleased_series and series:
            from datetime import date as _d
            first_air = series.get("first_air_date", "") or ""
            if first_air and first_air > _d.today().isoformat():
                log.info(f"⏭️  Skipping unreleased series: {title!r} (first_air_date={first_air!r})")
                return {"status": "skipped",
                        "message": f"'{title}' hasn't aired yet ({first_air}). Enable 'Include unreleased episodes' in Settings to add it anyway."}

        if not poster_url and tmdb_key and tmdb_id:
            poster_url = await _fetch_tmdb_poster(tmdb_id, title, False, tmdb_key)

        # Fetch ALL episodes from Overseerr/TMDB (including unreleased)
        episodes = await lm.get_episodes(
            arr_id,
            include_unreleased=False,
            requested_seasons=requested_seasons if requested_seasons else None,
        )

        log.info(f"📺 {title}: {len(episodes)} episodes from Overseerr for seasons {requested_seasons}")

        db.fake_library_add({
            "media_type":   "series",
            "title":        title,
            "year":         year,
            "sonarr_id":    arr_id,
            "tvdb_id":      tvdb_id,
            "tmdb_id":      tmdb_id,
            "imdb_id":      imdb_id,
            "season_count": sc,
            "poster_url":   poster_url,
            "overview":     overview,
            "status":       "ended" if is_ended else "continuing",
            "fake_path":    None,
        })

        log.info(f"📺 Added {title!r} — episodes indexed, no placeholders created")

        # Index hashes in background (no AllDebrid changes until play)
        _queue_index(request.app, _precache_series, request.app, title, year, episodes)

        return {"status": "ok", "message": f"Added {title} — {len(episodes)} episodes"}


@app.post("/api/library/remove")
async def api_library_remove(request: Request):
    body  = await request.json()
    mtype = body.get("media_type")
    title = body.get("title", "").strip()
    year  = body.get("year")
    lm    = request.app.state.library
    db    = request.app.state.db
    alldebrid = request.app.state.alldebrid

    # ── 0. Cancel all running jobs and precache tasks for this title ─────────
    title_lower = title.lower()
    cancelled_jobs = 0
    for job in list(_jobs.values()):
        if job.get("name", "").lower().startswith(title_lower):
            evt = job.get("cancel_event")
            if evt:
                evt.set()
                job["status"] = "cancelling"
                cancelled_jobs += 1
    if cancelled_jobs:
        log.info(f"🚫 Cancelled {cancelled_jobs} running job(s) for '{title}'")

    # Cancel the precache asyncio Task directly so the episode loop stops immediately
    precache_task = _precache_tasks.pop(title_lower, None)
    if precache_task and not precache_task.done():
        precache_task.cancel()
        log.info(f"🚫 Cancelled precache task for '{title}'")

    await asyncio.sleep(0.5)  # brief grace period for tasks to wind down

    # ── 1. Find all cache entries for this title ──────────────────────────────
    db_types    = ["movie"] if mtype == "movie" else ["episode", "series"]
    all_entries = db.list_all()
    entries     = [
        e for e in all_entries
        if e["title"].lower() == title.lower() and e["media_type"] in db_types
    ]
    log.info(f"🗑️  Removing '{title}' — {len(entries)} cache entries to clean up")

    # ── 2. AllDebrid: delete magnets ──────────────────────────────────────────
    import re as _re
    deleted_magnet_ids: set[str] = set()
    for entry in entries:
        magnet = entry.get("magnet_link") or ""
        m = _re.search(r"[?&]xt=urn:btih:([a-fA-F0-9]{40})", magnet, _re.I)
        if not m:
            continue
        # Find the magnet ID by querying AllDebrid status
        # We stored the magnet ID from add_magnet — it's not in our DB directly,
        # but we can delete by hash using the upload endpoint
        # Simpler: re-upload to get the ID, then delete
        try:
            result = await alldebrid._ad_post(
                alldebrid._client, alldebrid.api_key,
                "https://api.alldebrid.com/v4/magnet/upload",
                [("magnets[]", magnet)],
            )
            magnets_returned = result.get("data", {}).get("magnets", [])
            for mg in magnets_returned:
                if mg.get("error"):
                    continue
                mid = str(mg.get("id", ""))
                if mid and mid not in deleted_magnet_ids:
                    await alldebrid.delete_magnet(mid)
                    deleted_magnet_ids.add(mid)
                    log.info(f"  🗑️  AllDebrid: deleted magnet id={mid}")
        except Exception as e:
            log.warning(f"  ⚠ AllDebrid cleanup failed for '{title}': {e}")

    # ── 3. FUSE: unregister torrents ──────────────────────────────────────────
    if FUSE_AVAILABLE:
        torrent_names = {e["torrent_name"] for e in entries if e.get("torrent_name")}
        for tname in torrent_names:
            unregister_torrent(tname)
            log.info(f"  🗑️  FUSE: unregistered '{tname}'")

    # ── 4. DFS chunk cache: delete chunks for these stream URLs ───────────────
    try:
        from app.fuse_mount import _dfs
        import hashlib as _hl
        cache_dir = Path(_dfs.get("cache_dir", "/docker/debridarr/tmp/cache"))
        if cache_dir.exists():
            stream_urls = {e["stream_url"] for e in entries if e.get("stream_url")}
            deleted_chunks = 0
            for url in stream_urls:
                h = _hl.md5(url.encode()).hexdigest()[:16]
                for chunk_file in cache_dir.glob(f"{h}_*"):
                    chunk_file.unlink(missing_ok=True)
                    deleted_chunks += 1
            if deleted_chunks:
                log.info(f"  🗑️  DFS: deleted {deleted_chunks} cached chunks")
    except Exception as e:
        log.warning(f"  ⚠ DFS chunk cleanup failed: {e}")

    # ── 5. Plex-strm: remove files ───────────────────────────────────────────
    if mtype == "movie":
        lm.remove_fake_movie(title, year)
    else:
        lm.remove_fake_series(title)

    # ── 6. DB: remove cache entries and fake_library record ──────────────────
    for entry in entries:
        db.delete(entry["cache_key"])
    db.fake_library_remove(mtype, title, year)

    # ── 6b. Hash index: remove all hashes for this title ─────────────────────
    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    if hi:
        removed_hashes = hi.delete_for_title(title)
        log.info(f"🗑️  HashIndex: removed {removed_hashes} hash entries for '{title}'")

    # ── 7. Clear in-memory search cache ──────────────────────────────────────
    from app.alldebrid import _search_cache
    for k in [k for k in list(_search_cache) if title.lower() in k.lower()]:
        del _search_cache[k]

    # Remove from hash index
    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    hi_removed = 0
    if hi:
        hi_removed = hi.remove_title(title)

    # Remove from upcoming episodes tracker and pin exemptions
    db.remove_upcoming(title)
    db.remove_pin_exemption(title)

    log.info(f"🗑️  '{title}' fully removed: "
             f"{len(entries)} cache entries, {len(deleted_magnet_ids)} AllDebrid magnets, "
             f"{len({e.get('torrent_name') for e in entries if e.get('torrent_name')})} FUSE torrents, "
             f"{hi_removed} hash entries")

    return {
        "status": "removed",
        "cache_entries_deleted": len(entries),
        "magnets_deleted": len(deleted_magnet_ids),
    }


@app.post("/api/library/refresh")
async def api_library_refresh(request: Request):
    lm = request.app.state.library
    db = request.app.state.db
    if not lm: return {"status": "error", "message": "Not configured"}
    lm.invalidate_cache()
    movies = await lm.get_radarr_movies(force=True)
    series = await lm.get_sonarr_series(force=True)
    added  = [r for r in db.fake_library_list() if r["media_type"] == "series"]
    include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"
    synced = 0
    for entry in added:
        sid = entry.get("sonarr_id")
        if not sid: continue
        updated = next((s for s in series if s.get("id") == sid), None)
        if not updated: continue
        result = await lm.sync_series_episodes(entry["title"], sid, entry.get("year"),
                                                include_unreleased,
                                                requested_seasons=updated.get("requested_seasons", []))
        if result.get("added", 0) > 0: synced += 1
    return {"status": "ok", "movies": len(movies), "series": len(series), "synced": synced}


# ── /streams — resolved streams + search ─────────────────────────────────────
@app.get("/streams", response_class=HTMLResponse)
async def streams_page(request: Request, q: str = "", filter_type: str = "all"):
    if _needs_setup(request): return _setup_redirect()
    db: CacheDB = request.app.state.db
    tmdb_key = db.get_setting("tmdb_api_key", "")

    # Get library items for the search/poster display
    lib_items = db.fake_library_list()
    movies_lib = [i for i in lib_items if i["media_type"] == "movie"]
    shows_lib  = [i for i in lib_items if i["media_type"] == "series"]

    # Cached counts per title
    all_cached = [e for e in db.list_all() if e["status"] == "cached"]
    cached_counts: dict[str, int] = {}
    for e in all_cached:
        mt = "movie" if e["media_type"] == "movie" else "series"
        k  = f"{mt}::{e['title'].lower()}"
        cached_counts[k] = cached_counts.get(k, 0) + 1

    # Streams table (all entries — filtering done client-side)
    entries = db.list_all()
    entries.sort(key=lambda e: e.get("title","").lower())

    def pill(s):
        cls = {"cached":"pill-ok","resolving":"pill-res","error":"pill-err","not_found":"pill-nf"}.get(s,"pill-pend")
        return f'<span class="pill {cls}">{s}</span>'

    rows = ""
    for e in entries:
        t = e.get("torrent_name","") or ""
        t_short = (t[:60]+"…") if len(t) > 60 else t
        ep  = ""
        if e.get("season"):  ep += f"S{str(e['season']).zfill(2)}"
        if e.get("episode"): ep += f"E{str(e['episode']).zfill(2)}"
        exp = datetime.fromisoformat(e["expires_at"]).strftime("%Y-%m-%d") if e.get("expires_at") else "—"
        safe_title = e['title'].replace('"','&quot;')
        rows += f"""<tr data-title="{safe_title.lower()}" data-status="{e['status']}">
          <td style="color:#888;font-size:0.8rem">{e['media_type']}</td>
          <td><strong>{e['title']}</strong><br><small style="color:#555;font-size:0.72rem">{t_short}</small></td>
          <td style="font-family:monospace">{ep}</td>
          <td>{e.get('quality','—') or '—'}</td>
          <td>{exp}</td>
          <td>{pill(e['status'])}</td>
          <td style="white-space:nowrap">
            <button class="btn btn-rem" style="padding:3px 8px;font-size:0.72rem" data-key="{e['cache_key']}" onclick="del_(this)">Del</button>
            <button class="btn btn-sec" style="padding:3px 8px;font-size:0.72rem;margin-left:4px" data-key="{e['cache_key']}" onclick="expireNow(this)">⏰ Expire</button>
          </td>
        </tr>"""

    total = len(entries)

    # My Library cards section
    def lib_card(item, mtype):
        title  = item["title"]
        safe   = title.replace("'","&#39;").replace('"','&quot;')
        poster = item.get("poster_url") or ""
        sc     = item.get("season_count") or 0
        status = item.get("status","")
        year   = item.get("year") or ""
        n      = cached_counts.get(f"{mtype}::{title.lower()}", 0)

        if poster:
            img = f'<img src="{poster}" alt="{safe}" style="width:100%;aspect-ratio:2/3;object-fit:cover;display:block">'
        else:
            initials = "".join(w[0].upper() for w in title.split()[:2])
            img = f'<div class="no-poster">{initials}</div>'

        badge = f'<span class="badge-in">✅ {n} ep{"s" if n!=1 else ""}</span>' if n and mtype=="series" else \
                (f'<span class="badge-in">✅ Cached</span>' if n else \
                 '<span class="badge-grey">⏳ Not cached</span>')

        status_pill = ""
        if mtype == "series":
            col = "#ef4444" if status == "ended" else "#22c55e"
            lbl = "Ended" if status == "ended" else "Continuing"
            status_pill = f'<span style="font-size:0.65rem;color:{col};margin-left:4px">({lbl})</span>'

        sub = f"{sc} season{'s' if sc!=1 else ''}{status_pill}" if mtype=="series" else str(year)

        return (
            f'<div class="card" data-filter-title="{safe.lower()}" style="cursor:pointer" onclick="filterByTitle(this)">' +
            img +
            f'<div class="info"><div class="title" title="{safe}">{title}</div>' +
            f'<div class="meta">{sub}</div></div>' +
            f'<div class="actions">{badge}' +
            f'<button class="btn btn-rem" style="padding:3px 8px;font-size:0.7rem"' +
            f' data-mtype="{mtype}" data-title="{safe}" data-year="{item.get("year") or ""}"' +
            ' onclick="event.stopPropagation();remCard(this)">Remove</button></div></div>'
        )

    lib_section = ""
    if movies_lib:
        lib_section += f'''<div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;flex-wrap:wrap">
          <h2 style="margin:0">🎬 Movies <span id="movie-count" style="color:#555;font-size:0.8rem;font-weight:normal">({len(movies_lib)})</span></h2>
          <input id="movie-search" type="text" placeholder="Search movies…"
                 oninput="filterCards('movie')"
                 style="flex:1;min-width:160px;max-width:280px;background:#1a1a24;border:1px solid #2a2a3a;border-radius:8px;padding:7px 12px;color:#e0e0e0;font-size:0.85rem;outline:none">
          <button class="btn btn-sec" style="padding:6px 12px;font-size:0.8rem" onclick="document.getElementById('movie-search').value='';filterCards('movie')">Clear</button>
        </div>
        <div id="movie-grid" class="card-grid" style="margin-bottom:8px">{"".join(lib_card(i,"movie") for i in movies_lib)}</div>
        <div id="movie-pager" class="pg-bar" style="margin-bottom:32px"></div>'''
    if shows_lib:
        lib_section += f'''<div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;flex-wrap:wrap">
          <h2 style="margin:0">📺 TV Shows <span id="tv-count" style="color:#555;font-size:0.8rem;font-weight:normal">({len(shows_lib)})</span></h2>
          <input id="tv-search" type="text" placeholder="Search TV shows…"
                 oninput="filterCards('tv')"
                 style="flex:1;min-width:160px;max-width:280px;background:#1a1a24;border:1px solid #2a2a3a;border-radius:8px;padding:7px 12px;color:#e0e0e0;font-size:0.85rem;outline:none">
          <button class="btn btn-sec" style="padding:6px 12px;font-size:0.8rem" onclick="document.getElementById('tv-search').value='';filterCards('tv')">Clear</button>
        </div>
        <div id="tv-grid" class="card-grid" style="margin-bottom:8px">{"".join(lib_card(i,"series") for i in shows_lib)}</div>
        <div id="tv-pager" class="pg-bar" style="margin-bottom:32px"></div>'''
    if not lib_section:
        lib_section = f'<div class="empty"><a href="/library" style="color:#f97316">Browse Library</a> to add titles.</div>'

    streams_section = f"""
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
      <h2 style="margin:0">⚡ Resolved Streams <span id="stream-count" style="color:#555;font-size:0.8rem;font-weight:normal">({total}/{total})</span></h2>
      <div style="display:flex;align-items:center;gap:8px">
        <span style="color:#555;font-size:0.8rem">Show:</span>
        <select id="per-page-select" onchange="setPerPage(this.value)"
                style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:6px;
                       padding:5px 8px;color:#e0e0e0;font-size:0.8rem;outline:none">
          <option value="20">20</option>
          <option value="50">50</option>
          <option value="100">100</option>
          <option value="999999">All</option>
        </select>
        <button class="btn btn-rem" onclick="delAll()" style="padding:6px 14px">🗑️ Delete All Visible</button>
      </div>
    </div>
    <div class="search-bar" style="margin-bottom:14px">
      <input id="sq" type="text" placeholder="Search streams..." oninput="applyFilters(true)">
      <button class="btn btn-sec" onclick="clearSearch()">Clear</button>
      <select id="status-filter" onchange="applyFilters(true)"
              style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:8px;padding:8px 12px;color:#e0e0e0;font-size:0.85rem;outline:none">
        <option value="all">All statuses</option>
        <option value="cached">Cached</option>
        <option value="not_found">Not found</option>
        <option value="error">Error</option>
      </select>
    </div>
    <div id="streams-table">
      {"<table id='st'><thead><tr><th>Type</th><th>Title</th><th>Ep</th><th>Quality</th><th>Expires</th><th>Status</th><th></th></tr></thead><tbody>"+rows+"</tbody></table>" if rows else '<div class="empty">No streams yet.</div>'}
    </div>"""

    body = lib_section + '<hr style="border:none;border-top:1px solid #2a2a3a;margin:32px 0">' + streams_section

    extra = """<script>
// ── Card pagination/search (movies & TV) ─────────────────────────────────────
const CARDS_PER_PAGE = 12;
const cardState = { movie: { page: 1, q: '' }, tv: { page: 1, q: '' } };

function filterCards(section) {
  const gridId  = section + '-grid';
  const pagerId = section + '-pager';
  const countId = section + '-count';
  const inputId = section + '-search';
  const q = (document.getElementById(inputId)?.value || '').toLowerCase().trim();
  cardState[section].q = q;
  cardState[section].page = 1;
  renderCards(section);
}

function renderCards(section) {
  const gridEl  = document.getElementById(section + '-grid');
  const pagerEl = document.getElementById(section + '-pager');
  const countEl = document.getElementById(section + '-count');
  if (!gridEl) return;

  const q     = cardState[section].q;
  const page  = cardState[section].page;
  const cards = [...gridEl.querySelectorAll('.card')];
  const matched = cards.filter(c => !q || c.dataset.filterTitle.includes(q));
  const total   = matched.length;
  const totalPages = Math.max(1, Math.ceil(total / CARDS_PER_PAGE));
  cardState[section].page = Math.min(page, totalPages);
  const start = (cardState[section].page - 1) * CARDS_PER_PAGE;

  cards.forEach(c => c.style.display = 'none');
  matched.forEach((c, i) => c.style.display = (i >= start && i < start + CARDS_PER_PAGE) ? '' : 'none');

  if (countEl) countEl.textContent = '(' + total + ')';
  if (pagerEl) pagerEl.innerHTML = buildPager(section, cardState[section].page, totalPages);
}

function goCardPage(section, p) {
  cardState[section].page = p;
  renderCards(section);
  document.getElementById(section + '-grid')?.scrollIntoView({behavior:'smooth', block:'start'});
}

function buildPager(section, cur, total) {
  if (total <= 1) return '';
  const btn = (p, label, cls='') =>
    `<span class="pg-btn ${cls}" ${cls.includes('dis') ? '' : `onclick="goCardPage('${section}',${p})"`}>${label}</span>`;
  let pages = [];
  if (total <= 7) { for (let i=1;i<=total;i++) pages.push(i); }
  else {
    pages = [1];
    if (cur > 3) pages.push('…');
    for (let i=Math.max(2,cur-1);i<=Math.min(total-1,cur+1);i++) pages.push(i);
    if (cur < total-2) pages.push('…');
    pages.push(total);
  }
  let html = cur > 1 ? btn(cur-1,'‹') : btn(0,'‹','pg-dis');
  pages.forEach(p => {
    if (p==='…') html += btn(0,'…','pg-dis');
    else html += btn(p, p, p===cur ? 'pg-cur' : '');
  });
  html += cur < total ? btn(cur+1,'›') : btn(0,'›','pg-dis');
  return html;
}

// ── Streams table pagination/search ──────────────────────────────────────────
let STREAMS_PER_PAGE = 20;
let streamPage = 1;

function setPerPage(val) {
  STREAMS_PER_PAGE = parseInt(val) || 20;
  applyFilters(true);
}

function applyFilters(resetPage) {
  if (resetPage) streamPage = 1;
  const q      = (document.getElementById('sq').value || '').toLowerCase().trim();
  const status = document.getElementById('status-filter').value;
  const rows   = [...document.querySelectorAll('#st tbody tr')];
  const matched = rows.filter(r => {
    const titleMatch  = !q      || r.dataset.title.includes(q);
    const statusMatch = status === 'all' || r.dataset.status === status;
    return titleMatch && statusMatch;
  });
  const totalPages = Math.max(1, Math.ceil(matched.length / STREAMS_PER_PAGE));
  streamPage = Math.min(streamPage, totalPages);
  const start = (streamPage - 1) * STREAMS_PER_PAGE;
  const end   = start + STREAMS_PER_PAGE;

  rows.forEach(r => r.style.display = 'none');
  matched.forEach((r, i) => r.style.display = (i >= start && i < end) ? '' : 'none');

  const el = document.getElementById('stream-count');
  if (el) el.textContent = '(' + matched.length + ' total)';
  renderStreamPager(matched.length, totalPages);
}

function renderStreamPager(total, totalPages) {
  let el = document.getElementById('stream-pager');
  if (!el) {
    el = document.createElement('div');
    el.id = 'stream-pager';
    el.className = 'pg-bar';
    const tbl = document.getElementById('streams-table');
    if (tbl) tbl.after(el);
  }
  if (totalPages <= 1) { el.innerHTML = ''; return; }

  let html = '';
  const prev = streamPage > 1;
  const next = streamPage < totalPages;
  html += prev ? '<span class="pg-btn" onclick="goStreamPage('+( streamPage-1)+')">‹</span>'
               : '<span class="pg-btn pg-dis">‹</span>';

  let pages = [];
  if (totalPages <= 7) { for (let i=1;i<=totalPages;i++) pages.push(i); }
  else {
    pages = [1];
    if (streamPage > 3) pages.push('…');
    for (let i=Math.max(2,streamPage-1);i<=Math.min(totalPages-1,streamPage+1);i++) pages.push(i);
    if (streamPage < totalPages-2) pages.push('…');
    pages.push(totalPages);
  }
  pages.forEach(p => {
    if (p === '…') html += '<span class="pg-btn pg-dis">…</span>';
    else if (p === streamPage) html += '<span class="pg-btn pg-cur">'+p+'</span>';
    else html += '<span class="pg-btn" onclick="goStreamPage('+p+')">'+p+'</span>';
  });

  html += next ? '<span class="pg-btn" onclick="goStreamPage('+(streamPage+1)+')">›</span>'
               : '<span class="pg-btn pg-dis">›</span>';
  el.innerHTML = html;
}

function goStreamPage(p) { streamPage = p; applyFilters(false); window.scrollTo({top:document.getElementById('st')?.offsetTop||0,behavior:'smooth'}); }

function clearSearch() {
  document.getElementById('sq').value = '';
  document.getElementById('status-filter').value = 'all';
  applyFilters(true);
}

function filterByTitle(card) {
  const t = card.dataset.filterTitle || '';
  document.getElementById('sq').value = t;
  document.getElementById('status-filter').value = 'all';
  applyFilters();
  document.getElementById('st')?.scrollIntoView({behavior:'smooth', block:'start'});
}

async function expireNow(btn) {
  const k = btn.dataset.key;
  if (!confirm('Hard reset this cached stream? Symlink deleted, placeholder restored, removed from AllDebrid. Re-caches on next play.')) return;
  const r = await fetch('/cache/'+k+'/expire', {method:'POST'});
  if (r.ok) {
    const row = btn.closest('tr');
    if (row) {
      const pill = row.querySelector('.pill');
      if (pill) { pill.textContent = 'not_found'; pill.className = 'pill pill-nf'; }
      row.dataset.status = 'not_found';
    }
    toast('⏰ Reset — will re-cache on play');
    applyFilters();
  } else {
    toast('❌ Error', false);
  }
}

async function del_(btn) {
  const k = btn.dataset.key;
  const r = await fetch('/cache/'+k, {method:'DELETE'});
  if (r.ok) {
    const row = btn.closest('tr');
    if (row) row.remove();
    toast('🗑️ Deleted');
    applyFilters();
  } else {
    toast('❌ Error', false);
  }
}

async function delAll() {
  const rows = [...document.querySelectorAll('#st tbody tr')].filter(r => r.style.display !== 'none');
  if (!confirm('Delete ' + rows.length + ' visible streams?')) return;
  for (const row of rows) {
    const btn = row.querySelector('[data-key]');
    if (btn) {
      await fetch('/cache/'+btn.dataset.key, {method:'DELETE'});
      row.remove();
    }
  }
  toast('🗑️ All deleted');
  applyFilters();
}

async function remCard(btn) {
  const type  = btn.dataset.mtype;
  const title = btn.dataset.title.replace(/&#39;/g,"'").replace(/&quot;/g,'"');
  const year  = btn.dataset.year ? parseInt(btn.dataset.year) : null;
  if (!confirm('Remove "'+title+'" from library?')) return;
  const r = await fetch('/api/library/remove',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({media_type:type,title,year})});
  if (r.ok) {
    const card = btn.closest('.card');
    if (card) card.remove();
    document.querySelectorAll('#st tbody tr').forEach(row => {
      if (row.dataset.title === title.toLowerCase()) row.remove();
    });
    toast('🗑️ Removed');
    applyFilters();
  } else {
    toast('❌ Error', false);
  }
}

// Init on load
document.addEventListener('DOMContentLoaded', () => {
  renderCards('movie');
  renderCards('tv');
  applyFilters(true);
});
</script>"""
    return _page("Streams", "streams", body, extra)


# ── /settings ────────────────────────────────────────────────────────────────
@app.get("/settings", response_class=HTMLResponse)
async def settings_page(request: Request):
    if _needs_setup(request): return _setup_redirect()
    db: CacheDB = request.app.state.db
    ss  = db.get_all_settings()   # single source of truth — everything comes from here

    saved_msg = request.query_params.get("saved", "")

    def sv(key, default=""):
        """Get a setting value from DB."""
        return ss.get(key) or default

    def field(label, key, hint="", typ="text", placeholder="", masked_if_saved=False):
        val  = sv(key)
        mask = masked_if_saved and bool(val)
        ph   = "••••••• (saved — leave blank to keep)" if mask else (placeholder or "")
        attr = ' data-saved="true"' if mask else ""
        return f"""<div class="field">
          <label>{label}{'<span class="saved-badge">saved</span>' if mask else ""}</label>
          <input id="{key}" name="{key}" type="{'password' if mask else typ}"
                 value="{'  ' if mask else val}" placeholder="{ph}" autocomplete="off"{attr}>
          {'<div class="hint">'+hint+'</div>' if hint else ''}
        </div>"""

    def toggle(label, key, hint="", onchange=""):
        checked = 'checked' if ss.get(key, "false") == "true" else ""
        oc = f' onchange="{onchange}"' if onchange else ""
        return f"""<div style="display:flex;align-items:center;justify-content:space-between;gap:20px;margin-bottom:14px">
          <div>
            <div style="font-size:0.875rem;font-weight:600;margin-bottom:4px">{label}</div>
            {'<div style="font-size:0.75rem;color:#555">'+hint+'</div>' if hint else ''}
          </div>
          <label class="toggle">
            <input type="checkbox" name="{key}" value="true" {checked}{oc}>
            <span class="slider"></span>
          </label>
        </div>"""

    def select(label, key, options, hint=""):
        """options = list of (value, label)"""
        cur = ss.get(key, options[0][0])
        opts = "".join(
            f'<option value="{v}"{"selected" if v==cur else ""}>{lbl}</option>'
            for v, lbl in options
        )
        return f"""<div class="field"><label>{label}</label>
          <select name="{key}">{opts}</select>
          {'<div class="hint">'+hint+'</div>' if hint else ''}
        </div>"""

    debridarr_url = (sv("DEBRIDARR_BASE_URL") or "http://debridarr:7474").rstrip("/")
    tautulli_url  = f"{debridarr_url}/webhook/tautulli"
    tautulli_json = '{"media_type":"{media_type}","title":"{title}","grandparent_title":"{grandparent_title}","year":"{year}","grandparent_year":"{grandparent_year}","parent_media_index":"{parent_media_index}","media_index":"{media_index}","rating_key":"{rating_key}","themoviedb_id":"{themoviedb_id}","thetvdb_id":"{thetvdb_id}","imdb_id":"{imdb_id}"}'

    saved_banner = f'<div class="test-result ok" style="margin-bottom:16px">✅ {saved_msg}</div>' if saved_msg else ""

    body = f"""
    <div style="max-width:720px">
      <h2 style="margin-bottom:4px">⚙️ Settings</h2>
      <p style="color:#555;font-size:0.85rem;margin-bottom:20px">All settings are saved immediately when you click Save.</p>
      {saved_banner}

      <form method="POST" action="/settings/save">

      <div class="s-sect">
        <div class="s-title">AllDebrid</div>
        {field("API Key","ALLDEBRID_API_KEY","alldebrid.com/apikeys","text","",masked_if_saved=True)}
      </div>

      <div class="s-sect">
        <div class="s-title">Prowlarr</div>
        {field("URL","PROWLARR_URL","http://prowlarr:9696 — aggregate Torznab source for hash index","text","http://prowlarr:9696")}
        {field("API Key","PROWLARR_API_KEY","Prowlarr → Settings → General → API Key","text","",masked_if_saved=True)}
        {field("Min seconds between Prowlarr searches","PROWLARR_MIN_SECONDS_BETWEEN_SEARCHES","Anti-ban throttle. Default 3. Use 5–10 for strict/private indexers.","number","3")}
        {field("Prowlarr result limit","PROWLARR_SEARCH_LIMIT","Caps results per search before AllDebrid probing. Default 50, max 100.","number","50")}
        {field("Rate-limit cooldown seconds","PROWLARR_RATE_LIMIT_COOLDOWN_SECONDS","Pause Prowlarr after HTTP 403/429/5xx. Default 900 seconds.","number","900")}
        {field("Unavailable cooldown seconds","PROWLARR_UNAVAILABLE_COOLDOWN_SECONDS","Pause Prowlarr when all indexers are unavailable. Default 300 seconds.","number","300")}
        <div style="display:flex;gap:10px;align-items:center;margin-top:4px">
          <button type="button" class="btn btn-sec" style="padding:6px 14px" onclick="testProwlarr()">Test Connection</button>
          <div id="prowlarr-result" class="test-result" style="margin-top:0;flex:1"></div>
        </div>
      </div>

      <div class="s-sect">
        <div class="s-title">Overseerr</div>
        {field("URL","OVERSEERR_URL","http://overseerr:5055")}
        {field("API Key","OVERSEERR_API_KEY","Overseerr → Settings → General → API Key","text","",masked_if_saved=True)}
      </div>

      <div class="s-sect">
        <div class="s-title">Sonarr</div>
        {field("URL","SONARR_URL","http://sonarr:8989")}
        {field("API Key","SONARR_API_KEY","Sonarr → Settings → General → API Key","text","",masked_if_saved=True)}
      </div>

      <div class="s-sect">
        <div class="s-title">Radarr</div>
        {field("URL","RADARR_URL","http://radarr:7878")}
        {field("API Key","RADARR_API_KEY","Radarr → Settings → General → API Key","text","",masked_if_saved=True)}
      </div>

      <div class="s-sect">
        <div class="s-title">TMDB</div>
        {field("API Key","tmdb_api_key","themoviedb.org/settings/api — used for posters AND series/episode metadata","text","",masked_if_saved=True)}
      </div>

      <div class="s-sect">
        <div class="s-title">Plex</div>
        {field("Debridarr Base URL","DEBRIDARR_BASE_URL","URL Plex uses to reach Debridarr","text","http://192.168.1.x:7474")}
        {field("Plex Library Path","PLEX_ROOT","Path inside container where files are written","text","/plex-strm")}
        {field("Plex URL","PLEX_URL","Plex server URL Debridarr can reach, for instant targeted refresh","text","http://192.168.1.x:32400")}
        {field("Plex Token","PLEX_TOKEN","Used only to trigger targeted folder refresh after symlink creation","text","",masked_if_saved=True)}
        {field("Plex Movie Section ID","PLEX_MOVIE_SECTION_ID","Library section number for Movies, usually 1","number","1")}
        {field("Plex TV Section ID","PLEX_TV_SECTION_ID","Library section number for TV Shows, usually 2","number","2")}
        {toggle("Instant Plex refresh after symlink","instant_plex_refresh","Immediately refresh only the movie/show folder after each symlink is created")}
        {toggle("Symlink on play + binge lookahead","on_play_symlinks_only","Keep the library placeholder-first. Plex play creates the selected symlink immediately, and lookahead may pre-symlink the next episodes for bingeing. Startup/health scans do not mass-create symlinks.")}
        <div class="field" style="max-width:260px"><label>Played/pre-symlink retention days</label>
          <input name="symlink_retention_days" type="number" min="1" max="365" value="{ss.get('symlink_retention_days', ss.get('cache_ttl_days','30'))}">
          <div class="hint">Played and lookahead-created symlinks stay in Plex for this many days before normal TTL expiry restores the placeholder. Default 30.</div>
        </div>
      </div>

      <div class="s-sect">
        <div class="s-title">Library</div>
        {toggle("Include unreleased episodes","include_unreleased_episodes","Create placeholders for episodes not yet aired")}
        {toggle("Include unreleased movies","include_unreleased_movies","Add movies to library before their release date")}
      </div>

      <div class="s-sect">
        <div class="s-title">🤖 Overseerr Automation</div>
        {toggle("Auto-add approved requests","auto_add_requests","Automatically add Overseerr approved requests to Debridarr library")}
        <div class="field" style="max-width:220px">
          <label>Check interval (minutes)</label>
          <input name="auto_add_interval_minutes" type="number" min="5" max="1440"
                 value="{ss.get('auto_add_interval_minutes','60')}">
          <div class="hint">How often to poll Overseerr for new requests</div>
        </div>
        <div style="display:flex;gap:10px;align-items:center;margin-top:4px">
          <button type="button" class="btn btn-sec" onclick="runAutoAdd()" style="padding:6px 14px">▶ Run Now</button>
          <div id="auto-add-result" class="test-result" style="margin-top:0;flex:1"></div>
        </div>
      </div>

      <div class="s-sect">
        <div class="s-title">📡 Tautulli Webhook</div>
        <p style="font-size:0.82rem;color:#888;margin-bottom:12px">Triggers a search when you press play (required when pre-caching is off).</p>
        <div class="field">
          <label>1. Tautulli → Settings → Notification Agents → Add → Webhook — set URL to:</label>
          <div style="display:flex;gap:8px;align-items:center;margin-top:6px">
            <input id="twh-url" readonly value="{tautulli_url}"
                   style="flex:1;font-family:monospace;font-size:0.8rem;background:#0f0f13;border:1px solid #2a2a3a;border-radius:6px;padding:8px 10px;color:#e0e0e0">
            <button type="button" class="btn btn-sec" style="padding:6px 14px;white-space:nowrap"
                    onclick="navigator.clipboard.writeText(document.getElementById('twh-url').value);toast('✅ Copied')">Copy</button>
          </div>
        </div>
        <div class="field" style="margin-top:10px">
          <label>2. Set Method = POST, paste this as the JSON body under Triggers → Play:</label>
          <pre id="twh-json" style="background:#0f0f13;border:1px solid #2a2a3a;border-radius:6px;padding:10px;font-size:0.74rem;color:#a0a0b0;margin-top:6px;white-space:pre-wrap;word-break:break-all">{tautulli_json}</pre>
          <button type="button" class="btn btn-sec" style="padding:6px 14px;margin-top:6px"
                  onclick="navigator.clipboard.writeText(document.getElementById('twh-json').innerText);toast('✅ Copied')">Copy JSON</button>
        </div>
        <div style="display:flex;gap:8px;margin-top:10px">
          <button type="button" class="btn btn-sec" style="padding:6px 14px" onclick="testWebhook()">Test Webhook</button>
          <div id="webhook-result" class="test-result" style="margin-top:0;flex:1"></div>
        </div>
      </div>

      <div class="s-sect">
        <div class="s-title">🔍 Torrent Search</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px">
          {select("Completed Series Strategy","series_completed_strategy",[("series_pack","Series Pack (whole show)"),("season_pack","Season Pack"),("episode","Per Episode")])}
          {select("Ongoing Series Strategy","series_ongoing_strategy",[("season_pack","Season Pack"),("episode","Per Episode"),("series_pack","Series Pack")])}
          {select("Series Quality","series_preferred_quality",[("1080p","1080p"),("720p","720p"),("any","Any")])}
          {select("Series Fallback Quality","series_fallback_any_quality",[("true","Yes — any quality"),("false","No")])}
          {select("Movie Quality","movie_preferred_quality",[("1080p","1080p"),("720p","720p"),("any","Any")])}
          {select("Movie Fallback Quality","movie_fallback_any_quality",[("true","Yes — any quality"),("false","No")])}
          <div class="field"><label>Pre-cache Cooldown (min)</label>
            <input name="precache_cooldown_minutes" type="number" min="0" max="60"
                   value="{ss.get('precache_cooldown_minutes','1')}"></div>
          <div class="field"><label>Cache TTL (days)</label>
            <input name="cache_ttl_days" type="number" min="1" max="90"
                   value="{ss.get('cache_ttl_days','30')}"></div>
          <div class="field"><label>Hash Index TTL (months)</label>
            <input name="hash_index_ttl_months" type="number" min="1" max="120"
                   value="{ss.get('hash_index_ttl_months','6')}">
            <div class="hint">Remove hash entries not used for playback in this many months. Runs daily.</div>
          </div>
          <div class="field"><label>Verify symlinks every (minutes)</label>
            <input name="verify_symlinks_interval_minutes" type="number" min="0" max="1440"
                   value="{ss.get('verify_symlinks_interval_minutes','15')}">
            <div class="hint">Background loop scans cached symlinks after FUSE is ready, repairs broken targets, and keeps Plex paths stable. It does not delete symlinks on startup. 0 disables the loop.</div>
          </div>
          {select("Title Variant Mode","search_variant_mode",[("balanced","Balanced"),("aggressive","Aggressive")],"Aggressive tries more title variants like ampersand/and, apostrophes, region aliases, and simplified titles. Strict matching still blocks wrong titles.")}
          {select("Try episode first","search_try_episode_first",[("false","No — packs first"),("true","Yes — episode first")],"Packs first is usually faster for old shows like Friends/The Simpsons. Episode first can be better for new shows.")}
          {select("Season pack fallback","search_try_season_packs",[("true","Enabled"),("false","Disabled")],"Try Sxx / Season xx packs when exact episodes are not found.")}
          {select("Series pack fallback","search_try_series_packs",[("true","Enabled"),("false","Disabled")],"Try complete series packs for older completed shows.")}
          {select("Wide episode fallback","search_episode_fallback_without_title",[("true","Enabled"),("false","Disabled")],"Last resort: search SxxEyy broadly, then strict-title-filter candidates.")}
          <div class="field"><label>Search result limit</label>
            <input name="search_result_limit" type="number" min="20" max="200" value="{ss.get('search_result_limit','80')}">
            <div class="hint">Higher helps shows with many releases. Cached results are still preferred.</div>
          </div>
          <div class="field"><label>Max queries per item</label>
            <input name="search_max_queries_per_item" type="number" min="6" max="60" value="{ss.get('search_max_queries_per_item','24')}">
            <div class="hint">Limits title variants so search does not hammer indexers.</div>
          </div>
        </div>
        {toggle("Pre-cache on add","precache_enabled","Search TPB and probe AllDebrid for cached hashes when media is added to the library. Hashes are stored locally — no AllDebrid account changes until you press play. When off, the hash index is only populated as you play things (first play of each item will always do a live search).")}

        <div style="margin-top:16px;padding-top:14px;border-top:1px solid #1e1e2e">
          <div style="font-size:0.8rem;color:#888;font-weight:600;margin-bottom:10px">Hash Index</div>
          <div id="hi-stats" style="font-size:0.78rem;color:#555;margin-bottom:10px">Loading…</div>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <button type="button" class="btn btn-sec" style="padding:6px 14px;font-size:0.82rem"
                    onclick="reindexHashes()">🔄 Re-index All</button>
            <button type="button" class="btn btn-sec" style="padding:6px 14px;font-size:0.82rem"
                    onclick="verifySymlinks()" title="Scan cached entries and repair any missing symlinks on the fly">🔧 Verify Symlinks</button>
            <button type="button" class="btn btn-sec" style="padding:6px 14px;font-size:0.82rem"
                    onclick="purgeHashes()">🧹 Purge Unused</button>
            <button type="button" class="btn btn-rem" style="padding:6px 14px;font-size:0.82rem"
                    onclick="clearHashes()">🗑️ Clear Index</button>
            <button type="button" class="btn btn-rem" style="padding:6px 14px;font-size:0.82rem"
                    onclick="clearMovieHashes()">🎬 Clear Movie Indexes</button>
            <button type="button" class="btn btn-rem" style="padding:6px 14px;font-size:0.82rem"
                    onclick="clearTvHashes()">📺 Clear TV Indexes</button>
            <button type="button" class="btn btn-rem" style="padding:6px 14px;font-size:0.82rem"
                    onclick="clearMoviePlaceholders()">🎬 Clear Movie Placeholders</button>
            <button type="button" class="btn btn-rem" style="padding:6px 14px;font-size:0.82rem"
                    onclick="clearTvPlaceholders()">📺 Clear TV Placeholders</button>
            <a href="/hash-indexer?tab=logs" class="btn btn-sec"
               style="padding:6px 14px;font-size:0.82rem;text-decoration:none">📋 Open Hash Index Logs Tab</a>
          </div>
          <div id="hi-result" class="test-result" style="margin-top:10px"></div>
        </div>
      </div>

      <div class="s-sect">
        <div class="s-title">System</div>
        {field("TZ","TZ","Timezone e.g. America/New_York")}
        {field("PUID","PUID","User ID for file permissions")}
        {field("PGID","PGID","Group ID for file permissions")}
      </div>

      <div style="display:flex;gap:12px;align-items:center;margin-top:8px">
        <button type="submit" class="btn btn-add" style="padding:10px 28px;font-size:0.9rem">💾 Save All Settings</button>
        <div id="save-result" class="test-result" style="margin-top:0;flex:1"></div>
      </div>

      </form>
    </div>"""

    extra = f"""<style>
.s-sect {{ background:#1a1a24;border:1px solid #2a2a3a;border-radius:10px;padding:20px 24px;margin-bottom:16px; }}
.s-title {{ font-size:0.75rem;font-weight:700;text-transform:uppercase;color:#f97316;letter-spacing:.08em;margin-bottom:16px; }}
.field {{ margin-bottom:14px; }}
.field label {{ display:block;font-size:0.8rem;color:#888;margin-bottom:5px;font-weight:600; }}
.field input,.field select {{ width:100%;background:#0f0f13;border:1px solid #2a2a3a;border-radius:7px;
  padding:9px 13px;color:#e0e0e0;font-size:0.875rem;outline:none;font-family:monospace; }}
.field input:focus,.field select:focus {{ border-color:#f97316; }}
.field select {{ cursor:pointer;font-family:inherit; }}
.field .hint {{ font-size:0.74rem;color:#555;margin-top:4px;line-height:1.4; }}
.field .hint a {{ color:#f97316; }}
.saved-badge {{ display:inline-block;margin-left:8px;font-size:0.68rem;font-weight:700;
  background:#14532d;color:#4ade80;border-radius:4px;padding:1px 6px;text-transform:uppercase; }}
.test-result {{ margin-top:10px;padding:8px 12px;border-radius:6px;font-size:0.82rem;display:none; }}
.test-result.ok {{ background:#14532d;color:#4ade80;display:block; }}
.test-result.err {{ background:#3b0000;color:#f87171;display:block; }}
.test-result.testing {{ background:#1e1e2e;color:#aaa;display:block; }}
.toggle {{ position:relative;display:inline-block;width:44px;height:24px;flex-shrink:0; }}
.toggle input {{ position:absolute;opacity:0;width:100%;height:100%;margin:0;cursor:pointer;z-index:1; }}
.slider {{ position:absolute;inset:0;background:#2a2a3a;border-radius:24px;transition:.2s;pointer-events:none; }}
.slider:before {{ position:absolute;content:"";height:18px;width:18px;left:3px;bottom:3px;
  background:#555;border-radius:50%;transition:.2s; }}
.toggle input:checked ~ .slider {{ background:#f97316; }}
.toggle input:checked ~ .slider:before {{ transform:translateX(20px);background:#fff; }}
pre {{ font-family:monospace;overflow-x:auto; }}
</style>
<script>
function getFieldVal(id) {{
  const e=document.getElementById(id);
  if(!e) return null;
  const v=e.value.trim();
  if(!v || e.dataset.saved) return null;
  return v;
}}
async function testConn(type) {{
  const urlEl=document.getElementById('OVERSEERR_URL');
  const keyEl=document.getElementById('OVERSEERR_API_KEY');
  const adEl =document.getElementById('ALLDEBRID_API_KEY');
  const plEl =document.getElementById('PLEX_ROOT');
  const params=new URLSearchParams({{
    type,
    overseerr_url:  urlEl?.value||'',
    overseerr_key:  keyEl?.value||'',
    alldebrid_key:  adEl?.value||'',
    plex_root:      plEl?.value||'',
  }});
  const el=document.getElementById('test-'+type);
  if(el){{ el.className='test-result testing'; el.style.display='block'; el.textContent='Testing...'; }}
  const r=await fetch('/api/test-connection?'+params);
  const d=await r.json();
  if(el){{ el.className='test-result '+(d.ok?'ok':'err'); el.textContent=(d.ok?'✅ ':'❌ ')+d.message; }}
}}
async function testAll() {{ await Promise.all(['alldebrid','overseerr','plex'].map(testConn)); }}
async function testProwlarr() {{
  const res = document.getElementById('prowlarr-result');
  res.className = 'test-result testing'; res.style.display = 'block'; res.textContent = 'Testing...';
  try {{
    const r = await fetch('/api/test-prowlarr');
    const d = await r.json();
    res.className = 'test-result ' + (d.ok ? 'ok' : 'err');
    if (d.ok) {{
      res.textContent = '✅ ' + d.message + ' — Torznab URL: ' + d.torznab_url;
    }} else {{
      res.textContent = '❌ ' + d.message;
    }}
  }} catch(e) {{
    res.className = 'test-result err';
    res.textContent = '❌ Could not reach Prowlarr';
  }}
}}
async function testWebhook() {{
  const res=document.getElementById('webhook-result');
  res.className='test-result testing'; res.style.display='block'; res.textContent='Testing...';
  try {{
    const r=await fetch('/webhook/test');
    const d=await r.json();
    res.className='test-result '+(r.ok?'ok':'err');
    res.textContent=r.ok?'✅ Reachable — configure Tautulli to POST to this URL':'❌ '+(d.detail||'Unreachable');
  }} catch(e) {{ res.className='test-result err'; res.textContent='❌ Could not reach endpoint'; }}
}}
async function runAutoAdd() {{
  const res=document.getElementById('auto-add-result');
  res.className='test-result testing'; res.style.display='block'; res.textContent='Running...';
  const r=await fetch('/api/auto-add/run',{{method:'POST'}});
  const d=await r.json();
  res.className='test-result '+(r.ok?'ok':'err');
  res.textContent=r.ok?'✅ '+d.message:'❌ '+(d.detail||'Failed');
}}

// ── Hash index controls ─────────────────────────────────────────────────────
async function loadHiStats() {{
  try {{
    const r = await fetch('/api/hash-index/stats');
    const d = await r.json();
    const s = d.stats || {{}};
    document.getElementById('hi-stats').textContent =
      `${{s.total||0}} entries (${{s.cached||0}} cached · ${{s.movies||0}} movies · ${{s.seasons||0}} season packs · ${{s.episodes||0}} episodes)`;
  }} catch(e) {{
    document.getElementById('hi-stats').textContent = '(stats unavailable)';
  }}
}}

async function _hiJsonAction(url, method, payload, confirmMsg, successFn) {{
  const res = document.getElementById('hi-result');
  if (confirmMsg && !confirm(confirmMsg)) return;
  res.className = 'test-result testing'; res.style.display = 'block'; res.textContent = 'Working…';
  try {{
    const r = await fetch(url, {{method, headers: {{'Content-Type':'application/json'}}, body: JSON.stringify(payload || {{}})}});
    const d = await r.json();
    if (r.ok) {{
      res.className = 'test-result ok';
      res.textContent = successFn ? successFn(d) : (d.message || '✅ Done');
      await loadHiStats();
    }} else {{
      res.className = 'test-result err';
      res.textContent = '❌ ' + (d.detail || d.message || 'Error');
    }}
  }} catch(e) {{
    res.className = 'test-result err';
    res.textContent = '❌ ' + e;
  }}
}}

async function _hiAction(url, method, confirmMsg, successFn) {{
  const res = document.getElementById('hi-result');
  if (confirmMsg && !confirm(confirmMsg)) return;
  res.className = 'test-result testing'; res.style.display = 'block'; res.textContent = 'Working…';
  try {{
    const r = await fetch(url, {{method}});
    const d = await r.json();
    if (r.ok) {{
      res.className = 'test-result ok';
      res.textContent = successFn(d);
      await loadHiStats();
    }} else {{
      res.className = 'test-result err';
      res.textContent = '❌ ' + (d.detail || 'Error');
    }}
  }} catch(e) {{
    res.className = 'test-result err';
    res.textContent = '❌ ' + e;
  }}
}}

function reindexHashes() {{
  _hiJsonAction('/api/hash-index/reindex', 'POST', {{category:'all'}}, null,
    d => '✅ Full re-index started — check the Hash Index Logs tab for progress');
}}

function purgeHashes() {{
  const months = document.querySelector('input[name="hash_index_ttl_months"]')?.value || 6;
  _hiAction(`/api/hash-index/purge?months=${{months}}`, 'POST', null,
    d => `✅ Purged ${{d.deleted}} unused entr${{d.deleted===1?'y':'ies'}} (${{d.remaining}} remaining)`);
}}

function clearHashes() {{
  _hiAction('/api/hash-index/clear', 'POST',
    'Clear the entire hash index? It rebuilds automatically as you play media or via Re-index.',
    d => `✅ Cleared — ${{d.deleted}} entr${{d.deleted===1?'y':'ies'}} removed`);
}}

function clearMovieHashes() {{
  _hiAction('/api/hash-index/clear/media/movie', 'POST',
    'Clear ONLY movie hash-index entries? TV index entries are kept.',
    d => `✅ Cleared movie indexes — ${{d.deleted}} entr${{d.deleted===1?'y':'ies'}} removed`);
}}

function clearTvHashes() {{
  _hiAction('/api/hash-index/clear/media/tv', 'POST',
    'Clear ONLY TV hash-index entries? Movie index entries are kept.',
    d => `✅ Cleared TV indexes — ${{d.deleted}} entr${{d.deleted===1?'y':'ies'}} removed`);
}}

function clearMoviePlaceholders() {{
  _hiAction('/api/placeholders/clear/movie', 'POST',
    'Delete movie placeholder files from Plex? Real symlinks are kept.',
    d => `✅ Cleared movie placeholders — removed ${{d.deleted_files}} file${{d.deleted_files===1?'':'s'}} and ${{d.deleted_dirs}} folder${{d.deleted_dirs===1?'':'s'}}`);
}}

function clearTvPlaceholders() {{
  _hiAction('/api/placeholders/clear/tv', 'POST',
    'Delete TV placeholder files from Plex? Real symlinks are kept.',
    d => `✅ Cleared TV placeholders — removed ${{d.deleted_files}} file${{d.deleted_files===1?'':'s'}} and ${{d.deleted_dirs}} folder${{d.deleted_dirs===1?'':'s'}}`);
}}

function verifySymlinks() {{
  _hiAction('/api/cache/verify-symlinks', 'POST', null,
    d => `✅ Symlink scan — checked ${{d.checked}}, valid ${{d.valid}}, repairing ${{d.queued_repair}}`
        + (d.skipped ? ` (${{d.skipped}} skipped)` : ''));
}}

loadHiStats();
</script>"""
    return _page("Settings", "settings", body, extra)


@app.post("/settings/save")
async def settings_save(request: Request, background_tasks: BackgroundTasks):
    """
    Single unified settings save. Everything goes to app_settings in SQLite.
    No .env involvement — DB is the single source of truth for all settings.
    After saving, 303 redirect forces a fresh page render from the DB.
    """
    form = await request.form()
    db: CacheDB = request.app.state.db

    # Migrate legacy TMDB_API_KEY (uppercase) form value to tmdb_api_key.
    # The field was previously named with the uppercase API_KEY convention
    # used by other connection settings — but it wasn't in the save loop's
    # text_keys (which used lowercase), so the value was silently dropped.
    # This makes either case work going forward.
    legacy_tmdb = (form.get("TMDB_API_KEY") or "").strip()
    if legacy_tmdb and not (form.get("tmdb_api_key") or "").strip():
        db.set_setting("tmdb_api_key", legacy_tmdb)

    # ── All text/number/select fields ────────────────────────────────────────
    text_keys = {
        # Search settings
        "series_completed_strategy", "series_ongoing_strategy",
        "series_preferred_quality", "series_fallback_any_quality",
        "movie_preferred_quality", "movie_fallback_any_quality",
        "search_variant_mode", "search_try_episode_first", "search_try_season_packs",
        "search_try_series_packs", "search_episode_fallback_without_title",
        "search_result_limit", "search_max_queries_per_item",
        "cache_ttl_days", "precache_cooldown_minutes", "hash_index_ttl_months",
        "auto_add_interval_minutes", "tmdb_api_key",
        "verify_symlinks_interval_minutes", "symlink_retention_days",
        # Connection settings
        "ALLDEBRID_API_KEY", "OVERSEERR_URL", "OVERSEERR_API_KEY",
        "PROWLARR_URL", "PROWLARR_API_KEY",
        "PROWLARR_MIN_SECONDS_BETWEEN_SEARCHES", "PROWLARR_SEARCH_LIMIT",
        "PROWLARR_RATE_LIMIT_COOLDOWN_SECONDS", "PROWLARR_UNAVAILABLE_COOLDOWN_SECONDS",
        "SONARR_URL", "SONARR_API_KEY", "RADARR_URL", "RADARR_API_KEY",
        "DEBRIDARR_BASE_URL", "PLEX_ROOT", "PLEX_URL", "PLEX_TOKEN",
        "PLEX_MOVIE_SECTION_ID", "PLEX_TV_SECTION_ID", "TZ", "PUID", "PGID",
    }
    for key in text_keys:
        val = form.get(key, "").strip()
        if val:  # only overwrite if a value was actually submitted
            db.set_setting(key, val)

    # ── Checkboxes (absent from form = false) ────────────────────────────────
    for key in ("precache_enabled", "auto_add_requests", "include_unreleased_episodes", "include_unreleased_movies", "instant_plex_refresh", "on_play_symlinks_only"):
        db.set_setting(key, "true" if form.get(key) else "false")

    # ── Side effects ─────────────────────────────────────────────────────────
    if request.app.state.library:
        tmdb = db.get_setting("tmdb_api_key", "")
        request.app.state.library.tmdb_key = tmdb
        request.app.state.library.invalidate_cache()

    include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"
    background_tasks.add_task(_sync_all_series_episodes, request.app, include_unreleased)

    # Re-init clients so new API keys / URLs take effect immediately
    _init_clients(request.app)

    from fastapi.responses import RedirectResponse
    return RedirectResponse(url="/settings?saved=Settings+saved", status_code=303)


# ── Legacy JSON API endpoints (kept for backwards compat) ────────────────────












@app.get("/api/settings/dfs")
async def api_settings_dfs_get():
    return get_dfs_settings()


@app.post("/api/settings/dfs")
async def api_settings_dfs_save(request: Request):
    body = await request.json()
    allowed = {"cache_dir","disk_cache_size_gb","cache_expiry_h","chunk_size_mb","read_ahead_mb","cleanup_interval_m"}
    cfg = {k: v for k, v in body.items() if k in allowed}
    for k in ("disk_cache_size_gb","cache_expiry_h","chunk_size_mb","read_ahead_mb","cleanup_interval_m"):
        if k in cfg:
            try: cfg[k] = int(cfg[k])
            except Exception: pass
    update_dfs_settings(cfg)
    db: CacheDB = request.app.state.db
    import json
    db.set_setting("dfs_settings", json.dumps(cfg))
    return {"status": "ok", "settings": get_dfs_settings()}



@app.post("/api/auto-add/run")
async def api_auto_add_run(request: Request, background_tasks: BackgroundTasks):
    """Manually trigger an auto-add pass."""
    db: CacheDB = request.app.state.db
    if not getattr(request.app.state, "setup_complete", False):
        raise HTTPException(400, "Setup not complete")
    background_tasks.add_task(_run_auto_add, request.app)
    return {"status": "ok", "message": "Auto-add pass triggered — check logs for details"}


@app.post("/api/episodes/sync")
async def api_episodes_sync(request: Request, background_tasks: BackgroundTasks):
    """Manually trigger a new-episode sync for all tracked series."""
    background_tasks.add_task(_sync_new_episodes, request.app)
    return {"status": "ok", "message": "Episode sync triggered — check logs for details"}


@app.post("/api/library/cleanup")
async def api_library_cleanup(request: Request):
    """
    Remove anything in plex-strm that has no matching entry in the library DB.

    Checks:
      - plex-strm/movies/<folder>  → delete if title/year not in fake_library
      - plex-strm/tv/<folder>      → delete if title not in fake_library
      - Individual episode files   → delete if SxxExx not in any tracked season for that show

    Returns counts of what was removed.
    """
    db: CacheDB        = app.state.db
    lm: LibraryManager = app.state.library
    s                  = app.state.settings

    plex_root = s.PLEX_ROOT or lm.plex_root if lm else ""
    if not plex_root:
        raise HTTPException(400, "PLEX_ROOT not configured")

    plex = Path(plex_root)
    removed_movies  = []
    removed_series  = []
    removed_files   = []

    # Build lookup sets from DB
    tracked_movies: set[str] = set()   # "Title (Year)" or "Title"
    for entry in db.fake_library_list(media_type="movie"):
        yp = f" ({entry['year']})" if entry.get("year") else ""
        tracked_movies.add(f"{entry['title']}{yp}".lower())

    tracked_series: set[str] = set()   # title (lowered)
    for entry in db.fake_library_list(media_type="series"):
        tracked_series.add(entry["title"].lower())

    # Build set of (title_lower, season, episode) for all tracked cache entries
    tracked_episodes: set[tuple[str, int, int]] = set()
    for entry in db.list_all():
        if entry["media_type"] == "episode" and entry.get("season") and entry.get("episode"):
            tracked_episodes.add((entry["title"].lower(), entry["season"], entry["episode"]))

    # ── Movies ────────────────────────────────────────────────────────────────
    movies_dir = plex / "movies"
    if movies_dir.exists():
        for folder in movies_dir.iterdir():
            if not folder.is_dir():
                continue
            if folder.name.lower() not in tracked_movies:
                import shutil as _shutil
                _shutil.rmtree(folder, ignore_errors=True)
                removed_movies.append(folder.name)
                log.info(f"🧹 Cleanup: removed untracked movie folder: {folder.name}")

    # ── TV series ─────────────────────────────────────────────────────────────
    tv_dir = plex / "tv"
    if tv_dir.exists():
        for show_folder in tv_dir.iterdir():
            if not show_folder.is_dir():
                continue
            title_lower = show_folder.name.lower()

            if title_lower not in tracked_series:
                # Whole series not in library — remove entirely
                import shutil as _shutil
                _shutil.rmtree(show_folder, ignore_errors=True)
                removed_series.append(show_folder.name)
                log.info(f"🧹 Cleanup: removed untracked series folder: {show_folder.name}")
                continue

            # Series is tracked — check individual episode files
            import re as _re
            for season_dir in show_folder.iterdir():
                if not season_dir.is_dir():
                    continue
                for ep_file in season_dir.iterdir():
                    m = _re.search(r"[Ss](\d{1,2})[Ee](\d{1,2})", ep_file.name)
                    if not m:
                        continue
                    sn  = int(m.group(1))
                    epn = int(m.group(2))
                    key = (title_lower, sn, epn)
                    if key not in tracked_episodes:
                        ep_file.unlink(missing_ok=True)
                        removed_files.append(f"{show_folder.name}/Season {sn:02d}/{ep_file.name}")
                        log.info(f"🧹 Cleanup: removed untracked episode file: {ep_file.name}")
                # Remove empty season dirs
                try:
                    if not any(season_dir.iterdir()):
                        season_dir.rmdir()
                except Exception:
                    pass

    total = len(removed_movies) + len(removed_series) + len(removed_files)
    log.info(f"🧹 Cleanup complete: {len(removed_movies)} movies, {len(removed_series)} series, {len(removed_files)} episode files removed")
    return {
        "ok": True,
        "removed_movies":       removed_movies,
        "removed_series":       removed_series,
        "removed_episode_files": removed_files,
        "total_removed":        total,
    }


async def _auto_add_loop(app: FastAPI):
    """Background loop — polls Overseerr and auto-adds approved requests if enabled.
    Also syncs new episodes for all tracked ongoing series on the same schedule."""
    await asyncio.sleep(60)  # wait for startup to settle
    while True:
        db: CacheDB = app.state.db
        try:
            # Always sync new episodes for tracked series, regardless of auto_add setting
            await _sync_new_episodes(app)
        except Exception as e:
            log.error(f"Episode sync loop: {e}")

        if db.get_setting("auto_add_requests", "false") == "true":
            try:
                await _run_auto_add(app)
            except Exception as e:
                log.error(f"Auto-add loop: {e}")

        interval = int(db.get_setting("auto_add_interval_minutes", "60"))
        await asyncio.sleep(max(5, interval) * 60)


async def _sync_new_episodes(app: FastAPI):
    """
    Check every tracked series in the library for newly-aired episodes.

    For each episode that has aired but has no placeholder yet:
      1. Search AllDebrid for a cached torrent
      2. Only create a placeholder + trigger resolve if a torrent is actually available
      3. Episodes with no cached torrent are skipped silently — checked again next interval

    This means placeholders only appear in Plex when there is something to stream.
    """
    db: CacheDB         = app.state.db
    lm: LibraryManager  = app.state.library
    alldebrid           = app.state.alldebrid
    if not lm or not lm.plex_root or not alldebrid:
        return

    include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"
    s_cfg              = db.get_all_settings()
    preferred_quality  = s_cfg.get("series_preferred_quality", "1080p")
    fallback_any       = s_cfg.get("series_fallback_any_quality", "true") == "true"

    series_list = db.fake_library_list(media_type="series")
    if not series_list:
        return

    log.debug(f"\U0001f4c5 Episode sync: checking {len(series_list)} series for new episodes")
    total_new = 0

    for entry in series_list:
        title    = entry["title"]
        sid      = entry.get("sonarr_id")
        year     = entry.get("year")
        is_ended = (entry.get("status", "continuing") in ("ended", "cancelled", "canceled"))
        strategy = s_cfg.get("series_completed_strategy", "series_pack") if is_ended \
                   else s_cfg.get("series_ongoing_strategy", "season_pack")
        if not sid:
            continue

        try:
            # Invalidate episode cache so air_date data is fresh
            from app.library import _cache as _lib_cache
            for k in [k for k in list(_lib_cache) if f"episodes::{sid}" in k]:
                del _lib_cache[k]

            # Get the canonical released-episode list from TMDB. Falls back to
            # Sonarr/Overseerr if TMDB returns nothing (e.g. no API key set,
            # show not on TMDB). The hash-index and Seasons tab already use
            # TMDB as the source of truth — placeholders need to match.
            from app.models import PlayEvent, MediaType
            episodes: list[dict] = []
            try:
                tmdb_eps = await _get_series_episodes_via_tmdb(
                    app, title, year=year, include_unreleased=include_unreleased,
                )
                if tmdb_eps:
                    from datetime import date as _date_sync
                    _today_sync = _date_sync.today().isoformat()
                    episodes = [
                        {"season": e["season"], "episode": e["episode"],
                         "air_date": e.get("air_date", "")}
                        for e in tmdb_eps
                        if (e.get("season") or 0) > 0
                        and (e.get("episode") or 0) > 0
                        and e.get("air_date")
                        and e.get("air_date") <= _today_sync
                    ]
            except Exception as e:
                log.debug(f"_sync TMDB episodes for {title!r}: {e}")
            if not episodes:
                from datetime import date as _date_sync2
                _today_sync2 = _date_sync2.today().isoformat()
                episodes = [
                    ep for ep in await lm.get_episodes(sid, include_unreleased=False)
                    if ep.get("air_date") and ep.get("air_date") <= _today_sync2
                ]
            if not episodes:
                continue

            # tmdb_seasons is the authoritative set — used to drop any
            # episodes whose season TMDB doesn't list (handles stale Sonarr
            # entries for un-announced future seasons).
            tmdb_seasons_sync: set[int] = {
                ep["season"] for ep in episodes if (ep.get("season") or 0) > 0
            }

            # Ghost cleanup — remove on-disk files for slots TMDB no longer
            # recognises (e.g. removed seasons or migrated specials).
            try:
                ghosts = _remove_ghost_episode_files(
                    lm.plex_root, title, episodes, db, log,
                )
                if ghosts:
                    log.info(
                        f"🧹 {title!r}: removed {ghosts} ghost placeholder(s) "
                        f"(sync loop)"
                    )
            except Exception as e:
                log.debug(f"sync ghost cleanup {title!r}: {e}")

            # Find which SxxExx already exist in plex-strm (placeholder or symlink)
            show_dir = Path(lm.plex_root) / "tv" / title
            existing: set[tuple[int, int]] = set()
            if show_dir.exists():
                for sf in show_dir.iterdir():
                    if not sf.is_dir():
                        continue
                    for f in sf.iterdir():
                        import re as _re
                        m = _re.search(r"[Ss](\d{1,2})[Ee](\d{1,2})", f.name)
                        if m:
                            existing.add((int(m.group(1)), int(m.group(2))))

            # Episodes that exist per TMDB but have no file yet on disk.
            new_eps = [ep for ep in episodes if (ep["season"], ep["episode"]) not in existing]

            # ── Placeholders ONLY for episodes covered by cached hashes ──────
            # The hash-index pass below probes AllDebrid for season packs and
            # individual episode hashes. After that pass we know which (s, e)
            # pairs are backed by a cached hash. Placeholders get created for
            # those — and only those — so Plex never shows a slot that points
            # to nothing.

            if not new_eps:
                continue

            log.debug(
                f"\U0001f4c5 {title}: {len(new_eps)} aired episode(s) — "
                f"probing AllDebrid for cached packs"
            )

            # Group episodes by season — search once per season, not once per episode
            import re as _re_sync
            from collections import defaultdict as _dd
            _sync_hi: HashIndex = getattr(app.state, "hash_index", None)

            seasons_eps: dict[int, list] = _dd(list)
            for ep in new_eps:
                seasons_eps[ep["season"]].append(ep["episode"])

            for sn, ep_nums in sorted(seasons_eps.items()):
                try:
                    # One AllDebrid search per season (not per episode)
                    results = await alldebrid.search_cached(
                        title=title,
                        media_type="episode",
                        year=year,
                        season=sn,
                        episode=ep_nums[0],   # first episode — pack covers the rest
                        strategy=strategy,
                        preferred_quality=preferred_quality,
                        fallback_any=fallback_any,
                    )
                    if not results:
                        log.debug(f"  \u23ed  {title} S{sn:02d} — no cached torrent yet")
                        continue

                    best = results[0]
                    is_pack = not _re_sync.search(r"S\d{2}E\d{2}", best["name"], _re_sync.I)

                    # Verify the returned torrent matches the season we asked for.
                    # AllDebrid can return wrong-season results (e.g. S08 for S02 query).
                    # For season packs, check the torrent name contains the right season.
                    # For individual episodes, check season number matches.
                    returned_sn_m = _re_sync.search(r"S(\d{2})", best["name"], _re_sync.I)
                    if returned_sn_m:
                        returned_sn = int(returned_sn_m.group(1))
                        if returned_sn != sn:
                            log.debug(f"  ⏭  {title} S{sn:02d} — wrong season result (got S{returned_sn:02d}), skipping")
                            continue

                    log.info(f"  \u2705 {title} S{sn:02d} — {'season pack' if is_pack else 'episode'}: {best['name'][:50]}")

                    # Write to hash index (pack covers season, episode covers single ep)
                    upserted = False
                    if _sync_hi:
                        _hm = _re_sync.search(r"btih:([a-fA-F0-9]{40})", best.get("magnet",""), _re_sync.I)
                        if _hm:
                            try:
                                _sync_hi.upsert(
                                    media_type="season" if is_pack else "episode",
                                    title=title, year=year,
                                    season=sn, episode=None if is_pack else ep_nums[0],
                                    info_hash=_hm.group(1).lower(),
                                    magnet=best["magnet"],
                                    torrent_name=best["name"],
                                    quality=best.get("quality", "unknown"),
                                    strategy=strategy,
                                    is_cached=True,
                                )
                                upserted = True
                            except Exception:
                                pass

                    # Placeholders for the episodes the hash actually covers.
                    # Pack: every ep in this season's TMDB list.
                    # Single: just the requested episode number.
                    if upserted:
                        _air_by_ep = {int(ep["episode"]): ep.get("air_date", "") for ep in new_eps if int(ep.get("season") or 0) == int(sn)}
                        covered_eps = (
                            [{"season": sn, "episode": e, "air_date": _air_by_ep.get(int(e), "")} for e in ep_nums]
                            if is_pack
                            else [{"season": sn, "episode": ep_nums[0], "air_date": _air_by_ep.get(int(ep_nums[0]), "")}]
                        )
                        covered_eps = [
                            ep for ep in covered_eps
                            if _placeholder_allowed(app, "episode", title, year, ep["season"], ep["episode"], ep.get("air_date"))
                        ]
                        if not covered_eps:
                            log.info(f"  ⏭️  {title!r} S{sn:02d}: cached hash found but no released covered episodes — no placeholders")
                            continue
                        for ep in covered_eps:
                            try:
                                ev = PlayEvent(
                                    media_type=MediaType.episode, title=title, year=year,
                                    season=ep["season"], episode=ep["episode"],
                                )
                                if not db.get(ev.cache_key()):
                                    db.upsert(ev.cache_key(), ev, status="not_found")
                                    total_new += 1
                            except Exception:
                                pass
                        if lm.plex_root:
                            paths = lm.create_fake_episodes(title, year, [], covered_eps)
                            log.info(
                                f"  📺 {title!r} S{sn:02d}: {len(paths)} placeholder(s) "
                                f"written for {len(covered_eps)} cached episode(s)"
                            )

                    # One small sleep per season (not per episode)
                    await asyncio.sleep(2)

                except Exception as e:
                    log.error(f"  Season search {title} S{sn:02d}: {e}")

        except Exception as e:
            log.error(f"Episode sync '{title}': {e}")

    if total_new:
        log.info(f"\U0001f4c5 Episode sync: added {total_new} new episode(s) with available torrents")
    else:
        log.debug("\U0001f4c5 Episode sync: no new episodes with available torrents")


async def _run_auto_add(app: FastAPI):
    """
    Fetch all approved Overseerr requests and add any not already in the library.
    Mirrors what the user does by clicking "+ Add" on the library page.
    """
    lm: LibraryManager = app.state.library
    db: CacheDB        = app.state.db

    if not lm or not lm.url or not lm.key:
        log.info("Auto-add: Overseerr not configured — skipping")
        return

    added_entries = {
        (r["media_type"], r["title"].lower())
        for r in db.fake_library_list()
    }

    movies = await lm.get_radarr_movies(force=True)
    series = await lm.get_sonarr_series(force=True)
    tmdb_key = db.get_setting("tmdb_api_key", "")
    include_unreleased        = db.get_setting("include_unreleased_episodes", "false") == "true"
    include_unreleased_movies = db.get_setting("include_unreleased_movies",  "false") == "true"
    added_count = 0

    from datetime import date as _date
    today = _date.today().isoformat()

    for movie in movies:
        key = ("movie", movie["title"].lower())
        if key in added_entries:
            continue
        try:
            title    = movie["title"]
            year     = movie.get("year")
            tmdb_id  = movie.get("tmdb_id")
            imdb_id  = movie.get("imdb_id")
            poster   = movie.get("poster", "")
            overview = movie.get("overview", "")

            # Skip unreleased movies unless setting is on.
            # Only skip when release_date is known AND is in the future.
            # If release_date is empty (Overseerr doesn't always return it), allow through.
            release_date = movie.get("release_date", "")
            if not include_unreleased_movies and release_date and release_date > today:
                log.debug(f"⏭️  Auto-add skipping unreleased movie: {title!r} (release_date={release_date!r})")
                continue

            if not poster and tmdb_key and tmdb_id:
                poster = await _fetch_tmdb_poster(tmdb_id, title, True, tmdb_key)

            db.fake_library_add({
                "media_type": "movie",
                "title":      title,
                "year":       year,
                "tmdb_id":    tmdb_id,
                "imdb_id":    imdb_id,
                "poster_url": poster,
                "overview":   overview,
                "status":     "movie",
                "fake_path":  None,
            })
            log.info(f"🤖 Auto-added movie: {title} ({year})")
            added_entries.add(key)
            added_count += 1

            _queue_index(app, _precache_movie, app, title, year, tmdb_id, imdb_id)

        except Exception as e:
            log.error(f"Auto-add movie '{movie.get('title')}': {e}")

    for show in series:
        key = ("series", show["title"].lower())
        if key in added_entries:
            continue
        try:
            title             = show["title"]
            year              = show.get("year") or await _canonical_series_year(app, show["title"], None)
            arr_id            = show.get("id")
            tmdb_id           = show.get("tmdb_id")
            tvdb_id           = show.get("tvdb_id")
            imdb_id           = show.get("imdb_id")
            sc                = show.get("season_count", 0)
            poster            = show.get("poster", "")
            overview          = show.get("overview", "")
            is_ended          = show.get("is_ended", False)
            requested_seasons = show.get("requested_seasons", [])

            # Skip series that haven't aired yet unless setting allows it
            first_air_date = show.get("first_air_date", "")
            if not include_unreleased and first_air_date and first_air_date > today:
                log.debug(f"⏭️  Auto-add skipping unreleased series: {title!r} (first_air_date={first_air_date!r})")
                continue

            if not poster and tmdb_key and tmdb_id:
                poster = await _fetch_tmdb_poster(tmdb_id, title, False, tmdb_key)

            episodes = await lm.get_episodes(
                arr_id,
                include_unreleased=include_unreleased,
                requested_seasons=requested_seasons if requested_seasons else None,
            )
            db.fake_library_add({
                "media_type":   "series",
                "title":        title,
                "year":         year,
                "sonarr_id":    arr_id,
                "tvdb_id":      tvdb_id,
                "tmdb_id":      tmdb_id,
                "imdb_id":      imdb_id,
                "season_count": sc,
                "poster_url":   poster,
                "overview":     overview,
                "status":       "ended" if is_ended else "continuing",
                "fake_path":    None,
            })
            log.info(f"🤖 Auto-added series: {title} ({year}) — indexed, no placeholders")
            added_entries.add(key)
            added_count += 1

            _queue_index(app, _precache_series, app, title, year, episodes)

        except Exception as e:
            log.error(f"Auto-add series '{show.get('title')}': {e}")

    if added_count:
        log.info(f"🤖 Auto-add complete — {added_count} new item(s) added")
    else:
        log.debug("🤖 Auto-add complete — nothing new")


# ── Proxy / webhook / cache ───────────────────────────────────────────────────
@app.get("/webhook/test")
async def webhook_test():
    return {"status": "ok", "message": "Debridarr webhook is reachable"}

@app.get("/proxy/{cache_key}")
async def stream_proxy(cache_key: str, request: Request):
    return await proxy_stream(request, cache_key, request.app.state.db, request.app.state.alldebrid, request.app)

@app.get("/stream/{cache_key}")
async def stream_cached(cache_key: str, request: Request):
    return await stream_direct(request, cache_key, request.app.state.db, request.app.state.alldebrid)

@app.post("/resolve")
async def manual_resolve(request: Request, background_tasks: BackgroundTasks):
    body  = await request.json()
    event = PlayEvent(media_type=MediaType(body["media_type"]), title=body["title"],
                      year=body.get("year"), season=body.get("season"), episode=body.get("episode"))
    background_tasks.add_task(resolve_and_cache, request.app, event)
    s = request.app.state.settings
    return {"status": "resolving", "cache_key": event.cache_key(),
            "proxy_url": f"{s.DEBRIDARR_BASE_URL}/proxy/{event.cache_key()}"}

@app.get("/cache")
async def list_cache(request: Request): return request.app.state.db.list_all()

@app.post("/cache/{cache_key}/expire")
async def expire_cache_entry(cache_key: str, request: Request, background_tasks: BackgroundTasks):
    db        = request.app.state.db
    s         = request.app.state.settings
    alldebrid = request.app.state.alldebrid
    entry     = db.get(cache_key)
    if not entry:
        raise HTTPException(404, "Not found")
    background_tasks.add_task(_hard_expire, entry, db, s, alldebrid)
    return {"status": "ok", "message": "Expiring — symlink deleted, removed from AllDebrid"}


async def _hard_expire(entry: dict, db: "CacheDB", s, alldebrid):
    """
    Full delete for one cache entry:
    1. Delete symlink/placeholder file from plex-strm
    2. Unregister from FUSE
    3. Delete from AllDebrid
    4. Delete from DB cache table
    """
    ck           = entry["cache_key"]
    strm         = entry.get("strm_path")
    torrent_name = entry.get("torrent_name")
    magnet       = entry.get("magnet_link", "")

    # 1. Delete symlink or placeholder file entirely
    if strm:
        p = Path(strm)
        try:
            if p.exists() or p.is_symlink():
                p.unlink(missing_ok=True)
                log.info(f"🗑️  Deleted file: {p}")
        except Exception as e:
            log.debug(f"File delete {p}: {e}")

    # 1b. Do NOT restore placeholders on retention expiry. Stable Plex paths
    # are kept for the retention window, then removed only by expiry/manual
    # cleanup. New placeholders require a cached/covered hash during sync.

    # 2. Unregister from FUSE (only if no other cached entry uses this torrent)
    if torrent_name and FUSE_AVAILABLE:
        others = [e for e in db.list_all()
                  if e.get("torrent_name") == torrent_name
                  and e["cache_key"] != ck
                  and e["status"] == "cached"]
        if not others:
            unregister_torrent(torrent_name)

    # 3. Delete from AllDebrid by hash
    if alldebrid and magnet:
        try:
            import httpx as _hx
            m = re.search(r"btih:([a-fA-F0-9]{40})", magnet, re.I)
            if m:
                info_hash = m.group(1).lower()
                r = await _hx.AsyncClient(timeout=10).get(
                    "https://api.alldebrid.com/v4.1/magnet/status",
                    params={"agent": "debridarr", "apikey": alldebrid.api_key, "status": "ready"},
                )
                if r.status_code == 200:
                    magnets = r.json().get("data", {}).get("magnets", {})
                    if isinstance(magnets, dict):
                        magnets = list(magnets.values())
                    for t in magnets:
                        if (t.get("hash") or "").lower() == info_hash:
                            await alldebrid.delete_magnet(str(t["id"]))
                            log.info(f"🗑️  Deleted from AllDebrid: {t['id']} ({ck})")
                            break
        except Exception as e:
            log.debug(f"AllDebrid delete {ck}: {e}")

    # 4. Delete from DB
    db.delete(ck)
    log.info(f"🗑️  Expired and deleted: {ck}")
    log.info(f"🗑️  Hard expired: {ck}")


@app.delete("/cache/{cache_key}")
async def delete_cache_entry(cache_key: str, request: Request, background_tasks: BackgroundTasks):
    db    = request.app.state.db
    s     = request.app.state.settings
    alldebrid = request.app.state.alldebrid
    entry = db.get(cache_key)
    if not entry:
        raise HTTPException(404, "Not found")
    background_tasks.add_task(_hard_expire, entry, db, s, alldebrid)
    return {"status": "deleted"}

@app.get("/api/hash-index/stats")
async def api_hash_index_stats(request: Request):
    """Return stats and recent entries from the torrent hash index."""
    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    if not hi:
        raise HTTPException(503, "Hash index not initialised")
    stats = hi.stats()
    # Enrich stats with last_used info
    from app.cache import CacheDB as _CDB
    db_path = getattr(request.app.state, "db", None)
    ttl_months = 6
    if db_path:
        ttl_months = int(request.app.state.db.get_setting("hash_index_ttl_months", "6"))
    return {"status": "ok", "stats": stats, "ttl_months": ttl_months}


@app.post("/api/hash-index/reindex")
async def api_hash_index_reindex(request: Request, background_tasks: BackgroundTasks):
    """Re-index library items scoped to the active Hash Index tab/category."""
    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    alldebrid     = request.app.state.alldebrid
    db: CacheDB   = request.app.state.db
    if not hi or not alldebrid:
        raise HTTPException(503, "Hash index not ready")

    try:
        body = await request.json()
        if not isinstance(body, dict):
            body = {}
    except Exception:
        body = {}

    raw_category = str(body.get("category") or body.get("tab") or body.get("scope") or "all").strip().lower()
    aliases = {
        "movie": "movies", "movies": "movies",
        "tv": "tv", "series": "tv", "show": "tv", "shows": "tv",
        "all": "all", "global": "all",
        "missing": "missing", "cached": "cached", "upcoming": "upcoming",
    }
    category = aliases.get(raw_category, raw_category)
    if category not in {"movies", "tv", "all", "missing", "cached", "upcoming"}:
        raise HTTPException(400, "Re-index requires a category: movies, tv, all, missing, cached, or upcoming")

    all_movies = db.fake_library_list(media_type="movie")
    all_series = db.fake_library_list(media_type="series")

    if category == "movies":
        movies, series = all_movies, []
    elif category == "tv":
        movies, series = [], all_series
    elif category == "all":
        movies, series = all_movies, all_series
    else:
        rows = hi.list_titles() if hi else []
        by_key = {(str(r.get("title") or "").lower(), str(r.get("kind") or "")): r for r in rows}

        def _cached_count(item, kind):
            r = by_key.get((str(item.get("title") or "").lower(), kind))
            return int((r or {}).get("cached_count") or 0)

        if category == "cached":
            movies = [m for m in all_movies if _cached_count(m, "movie") > 0]
            series = [s for s in all_series if _cached_count(s, "tv") > 0]
        elif category == "missing":
            movies = [m for m in all_movies if _cached_count(m, "movie") <= 0]
            series = [s for s in all_series if _cached_count(s, "tv") <= 0]
        else:  # upcoming: TV only, if the DB exposes upcoming metadata
            movies = []
            try:
                upcoming_titles = {str(e.get("title") or e.get("series_title") or "").lower() for e in db.get_all_upcoming()}
            except Exception:
                upcoming_titles = set()
            series = [s for s in all_series if str(s.get("title") or "").lower() in upcoming_titles]

    total_items = len(movies) + len(series)

    async def _do_reindex():
        total = len(movies) + len(series)
        log.info(f"🔄 Hash reindex [{category}]: {len(movies)} movies, {len(series)} series ({total} total)")
        done = 0
        for m in movies:
            log.info(f"🔄 Re-indexing movie {done+1}/{total}: {m['title']!r}")
            await _index_movie_hashes(request.app, m["title"], m.get("year"))
            done += 1
            await asyncio.sleep(0.5)
        for s in series:
            log.info(f"🔄 Re-indexing series {done+1}/{total}: {s['title']!r}")
            await _index_series_hashes(request.app, s["title"], s.get("year"))
            done += 1
            await asyncio.sleep(0.5)
        log.info(f"✅ Hash reindex [{category}] complete")

    background_tasks.add_task(_do_reindex)
    return {"status": "started", "category": category, "movies": len(movies), "series": len(series), "total": total_items, "message": f"Re-index started for {category}: {total_items} item(s)"}


@app.post("/api/hash-index/purge")
async def api_hash_index_purge(request: Request, months: int = 6):
    """Manually trigger a purge of hash entries unused for more than `months` months."""
    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    if not hi:
        raise HTTPException(503, "Hash index not initialised")
    months = max(1, min(months, 120))
    result = hi.purge_unused(months=months)
    return {"status": "ok", "months": months, **result}




def _safe_clear_placeholders(plex_root: str, kind: str) -> dict:
    """
    Remove generated placeholder .mp4 files without touching real symlinks.

    Movie placeholders live under <PLEX_ROOT>/movies.
    TV placeholders live under <PLEX_ROOT>/tv.

    Also removes orphan .nfo sidecars and empty folders only when they belong to
    removed placeholders, so folders containing real symlinks are preserved.
    """
    root = Path(plex_root or "").expanduser()
    if not plex_root or not root.exists():
        return {"deleted_files": 0, "deleted_dirs": 0, "root": str(root), "skipped": "plex_root missing"}

    k = (kind or "").lower().strip()
    if k in ("movie", "movies"):
        base = root / "movies"
    elif k in ("tv", "show", "shows", "series"):
        base = root / "tv"
    else:
        raise ValueError("kind must be movie or tv")

    if not base.exists():
        return {"deleted_files": 0, "deleted_dirs": 0, "root": str(base), "skipped": "folder missing"}

    deleted_files = 0
    deleted_dirs = 0

    # Delete placeholder MP4s only. Symlinks are usually .mkv and are never touched.
    removed_mp4_stems: set[Path] = set()
    for mp4 in list(base.rglob("*.mp4")):
        try:
            if mp4.is_symlink():
                continue
            mp4.unlink()
            deleted_files += 1
            removed_mp4_stems.add(mp4.with_suffix(""))
        except Exception as e:
            log.warning(f"Failed to remove placeholder {mp4}: {e}")

    # Delete matching episode/movie sidecar NFO only when the media file was removed
    # and no same-stem real media remains. tvshow.nfo is handled by empty-dir cleanup.
    media_exts = (".mkv", ".mp4", ".avi", ".mov", ".m4v")
    for stem in list(removed_mp4_stems):
        nfo = stem.with_suffix(".nfo")
        try:
            if nfo.exists() and not any(stem.with_suffix(ext).exists() for ext in media_exts):
                nfo.unlink()
                deleted_files += 1
        except Exception as e:
            log.debug(f"Failed to remove orphan sidecar {nfo}: {e}")

    # Clean empty directories bottom-up. This removes placeholder-only folders but
    # leaves anything containing symlinks, posters, or real media.
    for d in sorted([p for p in base.rglob("*") if p.is_dir()], key=lambda p: len(p.parts), reverse=True):
        try:
            if not any(d.iterdir()):
                d.rmdir()
                deleted_dirs += 1
        except Exception:
            pass
    try:
        if base != root and base.exists() and not any(base.iterdir()):
            base.rmdir()
            deleted_dirs += 1
    except Exception:
        pass

    log.info(f"🧹 Cleared {kind} placeholders: files={deleted_files}, dirs={deleted_dirs}, root={base}")
    return {"deleted_files": deleted_files, "deleted_dirs": deleted_dirs, "root": str(base)}


@app.post("/api/hash-index/clear")
async def api_hash_index_clear(request: Request):
    """Clear the entire hash index. Re-populated automatically as media is played or re-indexed."""
    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    if not hi:
        raise HTTPException(503, "Hash index not initialised")
    deleted = hi.clear()
    return {"status": "ok", "deleted": deleted}


@app.post("/api/hash-index/clear/media/{kind}")
async def api_hash_index_clear_media(kind: str, request: Request):
    """Clear only movie or TV hash-index rows."""
    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    if not hi:
        raise HTTPException(503, "Hash index not initialised")
    try:
        deleted = hi.clear_media_type(kind)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"status": "ok", "kind": kind, "deleted": deleted}


@app.post("/api/placeholders/clear/{kind}")
async def api_placeholders_clear(kind: str, request: Request):
    """Clear generated placeholders for movies or TV while keeping real symlinks."""
    plex_root = getattr(request.app.state.settings, "PLEX_ROOT", "") or request.app.state.db.get_setting("PLEX_ROOT", "")
    try:
        result = _safe_clear_placeholders(plex_root, kind)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"status": "ok", "kind": kind, **result}


@app.post("/api/hash-index/delete-entry")
async def api_hash_index_delete_entry(request: Request):
    """
    Remove a single hash-index entry by info_hash. Used by the UI's per-row
    Remove button so users can prune bad season/series packs (misindexed,
    wrong-season, low-quality, etc.) without wiping the whole title.
    The hash can be re-added later via Re-index or a future play event.
    """
    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    if not hi:
        raise HTTPException(503, "Hash index not initialised")
    try:
        body = await request.json()
    except Exception:
        raise HTTPException(400, "Invalid JSON body")
    info_hash = (body or {}).get("info_hash", "").strip()
    if not info_hash:
        raise HTTPException(400, "info_hash is required")
    deleted = hi.delete_by_info_hash(info_hash)
    if not deleted:
        raise HTTPException(404, f"info_hash {info_hash[:12]}… not found")
    return {"status": "ok", "deleted": deleted, "info_hash": info_hash}


@app.post("/api/hash-index/blacklist")
async def api_hash_index_blacklist(request: Request):
    """
    Blacklist a hash so it's never used again — even if re-discovered by a
    later search. Unlike delete-entry, the row stays in the table so we can
    recognise the hash and refuse to promote it back to is_cached=1.
    """
    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    if not hi:
        raise HTTPException(503, "Hash index not initialised")
    try:
        body = await request.json()
    except Exception:
        raise HTTPException(400, "Invalid JSON body")
    info_hash = (body or {}).get("info_hash", "").strip()
    if not info_hash:
        raise HTTPException(400, "info_hash is required")
    n = hi.blacklist_by_info_hash(info_hash)
    if not n:
        raise HTTPException(404, f"info_hash {info_hash[:12]}… not found")
    return {"status": "ok", "blacklisted": n, "info_hash": info_hash}


@app.post("/api/hash-index/unblacklist")
async def api_hash_index_unblacklist(request: Request):
    """Reverse a blacklist — the hash returns to normal lookup eligibility."""
    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    if not hi:
        raise HTTPException(503, "Hash index not initialised")
    try:
        body = await request.json()
    except Exception:
        raise HTTPException(400, "Invalid JSON body")
    info_hash = (body or {}).get("info_hash", "").strip()
    if not info_hash:
        raise HTTPException(400, "info_hash is required")
    n = hi.unblacklist_by_info_hash(info_hash)
    if not n:
        raise HTTPException(404, f"info_hash {info_hash[:12]}… not found")
    return {"status": "ok", "unblacklisted": n, "info_hash": info_hash}


@app.get("/api/hash-index/blacklist")
async def api_hash_index_list_blacklist(request: Request):
    """List every blacklisted hash — for the management UI."""
    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    if not hi:
        raise HTTPException(503, "Hash index not initialised")
    rows = hi.list_blacklisted()
    return {"status": "ok", "count": len(rows), "entries": rows}


@app.post("/api/cache/verify-symlinks")
async def api_cache_verify_symlinks(request: Request):
    """
    Scan every "cached" CacheDB entry, check its on-disk symlink, and queue
    background re-resolves for any whose symlink is missing or broken.

    Returns counts: how many entries are cached, how many had valid symlinks,
    how many were broken and queued for repair. Repair runs asynchronously
    (is_user_play=False) so this endpoint returns quickly.
    """
    db: CacheDB = request.app.state.db
    s = request.app.state.settings
    if not db:
        raise HTTPException(503, "Cache DB not initialised")

    checked  = 0
    valid    = 0
    repaired = 0
    skipped  = 0
    placeholders_restored = 0

    try:
        with db._connect() as c:
            rows = c.execute(
                "SELECT cache_key, media_type, title, year, season, episode, strm_path, status "
                "FROM cache WHERE status = 'cached'"
            ).fetchall()
    except Exception as e:
        raise HTTPException(500, f"Failed to scan cache: {e}")

    for r in rows:
        checked += 1
        if _cached_symlink_valid(r["strm_path"]):
            valid += 1
            continue

        # Stable repair: do not restore placeholders or demote cached rows.
        # Keep the Plex path stable and try to find a replacement cached target.
        try:
            status = await _stable_repair_symlink(request.app, dict(r), reason="manual_verify")
            if status.startswith("repaired"):
                repaired += 1
            elif status == "valid":
                valid += 1
            elif status == "failed_expired":
                skipped += 1
            else:
                skipped += 1
        except Exception as e:
            log.debug(f"verify-symlinks stable repair failed for {r['cache_key']}: {e}")
            skipped += 1

    log.info(
        f"🔧 verify-symlinks: checked={checked} valid={valid} "
        f"placeholders_restored={placeholders_restored} "
        f"queued_repair={repaired} skipped={skipped}"
    )
    return {
        "status": "ok",
        "checked": checked,
        "valid": valid,
        "placeholders_restored": placeholders_restored,
        "queued_repair": repaired,
        "skipped": skipped,
    }


@app.get("/health")
async def health(): return {"status": "ok", "service": "debridarr", "version": "0.5.0"}


@app.get("/api/debug/settings")
async def debug_settings(request: Request):
    """
    Shows what's actually stored in the DB vs what's in env vars.
    Use this to diagnose settings not persisting after reboot.
    """
    import os
    db: CacheDB = request.app.state.db
    s           = request.app.state.settings
    ss          = db.get_all_settings()

    keys = ["ALLDEBRID_API_KEY","OVERSEERR_URL","OVERSEERR_API_KEY",
            "DEBRIDARR_BASE_URL","PLEX_ROOT","SONARR_URL","RADARR_URL",
            "precache_enabled","series_preferred_quality","cache_ttl_days"]

    from app.config import settings as cfg_settings
    return {
        "db_path":    cfg_settings.DB_PATH,
        "db_exists":  Path(cfg_settings.DB_PATH).exists(),
        "db_size_kb": round(Path(cfg_settings.DB_PATH).stat().st_size / 1024, 1) if Path(cfg_settings.DB_PATH).exists() else 0,
        "settings": {
            k: {
                "db":  ("SET" if ss.get(k) else "empty") if k.endswith("KEY") or k == "ALLDEBRID_API_KEY" else ss.get(k, "(not in db)"),
                "env": ("SET" if os.environ.get(k) else "not set") if k.endswith("KEY") or k == "ALLDEBRID_API_KEY" else os.environ.get(k, "(not in env)"),
                "active": ("SET" if getattr(s, k, None) else "not set") if k.endswith("KEY") or k == "ALLDEBRID_API_KEY" else getattr(s, k, ss.get(k, "(unknown)")),
            }
            for k in keys
        }
    }


@app.post("/api/fuse/ensure-symlinked")
@app.get("/api/fuse/ensure-symlinked")
async def fuse_ensure_symlinked(request: Request):
    """
    Walk every registered video file in the FUSE mount and recreate missing
    Plex symlinks for known movies and TV episodes.
    """
    if not FUSE_AVAILABLE:
        return {"ok": False, "error": "FUSE not available", "fixed": 0, "already_linked": 0, "unmatched_count": 0}

    fixed, already_linked, unmatched = _automatch_symlinks_from_fuse(
        request.app, log_prefix="[API-FUSE-AUTOMATCH]"
    )
    return {
        "ok": True,
        "fixed": fixed,
        "already_linked": already_linked,
        "unmatched_count": unmatched,
    }


@app.post("/webhook/tautulli")
async def tautulli_webhook(request: Request, background_tasks: BackgroundTasks):
    try:    payload = await request.json()
    except: payload = dict(await request.form())

    log.info(f"📺 Tautulli: {payload}")

    if not payload:
        log.warning(
            "📺 Tautulli webhook received empty payload — "
            "Tautulli is not configured to send parameters. "
            "Go to Settings → Tautulli Webhook and follow the setup instructions."
        )
        return {"status": "ignored", "reason": "empty payload — check Tautulli webhook JSON body configuration"}

    media_type = payload.get("media_type", "")
    title      = payload.get("grandparent_title") or payload.get("title", "")
    year       = payload.get("year") or payload.get("grandparent_year")
    season     = payload.get("parent_media_index")
    episode    = payload.get("media_index")

    if media_type not in ("movie", "episode") or not title:
        log.warning(f"📺 Tautulli webhook ignored — media_type={media_type!r} title={title!r}")
        return {"status": "ignored"}

    event = PlayEvent(
        media_type=MediaType(media_type), title=title,
        year=int(year) if year else None,
        season=int(season) if season else None,
        episode=int(episode) if episode else None,
        rating_key=payload.get("rating_key"),
        tmdb_id=payload.get("themoviedb_id") or payload.get("tmdb_id"),
        tvdb_id=payload.get("thetvdb_id") or payload.get("tvdb_id"),
        imdb_id=payload.get("imdb_id"),
    )
    log.info(f"📺 Play detected — creating symlink first: {event.cache_key()} — {title} S{season}E{episode}")
    # Prioritize the exact item the user pressed Play on. This returns once the
    # played item's symlink has been created or resolve has failed; lookahead/cache
    # tasks remain deferred in the background.
    await resolve_and_cache(request.app, event, is_user_play=True)
    return {"status": "accepted", "cache_key": event.cache_key(), "mode": "on_play_symlink"}


# ── Background helpers ────────────────────────────────────────────────────────


def _hash_index_has_cached_placeholder(app: FastAPI, media_type: str, title: str, year=None, season=None, episode=None) -> bool:
    """
    STRICT placeholder gate.

    A Plex placeholder is only allowed when the hash index already contains a
    confirmed cached row for the exact item that will appear in Plex.

    Important: episode placeholders must NOT be created from a broad season or
    series pack row alone. A season/series pack can be used later for playback
    resolving, but it cannot make Plex show individual episodes unless each
    episode has an exact cached episode entry in hash_index. This prevents
    placeholders for episodes that are released but not actually found online.
    """
    hi: HashIndex = getattr(app.state, "hash_index", None) if app is not None else None
    if not hi or not title:
        return False
    try:
        title_norm = _norm(title)
        with hi._conn() as c:
            if media_type == "movie":
                rows = c.execute(
                    """SELECT year FROM hash_index
                       WHERE title_norm = ?
                         AND media_type = 'movie'
                         AND blacklisted = 0
                         AND is_cached = 1
                       LIMIT 10""",
                    (title_norm,),
                ).fetchall()
                if year:
                    # Strict movie placeholder gate: a no-year cached row is
                    # not enough to make a specific movie appear in Plex.
                    # This prevents an uncached requested movie from getting a
                    # placeholder because an older/manual/no-year hash row has
                    # the same normalized title.
                    return any((r["year"] is not None and int(r["year"] or 0) == int(year)) for r in rows)
                return bool(rows)

            if media_type == "episode" and season is not None and episode is not None:
                row = c.execute(
                    """SELECT 1 FROM hash_index
                       WHERE title_norm = ?
                         AND media_type = 'episode'
                         AND season = ?
                         AND episode = ?
                         AND blacklisted = 0
                         AND is_cached = 1
                       LIMIT 1""",
                    (title_norm, int(season), int(episode)),
                ).fetchone()
                if row:
                    return True
                log.debug(
                    f"placeholder strict gate blocked {title!r} "
                    f"S{int(season):02d}E{int(episode):02d}: no exact cached episode row in hash_index"
                )
    except Exception as e:
        log.debug(f"placeholder hash gate failed for {title!r}: {e}")
    return False


def _episode_airdate_released(app: FastAPI, title: str, season, episode, air_date: str | None = None) -> bool:
    """Return True only after a known episode air_date has passed.

    Unknown air dates are treated as unreleased for placeholder creation.
    This keeps Plex clean until TMDB/Sonarr confirms the episode exists and aired.
    """
    from datetime import date as _date
    today = _date.today().isoformat()
    if air_date:
        return bool(air_date <= today)
    db: CacheDB = getattr(app.state, "db", None) if app is not None else None
    if db and title and season and episode:
        try:
            with db._connect() as c:
                row = c.execute(
                    "SELECT air_date FROM upcoming_episodes WHERE title=? AND season=? AND episode=?",
                    (title, int(season), int(episode)),
                ).fetchone()
            if row and row[0]:
                return row[0] <= today
        except Exception:
            pass
    return False


def _placeholder_allowed(app: FastAPI, media_type: str, title: str, year=None, season=None, episode=None, air_date: str | None = None) -> bool:
    """Hard gate for every placeholder writer/restorer.

    Rules:
      - uncached hash index miss => no placeholder
      - future/unknown episode air_date => no placeholder
      - movies rely on the add/search release-date checks plus cached hash gate
    """
    if media_type == "episode":
        if not _episode_airdate_released(app, title, season, episode, air_date):
            return False
    return _hash_index_has_cached_placeholder(app, media_type, title, year, season, episode)

async def _precache_resolve(app: FastAPI, title: str, year, media_type: str,
                            season: int = None, episode: int = None) -> bool:
    """
    Pre-cache-on-add resolver.

    When the setting "Pre-cache on add" is enabled, this must create the REAL
    playable symlink immediately, not just a placeholder. It uses the same
    resolve_and_cache() path as Plex playback, but with is_user_play=False so it
    does not trigger recursive binge/lookahead jobs.

    Returns True only when the cache row is marked cached and the on-disk
    symlink/STRM target exists.
    """
    from app.models import PlayEvent, MediaType
    db: CacheDB = getattr(app.state, "db", None)
    lm: LibraryManager = getattr(app.state, "library", None)

    if not lm or not lm.plex_root:
        return False

    if db and db.get_setting("precache_enabled", "true") == "false":
        return False

    mt = MediaType.movie if media_type == "movie" else MediaType.episode
    event = PlayEvent(media_type=mt, title=title, year=year,
                      season=season, episode=episode)
    cache_key = event.cache_key()

    # Keep the strict rules: no unreleased episodes and no hash-index hit means
    # no placeholder and no symlink attempt.
    if not _placeholder_allowed(app, media_type, title, year, season, episode):
        log.info(f"⏭️  Pre-cache blocked for {title!r} — unreleased or no cached hash index hit")
        return False

    try:
        await resolve_and_cache(app, event, is_user_play=False)
        row = db.get(cache_key) if db else None
        if row and row.get("status") == "cached":
            sp = row.get("strm_path")
            # FUSE symlink mode writes a symlink; non-FUSE fallback may write a
            # STRM/proxy file. Accept either an existing file or a valid symlink.
            if sp and (_cached_symlink_valid(sp) or Path(sp).exists()):
                log.info(f"✅ Pre-cache symlink ready: {cache_key}")
                return True
        log.info(f"⏭️  Pre-cache did not create a playable symlink for {cache_key}")
        return False
    except Exception as e:
        log.warning(f"_precache_resolve symlink failed for {cache_key}: {e}")
        return False



def _remove_ghost_episode_files(
    plex_root: str | Path,
    title: str,
    valid_eps: list[dict],
    db: Optional["CacheDB"],
    log,
) -> int:
    """
    Sweep <plex_root>/tv/<title> for files matching SxxExx patterns and remove
    any whose (season, episode) is NOT in `valid_eps`. Also removes empty
    season directories left behind. Returns the count of files removed.

    The CacheDB rows for the removed (s, e) are demoted to status='not_found'
    so a future play retry can re-resolve cleanly.

    Used to clean up stale placeholders/symlinks created by earlier code paths
    that didn't gate by TMDB — e.g. a "Season 2" placeholder for a one-season
    show whose TMDB record only has Season 1.
    """
    show_dir = Path(plex_root) / "tv" / title
    if not show_dir.exists():
        return 0

    valid_set = {(int(e["season"]), int(e["episode"])) for e in valid_eps if e.get("season") and e.get("episode")}
    valid_seasons = {s for s, _ in valid_set}
    removed = 0

    for season_dir in show_dir.iterdir():
        if not season_dir.is_dir():
            continue

        # Try to extract season number from "Season 02" etc.
        m_dir = re.match(r"Season\s+0*(\d+)", season_dir.name, re.I)
        season_dir_num = int(m_dir.group(1)) if m_dir else None

        for f in list(season_dir.iterdir()):
            m = re.search(r"[Ss](\d{1,2})[Ee](\d{1,2})", f.name)
            if not m:
                continue
            sn, en = int(m.group(1)), int(m.group(2))
            if (sn, en) in valid_set:
                continue
            try:
                if f.is_symlink():
                    # Stable symlink rule: never delete symlinks during metadata/
                    # ghost cleanup or startup.  They may point at valid cached
                    # media that TMDB/Overseerr has not synced yet.  Symlinks are
                    # only removed by manual expiry/retention or failed repair.
                    log.debug(f"🛡️ kept symlink during ghost cleanup S{sn:02d}E{en:02d}: {f.name}")
                    continue
                if f.is_file():
                    f.unlink()
                    removed += 1
                    if db:
                        # Demote only placeholder/regular files, never symlink-backed rows.
                        try:
                            from app.models import PlayEvent, MediaType
                            ev = PlayEvent(
                                media_type=MediaType.episode, title=title,
                                year=None, season=sn, episode=en,
                            )
                            existing = db.get(ev.cache_key())
                            if existing and not existing.get("strm_path"):
                                db.update_status(ev.cache_key(), "not_found")
                        except Exception:
                            pass
                    log.debug(f"🧹 removed ghost placeholder/file S{sn:02d}E{en:02d}: {f.name}")
            except Exception as e:
                log.debug(f"failed to remove ghost {f}: {e}")

        # If the season directory's number isn't in TMDB and the dir is now
        # empty, prune it too. Don't touch dirs we couldn't classify.
        if season_dir_num is not None and season_dir_num not in valid_seasons:
            try:
                if not any(season_dir.iterdir()):
                    season_dir.rmdir()
                    log.debug(f"🧹 removed empty ghost season dir: {season_dir.name}")
            except Exception:
                pass

    return removed


async def _index_movie_hashes(app: FastAPI, title: str, year):
    """
    Search AllDebrid directly for cached movie hashes and store in hash index.
    Uses alldebrid.search_cached() — the same proven path used by the play resolver.
    Falls back to Prowlarr if AllDebrid search returns nothing.
    """
    alldebrid: AllDebridClient = app.state.alldebrid
    hi: HashIndex  = getattr(app.state, "hash_index", None)
    db: CacheDB    = getattr(app.state, "db", None)
    if not hi or not alldebrid or not alldebrid.api_key:
        log.warning(f"_index_movie_hashes: missing hi={hi is not None} alldebrid={alldebrid is not None}")
        return
    settings         = db.get_all_settings() if db else {}
    preferred_quality = settings.get("movie_preferred_quality", "1080p")
    fallback_any      = settings.get("movie_fallback_any_quality", "true") == "true"
    try:
        import re as _re
        # Primary: use alldebrid.search_cached() — directly queries TPB/AllDebrid
        results = await alldebrid.search_cached(
            title=title, media_type="movie", year=year,
            preferred_quality=preferred_quality, fallback_any=fallback_any,
        )
        log.info(f"🗄️  AllDebrid search for {title!r}: {len(results)} cached result(s)")

        n = 0
        for r in results:
            magnet = r.get("magnet", "")
            m = _re.search(r"btih:([a-fA-F0-9]{40})", magnet, _re.I)
            if not m:
                continue
            try:
                _torrent_name = r.get("name", "")
                # Detect quality from torrent name first, fall back to result quality field
                import re as _qre
                _qm = _qre.search(r"(2160p|4k|uhd|1080p|720p|480p)", _torrent_name, _qre.I)
                _quality = _qm.group(1).lower() if _qm else (r.get("quality") or preferred_quality)
                hi.upsert(
                    media_type="movie",
                    title=title, year=year,
                    season=None, episode=None,
                    info_hash=m.group(1).lower(),
                    magnet=magnet,
                    torrent_name=_torrent_name,
                    quality=_quality,
                    strategy="movie",
                    is_cached=True,
                    file_size=r.get("size", 0),
                    preferred_quality=preferred_quality,
                )
                n += 1
            except Exception as ue:
                log.warning(f"  upsert error for {title!r}: {ue}")

        # Fallback: Prowlarr (if configured and AllDebrid search missed)
        if n == 0:
            prowlarr_url = settings.get("PROWLARR_URL", "")
            prowlarr_key = settings.get("PROWLARR_API_KEY", "")
            if prowlarr_url and prowlarr_key:
                log.info(f"🗄️  Falling back to Prowlarr for {title!r}")
                try:
                    n = await index_movie(
                        hi,
                        prowlarr_url=prowlarr_url,
                        prowlarr_key=prowlarr_key,
                        api_key=alldebrid.api_key,
                        title=title, year=year,
                        preferred_quality=preferred_quality,
                    )
                except Exception as pe:
                    log.warning(f"  Prowlarr fallback failed for {title!r}: {pe}")

        exact_cached_movie = _placeholder_allowed(app, "movie", title, year)
        log.info(f"🗄️  HashIndex movie {title!r}: {n} cached hash(es) stored; exact_cached={exact_cached_movie}")

        # Absolute movie placeholder rule:
        # no exact cached movie row in hash_index = no Plex placeholder.
        # This is checked AFTER indexing because Prowlarr/AD may store uncached
        # rows for downloads/search history. Those rows must never materialize
        # into Plex until AllDebrid confirms them cached.
        if not exact_cached_movie:
            lm: LibraryManager = getattr(app.state, "library", None)
            if lm and lm.plex_root:
                try:
                    lm.remove_fake_movie(title, year)
                except Exception:
                    pass
            log.info(f"⏭️  Movie placeholder blocked/removed for {title!r} — no exact cached movie hash in index")
            return

        if n > 0:
            precache_on = settings.get("precache_enabled", "true") != "false"
            if precache_on:
                # Pre-cache enabled: add_magnet + symlink now
                resolved = await _precache_resolve(app, title, year, "movie")
                if resolved:
                    log.info(f"🎬 Pre-cache: {title!r} symlinked into Plex")
                else:
                    # Do NOT create a fallback placeholder here. If symlinking
                    # fails, leave the movie hidden until a playable cached row
                    # can be resolved on play/manual retry.
                    lm: LibraryManager = getattr(app.state, "library", None)
                    if lm and lm.plex_root:
                        try:
                            lm.remove_fake_movie(title, year)
                        except Exception:
                            pass
                    log.info(f"⏭️  Pre-cache failed for {title!r}; placeholder not created")
            else:
                # Pre-cache disabled: write placeholder only, symlink on play
                lm: LibraryManager = getattr(app.state, "library", None)
                if lm and lm.plex_root and exact_cached_movie:
                    lm.create_fake_movie(title, year)
                    log.info(f"🎬 Placeholder written for {title!r} (symlink deferred to play)")
                else:
                    log.info(f"⏭️  Movie placeholder blocked for {title!r} — no cached hash in index")
        else:
            log.info(f"⏭️  No cached hash found for {title!r}")

    except Exception as e:
        log.error(f"_index_movie_hashes {title!r}: {e}", exc_info=True)


async def _index_series_hashes(app: FastAPI, title: str, year, season_count: int, is_ended: bool, episodes: list):
    """
    Search AllDebrid directly for cached series/season pack hashes and store in hash index.
    Uses alldebrid.search_cached() — same proven path used by episode sync.
    Falls back to Prowlarr if AllDebrid returns nothing.
    """
    alldebrid: AllDebridClient = app.state.alldebrid
    hi: HashIndex = getattr(app.state, "hash_index", None)
    db: CacheDB   = getattr(app.state, "db", None)
    if not hi or not alldebrid or not alldebrid.api_key:
        return
    year = await _canonical_series_year(app, title, year)
    settings         = db.get_all_settings() if db else {}
    preferred_quality = settings.get("series_preferred_quality", "1080p")
    fallback_any      = settings.get("series_fallback_any_quality", "true") == "true"
    strategy          = "series_pack" if is_ended else "season_pack"

    # Fetch TMDB's authoritative season + episode list ONCE at the top. We use
    # this for: (a) season_count, (b) which seasons to probe for packs, (c) the
    # `covered` set when creating placeholders, (d) the ghost cleanup pass.
    tmdb_known: list[dict] = []
    tmdb_seasons: set[int] = set()
    try:
        tmdb_eps = await _get_series_episodes_via_tmdb(
            app, title, year=year, include_unreleased=False,
        )
        if tmdb_eps:
            tmdb_known = [
                {
                    "season": e["season"],
                    "episode": e["episode"],
                    "air_date": e.get("air_date", ""),
                }
                for e in tmdb_eps
                if (e.get("season") or 0) > 0
                and (e.get("episode") or 0) > 0
                and e.get("air_date")
            ]
            tmdb_seasons = {e["season"] for e in tmdb_known}
    except Exception as e:
        log.debug(f"_index_series_hashes TMDB episodes {title!r}: {e}")

    # Fall back to caller-supplied episode list (Sonarr/Overseerr) when TMDB
    # is offline. Defensively filter by air_date so unreleased never sneaks in.
    if not tmdb_known and episodes:
        today_iso = datetime.utcnow().date().isoformat()
        tmdb_known = [
            {
                "season": ep["season"],
                "episode": ep["episode"],
                "air_date": ep.get("air_date", ""),
            }
            for ep in episodes
            if ep.get("season") and ep.get("episode")
            and ep.get("air_date") and ep["air_date"] <= today_iso
        ]
        tmdb_seasons = {e["season"] for e in tmdb_known}

    # Authoritative season count from TMDB. Persist back to library so other
    # paths (UI, sync loop) agree.
    if tmdb_seasons:
        tmdb_sc = max(tmdb_seasons)  # highest released season number
        if tmdb_sc != (season_count or 0):
            log.info(
                f"📺 {title!r}: season_count {season_count} (library) → "
                f"{tmdb_sc} (TMDB) — using TMDB"
            )
            if db:
                try:
                    db.fake_library_set_season_count(title, "series", tmdb_sc)
                except Exception:
                    pass
        season_count = tmdb_sc

    # Ghost cleanup — remove any pre-existing placeholders/symlinks on disk
    # for (season, episode) combos that TMDB doesn't know about. This handles
    # leftovers from earlier runs that wrote bad slots (e.g. a "Season 2"
    # placeholder for a one-season show).
    lm_early: LibraryManager = getattr(app.state, "library", None)
    if tmdb_known and lm_early and lm_early.plex_root:
        try:
            ghosts = _remove_ghost_episode_files(
                lm_early.plex_root, title, tmdb_known, db, log,
            )
            if ghosts:
                log.info(
                    f"🧹 {title!r}: removed {ghosts} ghost placeholder(s) "
                    f"for season/episode slots TMDB doesn't recognise"
                )
        except Exception as e:
            log.debug(f"ghost cleanup {title!r}: {e}")

    import re as _re
    cached_seasons: set[int] = set()
    total_cached = 0

    try:
        # ── Primary: AllDebrid search_cached (proven working) ─────────────────
        # Try series pack first
        series_results = await alldebrid.search_cached(
            title=title, media_type="episode", year=year,
            season=1, episode=1,
            strategy="series_pack",
            preferred_quality=preferred_quality, fallback_any=fallback_any,
        )
        if series_results:
            log.info(f"🗄️  AllDebrid series pack for {title!r}: {series_results[0]['name'][:60]}")
            for r in series_results:
                m = _re.search(r"btih:([a-fA-F0-9]{40})", r.get("magnet",""), _re.I)
                if m:
                    hi.upsert(media_type="series", title=title, year=year,
                              season=None, episode=None,
                              info_hash=m.group(1).lower(), magnet=r["magnet"],
                              torrent_name=r.get("name",""), quality=r.get("quality","unknown"),
                              strategy="series_pack", is_cached=True,
                              file_size=r.get("size",0), preferred_quality=preferred_quality)
                    total_cached += 1
            cached_seasons = {ep["season"] for ep in episodes} if episodes else set(range(1, season_count+1))

        # Try each season pack — limit to seasons TMDB actually knows about.
        # Falls back to the legacy range(1, season_count+1) only when TMDB is
        # unavailable (no API key, network blip, etc).
        seasons_to_probe = (
            sorted(tmdb_seasons) if tmdb_seasons
            else list(range(1, (season_count or 1) + 1))
        )
        for sn in seasons_to_probe:
            season_results = await alldebrid.search_cached(
                title=title, media_type="episode", year=year,
                season=sn, episode=1,
                strategy="season_pack",
                preferred_quality=preferred_quality, fallback_any=fallback_any,
            )
            if season_results:
                log.info(f"🗄️  AllDebrid season pack S{sn:02d} for {title!r}: {season_results[0]['name'][:60]}")
                for r in season_results:
                    m = _re.search(r"btih:([a-fA-F0-9]{40})", r.get("magnet",""), _re.I)
                    if m:
                        hi.upsert(media_type="season", title=title, year=year,
                                  season=sn, episode=None,
                                  info_hash=m.group(1).lower(), magnet=r["magnet"],
                                  torrent_name=r.get("name",""), quality=r.get("quality","unknown"),
                                  strategy="season_pack", is_cached=True,
                                  file_size=r.get("size",0), preferred_quality=preferred_quality)
                        total_cached += 1
                cached_seasons.add(sn)

        log.info(f"🗄️  HashIndex series {title!r}: {total_cached} cached hash(es), seasons={sorted(cached_seasons)}")

        # Fallback: Prowlarr (if AllDebrid search missed everything)
        if total_cached == 0:
            prowlarr_url = settings.get("PROWLARR_URL", "")
            prowlarr_key = settings.get("PROWLARR_API_KEY", "")
            if prowlarr_url and prowlarr_key:
                log.info(f"🗄️  Falling back to Prowlarr for series {title!r}")
                try:
                    counts = await index_series(
                        hi, prowlarr_url=prowlarr_url, prowlarr_key=prowlarr_key,
                        api_key=alldebrid.api_key,
                        title=title, year=year,
                        season_count=season_count or 1, is_ended=is_ended,
                        preferred_quality=preferred_quality,
                    )
                    total_cached = counts.get("series_packs",0) + counts.get("season_packs",0)
                    if total_cached > 0:
                        cached_seasons = {ep["season"] for ep in episodes} if episodes else set()
                except Exception as pe:
                    log.warning(f"  Prowlarr series fallback failed for {title!r}: {pe}")

        if total_cached == 0:
            log.info(f"⏭️  No cached hashes for {title!r} — no placeholders created")
            return

        # ── Gated placeholder creation ─────────────────────────────────────────
        # Only create placeholders for episodes that are actually backed by a
        # cached hash in the index. The hash index is the source of truth:
        #   • Cached series pack  → covers every episode TMDB knows about
        #   • Cached season N pack → covers every episode in season N
        #   • Cached per-episode hash → covers that specific episode
        # Episodes with no cached coverage do NOT get a placeholder — Plex
        # shouldn't display library slots that point nowhere.
        lm: LibraryManager = getattr(app.state, "library", None)

        # tmdb_known + tmdb_seasons were computed at the top of this function.
        # Reuse them — re-fetching wastes API calls and could disagree.

        # Build the covered set from the hash index.
        covered: set[tuple[int, int]] = set()

        # Series pack — if any series-pack row is cached, EVERY known episode is covered
        try:
            full_breakdown = hi.get_series_breakdown(title)
        except Exception:
            full_breakdown = {}
        series_pack_cached = bool(
            (full_breakdown.get("series_pack") or {}).get("is_cached")
        )
        if series_pack_cached:
            covered |= {(e["season"], e["episode"]) for e in tmdb_known}

        # Season packs (those we just upserted, plus any we knew before)
        seasons_block = full_breakdown.get("seasons") or {}
        for sn_key, s in seasons_block.items():
            sp = (s or {}).get("season_pack") or {}
            if sp.get("is_cached"):
                try:
                    sn = int(sn_key)
                except (TypeError, ValueError):
                    continue
                covered |= {(e["season"], e["episode"]) for e in tmdb_known if e["season"] == sn}

            # Per-episode hash entries that are cached
            for en_key, ep_row in ((s or {}).get("episodes") or {}).items():
                if ep_row.get("is_cached"):
                    try:
                        en = int(en_key); sn = int(sn_key)
                    except (TypeError, ValueError):
                        continue
                    covered.add((sn, en))

        if not covered:
            log.info(
                f"⏭️  {title!r}: search found {total_cached} cached hash(es) but "
                f"none mapped to known TMDB episodes — no placeholders created"
            )
            return

        _air_by_se = {(int(e["season"]), int(e["episode"])): e.get("air_date", "") for e in tmdb_known}
        placeholder_eps = [
            {"season": s, "episode": e, "air_date": _air_by_se.get((s, e), "")}
            for s, e in sorted(covered)
        ]
        placeholder_eps = [
            ep for ep in placeholder_eps
            if _placeholder_allowed(app, "episode", title, year, ep["season"], ep["episode"], ep.get("air_date"))
        ]
        if not placeholder_eps:
            log.info(f"⏭️  {title!r}: cached hashes found but no released cached episodes — no placeholders created")
            return

        # Mark covered episodes as not_found in CacheDB so subsequent
        # plays/cache_ahead events have something to resolve against.
        if db:
            for ep in placeholder_eps:
                try:
                    ev = PlayEvent(
                        media_type=MediaType.episode, title=title, year=year,
                        season=ep["season"], episode=ep["episode"],
                    )
                    if not db.get(ev.cache_key()):
                        db.upsert(ev.cache_key(), ev, status="not_found")
                except Exception:
                    pass

        if lm and lm.plex_root:
            paths = lm.create_fake_episodes(title, year, [], placeholder_eps)
            log.info(
                f"📺 {title!r}: {len(paths)} placeholder(s) written / "
                f"{len(covered)} cached episode(s) "
                f"(series_pack={series_pack_cached}, "
                f"seasons_with_packs={sorted({s for s,_ in covered})})"
            )

        precache_on = settings.get("precache_enabled", "true") != "false"

        if precache_on:
            # Pre-cache enabled: symlink every released, hash-index-backed
            # episode now. Do not limit to the first episode of each season —
            # that made TV series appear pre-cached while most episodes were
            # still placeholder-only.
            resolved_any = False
            resolved_count = 0
            for ep in placeholder_eps:
                sn = int(ep["season"]); en = int(ep["episode"])
                ok = await _precache_resolve(app, title, year, "episode", season=sn, episode=en)
                if ok:
                    resolved_any = True
                    resolved_count += 1
                    log.info(f"📺 Pre-cache: {title!r} S{sn:02d}E{en:02d} symlinked")
            if resolved_any:
                log.info(f"📺 Pre-cache: {title!r} {resolved_count} episode symlink(s) ready")
            else:
                log.info(f"📺 Pre-cache: {title!r} no symlinks created")

    except Exception as e:
        log.error(f"_index_series_hashes {title!r}: {e}", exc_info=True)


async def _hash_index_recheck_loop(app: FastAPI):
    """
    Periodic maintenance for the hash index:
      - Every 6 hours: re-verify stale hashes against AllDebrid
      - Every 24 hours: purge entries unused for > 6 months
    """
    await asyncio.sleep(300)  # 5-minute startup delay
    _recheck_count = 0
    while True:
        try:
            alldebrid: AllDebridClient = app.state.alldebrid
            hi: HashIndex = getattr(app.state, "hash_index", None)
            db: CacheDB   = app.state.db

            if hi and alldebrid and alldebrid.api_key:
                result = await recheck_stale(hi, alldebrid.api_key)
                log.info(f"🔄 HashIndex recheck: {result}")
                pruned = hi.prune_log(max_rows=5000)
                if pruned:
                    log.debug(f"🗄️  Hash log pruned: {pruned} old entries")

            # Purge unused entries once per day (every 4th 6-hour cycle)
            _recheck_count += 1
            if _recheck_count % 4 == 0 and hi:
                months = int(db.get_setting("hash_index_ttl_months", "6"))
                purge_result = hi.purge_unused(months=months)
                if purge_result["deleted"]:
                    log.info(
                        f"🗄️  HashIndex daily purge: "
                        f"removed {purge_result['deleted']} entries unused >{months}m, "
                        f"{purge_result['remaining']} remaining"
                    )

        except Exception as e:
            log.error(f"hash_index_recheck_loop: {e}")
        await asyncio.sleep(6 * 3600)  # 6 hours


async def _verify_symlinks_loop(app: FastAPI):
    """
    Periodically scan the cache DB for cached entries whose on-disk symlink
    is missing or broken, restore placeholders so Plex always sees a file,
    and queue re-resolves so playback works on next play.

    Interval is controlled by the `verify_symlinks_interval_minutes` setting
    (default 15). Setting the value to 0 disables the loop. The loop reads
    the setting every cycle so changes take effect without a restart.
    """
    # Stagger startup so we don't compete with sync loops in the first minute
    await asyncio.sleep(60)
    while True:
        try:
            db: CacheDB = getattr(app.state, "db", None)
            if db is None:
                await asyncio.sleep(60)
                continue

            # Even in on-play symlink mode we still verify existing symlinks.
            # We do not mass-create placeholders; repair keeps Plex paths stable.

            # Setting in minutes. 0 = disabled.
            try:
                interval_min = int(db.get_setting("verify_symlinks_interval_minutes", "15"))
            except (TypeError, ValueError):
                interval_min = 15

            if interval_min <= 0:
                # Disabled — wake up every 5 minutes to re-check the setting
                await asyncio.sleep(300)
                continue

            settings_cfg = app.state.settings
            checked = valid = repaired = restored = skipped = 0

            if not _fuse_mount_ready_for_symlink_repair(app):
                log.info("🔧 verify_symlinks_loop: FUSE not ready; keeping symlinks stable and retrying later")
                await asyncio.sleep(max(60, interval_min * 60))
                continue

            try:
                with db._connect() as c:
                    rows = c.execute(
                        "SELECT cache_key, media_type, title, year, season, episode, "
                        "strm_path, status FROM cache WHERE status = 'cached'"
                    ).fetchall()
            except Exception as e:
                log.error(f"verify_symlinks_loop scan: {e}")
                await asyncio.sleep(interval_min * 60)
                continue

            for r in rows:
                checked += 1
                if _cached_symlink_valid(r["strm_path"]):
                    valid += 1
                    continue
                try:
                    status = await _stable_repair_symlink(app, dict(r), reason="loop_verify")
                    if status.startswith("repaired"):
                        repaired += 1
                    elif status == "valid":
                        valid += 1
                    else:
                        skipped += 1
                except Exception:
                    skipped += 1

            if checked:
                log.info(
                    f"🔧 verify_symlinks_loop: checked={checked} valid={valid} "
                    f"placeholders_restored={restored} queued_repair={repaired} "
                    f"skipped={skipped} (next in {interval_min}m)"
                )

        except Exception as e:
            log.error(f"verify_symlinks_loop: {e}")
        await asyncio.sleep(max(60, interval_min * 60))


async def _sync_streams_to_index(app: FastAPI) -> dict:
    """
    Sync all resolved cache entries to the hash index.

    Every entry in the cache DB with status=cached already has a confirmed
    magnet + torrent name — write them directly to the hash index without
    going through Prowlarr or AllDebrid again.

    This is the reliable fill path: anything that has ever played gets indexed.
    Called on startup and via the /api/hash-index/sync-streams endpoint.
    """
    hi: HashIndex  = getattr(app.state, "hash_index", None)
    db: CacheDB    = getattr(app.state, "db", None)
    if not hi or not db:
        return {"synced": 0, "skipped": 0}

    entries = [e for e in db.list_all() if e.get("status") == "cached"
               and e.get("magnet_link") and e.get("torrent_name")]

    synced = skipped = 0
    for e in entries:
        title       = e.get("title", "")
        year        = e.get("year")
        media_type  = e.get("media_type", "movie")
        season      = e.get("season")
        episode     = e.get("episode")
        magnet      = e.get("magnet_link", "")
        torrent     = e.get("torrent_name", "")
        quality     = e.get("quality") or "unknown"

        if not title or not magnet:
            skipped += 1
            continue

        # Extract infohash from magnet
        import re as _re
        m = _re.search(r"btih:([a-fA-F0-9]{40})", magnet, _re.I)
        if not m:
            skipped += 1
            continue
        info_hash = m.group(1).lower()

        # Determine media_type for hash index
        if media_type == "movie":
            hi_type = "movie"
        elif season and not episode:
            hi_type = "season"
        elif season and episode:
            hi_type = "episode"
        else:
            hi_type = "series"

        try:
            hi.upsert(
                media_type=hi_type,
                title=title,
                year=year,
                season=season,
                episode=episode,
                info_hash=info_hash,
                magnet=magnet,
                torrent_name=torrent,
                quality=quality,
                strategy="stream_sync",
                is_cached=True,   # confirmed — it played
            )
            synced += 1
        except Exception as e:
            log.warning(f"sync_streams_to_index: {title!r}: {e}")
            skipped += 1

    log.info(f"🔄 Streams→HashIndex sync: {synced} synced, {skipped} skipped")
    return {"synced": synced, "skipped": skipped}


async def _precache_movie(app: FastAPI, title: str, year, tmdb_id, imdb_id):
    """Index the hash for a movie on add — no AllDebrid account changes."""
    log.info(f"🗄️  _precache_movie starting for {title!r} ({year})")
    try:
        await _index_movie_hashes(app, title, year)
        log.info(f"🗄️  _precache_movie done for {title!r}")
    except asyncio.CancelledError:
        log.info(f"🎬 Hash index cancelled for '{title}'")
        raise
    except Exception as e:
        log.error(f"Movie hash index {title!r}: {e}", exc_info=True)
    finally:
        _precache_tasks.pop(title.lower(), None)

async def _precache_series(app: FastAPI, title: str, year, episodes: list):
    """
    Index hashes for all seasons of a series on add — no AllDebrid account changes.

    Previously iterated every episode and called resolve_and_cache() which
    called add_magnet() for each one, permanently filling the AllDebrid
    account with every torrent before the user played anything.

    Now we run index_series() which:
      1. Searches TPB for series/season packs and individual episodes
      2. Probe-uploads hashes to AllDebrid to confirm they are cached
         (upload → read ready flag → delete immediately — no account side-effect)
      3. Stores confirmed hashes in the local SQLite hash index

    add_magnet() is called exactly once per item, only when the user
    presses play, via the hash-index fast path in _resolve_and_cache_inner.
    """
    try:
        db_ref: CacheDB = app.state.db
        year = await _canonical_series_year(app, title, year)
        lib_entry    = db_ref.fake_library_get("series", title, year) if db_ref else None
        if not lib_entry and db_ref:
            lib_entry = next((r for r in db_ref.fake_library_list(media_type="series") if (r.get("title") or "").strip().lower() == (title or "").strip().lower()), None)
        is_ended     = lib_entry.get("status", "continuing") in ("ended", "cancelled", "canceled") if lib_entry else False
        season_count = lib_entry.get("season_count", 1) or 1 if lib_entry else 1
        log.info(f"🗄️  _precache_series starting for {title!r} ({year}) — {len(episodes)} episodes, {season_count} seasons")
        await _index_series_hashes(app, title, year, season_count, is_ended, episodes)
        log.info(f"🗄️  _precache_series done for {title!r}")

        # Also populate upcoming episodes list right away
        try:
            _db2: CacheDB = app.state.db
            _lm2: LibraryManager = getattr(app.state, "library", None)
            if _db2 and _lm2 and lib_entry and lib_entry.get("sonarr_id"):
                _all_eps = await _lm2.get_episodes(lib_entry["sonarr_id"], include_unreleased=False)
                _today   = __import__('datetime').date.today().isoformat()
                _added   = 0
                for _ep in _all_eps:
                    _air = _ep.get("air_date", "")
                    if _air and _air > _today:
                        _db2.upsert_upcoming(
                            title=title, year=year,
                            sonarr_id=lib_entry["sonarr_id"],
                            season=_ep["season"], episode=_ep["episode"],
                            air_date=_air,
                        )
                        _added += 1
                if _added:
                    log.info(f"📅 Tracking {_added} upcoming episode(s) for {title!r}")
        except Exception as _ue:
            log.debug(f"Upcoming populate {title!r}: {_ue}")

    except asyncio.CancelledError:
        log.info(f"📺 Hash index cancelled for '{title}'")
        raise
    except Exception as e:
        log.error(f"Series hash index {title!r}: {e}", exc_info=True)
    finally:
        _precache_tasks.pop(title.lower(), None)
async def _fetch_tmdb_poster(tmdb_id, title: str, is_movie: bool, tmdb_key: str) -> str:
    """Fetch poster URL from TMDB — by ID first, title search fallback."""
    if not tmdb_key: return ""
    import httpx as _hx
    endpoint = "movie" if is_movie else "tv"
    try:
        async with _hx.AsyncClient(timeout=8) as c:
            if tmdb_id:
                r = await c.get(f"https://api.themoviedb.org/3/{endpoint}/{tmdb_id}",
                                params={"api_key": tmdb_key})
                if r.status_code == 200:
                    p = r.json().get("poster_path")
                    if p: return f"https://image.tmdb.org/t/p/w342{p}"
            # Fallback: search by title
            r2 = await c.get(f"https://api.themoviedb.org/3/search/{endpoint}",
                             params={"api_key": tmdb_key, "query": title})
            if r2.status_code == 200:
                results = r2.json().get("results", [])
                if results and results[0].get("poster_path"):
                    return f"https://image.tmdb.org/t/p/w342{results[0]['poster_path']}"
    except Exception:
        pass
    return ""


async def _cleanup_loop(app: FastAPI):
    """
    Hourly cleanup — remove entries whose retention TTL has expired.
    Played and lookahead pre-symlinked files remain until symlink_retention_days
    expires, then the symlink is removed and the placeholder is restored.
    """
    while True:
        await asyncio.sleep(3600)
        db = app.state.db
        s  = app.state.settings

        for entry in db.list_expired():
            ck    = entry["cache_key"]
            title = entry.get("title", "")

            if db.is_pinned(title):
                # Pinned title — re-resolve instead of expiring
                # This keeps it alive on AllDebrid and refreshes the 30-day TTL
                log.info(f"📌 Pinned TTL refresh: {ck} — re-resolving")
                try:
                    from app.models import PlayEvent, MediaType
                    event = PlayEvent(
                        media_type=MediaType(entry["media_type"]),
                        title=title, year=entry.get("year"),
                        season=entry.get("season"), episode=entry.get("episode"),
                    )
                    db.update_status(ck, "not_found")
                    await resolve_and_cache(app, event, is_user_play=False)
                    log.info(f"📌 Pinned refresh done: {ck}")
                except Exception as e:
                    log.error(f"📌 Pinned refresh failed {ck}: {e}")
                    db.refresh_ttl(ck)  # push TTL back even on failure
            else:
                log.info(f"⏰ TTL expired: {ck}")
                await _hard_expire(entry, db, s, app.state.alldebrid)

        purged = db.purge_expired()
        if purged:
            log.info(f"⏰ Purged {purged} expired cache entries")


# Torrent sync loop intentionally removed.
# Comparing FUSE names against AllDebrid names is unreliable due to truncation
# and causes false-positive deletions of valid cached files.
# Cache lifecycle is managed by:
#   - TTL expiry (_cleanup_loop) — removes after 30 days
#   - User remove action (api_library_remove) — removes immediately
#   - Symlink health check (_check_and_repair_symlinks) — repairs broken symlinks hourly

async def _upcoming_episode_watcher(app: FastAPI):
    """
    Runs every 15 minutes. Tracks upcoming episodes for all library series.
    When an episode's air_date passes:
      1. Search AllDebrid for a cached torrent (season pack first, then episode)
      2. Write to hash index
      3. Create placeholder (.mp4) so it appears in Plex
      4. Trigger resolve → symlink if pre-cache is enabled
    """
    await asyncio.sleep(60)   # let startup settle
    while True:
        try:
            await _check_upcoming_episodes(app)
        except Exception as e:
            log.error(f"Upcoming episode watcher: {e}", exc_info=True)
        await asyncio.sleep(900)   # every 15 minutes


async def _check_upcoming_episodes(app: FastAPI):
    """
    Two-phase check:
    Phase 1 — Refresh upcoming list from Overseerr/TMDB for all library series.
    Phase 2 — For any episode whose air_date has passed, index + create placeholder.
    """
    db:  CacheDB        = app.state.db
    lm:  LibraryManager = app.state.library
    hi:  HashIndex      = getattr(app.state, "hash_index", None)
    alldebrid           = app.state.alldebrid

    if not db or not lm or not hi or not alldebrid:
        return

    today = __import__('datetime').date.today().isoformat()

    # ── Phase 1: Refresh upcoming list ────────────────────────────────────────
    series_list = db.fake_library_list(media_type="series")
    for entry in series_list:
        sonarr_id = entry.get("sonarr_id")
        title     = entry["title"]
        year      = entry.get("year")
        if not sonarr_id:
            continue
        try:
            # Fetch ALL episodes including unreleased to track upcoming ones
            all_eps = await lm.get_episodes(sonarr_id, include_unreleased=False)
            for ep in all_eps:
                air_date = ep.get("air_date", "")
                if not air_date or air_date <= today:
                    continue   # already aired — not upcoming
                db.upsert_upcoming(
                    title=title, year=year, sonarr_id=sonarr_id,
                    season=ep["season"], episode=ep["episode"],
                    air_date=air_date,
                )
        except Exception as e:
            log.debug(f"Upcoming refresh {title!r}: {e}")

    # ── Phase 2: Process newly-aired episodes ─────────────────────────────────
    due = db.get_due_upcoming()
    if not due:
        return

    log.info(f"📅 {len(due)} episode(s) newly aired — indexing")
    settings         = db.get_all_settings()
    preferred_quality = settings.get("series_preferred_quality", "1080p")
    fallback_any      = settings.get("series_fallback_any_quality", "true") == "true"
    precache_enabled  = settings.get("precache_enabled", "true") != "false"

    import re as _re

    for ep in due:
        title   = ep["title"]
        year    = ep.get("year")
        season  = ep["season"]
        episode = ep["episode"]
        sn_str  = f"S{season:02d}E{episode:02d}"
        log.info(f"📅 New episode aired: {title!r} {sn_str} (air_date={ep['air_date']})")

        try:
            # Search AllDebrid — season pack first, then episode
            cached = 0
            for strategy in ("season_pack", "episode"):
                results = await alldebrid.search_cached(
                    title=title, media_type="episode", year=year,
                    season=season, episode=episode,
                    strategy=strategy,
                    preferred_quality=preferred_quality,
                    fallback_any=fallback_any,
                )
                for r in results:
                    m = _re.search(r"btih:([a-fA-F0-9]{40})", r.get("magnet",""), _re.I)
                    if not m:
                        continue
                    is_pack = not _re.search(r"S\d{2}E\d{2}", r.get("name",""), _re.I)
                    hi.upsert(
                        media_type="season" if is_pack else "episode",
                        title=title, year=year,
                        season=season, episode=None if is_pack else episode,
                        info_hash=m.group(1).lower(), magnet=r["magnet"],
                        torrent_name=r.get("name",""),
                        quality=r.get("quality","unknown"),
                        strategy=strategy, is_cached=True,
                    )
                    cached += 1
                if cached:
                    break

            db.mark_upcoming_indexed(title, season, episode)

            # Only create placeholder if a cached hash was found in the index
            if cached > 0:
                lm_obj: LibraryManager = getattr(app.state, "library", None)
                if lm_obj and lm_obj.plex_root:
                    ep_obj = {"season": season, "episode": episode, "air_date": ep["air_date"]}
                    if not _placeholder_allowed(app, "episode", title, year, season, episode, ep.get("air_date")):
                        log.info(f"📅 {title!r} {sn_str} cached search did not produce a valid released hash-index hit — no placeholder")
                        continue
                    paths = lm_obj.create_fake_episodes(title, year, [], [ep_obj])
                    if paths:
                        log.info(f"📅 Placeholder created: {title!r} {sn_str}")
                        db.mark_upcoming_placeholder(title, season, episode)
            else:
                log.info(f"📅 {title!r} {sn_str} aired but no cached torrent yet — no placeholder")

            # Never resolve here — symlink on play only
            # _precache_resolve now only writes placeholder, which is already done above

        except Exception as e:
            log.error(f"Upcoming episode processing {title!r} {sn_str}: {e}", exc_info=True)

    log.info(f"📅 Upcoming episode check done: {len(due)} processed")


async def _episode_sync_loop(app: FastAPI):
    """Run at startup (+30s) and hourly — audit episode placeholders against TMDB."""
    await asyncio.sleep(30)
    while True:
        try:   await _run_episode_sync(app)
        except Exception as e: log.error(f"Episode sync: {e}")
        await asyncio.sleep(3600)


async def _run_episode_sync(app: FastAPI):
    lm  = app.state.library
    db  = app.state.db
    s   = app.state.settings
    if not lm or not s.PLEX_ROOT: return

    lm.invalidate_cache()
    series_list        = await lm.get_sonarr_series(force=True)
    added_series       = [r for r in db.fake_library_list() if r["media_type"] == "series"]
    include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"
    total_added = total_removed = 0

    # ── Audit plex-strm/movies — remove folders not in fake_library ───────────
    added_movies = {r["title"].lower() for r in db.fake_library_list() if r["media_type"] == "movie"}
    movies_root  = Path(s.PLEX_ROOT) / "movies"
    if movies_root.exists():
        for folder in movies_root.iterdir():
            if not folder.is_dir(): continue
            # Extract title from "Title (Year)" folder name
            folder_title = folder.name.rsplit(" (", 1)[0].lower()
            if folder_title not in added_movies:
                import shutil as _shutil
                _shutil.rmtree(folder, ignore_errors=True)
                log.info(f"🗑️  Removed stale movie folder: {folder.name}")

    # ── Audit plex-strm/tv — remove folders not in fake_library ──────────────
    added_tv  = {r["title"].lower() for r in db.fake_library_list() if r["media_type"] == "series"}
    tv_root   = Path(s.PLEX_ROOT) / "tv"
    if tv_root.exists():
        for folder in tv_root.iterdir():
            if not folder.is_dir(): continue
            if folder.name.lower() not in added_tv:
                import shutil as _shutil
                _shutil.rmtree(folder, ignore_errors=True)
                log.info(f"🗑️  Removed stale TV folder: {folder.name}")

    for entry in added_series:
        title     = entry["title"]
        sonarr_id = entry.get("sonarr_id")
        year      = entry.get("year")
        if not sonarr_id: continue

        updated = next((s for s in series_list if s.get("id") == sonarr_id), None)
        if not updated: continue

        requested_seasons = updated.get("requested_seasons", [])
        result = await lm.sync_series_episodes(title, sonarr_id, year, include_unreleased,
                                                requested_seasons=requested_seasons)
        total_added   += result.get("added", 0)
        total_removed += result.get("removed", 0)

        # Audit: ensure every expected episode has placeholder or symlink
        try:
            all_eps = await lm.get_episodes(sonarr_id,
                                                    include_unreleased=include_unreleased,
                                                    requested_seasons=requested_seasons or None)
            by_season: dict[int, set] = {}
            for ep in all_eps:
                by_season.setdefault(ep["season"], set()).add(ep["episode"])

            show_folder = Path(s.PLEX_ROOT) / "tv" / title
            for sn, ep_nums in by_season.items():
                sf = show_folder / f"Season {sn:02d}"
                sf.mkdir(parents=True, exist_ok=True)
                on_mp4 = set(); on_sym = set()
                if sf.exists():
                    for f in sf.iterdir():
                        m = re.search(rf"S{sn:02d}E(\d{{2}})", f.name, re.I)
                        if m:
                            n = int(m.group(1))
                            if f.is_symlink(): on_sym.add(n)
                            elif f.suffix == ".mp4": on_mp4.add(n)
                covered = on_mp4 | on_sym
                for ep_n in on_mp4 - ep_nums:
                    ph = sf / f"{title} - S{sn:02d}E{ep_n:02d}.mp4"
                    if ph.exists() and not ph.is_symlink():
                        ph.unlink(missing_ok=True)
                        total_removed += 1
        except Exception as e:
            log.debug(f"Audit {title}: {e}")

    if total_added or total_removed:
        log.info(f"🔄 Episode sync: +{total_added} placeholders, -{total_removed} removed")
    else:
        log.info("🔄 Episode sync: all correct")


async def _sync_all_series_episodes(app: FastAPI, include_unreleased: bool):
    db = app.state.db; lm = app.state.library
    if not lm: return
    for entry in db.fake_library_list(media_type="series"):
        sid = entry.get("sonarr_id")
        if sid:
            await lm.sync_series_episodes(entry["title"], sid, entry.get("year"), include_unreleased)


async def _load_all_torrents(app: FastAPI):
    await asyncio.sleep(2)
    alldebrid = app.state.alldebrid
    s = app.state.settings
    if not alldebrid or not FUSE_AVAILABLE or not getattr(app.state, "fuse_thread", None):
        return
    try:
        torrents = await alldebrid.get_all_torrents()
        # Build hash → torrent map for reliable lookup on restart
        hash_map: dict[str, dict] = {}  # info_hash → {name, folder, files}
        for t in torrents:
            files       = t["files"]
            folder_name = t["name"]
            if files:
                stem = Path(files[0]["n"]).stem
                if stem and folder_name and stem.startswith(folder_name.rstrip("-")):
                    folder_name = stem
            register_torrent(folder_name, files)
            t["_folder"] = folder_name
            # Store by hash for reliable restart recovery
            h = t.get("hash", "").lower()
            if h:
                hash_map[h] = {"name": t["name"], "folder": folder_name, "files": files}

        log.info(f"✅ {len(torrents)} torrents loaded into FUSE")
        # Give lazy FUSE/rclone style mounts a short grace period before any
        # symlink verification.  This prevents restart races where valid Plex
        # links look broken for a few seconds and get touched too early.
        await asyncio.sleep(5)
        if s.PLEX_ROOT:
            _restore_symlinks(app, hash_map)
            # Second pass: scan the live FUSE registry and auto-match every
            # movie / episode already known to Debridarr. This repairs the
            # common restart case where Plex symlinks were removed or DB
            # entries were demoted, but the files still exist in the FUSE mount.
            _automatch_symlinks_from_fuse(app, log_prefix="[STARTUP-FUSE]")
    except Exception as e:
        log.error(f"_load_all_torrents: {e}", exc_info=True)



def _fuse_mount_ready_for_symlink_repair(app: FastAPI | None, min_registered: int = 0) -> bool:
    """Return True only when FUSE is far enough along for safe symlink repair.

    A common restart race is:
      Debridarr starts -> repair scans symlinks -> FUSE/AllDebrid registry is not
      populated yet -> broken target checks fail -> old code deletes links.

    Stable Plex paths must not be removed just because the remote mount is still
    warming up.  This helper is intentionally conservative: if FUSE is disabled
    or not started, repair should keep existing symlink nodes and retry later.
    """
    try:
        if app is None or not FUSE_AVAILABLE:
            return False
        s = getattr(app.state, "settings", None)
        if not s or not getattr(app.state, "fuse_thread", None):
            return False
        root = Path(getattr(s, "FUSE_SYMLINK_ROOT", "") or getattr(s, "FUSE_MOUNT", "") or "/")
        if not root.exists():
            return False
        # If the FUSE registry has entries, repair can safely trust registered
        # torrent/file mappings even when individual lazy targets have not been
        # opened by the OS yet.
        try:
            reg = globals().get("_fuse_registry") or globals().get("FUSE_REGISTRY")
            if isinstance(reg, dict) and len(reg) >= min_registered:
                return True
        except Exception:
            pass
        return True
    except Exception:
        return False

def _restore_symlinks(app, hash_map: dict = None):
    """
    Restore symlinks on startup using the unified reconcile engine.
    Called after _load_all_torrents has populated the FUSE hash_map.
    """
    db = app.state.db
    s  = app.state.settings
    if not s.PLEX_ROOT:
        return
    if _on_play_symlinks_only(app):
        log.info("▶️  Startup symlink verification running in stable on-play mode — existing links are repaired, new missing links are not aggressively cleaned")
    trusted, restored, missing = _reconcile_symlinks(app, hash_map or {}, log_prefix="[STARTUP]")
    log.info(f"✅ Startup symlinks: {trusted} trusted, {restored} restored, {missing} missing")


def _reconcile_symlinks(app, hash_map: dict, log_prefix: str = "") -> tuple[int, int, int]:
    """
    Unified symlink reconciliation engine.

    For every DB entry with status=cached:

    1. STRM_PATH EXISTS + IS SYMLINK
       a. Target registered in FUSE → trusted, refresh TTL
       b. Target not in FUSE but hash in hash_map → re-point symlink to new FUSE path
       c. Neither → keep symlink node/path stable and queue repair

    2. STRM_PATH MISSING OR NOT A SYMLINK
       a. Hash in hash_map → create symlink from scratch
       b. Title fuzzy match in FUSE → create symlink
       c. Neither → keep Plex path stable and queue repair; do not delete on boot

    3. DB ENTRY HAS NO STRM_PATH
       a. Hash in hash_map → create symlink, update DB
       b. Title fuzzy match → create symlink, update DB
       c. Neither → no placeholder (has never been resolved)

    Also audits plex-strm/movies and plex-strm/tv:
    - Removes orphan folders for titles not in fake_library
    - Removes orphan .mp4 placeholders for episodes not in DB

    Returns (trusted, restored, missing).
    """
    import re as _re
    db    = app.state.db
    s     = app.state.settings
    fuse_thread = getattr(app.state, "fuse_thread", None)

    trusted = restored = missing = 0
    needs_resolve: list[dict] = []

    all_cached = [e for e in db.list_all() if e["status"] == "cached"]

    for entry in all_cached:
        ck     = entry["cache_key"]
        strm   = entry.get("strm_path")
        magnet = entry.get("magnet_link", "")
        title  = entry["title"]
        year   = entry.get("year")
        season = entry.get("season")
        episode= entry.get("episode")
        mtype  = entry["media_type"]

        # Resolve info_hash from magnet
        m      = _re.search(r"btih:([a-fA-F0-9]{40})", magnet or "", _re.I)
        ihash  = m.group(1).lower() if m else None
        td     = hash_map.get(ihash) if ihash else None  # torrent data from AllDebrid

        resolved = False

        # ── Case 1: strm_path points to an existing symlink ─────────────────
        if strm and FUSE_AVAILABLE and fuse_thread:
            p = Path(strm)
            if p.is_symlink():
                target = str(p.readlink())
                if s.FUSE_SYMLINK_ROOT in target:
                    rel   = target.replace(s.FUSE_SYMLINK_ROOT, "").lstrip("/")
                    parts = rel.split("/", 1)
                    if len(parts) == 2 and get_torrent_file(parts[0], parts[1]):
                        # FUSE has this torrent registered — symlink is good
                        trusted += 1
                        db.refresh_ttl(ck)
                        resolved = True
                    elif td:
                        # FUSE doesn't have it registered but we have the torrent data
                        # Re-register and re-point the symlink
                        register_torrent(td["folder"], td["files"])
                        tf = _pick_file(td["files"], entry)
                        if tf:
                            new_target = get_fuse_path(td["folder"], tf["n"], s.FUSE_SYMLINK_ROOT)
                            p.unlink(missing_ok=True)
                            p.symlink_to(new_target)
                            db.update_cached(ck, magnet, entry.get("stream_url",""),
                                             td["folder"], entry.get("quality","unknown"), str(p))
                            trusted += 1
                            resolved = True
                    else:
                        # Symlink node exists but the target is not currently in the
                        # FUSE registry.  On restart this is usually a FUSE warm-up
                        # race, not proof the link is bad.  Keep the Plex path stable
                        # and queue stable repair instead of deleting or demoting it.
                        needs_resolve.append(entry)
                        trusted += 1
                        resolved = True
                elif p.exists():
                    # Symlink to non-FUSE path (strm file) — valid
                    trusted += 1
                    db.refresh_ttl(ck)
                    resolved = True

        if resolved:
            continue

        # ── Case 2 & 3: no valid symlink — create one ────────────────────────
        if not FUSE_AVAILABLE or not fuse_thread or not s.PLEX_ROOT or not _fuse_mount_ready_for_symlink_repair(app):
            # FUSE unavailable or still warming up — never delete/rewrite links on
            # startup. Keep the cache row and retry in the background verifier.
            needs_resolve.append(entry)
            missing += 1
            continue

        torrent_data = td
        if not torrent_data:
            # No hash match — try fuzzy FUSE search
            fuse_match = _find_in_fuse(title, year, season, episode)
            if fuse_match:
                tname, fname, _ = fuse_match
                torrent_data = {"folder": tname, "files": [{"n": fname, "l": "", "s": 0}]}

        if torrent_data:
            tf = _pick_file(torrent_data["files"], entry)
            if tf:
                if torrent_data.get("folder"):
                    register_torrent(torrent_data["folder"], torrent_data["files"])
                fuse_virtual = get_fuse_path(torrent_data["folder"], tf["n"], s.FUSE_SYMLINK_ROOT)
                link = _make_plex_symlink(ck, title, year, season, episode,
                                          mtype, s.PLEX_ROOT, fuse_virtual, tf["n"], app=app)
                if link:
                    db.update_cached(ck, magnet, entry.get("stream_url",""),
                                     torrent_data["folder"], entry.get("quality","unknown"), str(link))
                    log.info(f"{log_prefix} Restored: {ck}")
                    restored += 1
                    continue

        # ── Case: truly missing/broken — keep Plex path stable and queue repair ─
        # Do not restore placeholders or demote this cached entry. A replacement
        # cached torrent may exist in FUSE/HashIndex/search; the async repair
        # path will atomically swap the symlink target. Only retention expiry is
        # allowed to remove a dead symlink.
        needs_resolve.append(entry)
        missing += 1

    # Queue stable repairs for missing entries (with stagger to avoid hammering AD).
    async def _queue_missing():
        for i, entry in enumerate(needs_resolve):
            await asyncio.sleep(i * 3)
            await _stable_repair_symlink(app, entry, reason="reconcile")

    if needs_resolve:
        log.info(f"{log_prefix} {len(needs_resolve)} entries need stable repair — queuing")
        try:
            asyncio.create_task(_queue_missing())
        except RuntimeError:
            pass  # No event loop yet (called from sync context at startup)

    return trusted, restored, missing


def _pick_file(files: list, entry: dict) -> Optional[dict]:
    """Pick the right file from a torrent for this DB entry."""
    season  = entry.get("season")
    episode = entry.get("episode")
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}

    if season and episode:
        se = f"S{season:02d}E{episode:02d}".upper()
        for f in files:
            if se in f.get("n", "").upper() and any(f["n"].lower().endswith(e) for e in video_exts):
                return f

    # Fallback: largest video file
    videos = [f for f in files if any(f.get("n","").lower().endswith(e) for e in video_exts)]
    return max(videos, key=lambda f: f.get("s", 0)) if videos else None


def _media_words(value: str) -> list[str]:
    """Normalise titles/releases for fuzzy matching without external deps."""
    value = (value or "").lower().replace("'", "").replace("’", "")
    value = re.sub(r"[._\-\[\]\(\){}]+", " ", value)
    value = re.sub(r"\b(19|20)\d{2}\b", " ", value)
    value = re.sub(r"\b(2160p|1080p|720p|480p|4k|uhd|hdr|dv|web|webrip|webdl|bluray|brrip|x264|x265|h264|h265|hevc|aac|dts|atmos|proper|repack)\b", " ", value)
    return [w for w in re.findall(r"[a-z0-9]+", value) if len(w) > 1]


def _title_matches_release(title: str, release_text: str) -> bool:
    words = _media_words(title)
    if not words:
        return False
    hay = set(_media_words(release_text))
    # Require all important title words. For one-word titles this is exact-ish;
    # for longer titles this avoids matching random season packs.
    return all(w in hay for w in words)


def _automatch_symlinks_from_fuse(app, log_prefix: str = "[FUSE-AUTOMATCH]") -> tuple[int, int, int]:
    """
    Rebuild Plex symlinks by scanning the live FUSE registry.

    This is intentionally independent of the old strm_path. On restart the
    symlink in plex-strm may be gone, stale, or the DB row may have been marked
    not_found, while the real torrent files are still available in FUSE. We scan
    every registered FUSE video and match it back to known movie/episode cache
    rows, then recreate the symlink and promote the row to cached.

    Returns (created, already_valid, unmatched_fuse_files).
    """
    if not FUSE_AVAILABLE or not getattr(app.state, "fuse_thread", None):
        return (0, 0, 0)
    if _on_play_symlinks_only(app):
        log.info(f"{log_prefix} skipped — symlinks are created only on Plex play")
        return (0, 0, 0)

    db = app.state.db
    s = app.state.settings
    if not db or not s.PLEX_ROOT or not s.FUSE_SYMLINK_ROOT:
        return (0, 0, 0)

    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
    rows = db.list_all()

    # Do not touch removed library items. Cache rows can linger, so restrict to
    # titles still present in the fake library when possible.
    library_titles = {
        (r.get("media_type"), (r.get("title") or "").lower(), r.get("year"))
        for r in db.fake_library_list()
    }

    movie_rows = []
    episode_rows = []
    for r in rows:
        if r.get("media_type") == "movie":
            if library_titles and ("movie", (r.get("title") or "").lower(), r.get("year")) not in library_titles:
                continue
            movie_rows.append(r)
        elif r.get("media_type") == "episode" and r.get("season") and r.get("episode"):
            # Series fake_library rows often have year=None, so title match is enough.
            if library_titles and not any(mt == "series" and t == (r.get("title") or "").lower() for mt, t, _ in library_titles):
                continue
            episode_rows.append(r)

    created = already = unmatched = 0
    used_cache_keys: set[str] = set()

    for torrent in list_torrents():
        try:
            files = list_files(torrent)
        except Exception:
            continue
        for filename in files:
            if not any(filename.lower().endswith(ext) for ext in video_exts):
                continue

            release_text = f"{torrent} {filename}"
            fuse_path = str(get_fuse_path(torrent, filename, s.FUSE_SYMLINK_ROOT))
            entry = None

            se = _parse_season_episode(filename) or _parse_season_episode(torrent)
            if se:
                sn, en = se
                candidates = [
                    e for e in episode_rows
                    if e.get("season") == sn
                    and e.get("episode") == en
                    and e.get("cache_key") not in used_cache_keys
                    and _title_matches_release(e.get("title", ""), release_text)
                ]
                if candidates:
                    entry = candidates[0]
            else:
                candidates = []
                for e in movie_rows:
                    if e.get("cache_key") in used_cache_keys:
                        continue
                    if e.get("year") and str(e.get("year")) not in release_text:
                        continue
                    if _title_matches_release(e.get("title", ""), release_text):
                        candidates.append(e)
                if candidates:
                    # Prefer rows that were already associated to this torrent, then cached rows.
                    candidates.sort(key=lambda e: (e.get("torrent_name") != torrent, e.get("status") != "cached"))
                    entry = candidates[0]

            if not entry:
                unmatched += 1
                continue

            existing = entry.get("strm_path")
            if existing:
                p = Path(existing)
                if p.is_symlink():
                    try:
                        if str(p.readlink()) == fuse_path:
                            already += 1
                            used_cache_keys.add(entry["cache_key"])
                            db.refresh_ttl(entry["cache_key"])
                            continue
                    except Exception:
                        pass

            link = _make_plex_symlink(
                entry["cache_key"], entry["title"], entry.get("year"),
                entry.get("season"), entry.get("episode"), entry["media_type"],
                s.PLEX_ROOT, fuse_path, filename,
                app=request.app if 'request' in locals() else app,
            )
            if link:
                db.update_cached(
                    entry["cache_key"], entry.get("magnet_link", ""),
                    entry.get("stream_url", ""), torrent,
                    entry.get("quality") or _detect_quality(release_text), str(link),
                )
                used_cache_keys.add(entry["cache_key"])
                created += 1
                log.info(f"{log_prefix} linked {entry['cache_key']} → {filename}")
            else:
                unmatched += 1

    log.info(f"{log_prefix} complete: created={created} already={already} unmatched_fuse_files={unmatched}")
    return created, already, unmatched


async def _plex_strm_watcher(app: FastAPI):
    """
    Watch plex-strm for file deletions using watchdog.
    When a symlink or placeholder is deleted, immediately re-create it
    via _reconcile_symlinks — no waiting for the hourly health check.

    Debounces rapid batch deletions (e.g. user deletes a season folder)
    into a single reconcile call 5 seconds after the last delete event.
    """
    s = app.state.settings
    if not s.PLEX_ROOT:
        return

    try:
        from watchdog.observers import Observer
        from watchdog.events import FileSystemEventHandler
    except ImportError:
        log.warning("watchdog not installed — plex-strm delete watcher disabled. "
                    "Add watchdog to requirements.txt")
        return

    plex_root = Path(s.PLEX_ROOT)
    if not plex_root.exists():
        log.warning(f"plex-strm watcher: {plex_root} does not exist — skipping")
        return

    # Debounce: collect deletes for 5s then reconcile once
    _pending = {"count": 0, "task": None}

    async def _debounced_reconcile():
        await asyncio.sleep(5)
        n = _pending["count"]
        _pending["count"] = 0
        _pending["task"]  = None
        log.info(f"🔁 plex-strm: {n} file(s) deleted — reconciling symlinks")
        try:
            await _check_and_repair_symlinks(app)
        except Exception as e:
            log.error(f"plex-strm watcher reconcile: {e}")

    class PlexStrmHandler(FileSystemEventHandler):
        def on_deleted(self, event):
            path = event.src_path
            # Only care about video files and symlinks, not temp/hidden files
            if any(path.endswith(ext) for ext in (".mp4", ".mkv", ".avi", ".strm")):
                _pending["count"] += 1
                # Cancel existing debounce task and start fresh
                if _pending["task"] and not _pending["task"].done():
                    _pending["task"].cancel()
                # Schedule in the asyncio event loop (watchdog runs in a thread)
                try:
                    loop = asyncio.get_event_loop()
                    # run_coroutine_threadsafe submits to the loop without blocking
                    future = asyncio.run_coroutine_threadsafe(
                        _debounced_reconcile(), loop
                    )
                    _pending["task"] = future
                except Exception:
                    pass

        def on_moved(self, event):
            """Treat moves out of plex-strm as deletions."""
            self.on_deleted(event)

    observer = Observer()
    observer.schedule(PlexStrmHandler(), str(plex_root), recursive=True)
    observer.start()
    log.info(f"👁️  Watching {plex_root} for deletions")

    try:
        while True:
            await asyncio.sleep(60)
            if not observer.is_alive():
                log.warning("plex-strm watcher died — restarting")
                observer.start()
    finally:
        observer.stop()
        observer.join()


async def _symlink_health_loop(app: FastAPI):
    # Wait for FUSE to stabilise
    prev = 0; stable = 0
    for _ in range(180):
        await asyncio.sleep(1)
        count = len(list_torrents())
        if count > 0 and count == prev:
            stable += 1
            if stable >= 5: break
        else: stable = 0
        prev = count

    log.info(f"Starting symlink health check ({prev} torrents in FUSE)")
    # Run more frequently for the first hour after startup (catch any startup gaps)
    # then settle into hourly checks
    _startup_checks = 0
    while True:
        try:   await _check_and_repair_symlinks(app)
        except Exception as e: log.error(f"Symlink health: {e}")
        _startup_checks += 1
        if _startup_checks <= 12:          # first 12 checks = 1 hour at 5min intervals
            await asyncio.sleep(300)       # every 5 minutes for first hour
        else:
            await asyncio.sleep(3600)      # then hourly


async def _check_and_repair_symlinks(app: FastAPI):
    """Hourly symlink health check using the unified reconcile engine."""
    s = app.state.settings
    if not s.PLEX_ROOT:
        return
    if _on_play_symlinks_only(app):
        log.debug("Symlink health running in stable on-play mode — verify/repair existing links only")

    hash_map: dict[str, dict] = {}
    try:
        alldebrid = app.state.alldebrid
        if alldebrid and FUSE_AVAILABLE and getattr(app.state, "fuse_thread", None):
            torrents = await alldebrid.get_all_torrents()
            for t in torrents:
                h = t.get("hash", "").lower()
                if h:
                    files  = t["files"]
                    folder = t["name"]
                    if files:
                        stem = Path(files[0]["n"]).stem
                        if stem and folder and stem.startswith(folder.rstrip("-")):
                            folder = stem
                    register_torrent(folder, files)
                    hash_map[h] = {"folder": folder, "files": files}
    except Exception as e:
        log.warning(f"Health check: failed to refresh torrent list: {e}")

    trusted, restored, missing = _reconcile_symlinks(app, hash_map, log_prefix="[HEALTH]")
    total = trusted + restored + missing
    log.info(f"\u2705 Symlink check: {trusted} OK, {restored} restored, {missing} missing / {total}")


def _find_in_fuse(title: str, year, season, episode) -> Optional[tuple]:
    """Find an already-mounted FUSE file for a movie/episode.

    On-play resolution must prefer local FUSE files before doing any live
    search. For TV episodes, do NOT require the series year in the filename:
    most scene releases are named like `Rick.and.Morty.S09E03...` and do not
    include the 2013 first-air year. Requiring the year caused the resolver to
    miss the correct mounted file and then grab the first live search result
    (for example S09E01), which was correctly refused but left playback doing
    nothing.
    """
    def norm(s):
        s = (s or "").lower().replace("'", "").replace("\u2019", "")
        s = s.replace("&", " and ")
        s = re.sub(r"[._\-]+", " ", s)
        return [w for w in s.split() if w]

    def has_episode_token(name: str, sn: int, en: int) -> bool:
        u = (name or "").upper()
        patterns = (
            rf"(?<!\d)S0*{sn}E0*{en}(?!\d)",
            rf"(?<!\d)0*{sn}X0*{en}(?!\d)",
            rf"(?<!\d){sn:02d}{en:02d}(?!\d)",
        )
        return any(re.search(p, u) for p in patterns)

    title_words = norm(title)
    if not title_words:
        return None
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}

    for torrent_name in list_torrents():
        haystack_words = norm(torrent_name)
        if not all(w in haystack_words for w in title_words):
            continue
        for fname in list_files(torrent_name):
            if not any((fname or "").lower().endswith(e) for e in video_exts):
                continue
            # Movies may need a year to avoid wrong-title matches. TV episodes
            # should not require year; season/episode is the exact identity.
            if year and not (season and episode) and str(year) not in f"{torrent_name} {fname}":
                continue
            if season and episode:
                if not has_episode_token(fname, int(season), int(episode)):
                    continue
            elif season:
                if not re.search(rf"(?<!\d)S0*{int(season)}(?!\d)", (fname or "").upper()):
                    continue
            f = get_torrent_file(torrent_name, fname)
            if f:
                return torrent_name, fname, f
    return None


def _detect_quality(name: str) -> str:
    n = name.lower()
    for q in ("2160p","4k","uhd","1080p","720p","480p"):
        if q in n: return q
    return "unknown"


def _parse_season_episode(filename: str) -> Optional[tuple[int, int]]:
    """Extract (season, episode) from a filename. Returns None if not found."""
    import re as _re
    m = _re.search(r'[Ss](\d{1,2})[Ee](\d{1,2})', filename)
    if m:
        return int(m.group(1)), int(m.group(2))
    return None


async def _validate_pack_completeness(
    app, title: str, files: list, pack_kind: str, focus_season: Optional[int] = None,
) -> tuple[bool, set, set]:
    """
    For a season or series pack hit, verify the pack actually contains every
    RELEASED episode it's supposed to. If episodes are missing, the pack is
    "incomplete" and the caller should reject it.

    Source of truth: TMDB (via _get_series_episodes_via_tmdb). All series-
    related hash-index decisions go through TMDB so we stay in sync with the
    canonical metadata source.

    Returns (is_complete, missing_pairs, found_pairs).
    - pack_kind: "season" (only validate focus_season) or "series" (all seasons).
    - focus_season: only required when pack_kind == "season".

    Falls open (returns is_complete=True) when we can't reach TMDB or the show
    isn't found. That keeps users without a TMDB key working — they just lose
    the completeness gate.
    """
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
    found: set[tuple[int, int]] = set()
    for f in files or []:
        fname = (f.get("n") or "").lower()
        if not any(fname.endswith(e) for e in video_exts):
            continue
        info = _parse_season_episode(f.get("n", ""))
        if info:
            found.add(info)

    if not found:
        return True, set(), set()

    eps = await _get_series_episodes_via_tmdb(app, title, include_unreleased=False)
    if not eps:
        # TMDB unavailable, or show not on TMDB. Don't block resolves.
        return True, set(), found

    expected: set[tuple[int, int]] = set()
    for ep in eps:
        sn = ep.get("season") or 0
        en = ep.get("episode") or 0
        if sn <= 0 or en <= 0:
            continue
        if pack_kind == "season":
            if focus_season is not None and sn == focus_season:
                expected.add((sn, en))
        else:  # series
            expected.add((sn, en))

    if not expected:
        # TMDB knows the show but no released episodes for this scope.
        return True, set(), found

    missing = expected - found
    return (len(missing) == 0), missing, found


def _symlink_pack_episodes(
    app, db, files: list, magnet_str: str, torrent_name: str, quality: str,
    title: str, year, season: int, event_episode: int,
    media_type: str, plex_root: str, debridarr_base_url: str,
    fuse_thread, fuse_symlink_root: str,
    all_seasons: bool = False,
) -> int:
    """
    For every video file in a season/series pack, create a DB cache entry
    and a Plex symlink (or .strm if FUSE is unavailable).
    Skips the episode that was already handled by the main resolve path.

    all_seasons=True  → series pack: symlink every season in the torrent.
    all_seasons=False → season pack: only symlink the requested season.

    Returns the count of additional episodes symlinked.
    """
    import re as _re
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
    count = 0
    for f in files:
        fname = f.get("n", "")
        if not any(fname.lower().endswith(e) for e in video_exts):
            continue
        ep_info = _parse_season_episode(fname)
        if not ep_info:
            continue
        ep_season, ep_episode = ep_info
        if not all_seasons and ep_season != season:
            continue              # season pack — only handle the requested season
        if ep_season == season and ep_episode == event_episode:
            continue              # already handled by main resolve path

        ad_link = f.get("l", "")
        if not ad_link:
            continue

        # Build a PlayEvent for this episode so cache_key is correct
        from app.models import PlayEvent, MediaType
        ep_event = PlayEvent(
            media_type=MediaType.episode,
            title=title, year=year,
            season=ep_season, episode=ep_episode,
        )
        ck = ep_event.cache_key()

        existing = db.get(ck)
        if existing and existing["status"] == "cached":
            log.debug(f"  Pack episode already cached: {ck}")
            continue

        # Write DB entry
        db.upsert(ck, ep_event, status="resolving")

        # Create symlink or strm
        strm_path = None
        if plex_root:
            if FUSE_AVAILABLE and fuse_thread:
                stem = Path(fname).stem
                fuse_folder = stem if (stem and torrent_name and stem.startswith(torrent_name.rstrip("-"))) else torrent_name
                fuse_virtual = get_fuse_path(fuse_folder, fname, fuse_symlink_root)
                link = _make_plex_symlink(ck, title, year, ep_season, ep_episode,
                                          media_type, plex_root, fuse_virtual, fname, app=app)
                strm_path = str(link) if link else None
            else:
                p = write_strm(cache_key=ck, title=title, year=year,
                               season=ep_season, episode=ep_episode,
                               media_type=media_type,
                               debridarr_base_url=debridarr_base_url,
                               plex_root=plex_root)
                strm_path = str(p) if p else None

        db.update_cached(ck, magnet_str, ad_link, torrent_name, quality, strm_path)
        log.info(f"  📦 Pack episode: S{ep_season:02d}E{ep_episode:02d} → {fname}")
        count += 1

    return count


# ── 3-Episode Rule: lookahead chain helpers ──────────────────────────────────
def _cached_symlink_valid(strm_path) -> bool:
    """
    Verify that a cached entry's on-disk symlink (or .strm file) is actually
    usable. The DB tracks logical state but can go stale if the symlink was
    deleted manually, the FUSE mount was remounted, the torrent was evicted
    from AllDebrid, or PLEX_ROOT changed. Without this check, Plex would
    play the tiny placeholder mp4 instead of the real media.

    Returns True iff:
      - For symlinks: the link exists AND its target resolves.
      - For regular files (.strm): the file exists.
    """
    if not strm_path:
        return False
    try:
        p = Path(strm_path)
        if p.is_symlink():
            # is_symlink() True means the link node itself is present.
            # exists() follows the link — True iff the target resolves.
            return p.exists()
        # Not a symlink — accept a regular file (.strm or migrated entry).
        return p.exists() and p.is_file()
    except Exception:
        return False


def _restore_placeholder(
    plex_root: str, media_type: str, title: str, year=None,
    season=None, episode=None, app: FastAPI | None = None, air_date: str | None = None,
) -> Optional[Path]:
    """
    Immediately restore the Plex placeholder mp4 at the canonical path for
    a media item. Used the moment we detect a missing/broken symlink — Plex
    keeps showing *something* in the library while the resolve runs (or
    even if it never does). Without this, the user sees "missing file" or
    Plex prunes the item entirely.

    Idempotent: if a usable file (symlink or placeholder) already exists
    at the target path, this is a no-op. Returns the path written, or None
    if PLEX_ROOT is unset or the params don't form a valid path.
    """
    if not plex_root or not title:
        return None
    if app is not None and not _placeholder_allowed(app, media_type, title, year, season, episode, air_date):
        log.info(f"⏭️  Placeholder blocked: {title!r} {media_type} — not released or no cached hash in index")
        return None
    try:
        if media_type == "movie":
            yp     = f" ({year})" if year else ""
            folder = Path(plex_root) / "movies" / f"{title}{yp}"
            ph     = folder / f"{title}{yp}.mp4"
        elif media_type == "episode" and season and episode:
            sf     = f"Season {season:02d}"
            folder = Path(plex_root) / "tv" / title / sf
            ph     = folder / f"{title} - S{season:02d}E{episode:02d}.mp4"
        else:
            return None

        folder.mkdir(parents=True, exist_ok=True)
        # If there's already a usable file (real symlink or existing placeholder)
        # we don't overwrite — _make_plex_symlink may have a real symlink waiting.
        # We only write if the canonical placeholder path is empty.
        if not ph.exists() and not ph.is_symlink():
            ph.write_bytes(_FAKE_MP4)
            log.info(f"📺 Placeholder restored: {ph}")
        return ph
    except Exception as e:
        log.debug(f"_restore_placeholder failed {title} S{season}E{episode}: {e}")
        return None


def _restore_placeholder_for_entry(plex_root: str, entry: dict, app: FastAPI | None = None) -> Optional[Path]:
    """Convenience: pull params off a DB row and restore the placeholder."""
    return _restore_placeholder(
        plex_root,
        entry.get("media_type") or "",
        entry.get("title") or "",
        year=entry.get("year"),
        season=entry.get("season"),
        episode=entry.get("episode"),
        app=app,
        air_date=entry.get("air_date"),
    )

def _cache_entry_expired(entry: dict) -> bool:
    """True when a cached symlink has aged past retention."""
    try:
        exp = entry.get("expires_at")
        if not exp:
            return False
        return datetime.fromisoformat(str(exp).replace("Z", "+00:00")).replace(tzinfo=None) < datetime.utcnow()
    except Exception:
        return False


async def _stable_repair_symlink(app: FastAPI, entry: dict, reason: str = "") -> str:
    """Repair a cached symlink without destabilising Plex paths.

    The stable repair rule is:
      1. If the symlink target is valid, keep it and refresh retention.
      2. If broken/missing, first look in the existing FUSE registry.
      3. Then look in the cached Hash Index.
      4. Then run an exact cached resolve/search for a replacement torrent.
      5. Only remove the local path if retention expired and no repair worked.

    We intentionally do NOT restore placeholders or mark the row not_found during
    repair. Plex keeps the same media path while the target is swapped.
    """
    db: CacheDB = app.state.db
    s = app.state.settings
    ck = entry.get("cache_key")
    mtype = entry.get("media_type")
    title = entry.get("title") or ""
    year = entry.get("year")
    season = entry.get("season")
    episode = entry.get("episode")
    strm = entry.get("strm_path")

    if strm and _cached_symlink_valid(strm):
        try:
            db.refresh_ttl(ck)
        except Exception:
            pass
        return "valid"

    if not _fuse_mount_ready_for_symlink_repair(app):
        # During restart/remount, broken-target checks are unreliable. Do not
        # delete, demote, or restore placeholders. Keep the Plex path and retry.
        log.info(f"🔧 Stable repair delayed for {ck}: FUSE not ready")
        return "delayed_fuse_not_ready"

    # 1) Existing FUSE registry first — fastest and avoids external searches.
    try:
        fuse_match = _find_in_fuse(title, year, season, episode)
        if fuse_match and s.PLEX_ROOT:
            tname, fname, _ = fuse_match
            target = get_fuse_path(tname, fname, s.FUSE_SYMLINK_ROOT)
            link = _make_plex_symlink(
                ck, title, year, season, episode, mtype,
                s.PLEX_ROOT, target, Path(fname).name, app=app,
            )
            if link and link.is_symlink():
                db.update_cached(
                    ck,
                    entry.get("magnet_link") or "",
                    entry.get("stream_url") or "",
                    tname,
                    entry.get("quality") or "unknown",
                    str(link),
                )
                log.info(f"🔧 Stable repair from FUSE: {ck} → {Path(fname).name}")
                return "repaired_fuse"
    except Exception as e:
        log.debug(f"stable repair FUSE failed for {ck}: {e}")

    # 2) Cached Hash Index next — only cached rows, exact episode if TV.
    try:
        hi: HashIndex = getattr(app.state, "hash_index", None)
        alldebrid = getattr(app.state, "alldebrid", None)
        if hi and alldebrid and s.PLEX_ROOT:
            candidates = hi.lookup(title, season=season, episode=episode, cached_only=True) or []
            for row in candidates:
                if mtype == "episode":
                    if row.get("season") and int(row.get("season") or 0) != int(season or 0):
                        continue
                    if row.get("episode") and int(row.get("episode") or 0) != int(episode or 0):
                        continue
                raw = row.get("magnet") or ""
                if not raw.startswith("magnet:?xt=urn:btih:") and row.get("info_hash"):
                    raw = f"magnet:?xt=urn:btih:{row.get('info_hash')}&dn={quote(row.get('torrent_name') or '')}"
                if not raw:
                    continue
                result = await alldebrid.add_magnet(raw)
                if not result:
                    continue
                _magnet_id, files = result
                torrent_name = row.get("torrent_name") or title
                tf = _pick_file(files, entry)
                if not tf:
                    continue
                if mtype == "episode" and season and episode:
                    se = f"S{int(season):02d}E{int(episode):02d}".upper()
                    if se not in (tf.get("n") or "").upper():
                        continue
                register_torrent(torrent_name, files)
                target = get_fuse_path(torrent_name, tf.get("n"), s.FUSE_SYMLINK_ROOT)
                link = _make_plex_symlink(
                    ck, title, year, season, episode, mtype,
                    s.PLEX_ROOT, target, Path(tf.get("n") or "video.mkv").name, app=app,
                )
                if link and link.is_symlink():
                    db.update_cached(
                        ck, raw, entry.get("stream_url") or "", torrent_name,
                        row.get("quality") or entry.get("quality") or "unknown", str(link),
                    )
                    log.info(f"🔧 Stable repair from HashIndex: {ck} → {Path(tf.get('n')).name}")
                    return "repaired_hash"
    except Exception as e:
        log.debug(f"stable repair HashIndex failed for {ck}: {e}")

    # 3) Exact live cached resolve/search last. This is allowed to find a new
    # cached torrent, write it to the Hash Index, and atomically re-symlink.
    try:
        ev = PlayEvent(
            media_type=MediaType(mtype), title=title, year=year,
            season=season, episode=episode,
        )
        await resolve_and_cache(app, ev, is_user_play=False)
        refreshed = db.get(ck)
        if refreshed and _cached_symlink_valid(refreshed.get("strm_path")):
            log.info(f"🔧 Stable repair from exact search: {ck}")
            return "repaired_search"
    except Exception as e:
        log.debug(f"stable repair exact search failed for {ck}: {e}")

    # 4) Keep the path stable unless retention has expired. If expired, remove
    # the broken path so normal cleanup can reclaim it.
    if _cache_entry_expired(entry):
        try:
            p = Path(strm) if strm else None
            if p and (p.exists() or p.is_symlink()):
                p.unlink(missing_ok=True)
                log.info(f"🗑️  Stable repair failed and retention expired — removed {p}")
        except Exception as e:
            log.debug(f"stable repair expire unlink failed for {ck}: {e}")
        return "failed_expired"

    log.warning(f"⚠️  Stable repair failed for {ck}; keeping Plex path for next repair cycle")
    return "failed_kept"


# Long-lived set so fire-and-forget tasks aren't garbage-collected mid-execution.
# (Python's asyncio.create_task only keeps a weak reference — without an external
# strong reference, the loop may drop the task before it finishes. This was the
# root cause of the lookahead chain breaking partway through a binge.)
_LOOKAHEAD_TASKS: set = set()

def _spawn_lookahead(coro) -> asyncio.Task:
    """
    Schedule a fire-and-forget coroutine with a held reference so the GC can't
    drop it. The task is auto-removed from the registry on completion.
    Use this for every lookahead/cache-ahead task we schedule.
    """
    t = asyncio.create_task(coro)
    _LOOKAHEAD_TASKS.add(t)
    t.add_done_callback(_LOOKAHEAD_TASKS.discard)
    return t


async def _symlink_ahead_from_existing(
    app, db, event, existing_row: dict, lookahead: int = 3,
) -> int:
    """
    Cache-hit fast path: the played episode is already 'cached' and its DB row
    carries the pack's magnet + torrent_name. Re-use that pack's file list to
    synchronously symlink the next `lookahead` episodes — no resolve cycle,
    no extra Prowlarr/AllDebrid spam.

    Resolution order:
      1. In-process FUSE registry — zero API calls if the pack is still there.
      2. add_magnet() against the cached pack magnet — fast for already-cached
         AllDebrid torrents; just gets the file list back.
    Returns count of new symlinks created.
    """
    magnet       = existing_row.get("magnet_link") or ""
    torrent_name = existing_row.get("torrent_name") or ""
    quality      = existing_row.get("quality") or "unknown"

    if not torrent_name and not magnet:
        return 0
    if not event.season or not event.episode:
        return 0

    s = app.state.settings

    # 1) FUSE in-process registry (best case)
    files = []
    if torrent_name:
        try:
            files = get_torrent_files(torrent_name)
        except Exception:
            files = []

    # 2) Fall back to add_magnet (still cheap for already-cached AllDebrid torrents)
    if (not files or len(files) <= 1) and magnet:
        alldebrid = getattr(app.state, "alldebrid", None)
        if alldebrid and alldebrid.api_key:
            try:
                result = await alldebrid.add_magnet(magnet)
                if result:
                    _magnet_id, files = result
                    # Re-register so subsequent lookaheads on this title are free
                    if torrent_name and files:
                        try:
                            register_torrent(torrent_name, files)
                        except Exception:
                            pass
            except Exception as e:
                log.debug(f"_symlink_ahead_from_existing add_magnet: {e}")

    if not files or len(files) <= 1:
        log.debug(
            f"  📦 Fast-path lookahead: no pack files for {event.title!r} "
            f"S{event.season:02d}E{event.episode:02d} — handing to _cache_ahead"
        )
        return 0

    extra = _symlink_ahead(
        app=app, db=db, files=files,
        magnet_str=magnet, torrent_name=torrent_name, quality=quality,
        title=event.title, year=event.year,
        event_season=event.season, event_episode=event.episode,
        plex_root=s.PLEX_ROOT,
        debridarr_base_url=s.DEBRIDARR_BASE_URL,
        fuse_thread=getattr(app.state, "fuse_thread", None),
        fuse_symlink_root=s.FUSE_SYMLINK_ROOT,
        lookahead=lookahead,
    )
    if extra:
        log.info(
            f"📦 Lookahead (fast-path): {extra} episode(s) symlinked for "
            f"{event.title!r} from S{event.season:02d}E{event.episode:02d}"
        )
    return extra


async def _lookahead_chain(app, db, event, existing_row: Optional[dict] = None,
                           lookahead: int = 3, symlink_delay: int = 15,
                           cache_delay: int = 120):
    """
    Run the 3-episode rule for a play event. Two stages:

      1. Fast-path symlink-ahead (after `symlink_delay` s):
         If we have the played episode's pack info, immediately symlink the
         next `lookahead` episodes from the same pack. Cheap; no resolve cycle.

      2. Cache-ahead (after `cache_delay` s):
         Queue full resolves for any of the next `lookahead` episodes that
         the fast-path couldn't cover (cross-season, different pack, etc.).
         This safety net guarantees the user is never more than ~120 s away
         from having the next 3 cached.
    """
    if not event or event.media_type.value != "episode":
        return
    if not event.season or not event.episode:
        return

    # Stage 1 — fast symlink-ahead using existing pack.
    # On-play mode still allows this for easy bingeing: the selected episode is
    # created on play, then the next episodes are pre-symlinked shortly after.
    try:
        await asyncio.sleep(symlink_delay)
        if existing_row is None:
            existing_row = db.get(event.cache_key()) or {}
        if existing_row:
            await _symlink_ahead_from_existing(app, db, event, existing_row, lookahead=lookahead)
    except Exception as e:
        log.debug(f"_lookahead_chain stage 1: {e}")

    # Stage 2 — cache-ahead safety net (delay measured from start, not from stage 1)
    try:
        remaining = max(cache_delay - symlink_delay, 0)
        if remaining:
            await asyncio.sleep(remaining)
        await _cache_ahead(
            app=app, db=db,
            title=event.title, year=event.year,
            event_season=event.season, event_episode=event.episode,
            lookahead=lookahead,
        )
    except Exception as e:
        log.debug(f"_lookahead_chain stage 2: {e}")


async def _cache_ahead(
    app, db, title: str, year, event_season: int, event_episode: int,
    lookahead: int = 3,
):
    """
    After a play event, ensure the next `lookahead` uncached episodes are
    queued for resolve so they're instantly ready when the user gets there.
    Fires 120s after play. Crosses season boundaries automatically.

    Uses the hash index to find cached hashes and the library for episode counts.
    Skips already-cached DB entries, finds the next truly uncached ones.
    """
    from app.models import PlayEvent, MediaType

    hi: HashIndex         = getattr(app.state, "hash_index", None)
    lm: LibraryManager    = getattr(app.state, "library", None)
    if not hi:
        return

    # Episode counts per season — TMDB is authoritative. Falls back to
    # Sonarr/Overseerr if TMDB isn't configured. 50 is the safety cap so
    # we never loop forever on an unknown show.
    episode_counts: dict[int, int] = {}
    try:
        tmdb_counts = await _get_series_counts_via_tmdb(app, title, year=year)
        if tmdb_counts["source"] == "tmdb":
            episode_counts = dict(tmdb_counts["per_season"])
    except Exception as e:
        log.debug(f"_cache_ahead TMDB counts {title!r}: {e}")

    if not episode_counts and lm:
        # Sonarr fallback only when TMDB has nothing
        try:
            lib_entry = next(
                (r for r in db.fake_library_list("series")
                 if r["title"].lower() == title.lower()),
                None,
            )
            if lib_entry and lib_entry.get("sonarr_id"):
                all_eps = await lm.get_episodes(lib_entry["sonarr_id"],
                                                include_unreleased=False)
                for ep in all_eps:
                    sn = ep.get("season", 0)
                    en = ep.get("episode", 0)
                    if sn and en:
                        episode_counts[sn] = max(episode_counts.get(sn, 0), en)
        except Exception:
            pass

    def season_max(sn: int) -> int:
        return episode_counts.get(sn, 50)  # 50 = safe upper bound if unknown

    queued    = 0
    skipped   = 0  # already-cached positions within the +N window
    season    = event_season
    episode   = event_episode + 1
    positions = 0  # positions scanned in the +N window — hard cap

    while positions < lookahead:
        positions += 1

        # Cross to next season if we've passed the end of this one
        smax = season_max(season)
        if episode > smax:
            season  += 1
            episode  = 1
            # Decide whether to attempt the next season.
            #   - Sonarr knows the show structure: trust it. If next season
            #     has released episodes, proceed (live search will fill them
            #     in even if hash index doesn't have them yet).
            #   - No Sonarr data: fall back to a hash-index probe.
            should_continue = True
            if episode_counts:
                if season not in episode_counts:
                    log.debug(f"  🔥 Cache-ahead: Sonarr has no S{season:02d} — stopping")
                    should_continue = False
            else:
                if (not hi.lookup(title, season=season, episode=None, cached_only=True)
                    and not hi.lookup(title, season=season, episode=1, cached_only=True)):
                    log.debug(f"  🔥 Cache-ahead: no hash for S{season:02d} — stopping")
                    should_continue = False
            if not should_continue:
                break
            # Don't burn the position on the boundary itself; let the loop
            # retry this iteration against the new (season, episode=1).
            positions -= 1
            continue

        ep_event = PlayEvent(media_type=MediaType.episode, title=title,
                             year=year, season=season, episode=episode)
        ck       = ep_event.cache_key()
        existing = db.get(ck)

        if existing and existing.get("status") == "cached":
            # DB-cached, but only skip if the on-disk symlink is actually there.
            # Otherwise the lookahead would silently leave a broken entry in
            # the user's path. Re-queue it for resolve, just like a fresh miss.
            if _cached_symlink_valid(existing.get("strm_path")):
                skipped += 1
                episode += 1
                continue
            else:
                log.warning(
                    f"  🔥 Cache-ahead: S{season:02d}E{episode:02d} "
                    f"marked cached but symlink missing — re-queuing"
                )
                # Restore the placeholder so Plex doesn't see a hole while
                # the re-resolve task runs.
                s = app.state.settings
                try:
                    _restore_placeholder(
                        s.PLEX_ROOT, "episode", title,
                        year=year, season=season, episode=episode, app=app,
                    )
                except Exception as e:
                    log.debug(f"_cache_ahead placeholder restore: {e}")
                db.update_status(ck, "not_found")
                # fall through to the queue logic below

        # Hash index hit means fast resolve; no hit means we'll fall through
        # to FUSE / live search inside resolve_and_cache itself. Both paths
        # are fine — we queue either way so per-episode (non-pack) shows still
        # get the 3-episode rule. The wrong-season guard inside the resolve
        # paths keeps misindexed packs from creating bad symlinks.
        candidates = (
            hi.lookup(title, season=season, episode=episode, cached_only=True) or
            hi.lookup(title, season=season, episode=None,    cached_only=True)
        )

        if candidates:
            log.info(f"  🔥 Cache-ahead: queuing {title!r} S{season:02d}E{episode:02d} (hash hit)")
        else:
            log.info(f"  🔥 Cache-ahead: queuing {title!r} S{season:02d}E{episode:02d} (live search)")

        # is_user_play=False — internal resolve, do NOT trigger another
        # round of lookaheads. The chain only extends when the user
        # actually plays an episode. Keeps Plex's scanner sane.
        _spawn_lookahead(resolve_and_cache(app, ep_event, is_user_play=False))
        queued += 1
        # Either way, this position is consumed. Move on.
        episode += 1

    if queued:
        log.info(f"🔥 Cache-ahead: {queued} queued, {skipped} already-cached for "
                 f"{title!r} within +{lookahead} of S{event_season:02d}E{event_episode:02d}")



def _symlink_ahead(
    app, db, files: list, magnet_str: str, torrent_name: str, quality: str,
    title: str, year, event_season: int, event_episode: int,
    plex_root: str, debridarr_base_url: str,
    fuse_thread, fuse_symlink_root: str,
    lookahead: int = 3,
) -> int:
    """
    Smarter pack symlink — only creates symlinks for the current season,
    limited to the next `lookahead` episodes after the one being played.

    Rules:
    - Symlink event_episode+1 … event_episode+lookahead in the same season
    - If any of those episodes don't exist in the pack (season is ending),
      and a next-season file exists in the pack, symlink the first `lookahead`
      episodes of the next season instead

    Returns count of symlinks created.
    """
    import re as _re
    from app.models import PlayEvent, MediaType

    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
    count = 0

    # Build map: (season, episode) → file dict
    ep_map: dict[tuple[int,int], dict] = {}
    for f in files:
        fname = f.get("n", "")
        if not any(fname.lower().endswith(e) for e in video_exts):
            continue
        info = _parse_season_episode(fname)
        if info:
            ep_map[info] = f

    if not ep_map:
        return 0

    # Figure out how many episodes are in the current season
    current_season_eps = sorted(ep for (sn, ep) in ep_map if sn == event_season)
    next_season_eps    = sorted(ep for (sn, ep) in ep_map if sn == event_season + 1)
    season_max         = max(current_season_eps) if current_season_eps else event_episode

    # Determine target episodes: lookahead in current season
    targets: list[tuple[int, int]] = []
    for ep in range(event_episode + 1, event_episode + lookahead + 1):
        if ep <= season_max:
            targets.append((event_season, ep))
        else:
            # Episode beyond season end — pull from next season
            overflow = ep - season_max - 1
            if overflow < len(next_season_eps):
                targets.append((event_season + 1, next_season_eps[overflow]))

    # Also: if user is within `lookahead` of season end (inclusive of last
    # episode itself), pre-load start of next season from this pack.
    episodes_left_in_season = season_max - event_episode
    if 0 <= episodes_left_in_season <= lookahead and next_season_eps:
        for i, nep in enumerate(next_season_eps[:lookahead]):
            pair = (event_season + 1, nep)
            if pair not in targets:
                targets.append(pair)

    log.debug(f"📦 Lookahead targets for {title!r} from S{event_season:02d}E{event_episode:02d}: {targets}")

    for (ep_season, ep_episode) in targets:
        f = ep_map.get((ep_season, ep_episode))
        if not f:
            continue
        fname  = f.get("n", "")
        ad_link = f.get("l", "")
        if not ad_link:
            continue

        ep_event = PlayEvent(
            media_type=MediaType.episode,
            title=title, year=year,
            season=ep_season, episode=ep_episode,
        )
        ck = ep_event.cache_key()

        existing = db.get(ck)
        if existing and existing["status"] == "cached":
            log.debug(f"  📦 Already cached: {ck}")
            continue

        db.upsert(ck, ep_event, status="resolving")

        strm_path = None
        if plex_root:
            if FUSE_AVAILABLE and fuse_thread:
                stem = Path(fname).stem
                fuse_folder = (stem if (stem and torrent_name
                               and stem.startswith(torrent_name.rstrip("-")))
                               else torrent_name)
                fuse_virtual = get_fuse_path(fuse_folder, fname, fuse_symlink_root)
                link = _make_plex_symlink(ck, title, year, ep_season, ep_episode,
                                          "episode", plex_root, fuse_virtual, fname, app=app)
                strm_path = str(link) if link else None
            else:
                p = write_strm(cache_key=ck, title=title, year=year,
                               season=ep_season, episode=ep_episode,
                               media_type="episode",
                               debridarr_base_url=debridarr_base_url,
                               plex_root=plex_root)
                strm_path = str(p) if p else None

        db.update_cached(ck, magnet_str, ad_link, torrent_name, quality, strm_path)
        cross = " (next season)" if ep_season != event_season else ""
        log.info(f"  📦 Lookahead: S{ep_season:02d}E{ep_episode:02d}{cross} → {fname}")
        count += 1

    return count



async def _instant_plex_refresh(app: FastAPI, symlink_path: str | Path,
                                media_type: str, title: str = "",
                                year: int | None = None,
                                season: int | None = None,
                                episode: int | None = None) -> bool:
    """
    Fire an immediate targeted Plex folder refresh after a symlink appears.
    This avoids waiting for Plex's current full scan/metadata queue to notice
    the new file. It scans only the movie folder or show folder.
    """
    if not app or not symlink_path:
        return False

    db: CacheDB = getattr(app.state, "db", None)
    if not db:
        return False

    if db.get_setting("instant_plex_refresh", "true").lower() not in ("1", "true", "yes", "on"):
        return False

    plex_url = (db.get_setting("PLEX_URL", "") or db.get_setting("plex_url", "")).strip().rstrip("/")
    plex_token = (db.get_setting("PLEX_TOKEN", "") or db.get_setting("plex_token", "")).strip()
    if not plex_url or not plex_token:
        log.debug("Instant Plex refresh skipped: PLEX_URL or PLEX_TOKEN not set")
        return False

    section = ""
    if media_type == "movie":
        section = (db.get_setting("PLEX_MOVIE_SECTION_ID", "") or db.get_setting("plex_movie_section_id", "")).strip()
    else:
        section = (db.get_setting("PLEX_TV_SECTION_ID", "") or db.get_setting("plex_tv_section_id", "")).strip()
    if not section:
        log.debug(f"Instant Plex refresh skipped: no Plex section id for media_type={media_type!r}")
        return False

    # Plex wants the library path as Plex sees it. In a normal shared-volume
    # setup this is the same PLEX_ROOT path Debridarr just wrote to.
    sp = Path(symlink_path)
    refresh_path = sp.parent
    if media_type != "movie":
        # Refresh the show folder instead of just Season XX so Plex notices new
        # episode files reliably even while another scan/metadata task is busy.
        try:
            if refresh_path.name.lower().startswith("season "):
                refresh_path = refresh_path.parent
        except Exception:
            pass

    try:
        import httpx
        url = f"{plex_url}/library/sections/{quote(str(section), safe='')}/refresh"
        async with httpx.AsyncClient(timeout=8.0) as client:
            r = await client.get(url, params={"path": str(refresh_path), "X-Plex-Token": plex_token})
        if 200 <= r.status_code < 300:
            log.info(f"⚡ Plex targeted refresh queued: section={section} path={refresh_path}")
            return True
        log.warning(f"Plex targeted refresh failed: HTTP {r.status_code} path={refresh_path}")
    except Exception as e:
        log.warning(f"Plex targeted refresh error for {symlink_path}: {e}")
    return False


def _queue_instant_plex_refresh(app: FastAPI | None, symlink_path: str | Path,
                                media_type: str, title: str = "",
                                year: int | None = None,
                                season: int | None = None,
                                episode: int | None = None):
    """Best-effort fire-and-forget wrapper safe from sync code paths."""
    if not app:
        return
    try:
        loop = asyncio.get_running_loop()
        loop.create_task(_instant_plex_refresh(app, symlink_path, media_type, title, year, season, episode))
    except RuntimeError:
        # Startup sync context: skip rather than blocking startup.
        pass

def _make_plex_symlink(cache_key, title, year, season, episode,
                       media_type, plex_root, target, video_name,
                       app: FastAPI | None = None) -> Optional[Path]:
    """Placeholder-first symlink creation. Never leaves Plex with an empty slot."""
    if media_type == "movie":
        yp     = f" ({year})" if year else ""
        folder = Path(plex_root) / "movies" / f"{title}{yp}"
        ph     = folder / f"{title}{yp}.mp4"
    else:
        sf     = f"Season {season:02d}" if season else "Season 00"
        folder = Path(plex_root) / "tv" / title / sf
        se     = f"S{season:02d}E{episode:02d}" if (season and episode) else "S00E00"
        ph     = folder / f"{title} - {se}.mp4"

    try:
        folder.mkdir(parents=True, exist_ok=True)
        lm = getattr(app.state, "library", None) if app is not None else None
        if lm:
            if media_type == "movie":
                lm.create_movie_nfo(title, year)
            elif season and episode:
                lm.create_tvshow_nfo(title, year)
                lm.create_episode_nfo(title, int(season), int(episode))
        if not ph.exists() and not ph.is_symlink():
            ph.write_bytes(_FAKE_MP4)
    except Exception as e:
        log.error(f"Placeholder/NFO write {cache_key}: {e}")

    try:
        # Remove stale symlinks for this episode
        if media_type == "movie":
            for f in folder.iterdir():
                if f.is_symlink() and f.suffix in (".mkv",".mp4",".avi",".mov",".m4v"):
                    f.unlink(missing_ok=True)
        elif season and episode:
            se_pat = f"S{season:02d}E{episode:02d}".upper()
            for f in folder.iterdir():
                if f.is_symlink() and se_pat in f.name.upper():
                    f.unlink(missing_ok=True)

        link = folder / video_name
        tmp = folder / f".{video_name}.tmp-{int(time.time() * 1000)}"
        if tmp.is_symlink() or tmp.exists():
            tmp.unlink(missing_ok=True)
        tmp.symlink_to(target)
        if link.is_symlink() or link.exists():
            link.unlink(missing_ok=True)
        os_replace = __import__("os").replace
        os_replace(tmp, link)

        if link.is_symlink():
            if ph.exists() and not ph.is_symlink(): ph.unlink(missing_ok=True)
            log.info(f"🔗 Symlink: {link.name} → {target}")
            _queue_instant_plex_refresh(app, link, media_type, title, year, season, episode)
            return link
        else:
            if not ph.exists(): ph.write_bytes(_FAKE_MP4)
            return None
    except Exception as e:
        log.error(f"symlink {cache_key}: {e}")
        try:
            if not ph.exists() and not ph.is_symlink():
                folder.mkdir(parents=True, exist_ok=True)
                ph.write_bytes(_FAKE_MP4)
        except Exception: pass
        return None


async def _verify_episode_with_tmdb(tmdb_id, tvdb_id, season, episode, title, tmdb_key=""):
    if not tmdb_key: return season, episode
    import httpx as _hx
    try:
        if tvdb_id:
            async with _hx.AsyncClient(timeout=10) as c:
                r = await c.get(f"https://api.themoviedb.org/3/find/{tvdb_id}",
                                params={"api_key": tmdb_key, "external_source": "tvdb_id"})
                if r.status_code == 200:
                    eps = r.json().get("tv_episode_results", [])
                    if eps:
                        e   = eps[0]
                        ts  = e.get("season_number", season)
                        tep = e.get("episode_number", episode)
                        if ts != season or tep != episode:
                            log.info(f"TMDB corrected {title} S{season:02d}E{episode:02d} → S{ts:02d}E{tep:02d}")
                        return ts, tep
    except Exception as e:
        log.debug(f"TMDB lookup {title}: {e}")
    return season, episode


# ── TMDB series episode catalog ───────────────────────────────────────────────
# Single source of truth for "what episodes exist for this show" used by the
# hash-index UI, pack-completeness validation, and anywhere else series data
# is consulted. Bypasses Sonarr/Overseerr entirely so the system stays in sync
# with what TMDB reports. Caches in-process for 6h.

_TMDB_EP_CACHE: dict[str, tuple[float, list[dict]]] = {}
_TMDB_EP_CACHE_TTL = 6 * 3600
_TMDB_RESOLVE_ID_CACHE: dict[str, tuple[float, Optional[int]]] = {}


async def _tmdb_resolve_series_id(title: str, year, tmdb_key: str) -> Optional[int]:
    """
    Best-effort: turn a title (+ optional year) into a TMDB series id by
    searching `/search/tv`. Used only when the library entry has no tmdb_id
    yet. Cached for 6h.
    """
    if not tmdb_key or not title:
        return None
    key = f"{title.lower().strip()}|{year or ''}"
    now = time.time()
    hit = _TMDB_RESOLVE_ID_CACHE.get(key)
    if hit and now - hit[0] < _TMDB_EP_CACHE_TTL:
        return hit[1]

    import httpx as _hx
    try:
        async with _hx.AsyncClient(timeout=10) as c:
            params = {"api_key": tmdb_key, "query": title}
            if year:
                params["first_air_date_year"] = str(year)
            r = await c.get("https://api.themoviedb.org/3/search/tv", params=params)
            if r.status_code != 200:
                _TMDB_RESOLVE_ID_CACHE[key] = (now, None)
                return None
            results = (r.json() or {}).get("results", []) or []
            # Prefer exact-title match, then first result.
            tl = title.lower().strip()
            picked = next(
                (x for x in results if (x.get("name") or "").lower().strip() == tl),
                results[0] if results else None,
            )
            tmdb_id = picked.get("id") if picked else None
            _TMDB_RESOLVE_ID_CACHE[key] = (now, tmdb_id)
            return tmdb_id
    except Exception as e:
        log.debug(f"_tmdb_resolve_series_id {title!r}: {e}")
        return None


async def _tmdb_get_series_episodes(
    tmdb_id: int, tmdb_key: str, include_unreleased: bool = False,
) -> list[dict]:
    """
    Fetch the complete episode catalog for a TMDB series via direct
    TMDB API calls. Returns a list of dicts:
        [{ "season": 1, "episode": 1, "title": "Pilot",
           "air_date": "2024-01-15", "tmdb_id": <int> }, ...]
    Skips Season 0 (specials). Released-by-default; pass include_unreleased=True
    for the full catalog (used by missing-list previews).
    Cached in-process for 6h.
    """
    if not tmdb_id or not tmdb_key:
        return []

    key = f"{tmdb_id}|{int(bool(include_unreleased))}"
    now = time.time()
    hit = _TMDB_EP_CACHE.get(key)
    if hit and now - hit[0] < _TMDB_EP_CACHE_TTL:
        return list(hit[1])

    import httpx as _hx
    out: list[dict] = []
    today = datetime.utcnow().date().isoformat()

    try:
        async with _hx.AsyncClient(timeout=15) as c:
            # 1) Get the show's season list.
            r = await c.get(
                f"https://api.themoviedb.org/3/tv/{tmdb_id}",
                params={"api_key": tmdb_key},
            )
            if r.status_code != 200:
                log.warning(
                    f"TMDB /tv/{tmdb_id} HTTP {r.status_code}: {r.text[:200]!r}"
                    + (" — check your TMDB API key" if r.status_code in (401, 403) else "")
                )
                return []
            show = r.json() or {}
            season_nums = [
                s.get("season_number") for s in (show.get("seasons") or [])
                if isinstance(s.get("season_number"), int) and s.get("season_number", 0) > 0
            ]
            log.debug(f"TMDB /tv/{tmdb_id}: found seasons {season_nums}")

            # 2) Fetch each season's episode list.
            for sn in season_nums:
                try:
                    rs = await c.get(
                        f"https://api.themoviedb.org/3/tv/{tmdb_id}/season/{sn}",
                        params={"api_key": tmdb_key},
                    )
                    if rs.status_code != 200:
                        continue
                    sd = rs.json() or {}
                    for ep in (sd.get("episodes") or []):
                        en = ep.get("episode_number")
                        if not isinstance(en, int) or en <= 0:
                            continue
                        out.append({
                            "season":   sn,
                            "episode":  en,
                            "title":    ep.get("name") or "",
                            "air_date": ep.get("air_date") or "",
                            "tmdb_id":  ep.get("id"),
                        })
                except Exception as e:
                    log.debug(f"TMDB season {tmdb_id}/{sn}: {e}")
    except Exception as e:
        log.debug(f"_tmdb_get_series_episodes {tmdb_id}: {e}")
        return []

    if not include_unreleased:
        # Strict release gate: unknown/future air dates are NOT released.
        # Do not let TMDB placeholder/index paths treat blank air dates as aired.
        out = [
            ep for ep in out
            if ep.get("air_date") and ep["air_date"] <= today
        ]

    _TMDB_EP_CACHE[key] = (now, out)
    return out


async def _get_series_episodes_via_tmdb(
    app, title: str, year=None, include_unreleased: bool = False,
) -> list[dict]:
    """
    Series data via TMDB only — looks up the show's tmdb_id from the
    library, falls back to a TMDB title search, then returns the episode
    catalog. Used everywhere the hash-index needs to know about a series.
    Returns [] if TMDB isn't configured or the show can't be found.
    """
    db = getattr(app.state, "db", None)
    if not db:
        return []

    # Accept either spelling — old form saved nothing under either name due
    # to a key mismatch; some installs may have set the setting manually
    # under TMDB_API_KEY before the form save was fixed.
    tmdb_key = (
        db.get_setting("tmdb_api_key", "")
        or db.get_setting("TMDB_API_KEY", "")
        or ""
    )
    if not tmdb_key:
        log.warning(
            f"TMDB lookup for {title!r}: no API key configured. "
            f"Set it in Settings → TMDB so the Seasons tab can enumerate episodes."
        )
        return []

    # 1) Prefer the tmdb_id stored on the library entry.
    tmdb_id = None
    try:
        lib_entry = next(
            (r for r in db.fake_library_list(media_type="series")
             if (r.get("title") or "").lower() == (title or "").lower()),
            None,
        )
    except Exception:
        lib_entry = None
    if lib_entry:
        tmdb_id = lib_entry.get("tmdb_id") or None
        if not year:
            year = lib_entry.get("year")

    # 2) Fall back to TMDB search by title (+ year).
    if not tmdb_id:
        log.info(
            f"TMDB lookup for {title!r}: no tmdb_id stored in library, "
            f"searching TMDB by title (year={year})"
        )
        tmdb_id = await _tmdb_resolve_series_id(title, year, tmdb_key)
        if not tmdb_id:
            log.warning(
                f"TMDB lookup for {title!r}: search returned no match. "
                f"The show may be listed under a different title on TMDB."
            )
            return []

    eps = await _tmdb_get_series_episodes(tmdb_id, tmdb_key, include_unreleased)
    log.info(
        f"TMDB {title!r} (id={tmdb_id}): {len(eps)} released episodes across "
        f"{len({e.get('season') for e in eps})} season(s)"
    )
    return eps


async def _get_series_counts_via_tmdb(
    app, title: str, year=None, *, include_unreleased: bool = False,
) -> dict:
    """
    Single source of truth for "how many seasons / episodes does this show have"
    — straight from TMDB. Used at indexing time, library-add time, lookahead
    boundary checks, and the series-detail UI so every part of the system
    agrees on what's expected.

    Returns:
        {
            "season_count":  <total released seasons>,
            "episode_count": <total released episodes>,
            "per_season":    {season_number: episode_count_for_that_season},
            "episodes":      <raw episode list>,    # for callers that need it
            "source":        "tmdb" | "unavailable",
        }

    `include_unreleased=False` (default) only counts episodes whose air_date
    is on or before today. Pass True for the catalog total (used when sizing
    the indexer to search every season the show will ever have).
    """
    eps = await _get_series_episodes_via_tmdb(
        app, title, year=year, include_unreleased=include_unreleased,
    )
    if not eps:
        return {
            "season_count": 0,
            "episode_count": 0,
            "per_season": {},
            "episodes": [],
            "source": "unavailable",
        }
    per_season: dict[int, int] = {}
    for ep in eps:
        sn = ep.get("season") or 0
        if sn > 0:
            per_season[sn] = per_season.get(sn, 0) + 1
    return {
        "season_count":  len(per_season),
        "episode_count": sum(per_season.values()),
        "per_season":    per_season,
        "episodes":      eps,
        "source":        "tmdb",
    }


async def resolve_and_cache(app: FastAPI, event: PlayEvent, is_user_play: bool = True):
    """
    Resolve & cache an episode/movie.

    is_user_play=True (default): this is a real user play event from the webhook.
        Triggers the 3-episode-rule lookahead chain on success/cache-hit.
    is_user_play=False: this is an internal cache-ahead resolve. Just resolves
        the episode and stops — no further lookahead scheduling. Keeps Plex's
        library scanner from being hammered by recursive cascades.
    """
    db = app.state.db; alldebrid = app.state.alldebrid; s = app.state.settings
    cache_key = event.cache_key()

    existing = db.get(cache_key)
    if existing and existing["status"] == "cached":
        # DB says cached, but verify the on-disk symlink actually exists and
        # resolves. The placeholder mp4 alone is not enough — without the
        # symlink, Plex plays a fake 60-byte file. Common causes of a
        # missing/broken symlink: manual deletion, FUSE remount, AllDebrid
        # eviction, PLEX_ROOT change.
        if _cached_symlink_valid(existing.get("strm_path")):
            log.info(f"✅ Cache hit: {cache_key}")
            # 3-episode rule fires ONLY on real user plays. Internal cache-ahead
            # resolves don't re-trigger another round — that's what kept Plex busy.
            if (is_user_play
                    and event.media_type.value == "episode"
                    and event.season and event.episode):
                _spawn_lookahead(_lookahead_chain(
                    app, db, event, existing_row=existing,
                    lookahead=3, symlink_delay=15, cache_delay=120,
                ))
            return
        else:
            log.warning(
                f"⚠️  Cache miss: DB says cached but symlink missing/broken for "
                f"{cache_key} (strm_path={existing.get('strm_path')!r}) — re-resolving"
            )
            # Restore the placeholder immediately so Plex always has *something*
            # to show while the re-resolve runs. Without this, the item briefly
            # disappears from the library and Plex may skip it.
            try:
                _restore_placeholder(
                    s.PLEX_ROOT, event.media_type.value, event.title,
                    year=event.year, season=event.season, episode=event.episode, app=app,
                )
            except Exception as e:
                log.debug(f"resolve_and_cache placeholder restore: {e}")
            # Demote so the rest of this function and downstream resolves
            # treat the entry as fresh. The existing magnet/torrent_name in
            # the row is left intact — _resolve_and_cache_inner will overwrite.
            db.update_status(cache_key, "not_found")
            # Fall through to the full resolve path below.

    # Register job and acquire worker slot
    ep = f" S{event.season:02d}E{event.episode:02d}" if event.season and event.episode else ""
    jid, cancel_event = _job_start(f"{event.title}{ep}", job_type="resolve")
    sem = _get_semaphore(app)
    try:
        async with sem:
            if cancel_event.is_set():
                _job_done(jid, "cancelled")
                return
            await _resolve_and_cache_inner(app, event, cancel_event, is_user_play=is_user_play)
        _job_done(jid)
    except asyncio.CancelledError:
        _job_done(jid, "cancelled")
        raise
    except Exception as e:
        _job_done(jid, str(e))
        raise


async def _resolve_and_cache_inner(app: FastAPI, event: PlayEvent,
                                   cancel_event: asyncio.Event = None,
                                   is_user_play: bool = True):
    db = app.state.db; alldebrid = app.state.alldebrid; s = app.state.settings
    cache_key = event.cache_key()

    log.info(f"🔍 Resolving: {cache_key}")
    db.upsert(cache_key, event, status="resolving")

    try:
        if event.media_type.value == "episode":
            cy = await _canonical_series_year(app, event.title, event.year)
            if cy and cy != event.year:
                event = event.model_copy(update={"year": cy})
                cache_key = event.cache_key()
                db.upsert(cache_key, event, status="resolving")

        # Verify episode numbering
        if event.media_type.value == "episode" and event.season and event.episode:
            tmdb_key = db.get_setting("tmdb_api_key", "")
            cs, cep = await _verify_episode_with_tmdb(
                event.tmdb_id, event.tvdb_id, event.season, event.episode, event.title, tmdb_key)
            if cs != event.season or cep != event.episode:
                event      = event.model_copy(update={"season": cs, "episode": cep})
                cache_key  = event.cache_key()
                existing   = db.get(cache_key)
                if existing and existing["status"] == "cached":
                    log.info(f"✅ Cache hit (corrected): {cache_key}"); return
                db.upsert(cache_key, event, status="resolving")

        # Strategy
        s_cfg = db.get_all_settings()
        if event.media_type.value == "episode":
            lm = app.state.library; is_ended = False
            if lm:
                try:
                    sl = await lm.get_sonarr_series()
                    sm = next((x for x in sl if x["title"].lower() == event.title.lower()), None)
                    if sm: is_ended = sm.get("status","").lower() in ("ended","cancelled","canceled")
                except Exception: pass
            strategy         = s_cfg.get("series_completed_strategy","series_pack") if is_ended else s_cfg.get("series_ongoing_strategy","season_pack")
            preferred_quality = s_cfg.get("series_preferred_quality","1080p")
            fallback_any      = s_cfg.get("series_fallback_any_quality","true") == "true"
        else:
            strategy         = "movie"
            preferred_quality = s_cfg.get("movie_preferred_quality","1080p")
            fallback_any      = s_cfg.get("movie_fallback_any_quality","true") == "true"

        # ── Hash index fast path ────────────────────────────────────────────
        # Check the pre-built hash index before doing a live TPB search.
        # This gives sub-second resolution for anything already indexed.
        hi: HashIndex = getattr(app.state, "hash_index", None)
        if hi:
            candidates = hi.lookup(
                event.title,
                season=event.season,
                episode=event.episode,
                cached_only=True,
            )
            if candidates:
                best_hash_row = candidates[0]
                log.info(
                    f"⚡ HashIndex hit: {event.title!r} — "
                    f"{best_hash_row['torrent_name']!r} ({best_hash_row['quality']})"
                )
                # Sanitise magnet — reject proxy URLs, reconstruct from hash if needed
                _raw_magnet = best_hash_row["magnet"] or ""
                if not _raw_magnet.startswith("magnet:?xt=urn:btih:"):
                    _raw_magnet = (
                        f"magnet:?xt=urn:btih:{best_hash_row['info_hash']}"
                        f"&dn={best_hash_row.get('torrent_name','')}"
                    )
                    # Write the corrected magnet back so it doesn't fail again
                    hi.upsert(
                        media_type=best_hash_row["media_type"],
                        title=best_hash_row["title"],
                        year=best_hash_row.get("year"),
                        season=best_hash_row.get("season"),
                        episode=best_hash_row.get("episode"),
                        info_hash=best_hash_row["info_hash"],
                        magnet=_raw_magnet,
                        torrent_name=best_hash_row.get("torrent_name", ""),
                        quality=best_hash_row.get("quality", "unknown"),
                        strategy=best_hash_row.get("strategy", "unknown"),
                        is_cached=True,
                    )
                    log.info(f"🔧 Repaired invalid magnet for {best_hash_row['info_hash'][:8]}")
                result = await alldebrid.add_magnet(_raw_magnet)
                if result:
                    magnet_id, files = result
                    torrent_name = best_hash_row["torrent_name"]

                    # Find episode-specific file. For episode requests we
                    # REQUIRE an SxxEyy match in the file list — otherwise
                    # this pack doesn't actually contain the requested episode
                    # (e.g., a torrent classified as 'series' that only holds
                    # one season). Falling back to "largest file" would drop a
                    # wrong-season file into the wrong-season folder.
                    target_file = None
                    if event.media_type.value == "episode" and event.season and event.episode:
                        se_pat = f"S{event.season:02d}E{event.episode:02d}".upper()
                        for f in files:
                            if se_pat in f.get("n", "").upper():
                                target_file = f
                                break
                        if not target_file:
                            log.warning(
                                f"⚠️  HashIndex hit {best_hash_row['info_hash'][:8]} "
                                f"({best_hash_row.get('torrent_name','?')!r}) does NOT "
                                f"contain {se_pat} — rejecting and falling back to live search"
                            )
                            # Do not mark the entire hash uncached here. The
                            # pack may be valid for other episodes; it simply
                            # does not cover this requested episode. Fall through
                            # to FUSE/live exact-episode search.

                        # Pack-completeness gate: for season/series packs, require
                        # every RELEASED episode (per Sonarr) to be in the file
                        # list. Incomplete packs are common during airing seasons —
                        # we don't want to "grab" them as the canonical source.
                        if target_file:
                            pack_kind = best_hash_row.get("media_type", "")
                            if pack_kind in ("season", "series") and event.season:
                                is_complete, missing, _ = await _validate_pack_completeness(
                                    app, event.title, files,
                                    pack_kind=pack_kind,
                                    focus_season=event.season if pack_kind == "season" else None,
                                )
                                if not is_complete:
                                    miss_sample = ", ".join(
                                        f"S{sn:02d}E{en:02d}"
                                        for sn, en in sorted(missing)[:5]
                                    )
                                    more = f" +{len(missing)-5} more" if len(missing) > 5 else ""
                                    log.warning(
                                        f"⚠️  Pack {best_hash_row['info_hash'][:8]} "
                                        f"({pack_kind}) is INCOMPLETE — missing {len(missing)} "
                                        f"released episode(s): {miss_sample}{more} — rejecting"
                                    )
                                    try:
                                        hi.mark_uncached(best_hash_row["info_hash"])
                                    except Exception:
                                        pass
                                    target_file = None  # force fallthrough to live search
                    elif files:
                        # Movie or non-episode ambient request — pick largest.
                        target_file = max(files, key=lambda f: f.get("s", 0))

                if result and target_file:

                    filename  = target_file.get("n", torrent_name)
                    ad_link   = target_file.get("l", "")
                    stem = Path(filename).stem if filename else torrent_name
                    fuse_folder = stem if (stem and torrent_name and stem.startswith(torrent_name.rstrip("-"))) else torrent_name

                    if ad_link and s.PLEX_ROOT:
                        fuse_thread = getattr(app.state, "fuse_thread", None)
                        if FUSE_AVAILABLE and fuse_thread:
                            register_torrent(fuse_folder, files)
                            fuse_virtual = get_fuse_path(fuse_folder, filename, s.FUSE_SYMLINK_ROOT)
                            link = _make_plex_symlink(
                                cache_key, event.title, event.year, event.season,
                                event.episode, event.media_type.value, s.PLEX_ROOT,
                                fuse_virtual, filename,
                                app=app,
                            )
                            strm_path = str(link) if link else None
                        else:
                            p = write_strm(
                                cache_key=cache_key, title=event.title, year=event.year,
                                season=event.season, episode=event.episode,
                                media_type=event.media_type.value,
                                debridarr_base_url=s.DEBRIDARR_BASE_URL,
                                plex_root=s.PLEX_ROOT,
                            )
                            strm_path = str(p) if p else None
                    else:
                        strm_path = None

                    db.update_cached(
                        cache_key, best_hash_row["magnet"], ad_link, torrent_name,
                        best_hash_row["quality"], strm_path,
                    )
                    # Write-back: mark this hash as used and confirmed
                    hi.touch(best_hash_row["info_hash"])
                    log.info(f"✅ HashIndex resolve done: {cache_key}")

                    # Cache +3 ahead from hash index after 120s — user plays only.
                    # Internal cache-ahead resolves skip this to keep Plex calm.
                    if (is_user_play
                            and event.media_type.value == "episode"
                            and event.season and event.episode):
                        async def _hi_cache_ahead():
                            await asyncio.sleep(120)
                            await _cache_ahead(app=app, db=db,
                                               title=event.title, year=event.year,
                                               event_season=event.season,
                                               event_episode=event.episode,
                                               lookahead=3)
                        _spawn_lookahead(_hi_cache_ahead())

                    # ── Season/series pack: symlink next 3 episodes after 15s ──
                    # User plays only — internal cache-ahead resolves skip.
                    hi_media_type = best_hash_row.get("media_type", "")
                    if (is_user_play
                            and event.media_type.value == "episode"
                            and event.season
                            and hi_media_type in ("season", "series")
                            and len(files) > 1):
                        _hi_magnet   = _raw_magnet
                        _hi_torrent  = torrent_name
                        _hi_quality  = best_hash_row.get("quality", "unknown")
                        _hi_all_seas = (hi_media_type == "series")

                        async def _hi_delayed_pack():
                            await asyncio.sleep(15)
                            # Symlink next 3 episodes
                            extra = _symlink_ahead(
                                app=app, db=db, files=files,
                                magnet_str=_hi_magnet, torrent_name=_hi_torrent,
                                quality=_hi_quality,
                                title=event.title, year=event.year,
                                event_season=event.season,
                                event_episode=event.episode,
                                plex_root=s.PLEX_ROOT,
                                debridarr_base_url=s.DEBRIDARR_BASE_URL,
                                fuse_thread=getattr(app.state, "fuse_thread", None),
                                fuse_symlink_root=s.FUSE_SYMLINK_ROOT,
                                lookahead=3,
                            )

                            if extra:
                                log.info(f"📦 Lookahead: {extra} episode(s) symlinked for "
                                         f"{event.title!r} S{event.season:02d}E{event.episode:02d}+3")
                        _spawn_lookahead(_hi_delayed_pack())
                        log.info(f"📦 Pack hit — episode ready, +3 symlink in 15s, +3 cache in 120s")

                    return
                elif not result:
                    # add_magnet failed — hash may have been evicted from AllDebrid.
                    # Mark it uncached and fall through to FUSE / live search.
                    log.warning(
                        f"⚠️  HashIndex hit but add_magnet failed for "
                        f"{best_hash_row['info_hash']!r} — falling back to live search"
                    )
                    hi.mark_uncached(best_hash_row["info_hash"])
                # else: result OK but target_file is None — already marked uncached
                # in the per-episode check above. Fall through to FUSE / live search.

        # Check/refresh FUSE before doing any live search.
        # The in-process FUSE registry can be empty/stale after restart even
        # though AllDebrid already has the correct ready torrent mounted.
        # Refreshing here lets on-play symlinking find an existing exact
        # episode (for example S09E03) instead of doing a broad TPB search
        # and accidentally touching S09E01 first.
        try:
            if FUSE_AVAILABLE and getattr(app.state, "fuse_thread", None) and alldebrid:
                for _t in await alldebrid.get_all_torrents():
                    _folder = _t.get("name", "")
                    _files = _t.get("files", []) or []
                    if _folder and _files:
                        register_torrent(_folder, _files)
        except Exception as _e_rf:
            log.debug(f"FUSE refresh before resolve failed: {_e_rf}")

        fuse_match = _find_in_fuse(event.title, event.year, event.season, event.episode)
        if fuse_match:
            torrent_name, filename, fuse_file = fuse_match
            log.info(f"✅ Found in FUSE — symlinking directly")
            fuse_virtual = get_fuse_path(torrent_name, filename, s.FUSE_SYMLINK_ROOT)
            link = _make_plex_symlink(cache_key, event.title, event.year, event.season,
                                      event.episode, event.media_type.value, s.PLEX_ROOT,
                                      fuse_virtual, filename, app=app)
            fuse_quality = _detect_quality(filename)
            db.update_cached(cache_key, "", fuse_file.get("l",""), torrent_name,
                             fuse_quality, str(link) if link else None)
            # Write to hash index so future plays use the fast path
            _fuse_hi: HashIndex = getattr(app.state, "hash_index", None)
            if _fuse_hi:
                import re as _re_fuse
                _fuse_magnet = fuse_file.get("l", "")  # file link, not a magnet
                # Build a minimal magnet from the torrent name for index lookup
                # The FUSE path itself is the authoritative source; magnet may be empty
                # Store the file link so mark_uncached can clean up if needed
                try:
                    _fuse_hi.upsert(
                        media_type=event.media_type.value,
                        title=event.title,
                        year=event.year,
                        season=event.season,
                        episode=event.episode,
                        info_hash="fuse_" + torrent_name[:32].replace(" ", "_").lower(),
                        magnet=_fuse_magnet or f"fuse://{torrent_name}",
                        torrent_name=torrent_name,
                        quality=fuse_quality,
                        strategy="fuse",
                        is_cached=True,
                    )
                    log.info(f"🗄️  HashIndex FUSE write-back: {event.title!r} → {torrent_name!r}")
                except Exception as _e_fuse:
                    log.debug(f"HashIndex FUSE write-back failed: {_e_fuse}")
            return

        # Check cancellation before expensive AllDebrid search
        if cancel_event and cancel_event.is_set():
            db.update_status(cache_key, "not_found")
            log.info(f"🚫 Cancelled: {cache_key}")
            return

        # Search TPB/AD cache. For real episode playback, exact episode search
        # must happen before season/series pack strategies. If exact search finds
        # S09E03, write it under that episode in Hash Index and symlink it. Only
        # fall back to season/series packs after exact episode search finds no
        # cached result.
        log.info(f"🔎 Searching TPB for: {event.title!r}")
        _search_strategies = [strategy]
        if event.media_type.value == "episode" and event.season and event.episode:
            _search_strategies = ["episode"] + ([strategy] if strategy != "episode" else [])
            if strategy != "series_pack":
                _search_strategies.append("series_pack")

        results = []
        _used_strategy = strategy
        for _st in dict.fromkeys(_search_strategies):
            results = await alldebrid.search_cached(
                title=event.title, media_type=event.media_type.value,
                year=event.year, season=event.season, episode=event.episode,
                imdb_id=event.imdb_id, strategy=_st,
                preferred_quality=preferred_quality, fallback_any=fallback_any,
            )
            if results:
                _used_strategy = _st
                break
        strategy = _used_strategy
        if not results:
            log.warning(f"❌ No results: {cache_key}")
            db.update_status(cache_key, "not_found")

            # ── Ongoing series fallback: no pack found → try individual episodes ──
            if (event.media_type.value == "episode"
                    and event.season
                    and strategy in ("season_pack", "episode")
                    and not is_ended):
                asyncio.create_task(
                    _resolve_season_episodes(app, event, preferred_quality, fallback_any)
                )
                log.info(f"📺 Ongoing series — queuing individual episode search for {event.title} S{event.season:02d}")
            return

        best = results[0]
        log.info(f"🎯 {best['name']} cached={best['cached']} q={best.get('quality','?')}")

        result = await alldebrid.add_magnet(best["magnet"])
        if not result:
            db.update_status(cache_key, "unlock_failed"); return

        magnet_id, files = result
        torrent_name = best["name"]

        # Find episode-specific file. Episode requests require an SxxEyy
        # match — never fall back to largest-file for episodes, or we'll
        # drop a wrong-season file into the wrong-season folder.
        target_file = None
        if event.media_type.value == "episode" and event.season and event.episode:
            se_pat = f"S{event.season:02d}E{event.episode:02d}".upper()
            for f in files:
                if se_pat in f.get("n","").upper(): target_file = f; break
            if not target_file:
                # The first cached result may be a nearby but wrong episode
                # (for example S09E01 while playing S09E03). Do not stop the
                # resolver on the first bad candidate. Try the remaining cached
                # results for an exact file match before giving up.
                log.warning(
                    f"⚠️  Live-resolve candidate {best.get('name','?')!r} does NOT "
                    f"contain {se_pat} — trying alternate cached candidates"
                )
                for _alt in results[1:]:
                    if cancel_event and cancel_event.is_set():
                        break
                    try:
                        _alt_result = await alldebrid.add_magnet(_alt["magnet"])
                        if not _alt_result:
                            continue
                        _alt_mid, _alt_files = _alt_result
                        _alt_target = next(
                            (f for f in _alt_files if se_pat in f.get("n", "").upper()),
                            None,
                        )
                        if _alt_target:
                            best = _alt
                            magnet_id, files = _alt_mid, _alt_files
                            torrent_name = _alt.get("name", torrent_name)
                            target_file = _alt_target
                            log.info(f"✅ Alternate exact episode candidate selected: {_alt.get('name','?')}")
                            break
                    except Exception as _e_alt:
                        log.debug(f"Alternate live candidate failed: {_e_alt}")
                if not target_file:
                    log.warning(
                        f"⚠️  No cached live candidate contains {se_pat} — refusing to symlink wrong episode"
                    )
                    db.update_status(cache_key, "not_found")
                    return

            # Pack-completeness gate: same rule as the hash-index path. If
            # this is a season/series pack and Sonarr says it's missing
            # released episodes, refuse to "grab" it.
            live_pack_kind = (
                "series" if strategy == "series_pack"
                else "season" if strategy == "season_pack"
                else None
            )
            if live_pack_kind and len(files) > 1:
                is_complete, missing, _ = await _validate_pack_completeness(
                    app, event.title, files,
                    pack_kind=live_pack_kind,
                    focus_season=event.season if live_pack_kind == "season" else None,
                )
                if not is_complete:
                    miss_sample = ", ".join(
                        f"S{sn:02d}E{en:02d}"
                        for sn, en in sorted(missing)[:5]
                    )
                    more = f" +{len(missing)-5} more" if len(missing) > 5 else ""
                    log.warning(
                        f"⚠️  Live-resolve pack {best.get('name','?')!r} ({live_pack_kind}) "
                        f"is INCOMPLETE — missing {len(missing)} released episode(s): "
                        f"{miss_sample}{more} — refusing to grab"
                    )
                    db.update_status(cache_key, "not_found")
                    return
        else:
            target_file = max(files, key=lambda f: f.get("s",0))

        filename  = target_file.get("n", torrent_name)
        ad_link   = target_file.get("l","")
        file_size = target_file.get("s", 0)

        # Resolve FUSE folder name (handle truncated names)
        stem = Path(filename).stem if filename else torrent_name
        fuse_folder = stem if (stem and torrent_name and stem.startswith(torrent_name.rstrip("-"))) else torrent_name

        if not ad_link:
            log.error(f"No file link for {cache_key}")
            db.update_status(cache_key, "unlock_failed"); return

        log.info(f"📁 {fuse_folder}/{filename} ({file_size} bytes)")

        strm_path = None
        fuse_thread = getattr(app.state, "fuse_thread", None)

        if s.PLEX_ROOT:
            if FUSE_AVAILABLE and fuse_thread:
                register_torrent(fuse_folder, files)
                fuse_virtual = get_fuse_path(fuse_folder, filename, s.FUSE_SYMLINK_ROOT)
                log.info(f"📂 FUSE: {fuse_virtual}")
                link = _make_plex_symlink(cache_key, event.title, event.year, event.season,
                                          event.episode, event.media_type.value, s.PLEX_ROOT,
                                          fuse_virtual, filename, app=app)
                strm_path = str(link) if link else None
                log.info(f"🔗 {link} → {fuse_virtual}")
            else:
                p = write_strm(cache_key=cache_key, title=event.title, year=event.year,
                               season=event.season, episode=event.episode,
                               media_type=event.media_type.value,
                               debridarr_base_url=s.DEBRIDARR_BASE_URL, plex_root=s.PLEX_ROOT)
                strm_path = str(p) if p else None

        db.update_cached(cache_key, best["magnet"], ad_link, torrent_name,
                         best.get("quality","unknown"), strm_path)
        log.info(f"✅ Done: {cache_key}")

        # Cache +3 ahead from hash index after 120s — user plays only.
        if (is_user_play
                and event.media_type.value == "episode"
                and event.season and event.episode):
            async def _live_cache_ahead():
                await asyncio.sleep(120)
                await _cache_ahead(app=app, db=db,
                                   title=event.title, year=event.year,
                                   event_season=event.season,
                                   event_episode=event.episode,
                                   lookahead=3)
            _spawn_lookahead(_live_cache_ahead())

        # Write resolved magnet into hash index — future plays hit fast path
        _hi2: HashIndex = getattr(app.state, "hash_index", None)
        if _hi2 and best.get("magnet"):
            import re as _re2
            _m2 = _re2.search(r"btih:([a-fA-F0-9]{40})", best["magnet"], _re2.I)
            if _m2:
                _hi2.upsert(
                    media_type=event.media_type.value,
                    title=event.title, year=event.year,
                    season=event.season, episode=event.episode,
                    info_hash=_m2.group(1).lower(),
                    magnet=best["magnet"],
                    torrent_name=torrent_name,
                    quality=best.get("quality", "unknown"),
                    strategy="exact_episode" if event.media_type.value == "episode" else "live_resolve",
                    is_cached=True,
                )
                log.info(f"🗄️  Live resolve written to hash index under exact media item: {event.title!r}")

        # ── Write-back: store ALL search results so future plays skip TPB ────
        # We store every cached candidate (up to 5), not just the one we used.
        # If that torrent gets evicted from AllDebrid, the next play can try
        # the next-best candidate without doing a new TPB search.
        # Season/series packs stored without episode so any episode in the pack
        # hits the index directly.
        _hi_wb: HashIndex = getattr(app.state, "hash_index", None)
        if _hi_wb:
            import re as _re_wb
            _is_pack = (
                event.media_type.value == "episode"
                and strategy in ("season_pack", "series_pack")
                and len(files) > 1
            )
            for _wb_r in results:  # results already filtered to cached only, up to 5
                _hm = _re_wb.search(r"btih:([a-fA-F0-9]{40})", _wb_r.get("magnet",""), _re_wb.I)
                if not _hm:
                    continue
                try:
                    _hi_wb.upsert(
                        media_type="season" if _is_pack else event.media_type.value,
                        title=event.title,
                        year=event.year,
                        season=event.season if strategy != "series_pack" else None,
                        episode=None if _is_pack else event.episode,
                        info_hash=_hm.group(1).lower(),
                        magnet=_wb_r["magnet"],
                        torrent_name=_wb_r.get("name", torrent_name),
                        quality=_wb_r.get("quality", "unknown"),
                        strategy=strategy,
                        is_cached=bool(_wb_r.get("cached", True)),
                    )
                except Exception as _e_wb:
                    log.debug(f"HashIndex write-back failed: {_e_wb}")
            log.info(
                f"🗄️  HashIndex write-back: {event.title!r} → "
                f"{torrent_name!r} ({strategy}, {best.get('quality','unknown')}) "
                f"[+{len(results)-1} alternates]"
            )

        # ── Season/series pack: symlink requested episode NOW, next 3 after 15s ──
        # User plays only — internal cache-ahead resolves skip the symlink-ahead.
        if (is_user_play
                and event.media_type.value == "episode"
                and event.season
                and strategy in ("season_pack", "series_pack")
                and len(files) > 1):
            # Short delay — symlinks are local fs ops, don't interfere with stream
            async def _delayed_pack_symlinks():
                await asyncio.sleep(15)
                # Symlink next 3 episodes
                extra = _symlink_ahead(
                    app=app, db=db, files=files,
                    magnet_str=best["magnet"], torrent_name=torrent_name,
                    quality=best.get("quality", "unknown"),
                    title=event.title, year=event.year,
                    event_season=event.season, event_episode=event.episode,
                    plex_root=s.PLEX_ROOT,
                    debridarr_base_url=s.DEBRIDARR_BASE_URL,
                    fuse_thread=getattr(app.state, "fuse_thread", None),
                    fuse_symlink_root=s.FUSE_SYMLINK_ROOT,
                    lookahead=3,
                )

                if extra:
                    log.info(f"📦 Lookahead: {extra} episodes for {event.title} S{event.season:02d}E{event.episode:02d}+3")
            _spawn_lookahead(_delayed_pack_symlinks())
            log.info(f"📦 Pack found — episode ready, +3 symlink in 15s, +3 cache in 120s")

    except Exception as e:
        log.error(f"❌ {cache_key}: {e}", exc_info=True)
        db.update_status(cache_key, "error")


async def _resolve_season_episodes(
    app: FastAPI,
    event: PlayEvent,
    preferred_quality: str,
    fallback_any: bool,
    delay_between: int = 10,
):
    """
    Fallback for ongoing series with no season pack available.
    Searches for each individual episode in the season and resolves them,
    starting with the requested episode and working outward.

    Called when strategy=season_pack|episode and no pack is found.
    Staggered by delay_between seconds to avoid hammering AllDebrid.
    """
    db        = app.state.db
    lm        = app.state.library
    alldebrid = app.state.alldebrid

    title  = event.title
    season = event.season
    year   = event.year
    target = event.episode

    # Get the full episode list for this season from Overseerr/Sonarr
    episodes_in_season = []
    if lm:
        try:
            sl = await lm.get_sonarr_series()
            sm = next((x for x in sl if x["title"].lower() == title.lower()), None)
            if sm:
                all_eps = await lm.get_episodes(sm["id"], include_unreleased=False)
                episodes_in_season = [
                    e["episode"] for e in all_eps
                    if e["season"] == season
                ]
        except Exception as e:
            log.warning(f"_resolve_season_episodes: could not get episode list: {e}")

    if not episodes_in_season:
        # Fallback: assume standard season of up to 20 episodes
        episodes_in_season = list(range(1, 21))

    # Sort: start with the requested episode, then forward, then backward
    before = sorted([e for e in episodes_in_season if e < target], reverse=True)
    after  = sorted([e for e in episodes_in_season if e > target])
    ordered = [target] + after + before   # target first, then forward, then backfill

    log.info(f"📺 Individual episode search for {title} S{season:02d} — {len(ordered)} episodes")

    resolved = 0
    for epn in ordered:
        ep_event = PlayEvent(
            media_type=MediaType.episode,
            title=title, year=year,
            season=season, episode=epn,
        )
        ck = ep_event.cache_key()
        existing = db.get(ck)
        if existing and existing["status"] == "cached":
            resolved += 1
            continue
        if existing and existing["status"] == "resolving":
            continue

        try:
            results = await alldebrid.search_cached(
                title=title, media_type="episode", year=year,
                season=season, episode=epn,
                strategy="episode",
                preferred_quality=preferred_quality,
                fallback_any=fallback_any,
            )
            if results:
                # Write all candidates to hash index before resolving
                _rs_hi: HashIndex = getattr(app.state, "hash_index", None)
                if _rs_hi:
                    import re as _re_rs
                    for _rsr in results:
                        _hm_rs = _re_rs.search(r"btih:([a-fA-F0-9]{40})", _rsr.get("magnet",""), _re_rs.I)
                        if _hm_rs and _rsr.get("cached"):
                            try:
                                _is_pack_rs = not _re_rs.search(r"S\d{2}E\d{2}", _rsr["name"], _re_rs.I)
                                _rs_hi.upsert(
                                    media_type="season" if _is_pack_rs else "episode",
                                    title=title, year=year,
                                    season=season, episode=None if _is_pack_rs else epn,
                                    info_hash=_hm_rs.group(1).lower(),
                                    magnet=_rsr["magnet"],
                                    torrent_name=_rsr["name"],
                                    quality=_rsr.get("quality", "unknown"),
                                    strategy="episode",
                                    is_cached=True,
                                )
                            except Exception:
                                pass
                # Always placeholder only — symlink on play
                ck_ep = ep_event.cache_key()
                if not db.get(ck_ep):
                    db.upsert(ck_ep, ep_event, status="not_found")
                    if lm and lm.plex_root and _placeholder_allowed(app, "episode", title, year, season, epn):
                        lm.create_fake_episodes(title, year, [], [{
                            "season": season, "episode": epn
                        }])
                    else:
                        log.debug(f"  ⏭  Placeholder blocked: {title} S{season:02d}E{epn:02d}")
                resolved += 1
                log.debug(f"  📺 Queued resolve: {title} S{season:02d}E{epn:02d}")
            else:
                log.debug(f"  ⏭  No torrent: {title} S{season:02d}E{epn:02d}")
        except Exception as e:
            log.error(f"  Episode search {title} S{season:02d}E{epn:02d}: {e}")

        await asyncio.sleep(delay_between)

    log.info(f"📺 Individual episode resolve queued {resolved}/{len(ordered)} for {title} S{season:02d}")





# ══════════════════════════════════════════════════════════════════════
# /hash-indexer — Hash Indexer page
# ══════════════════════════════════════════════════════════════════════



def _fmt_ts(ts) -> str:
    """Unix timestamp → human-readable relative string."""
    if not ts:
        return "never"
    try:
        dt   = datetime.fromtimestamp(int(ts), tz=timezone.utc)
        diff = (datetime.now(tz=timezone.utc) - dt).total_seconds()
        if diff < 60:        return "just now"
        if diff < 3600:      return f"{int(diff//60)}m ago"
        if diff < 86400:     return f"{int(diff//3600)}h ago"
        if diff < 86400*7:   return f"{int(diff//86400)}d ago"
        return dt.strftime("%Y-%m-%d")
    except Exception:
        return "—"


def _quality_pill(q: str) -> str:
    colours = {
        "2160p": ("#1a0a3a", "#c084fc"),
        "4k":    ("#1a0a3a", "#c084fc"),
        "uhd":   ("#1a0a3a", "#c084fc"),
        "1080p": ("#0d2640", "#60a5fa"),
        "720p":  ("#162a00", "#86efac"),
        "480p":  ("#2a1a00", "#fbbf24"),
    }
    bg, fg = colours.get((q or "").lower(), ("#1e1e2e", "#555"))
    return f'<span style="background:{bg};color:{fg};padding:2px 8px;border-radius:20px;font-size:0.68rem;font-weight:700">{_html.escape(q or "?")}</span>'


def _score_bar(score: int, max_score: int = 120) -> str:
    pct  = min(100, int(score / max(max_score, 1) * 100))
    col  = "#4ade80" if pct >= 70 else "#f97316" if pct >= 40 else "#f87171"
    return (
        f'<div style="display:flex;align-items:center;gap:6px">'
        f'<div style="width:64px;height:6px;background:#1e1e2e;border-radius:3px;overflow:hidden">'
        f'<div style="width:{pct}%;height:100%;background:{col};border-radius:3px"></div></div>'
        f'<span style="font-size:0.72rem;color:#555">{score}</span>'
        f'</div>'
    )



@app.get("/hash-log")
@app.get("/hash-index/log")
async def hash_index_log_redirect():
    # Hash logs are not a standalone page anymore. Legacy URLs land on the
    # Logs tab inside the Hash Indexer page.
    return RedirectResponse("/hash-indexer?tab=logs", status_code=303)

@app.get("/hash-indexer", response_class=HTMLResponse)
async def hash_indexer_page(
    request: Request,
    tab: str = "all",
    q: str = "",
    page: int = 1,
):
    if _needs_setup(request):
        return _setup_redirect()

    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    db: CacheDB   = request.app.state.db

    if not hi:
        return _page("Hash Indexer", "hashindexer",
                     '<div class="empty">Hash index not initialised.</div>')

    # Hash Logs are now part of Hash Indexer. Keep this path lightweight so
    # viewing logs does not trigger the expensive title/season augmentation.
    if tab == "logs":
        stats = hi.stats()
        lines = hi.recent_log_lines(500)
        if q:
            ql = q.lower()
            lines = [line for line in lines if ql in line.lower()]

        def _log_tab(key, label, href=None):
            active = "active" if tab == key else ""
            url = href or f"/hash-indexer?tab={key}"
            return f'<div class="tab {active}" onclick="location.href=\'{url}\'">{label}</div>'

        tabs_html = (
            '<div class="tabs" style="margin-bottom:20px">'
            + _log_tab("all", "All")
            + _log_tab("movies", "🎬 Movies")
            + _log_tab("tv", "📺 TV")
            + _log_tab("cached", "✅ Cached")
            + _log_tab("missing", "❌ Missing")
            + _log_tab("upcoming", "📅 Upcoming")
            + _log_tab("logs", "📋 Logs")
            + '</div>'
        )

        clear_btn = '<button class="btn btn-sec" onclick="location.href=\'/hash-indexer?tab=logs\'">&times; Clear</button>' if q else ''
        search_html = f'''
        <div class="search-bar">
          <input id="q" type="text" placeholder="Search hash logs…" value="{_html.escape(q)}"
                 onkeydown="if(event.key==='Enter')goHashLogs()">
          <button class="btn btn-add" onclick="goHashLogs()">Search</button>
          {clear_btn}
          <button class="btn btn-sec" onclick="location.reload()" style="margin-left:auto">⟳ Refresh</button>
        </div>'''

        tv_rows = stats.get("episodes", 0) + stats.get("seasons", 0) + stats.get("series", 0)
        stat_bar = (
            '<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:24px">'
            f'<div style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:10px;padding:16px 20px;min-width:110px"><div style="font-size:1.6rem;font-weight:700;color:#e0e0e0">{stats.get("total",0)}</div><div style="font-size:0.72rem;color:#555;margin-top:3px">Total hashes</div></div>'
            f'<div style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:10px;padding:16px 20px;min-width:110px"><div style="font-size:1.6rem;font-weight:700;color:#4ade80">{stats.get("cached",0)}</div><div style="font-size:0.72rem;color:#555;margin-top:3px">Cached</div></div>'
            f'<div style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:10px;padding:16px 20px;min-width:110px"><div style="font-size:1.6rem;font-weight:700;color:#60a5fa">{stats.get("movies",0)}</div><div style="font-size:0.72rem;color:#555;margin-top:3px">Movies</div></div>'
            f'<div style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:10px;padding:16px 20px;min-width:110px"><div style="font-size:1.6rem;font-weight:700;color:#c084fc">{tv_rows}</div><div style="font-size:0.72rem;color:#555;margin-top:3px">TV rows</div></div>'
            '</div>'
        )

        log_body = '<div class="empty">No hash log entries yet.</div>'
        if lines:
            log_body = '<pre style="background:#101018;border:1px solid #2a2a3a;border-radius:10px;padding:14px;max-height:70vh;overflow:auto;white-space:pre-wrap;font-size:0.78rem;line-height:1.45;color:#cbd5e1">' + _html.escape("\n".join(lines)) + '</pre>'

        body = f'''
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;gap:12px;flex-wrap:wrap">
          <h2 style="margin:0">🔎 Hash Indexer</h2>
          <span style="color:#666;font-size:0.85rem">Logs section inside Hash Index only</span>
        </div>
        {tabs_html}
        {stat_bar}
        {search_html}
        {log_body}
        '''
        extra = '''
        <script>
        function goHashLogs(){
          const q = document.getElementById('q')?.value || '';
          location.href = '/hash-indexer?tab=logs&q=' + encodeURIComponent(q);
        }
        </script>
        '''
        return _page("Hash Indexer", "hashindexer", body, extra)

    # ── Pull data ─────────────────────────────────────────────────────────────
    stats    = hi.stats()
    all_rows = hi.list_titles()

    # Cross-reference with fake_library to detect missing titles and seasons
    lib_entries     = db.fake_library_list()
    lib_by_title    = {r["title"].lower(): r for r in lib_entries}
    lib_titles      = set(lib_by_title.keys())
    indexed_titles  = {row["title"].lower() for row in all_rows}

    # Upcoming episodes being tracked
    upcoming_eps = db.get_all_upcoming()

    # Augment indexed rows with library membership and missing flag
    for row in all_rows:
        lib_key          = row["title"].lower()
        row["in_library"] = lib_key in lib_titles
        lib_entry         = lib_by_title.get(lib_key)

        if row["kind"] == "movie":
            # Availability is driven by AllDebrid/hash-index cache state, not
            # by local placeholders or on-play symlinks. A movie with any
            # cached hash is AVAILABLE even if it has not been materialized on
            # disk yet.
            row["missing"] = row["in_library"] and row["cached_count"] == 0
            row["missing_seasons"] = []
        else:
            # TV availability follows the same rule: if the title has any
            # cached hash-index entry, it is NOT a missing title. Missing
            # seasons are shown only as advisory detail in the row/detail view;
            # they must not put a cached show into the Missing tab.
            row["missing"] = row["in_library"] and row["cached_count"] == 0
            if lib_entry and row["in_library"]:
                sc = lib_entry.get("season_count") or 0
                indexed_seasons = set()
                if row.get("has_series_pack"):
                    indexed_seasons = set(range(1, sc + 1))  # cached series pack covers all seasons
                else:
                    hi_seasons = hi.get_indexed_seasons(row["title"])
                    indexed_seasons = set(hi_seasons)
                expected_seasons = set(range(1, sc + 1)) if sc else set()
                row["missing_seasons"] = sorted(expected_seasons - indexed_seasons)
            else:
                row["missing_seasons"] = []

    # Add library titles with NO hash index entries at all
    ghost_rows = []
    for lib_entry in lib_entries:
        if lib_entry["title"].lower() not in indexed_titles:
            kind = "movie" if lib_entry["media_type"] == "movie" else "tv"
            sc   = lib_entry.get("season_count") or 0
            ghost_rows.append({
                "title":          lib_entry["title"],
                "year":           lib_entry.get("year"),
                "kind":           kind,
                "total_hashes":   0,
                "cached_count":   0,
                "best_score":     0,
                "best_quality":   None,
                "has_series_pack": False,
                "has_season_pack": False,
                "season_count":   sc,
                "last_checked":   None,
                "last_used":      None,
                "in_library":     True,
                "missing":        True,
                "missing_seasons": list(range(1, sc + 1)) if (kind == "tv" and sc) else [],
            })

    all_rows = all_rows + ghost_rows

    # ── Filter by tab ─────────────────────────────────────────────────────────
    if tab == "movies":
        rows = [r for r in all_rows if r["kind"] == "movie"]
    elif tab == "tv":
        rows = [r for r in all_rows if r["kind"] == "tv"]
    elif tab == "cached":
        rows = [r for r in all_rows if r["cached_count"] > 0]
    elif tab == "missing":
        rows = [r for r in all_rows if r["missing"]]
    elif tab == "upcoming":
        rows = []   # upcoming shows its own table below
    else:
        rows = all_rows

    # ── Search ────────────────────────────────────────────────────────────────
    if q:
        ql   = q.lower()
        rows = [r for r in rows if ql in r["title"].lower()]

    # ── Counts for tab badges ─────────────────────────────────────────────────
    n_all     = len(all_rows)
    n_movies  = sum(1 for r in all_rows if r["kind"] == "movie")
    n_tv      = sum(1 for r in all_rows if r["kind"] == "tv")
    n_cached  = sum(1 for r in all_rows if r["cached_count"] > 0)
    n_missing = sum(1 for r in all_rows if r["missing"])

    # ── Pagination ────────────────────────────────────────────────────────────
    PER_PAGE    = 50
    total       = len(rows)
    total_pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)
    page        = max(1, min(page, total_pages))
    page_rows   = rows[(page - 1) * PER_PAGE : page * PER_PAGE]

    # ── Stat cards ────────────────────────────────────────────────────────────
    def stat_card(label, value, colour="#e0e0e0"):
        return (
            f'<div style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:10px;'
            f'padding:16px 20px;min-width:110px">'
            f'<div style="font-size:1.6rem;font-weight:700;color:{colour}">{value}</div>'
            f'<div style="font-size:0.72rem;color:#555;margin-top:3px">{label}</div>'
            f'</div>'
        )

    stat_bar = (
        '<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:24px">'
        + stat_card("Total hashes",   stats["total"])
        + stat_card("Cached on AD",   stats["cached"],   "#4ade80")
        + stat_card("Movies",         stats["movies"],   "#60a5fa")
        + stat_card("Season packs",   stats["seasons"],  "#c084fc")
        + stat_card("Series packs",   stats["series"],   "#c084fc")
        + stat_card("Avg score",      stats["avg_score"])
        + stat_card("Missing",        n_missing,         "#f87171" if n_missing else "#555")
        + stat_card("Upcoming",       len(upcoming_eps),  "#f97316" if upcoming_eps else "#555")
        + '</div>'
    )

    # ── Tabs ──────────────────────────────────────────────────────────────────
    def _tab(key, label, count):
        active = "active" if tab == key else ""
        return (
            f'<div class="tab {active}" onclick="location.href=\'/hash-indexer?tab={key}&q={_html.escape(q)}\'">'
            f'{label} <span style="font-size:0.72rem;opacity:0.7">({count})</span></div>'
        )

    tabs_html = (
        '<div class="tabs" style="margin-bottom:20px">'
        + _tab("all",     "All",         n_all)
        + _tab("movies",  "🎬 Movies",   n_movies)
        + _tab("tv",      "📺 TV",       n_tv)
        + _tab("cached",  "✅ Cached",   n_cached)
        + _tab("missing",   "❌ Missing",   n_missing)
        + _tab("upcoming",  "📅 Upcoming",  len(upcoming_eps))
        + _tab("logs",      "📋 Logs",      len(hi.recent_log_lines(500)))
        + '</div>'
    )

    # ── Search bar ────────────────────────────────────────────────────────────
    search_html = f"""
    <div class="search-bar">
      <input id="q" type="text" placeholder="Search titles…" value="{_html.escape(q)}"
             onkeydown="if(event.key==='Enter')go()">
      <button class="btn btn-add" onclick="go()">Search</button>
      {'<button class="btn btn-sec" onclick="location.href=\'/hash-indexer?tab='+tab+'\'">&times; Clear</button>' if q else ''}
      <button class="btn btn-sec" onclick="triggerReindex()" style="margin-left:auto">🔄 Re-index All</button>
      <button class="btn btn-sec" onclick="triggerRecheck()">⟳ Recheck AD</button>
      <button class="btn btn-add" onclick="syncStreams()">⚡ Sync Streams→Index</button>
    </div>"""

    # ── Table rows ────────────────────────────────────────────────────────────
    def row_html(r: dict) -> str:
        title_raw  = r["title"] or ""
        title_safe = _html.escape(title_raw)
        title_enc  = quote(title_raw, safe="")
        kind_enc   = quote(r["kind"], safe="")
        year_str   = f' ({r["year"]})' if r.get("year") else ""

        # Cached status indicator
        if r["cached_count"] > 0:
            status = (
                f'<span style="color:#4ade80;font-size:0.75rem;font-weight:700">✅ cached</span>'
                f'<span style="color:#555;font-size:0.72rem;margin-left:4px">'
                f'{r["cached_count"]}/{r["total_hashes"]} hashes</span>'
            )
        elif r["missing"]:
            missing_seasons = r.get("missing_seasons", [])
            if r.get("total_hashes", 0) == 0:
                miss_detail = "not indexed"
            elif missing_seasons:
                sn_list = ", ".join(f"S{s:02d}" for s in missing_seasons[:4])
                more    = f" +{len(missing_seasons)-4}" if len(missing_seasons) > 4 else ""
                miss_detail = f"missing {sn_list}{more}"
            else:
                miss_detail = "no cached hash"
            status = (
                f'<span style="color:#f87171;font-size:0.75rem;font-weight:700">❌ missing</span>'
                f' <span style="color:#555;font-size:0.68rem">{_html.escape(miss_detail)}</span>'
            )
        else:
            status = '<span style="color:#555;font-size:0.75rem">⏳ not cached</span>'

        # Pack badges
        packs = ""
        if r.get("has_series_pack"):
            packs += '<span style="background:#1a0a3a;color:#c084fc;padding:1px 6px;border-radius:10px;font-size:0.65rem;margin-right:3px">series pack</span>'
        if r.get("has_season_pack"):
            packs += '<span style="background:#0d2640;color:#60a5fa;padding:1px 6px;border-radius:10px;font-size:0.65rem;margin-right:3px">season pack</span>'

        # Season count for TV
        kind_badge = ""
        if r["kind"] == "tv":
            sc = r.get("season_count") or 0
            kind_badge = f'<span style="color:#555;font-size:0.72rem">{sc} season{"s" if sc != 1 else ""}</span>'
        else:
            kind_badge = '<span style="color:#555;font-size:0.72rem">movie</span>'

        # Library badge
        lib_badge = (
            '<span style="background:#14532d;color:#4ade80;padding:1px 6px;'
            'border-radius:10px;font-size:0.65rem">in library</span>'
            if r["in_library"] else
            '<span style="background:#1e1e2e;color:#444;padding:1px 6px;'
            'border-radius:10px;font-size:0.65rem">not in library</span>'
        )

        quality = _quality_pill(r.get("best_quality") or "")
        score   = _score_bar(r.get("best_score") or 0)

        last_checked = _fmt_ts(r.get("last_checked"))
        last_used    = _fmt_ts(r.get("last_used"))

        return (
            f'<tr data-title="{title_safe.lower()}" data-kind="{r["kind"]}" '
            f'data-cached="{1 if r["cached_count"] else 0}">'
            f'<td>'
            f'  <div style="font-weight:600;color:#e0e0e0">{title_safe}</div>'
            f'{"  <div style=\"font-size:0.72rem;color:#666;margin-top:1px\">" + _html.escape(year_str.strip()) + "</div>" if year_str.strip() else ""}'
            f'  <div style="margin-top:3px;display:flex;gap:4px;flex-wrap:wrap">'
            f'    {kind_badge} {lib_badge} {packs}'
            f'  </div>'
            f'</td>'
            f'<td>{status}</td>'
            f'<td>{quality}</td>'
            f'<td>{score}</td>'
            f'<td style="color:#555;font-size:0.78rem">{last_checked}</td>'
            f'<td style="color:#555;font-size:0.78rem">{last_used}</td>'
            f'<td style="white-space:nowrap">'
            f'  <button type="button" class="btn btn-sec hi-detail" style="padding:3px 9px;font-size:0.72rem" '
            f'    data-title="{title_safe}" data-title-enc="{title_enc}" data-kind="{r["kind"]}" data-kind-enc="{kind_enc}" '
            f'    onclick="showDetailFromBtn(this); return false;">Detail</button>'
            f'  <button type="button" class="btn btn-rem hi-reindex" style="padding:3px 9px;font-size:0.72rem;margin-left:4px" '
            f'    data-title="{title_safe}" data-title-enc="{title_enc}" '
            f'    onclick="reindexTitleFromBtn(this); return false;">Re-index</button>'
            + (
                '  <button type="button" class="btn btn-add hi-addlib"'
                f' style="padding:3px 9px;font-size:0.72rem;margin-left:4px"'
                f' data-title="{title_safe}" data-title-enc="{title_enc}"'
                f' data-year="{r.get("year") or ""}"'
                f' data-kind="{r["kind"]}" data-kind-enc="{kind_enc}">+ Library</button>'
                if not r["in_library"] else ""
            ) +
            f'</td>'
            f'</tr>'
        )

    table_rows = "".join(row_html(r) for r in page_rows)

    if table_rows:
        table_html = f"""
        <table>
          <thead><tr>
            <th>Title</th>
            <th>Status</th>
            <th>Quality</th>
            <th>Score</th>
            <th>Last checked</th>
            <th>Last played</th>
            <th></th>
          </tr></thead>
          <tbody>{table_rows}</tbody>
        </table>"""
    else:
        msg = f'No results for "{_html.escape(q)}"' if q else "Nothing indexed yet — add titles to your library to start indexing."
        table_html = f'<div class="empty">{msg}</div>'

    # ── Upcoming episodes — grouped by series, card layout ──────────────────
    upcoming_html = ""
    if tab == "upcoming":
        from datetime import date as _date
        import collections as _col
        today_d = _date.today()

        if upcoming_eps:
            # Group by series title
            by_series = _col.defaultdict(list)
            for u in upcoming_eps:
                by_series[u["title"]].append(u)

            cards = ""
            for series_title, eps in sorted(by_series.items()):
                eps_sorted = sorted(eps, key=lambda x: (x["season"], x["episode"]))

                ep_pills = ""
                for u in eps_sorted:
                    try:
                        air_d     = _date.fromisoformat(u["air_date"])
                        days      = (air_d - today_d).days
                    except Exception:
                        days = 999

                    if days == 0:
                        badge_bg, badge_col, label = "#7c2d12", "#fb923c", "today"
                    elif days == 1:
                        badge_bg, badge_col, label = "#7c2d12", "#fb923c", "tomorrow"
                    elif days <= 7:
                        badge_bg, badge_col, label = "#422006", "#fbbf24", f"in {days}d"
                    elif days <= 30:
                        badge_bg, badge_col, label = "#1a1a2e", "#818cf8", f"{u['air_date'][5:]}"
                    else:
                        badge_bg, badge_col, label = "#1a1a24", "#444",    f"{u['air_date'][5:]}"

                    indexed_dot = (
                        '<span style="width:6px;height:6px;border-radius:50%;'
                        'background:#4ade80;display:inline-block;margin-left:4px;'
                        'vertical-align:middle" title="indexed"></span>'
                        if u["indexed"] else ""
                    )

                    ep_pills += (
                        f'<div style="display:inline-flex;align-items:center;gap:3px;'
                        f'background:{badge_bg};border:1px solid {badge_col}33;'
                        f'border-radius:6px;padding:3px 8px;margin:2px">'
                        f'<span style="font-family:monospace;font-size:0.72rem;color:#aaa">'
                        f'S{u["season"]:02d}E{u["episode"]:02d}</span>'
                        f'<span style="font-size:0.65rem;color:{badge_col};margin-left:4px">'
                        f'{label}</span>'
                        f'{indexed_dot}'
                        f'</div>'
                    )

                # Next episode info
                next_ep  = eps_sorted[0]
                try:
                    next_d   = _date.fromisoformat(next_ep["air_date"])
                    next_days = (next_d - today_d).days
                    if next_days == 0:   next_label = "airs today"
                    elif next_days == 1: next_label = "airs tomorrow"
                    else:                next_label = f"next in {next_days}d"
                except Exception:
                    next_label = next_ep["air_date"]

                cards += (
                    f'<div style="background:#1a1a24;border:1px solid #2a2a3a;'
                    f'border-radius:10px;padding:14px 16px;margin-bottom:10px">'
                    f'<div style="display:flex;align-items:baseline;'
                    f'justify-content:space-between;margin-bottom:8px">'
                    f'<span style="font-weight:700;color:#e0e0e0;font-size:0.9rem">'
                    f'{_html.escape(series_title)}</span>'
                    f'<span style="font-size:0.72rem;color:#555">'
                    f'{len(eps)} episode{"s" if len(eps)!=1 else ""} · {next_label}</span>'
                    f'</div>'
                    f'<div style="display:flex;flex-wrap:wrap;gap:0">{ep_pills}</div>'
                    f'</div>'
                )

            legend = (
                '<div style="display:flex;gap:16px;flex-wrap:wrap;'
                'margin-bottom:16px;font-size:0.7rem;color:#555">'
                '<span><span style="color:#fb923c">●</span> within 24h</span>'
                '<span><span style="color:#fbbf24">●</span> this week</span>'
                '<span><span style="color:#818cf8">●</span> this month</span>'
                '<span><span style="color:#4ade80;font-size:0.5rem">●</span>'
                ' green dot = indexed</span>'
                '</div>'
            )

            upcoming_html = (
                f'<div style="margin-top:8px">'
                f'<div style="display:flex;align-items:center;'
                f'justify-content:space-between;margin-bottom:12px">'
                f'<h3 style="margin:0;color:#e0e0e0;font-size:0.95rem">'
                f'📅 {len(upcoming_eps)} upcoming episode'
                f'{"s" if len(upcoming_eps)!=1 else ""} across '
                f'{len(by_series)} series</h3>'
                f'</div>'
                f'{legend}'
                f'{cards}'
                f'</div>'
            )
        else:
            upcoming_html = (
                '<div class="empty" style="margin-top:20px">'
                'No upcoming episodes tracked yet. '
                'Episodes will appear here automatically as series are added to your library.'
                '</div>'
            )

    pager = _pagination("/hash-indexer", {"tab": tab, "q": q}, page, total_pages)

    count_str = f"{total} title{'s' if total != 1 else ''}"
    if q:
        count_str += f' matching "{_html.escape(q)}"'

    body = f"""
    <div style="display:flex;align-items:baseline;gap:12px;margin-bottom:20px">
      <h2 style="margin:0">🔎 Hash Indexer</h2>
      <span style="color:#555;font-size:0.82rem">{count_str}</span>
    </div>
    {stat_bar}
    {tabs_html}
    {search_html}
    <div id="result-msg" style="margin-bottom:12px;font-size:0.82rem;color:#4ade80;display:none"></div>
    {table_html}
    {upcoming_html}
    {pager}

    <!-- Detail drawer -->
    <div id="detail-drawer" style="display:none;position:fixed;right:0;top:0;bottom:0;width:480px;
         background:#13131a;border-left:1px solid #2a2a3a;padding:24px;overflow-y:auto;z-index:100">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
        <h2 id="detail-title" style="margin:0;font-size:1rem"></h2>
        <button onclick="closeDetail()" style="background:none;border:none;color:#888;font-size:1.3rem;cursor:pointer">✕</button>
      </div>
      <div id="detail-body" style="font-size:0.82rem"></div>
    </div>
    <div id="detail-overlay" onclick="closeDetail()"
         style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:99"></div>
    """

    extra = f"""<script>
function go() {{
  const q = encodeURIComponent(document.getElementById('q').value.trim());
  location.href = '/hash-indexer?tab={tab}&q=' + q;
}}
document.getElementById('q').addEventListener('keydown', e => {{ if(e.key==='Enter') go(); }});

// Direct Detail opener used by row buttons. This keeps the Detail button
// working even if another click handler or nested button stops delegated events.
function _decodeBtnData(btn, key, fallback='') {{
  if (!btn) return fallback;
  const enc = btn.dataset[key + 'Enc'];
  if (enc) {{
    try {{ return decodeURIComponent(enc); }} catch(e) {{ console.warn('decode failed', key, e); }}
  }}
  return btn.dataset[key] || fallback;
}}

function showDetailFromBtn(btn) {{
  if (!btn) return;
  const title = _decodeBtnData(btn, 'title', '');
  const kind  = _decodeBtnData(btn, 'kind', 'movie');
  if (!title) {{ showMsg('❌ Missing title for detail view'); return; }}
  showDetail(title, kind).catch(err => {{
    console.error('showDetail failed:', err);
    showMsg('❌ Detail failed: ' + (err && err.message ? err.message : err));
  }});
}}

function reindexTitleFromBtn(btn) {{
  if (!btn) return;
  const title = _decodeBtnData(btn, 'title', '');
  if (!title) {{ showMsg('❌ Missing title for re-index'); return; }}
  reindexTitle(title, btn).catch(err => {{
    console.error('reindex failed:', err);
    showMsg('❌ Re-index failed: ' + (err && err.message ? err.message : err));
  }});
}}

// Event delegation for Detail and Re-index buttons
// Avoids all HTML-encoding / JS-quoting issues with titles containing quotes/apostrophes
document.addEventListener('click', function(e) {{
  const detailBtn  = e.target.closest('.hi-detail');
  const reindexBtn = e.target.closest('.hi-reindex');
  if (detailBtn) {{
    e.preventDefault();
    showDetailFromBtn(detailBtn);
    return;
  }}
  if (reindexBtn) {{
    e.preventDefault();
    reindexTitleFromBtn(reindexBtn);
    return;
  }}
  const addLibBtn = e.target.closest('.hi-addlib');
  if (addLibBtn) {{
    e.preventDefault();
    addToLibraryFromIndex(
      _decodeBtnData(addLibBtn, 'title', ''),
      addLibBtn.dataset.year ? parseInt(addLibBtn.dataset.year) : null,
      _decodeBtnData(addLibBtn, 'kind', addLibBtn.dataset.kind || 'movie'),
      addLibBtn
    );
    return;
  }}
  // Copy info_hash — works on HTTP too (navigator.clipboard requires HTTPS/localhost).
  const copyBtn = e.target.closest('.hi-copy-btn');
  if (copyBtn) {{
    const txt = copyBtn.dataset.hash || '';
    _copyText(txt).then(ok => {{
      copyBtn.textContent = ok ? '✓' : '✗ no clipboard';
      copyBtn.style.color = ok ? '#4ade80' : '#f87171';
      setTimeout(() => {{
        copyBtn.textContent = 'copy';
        copyBtn.style.color = '#666';
      }}, 1500);
    }});
  }}
  // Remove a single hash-index entry by info_hash.
  const removeBtn = e.target.closest('.hi-remove-btn');
  if (removeBtn) {{
    const h        = removeBtn.dataset.hash || '';
    const title    = removeBtn.dataset.title || '';
    const mt       = removeBtn.dataset.mt || 'entry';
    const season   = removeBtn.dataset.season || '';
    const episode  = removeBtn.dataset.episode || '';
    const name     = removeBtn.dataset.name || '';
    let label = mt;
    if (mt === 'season' && season) label = 'Season ' + season + ' pack';
    else if (mt === 'series')      label = 'Series pack';
    else if (mt === 'episode')     label = 'S' + String(season).padStart(2,'0') + 'E' + String(episode).padStart(2,'0');
    const detail = name ? '\\n\\nTorrent: ' + name : '';
    if (!confirm('Remove this ' + label + ' from the hash index for "' + title + '"?' + detail +
                 '\\n\\nIt can be re-added later via Re-index or the next play.')) {{
      return;
    }}
    removeBtn.disabled = true;
    removeBtn.textContent = '⏳';
    fetch('/api/hash-index/delete-entry', {{
      method: 'POST',
      headers: {{'Content-Type': 'application/json'}},
      body: JSON.stringify({{info_hash: h}})
    }}).then(r => r.json().then(d => ({{ok: r.ok, d}})))
      .then(({{ok, d}}) => {{
        if (ok) {{
          showMsg('🗑 Removed ' + label + ' from hash index');
          // Refresh the drawer with the entry gone. Use the kind we recorded
          // when the drawer opened — DOM lookup after delete is unreliable.
          const drawer = document.getElementById('detail-drawer');
          showDetail(drawer.dataset.title || title, drawer.dataset.kind || 'tv');
        }} else {{
          showMsg('❌ ' + (d.detail || 'Failed to remove'));
          removeBtn.disabled = false;
          removeBtn.textContent = '🗑 remove';
        }}
      }})
      .catch(err => {{
        showMsg('❌ ' + err.message);
        removeBtn.disabled = false;
        removeBtn.textContent = '🗑 remove';
      }});
  }}

  // Blacklist a hash — same UX as remove but POSTs to /blacklist so the row
  // stays in the table with blacklisted=1 (won't reappear on rediscovery).
  const blacklistBtn = e.target.closest('.hi-blacklist-btn');
  if (blacklistBtn) {{
    const h        = blacklistBtn.dataset.hash || '';
    const title    = blacklistBtn.dataset.title || '';
    const mt       = blacklistBtn.dataset.mt || 'entry';
    const season   = blacklistBtn.dataset.season || '';
    const episode  = blacklistBtn.dataset.episode || '';
    const name     = blacklistBtn.dataset.name || '';
    let label = mt;
    if (mt === 'season' && season) label = 'Season ' + season + ' pack';
    else if (mt === 'series')      label = 'Series pack';
    else if (mt === 'episode')     label = 'S' + String(season).padStart(2,'0') + 'E' + String(episode).padStart(2,'0');
    const detail = name ? '\\n\\nTorrent: ' + name : '';
    if (!confirm('Blacklist this ' + label + ' for "' + title + '"?' + detail +
                 '\\n\\nIt will NEVER be used again, even if rediscovered by a future search.')) {{
      return;
    }}
    blacklistBtn.disabled = true;
    blacklistBtn.textContent = '⏳';
    fetch('/api/hash-index/blacklist', {{
      method: 'POST',
      headers: {{'Content-Type': 'application/json'}},
      body: JSON.stringify({{info_hash: h}})
    }}).then(r => r.json().then(d => ({{ok: r.ok, d}})))
      .then(({{ok, d}}) => {{
        if (ok) {{
          showMsg('🚫 Blacklisted ' + label);
          const drawer = document.getElementById('detail-drawer');
          showDetail(drawer.dataset.title || title, drawer.dataset.kind || 'tv');
        }} else {{
          showMsg('❌ ' + (d.detail || 'Failed to blacklist'));
          blacklistBtn.disabled = false;
          blacklistBtn.textContent = '🚫 blacklist';
        }}
      }})
      .catch(err => {{
        showMsg('❌ ' + err.message);
        blacklistBtn.disabled = false;
        blacklistBtn.textContent = '🚫 blacklist';
      }});
  }}

  // Add a hash-index entry to AllDebrid / Downloads. Cached entries become
  // ready immediately; uncached entries start downloading and are tracked on
  // the Downloads page.
  const addDownloadBtn = e.target.closest('.hi-add-download-btn');
  if (addDownloadBtn) {{
    const h      = addDownloadBtn.dataset.hash || '';
    const title  = addDownloadBtn.dataset.title || '';
    const cached = addDownloadBtn.dataset.cached === '1';
    const name   = addDownloadBtn.dataset.name || '';
    const action = cached ? 'add this cached torrent to AllDebrid?' : 'start downloading this uncached torrent?';
    const detail = name ? '\n\nTorrent: ' + name : '';
    if (!confirm('Add "' + title + '" — ' + action + detail)) return;

    addDownloadBtn.disabled = true;
    addDownloadBtn.textContent = '⏳ adding';
    fetch('/api/hash-index/add-to-downloads', {{
      method: 'POST',
      headers: {{'Content-Type': 'application/json'}},
      body: JSON.stringify({{info_hash: h}})
    }}).then(r => r.json().then(d => ({{ok: r.ok, d}})))
      .then(({{ok, d}}) => {{
        if (ok) {{
          showMsg(d.ready ? '✅ Added cached torrent — ready' : '⬇️ Download started — check Downloads page');
          addDownloadBtn.textContent = d.ready ? '✅ added' : '⬇️ downloading';
          setTimeout(() => showDetail(document.getElementById('detail-drawer').dataset.title || title, document.getElementById('detail-drawer').dataset.kind || 'tv'), 800);
        }} else {{
          showMsg('❌ ' + (d.detail || 'Failed to add torrent'));
          addDownloadBtn.disabled = false;
          addDownloadBtn.textContent = cached ? '➕ add' : '⬇ download';
        }}
      }})
      .catch(err => {{
        showMsg('❌ ' + err.message);
        addDownloadBtn.disabled = false;
        addDownloadBtn.textContent = cached ? '➕ add' : '⬇ download';
      }});
  }}

  // Tab switch in the detail drawer (Seasons / Hashes). Toggling here
  // instead of via inline onclick because the build* functions are closure-
  // scoped inside showDetail and unreachable from HTML attribute scope.
  const tabBtn = e.target.closest('.detail-tab-btn');
  if (tabBtn) {{
    const which = tabBtn.dataset.tab;
    document.querySelectorAll('.detail-tab-btn').forEach(t => {{
      const active = (t.dataset.tab === which);
      t.style.fontWeight   = active ? '700' : '400';
      t.style.color        = active ? '#e0e0e0' : '#888';
      t.style.borderBottom = active ? '2px solid #4ade80' : '2px solid transparent';
    }});
    document.querySelectorAll('.detail-tab-panel').forEach(p => {{
      p.style.display = (p.dataset.panel === which) ? 'block' : 'none';
    }});
  }}
}});

// Clipboard helper with HTTP fallback. navigator.clipboard.writeText is only
// available on HTTPS or localhost; on plain HTTP (typical for self-hosted on
// LAN IPs) it's undefined and silently fails. Fall back to execCommand.
function _copyText(text) {{
  if (navigator.clipboard && navigator.clipboard.writeText && window.isSecureContext) {{
    return navigator.clipboard.writeText(text).then(() => true).catch(() => _copyFallback(text));
  }}
  return Promise.resolve(_copyFallback(text));
}}
function _copyFallback(text) {{
  try {{
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity  = '0';
    ta.style.left     = '-9999px';
    document.body.appendChild(ta);
    ta.focus(); ta.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    return ok;
  }} catch (e) {{
    return false;
  }}
}}

async function addToLibraryFromIndex(title, year, kind, btn) {{
  btn.disabled = true;
  btn.textContent = '⏳';
  showMsg('Adding ' + title + ' to library…');
  try {{
    const r = await fetch('/api/library/add', {{
      method: 'POST',
      headers: {{'Content-Type': 'application/json'}},
      body: JSON.stringify({{
        media_type: kind === 'tv' ? 'series' : 'movie',
        title, year: year || null, arr_id: null, season_count: 0
      }})
    }});
    const d = await r.json();
    if (r.ok) {{
      showMsg('✅ ' + title + ' added to library');
      btn.textContent = '✅ Added';
      setTimeout(() => location.reload(), 1500);
    }} else {{
      showMsg('❌ ' + (d.detail || d.message || 'Failed'));
      btn.disabled = false;
      btn.textContent = '+ Library';
    }}
  }} catch(e) {{
    showMsg('❌ ' + e.message);
    btn.disabled = false;
    btn.textContent = '+ Library';
  }}
}}

async function triggerReindex() {{
  const tab = new URLSearchParams(location.search).get('tab') || 'all';
  const r = await fetch('/api/hash-index/reindex', {{
    method:'POST',
    headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{category:tab}})
  }});
  const d = await r.json();
  if (!r.ok) {{ showMsg('❌ ' + (d.detail || d.message || 'Re-index failed')); return; }}
  showMsg(d.message || ('Re-index ' + tab + ' started'));
}}

async function syncStreams() {{
  const r = await fetch('/api/hash-index/sync-streams', {{method:'POST'}});
  const d = await r.json();
  showMsg(d.message || '⚡ Sync complete');
}}

async function triggerRecheck() {{
  const r = await fetch('/api/hash-index/recheck', {{method:'POST'}});
  const d = await r.json();
  showMsg(d.message || 'Recheck queued');
}}

async function reindexTitle(title, btn=null) {{
  if (btn) {{ btn.disabled = true; btn.dataset.oldText = btn.textContent; btn.textContent = '⏳'; }}
  try {{
    const r = await fetch('/api/hash-index/reindex-title', {{
      method: 'POST',
      headers: {{'Content-Type': 'application/json'}},
      body: JSON.stringify({{title}})
    }});
    let d = {{}};
    try {{ d = await r.json(); }} catch(e) {{ d = {{detail: await r.text()}}; }}
    showMsg(r.ok ? '🔄 Re-indexing ' + title : '❌ ' + (d.detail || 'Error'));
  }} finally {{
    if (btn) {{ btn.disabled = false; btn.textContent = btn.dataset.oldText || 'Re-index'; }}
  }}
}}

function showMsg(msg) {{
  const el = document.getElementById('result-msg');
  if (!el) {{ console.log('showMsg:', msg); return; }}
  el.textContent = msg;
  el.style.display = 'block';
  setTimeout(() => el.style.display = 'none', 4000);
}}

async function showDetail(title, kind) {{
  const isTV = (kind === 'tv');
  document.getElementById('detail-title').textContent = title;
  document.getElementById('detail-body').innerHTML = '<div style="color:#555">Loading…</div>';
  const drawer = document.getElementById('detail-drawer');
  drawer.style.display = 'block';
  drawer.dataset.title = title;
  drawer.dataset.kind  = kind;
  document.getElementById('detail-overlay').style.display = 'block';

  // Isolate the two fetches so a failure in the series-detail endpoint
  // (e.g. TMDB outage, slow Sonarr) can't break the Hashes tab and its
  // copy/remove buttons. Each error is logged but the other tab still loads.
  let hashData   = {{ hashes: [] }};
  let seriesData = null;
  try {{
    const hashRes = await fetch('/api/hash-index/detail?title=' + encodeURIComponent(title));
    hashData = await hashRes.json();
    if (!hashRes.ok) throw new Error(hashData.detail || 'Hash detail failed');
  }} catch (err) {{
    console.error('hash-index/detail failed:', err);
  }}
  if (isTV) {{
    try {{
      const sRes = await fetch('/api/hash-index/series-detail?title=' + encodeURIComponent(title));
      seriesData = await sRes.json();
      if (!sRes.ok) throw new Error(seriesData.detail || 'Series detail failed');
    }} catch (err) {{
      console.error('hash-index/series-detail failed:', err);
    }}
  }}

  const rows = hashData.hashes || [];

  // HTML-escape any user-controlled string before putting it in an attribute.
  // The dataset DOM API will decode entities when read back, so this is safe
  // and won't double-escape. Without this, titles containing &, ", ', <, >
  // could break the data-title attribute and silently disable the click
  // handlers — that was the "hash button does not work for TV shows" report.
  function _attr(s) {{
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }}

  const qualColour = {{
    '2160p': '#c084fc', '4k': '#c084fc', 'uhd': '#c084fc',
    '1080p': '#60a5fa', '720p': '#86efac', '480p': '#fbbf24'
  }};

  // ── Build hashes tab ────────────────────────────────────────────────────────
  function buildHashesTab() {{
    if (!rows.length) return '<div style="color:#555;padding:20px 0">No hashes indexed yet.</div>';
    const topCachedIdx = rows.findIndex(h => h.is_cached);
    let html = '';
    const cachedCount = rows.filter(h => h.is_cached).length;
    html += `<div style="font-size:0.75rem;color:#555;margin-bottom:12px">
      ${{rows.length}} hash${{rows.length !== 1 ? 'es' : ''}} indexed
      · ${{cachedCount}} cached on AllDebrid
      ${{topCachedIdx >= 0
        ? '· <span style="color:#4ade80">top result will be used on play</span>'
        : '· <span style="color:#f87171">none cached — play will trigger live search</span>'}}
    </div>`;
    for (let i = 0; i < rows.length; i++) {{
      const h = rows[i];
      const isActive  = (i === topCachedIdx);
      const blocked   = !!h.blacklisted;
      const border    = blocked  ? '1px solid #5a2020'
                      : isActive ? '1px solid #4ade80'
                      :            '1px solid #2a2a3a';
      const bg        = blocked  ? '#1c0f0f'
                      : isActive ? '#0d2010'
                      :            '#1a1a24';
      const qcol      = qualColour[h.quality] || '#555';
      const score_pct = Math.min(100, Math.round((h.score || 0) / 120 * 100));
      const score_col = score_pct >= 70 ? '#4ade80' : score_pct >= 40 ? '#f97316' : '#f87171';
      const ts        = h.last_checked ? new Date(h.last_checked * 1000).toLocaleString() : 'never';
      const used      = h.last_used    ? new Date(h.last_used * 1000).toLocaleString()    : 'never';
      const season_ep = h.season
        ? 'S' + String(h.season).padStart(2,'0') + (h.episode ? 'E' + String(h.episode).padStart(2,'0') : ' (pack)')
        : '';
      const fullHash  = h.info_hash || '—';
      html += `<div style="background:${{bg}};border:${{border}};border-radius:8px;padding:14px;margin-bottom:10px;${{blocked ? 'opacity:0.7;' : ''}}">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px">
          <div style="flex:1;min-width:0">
            <div style="font-weight:600;color:#e0e0e0;font-size:0.84rem;word-break:break-word;line-height:1.3">${{_attr(h.torrent_name || '—')}}</div>
            ${{blocked  ? '<div style="margin-top:4px"><span style="background:#5a2020;color:#f87171;font-size:0.65rem;font-weight:700;padding:2px 7px;border-radius:10px">🚫 BLACKLISTED</span></div>' : ''}}
            ${{isActive && !blocked ? '<div style="margin-top:4px"><span style="background:#14532d;color:#4ade80;font-size:0.65rem;font-weight:700;padding:2px 7px;border-radius:10px">▶ WILL USE ON PLAY</span></div>' : ''}}
          </div>
          <div style="margin-left:10px;flex-shrink:0">
            ${{blocked ? '<span style="color:#f87171;font-weight:700">🚫 blocked</span>'
              : h.is_cached ? '<span style="color:#4ade80;font-weight:700">✅ cached</span>'
                            : '<span style="color:#f87171">✗ not cached</span>'}}
          </div>
        </div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:10px">
          <span style="color:${{qcol}};font-size:0.75rem;font-weight:700;background:${{qcol}}22;padding:1px 7px;border-radius:10px">${{h.quality || '?'}}</span>
          <span style="font-size:0.72rem;color:#777">${{h.media_type}}</span>
          ${{season_ep ? `<span style="font-size:0.72rem;color:#777">${{season_ep}}</span>` : ''}}
          <span style="font-size:0.72rem;color:#555">${{h.strategy || '—'}}</span>
          <div style="display:flex;align-items:center;gap:5px;margin-left:auto">
            <div style="width:56px;height:5px;background:#111;border-radius:3px;overflow:hidden">
              <div style="width:${{score_pct}}%;height:100%;background:${{score_col}};border-radius:3px"></div>
            </div>
            <span style="font-size:0.72rem;color:#888">${{h.score}}</span>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px;background:#111;border-radius:5px;padding:5px 8px">
          <span style="font-family:monospace;font-size:0.68rem;color:#666;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${{fullHash}}</span>
          <button class="hi-copy-btn" data-hash="${{fullHash}}"
                  style="background:none;border:1px solid #333;border-radius:4px;color:#666;font-size:0.65rem;padding:2px 6px;cursor:pointer;flex-shrink:0">copy</button>
          <button class="hi-add-download-btn" data-hash="${{fullHash}}"
                  data-title="${{_attr(h.title || title)}}"
                  data-cached="${{h.is_cached ? '1' : '0'}}"
                  data-name="${{_attr(h.torrent_name || '')}}"
                  title="Add this torrent. Cached entries are ready immediately; uncached entries start downloading."
                  style="background:none;border:1px solid ${{h.is_cached ? '#14532d' : '#7c2d12'}};border-radius:4px;color:${{h.is_cached ? '#4ade80' : '#fb923c'}};font-size:0.65rem;padding:2px 6px;cursor:pointer;flex-shrink:0">${{h.is_cached ? '➕ add' : '⬇ download'}}</button>
          <button class="hi-remove-btn" data-hash="${{fullHash}}"
                  data-title="${{_attr(h.title || title)}}"
                  data-mt="${{_attr(h.media_type || '')}}"
                  data-season="${{_attr(h.season || '')}}"
                  data-episode="${{_attr(h.episode || '')}}"
                  data-name="${{_attr(h.torrent_name || '')}}"
                  title="Remove this entry from the hash index"
                  style="background:none;border:1px solid #5a2020;border-radius:4px;color:#f87171;font-size:0.65rem;padding:2px 6px;cursor:pointer;flex-shrink:0">🗑 remove</button>
          <button class="hi-blacklist-btn" data-hash="${{fullHash}}"
                  data-title="${{_attr(h.title || title)}}"
                  data-mt="${{_attr(h.media_type || '')}}"
                  data-season="${{_attr(h.season || '')}}"
                  data-episode="${{_attr(h.episode || '')}}"
                  data-name="${{_attr(h.torrent_name || '')}}"
                  title="Blacklist this hash — never use it again even if re-discovered"
                  style="background:none;border:1px solid #4a2a2a;border-radius:4px;color:#fbbf24;font-size:0.65rem;padding:2px 6px;cursor:pointer;flex-shrink:0">🚫 blacklist</button>
        </div>
        <div style="display:flex;gap:20px;flex-wrap:wrap">
          <span style="font-size:0.68rem;color:#444">checked: ${{ts}}</span>
          <span style="font-size:0.68rem;color:#444">last played: ${{used}}</span>
          ${{h.file_size ? `<span style="font-size:0.68rem;color:#444">size: ${{(h.file_size/1e9).toFixed(1)}} GB</span>` : ''}}
        </div>
      </div>`;
    }}
    return html;
  }}

  // ── Build seasons tab (TV only) ─────────────────────────────────────────────
  function buildSeasonsTab(sd) {{
    if (!sd) return '';
    const seasons = sd.seasons || {{}};
    const seasonNums = Object.keys(seasons).map(Number).sort((a,b) => a-b);
    let html = '';

    // Series-level search button
    html += `<div style="display:flex;justify-content:space-between;align-items:center;
                         margin-bottom:16px;padding-bottom:12px;border-bottom:1px solid #2a2a3a">
      <div>
        ${{sd.has_series_pack && sd.series_pack?.is_cached
          ? '<span style="color:#4ade80;font-size:0.78rem;font-weight:700">✅ series pack cached</span>'
          : sd.has_series_pack
            ? '<span style="color:#555;font-size:0.78rem">series pack indexed (not cached)</span>'
            : '<span style="color:#555;font-size:0.78rem">no series pack indexed</span>'
        }}
        <div style="font-size:0.7rem;color:#444;margin-top:2px">
          ${{sd.total_hashes}} hashes · ${{sd.cached_hashes}} cached
        </div>
      </div>
      <button class="btn btn-add" style="padding:4px 12px;font-size:0.75rem"
              onclick="searchSeries('${{sd.title.replace(/'/g, "\\'")}}')">
        🔍 Search whole series
      </button>
    </div>`;

    if (!seasonNums.length) {{
      html += '<div style="color:#555;font-size:0.82rem">No seasons indexed yet. Use Search to populate.</div>';
      return html;
    }}

    for (const sn of seasonNums) {{
      const s = seasons[sn];
      const snPad = String(sn).padStart(2, '0');
      const expCount = s.expected_count || 0;
      const cachedCount = s.cached_episodes || 0;
      const missingList = s.missing_episodes || [];
      const complete = !!s.complete;

      // Build header status: prefer "complete" over "pack cached" if Sonarr-known
      let packStatus;
      if (s.has_season_pack && s.season_pack?.is_cached) {{
        packStatus = complete
          ? '<span style="color:#4ade80;font-size:0.7rem">✅ pack cached · complete</span>'
          : '<span style="color:#fbbf24;font-size:0.7rem">⚠️ pack cached · ' + missingList.length + ' missing</span>';
      }} else if (s.has_season_pack) {{
        packStatus = '<span style="color:#555;font-size:0.7rem">pack indexed (not cached)</span>';
      }} else {{
        packStatus = complete
          ? '<span style="color:#4ade80;font-size:0.7rem">✅ all episodes cached</span>'
          : (cachedCount > 0
              ? '<span style="color:#fbbf24;font-size:0.7rem">⚠️ ' + cachedCount + '/' + expCount + ' cached</span>'
              : (expCount > 0
                  ? '<span style="color:#f87171;font-size:0.7rem">❌ 0/' + expCount + ' cached</span>'
                  : '<span style="color:#3a3a4a;font-size:0.7rem">no pack</span>'));
      }}

      // Sort merged episode list. Use expected_count to ensure every ep number is present.
      const epsMap = s.episodes || {{}};
      const epNums = [];
      if (expCount > 0) {{
        // Render 1..expected_count so missing slots are visible
        for (let i = 1; i <= expCount; i++) epNums.push(i);
        // Plus any indexed episodes outside that range (shouldn't happen but be safe)
        Object.keys(epsMap).map(Number).forEach(n => {{
          if (!epNums.includes(n)) epNums.push(n);
        }});
        epNums.sort((a, b) => a - b);
      }} else {{
        Object.keys(epsMap).map(Number).sort((a,b) => a-b).forEach(n => epNums.push(n));
      }}

      html += `<div style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:8px;
                            margin-bottom:8px;overflow:hidden">

        <!-- Season header row -->
        <div style="display:flex;align-items:center;justify-content:space-between;
                    padding:10px 14px;cursor:pointer;user-select:none"
             onclick="toggleSeason('sn-${{snPad}}')">
          <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
            <span style="color:#e0e0e0;font-weight:600;font-size:0.85rem">Season ${{sn}}</span>
            ${{packStatus}}
            ${{expCount > 0
              ? '<span style="color:#555;font-size:0.7rem">' + cachedCount + '/' + expCount + ' ep cached</span>'
              : '<span style="color:#555;font-size:0.7rem">' + (s.episode_count || 0) + ' ep indexed</span>'
            }}
          </div>
          <div style="display:flex;align-items:center;gap:8px">
            <button class="btn btn-sec" style="padding:3px 9px;font-size:0.7rem"
                    onclick="event.stopPropagation();searchSeason('${{sd.title.replace(/'/g, "\\'")}}', ${{sn}})">
              🔍 Search S${{snPad}}
            </button>
            <span id="chevron-${{snPad}}" style="color:#555;font-size:0.8rem;transition:transform 0.15s">▶</span>
          </div>
        </div>

        <!-- Episode rows (collapsed by default) -->
        <div id="sn-${{snPad}}" style="display:none;border-top:1px solid #2a2a3a">`;

      if (!epNums.length) {{
        html += `<div style="padding:10px 14px;color:#555;font-size:0.78rem">
          No episodes for this season — neither the hash index nor TMDB knows
          of any. Configure a TMDB API key in Settings to enumerate expected
          episodes, or run a search to populate the index.</div>`;
      }} else {{
        for (const ep of epNums) {{
          const e = epsMap[ep] || {{}};
          const epPad = String(ep).padStart(2,'0');
          const qcol  = qualColour[e.quality] || '#555';
          const hasHash    = !!e.info_hash;
          // is_cached now reflects the HASH INDEX truth (per-episode hash
          // cached on AllDebrid OR covered by a cached pack). Disk symlink
          // state is shown separately via needsRepair.
          const cached     = !!e.is_cached;
          const hashCached = !!e.hash_cached;
          const coveredByPack = !!e.covered_by_pack;
          const needsRepair = !!e.needs_repair;

          // Status pill — reflects on-disk truth, not just AllDebrid state.
          // Status pill — reflects the HASH INDEX truth (cached on AllDebrid
          // or covered by a cached pack). The on-disk symlink state surfaces
          // as a small repair indicator without overriding the cached signal.
          let pill;
          if (cached && needsRepair) {{
            pill = '<span style="color:#4ade80;font-size:0.68rem" title="cached in hash index — symlink being repaired in the background">✅🔧</span>';
          }} else if (cached) {{
            pill = '<span style="color:#4ade80;font-size:0.68rem" title="cached in hash index (AllDebrid or pack-covered)">✅</span>';
          }} else if (hasHash) {{
            pill = '<span style="color:#fbbf24;font-size:0.68rem" title="indexed but not cached on AllDebrid">⚠</span>';
          }} else {{
            pill = '<span style="color:#f87171;font-size:0.68rem" title="missing from hash index — click 🔍 to search">✗</span>';
          }}

          const qualityHtml = e.quality
            ? `<span style="color:${{qcol}};font-size:0.68rem">${{e.quality}}</span>`
            : '<span style="color:#3a3a4a;font-size:0.68rem">—</span>';
          const scoreHtml = (e.score !== undefined && hasHash)
            ? `<span style="color:#444;font-size:0.68rem">score: ${{e.score}}</span>`
            : '<span style="color:#3a3a4a;font-size:0.68rem">no hash</span>';
          const epTitle = e.ep_title
            ? `<span style="color:#666;font-size:0.7rem;margin-left:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:260px">${{e.ep_title.replace(/</g,'&lt;')}}</span>`
            : '';
          // Highlight rows that have no hash-index backing at all (red),
          // and gently tint rows that need symlink repair (amber).
          const rowBg = (!cached && !hasHash)
            ? 'background:#1e1414'
            : (needsRepair ? 'background:#1e1a14' : '');

          html += `<div style="display:flex;align-items:center;justify-content:space-between;
                               padding:7px 14px;border-bottom:1px solid #1e1e2e;${{rowBg}}">
            <div style="display:flex;align-items:center;gap:8px;min-width:0;flex:1">
              ${{pill}}
              <span style="color:#888;font-size:0.78rem;font-family:monospace">S${{snPad}}E${{epPad}}</span>
              ${{qualityHtml}}
              ${{scoreHtml}}
              ${{epTitle}}
            </div>
            <button class="btn btn-sec" style="padding:2px 7px;font-size:0.65rem;flex-shrink:0"
                    onclick="searchEpisode('${{sd.title.replace(/'/g, "\\'")}}', ${{sn}}, ${{ep}})">
              🔍 S${{snPad}}E${{epPad}}
            </button>
          </div>`;
        }}
      }}

      html += `</div></div>`;
    }}

    return html;
  }}

  // ── Assemble the drawer ─────────────────────────────────────────────────────
  // Both tabs are rendered upfront into separate panels and toggled via CSS.
  // We avoid inline onclick handlers because renderTab/buildHashesTab/
  // buildSeasonsTab are closure-scoped inside showDetail — an HTML onclick
  // attribute is evaluated in global scope and can't see them, so the tabs
  // would silently not switch (the "hashes button doesn't work" report).
  let drawerHtml = '';

  if (isTV && seriesData) {{
    const seasonsHtml = buildSeasonsTab(seriesData);
    const hashesHtml  = buildHashesTab();
    drawerHtml += `<div style="display:flex;gap:0;margin-bottom:16px;border-bottom:1px solid #2a2a3a">
      <button class="detail-tab-btn" data-tab="seasons"
              style="background:none;border:none;border-bottom:2px solid #4ade80;color:#e0e0e0;
                     font-size:0.82rem;font-weight:700;padding:6px 14px;cursor:pointer">📺 Seasons</button>
      <button class="detail-tab-btn" data-tab="hashes"
              style="background:none;border:none;border-bottom:2px solid transparent;color:#888;
                     font-size:0.82rem;font-weight:400;padding:6px 14px;cursor:pointer">🗄 Hashes</button>
    </div>
    <div class="detail-tab-panel" data-panel="seasons" style="display:block">${{seasonsHtml}}</div>
    <div class="detail-tab-panel" data-panel="hashes"  style="display:none">${{hashesHtml}}</div>`;
  }} else {{
    drawerHtml += `<div class="detail-tab-panel" data-panel="hashes" style="display:block">${{buildHashesTab()}}</div>`;
  }}

  document.getElementById('detail-body').innerHTML = drawerHtml;
}}

// ── Season/episode search helpers ─────────────────────────────────────────────

async function searchSeries(title) {{
  _runSearch(title, 'episode', null, null);
}}

async function searchSeason(title, season) {{
  _runSearch(title, 'episode', season, null);
}}

async function searchEpisode(title, season, episode) {{
  _runSearch(title, 'episode', season, episode);
}}

async function _runSearch(title, mediaType, season, episode) {{
  const label = season
    ? (episode ? `S${{String(season).padStart(2,'0')}}E${{String(episode).padStart(2,'0')}}` : `Season ${{season}}`)
    : 'whole series';

  showMsg(`🔍 Searching ${{title}} ${{label}}…`);

  try {{
    const r = await fetch('/api/hash-index/search', {{
      method: 'POST',
      headers: {{'Content-Type': 'application/json'}},
      body: JSON.stringify({{ title, media_type: mediaType, season, episode }}),
    }});
    const d = await r.json();
    if (r.ok) {{
      const msg = d.cached > 0
        ? `✅ ${{d.cached}} cached hash(es) found for ${{title}} ${{label}}`
        : `⚠️ No cached results on AllDebrid for ${{title}} ${{label}}`;
      showMsg(msg);
      // Refresh the drawer with updated data
      if (d.breakdown) {{
        showDetail(title, 'tv');
      }}
    }} else {{
      showMsg('❌ Search error: ' + (d.detail || 'Unknown error'));
    }}
  }} catch(e) {{
    showMsg('❌ Search failed: ' + e.message);
  }}
}}

// ── Season expand/collapse ────────────────────────────────────────────────────

function toggleSeason(id) {{
  const el  = document.getElementById(id);
  const snPad = id.replace('sn-', '');
  const chev = document.getElementById('chevron-' + snPad);
  if (!el) return;
  const open = el.style.display !== 'none';
  el.style.display  = open ? 'none' : 'block';
  if (chev) chev.style.transform = open ? '' : 'rotate(90deg)';
}}

function closeDetail() {{
  document.getElementById('detail-drawer').style.display = 'none';
  document.getElementById('detail-overlay').style.display = 'none';
}}

document.addEventListener('keydown', e => {{ if (e.key === 'Escape') closeDetail(); }});
</script>"""

    return _page("Hash Indexer", "hashindexer", body, extra)


# ── /api/hash-index/detail ────────────────────────────────────────────────────

@app.get("/api/hash-index/detail")
async def api_hash_index_detail(title: str, request: Request):
    """Return all hash rows for a single title — for the detail drawer."""
    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    if not hi:
        raise HTTPException(503, "Hash index not initialised")
    rows = hi.list_hashes_for_title(title)
    return {"title": title, "hashes": rows}


# ── /api/hash-index/series-detail ────────────────────────────────────────────

@app.get("/api/hash-index/series-detail")
async def api_hash_index_series_detail(title: str, request: Request):
    """
    Return season/episode breakdown for a TV series detail drawer.

    Data sources:
      - HASH INDEX is the source of truth for "what's cached" (per-episode
        hash entries, season packs, series packs — each with is_cached).
      - TMDB provides the expected season/episode list so the UI can show
        which episodes are missing from the index.

    Sonarr and Overseerr are not consulted here. The hash index decides
    what's cached; TMDB decides what should exist.
    """
    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    if not hi:
        raise HTTPException(503, "Hash index not initialised")

    breakdown = hi.get_series_breakdown(title)

    # Source of truth: TMDB (via _get_series_episodes_via_tmdb). Everything
    # series-related in the hash-index goes through TMDB so the UI stays in
    # sync with the canonical metadata source — no Sonarr / Overseerr coupling.
    db: CacheDB = request.app.state.db

    expected_episodes: list[dict] = []
    series_total_eps  = 0
    series_total_seasons = 0
    try:
        expected_episodes = await _get_series_episodes_via_tmdb(
            request.app, title, include_unreleased=False
        ) or []
        seasons_seen = set()
        for ep in expected_episodes:
            sn = ep.get("season", 0)
            if sn and sn > 0:
                seasons_seen.add(sn)
        series_total_seasons = len(seasons_seen)
        series_total_eps = sum(
            1 for ep in expected_episodes
            if (ep.get("season") or 0) > 0
        )

        # Persist TMDB-verified season count back to the library entry so the
        # rest of the system (indexer, UI lists, cache-ahead) stays in sync.
        # Only update if the stored value differs to avoid pointless writes.
        if series_total_seasons > 0:
            try:
                lib_entry = next(
                    (r for r in db.fake_library_list(media_type="series")
                     if (r.get("title") or "").lower() == (title or "").lower()),
                    None,
                )
                if lib_entry and lib_entry.get("season_count") != series_total_seasons:
                    db.fake_library_set_season_count(title, "series", series_total_seasons)
                    log.info(
                        f"📺 {title!r}: season_count {lib_entry.get('season_count')} "
                        f"→ {series_total_seasons} (TMDB) — persisted"
                    )
            except Exception as e:
                log.debug(f"series-detail season_count persist {title!r}: {e}")
    except Exception as e:
        log.debug(f"series-detail: TMDB fetch failed for {title!r}: {e}")

    # Group expected episodes by season
    expected_by_season: dict[int, list[dict]] = {}
    for ep in expected_episodes:
        sn = ep.get("season") or 0
        if sn <= 0:
            continue
        expected_by_season.setdefault(sn, []).append(ep)

    # Merge into breakdown's seasons. Add seasons that exist per TMDB but
    # aren't yet indexed, and add missing episodes within each season.
    seasons_out = breakdown.get("seasons", {}) or {}
    has_series_pack_cached = bool(
        breakdown.get("series_pack")
        and breakdown["series_pack"].get("is_cached")
    )

    # Auto-repair queue — on-disk symlink missing for an episode that the
    # CacheDB claims is cached. Triggers a background re-resolve so playback
    # works next time, without blocking this response. Display state below
    # is driven by the HASH INDEX (and TMDB for expected list), not by disk.
    repair_queue: list[PlayEvent] = []

    def _disk_status(title: str, year, sn: int, en: int) -> tuple[bool, bool, dict]:
        """
        Look up the CacheDB row for this episode and verify the symlink.
        Returns (db_says_cached, symlink_ok, row). Used only for the auto-
        repair check — does NOT drive display state.
        """
        try:
            ev = PlayEvent(
                media_type=MediaType.episode, title=title, year=year,
                season=sn, episode=en,
            )
            row = db.get(ev.cache_key()) or {}
        except Exception:
            return False, False, {}
        db_cached = (row.get("status") == "cached")
        sym_ok    = db_cached and _cached_symlink_valid(row.get("strm_path"))
        return db_cached, sym_ok, row

    # Lookup library year (for accurate cache_key derivation in disk check)
    try:
        lib_entry = next(
            (r for r in db.fake_library_list(media_type="series")
             if (r.get("title") or "").lower() == (title or "").lower()),
            None,
        )
        title_year = (lib_entry or {}).get("year") if lib_entry else None
    except Exception:
        title_year = None

    for sn, eps in expected_by_season.items():
        season_entry = seasons_out.get(sn) or {
            "season": sn, "has_season_pack": False, "season_pack": None,
            "cached": False, "episode_count": 0, "cached_episodes": 0,
            "episodes": {},
        }
        # Pack-cached on AllDebrid covers every episode in the season.
        # That's the canonical "cached" signal — it's what the hash index
        # tracks, and what the resolver uses on play. On-disk symlink state
        # is checked separately for auto-repair only.
        season_pack_cached = bool(
            season_entry.get("season_pack")
            and season_entry["season_pack"].get("is_cached")
        )
        pack_covers = season_pack_cached or has_series_pack_cached

        merged_episodes = dict(season_entry.get("episodes") or {})
        for ep in eps:
            en = ep.get("episode") or 0
            if not en:
                continue

            db_cached, sym_ok, row = _disk_status(title, title_year, sn, en)

            indexed = merged_episodes.get(en)
            if indexed:
                # Source of truth: the hash index (`indexed['is_cached']`)
                # which reflects whether the per-episode hash OR a covering
                # pack is cached on AllDebrid. We preserve that as is_cached.
                # Layer pack-coverage on top so episodes with no individual
                # hash still show "cached" when a pack covers them.
                hash_cached         = bool(indexed.get("is_cached")) or pack_covers
                indexed["expected"]   = True
                indexed["air_date"]   = ep.get("air_date") or indexed.get("air_date")
                indexed["ep_title"]   = ep.get("title")    or indexed.get("ep_title")
                indexed["is_cached"]    = hash_cached
                indexed["hash_cached"]  = hash_cached
                indexed["covered_by_pack"] = pack_covers
                # On-disk verification — display layer can show a repair pill
                # but is_cached itself reflects the hash-index answer.
                indexed["symlink_ok"]   = sym_ok
                indexed["db_cached"]    = db_cached
                indexed["needs_repair"] = (hash_cached and db_cached and not sym_ok)
                merged_episodes[en]     = indexed
            else:
                # Not in the hash index. Only "cached" via pack coverage.
                merged_episodes[en] = {
                    "season":          sn,
                    "episode":         en,
                    "expected":        True,
                    "indexed":         False,
                    "is_cached":       pack_covers,
                    "hash_cached":     pack_covers,
                    "covered_by_pack": pack_covers,
                    "symlink_ok":      sym_ok,
                    "db_cached":       db_cached,
                    "needs_repair":    (pack_covers and db_cached and not sym_ok),
                    "quality":         row.get("quality"),
                    "score":           0,
                    "info_hash":       None,
                    "torrent_name":    row.get("torrent_name"),
                    "air_date":        ep.get("air_date") or "",
                    "ep_title":        ep.get("title")    or "",
                }

            # Queue auto-repair if hash-cached + DB-cached but no symlink.
            if (db_cached and not sym_ok):
                try:
                    repair_queue.append(PlayEvent(
                        media_type=MediaType.episode,
                        title=title, year=title_year,
                        season=sn, episode=en,
                    ))
                except Exception:
                    pass

        # Season stats — driven by hash-index truth.
        expected_count   = len(eps)
        indexed_count    = sum(1 for v in merged_episodes.values() if v.get("info_hash"))
        cached_ep_count  = sum(1 for v in merged_episodes.values() if v.get("is_cached"))
        missing          = sorted(
            e.get("episode") for e in eps
            if not (merged_episodes.get(e.get("episode")) or {}).get("is_cached")
        )

        season_entry["episodes"]         = merged_episodes
        season_entry["expected_count"]   = expected_count
        season_entry["episode_count"]    = indexed_count
        season_entry["cached_episodes"]  = cached_ep_count
        season_entry["missing_episodes"] = missing
        season_entry["complete"]         = (cached_ep_count >= expected_count and expected_count > 0)
        seasons_out[sn] = season_entry

    # Mark each existing season entry for "expected_count" if Sonarr didn't
    # know about it (rare — e.g., specials or no library entry yet).
    for sn, s in seasons_out.items():
        s.setdefault("expected_count", s.get("episode_count", 0))
        s.setdefault("missing_episodes", [])
        s.setdefault("complete", False)

    breakdown["seasons"]              = seasons_out
    breakdown["series_total_seasons"] = series_total_seasons
    breakdown["series_total_eps"]     = series_total_eps
    # Series-level completeness: every expected episode is cached somewhere
    total_cached_eps = sum(s.get("cached_episodes", 0) for s in seasons_out.values())
    breakdown["series_complete"]     = (
        series_total_eps > 0 and total_cached_eps >= series_total_eps
    )
    breakdown["repair_queued"] = len(repair_queue)

    # Auto-repair: kick off background re-resolves for every episode the DB
    # claimed was cached but where the symlink turned out to be missing or
    # broken. No user input required — the moment the UI is rendered, the
    # repair chain has already started. Tagged is_user_play=False so we don't
    # cascade the 3-episode lookahead from a maintenance task.
    if repair_queue:
        log.info(
            f"🔧 Auto-repairing {len(repair_queue)} missing symlink(s) for "
            f"{title!r} (detected during series-detail load)"
        )
        s_cfg = request.app.state.settings
        for ev in repair_queue:
            try:
                # Restore the placeholder NOW so Plex doesn't see a gap while
                # the real resolve runs.
                _restore_placeholder(
                    s_cfg.PLEX_ROOT, ev.media_type.value, ev.title,
                    year=ev.year, season=ev.season, episode=ev.episode, app=request.app,
                )
            except Exception as e:
                log.debug(f"series-detail placeholder restore: {e}")
            try:
                # Demote DB state so resolve_and_cache treats it as fresh.
                db.update_status(ev.cache_key(), "not_found")
            except Exception:
                pass
            _spawn_lookahead(resolve_and_cache(request.app, ev, is_user_play=False))

    return breakdown


# ── /api/hash-index/search ────────────────────────────────────────────────────

@app.post("/api/hash-index/search")
async def api_hash_index_search(request: Request):
    """
    Targeted search for a specific title / season / episode.
    Runs search_and_index() immediately (not via queue) and returns the result.
    Used by the Hash Indexer detail drawer search buttons.
    """
    body       = await request.json()
    title      = body.get("title", "").strip()
    media_type = body.get("media_type", "episode")  # "movie" | "episode"
    season     = body.get("season")
    episode    = body.get("episode")
    year       = body.get("year")

    if not title:
        raise HTTPException(400, "title required")

    hi:        HashIndex        = getattr(request.app.state, "hash_index", None)
    alldebrid: AllDebridClient  = request.app.state.alldebrid
    db:        CacheDB          = request.app.state.db

    if not hi or not alldebrid or not alldebrid.api_key:
        raise HTTPException(503, "Hash index or AllDebrid not ready")

    settings       = db.get_all_settings()
    prowlarr_url   = settings.get("PROWLARR_URL", "")
    prowlarr_key   = settings.get("PROWLARR_API_KEY", "")
    pref_quality   = settings.get(
        "movie_preferred_quality" if media_type == "movie" else "series_preferred_quality",
        "1080p",
    )

    if not prowlarr_url or not prowlarr_key:
        raise HTTPException(400, "Prowlarr not configured in Settings")

    try:
        n = await search_and_index(
            hi,
            prowlarr_url=prowlarr_url,
            prowlarr_key=prowlarr_key,
            api_key=alldebrid.api_key,
            title=title,
            year=year,
            media_type=media_type,
            season=season,
            episode=episode,
            preferred_quality=pref_quality,
        )
        breakdown = hi.get_series_breakdown(title) if media_type != "movie" else None
        return {
            "status":    "ok",
            "cached":    n,
            "message":   f"{n} cached hash(es) found" if n else "No cached results found on AllDebrid",
            "breakdown": breakdown,
        }
    except Exception as e:
        log.error(f"hash-index search {title!r} S{season}E{episode}: {e}", exc_info=True)
        raise HTTPException(500, str(e))


# ── /api/hash-index/reindex-title ────────────────────────────────────────────

@app.post("/api/hash-index/reindex-title")
async def api_hash_index_reindex_title(request: Request, background_tasks: BackgroundTasks):
    """Re-index a single title — fires _index_movie_hashes or _index_series_hashes."""
    body  = await request.json()
    title = body.get("title", "").strip()
    if not title:
        raise HTTPException(400, "title required")

    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    db: CacheDB   = request.app.state.db
    if not hi:
        raise HTTPException(503, "Hash index not initialised")

    # Try exact match first, then case-insensitive scan of library
    lib_entry = None
    for _le in db.fake_library_list():
        if _le["title"].lower() == title.lower():
            lib_entry = _le
            break
    # If not in library, check hash index for media_type
    if not lib_entry:
        hi_entries = hi.list_hashes_for_title(title)
        if hi_entries:
            # Infer from hash index
            media_type = hi_entries[0].get("media_type", "movie")
            year       = hi_entries[0].get("year")
            is_movie   = (media_type == "movie")
        else:
            # Default to movie reindex — user can override via search buttons
            is_movie = True
            year     = None
    else:
        is_movie = (lib_entry["media_type"] == "movie")
        year     = lib_entry.get("year")

    if is_movie:
        background_tasks.add_task(
            _index_movie_hashes, request.app, title, year
        )
    else:
        is_ended     = lib_entry.get("status", "") in ("ended", "cancelled", "canceled") if lib_entry else False
        season_count = lib_entry.get("season_count", 1) or 1 if lib_entry else 1
        background_tasks.add_task(
            _index_series_hashes, request.app, title, year,
            season_count, is_ended, []
        )

    return {"status": "ok", "message": f"Re-indexing '{title}'"}
