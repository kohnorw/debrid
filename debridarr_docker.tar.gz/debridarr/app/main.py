import os, sqlite3, uuid, shutil
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional, Literal, Any

from fastapi import FastAPI, HTTPException, Request, Header, Depends, BackgroundTasks
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel, Field

DB_PATH = os.getenv('DB_PATH', '/data/debridarr.db')
STREAMS_PATH = Path(os.getenv('STREAMS_PATH', '/streams'))
FUSE_MOUNT_PATH = Path(os.getenv('FUSE_MOUNT_PATH', '/mnt/debrid'))
SYMLINK_TTL_DAYS = int(os.getenv('SYMLINK_TTL_DAYS', '30'))
PLACEHOLDER_EXT = os.getenv('PLACEHOLDER_EXT', '.mkv')
API_KEY = os.getenv('API_KEY', '').strip()

app = FastAPI(title='Debridarr Rebuild', version='2026.06.minimal')

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def utc_from_iso(value: str) -> datetime:
    return datetime.fromisoformat(value.replace('Z', '+00:00'))

def safe_name(value: str) -> str:
    keep = ''.join(c if c.isalnum() or c in ' ._-()[]' else ' ' for c in (value or '').strip())
    return ' '.join(keep.split()) or 'Unknown'

def conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    STREAMS_PATH.mkdir(parents=True, exist_ok=True)
    FUSE_MOUNT_PATH.mkdir(parents=True, exist_ok=True)
    with conn() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS settings (
          key TEXT PRIMARY KEY,
          value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS streams (
          id TEXT PRIMARY KEY,
          arr TEXT NOT NULL,
          media_type TEXT NOT NULL,
          title TEXT NOT NULL,
          year INTEGER,
          season INTEGER,
          episode INTEGER,
          source_path TEXT NOT NULL,
          symlink_path TEXT NOT NULL,
          placeholder_path TEXT,
          created_at TEXT NOT NULL,
          expires_at TEXT NOT NULL,
          last_seen_at TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'active',
          metadata_json TEXT NOT NULL DEFAULT '{}'
        );
        CREATE INDEX IF NOT EXISTS idx_streams_expires ON streams(expires_at);
        CREATE INDEX IF NOT EXISTS idx_streams_status ON streams(status);
        ''')
        defaults = {
            'streams_path': str(STREAMS_PATH),
            'fuse_mount_path': str(FUSE_MOUNT_PATH),
            'symlink_ttl_days': str(SYMLINK_TTL_DAYS),
            'placeholder_ext': PLACEHOLDER_EXT,
            'sonarr_enabled': 'true',
            'radarr_enabled': 'true',
        }
        for k, v in defaults.items():
            db.execute('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)', (k, v))

@app.on_event('startup')
def startup():
    init_db()
    cleanup_expired()

async def require_api_key(authorization: Optional[str] = Header(default=None), x_api_key: Optional[str] = Header(default=None)):
    if not API_KEY:
        return True
    token = (x_api_key or '').strip()
    if authorization and authorization.lower().startswith('bearer '):
        token = authorization.split(' ', 1)[1].strip()
    if token != API_KEY:
        raise HTTPException(401, 'Invalid API key')
    return True

class StreamCreate(BaseModel):
    arr: Literal['sonarr', 'radarr'] = 'sonarr'
    media_type: Literal['movie', 'episode'] = 'episode'
    title: str
    year: Optional[int] = None
    season: Optional[int] = None
    episode: Optional[int] = None
    source_path: str = Field(..., description='Real file path inside the FUSE mount or another path visible to ARR')
    desired_path: Optional[str] = Field(None, description='Optional exact symlink path under /streams')
    ttl_days: Optional[int] = None
    metadata: dict[str, Any] = {}

class InteractiveSearchPlaceholder(BaseModel):
    arr: Literal['sonarr', 'radarr'] = 'sonarr'
    media_type: Literal['movie', 'episode'] = 'episode'
    title: str
    year: Optional[int] = None
    season: Optional[int] = None
    episode: Optional[int] = None
    results: list[dict[str, Any]] = Field(default_factory=list)
    desired_path: Optional[str] = None

class SettingsPatch(BaseModel):
    settings: dict[str, str]

def build_stream_path(item: StreamCreate | InteractiveSearchPlaceholder) -> Path:
    if item.desired_path:
        p = Path(item.desired_path)
        if not p.is_absolute():
            p = STREAMS_PATH / p
        return p
    title = safe_name(item.title)
    if item.media_type == 'movie':
        folder = f'{title} ({item.year})' if item.year else title
        return STREAMS_PATH / 'radarr' / folder / f'{folder}{PLACEHOLDER_EXT}'
    s = int(item.season or 0)
    e = int(item.episode or 0)
    return STREAMS_PATH / 'sonarr' / title / f'Season {s:02d}' / f'{title} - S{s:02d}E{e:02d}{PLACEHOLDER_EXT}'

def row_to_dict(row):
    d = dict(row)
    return d

def cleanup_expired():
    deleted = []
    current = datetime.now(timezone.utc)
    with conn() as db:
        rows = db.execute("SELECT * FROM streams WHERE status='active'").fetchall()
        for r in rows:
            try:
                if utc_from_iso(r['expires_at']) > current:
                    continue
            except Exception:
                continue
            for field in ('symlink_path', 'placeholder_path'):
                p = r[field]
                if p:
                    try:
                        path = Path(p)
                        if path.exists() or path.is_symlink():
                            path.unlink()
                    except Exception:
                        pass
            db.execute("UPDATE streams SET status='expired' WHERE id=?", (r['id'],))
            deleted.append(r['id'])
    return deleted

@app.get('/', response_class=HTMLResponse)
def home():
    return HTMLResponse(UI)

@app.get('/health')
def health():
    return {'ok': True, 'version': app.version, 'streams_path': str(STREAMS_PATH), 'fuse_mount_path': str(FUSE_MOUNT_PATH)}

@app.get('/api/settings')
def get_settings(_: bool = Depends(require_api_key)):
    with conn() as db:
        return {'settings': {r['key']: r['value'] for r in db.execute('SELECT key,value FROM settings ORDER BY key')}}

@app.patch('/api/settings')
def patch_settings(patch: SettingsPatch, _: bool = Depends(require_api_key)):
    with conn() as db:
        for k, v in patch.settings.items():
            db.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', (k, str(v)))
    return get_settings(True)

@app.get('/api/fuse')
def fuse_status(_: bool = Depends(require_api_key)):
    mounted = FUSE_MOUNT_PATH.exists() and any(FUSE_MOUNT_PATH.iterdir()) if FUSE_MOUNT_PATH.exists() else False
    return {'mount_path': str(FUSE_MOUNT_PATH), 'exists': FUSE_MOUNT_PATH.exists(), 'has_files': mounted}

@app.get('/api/streams')
def list_streams(status: str = 'active', _: bool = Depends(require_api_key)):
    cleanup_expired()
    with conn() as db:
        if status == 'all':
            rows = db.execute('SELECT * FROM streams ORDER BY created_at DESC').fetchall()
        else:
            rows = db.execute('SELECT * FROM streams WHERE status=? ORDER BY created_at DESC', (status,)).fetchall()
        return {'streams': [row_to_dict(r) for r in rows]}

@app.post('/api/streams')
def create_stream(item: StreamCreate, _: bool = Depends(require_api_key)):
    cleanup_expired()
    source = Path(item.source_path)
    dest = build_stream_path(item)
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists() or dest.is_symlink():
        dest.unlink()
    try:
        os.symlink(str(source), str(dest))
    except OSError:
        shutil.copyfile(str(source), str(dest))
    ttl = int(item.ttl_days or SYMLINK_TTL_DAYS)
    stream_id = str(uuid.uuid4())
    created = now_iso()
    expires = (datetime.now(timezone.utc) + timedelta(days=ttl)).isoformat()
    with conn() as db:
        db.execute('''INSERT INTO streams(id,arr,media_type,title,year,season,episode,source_path,symlink_path,created_at,expires_at,last_seen_at,metadata_json)
                      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,json(?))''',
                   (stream_id,item.arr,item.media_type,item.title,item.year,item.season,item.episode,str(source),str(dest),created,expires,created,str(item.metadata).replace("'", '"')))
    return {'ok': True, 'id': stream_id, 'symlink_path': str(dest), 'expires_at': expires}

@app.delete('/api/streams/{stream_id}')
def delete_stream(stream_id: str, _: bool = Depends(require_api_key)):
    with conn() as db:
        row = db.execute('SELECT * FROM streams WHERE id=?', (stream_id,)).fetchone()
        if not row:
            raise HTTPException(404, 'Stream not found')
        for field in ('symlink_path', 'placeholder_path'):
            p = row[field]
            if p:
                try:
                    path = Path(p)
                    if path.exists() or path.is_symlink():
                        path.unlink()
                except Exception:
                    pass
        db.execute("UPDATE streams SET status='removed' WHERE id=?", (stream_id,))
    return {'ok': True, 'removed': stream_id}

@app.post('/api/streams/cleanup')
def cleanup(_: bool = Depends(require_api_key)):
    return {'ok': True, 'expired_removed': cleanup_expired()}

@app.post('/api/interactive-search/placeholders')
def create_placeholder_from_interactive_search(item: InteractiveSearchPlaceholder, _: bool = Depends(require_api_key)):
    # Critical rule: no result = no placeholder.
    if not item.results:
        return {'ok': True, 'created': False, 'reason': 'No interactive search results were supplied, so no placeholder was created.'}
    p = build_stream_path(item)
    p.parent.mkdir(parents=True, exist_ok=True)
    if not (p.exists() or p.is_symlink()):
        p.write_bytes(b'')
    return {'ok': True, 'created': True, 'placeholder_path': str(p), 'result_count': len(item.results)}

UI = r'''
<!doctype html><html><head><meta charset="utf-8"><title>Debridarr</title>
<style>body{font-family:system-ui,Arial;margin:0;background:#10131a;color:#e8e8e8}nav{display:flex;gap:12px;padding:14px 20px;background:#171b24;position:sticky;top:0}button{background:#2c3445;color:#fff;border:0;border-radius:8px;padding:9px 12px;cursor:pointer}.tab{display:none;padding:22px}.tab.active{display:block}.card{background:#171b24;border:1px solid #2b3242;border-radius:12px;padding:16px;margin:12px 0}input,textarea{width:100%;box-sizing:border-box;background:#0e1118;color:#fff;border:1px solid #343b4d;border-radius:8px;padding:10px;margin:5px 0 12px}pre{white-space:pre-wrap;background:#0e1118;border-radius:8px;padding:12px}</style></head><body>
<nav><button onclick="show('streams')">Streams</button><button onclick="show('settings')">Settings</button><button onclick="show('fuse')">FUSE Mount</button></nav>
<section id="streams" class="tab active"><h1>Streams</h1><div class="card"><button onclick="loadStreams()">Refresh</button><button onclick="cleanup()">Run 30-day cleanup</button><pre id="streamsOut"></pre></div></section>
<section id="settings" class="tab"><h1>Settings</h1><div class="card"><button onclick="loadSettings()">Load settings</button><pre id="settingsOut"></pre></div></section>
<section id="fuse" class="tab"><h1>FUSE Mount</h1><div class="card"><button onclick="loadFuse()">Check mount</button><pre id="fuseOut"></pre></div></section>
<script>
function show(id){document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));document.getElementById(id).classList.add('active')}
async function j(url,opt){let r=await fetch(url,opt||{});return JSON.stringify(await r.json(),null,2)}
async function loadStreams(){streamsOut.textContent=await j('/api/streams')}
async function cleanup(){streamsOut.textContent=await j('/api/streams/cleanup',{method:'POST'})}
async function loadSettings(){settingsOut.textContent=await j('/api/settings')}
async function loadFuse(){fuseOut.textContent=await j('/api/fuse')}
loadStreams();
</script></body></html>
'''
