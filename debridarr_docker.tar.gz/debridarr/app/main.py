"""
Debridarr - On-the-fly AllDebrid streaming for Plex
"""

import asyncio
import html as _html
import logging
import re
import sys
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from app.alldebrid import AllDebridClient
from app.cache import CacheDB
from app.config import settings
from app.hash_index import HashIndex
from app.indexer import index_movie, index_series, recheck_stale, search_and_index
from app.library import LibraryManager, _FAKE_MP4
from app.models import MediaType, PlayEvent
from app.proxy import proxy_stream, stream_direct, write_strm
from app.fuse_mount import (
    start_fuse_mount, stop_fuse_mount,
    register_torrent, unregister_torrent, get_fuse_path,
    list_torrents, list_files, get_torrent_file,
    FUSE_AVAILABLE, update_dfs_settings, get_dfs_settings,
)
from app.setup import (
    is_setup_complete, mark_setup_complete,
    load_saved_config, write_env,
    test_alldebrid, test_overseerr, test_plex_root,
)

logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("debridarr")


# ── Helpers ───────────────────────────────────────────────────────────────────

def _schedule_restart(delay: float = 2.0):
    import threading, subprocess, time
    def _do():
        time.sleep(delay)
        log.info("🔄 Restarting...")
        try: subprocess.run(["kill", "-TERM", "1"], check=False)
        except Exception as e: log.error(f"Restart failed: {e}")
    threading.Thread(target=_do, daemon=True).start()


def _init_clients(app: FastAPI):
    import os
    db: CacheDB = getattr(app.state, "db", None)

    def _cfg(key: str, env_key: str = None, default: str = "") -> str:
        """Read from DB first, fall back to env var, then hardcoded default."""
        if db:
            val = db.get_setting(key, "")
            if val:
                return val
        env_key = env_key or key
        return os.environ.get(env_key, default)

    class _S:
        ALLDEBRID_API_KEY  = _cfg("ALLDEBRID_API_KEY")
        OVERSEERR_URL      = _cfg("OVERSEERR_URL")
        OVERSEERR_API_KEY  = _cfg("OVERSEERR_API_KEY")
        PLEX_ROOT          = _cfg("PLEX_ROOT", default="/plex-strm")
        DEBRIDARR_BASE_URL = _cfg("DEBRIDARR_BASE_URL")
        DB_PATH            = os.environ.get("DB_PATH", "/data/debridarr.db")
        PORT               = int(os.environ.get("PORT", "7474"))
        LOG_LEVEL          = os.environ.get("LOG_LEVEL", "INFO")
        FUSE_MOUNT         = os.environ.get("FUSE_MOUNT", "/mnt/alldebrid")
        FUSE_SYMLINK_ROOT  = os.environ.get("FUSE_SYMLINK_ROOT", "/docker/debridarr/mnt-alldebrid")

    s = _S()
    tmdb_key = db.get_setting("tmdb_api_key", "") if db else ""

    app.state.alldebrid = AllDebridClient(s.ALLDEBRID_API_KEY)
    app.state.library   = LibraryManager(
        overseerr_url=s.OVERSEERR_URL,
        overseerr_key=s.OVERSEERR_API_KEY,
        plex_root=s.PLEX_ROOT,
        tmdb_api_key=tmdb_key,
    )
    app.state.settings  = s
    app.state.fuse_thread = getattr(app.state, "fuse_thread", None)
    log.info(f"✅ Clients initialised — overseerr={s.OVERSEERR_URL or 'not set'}")


async def _index_worker(app: FastAPI):
    """
    Persistent background worker that processes the index queue.
    Runs for the entire lifespan of the app — never cancelled by a request.
    Items are (coro_fn, args) tuples pushed by api_library_add and _run_auto_add.
    """
    global _index_queue
    # Use app.state queue — same object as global, but reliable reference
    q = getattr(app.state, "index_queue", None) or _index_queue
    log.info(f"🗄️  Index worker started — queue={q}")
    while True:
        try:
            coro_fn, args = await q.get()
            fn_name = getattr(coro_fn, "__name__", str(coro_fn))
            title_hint = args[1] if len(args) > 1 else "?"
            log.info(f"🗄️  Index worker picked up: {fn_name}({title_hint!r})")
            try:
                await coro_fn(*args)
            except asyncio.CancelledError:
                pass
            except Exception as e:
                log.error(f"Index worker error in {fn_name}: {e}", exc_info=True)
            finally:
                q.task_done()
        except asyncio.CancelledError:
            break
        except Exception as e:
            log.error(f"Index worker loop error: {e}")
            await asyncio.sleep(1)


def _queue_index(app: FastAPI, coro_fn, *args):
    """
    Fire-and-forget indexing anchored to app.state.index_queue.
    Uses app.state so it's immune to Python global variable scoping issues.
    Falls back to asyncio.ensure_future if the queue isn't ready yet.
    """
    fn_name    = getattr(coro_fn, "__name__", str(coro_fn))
    title_hint = args[1] if len(args) > 1 else "?"

    # Primary: use app.state.index_queue (set in lifespan, same object always)
    q = getattr(app.state, "index_queue", None)
    if q is not None:
        q.put_nowait((coro_fn, args))
        log.info(f"🗄️  Queued: {fn_name}({title_hint!r}) — qsize={q.qsize()}")
        return

    # Fallback: global queue (belt-and-suspenders)
    global _index_queue
    if _index_queue is not None:
        _index_queue.put_nowait((coro_fn, args))
        log.info(f"🗄️  Queued (global): {fn_name}({title_hint!r}) — qsize={_index_queue.qsize()}")
        return

    # Last resort: schedule directly on the running event loop
    log.warning(f"🗄️  No queue available — scheduling {fn_name}({title_hint!r}) directly")
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            asyncio.ensure_future(coro_fn(*args), loop=loop)
            log.info(f"🗄️  Scheduled via ensure_future: {fn_name}({title_hint!r})")
        else:
            log.error(f"🗄️  No running event loop for {fn_name}({title_hint!r})")
    except Exception as e:
        log.error(f"🗄️  Failed to schedule {fn_name}({title_hint!r}): {e}", exc_info=True)


@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info("🚀 Debridarr starting up...")
    for noisy in ("httpx", "httpcore", "multipart", "uvicorn.access"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    import os
    _data_env = Path("/data/.env")
    if _data_env.exists():
        log.info(f"📂 Loading config from {_data_env}")
        for line in _data_env.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            k, v = k.strip(), v.strip()
            if k and v and not os.environ.get(k):
                os.environ[k] = v

    db = CacheDB(settings.DB_PATH)
    db.init()
    db.bootstrap_from_env()   # seed DB from env vars on first run
    app.state.db = db

    # Initialise hash index (table created inside CacheDB.init already)
    hi = HashIndex(settings.DB_PATH)
    app.state.hash_index = hi
    log.info(f"🗄️  HashIndex attached — stats: {hi.stats()}")

    app.state.setup_complete = is_setup_complete()

    # Sync any previously resolved streams into the hash index immediately
    # This ensures the index is populated even if add-time indexing failed
    try:
        asyncio.create_task(_sync_streams_to_index(app))
    except Exception:
        pass  # lifespan hasn't yielded yet — will run once loop starts

    # Log clearly which settings are active and where they came from
    ss = db.get_all_settings()
    log.info(f"📦 DB path: {settings.DB_PATH}")
    log.info(f"📦 Settings loaded from DB — "
             f"api_key={'set' if ss.get('ALLDEBRID_API_KEY') else 'NOT SET'}, "
             f"overseerr={'set' if ss.get('OVERSEERR_URL') else 'NOT SET'}, "
             f"plex_root={ss.get('PLEX_ROOT') or 'NOT SET'}, "
             f"precache={ss.get('precache_enabled','true')}")

    # Reset any entries stuck in "resolving" from a previous crashed run
    # Also recover entries that had symlinks (were cached) but got stuck
    stuck = 0
    recovered_symlinks = 0
    with db._connect() as conn:
        result = conn.execute(
            "UPDATE cache SET status='not_found' WHERE status='resolving'"
        )
        stuck = result.rowcount
        # Any not_found entry that still has a valid symlink path → restore to cached
        # These are entries that were cached, then something went wrong on restart
        not_found = conn.execute(
            "SELECT cache_key, strm_path FROM cache WHERE status='not_found' AND strm_path IS NOT NULL"
        ).fetchall()
        for row in not_found:
            strm = row[1]
            if strm and Path(strm).is_symlink():
                conn.execute(
                    "UPDATE cache SET status='cached' WHERE cache_key=?", (row[0],)
                )
                recovered_symlinks += 1
    if stuck:
        log.info(f"🔄 Reset {stuck} stuck 'resolving' entries → 'not_found'")
    if recovered_symlinks:
        log.info(f"🔄 Recovered {recovered_symlinks} entries with existing symlinks → 'cached'")

    _init_clients(app)
    s = app.state.settings
    log.info(f"✅ Debridarr ready — plex_root={s.PLEX_ROOT or 'NOT SET'}")

    # Load DFS settings
    try:
        import json as _json
        saved_dfs = db.get_setting("dfs_settings")
        if saved_dfs:
            update_dfs_settings(_json.loads(saved_dfs))
        else:
            cache_dir = s.FUSE_SYMLINK_ROOT.replace("mnt-alldebrid", "tmp/cache") if s.FUSE_SYMLINK_ROOT else "/docker/debridarr/tmp/cache"
            update_dfs_settings({"cache_dir": cache_dir})
    except Exception as e:
        log.debug(f"DFS settings: {e}")

    try:
        Path(get_dfs_settings()["cache_dir"]).mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

    # Start FUSE
    if FUSE_AVAILABLE:
        _loop = asyncio.get_event_loop()
        _t = start_fuse_mount(s.FUSE_MOUNT, app.state.alldebrid, _loop)
        app.state.fuse_thread = _t
        if _t:
            log.info(f"🗂️  FUSE at {s.FUSE_MOUNT}")
            asyncio.create_task(_load_all_torrents(app))
    else:
        app.state.fuse_thread = None
        log.warning("⚠️  FUSE unavailable")

    global _index_queue
    _index_queue = asyncio.Queue()
    app.state.index_queue = _index_queue   # also on app.state for reliable access
    asyncio.create_task(_index_worker(app))
    asyncio.create_task(_cleanup_loop(app))
    asyncio.create_task(_symlink_health_loop(app))
    asyncio.create_task(_episode_sync_loop(app))
    asyncio.create_task(_auto_add_loop(app))
    asyncio.create_task(_hash_index_recheck_loop(app))

    yield

    if getattr(app.state, "fuse_thread", None):
        stop_fuse_mount(app.state.settings.FUSE_MOUNT)


app = FastAPI(title="Debridarr", version="0.5.0", lifespan=lifespan)


def _needs_setup(request: Request) -> bool:
    return not getattr(request.app.state, "setup_complete", False)

def _setup_redirect():
    return RedirectResponse("/setup", status_code=302)


# ── Job registry ──────────────────────────────────────────────────────────────
import uuid as _uuid
from collections import deque

_jobs: dict[str, dict] = {}          # job_id → job dict
_jobs_history: deque   = deque(maxlen=200)  # completed jobs (capped)
_resolve_semaphore: Optional[asyncio.Semaphore] = None  # set at startup
_precache_tasks: dict[str, asyncio.Task] = {}           # title.lower() → running precache Task
_index_queue: asyncio.Queue = None                          # type: ignore  # set at startup

def _get_semaphore(app=None) -> asyncio.Semaphore:
    global _resolve_semaphore
    if _resolve_semaphore is None:
        count = 3  # default worker count
        if app:
            try:
                db = getattr(app.state, "db", None)
                if db:
                    count = int(db.get_setting("resolve_workers", str(count)))
            except Exception:
                pass
        _resolve_semaphore = asyncio.Semaphore(count)
    return _resolve_semaphore


def _reset_semaphore(count: int):
    global _resolve_semaphore
    _resolve_semaphore = asyncio.Semaphore(count)


def _job_start(name: str, job_type: str = "resolve", cancellable: bool = True) -> tuple[str, asyncio.Event]:
    jid   = _uuid.uuid4().hex[:8]
    event = asyncio.Event()
    _jobs[jid] = {
        "id":          jid,
        "name":        name,
        "type":        job_type,
        "status":      "running",
        "started_at":  datetime.utcnow().isoformat(),
        "finished_at": None,
        "error":       None,
        "cancel_event": event,
        "cancellable": cancellable,
    }
    return jid, event


def _job_done(jid: str, error: str = None):
    if jid not in _jobs:
        return
    job = _jobs.pop(jid)
    job["status"]      = "error" if error else "done"
    job["finished_at"] = datetime.utcnow().isoformat()
    job["error"]       = error
    job.pop("cancel_event", None)
    _jobs_history.appendleft(job)


# ── Styles ────────────────────────────────────────────────────────────────────
_CSS = """
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
       background: #0f0f13; color: #e0e0e0; min-height: 100vh; }
header { background: #1a1a24; border-bottom: 1px solid #2a2a3a;
         padding: 14px 28px; display: flex; align-items: center; gap: 16px; }
header h1 { font-size: 1.3rem; color: #fff; }
header .ver { font-size: 0.75rem; background: #f97316; color: #fff;
              border-radius: 4px; padding: 2px 8px; }
nav { display: flex; gap: 4px; margin-left: auto; }
nav a { color: #aaa; text-decoration: none; padding: 6px 14px; border-radius: 6px;
        font-size: 0.85rem; transition: background .15s; }
nav a:hover, nav a.active { background: #2a2a3a; color: #fff; }
main { padding: 28px; max-width: 1400px; margin: 0 auto; }
h2 { font-size: 1.05rem; color: #ccc; margin-bottom: 18px; }
.card-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 14px; }
.card { background: #1a1a24; border: 1px solid #2a2a3a; border-radius: 10px; overflow: hidden; }
.card img { width: 100%; aspect-ratio: 2/3; object-fit: cover; background: #111; display: block; }
.card .no-poster { width: 100%; aspect-ratio: 2/3; background: #1a1a2e;
                   display: flex; align-items: center; justify-content: center;
                   font-size: 2rem; color: #333; }
.card .info { padding: 10px 12px; }
.card .title { font-size: 0.85rem; font-weight: 600; color: #e0e0e0;
               white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.card .meta  { font-size: 0.72rem; color: #555; margin-top: 3px; }
.card .actions { padding: 0 10px 10px; display: flex; gap: 6px; flex-wrap: wrap; }
.btn { display: inline-block; padding: 5px 12px; border-radius: 6px; font-size: 0.78rem;
       font-weight: 600; border: none; cursor: pointer; text-decoration: none; transition: opacity .15s; }
.btn-add  { background: #f97316; color: #fff; }
.btn-add:hover { opacity: .85; }
.btn-rem  { background: #3b1f00; color: #fb923c; }
.btn-sec  { background: #1e3a5f; color: #60a5fa; }
.badge-in { display: inline-block; background: #14532d; color: #4ade80;
            font-size: 0.68rem; font-weight: 700; padding: 2px 7px; border-radius: 20px; }
.badge-grey { display: inline-block; background: #1a1a24; color: #555;
              font-size: 0.68rem; padding: 2px 7px; border-radius: 20px; border: 1px solid #2a2a3a; }
.search-bar { display: flex; gap: 10px; margin-bottom: 20px; }
.search-bar input { flex: 1; background: #1a1a24; border: 1px solid #2a2a3a;
                    border-radius: 8px; padding: 9px 14px; color: #e0e0e0; font-size: 0.9rem; outline: none; }
.search-bar input:focus { border-color: #f97316; }
.tabs { display: flex; gap: 2px; margin-bottom: 20px; }
.tab { padding: 8px 20px; border-radius: 8px; cursor: pointer; font-size: 0.85rem;
       font-weight: 600; border: 1px solid #2a2a3a; background: #1a1a24; color: #888; }
.pg-bar { display:flex;gap:4px;align-items:center;justify-content:center;margin:24px 0 8px;flex-wrap:wrap; }
.pg-btn { display:inline-flex;align-items:center;justify-content:center;min-width:34px;height:34px;
  padding:0 8px;border-radius:6px;border:1px solid #2a2a3a;background:#1a1a24;color:#aaa;
  font-size:0.82rem;font-weight:600;text-decoration:none;cursor:pointer; }
.pg-btn:hover { border-color:#f97316;color:#f97316; }
.pg-cur { background:#f97316;border-color:#f97316;color:#fff;cursor:default; }
.pg-dis { opacity:0.35;cursor:default; }
.tab.active { background: #f97316; color: #fff; border-color: #f97316; }
.empty { text-align: center; padding: 60px; color: #444; font-size: 0.9rem; }
.toast { position: fixed; bottom: 24px; right: 24px; background: #1a1a24;
         border: 1px solid #2a2a3a; border-radius: 10px; padding: 12px 20px;
         font-size: 0.85rem; opacity: 0; transition: opacity .3s; z-index: 999; }
.toast.show { opacity: 1; }
table { width: 100%; border-collapse: collapse; background: #1a1a24;
        border-radius: 10px; overflow: hidden; }
th { text-align: left; padding: 11px 14px; font-size: 0.72rem; text-transform: uppercase;
     color: #555; border-bottom: 1px solid #2a2a3a; }
td { padding: 10px 14px; border-bottom: 1px solid #1e1e2e; font-size: 0.85rem; }
tr:last-child td { border-bottom: none; }
.pill { padding: 2px 9px; border-radius: 20px; font-size: 0.72rem; font-weight: 600; }
.pill-ok   { background: #14532d; color: #4ade80; }
.pill-res  { background: #1e3a5f; color: #60a5fa; }
.pill-err  { background: #3b0000; color: #f87171; }
.pill-pend { background: #2d2d00; color: #facc15; }
.pill-nf   { background: #3b1f00; color: #fb923c; }
"""

_NAV = lambda active: f"""
<nav>
  <a href="/library"      class="{'active' if active=='library'     else ''}">📚 Add to Library</a>
  <a href="/import"       class="{'active' if active=='import'      else ''}">⬇️ Import</a>
  <a href="/streams"      class="{'active' if active=='streams'     else ''}">⚡ Streams</a>
  <a href="/hash-indexer" class="{'active' if active=='hashindexer' else ''}">🔎 Hash Indexer</a>
  <a href="/hash-index/log" class="{'active' if active=='hashlog'   else ''}">🗄️ Hash Log</a>
  <a href="/jobs"         class="{'active' if active=='jobs'        else ''}">⚙️ Jobs</a>
  <a href="/settings"     class="{'active' if active=='settings'    else ''}">⚙️ Settings</a>
</nav>"""

_TOAST_JS = """
function toast(msg, ok=true) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.style.borderColor = ok ? '#4ade80' : '#f87171';
  t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 3500);
}"""

def _pagination(base_url: str, params: dict, current: int, total: int) -> str:
    """Render a pagination bar. Preserves existing query params."""
    if total <= 1:
        return ""
    def url(p):
        q = "&".join(f"{k}={v}" for k, v in params.items() if v) + f"&page={p}"
        return f"{base_url}?{q}"

    buttons = []
    # Prev
    if current > 1:
        buttons.append(f'<a class="pg-btn" href="{url(current-1)}">‹</a>')
    else:
        buttons.append('<span class="pg-btn pg-dis">‹</span>')

    # Page numbers — show up to 7, with ellipsis
    pages = []
    if total <= 7:
        pages = list(range(1, total+1))
    else:
        pages = [1]
        if current > 3:  pages.append("…")
        for p in range(max(2,current-1), min(total, current+2)):
            pages.append(p)
        if current < total - 2: pages.append("…")
        if total not in pages:  pages.append(total)

    for p in pages:
        if p == "…":
            buttons.append('<span class="pg-btn pg-dis">…</span>')
        elif p == current:
            buttons.append(f'<span class="pg-btn pg-cur">{p}</span>')
        else:
            buttons.append(f'<a class="pg-btn" href="{url(p)}">{p}</a>')

    # Next
    if current < total:
        buttons.append(f'<a class="pg-btn" href="{url(current+1)}">›</a>')
    else:
        buttons.append('<span class="pg-btn pg-dis">›</span>')

    inner = "".join(buttons)
    return f'<div class="pg-bar">{inner}</div>'


def _page(title, nav_active, body, extra=""):
    return HTMLResponse(f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>{title} — Debridarr</title>
  <style>{_CSS}</style>
</head>
<body>
  <header>
    <h1>🎬 Debridarr</h1><span class="ver">v0.5.0</span>
    {_NAV(nav_active)}
  </header>
  <main>{body}</main>
  <div id="toast" class="toast"></div>
  <script>{_TOAST_JS}</script>
  {extra}
</body>
</html>""")


# ── Setup ─────────────────────────────────────────────────────────────────────
_SETUP_CSS = _CSS + """
.wizard { max-width: 620px; margin: 60px auto; }
.wizard-card { background: #1a1a24; border: 1px solid #2a2a3a; border-radius: 14px; padding: 36px; }
.wizard h2 { font-size: 1.4rem; color: #fff; margin-bottom: 6px; }
.wizard .sub { color: #666; font-size: 0.88rem; margin-bottom: 28px; line-height: 1.5; }
.steps { display: flex; gap: 0; margin-bottom: 32px; }
.step { flex: 1; text-align: center; font-size: 0.7rem; color: #444; padding-bottom: 8px;
        border-bottom: 2px solid #2a2a3a; }
.step.done   { color: #4ade80; border-color: #4ade80; }
.step.active { color: #f97316; border-color: #f97316; font-weight: 700; }
.field { margin-bottom: 20px; }
.field label { display: block; font-size: 0.8rem; color: #888; margin-bottom: 6px; font-weight: 600; }
.field input { width: 100%; background: #0f0f13; border: 1px solid #2a2a3a; border-radius: 8px;
               padding: 10px 14px; color: #e0e0e0; font-size: 0.9rem; outline: none; font-family: monospace; }
.field input:focus { border-color: #f97316; }
.field .hint { font-size: 0.75rem; color: #555; margin-top: 5px; line-height: 1.4; }
.field .hint a { color: #f97316; }
.test-result { margin-top: 10px; padding: 8px 12px; border-radius: 6px; font-size: 0.82rem; display: none; }
.test-result.ok      { background: #14532d; color: #4ade80; display: block; }
.test-result.err     { background: #3b0000; color: #f87171; display: block; }
.test-result.testing { background: #1e1e2e; color: #aaa; display: block; }
.row { display: flex; gap: 10px; }
.row .field { flex: 1; }
.actions { display: flex; gap: 10px; margin-top: 28px; justify-content: flex-end; }
.btn-primary { background: #f97316; color: #fff; padding: 10px 24px; border-radius: 8px;
               font-size: 0.9rem; font-weight: 600; border: none; cursor: pointer; }
.btn-primary:hover { opacity: .85; }
.btn-primary:disabled { opacity: .4; cursor: not-allowed; }
.btn-ghost { background: transparent; color: #666; padding: 10px 16px; border-radius: 8px;
             font-size: 0.9rem; border: 1px solid #2a2a3a; cursor: pointer; }
.btn-ghost:hover { color: #ccc; border-color: #444; }
.confirm-row { display: flex; justify-content: space-between; padding: 10px 0;
               border-bottom: 1px solid #1e1e2e; font-size: 0.875rem; }
.confirm-row:last-child { border-bottom: none; }
.confirm-row .lbl { color: #666; }
.confirm-row .val { color: #e0e0e0; font-family: monospace; font-size: 0.82rem; }
"""

def _setup_page(body, step):
    step_names = ["Welcome", "AllDebrid", "Overseerr", "Plex", "Confirm"]
    step_keys  = ["welcome", "alldebrid", "overseerr", "plex", "confirm"]
    idx = step_keys.index(step) if step in step_keys else 0
    steps_html = "".join(
        f'<div class="step {"done" if i < idx else "active" if i == idx else ""}">{n}</div>'
        for i, n in enumerate(step_names)
    )
    return HTMLResponse(f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Debridarr Setup</title>
  <style>{_SETUP_CSS}</style>
</head>
<body>
  <header>
    <h1>🎬 Debridarr</h1><span class="ver">v0.5.0</span>
    <span style="margin-left:auto;color:#555;font-size:0.8rem">First-run setup</span>
  </header>
  <div class="wizard">
    <div class="steps">{steps_html}</div>
    <div class="wizard-card">{body}</div>
  </div>
  <div id="toast" class="toast"></div>
  <script>{_TOAST_JS}</script>
</body>
</html>""")


@app.get("/setup", response_class=HTMLResponse)
async def setup_get(request: Request, step: str = "welcome"):
    cfg = load_saved_config()

    if step == "welcome":
        return _setup_page("""
        <div style="font-size:4rem;text-align:center;margin-bottom:20px">🎬</div>
        <h2>Welcome to Debridarr</h2>
        <p class="sub">Connect Debridarr to AllDebrid and Overseerr. Takes ~2 minutes.</p>
        <div class="actions">
          <a href="/setup?step=alldebrid" class="btn-primary" style="text-decoration:none;display:inline-block;padding:10px 24px">Get Started →</a>
        </div>""", "welcome")

    if step == "alldebrid":
        val = cfg.get("ALLDEBRID_API_KEY", "")
        return _setup_page(f"""
        <h2>AllDebrid</h2>
        <p class="sub">Debridarr uses AllDebrid to stream cached torrents instantly.</p>
        <div class="field">
          <label>API Key</label>
          <input id="api_key" type="password" value="{val}" placeholder="Paste your AllDebrid API key">
          <div class="hint">Get yours at <a href="https://alldebrid.com/apikeys" target="_blank">alldebrid.com/apikeys</a></div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="actions">
          <a href="/setup?step=welcome" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="btn" onclick="go()">Test & Continue →</button>
        </div>
        <script>
        async function go() {{
          const key = document.getElementById('api_key').value.trim();
          const res = document.getElementById('test-result');
          const btn = document.getElementById('btn');
          if (!key) {{ res.className='test-result err'; res.textContent='API key required'; return; }}
          res.className='test-result testing'; res.textContent='Testing...'; btn.disabled=true;
          const r = await fetch('/setup/test', {{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{step:'alldebrid',api_key:key}})}});
          const d = await r.json(); btn.disabled=false;
          if (d.ok) {{ res.className='test-result ok'; res.textContent='✅ '+d.message;
            setTimeout(()=>window.location='/setup?step=overseerr&akey='+encodeURIComponent(key),800); }}
          else {{ res.className='test-result err'; res.textContent='❌ '+d.message; }}
        }}
        document.getElementById('api_key').addEventListener('keydown',e=>{{if(e.key==='Enter')go();}});
        </script>""", "alldebrid")

    if step == "overseerr":
        url_val = cfg.get("OVERSEERR_URL", "http://192.168.1.x:5055")
        key_val = cfg.get("OVERSEERR_API_KEY", "")
        akey    = request.query_params.get("akey", cfg.get("ALLDEBRID_API_KEY", ""))
        return _setup_page(f"""
        <h2>Overseerr</h2>
        <p class="sub">Connect to your Overseerr instance to browse your request library.</p>
        <div class="field">
          <label>Overseerr URL</label>
          <input id="url" type="text" value="{url_val}" placeholder="http://192.168.1.x:5055">
        </div>
        <div class="field">
          <label>API Key</label>
          <input id="key" type="password" value="{key_val}" placeholder="Overseerr API key">
          <div class="hint">Overseerr → Settings → General → API Key</div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="actions">
          <a href="/setup?step=alldebrid" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="btn" onclick="go()">Test & Continue →</button>
        </div>
        <input type="hidden" id="akey" value="{akey}">
        <script>
        async function go() {{
          const url=document.getElementById('url').value.trim();
          const key=document.getElementById('key').value.trim();
          const akey=document.getElementById('akey').value;
          const res=document.getElementById('test-result'); const btn=document.getElementById('btn');
          res.className='test-result testing'; res.textContent='Testing...'; btn.disabled=true;
          const r=await fetch('/setup/test',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{step:'overseerr',url,api_key:key}})}});
          const d=await r.json(); btn.disabled=false;
          if(d.ok){{res.className='test-result ok';res.textContent='✅ '+d.message;
            setTimeout(()=>window.location='/setup?step=plex&akey='+encodeURIComponent(akey)+'&ourl='+encodeURIComponent(url)+'&okey='+encodeURIComponent(key),800);}}
          else{{res.className='test-result err';res.textContent='❌ '+d.message;}}
        }}
        </script>""", "overseerr")

    if step == "plex":
        qs = dict(request.query_params)
        hidden = "".join(f'<input type="hidden" id="{k}" value="{v}">' for k, v in qs.items() if k != "step")
        tz_val   = cfg.get("TZ", "America/Edmonton")
        puid_val = cfg.get("PUID", "1000")
        pgid_val = cfg.get("PGID", "1000")
        base_url = cfg.get("DEBRIDARR_BASE_URL", "http://192.168.1.x:7474")
        return _setup_page(f"""
        <h2>Plex Integration</h2>
        <p class="sub">Where to write library files and how Plex reaches Debridarr.</p>
        <div class="field">
          <label>Plex Library Path (inside container)</label>
          <input id="plex_root" type="text" value="/plex-strm" placeholder="/plex-strm">
          <div class="hint">Must be bind-mounted into both Debridarr and Plex.</div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="field">
          <label>Debridarr Base URL (as seen by Plex)</label>
          <input id="base_url" type="text" value="{base_url}" placeholder="http://192.168.1.x:7474">
        </div>
        <div class="row">
          <div class="field"><label>Timezone</label><input id="tz" value="{tz_val}"></div>
          <div class="field"><label>PUID</label><input id="puid" value="{puid_val}"></div>
          <div class="field"><label>PGID</label><input id="pgid" value="{pgid_val}"></div>
        </div>
        {hidden}
        <div class="actions">
          <a href="/setup?step=overseerr" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="btn" onclick="go()">Test & Continue →</button>
        </div>
        <script>
        async function go(){{
          const plex_root=document.getElementById('plex_root').value.trim();
          const res=document.getElementById('test-result'); const btn=document.getElementById('btn');
          res.className='test-result testing'; res.textContent='Checking...'; btn.disabled=true;
          const r=await fetch('/setup/test',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{step:'plex',plex_root}})}});
          const d=await r.json(); btn.disabled=false;
          if(d.ok){{res.className='test-result ok';res.textContent='✅ '+d.message;
            const prev={{}};
            document.querySelectorAll('input[type=hidden]').forEach(i=>prev[i.id]=i.value);
            const p=new URLSearchParams({{...prev,step:'confirm',plex_root,
              base_url:document.getElementById('base_url').value.trim(),
              tz:document.getElementById('tz').value.trim(),
              puid:document.getElementById('puid').value.trim(),
              pgid:document.getElementById('pgid').value.trim()}});
            setTimeout(()=>window.location='/setup?'+p.toString(),800);}}
          else{{res.className='test-result err';res.textContent='❌ '+d.message;}}
        }}
        </script>""", "plex")

    if step == "confirm":
        qs = dict(request.query_params)
        def row(lbl, key, mask=False):
            val = qs.get(key, "—")
            display = ("•" * 8 + val[-4:]) if mask and val and val != "—" else val
            return f'<div class="confirm-row"><span class="lbl">{lbl}</span><span class="val">{display}</span></div>'
        hidden = "".join(f'<input type="hidden" name="{k}" value="{v}">' for k, v in qs.items() if k != "step")
        return _setup_page(f"""
        <h2>Confirm & Save</h2>
        <p class="sub">Review settings and click Save to finish.</p>
        <div style="margin-bottom:24px">
          {row("AllDebrid API Key", "akey", mask=True)}
          {row("Overseerr URL", "ourl")}
          {row("Overseerr API Key", "okey", mask=True)}
          {row("Plex Library Path", "plex_root")}
          {row("Debridarr Base URL", "base_url")}
          {row("Timezone", "tz")}
        </div>
        <form method="POST" action="/setup/save">
          {hidden}
          <div class="actions">
            <a href="/setup?step=plex" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
            <button type="submit" class="btn-primary">💾 Save & Finish</button>
          </div>
        </form>""", "confirm")

    return RedirectResponse("/setup")


@app.post("/setup/test")
async def setup_test(request: Request):
    body = await request.json()
    step = body.get("step")
    if step == "alldebrid":  ok, msg = await test_alldebrid(body.get("api_key", ""))
    elif step == "overseerr": ok, msg = await test_overseerr(body.get("url", ""), body.get("api_key", ""))
    elif step == "plex":      ok, msg = await test_plex_root(body.get("plex_root", ""))
    else:                     ok, msg = False, "Unknown step"
    return JSONResponse({"ok": ok, "message": msg})


@app.post("/setup/save")
async def setup_save(request: Request):
    form = dict(await request.form())
    config = {
        "ALLDEBRID_API_KEY":  form.get("akey", ""),
        "OVERSEERR_URL":      form.get("ourl", ""),
        "OVERSEERR_API_KEY":  form.get("okey", ""),
        "DEBRIDARR_BASE_URL": form.get("base_url", ""),
        "TZ":                 form.get("tz", "America/Edmonton"),
        "PUID":               form.get("puid", "1000"),
        "PGID":               form.get("pgid", "1000"),
    }
    write_env(config)
    import os
    for k, v in config.items(): os.environ[k] = v
    os.environ["PLEX_ROOT"] = form.get("plex_root", "/plex-strm")
    mark_setup_complete()
    request.app.state.setup_complete = True
    _init_clients(request.app)
    log.info("✅ Setup complete — restarting...")
    _schedule_restart(delay=2.0)
    return HTMLResponse(f"""<!DOCTYPE html><html><head><meta charset="UTF-8">
<meta http-equiv="refresh" content="6;url=/library">
<style>{_SETUP_CSS}</style></head><body>
<header><h1>🎬 Debridarr</h1><span class="ver">v0.5.0</span></header>
<div class="wizard"><div class="wizard-card" style="text-align:center;padding:48px">
<div style="font-size:3rem;margin-bottom:16px">🎉</div>
<h2 style="color:#4ade80;margin-bottom:12px">Setup Complete!</h2>
<p style="color:#888;margin-bottom:24px">Redirecting to library...</p>
<a href="/library" style="color:#f97316">Click here if not redirected</a>
</div></div></body></html>""")


# ── / redirect ────────────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    if _needs_setup(request): return _setup_redirect()
    return RedirectResponse("/library")


# ── /jobs ─────────────────────────────────────────────────────────────────────
@app.get("/jobs", response_class=HTMLResponse)
async def jobs_page(request: Request):
    if _needs_setup(request): return _setup_redirect()
    db: CacheDB = request.app.state.db
    workers = int(db.get_setting("resolve_workers", "3"))

    def fmt_duration(start_iso: str) -> str:
        try:
            secs = int((datetime.utcnow() - datetime.fromisoformat(start_iso)).total_seconds())
            if secs < 60:  return f"{secs}s"
            if secs < 3600: return f"{secs//60}m {secs%60}s"
            return f"{secs//3600}h {(secs%3600)//60}m"
        except Exception:
            return "?"

    def job_row(j: dict, running: bool) -> str:
        dur    = fmt_duration(j["started_at"]) if running else fmt_duration(j.get("finished_at", j["started_at"]))
        status = j.get("status", "running")
        dot    = {"running": "#22c55e", "done": "#555", "error": "#ef4444", "cancelled": "#f97316"}.get(status, "#888")
        cancel = f'<button class="btn btn-rem" style="padding:3px 10px;font-size:0.72rem" onclick="cancelJob(\'{j["id"]}\')">✕ Cancel</button>' if running and j.get("cancellable") else ""
        err    = f'<span style="color:#f87171;font-size:0.72rem">{j.get("error","")}</span>' if j.get("error") else ""
        return f"""<tr>
          <td style="font-family:monospace;font-size:0.75rem;color:#555">{j["id"]}</td>
          <td><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:{dot};margin-right:6px"></span>{j["name"]}</td>
          <td style="color:#888;font-size:0.78rem">{j["type"]}</td>
          <td style="color:#888;font-size:0.78rem">{"⏱ "+dur if running else dur}</td>
          <td>{cancel}{err}</td>
        </tr>"""

    running_rows  = "".join(job_row(j, True)  for j in _jobs.values())
    history_rows  = "".join(job_row(j, False) for j in list(_jobs_history)[:50])

    running_table = f"""<table><thead><tr>
      <th>ID</th><th>Job</th><th>Type</th><th>Running</th><th></th>
    </tr></thead><tbody>{running_rows}</tbody></table>""" if running_rows else \
    '<div class="empty">No jobs running.</div>'

    history_table = f"""<table><thead><tr>
      <th>ID</th><th>Job</th><th>Type</th><th>Duration</th><th>Status</th>
    </tr></thead><tbody>{history_rows}</tbody></table>""" if history_rows else \
    '<div class="empty">No completed jobs yet.</div>'

    body = f"""
    <h2 style="margin-bottom:20px">⚙️ Jobs</h2>

    <div class="s-sect">
      <div class="s-title">Worker Settings</div>
      <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap">
        <div class="field" style="max-width:220px;margin:0">
          <label>Max concurrent resolve workers</label>
          <input id="worker-count" type="number" min="1" max="10" value="{workers}"
                 style="background:#0f0f13;border:1px solid #2a2a3a;border-radius:7px;padding:8px 12px;color:#e0e0e0;font-size:0.875rem;width:100%">
          <div class="hint">How many resolve_and_cache tasks run in parallel. Higher = faster but more AllDebrid API load.</div>
        </div>
        <button class="btn btn-add" style="padding:8px 20px;margin-top:14px" onclick="saveWorkers()">Save</button>
        <div id="worker-result" class="test-result" style="margin-top:14px;flex:1"></div>
      </div>
    </div>

    <div class="s-sect">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
        <div class="s-title" style="margin:0">Running Jobs ({len(_jobs)})</div>
        <div style="display:flex;gap:8px">
          <button class="btn btn-sec" style="padding:5px 12px;font-size:0.8rem" onclick="location.reload()">🔄 Refresh</button>
          <button class="btn btn-rem" style="padding:5px 12px;font-size:0.8rem" onclick="cancelAll()">✕ Cancel All</button>
        </div>
      </div>
      {running_table}
    </div>

    <div class="s-sect">
      <div class="s-title">Recent Jobs (last {min(len(_jobs_history),50)})</div>
      {history_table}
    </div>"""

    extra = """<script>
async function cancelJob(id) {
  const r = await fetch('/api/jobs/'+id+'/cancel', {method:'POST'});
  const d = await r.json();
  toast(r.ok ? '🚫 Job cancelled' : '❌ '+(d.detail||'Error'), r.ok);
  setTimeout(()=>location.reload(), 800);
}
async function cancelAll() {
  if (!confirm('Cancel all running jobs?')) return;
  const r = await fetch('/api/jobs/cancel-all', {method:'POST'});
  const d = await r.json();
  toast('🚫 Cancelled '+d.cancelled+' jobs');
  setTimeout(()=>location.reload(), 800);
}
async function saveWorkers() {
  const n   = parseInt(document.getElementById('worker-count').value);
  const res = document.getElementById('worker-result');
  if (!n || n < 1 || n > 10) { res.className='test-result err'; res.style.display='block'; res.textContent='❌ Must be 1–10'; return; }
  const r = await fetch('/api/jobs/workers', {method:'POST',
    headers:{'Content-Type':'application/json'}, body:JSON.stringify({count:n})});
  const d = await r.json();
  res.className = 'test-result '+(r.ok?'ok':'err');
  res.style.display = 'block';
  res.textContent = r.ok ? '✅ Workers set to '+d.workers+' (takes effect immediately)' : '❌ '+(d.detail||'Error');
}
// Auto-refresh every 3s when jobs are running
if (document.querySelector('tbody tr')) {
  setTimeout(()=>location.reload(), 3000);
}
</script>"""
    return _page("Jobs", "jobs", body, extra)


@app.post("/api/jobs/{job_id}/cancel")
async def api_job_cancel(job_id: str):
    job = _jobs.get(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    if not job.get("cancellable"):
        raise HTTPException(400, "Job is not cancellable")
    job["cancel_event"].set()
    job["status"] = "cancelling"
    return {"status": "ok", "message": f"Cancelling job {job_id}"}


@app.post("/api/jobs/cancel-all")
async def api_jobs_cancel_all():
    count = 0
    for job in list(_jobs.values()):
        if job.get("cancellable") and not job["cancel_event"].is_set():
            job["cancel_event"].set()
            job["status"] = "cancelling"
            count += 1
    return {"status": "ok", "cancelled": count}


@app.post("/api/jobs/workers")
async def api_jobs_workers(request: Request):
    body    = await request.json()
    count   = int(body.get("count", 3))
    count   = max(1, min(10, count))
    db: CacheDB = request.app.state.db
    db.set_setting("resolve_workers", str(count))
    _reset_semaphore(count)
    log.info(f"⚙️  Resolve workers set to {count}")
    return {"status": "ok", "workers": count}


@app.get("/api/jobs")
async def api_jobs_list():
    def serialise(j: dict) -> dict:
        return {k: v for k, v in j.items() if k != "cancel_event"}
    return {
        "running":  [serialise(j) for j in _jobs.values()],
        "history":  [serialise(j) for j in list(_jobs_history)[:50]],
        "workers":  _resolve_semaphore._value if _resolve_semaphore else 3,
    }


# ── /import — Sonarr / Radarr direct import ───────────────────────────────────
@app.get("/import", response_class=HTMLResponse)
async def import_page(request: Request, tab: str = "radarr", q: str = "", page: int = 1):
    if _needs_setup(request): return _setup_redirect()
    lm: LibraryManager = request.app.state.library
    db: CacheDB = request.app.state.db

    radarr_url = db.get_setting("RADARR_URL", "")
    radarr_key = db.get_setting("RADARR_API_KEY", "")
    sonarr_url = db.get_setting("SONARR_URL", "")
    sonarr_key = db.get_setting("SONARR_API_KEY", "")

    already_added = {(r["media_type"], r["title"].lower()) for r in db.fake_library_list()}

    if tab == "radarr":
        items = await lm.get_radarr_direct(radarr_url, radarr_key)
        source_name = "Radarr"
        not_configured = not radarr_url or not radarr_key
    else:
        items = await lm.get_sonarr_direct(sonarr_url, sonarr_key)
        source_name = "Sonarr"
        not_configured = not sonarr_url or not sonarr_key

    if q:
        ql = q.lower()
        items = [i for i in items if ql in i["title"].lower()]

    mtype = "movie" if tab == "radarr" else "series"

    IMP_PER_PAGE   = 24
    total_imp      = len(items)
    total_imp_pages = max(1, (total_imp + IMP_PER_PAGE - 1) // IMP_PER_PAGE)
    page           = max(1, min(page, total_imp_pages))
    not_added      = [i for i in items if (mtype, i["title"].lower()) not in already_added]
    items          = items[(page-1)*IMP_PER_PAGE : page*IMP_PER_PAGE]
    not_added_page = [i for i in items if (mtype, i["title"].lower()) not in already_added]

    cards = ""
    for item in items:
        in_lib = (mtype, item["title"].lower()) in already_added
        poster = item.get("poster", "")
        year   = item.get("year", "")
        safe   = item["title"].replace("'", "&#39;").replace('"', "&quot;")
        img    = f'<img src="{poster}" onerror="this.style.display=\'none\'" loading="lazy">' if poster \
                 else f'<div class="no-poster">{"".join(w[0].upper() for w in item["title"].split()[:2])}</div>'

        if tab == "radarr":
            meta = str(year or "")
            has_file = item.get("has_file", False)
            meta += ' <span style="color:#22c55e;font-size:0.7rem">●&nbsp;Downloaded</span>' if has_file else \
                    ' <span style="color:#888;font-size:0.7rem">○&nbsp;Not downloaded</span>'
        else:
            sc   = item.get("season_count", 0)
            meta = f"{year or ''} · {sc} season{'s' if sc!=1 else ''}"
            st   = item.get("status", "")
            col  = "#ef4444" if item.get("is_ended") else "#22c55e"
            meta += f' <span style="color:{col};font-size:0.7rem">({st})</span>'

        sc = item.get("season_count", 0)
        if in_lib:
            action = f'<span class="badge-in">✓ In Library</span>'
        else:
            action = (
                f'<button class="btn btn-add" style="padding:4px 10px;font-size:0.78rem"'
                f' data-mtype="{mtype}" data-id="{item.get("id","")}"'
                f' data-title="{safe}" data-year="{year or ""}" data-sc="{sc}"'
                f' onclick="addCard(this)">+ Add</button>'
            )

        cards += f"""<div class="card" data-title="{safe.lower()}" data-in-lib="{'1' if in_lib else '0'}">
          {img}
          <div class="info"><div class="title" title="{safe}">{item["title"]}</div>
          <div class="meta">{meta}</div></div>
          <div class="actions">{action}</div>
        </div>"""

    if not cards:
        if not_configured:
            cards = f'<div class="empty">Configure {source_name} URL and API key in <a href="/settings" style="color:#f97316">Settings</a>.</div>'
        else:
            cards = f'<div class="empty">{"No results for &quot;"+q+"&quot;" if q else "Nothing found in "+source_name}</div>'

    radarr_count = len(await lm.get_radarr_direct(radarr_url, radarr_key)) if radarr_url and radarr_key else 0
    sonarr_count = len(await lm.get_sonarr_direct(sonarr_url, sonarr_key)) if sonarr_url and sonarr_key else 0
    not_added_count = len(not_added)

    body = f"""
    <h2>Import from Sonarr / Radarr</h2>
    <div class="tabs">
      <div class="tab {'active' if tab=='radarr' else ''}" onclick="switchTab('radarr')">🎬 Radarr ({radarr_count})</div>
      <div class="tab {'active' if tab=='sonarr' else ''}" onclick="switchTab('sonarr')">📺 Sonarr ({sonarr_count})</div>
    </div>
    <div class="search-bar">
      <input id="q" type="text" placeholder="Search {source_name}..." value="{q}" oninput="filterCards()">
      <button class="btn btn-sec" onclick="clearSearch()">Clear</button>
      <button class="btn btn-sec" onclick="refreshSource()">🔄 Refresh</button>
      {f'<button class="btn btn-add" onclick="addAllServer()" style="margin-left:auto" id="add-all-btn">+ Add All ({len(not_added)})</button>' if not_added else ''}
    </div>
    <div id="card-grid" class="card-grid">{cards}</div>
    {_pagination("/import", {"tab": tab, "q": q}, page, total_imp_pages)}
    <div id="add-progress" style="display:none;margin-top:16px;padding:12px;background:#1a1a24;border-radius:8px;font-size:0.85rem"></div>"""

    import json as _ijson
    _not_added_json = _ijson.dumps([{
        "title": i["title"], "year": i.get("year"),
        "id": i.get("id"), "sc": i.get("season_count", 0)
    } for i in not_added])

    extra = f"""<script>
const CURRENT_TAB = '{tab}';
const ALL_NOT_ADDED = {_not_added_json};

function switchTab(t) {{
  window.location.href = '/import?tab=' + t;
}}

function filterCards() {{
  const q = document.getElementById('q').value.toLowerCase();
  document.querySelectorAll('#card-grid .card').forEach(c => {{
    c.style.display = q === '' || c.dataset.title.includes(q) ? '' : 'none';
  }});
}}

function clearSearch() {{
  document.getElementById('q').value = '';
  filterCards();
}}

async function refreshSource() {{
  window.location.href = '/import?tab=' + CURRENT_TAB + '&_=' + Date.now();
}}

async function addCard(btn) {{
  btn.disabled = true;
  btn.textContent = '⏳';
  const type  = btn.dataset.mtype;
  const id    = parseInt(btn.dataset.id) || null;
  const title = btn.dataset.title.replace(/&#39;/g,"'").replace(/&quot;/g,'"');
  const year  = btn.dataset.year ? parseInt(btn.dataset.year) : null;
  const sc    = parseInt(btn.dataset.sc) || 0;
  const r = await fetch('/api/library/add', {{method:'POST',
    headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{media_type:type, arr_id:id, title, year, season_count:sc}})}});
  const d = await r.json();
  if (r.ok && d.status !== 'skipped') {{
    btn.textContent = '✓ Added';
    btn.className = 'btn';
    btn.style.background = '#14532d';
    btn.disabled = true;
    btn.closest('.card').dataset.inLib = '1';
    toast('✅ ' + title + ' added');
  }} else if (d.status === 'skipped') {{
    btn.textContent = '🎬 Not out yet';
    btn.style.background = '#78350f';
    btn.style.color = '#fcd34d';
    btn.disabled = true;
    toast('⏭️ ' + title + ' is not released yet', false);
  }} else {{
    btn.textContent = '❌ Error';
    btn.disabled = false;
    toast('❌ ' + (d.detail || d.message || 'Error'), false);
  }}
}}

async function addAllServer() {{
  const btn  = document.getElementById('add-all-btn');
  const prog = document.getElementById('add-progress');
  if (!ALL_NOT_ADDED || !ALL_NOT_ADDED.length) {{ toast('Nothing to add', false); return; }}
  btn.disabled  = true;
  btn.textContent = '⏳ Starting...';
  prog.style.display = 'block';
  prog.textContent = `Queuing ${{ALL_NOT_ADDED.length}} item(s)...`;

  const r = await fetch('/api/import/add-all', {{
    method: 'POST',
    headers: {{'Content-Type': 'application/json'}},
    body: JSON.stringify({{ tab: CURRENT_TAB, items: ALL_NOT_ADDED }}),
  }});
  const d = await r.json();

  if (!r.ok) {{
    prog.textContent = '❌ Error: ' + (d.detail || 'Failed');
    btn.disabled = false;
    btn.textContent = '+ Add All';
    return;
  }}

  if (d.queued === 0) {{
    prog.textContent = '✅ ' + (d.message || 'All already in library');
    btn.textContent = '+ Add All (0)';
    return;
  }}

  prog.textContent = `✅ ${{d.queued}} item(s) queued — adding in background (job: ${{d.job_id}})`;
  btn.textContent  = `⏳ Adding ${{d.queued}}...`;

  // Poll the job until done
  let polls = 0;
  const poll = setInterval(async () => {{
    polls++;
    const jr = await fetch('/api/jobs');
    const jd = await jr.json();
    const running  = jd.running  || [];
    const history  = jd.history  || [];
    const job = running.find(j => j.id === d.job_id) ||
                history.find(j => j.id === d.job_id);

    if (!job || job.status === 'done') {{
      clearInterval(poll);
      prog.textContent = `✅ Done — ${{d.queued}} item(s) added. Refreshing...`;
      btn.textContent  = '✅ Done';
      setTimeout(() => location.href = '/import?tab=' + CURRENT_TAB, 1500);
    }} else if (job.status === 'error') {{
      clearInterval(poll);
      prog.textContent = '❌ Import error: ' + (job.error || 'Unknown');
      btn.disabled = false;
      btn.textContent = '+ Add All';
    }} else if (polls > 600) {{
      clearInterval(poll);
      prog.textContent = '⏰ Still running in background — check Jobs page';
    }} else {{
      prog.textContent = `⏳ Adding... (job ${{d.job_id}} running)`;
    }}
  }}, 2000);
}}

// Keep old addAll as alias for page-level cards (used nowhere now but kept for safety)
async function addAll() {{ return addAllServer(); }}
</script>"""

    return _page("Import", "import", body, extra)


@app.get("/api/test-prowlarr")
async def api_test_prowlarr(request: Request):
    """Test Prowlarr connectivity and return the first few indexer names."""
    db: CacheDB = request.app.state.db
    url = db.get_setting("PROWLARR_URL", "").rstrip("/")
    key = db.get_setting("PROWLARR_API_KEY", "")
    if not url or not key:
        return {"ok": False, "message": "PROWLARR_URL or PROWLARR_API_KEY not set in Settings"}
    import httpx as _hx
    try:
        # Test 1: hit the indexers list endpoint
        async with _hx.AsyncClient(timeout=10) as c:
            r = await c.get(
                f"{url}/api/v1/indexer",
                headers={"X-Api-Key": key},
            )
        if r.status_code == 200:
            indexers    = r.json()
            names       = [i.get("name", "?") for i in indexers[:5]]
            search_url  = f"{url}/api/v1/search"
            return {
                "ok":           True,
                "message":      f"{len(indexers)} indexer(s): {', '.join(names)}",
                "torznab_url":  search_url,
                "indexer_count": len(indexers),
            }
        elif r.status_code == 401:
            return {"ok": False, "message": f"Unauthorized — check API key (HTTP 401)"}
        elif r.status_code == 404:
            return {
                "ok":     False,
                "message": (
                    f"HTTP 404 — URL may be wrong. "
                    f"Tried: {url}/api/v1/indexer. "
                    f"Expected format: http://prowlarr:9696 or http://host:9696/prowlarr"
                ),
            }
        else:
            return {"ok": False, "message": f"HTTP {r.status_code} from {url}"}
    except Exception as e:
        return {"ok": False, "message": str(e)}


@app.post("/api/import/refresh")
async def api_import_refresh(request: Request):
    lm: LibraryManager = request.app.state.library
    lm.invalidate_direct_cache()
    return {"status": "ok"}


@app.post("/api/import/add-all")
async def api_import_add_all(request: Request, background_tasks: BackgroundTasks):
    """
    Add every not-yet-added item from Sonarr or Radarr in one call.
    The client sends the full list (title, year, id, media_type, season_count)
    for every item it wants added. Processing happens in a background task so
    the HTTP response returns immediately with a job_id to poll.
    """
    body     = await request.json()
    tab      = body.get("tab", "radarr")          # "radarr" | "sonarr"
    items    = body.get("items", [])              # [{title, year, id, sc}, ...]
    mtype    = "movie" if tab == "radarr" else "series"

    if not items:
        return {"status": "ok", "queued": 0, "message": "Nothing to add"}

    db: CacheDB         = request.app.state.db
    lm: LibraryManager  = request.app.state.library

    # Filter out already-added items server-side (race-safe)
    already = {(r["media_type"], r["title"].lower()) for r in db.fake_library_list()}
    to_add  = [i for i in items if (mtype, i["title"].lower()) not in already]

    if not to_add:
        return {"status": "ok", "queued": 0, "message": "All items already in library"}

    jid, cancel_event = _job_start(
        f"Bulk import {len(to_add)} {mtype}(s) from {'Radarr' if tab=='radarr' else 'Sonarr'}",
        job_type="bulk_import",
        cancellable=True,
    )

    async def _do_bulk():
        added = skipped = errors = 0
        for item in to_add:
            if cancel_event.is_set():
                break
            try:
                # Re-use the same logic as /api/library/add
                title        = item.get("title", "").strip()
                year         = item.get("year")
                arr_id       = item.get("id")
                season_count = item.get("sc", 0)
                if not title:
                    continue

                tmdb_key = db.get_setting("tmdb_api_key", "")

                if mtype == "movie":
                    movies     = await lm.get_radarr_movies()
                    movie      = next((m for m in movies if m.get("id") == arr_id
                                       or m["title"].lower() == title.lower()), None)
                    poster_url = movie.get("poster", "") if movie else ""
                    tmdb_id    = movie.get("tmdb_id") if movie else None
                    imdb_id    = movie.get("imdb_id") if movie else None
                    overview   = movie.get("overview", "") if movie else ""

                    include_unreleased = db.get_setting("include_unreleased_movies", "false") == "true"
                    if not include_unreleased:
                        from datetime import date
                        release_date = movie.get("release_date", "") if movie else ""
                        if release_date and release_date > date.today().isoformat():
                            skipped += 1
                            continue

                    if not poster_url and tmdb_key and tmdb_id:
                        poster_url = await _fetch_tmdb_poster(tmdb_id, title, True, tmdb_key)

                    db.fake_library_add({
                        "media_type": "movie", "title": title, "year": year,
                        "radarr_id": arr_id, "tmdb_id": tmdb_id, "imdb_id": imdb_id,
                        "poster_url": poster_url, "overview": overview,
                        "status": "movie", "fake_path": None,
                    })
                    if db.get_setting("precache_enabled", "true") != "false":
                        _queue_index(request.app, _precache_movie, request.app, title, year, tmdb_id, imdb_id)
                    added += 1
                    log.info(f"📦 Bulk import movie: {title} ({year})")

                else:
                    series_list = await lm.get_sonarr_series()
                    series      = next((s for s in series_list if s.get("id") == arr_id), None)
                    sc          = series.get("season_count", season_count) if series else season_count
                    tvdb_id     = series.get("tvdb_id") if series else None
                    tmdb_id     = series.get("tmdb_id") if series else None
                    imdb_id     = series.get("imdb_id") if series else None
                    poster_url  = series.get("poster", "") if series else ""
                    overview    = series.get("overview", "") if series else ""
                    is_ended    = series.get("is_ended", False) if series else False
                    req_seasons = series.get("requested_seasons", []) if series else []

                    if not poster_url and tmdb_key and tmdb_id:
                        poster_url = await _fetch_tmdb_poster(tmdb_id, title, False, tmdb_key)

                    include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"
                    episodes = await lm.get_episodes(
                        arr_id, include_unreleased=True,
                        requested_seasons=req_seasons if req_seasons else None,
                    )

                    db.fake_library_add({
                        "media_type": "series", "title": title, "year": year,
                        "sonarr_id": arr_id, "tvdb_id": tvdb_id, "tmdb_id": tmdb_id,
                        "imdb_id": imdb_id, "season_count": sc, "poster_url": poster_url,
                        "overview": overview,
                        "status": "ended" if is_ended else "continuing",
                        "fake_path": None,
                    })
                    if db.get_setting("precache_enabled", "true") != "false":
                        _queue_index(request.app, _precache_series, request.app, title, year, episodes)
                    added += 1
                    log.info(f"📦 Bulk import series: {title} ({year})")

                # Small yield so other tasks aren't starved
                await asyncio.sleep(0.1)

            except asyncio.CancelledError:
                break
            except Exception as e:
                log.error(f"Bulk import '{item.get('title')}': {e}")
                errors += 1

        summary = f"Bulk import done: {added} added, {skipped} skipped, {errors} errors"
        log.info(f"📦 {summary}")
        _job_done(jid)

    background_tasks.add_task(_do_bulk)
    return {"status": "ok", "job_id": jid, "queued": len(to_add)}


# ── /library — browse Overseerr ───────────────────────────────────────────────
@app.get("/library", response_class=HTMLResponse)
async def library_browse(request: Request, tab: str = "movies", q: str = "", page: int = 1):
    if _needs_setup(request): return _setup_redirect()
    lm: LibraryManager = request.app.state.library
    db: CacheDB = request.app.state.db

    PER_PAGE = 24
    already_added = {(r["media_type"], r["title"].lower()) for r in db.fake_library_list()}

    if tab == "movies":
        all_items = await lm.get_radarr_movies()
    else:
        all_items = await lm.get_sonarr_series()

    if q:
        ql = q.lower()
        all_items = [i for i in all_items if ql in i["title"].lower()]

    total_items = len(all_items)
    total_pages = max(1, (total_items + PER_PAGE - 1) // PER_PAGE)
    page        = max(1, min(page, total_pages))
    items       = all_items[(page-1)*PER_PAGE : page*PER_PAGE]

    cards = ""
    for item in items:
        mtype = "movie" if tab == "movies" else "series"
        year  = item.get("year")
        in_lib = (mtype, item["title"].lower()) in already_added
        poster = item.get("poster", "")
        img = f'<img src="{poster}" onerror="this.style.display=\'none\'" loading="lazy">' if poster else f'<div class="no-poster">{item["title"][:1]}</div>'
        safe = item["title"].replace("'", "\\'").replace('"', '&quot;')
        sc  = item.get("season_count", 0)
        meta = str(year or "")
        if tab != "movies" and sc:
            meta += f" · {sc} season{'s' if sc != 1 else ''}"
        badge = '<div class="actions"><span class="badge-in">✓ In Library</span>' if in_lib else ""

        if in_lib:
            t = item["title"].replace('"', '&quot;')
            action = f'<button class="btn btn-rem" data-mtype="{mtype}" data-title="{t}" data-year="{year or ""}" onclick="removeCard(this)">Remove</button>'
        else:
            t = item["title"].replace('"', '&quot;')
            action = f'<button class="btn btn-add" data-mtype="{mtype}" data-id="{item.get("id","")}" data-title="{t}" data-year="{year or ""}" data-sc="{sc}" onclick="addCard(this)">+ Add</button>'

        cards += f"""<div class="card">
          {img}
          <div class="info">
            <div class="title" title="{item['title']}">{item['title']}</div>
            <div class="meta">{meta}</div>
          </div>
          <div class="actions">{action}</div>
        </div>"""

    if not cards:
        cards = f'<div class="empty">{"No results for &quot;"+q+"&quot;" if q else "Nothing found — check Overseerr settings"}</div>'

    movie_count = len(await lm.get_radarr_movies())
    tv_count    = len(await lm.get_sonarr_series())

    body = f"""
    <h2>Browse Library</h2>
    <div class="tabs">
      <div class="tab {'active' if tab=='movies' else ''}" onclick="location.href='/library?tab=movies&q={q}'">🎬 Movies ({movie_count})</div>
      <div class="tab {'active' if tab=='tv'     else ''}" onclick="location.href='/library?tab=tv&q={q}'">📺 TV Shows ({tv_count})</div>
    </div>
    <div class="search-bar">
      <input id="q" type="text" placeholder="Search..." value="{q}"
             onkeydown="if(event.key==='Enter')location.href='/library?tab={tab}&q='+encodeURIComponent(this.value)">
      <button class="btn btn-add" onclick="location.href='/library?tab={tab}&q='+encodeURIComponent(document.getElementById('q').value)">Search</button>
      {'<button class="btn btn-sec" onclick="location.href=\'/library?tab='+tab+'\'">Clear</button>' if q else ''}
      <button class="btn btn-sec" onclick="refreshLib()">🔄 Refresh</button>
    </div>
    <div class="card-grid">{cards}</div>
    {_pagination("/library", {"tab": tab, "q": q}, page, total_pages)}"""

    extra = """<script>
function addCard(btn) {
  const type  = btn.dataset.mtype;
  const id    = parseInt(btn.dataset.id) || null;
  const title = btn.dataset.title;
  const year  = btn.dataset.year ? parseInt(btn.dataset.year) : null;
  const sc    = parseInt(btn.dataset.sc) || 0;
  addItem(type, id, title, year, sc);
}
function removeCard(btn) {
  const type  = btn.dataset.mtype;
  const title = btn.dataset.title;
  const year  = btn.dataset.year ? parseInt(btn.dataset.year) : null;
  removeItem(type, title, year);
}
async function addItem(type, id, title, year, sc) {
  const r = await fetch('/api/library/add', {method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({media_type:type,arr_id:id,title,year,season_count:sc})});
  const d = await r.json();
  if (r.ok && d.status !== 'skipped') { toast('✅ '+title+' added'); setTimeout(()=>location.reload(),1200); }
  else if (d.status === 'skipped') { toast('⏭️ '+title+' is not released yet — enable "Include unreleased movies" in Settings', false); }
  else { toast('❌ '+(d.detail||d.message||'Error'), false); }
}
async function removeItem(type, title, year) {
  if (!confirm('Remove "'+title+'" from library?')) return;
  const r = await fetch('/api/library/remove',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({media_type:type,title,year})});
  if (r.ok) { toast('🗑️ Removed'); setTimeout(()=>location.reload(),1200); }
  else { toast('❌ Error', false); }
}
async function refreshLib() {
  const r = await fetch('/api/library/refresh',{method:'POST'});
  const d = await r.json();
  toast('✅ Refreshed — '+d.synced+' series updated');
  setTimeout(()=>location.reload(),1200);
}
</script>"""
    return _page("Browse Library", "library", body, extra)


# ── /api/library/add ─────────────────────────────────────────────────────────
@app.post("/api/library/add")
async def api_library_add(request: Request, background_tasks: BackgroundTasks):
    body = await request.json()
    media_type   = body.get("media_type", "movie")
    arr_id       = body.get("arr_id")
    title        = body.get("title", "").strip()
    year         = body.get("year")
    season_count = body.get("season_count", 0)

    if not title:
        raise HTTPException(400, "title required")

    lm: LibraryManager = request.app.state.library
    db: CacheDB         = request.app.state.db
    tmdb_key            = db.get_setting("tmdb_api_key", "")

    if media_type == "movie":
        # Fetch full movie details from Overseerr to get poster/overview/tmdb_id
        movies = await lm.get_radarr_movies()
        movie  = next((m for m in movies if m.get("id") == arr_id or m["title"].lower() == title.lower()), None)

        poster_url = movie.get("poster", "") if movie else ""
        tmdb_id    = movie.get("tmdb_id") if movie else None
        imdb_id    = movie.get("imdb_id") if movie else None
        overview   = movie.get("overview", "") if movie else ""

        # Filter unreleased movies if setting is off
        include_unreleased_movies = db.get_setting("include_unreleased_movies", "false") == "true"
        if not include_unreleased_movies:
            from datetime import date
            today = date.today().isoformat()
            release_date = movie.get("release_date", "") if movie else ""
            if release_date and release_date > today:
                log.info(f"⏭️  Skipping unreleased movie: {title!r} (release_date={release_date!r})")
                return {"status": "skipped", "message": f"{title} is not yet released — enable 'Include unreleased movies' in Settings to add it"}

        # Fetch poster from TMDB if not from Overseerr
        if not poster_url and tmdb_key and tmdb_id:
            poster_url = await _fetch_tmdb_poster(tmdb_id, title, True, tmdb_key)

        db.fake_library_add({
            "media_type": "movie",
            "title":      title,
            "year":       year,
            "radarr_id":  arr_id,
            "tmdb_id":    tmdb_id,
            "imdb_id":    imdb_id,
            "poster_url": poster_url,
            "overview":   overview,
            "status":     "movie",
            "fake_path":  None,
        })
        log.info(f"🎬 Added movie: {title} ({year})")
        _queue_index(request.app, _precache_movie, request.app, title, year, tmdb_id, imdb_id)

        return {"status": "ok", "message": f"Added {title}"}

    else:
        # Series — fetch details synchronously so we can return a useful response
        series_list = await lm.get_sonarr_series()
        series = next((s for s in series_list if s.get("id") == arr_id), None)

        sc                = series.get("season_count", season_count) if series else season_count
        tvdb_id           = series.get("tvdb_id") if series else None
        tmdb_id           = series.get("tmdb_id") if series else None
        imdb_id           = series.get("imdb_id") if series else None
        poster_url        = series.get("poster", "") if series else ""
        overview          = series.get("overview", "") if series else ""
        is_ended          = series.get("is_ended", False) if series else False
        requested_seasons = series.get("requested_seasons", []) if series else []

        if not poster_url and tmdb_key and tmdb_id:
            poster_url = await _fetch_tmdb_poster(tmdb_id, title, False, tmdb_key)

        # Fetch ALL episodes from Overseerr/TMDB (including unreleased)
        episodes = await lm.get_episodes(
            arr_id,
            include_unreleased=True,
            requested_seasons=requested_seasons if requested_seasons else None,
        )

        log.info(f"📺 {title}: {len(episodes)} episodes from Overseerr for seasons {requested_seasons}")

        db.fake_library_add({
            "media_type":   "series",
            "title":        title,
            "year":         year,
            "sonarr_id":    arr_id,
            "tvdb_id":      tvdb_id,
            "tmdb_id":      tmdb_id,
            "imdb_id":      imdb_id,
            "season_count": sc,
            "poster_url":   poster_url,
            "overview":     overview,
            "status":       "ended" if is_ended else "continuing",
            "fake_path":    None,
        })

        log.info(f"📺 Added {title!r} — episodes indexed, no placeholders created")

        # Index hashes in background (no AllDebrid changes until play)
        _queue_index(request.app, _precache_series, request.app, title, year, episodes)

        return {"status": "ok", "message": f"Added {title} — {len(episodes)} episodes"}


@app.post("/api/library/remove")
async def api_library_remove(request: Request):
    body  = await request.json()
    mtype = body.get("media_type")
    title = body.get("title", "").strip()
    year  = body.get("year")
    lm    = request.app.state.library
    db    = request.app.state.db
    alldebrid = request.app.state.alldebrid

    # ── 0. Cancel all running jobs and precache tasks for this title ─────────
    title_lower = title.lower()
    cancelled_jobs = 0
    for job in list(_jobs.values()):
        if job.get("name", "").lower().startswith(title_lower):
            evt = job.get("cancel_event")
            if evt:
                evt.set()
                job["status"] = "cancelling"
                cancelled_jobs += 1
    if cancelled_jobs:
        log.info(f"🚫 Cancelled {cancelled_jobs} running job(s) for '{title}'")

    # Cancel the precache asyncio Task directly so the episode loop stops immediately
    precache_task = _precache_tasks.pop(title_lower, None)
    if precache_task and not precache_task.done():
        precache_task.cancel()
        log.info(f"🚫 Cancelled precache task for '{title}'")

    await asyncio.sleep(0.5)  # brief grace period for tasks to wind down

    # ── 1. Find all cache entries for this title ──────────────────────────────
    db_types    = ["movie"] if mtype == "movie" else ["episode", "series"]
    all_entries = db.list_all()
    entries     = [
        e for e in all_entries
        if e["title"].lower() == title.lower() and e["media_type"] in db_types
    ]
    log.info(f"🗑️  Removing '{title}' — {len(entries)} cache entries to clean up")

    # ── 2. AllDebrid: delete magnets ──────────────────────────────────────────
    import re as _re
    deleted_magnet_ids: set[str] = set()
    for entry in entries:
        magnet = entry.get("magnet_link") or ""
        m = _re.search(r"[?&]xt=urn:btih:([a-fA-F0-9]{40})", magnet, _re.I)
        if not m:
            continue
        # Find the magnet ID by querying AllDebrid status
        # We stored the magnet ID from add_magnet — it's not in our DB directly,
        # but we can delete by hash using the upload endpoint
        # Simpler: re-upload to get the ID, then delete
        try:
            result = await alldebrid._ad_post(
                alldebrid._client, alldebrid.api_key,
                "https://api.alldebrid.com/v4/magnet/upload",
                [("magnets[]", magnet)],
            )
            magnets_returned = result.get("data", {}).get("magnets", [])
            for mg in magnets_returned:
                if mg.get("error"):
                    continue
                mid = str(mg.get("id", ""))
                if mid and mid not in deleted_magnet_ids:
                    await alldebrid.delete_magnet(mid)
                    deleted_magnet_ids.add(mid)
                    log.info(f"  🗑️  AllDebrid: deleted magnet id={mid}")
        except Exception as e:
            log.warning(f"  ⚠ AllDebrid cleanup failed for '{title}': {e}")

    # ── 3. FUSE: unregister torrents ──────────────────────────────────────────
    if FUSE_AVAILABLE:
        torrent_names = {e["torrent_name"] for e in entries if e.get("torrent_name")}
        for tname in torrent_names:
            unregister_torrent(tname)
            log.info(f"  🗑️  FUSE: unregistered '{tname}'")

    # ── 4. DFS chunk cache: delete chunks for these stream URLs ───────────────
    try:
        from app.fuse_mount import _dfs
        import hashlib as _hl
        cache_dir = Path(_dfs.get("cache_dir", "/docker/debridarr/tmp/cache"))
        if cache_dir.exists():
            stream_urls = {e["stream_url"] for e in entries if e.get("stream_url")}
            deleted_chunks = 0
            for url in stream_urls:
                h = _hl.md5(url.encode()).hexdigest()[:16]
                for chunk_file in cache_dir.glob(f"{h}_*"):
                    chunk_file.unlink(missing_ok=True)
                    deleted_chunks += 1
            if deleted_chunks:
                log.info(f"  🗑️  DFS: deleted {deleted_chunks} cached chunks")
    except Exception as e:
        log.warning(f"  ⚠ DFS chunk cleanup failed: {e}")

    # ── 5. Plex-strm: remove files ───────────────────────────────────────────
    if mtype == "movie":
        lm.remove_fake_movie(title, year)
    else:
        lm.remove_fake_series(title)

    # ── 6. DB: remove cache entries and fake_library record ──────────────────
    for entry in entries:
        db.delete(entry["cache_key"])
    db.fake_library_remove(mtype, title, year)

    # ── 6b. Hash index: remove all hashes for this title ─────────────────────
    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    if hi:
        removed_hashes = hi.delete_for_title(title)
        log.info(f"🗑️  HashIndex: removed {removed_hashes} hash entries for '{title}'")

    # ── 7. Clear in-memory search cache ──────────────────────────────────────
    from app.alldebrid import _search_cache
    for k in [k for k in list(_search_cache) if title.lower() in k.lower()]:
        del _search_cache[k]

    log.info(f"🗑️  '{title}' fully removed: "
             f"{len(entries)} cache entries, {len(deleted_magnet_ids)} AllDebrid magnets, "
             f"{len({e.get('torrent_name') for e in entries if e.get('torrent_name')})} FUSE torrents")

    return {
        "status": "removed",
        "cache_entries_deleted": len(entries),
        "magnets_deleted": len(deleted_magnet_ids),
    }


@app.post("/api/library/refresh")
async def api_library_refresh(request: Request):
    lm = request.app.state.library
    db = request.app.state.db
    if not lm: return {"status": "error", "message": "Not configured"}
    lm.invalidate_cache()
    movies = await lm.get_radarr_movies(force=True)
    series = await lm.get_sonarr_series(force=True)
    added  = [r for r in db.fake_library_list() if r["media_type"] == "series"]
    include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"
    synced = 0
    for entry in added:
        sid = entry.get("sonarr_id")
        if not sid: continue
        updated = next((s for s in series if s.get("id") == sid), None)
        if not updated: continue
        result = await lm.sync_series_episodes(entry["title"], sid, entry.get("year"),
                                                include_unreleased,
                                                requested_seasons=updated.get("requested_seasons", []))
        if result.get("added", 0) > 0: synced += 1
    return {"status": "ok", "movies": len(movies), "series": len(series), "synced": synced}


# ── /streams — resolved streams + search ─────────────────────────────────────
@app.get("/streams", response_class=HTMLResponse)
async def streams_page(request: Request, q: str = "", filter_type: str = "all"):
    if _needs_setup(request): return _setup_redirect()
    db: CacheDB = request.app.state.db
    tmdb_key = db.get_setting("tmdb_api_key", "")

    # Get library items for the search/poster display
    lib_items = db.fake_library_list()
    movies_lib = [i for i in lib_items if i["media_type"] == "movie"]
    shows_lib  = [i for i in lib_items if i["media_type"] == "series"]

    # Cached counts per title
    all_cached = [e for e in db.list_all() if e["status"] == "cached"]
    cached_counts: dict[str, int] = {}
    for e in all_cached:
        mt = "movie" if e["media_type"] == "movie" else "series"
        k  = f"{mt}::{e['title'].lower()}"
        cached_counts[k] = cached_counts.get(k, 0) + 1

    # Streams table (all entries — filtering done client-side)
    entries = db.list_all()
    entries.sort(key=lambda e: e.get("title","").lower())

    def pill(s):
        cls = {"cached":"pill-ok","resolving":"pill-res","error":"pill-err","not_found":"pill-nf"}.get(s,"pill-pend")
        return f'<span class="pill {cls}">{s}</span>'

    rows = ""
    for e in entries:
        t = e.get("torrent_name","") or ""
        t_short = (t[:60]+"…") if len(t) > 60 else t
        ep  = ""
        if e.get("season"):  ep += f"S{str(e['season']).zfill(2)}"
        if e.get("episode"): ep += f"E{str(e['episode']).zfill(2)}"
        exp = datetime.fromisoformat(e["expires_at"]).strftime("%Y-%m-%d") if e.get("expires_at") else "—"
        safe_title = e['title'].replace('"','&quot;')
        rows += f"""<tr data-title="{safe_title.lower()}" data-status="{e['status']}">
          <td style="color:#888;font-size:0.8rem">{e['media_type']}</td>
          <td><strong>{e['title']}</strong><br><small style="color:#555;font-size:0.72rem">{t_short}</small></td>
          <td style="font-family:monospace">{ep}</td>
          <td>{e.get('quality','—') or '—'}</td>
          <td>{exp}</td>
          <td>{pill(e['status'])}</td>
          <td style="white-space:nowrap">
            <button class="btn btn-rem" style="padding:3px 8px;font-size:0.72rem" data-key="{e['cache_key']}" onclick="del_(this)">Del</button>
            <button class="btn btn-sec" style="padding:3px 8px;font-size:0.72rem;margin-left:4px" data-key="{e['cache_key']}" onclick="expireNow(this)">⏰ Expire</button>
          </td>
        </tr>"""

    total = len(entries)

    # My Library cards section
    def lib_card(item, mtype):
        title  = item["title"]
        safe   = title.replace("'","&#39;").replace('"','&quot;')
        poster = item.get("poster_url") or ""
        sc     = item.get("season_count") or 0
        status = item.get("status","")
        year   = item.get("year") or ""
        n      = cached_counts.get(f"{mtype}::{title.lower()}", 0)

        if poster:
            img = f'<img src="{poster}" alt="{safe}" style="width:100%;aspect-ratio:2/3;object-fit:cover;display:block">'
        else:
            initials = "".join(w[0].upper() for w in title.split()[:2])
            img = f'<div class="no-poster">{initials}</div>'

        badge = f'<span class="badge-in">✅ {n} ep{"s" if n!=1 else ""}</span>' if n and mtype=="series" else \
                (f'<span class="badge-in">✅ Cached</span>' if n else \
                 '<span class="badge-grey">⏳ Not cached</span>')

        status_pill = ""
        if mtype == "series":
            col = "#ef4444" if status == "ended" else "#22c55e"
            lbl = "Ended" if status == "ended" else "Continuing"
            status_pill = f'<span style="font-size:0.65rem;color:{col};margin-left:4px">({lbl})</span>'

        sub = f"{sc} season{'s' if sc!=1 else ''}{status_pill}" if mtype=="series" else str(year)

        return (
            f'<div class="card" data-filter-title="{safe.lower()}" style="cursor:pointer" onclick="filterByTitle(this)">' +
            img +
            f'<div class="info"><div class="title" title="{safe}">{title}</div>' +
            f'<div class="meta">{sub}</div></div>' +
            f'<div class="actions">{badge}' +
            f'<button class="btn btn-rem" style="padding:3px 8px;font-size:0.7rem"' +
            f' data-mtype="{mtype}" data-title="{safe}" data-year="{item.get("year") or ""}"' +
            ' onclick="event.stopPropagation();remCard(this)">Remove</button></div></div>'
        )

    lib_section = ""
    if movies_lib:
        lib_section += f'''<div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;flex-wrap:wrap">
          <h2 style="margin:0">🎬 Movies <span id="movie-count" style="color:#555;font-size:0.8rem;font-weight:normal">({len(movies_lib)})</span></h2>
          <input id="movie-search" type="text" placeholder="Search movies…"
                 oninput="filterCards('movie')"
                 style="flex:1;min-width:160px;max-width:280px;background:#1a1a24;border:1px solid #2a2a3a;border-radius:8px;padding:7px 12px;color:#e0e0e0;font-size:0.85rem;outline:none">
          <button class="btn btn-sec" style="padding:6px 12px;font-size:0.8rem" onclick="document.getElementById('movie-search').value='';filterCards('movie')">Clear</button>
        </div>
        <div id="movie-grid" class="card-grid" style="margin-bottom:8px">{"".join(lib_card(i,"movie") for i in movies_lib)}</div>
        <div id="movie-pager" class="pg-bar" style="margin-bottom:32px"></div>'''
    if shows_lib:
        lib_section += f'''<div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;flex-wrap:wrap">
          <h2 style="margin:0">📺 TV Shows <span id="tv-count" style="color:#555;font-size:0.8rem;font-weight:normal">({len(shows_lib)})</span></h2>
          <input id="tv-search" type="text" placeholder="Search TV shows…"
                 oninput="filterCards('tv')"
                 style="flex:1;min-width:160px;max-width:280px;background:#1a1a24;border:1px solid #2a2a3a;border-radius:8px;padding:7px 12px;color:#e0e0e0;font-size:0.85rem;outline:none">
          <button class="btn btn-sec" style="padding:6px 12px;font-size:0.8rem" onclick="document.getElementById('tv-search').value='';filterCards('tv')">Clear</button>
        </div>
        <div id="tv-grid" class="card-grid" style="margin-bottom:8px">{"".join(lib_card(i,"series") for i in shows_lib)}</div>
        <div id="tv-pager" class="pg-bar" style="margin-bottom:32px"></div>'''
    if not lib_section:
        lib_section = f'<div class="empty"><a href="/library" style="color:#f97316">Browse Library</a> to add titles.</div>'

    streams_section = f"""
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
      <h2 style="margin:0">⚡ Resolved Streams <span id="stream-count" style="color:#555;font-size:0.8rem;font-weight:normal">({total}/{total})</span></h2>
      <button class="btn btn-rem" onclick="delAll()" style="padding:6px 14px">🗑️ Delete All Visible</button>
    </div>
    <div class="search-bar" style="margin-bottom:14px">
      <input id="sq" type="text" placeholder="Search streams..." oninput="applyFilters(true)">
      <button class="btn btn-sec" onclick="clearSearch()">Clear</button>
      <select id="status-filter" onchange="applyFilters(true)"
              style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:8px;padding:8px 12px;color:#e0e0e0;font-size:0.85rem;outline:none">
        <option value="all">All statuses</option>
        <option value="cached">Cached</option>
        <option value="not_found">Not found</option>
        <option value="error">Error</option>
      </select>
    </div>
    <div id="streams-table">
      {"<table id='st'><thead><tr><th>Type</th><th>Title</th><th>Ep</th><th>Quality</th><th>Expires</th><th>Status</th><th></th></tr></thead><tbody>"+rows+"</tbody></table>" if rows else '<div class="empty">No streams yet.</div>'}
    </div>"""

    body = lib_section + '<hr style="border:none;border-top:1px solid #2a2a3a;margin:32px 0">' + streams_section

    extra = """<script>
// ── Card pagination/search (movies & TV) ─────────────────────────────────────
const CARDS_PER_PAGE = 12;
const cardState = { movie: { page: 1, q: '' }, tv: { page: 1, q: '' } };

function filterCards(section) {
  const gridId  = section + '-grid';
  const pagerId = section + '-pager';
  const countId = section + '-count';
  const inputId = section + '-search';
  const q = (document.getElementById(inputId)?.value || '').toLowerCase().trim();
  cardState[section].q = q;
  cardState[section].page = 1;
  renderCards(section);
}

function renderCards(section) {
  const gridEl  = document.getElementById(section + '-grid');
  const pagerEl = document.getElementById(section + '-pager');
  const countEl = document.getElementById(section + '-count');
  if (!gridEl) return;

  const q     = cardState[section].q;
  const page  = cardState[section].page;
  const cards = [...gridEl.querySelectorAll('.card')];
  const matched = cards.filter(c => !q || c.dataset.filterTitle.includes(q));
  const total   = matched.length;
  const totalPages = Math.max(1, Math.ceil(total / CARDS_PER_PAGE));
  cardState[section].page = Math.min(page, totalPages);
  const start = (cardState[section].page - 1) * CARDS_PER_PAGE;

  cards.forEach(c => c.style.display = 'none');
  matched.forEach((c, i) => c.style.display = (i >= start && i < start + CARDS_PER_PAGE) ? '' : 'none');

  if (countEl) countEl.textContent = '(' + total + ')';
  if (pagerEl) pagerEl.innerHTML = buildPager(section, cardState[section].page, totalPages);
}

function goCardPage(section, p) {
  cardState[section].page = p;
  renderCards(section);
  document.getElementById(section + '-grid')?.scrollIntoView({behavior:'smooth', block:'start'});
}

function buildPager(section, cur, total) {
  if (total <= 1) return '';
  const btn = (p, label, cls='') =>
    `<span class="pg-btn ${cls}" ${cls.includes('dis') ? '' : `onclick="goCardPage('${section}',${p})"`}>${label}</span>`;
  let pages = [];
  if (total <= 7) { for (let i=1;i<=total;i++) pages.push(i); }
  else {
    pages = [1];
    if (cur > 3) pages.push('…');
    for (let i=Math.max(2,cur-1);i<=Math.min(total-1,cur+1);i++) pages.push(i);
    if (cur < total-2) pages.push('…');
    pages.push(total);
  }
  let html = cur > 1 ? btn(cur-1,'‹') : btn(0,'‹','pg-dis');
  pages.forEach(p => {
    if (p==='…') html += btn(0,'…','pg-dis');
    else html += btn(p, p, p===cur ? 'pg-cur' : '');
  });
  html += cur < total ? btn(cur+1,'›') : btn(0,'›','pg-dis');
  return html;
}

// ── Streams table pagination/search ──────────────────────────────────────────
const STREAMS_PER_PAGE = 10;
let streamPage = 1;

function applyFilters(resetPage) {
  if (resetPage) streamPage = 1;
  const q      = (document.getElementById('sq').value || '').toLowerCase().trim();
  const status = document.getElementById('status-filter').value;
  const rows   = [...document.querySelectorAll('#st tbody tr')];
  const matched = rows.filter(r => {
    const titleMatch  = !q      || r.dataset.title.includes(q);
    const statusMatch = status === 'all' || r.dataset.status === status;
    return titleMatch && statusMatch;
  });
  const totalPages = Math.max(1, Math.ceil(matched.length / STREAMS_PER_PAGE));
  streamPage = Math.min(streamPage, totalPages);
  const start = (streamPage - 1) * STREAMS_PER_PAGE;
  const end   = start + STREAMS_PER_PAGE;

  rows.forEach(r => r.style.display = 'none');
  matched.forEach((r, i) => r.style.display = (i >= start && i < end) ? '' : 'none');

  const el = document.getElementById('stream-count');
  if (el) el.textContent = '(' + matched.length + ' total)';
  renderStreamPager(matched.length, totalPages);
}

function renderStreamPager(total, totalPages) {
  let el = document.getElementById('stream-pager');
  if (!el) {
    el = document.createElement('div');
    el.id = 'stream-pager';
    el.className = 'pg-bar';
    const tbl = document.getElementById('streams-table');
    if (tbl) tbl.after(el);
  }
  if (totalPages <= 1) { el.innerHTML = ''; return; }

  let html = '';
  const prev = streamPage > 1;
  const next = streamPage < totalPages;
  html += prev ? '<span class="pg-btn" onclick="goStreamPage('+( streamPage-1)+')">‹</span>'
               : '<span class="pg-btn pg-dis">‹</span>';

  let pages = [];
  if (totalPages <= 7) { for (let i=1;i<=totalPages;i++) pages.push(i); }
  else {
    pages = [1];
    if (streamPage > 3) pages.push('…');
    for (let i=Math.max(2,streamPage-1);i<=Math.min(totalPages-1,streamPage+1);i++) pages.push(i);
    if (streamPage < totalPages-2) pages.push('…');
    pages.push(totalPages);
  }
  pages.forEach(p => {
    if (p === '…') html += '<span class="pg-btn pg-dis">…</span>';
    else if (p === streamPage) html += '<span class="pg-btn pg-cur">'+p+'</span>';
    else html += '<span class="pg-btn" onclick="goStreamPage('+p+')">'+p+'</span>';
  });

  html += next ? '<span class="pg-btn" onclick="goStreamPage('+(streamPage+1)+')">›</span>'
               : '<span class="pg-btn pg-dis">›</span>';
  el.innerHTML = html;
}

function goStreamPage(p) { streamPage = p; applyFilters(false); window.scrollTo({top:document.getElementById('st')?.offsetTop||0,behavior:'smooth'}); }

function clearSearch() {
  document.getElementById('sq').value = '';
  document.getElementById('status-filter').value = 'all';
  applyFilters(true);
}

function filterByTitle(card) {
  const t = card.dataset.filterTitle || '';
  document.getElementById('sq').value = t;
  document.getElementById('status-filter').value = 'all';
  applyFilters();
  document.getElementById('st')?.scrollIntoView({behavior:'smooth', block:'start'});
}

async function expireNow(btn) {
  const k = btn.dataset.key;
  if (!confirm('Hard reset this cached stream? Symlink deleted, placeholder restored, removed from AllDebrid. Re-caches on next play.')) return;
  const r = await fetch('/cache/'+k+'/expire', {method:'POST'});
  if (r.ok) {
    const row = btn.closest('tr');
    if (row) {
      const pill = row.querySelector('.pill');
      if (pill) { pill.textContent = 'not_found'; pill.className = 'pill pill-nf'; }
      row.dataset.status = 'not_found';
    }
    toast('⏰ Reset — will re-cache on play');
    applyFilters();
  } else {
    toast('❌ Error', false);
  }
}

async function del_(btn) {
  const k = btn.dataset.key;
  const r = await fetch('/cache/'+k, {method:'DELETE'});
  if (r.ok) {
    const row = btn.closest('tr');
    if (row) row.remove();
    toast('🗑️ Deleted');
    applyFilters();
  } else {
    toast('❌ Error', false);
  }
}

async function delAll() {
  const rows = [...document.querySelectorAll('#st tbody tr')].filter(r => r.style.display !== 'none');
  if (!confirm('Delete ' + rows.length + ' visible streams?')) return;
  for (const row of rows) {
    const btn = row.querySelector('[data-key]');
    if (btn) {
      await fetch('/cache/'+btn.dataset.key, {method:'DELETE'});
      row.remove();
    }
  }
  toast('🗑️ All deleted');
  applyFilters();
}

async function remCard(btn) {
  const type  = btn.dataset.mtype;
  const title = btn.dataset.title.replace(/&#39;/g,"'").replace(/&quot;/g,'"');
  const year  = btn.dataset.year ? parseInt(btn.dataset.year) : null;
  if (!confirm('Remove "'+title+'" from library?')) return;
  const r = await fetch('/api/library/remove',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({media_type:type,title,year})});
  if (r.ok) {
    const card = btn.closest('.card');
    if (card) card.remove();
    document.querySelectorAll('#st tbody tr').forEach(row => {
      if (row.dataset.title === title.toLowerCase()) row.remove();
    });
    toast('🗑️ Removed');
    applyFilters();
  } else {
    toast('❌ Error', false);
  }
}

// Init on load
document.addEventListener('DOMContentLoaded', () => {
  renderCards('movie');
  renderCards('tv');
  applyFilters(true);
});
</script>"""
    return _page("Streams", "streams", body, extra)


# ── /settings ────────────────────────────────────────────────────────────────
@app.get("/settings", response_class=HTMLResponse)
async def settings_page(request: Request):
    if _needs_setup(request): return _setup_redirect()
    db: CacheDB = request.app.state.db
    ss  = db.get_all_settings()   # single source of truth — everything comes from here

    saved_msg = request.query_params.get("saved", "")

    def sv(key, default=""):
        """Get a setting value from DB."""
        return ss.get(key) or default

    def field(label, key, hint="", typ="text", placeholder="", masked_if_saved=False):
        val  = sv(key)
        mask = masked_if_saved and bool(val)
        ph   = "••••••• (saved — leave blank to keep)" if mask else (placeholder or "")
        attr = ' data-saved="true"' if mask else ""
        return f"""<div class="field">
          <label>{label}{'<span class="saved-badge">saved</span>' if mask else ""}</label>
          <input id="{key}" name="{key}" type="{'password' if mask else typ}"
                 value="{'  ' if mask else val}" placeholder="{ph}" autocomplete="off"{attr}>
          {'<div class="hint">'+hint+'</div>' if hint else ''}
        </div>"""

    def toggle(label, key, hint="", onchange=""):
        checked = 'checked' if ss.get(key, "false") == "true" else ""
        oc = f' onchange="{onchange}"' if onchange else ""
        return f"""<div style="display:flex;align-items:center;justify-content:space-between;gap:20px;margin-bottom:14px">
          <div>
            <div style="font-size:0.875rem;font-weight:600;margin-bottom:4px">{label}</div>
            {'<div style="font-size:0.75rem;color:#555">'+hint+'</div>' if hint else ''}
          </div>
          <label class="toggle">
            <input type="checkbox" name="{key}" value="true" {checked}{oc}>
            <span class="slider"></span>
          </label>
        </div>"""

    def select(label, key, options, hint=""):
        """options = list of (value, label)"""
        cur = ss.get(key, options[0][0])
        opts = "".join(
            f'<option value="{v}"{"selected" if v==cur else ""}>{lbl}</option>'
            for v, lbl in options
        )
        return f"""<div class="field"><label>{label}</label>
          <select name="{key}">{opts}</select>
          {'<div class="hint">'+hint+'</div>' if hint else ''}
        </div>"""

    debridarr_url = (sv("DEBRIDARR_BASE_URL") or "http://debridarr:7474").rstrip("/")
    tautulli_url  = f"{debridarr_url}/webhook/tautulli"
    tautulli_json = '{"media_type":"{media_type}","title":"{title}","grandparent_title":"{grandparent_title}","year":"{year}","grandparent_year":"{grandparent_year}","parent_media_index":"{parent_media_index}","media_index":"{media_index}","rating_key":"{rating_key}","themoviedb_id":"{themoviedb_id}","thetvdb_id":"{thetvdb_id}","imdb_id":"{imdb_id}"}'

    saved_banner = f'<div class="test-result ok" style="margin-bottom:16px">✅ {saved_msg}</div>' if saved_msg else ""

    body = f"""
    <div style="max-width:720px">
      <h2 style="margin-bottom:4px">⚙️ Settings</h2>
      <p style="color:#555;font-size:0.85rem;margin-bottom:20px">All settings are saved immediately when you click Save.</p>
      {saved_banner}

      <form method="POST" action="/settings/save">

      <div class="s-sect">
        <div class="s-title">AllDebrid</div>
        {field("API Key","ALLDEBRID_API_KEY","alldebrid.com/apikeys","text","",masked_if_saved=True)}
      </div>

      <div class="s-sect">
        <div class="s-title">Prowlarr</div>
        {field("URL","PROWLARR_URL","http://prowlarr:9696 — aggregate Torznab source for hash index","text","http://prowlarr:9696")}
        {field("API Key","PROWLARR_API_KEY","Prowlarr → Settings → General → API Key","text","",masked_if_saved=True)}
        <div style="display:flex;gap:10px;align-items:center;margin-top:4px">
          <button type="button" class="btn btn-sec" style="padding:6px 14px" onclick="testProwlarr()">Test Connection</button>
          <div id="prowlarr-result" class="test-result" style="margin-top:0;flex:1"></div>
        </div>
      </div>

      <div class="s-sect">
        <div class="s-title">Overseerr</div>
        {field("URL","OVERSEERR_URL","http://overseerr:5055")}
        {field("API Key","OVERSEERR_API_KEY","Overseerr → Settings → General → API Key","text","",masked_if_saved=True)}
      </div>

      <div class="s-sect">
        <div class="s-title">Sonarr</div>
        {field("URL","SONARR_URL","http://sonarr:8989")}
        {field("API Key","SONARR_API_KEY","Sonarr → Settings → General → API Key","text","",masked_if_saved=True)}
      </div>

      <div class="s-sect">
        <div class="s-title">Radarr</div>
        {field("URL","RADARR_URL","http://radarr:7878")}
        {field("API Key","RADARR_API_KEY","Radarr → Settings → General → API Key","text","",masked_if_saved=True)}
      </div>

      <div class="s-sect">
        <div class="s-title">TMDB</div>
        {field("API Key","TMDB_API_KEY","themoviedb.org/settings/api — used for posters","text","",masked_if_saved=True)}
      </div>

      <div class="s-sect">
        <div class="s-title">Plex</div>
        {field("Debridarr Base URL","DEBRIDARR_BASE_URL","URL Plex uses to reach Debridarr","text","http://192.168.1.x:7474")}
        {field("Plex Library Path","PLEX_ROOT","Path inside container where files are written","text","/plex-strm")}
      </div>

      <div class="s-sect">
        <div class="s-title">Library</div>
        {toggle("Include unreleased episodes","include_unreleased_episodes","Create placeholders for episodes not yet aired")}
        {toggle("Include unreleased movies","include_unreleased_movies","Add movies to library before their release date")}
      </div>

      <div class="s-sect">
        <div class="s-title">🤖 Overseerr Automation</div>
        {toggle("Auto-add approved requests","auto_add_requests","Automatically add Overseerr approved requests to Debridarr library")}
        <div class="field" style="max-width:220px">
          <label>Check interval (minutes)</label>
          <input name="auto_add_interval_minutes" type="number" min="5" max="1440"
                 value="{ss.get('auto_add_interval_minutes','60')}">
          <div class="hint">How often to poll Overseerr for new requests</div>
        </div>
        <div style="display:flex;gap:10px;align-items:center;margin-top:4px">
          <button type="button" class="btn btn-sec" onclick="runAutoAdd()" style="padding:6px 14px">▶ Run Now</button>
          <div id="auto-add-result" class="test-result" style="margin-top:0;flex:1"></div>
        </div>
      </div>

      <div class="s-sect">
        <div class="s-title">📡 Tautulli Webhook</div>
        <p style="font-size:0.82rem;color:#888;margin-bottom:12px">Triggers a search when you press play (required when pre-caching is off).</p>
        <div class="field">
          <label>1. Tautulli → Settings → Notification Agents → Add → Webhook — set URL to:</label>
          <div style="display:flex;gap:8px;align-items:center;margin-top:6px">
            <input id="twh-url" readonly value="{tautulli_url}"
                   style="flex:1;font-family:monospace;font-size:0.8rem;background:#0f0f13;border:1px solid #2a2a3a;border-radius:6px;padding:8px 10px;color:#e0e0e0">
            <button type="button" class="btn btn-sec" style="padding:6px 14px;white-space:nowrap"
                    onclick="navigator.clipboard.writeText(document.getElementById('twh-url').value);toast('✅ Copied')">Copy</button>
          </div>
        </div>
        <div class="field" style="margin-top:10px">
          <label>2. Set Method = POST, paste this as the JSON body under Triggers → Play:</label>
          <pre id="twh-json" style="background:#0f0f13;border:1px solid #2a2a3a;border-radius:6px;padding:10px;font-size:0.74rem;color:#a0a0b0;margin-top:6px;white-space:pre-wrap;word-break:break-all">{tautulli_json}</pre>
          <button type="button" class="btn btn-sec" style="padding:6px 14px;margin-top:6px"
                  onclick="navigator.clipboard.writeText(document.getElementById('twh-json').innerText);toast('✅ Copied')">Copy JSON</button>
        </div>
        <div style="display:flex;gap:8px;margin-top:10px">
          <button type="button" class="btn btn-sec" style="padding:6px 14px" onclick="testWebhook()">Test Webhook</button>
          <div id="webhook-result" class="test-result" style="margin-top:0;flex:1"></div>
        </div>
      </div>

      <div class="s-sect">
        <div class="s-title">🔍 Torrent Search</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px">
          {select("Completed Series Strategy","series_completed_strategy",[("series_pack","Series Pack (whole show)"),("season_pack","Season Pack"),("episode","Per Episode")])}
          {select("Ongoing Series Strategy","series_ongoing_strategy",[("season_pack","Season Pack"),("episode","Per Episode"),("series_pack","Series Pack")])}
          {select("Series Quality","series_preferred_quality",[("1080p","1080p"),("720p","720p"),("any","Any")])}
          {select("Series Fallback Quality","series_fallback_any_quality",[("true","Yes — any quality"),("false","No")])}
          {select("Movie Quality","movie_preferred_quality",[("1080p","1080p"),("720p","720p"),("any","Any")])}
          {select("Movie Fallback Quality","movie_fallback_any_quality",[("true","Yes — any quality"),("false","No")])}
          <div class="field"><label>Pre-cache Cooldown (min)</label>
            <input name="precache_cooldown_minutes" type="number" min="0" max="60"
                   value="{ss.get('precache_cooldown_minutes','1')}"></div>
          <div class="field"><label>Cache TTL (days)</label>
            <input name="cache_ttl_days" type="number" min="1" max="90"
                   value="{ss.get('cache_ttl_days','30')}"></div>
          <div class="field"><label>Hash Index TTL (months)</label>
            <input name="hash_index_ttl_months" type="number" min="1" max="120"
                   value="{ss.get('hash_index_ttl_months','6')}">
            <div class="hint">Remove hash entries not used for playback in this many months. Runs daily.</div>
          </div>
        </div>
        {toggle("Pre-cache on add","precache_enabled","Search TPB and probe AllDebrid for cached hashes when media is added to the library. Hashes are stored locally — no AllDebrid account changes until you press play. When off, the hash index is only populated as you play things (first play of each item will always do a live search).")}

        <div style="margin-top:16px;padding-top:14px;border-top:1px solid #1e1e2e">
          <div style="font-size:0.8rem;color:#888;font-weight:600;margin-bottom:10px">Hash Index</div>
          <div id="hi-stats" style="font-size:0.78rem;color:#555;margin-bottom:10px">Loading…</div>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <button type="button" class="btn btn-sec" style="padding:6px 14px;font-size:0.82rem"
                    onclick="reindexHashes()">🔄 Re-index All</button>
            <button type="button" class="btn btn-sec" style="padding:6px 14px;font-size:0.82rem"
                    onclick="purgeHashes()">🧹 Purge Unused</button>
            <button type="button" class="btn btn-rem" style="padding:6px 14px;font-size:0.82rem"
                    onclick="clearHashes()">🗑️ Clear Index</button>
            <a href="/hash-index/log" class="btn btn-sec"
               style="padding:6px 14px;font-size:0.82rem;text-decoration:none">📋 View Log</a>
          </div>
          <div id="hi-result" class="test-result" style="margin-top:10px"></div>
        </div>
      </div>

      <div class="s-sect">
        <div class="s-title">System</div>
        {field("TZ","TZ","Timezone e.g. America/New_York")}
        {field("PUID","PUID","User ID for file permissions")}
        {field("PGID","PGID","Group ID for file permissions")}
      </div>

      <div style="display:flex;gap:12px;align-items:center;margin-top:8px">
        <button type="submit" class="btn btn-add" style="padding:10px 28px;font-size:0.9rem">💾 Save All Settings</button>
        <div id="save-result" class="test-result" style="margin-top:0;flex:1"></div>
      </div>

      </form>
    </div>"""

    extra = f"""<style>
.s-sect {{ background:#1a1a24;border:1px solid #2a2a3a;border-radius:10px;padding:20px 24px;margin-bottom:16px; }}
.s-title {{ font-size:0.75rem;font-weight:700;text-transform:uppercase;color:#f97316;letter-spacing:.08em;margin-bottom:16px; }}
.field {{ margin-bottom:14px; }}
.field label {{ display:block;font-size:0.8rem;color:#888;margin-bottom:5px;font-weight:600; }}
.field input,.field select {{ width:100%;background:#0f0f13;border:1px solid #2a2a3a;border-radius:7px;
  padding:9px 13px;color:#e0e0e0;font-size:0.875rem;outline:none;font-family:monospace; }}
.field input:focus,.field select:focus {{ border-color:#f97316; }}
.field select {{ cursor:pointer;font-family:inherit; }}
.field .hint {{ font-size:0.74rem;color:#555;margin-top:4px;line-height:1.4; }}
.field .hint a {{ color:#f97316; }}
.saved-badge {{ display:inline-block;margin-left:8px;font-size:0.68rem;font-weight:700;
  background:#14532d;color:#4ade80;border-radius:4px;padding:1px 6px;text-transform:uppercase; }}
.test-result {{ margin-top:10px;padding:8px 12px;border-radius:6px;font-size:0.82rem;display:none; }}
.test-result.ok {{ background:#14532d;color:#4ade80;display:block; }}
.test-result.err {{ background:#3b0000;color:#f87171;display:block; }}
.test-result.testing {{ background:#1e1e2e;color:#aaa;display:block; }}
.toggle {{ position:relative;display:inline-block;width:44px;height:24px;flex-shrink:0; }}
.toggle input {{ position:absolute;opacity:0;width:100%;height:100%;margin:0;cursor:pointer;z-index:1; }}
.slider {{ position:absolute;inset:0;background:#2a2a3a;border-radius:24px;transition:.2s;pointer-events:none; }}
.slider:before {{ position:absolute;content:"";height:18px;width:18px;left:3px;bottom:3px;
  background:#555;border-radius:50%;transition:.2s; }}
.toggle input:checked ~ .slider {{ background:#f97316; }}
.toggle input:checked ~ .slider:before {{ transform:translateX(20px);background:#fff; }}
pre {{ font-family:monospace;overflow-x:auto; }}
</style>
<script>
function getFieldVal(id) {{
  const e=document.getElementById(id);
  if(!e) return null;
  const v=e.value.trim();
  if(!v || e.dataset.saved) return null;
  return v;
}}
async function testConn(type) {{
  const urlEl=document.getElementById('OVERSEERR_URL');
  const keyEl=document.getElementById('OVERSEERR_API_KEY');
  const adEl =document.getElementById('ALLDEBRID_API_KEY');
  const plEl =document.getElementById('PLEX_ROOT');
  const params=new URLSearchParams({{
    type,
    overseerr_url:  urlEl?.value||'',
    overseerr_key:  keyEl?.value||'',
    alldebrid_key:  adEl?.value||'',
    plex_root:      plEl?.value||'',
  }});
  const el=document.getElementById('test-'+type);
  if(el){{ el.className='test-result testing'; el.style.display='block'; el.textContent='Testing...'; }}
  const r=await fetch('/api/test-connection?'+params);
  const d=await r.json();
  if(el){{ el.className='test-result '+(d.ok?'ok':'err'); el.textContent=(d.ok?'✅ ':'❌ ')+d.message; }}
}}
async function testAll() {{ await Promise.all(['alldebrid','overseerr','plex'].map(testConn)); }}
async function testProwlarr() {{
  const res = document.getElementById('prowlarr-result');
  res.className = 'test-result testing'; res.style.display = 'block'; res.textContent = 'Testing...';
  try {{
    const r = await fetch('/api/test-prowlarr');
    const d = await r.json();
    res.className = 'test-result ' + (d.ok ? 'ok' : 'err');
    if (d.ok) {{
      res.textContent = '✅ ' + d.message + ' — Torznab URL: ' + d.torznab_url;
    }} else {{
      res.textContent = '❌ ' + d.message;
    }}
  }} catch(e) {{
    res.className = 'test-result err';
    res.textContent = '❌ Could not reach Prowlarr';
  }}
}}
async function testWebhook() {{
  const res=document.getElementById('webhook-result');
  res.className='test-result testing'; res.style.display='block'; res.textContent='Testing...';
  try {{
    const r=await fetch('/webhook/test');
    const d=await r.json();
    res.className='test-result '+(r.ok?'ok':'err');
    res.textContent=r.ok?'✅ Reachable — configure Tautulli to POST to this URL':'❌ '+(d.detail||'Unreachable');
  }} catch(e) {{ res.className='test-result err'; res.textContent='❌ Could not reach endpoint'; }}
}}
async function runAutoAdd() {{
  const res=document.getElementById('auto-add-result');
  res.className='test-result testing'; res.style.display='block'; res.textContent='Running...';
  const r=await fetch('/api/auto-add/run',{{method:'POST'}});
  const d=await r.json();
  res.className='test-result '+(r.ok?'ok':'err');
  res.textContent=r.ok?'✅ '+d.message:'❌ '+(d.detail||'Failed');
}}

// ── Hash index controls ─────────────────────────────────────────────────────
async function loadHiStats() {{
  try {{
    const r = await fetch('/api/hash-index/stats');
    const d = await r.json();
    const s = d.stats || {{}};
    document.getElementById('hi-stats').textContent =
      `${{s.total||0}} entries (${{s.cached||0}} cached · ${{s.movies||0}} movies · ${{s.seasons||0}} season packs · ${{s.episodes||0}} episodes)`;
  }} catch(e) {{
    document.getElementById('hi-stats').textContent = '(stats unavailable)';
  }}
}}

async function _hiAction(url, method, confirmMsg, successFn) {{
  const res = document.getElementById('hi-result');
  if (confirmMsg && !confirm(confirmMsg)) return;
  res.className = 'test-result testing'; res.style.display = 'block'; res.textContent = 'Working…';
  try {{
    const r = await fetch(url, {{method}});
    const d = await r.json();
    if (r.ok) {{
      res.className = 'test-result ok';
      res.textContent = successFn(d);
      await loadHiStats();
    }} else {{
      res.className = 'test-result err';
      res.textContent = '❌ ' + (d.detail || 'Error');
    }}
  }} catch(e) {{
    res.className = 'test-result err';
    res.textContent = '❌ ' + e;
  }}
}}

function reindexHashes() {{
  _hiAction('/api/hash-index/reindex', 'POST', null,
    d => '✅ Re-index started — check Hash Log for progress');
}}

function purgeHashes() {{
  const months = document.querySelector('input[name="hash_index_ttl_months"]')?.value || 6;
  _hiAction(`/api/hash-index/purge?months=${{months}}`, 'POST', null,
    d => `✅ Purged ${{d.deleted}} unused entr${{d.deleted===1?'y':'ies'}} (${{d.remaining}} remaining)`);
}}

function clearHashes() {{
  _hiAction('/api/hash-index/clear', 'POST',
    'Clear the entire hash index? It rebuilds automatically as you play media or via Re-index.',
    d => `✅ Cleared — ${{d.deleted}} entr${{d.deleted===1?'y':'ies'}} removed`);
}}

loadHiStats();
</script>"""
    return _page("Settings", "settings", body, extra)


@app.post("/settings/save")
async def settings_save(request: Request, background_tasks: BackgroundTasks):
    """
    Single unified settings save. Everything goes to app_settings in SQLite.
    No .env involvement — DB is the single source of truth for all settings.
    After saving, 303 redirect forces a fresh page render from the DB.
    """
    form = await request.form()
    db: CacheDB = request.app.state.db

    # ── All text/number/select fields ────────────────────────────────────────
    text_keys = {
        # Search settings
        "series_completed_strategy", "series_ongoing_strategy",
        "series_preferred_quality", "series_fallback_any_quality",
        "movie_preferred_quality", "movie_fallback_any_quality",
        "cache_ttl_days", "precache_cooldown_minutes", "hash_index_ttl_months",
        "auto_add_interval_minutes", "tmdb_api_key",
        # Connection settings
        "ALLDEBRID_API_KEY", "OVERSEERR_URL", "OVERSEERR_API_KEY",
        "PROWLARR_URL", "PROWLARR_API_KEY",
        "SONARR_URL", "SONARR_API_KEY", "RADARR_URL", "RADARR_API_KEY",
        "DEBRIDARR_BASE_URL", "PLEX_ROOT", "TZ", "PUID", "PGID",
    }
    for key in text_keys:
        val = form.get(key, "").strip()
        if val:  # only overwrite if a value was actually submitted
            db.set_setting(key, val)

    # ── Checkboxes (absent from form = false) ────────────────────────────────
    for key in ("precache_enabled", "auto_add_requests", "include_unreleased_episodes", "include_unreleased_movies"):
        db.set_setting(key, "true" if form.get(key) else "false")

    # ── Side effects ─────────────────────────────────────────────────────────
    if request.app.state.library:
        tmdb = db.get_setting("tmdb_api_key", "")
        request.app.state.library.tmdb_key = tmdb
        request.app.state.library.invalidate_cache()

    include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"
    background_tasks.add_task(_sync_all_series_episodes, request.app, include_unreleased)

    # Re-init clients so new API keys / URLs take effect immediately
    _init_clients(request.app)

    from fastapi.responses import RedirectResponse
    return RedirectResponse(url="/settings?saved=Settings+saved", status_code=303)


# ── Legacy JSON API endpoints (kept for backwards compat) ────────────────────












@app.get("/api/settings/dfs")
async def api_settings_dfs_get():
    return get_dfs_settings()


@app.post("/api/settings/dfs")
async def api_settings_dfs_save(request: Request):
    body = await request.json()
    allowed = {"cache_dir","disk_cache_size_gb","cache_expiry_h","chunk_size_mb","read_ahead_mb","cleanup_interval_m"}
    cfg = {k: v for k, v in body.items() if k in allowed}
    for k in ("disk_cache_size_gb","cache_expiry_h","chunk_size_mb","read_ahead_mb","cleanup_interval_m"):
        if k in cfg:
            try: cfg[k] = int(cfg[k])
            except Exception: pass
    update_dfs_settings(cfg)
    db: CacheDB = request.app.state.db
    import json
    db.set_setting("dfs_settings", json.dumps(cfg))
    return {"status": "ok", "settings": get_dfs_settings()}



@app.post("/api/auto-add/run")
async def api_auto_add_run(request: Request, background_tasks: BackgroundTasks):
    """Manually trigger an auto-add pass."""
    db: CacheDB = request.app.state.db
    if not getattr(request.app.state, "setup_complete", False):
        raise HTTPException(400, "Setup not complete")
    background_tasks.add_task(_run_auto_add, request.app)
    return {"status": "ok", "message": "Auto-add pass triggered — check logs for details"}


@app.post("/api/episodes/sync")
async def api_episodes_sync(request: Request, background_tasks: BackgroundTasks):
    """Manually trigger a new-episode sync for all tracked series."""
    background_tasks.add_task(_sync_new_episodes, request.app)
    return {"status": "ok", "message": "Episode sync triggered — check logs for details"}


@app.post("/api/library/cleanup")
async def api_library_cleanup(request: Request):
    """
    Remove anything in plex-strm that has no matching entry in the library DB.

    Checks:
      - plex-strm/movies/<folder>  → delete if title/year not in fake_library
      - plex-strm/tv/<folder>      → delete if title not in fake_library
      - Individual episode files   → delete if SxxExx not in any tracked season for that show

    Returns counts of what was removed.
    """
    db: CacheDB        = app.state.db
    lm: LibraryManager = app.state.library
    s                  = app.state.settings

    plex_root = s.PLEX_ROOT or lm.plex_root if lm else ""
    if not plex_root:
        raise HTTPException(400, "PLEX_ROOT not configured")

    plex = Path(plex_root)
    removed_movies  = []
    removed_series  = []
    removed_files   = []

    # Build lookup sets from DB
    tracked_movies: set[str] = set()   # "Title (Year)" or "Title"
    for entry in db.fake_library_list(media_type="movie"):
        yp = f" ({entry['year']})" if entry.get("year") else ""
        tracked_movies.add(f"{entry['title']}{yp}".lower())

    tracked_series: set[str] = set()   # title (lowered)
    for entry in db.fake_library_list(media_type="series"):
        tracked_series.add(entry["title"].lower())

    # Build set of (title_lower, season, episode) for all tracked cache entries
    tracked_episodes: set[tuple[str, int, int]] = set()
    for entry in db.list_all():
        if entry["media_type"] == "episode" and entry.get("season") and entry.get("episode"):
            tracked_episodes.add((entry["title"].lower(), entry["season"], entry["episode"]))

    # ── Movies ────────────────────────────────────────────────────────────────
    movies_dir = plex / "movies"
    if movies_dir.exists():
        for folder in movies_dir.iterdir():
            if not folder.is_dir():
                continue
            if folder.name.lower() not in tracked_movies:
                import shutil as _shutil
                _shutil.rmtree(folder, ignore_errors=True)
                removed_movies.append(folder.name)
                log.info(f"🧹 Cleanup: removed untracked movie folder: {folder.name}")

    # ── TV series ─────────────────────────────────────────────────────────────
    tv_dir = plex / "tv"
    if tv_dir.exists():
        for show_folder in tv_dir.iterdir():
            if not show_folder.is_dir():
                continue
            title_lower = show_folder.name.lower()

            if title_lower not in tracked_series:
                # Whole series not in library — remove entirely
                import shutil as _shutil
                _shutil.rmtree(show_folder, ignore_errors=True)
                removed_series.append(show_folder.name)
                log.info(f"🧹 Cleanup: removed untracked series folder: {show_folder.name}")
                continue

            # Series is tracked — check individual episode files
            import re as _re
            for season_dir in show_folder.iterdir():
                if not season_dir.is_dir():
                    continue
                for ep_file in season_dir.iterdir():
                    m = _re.search(r"[Ss](\d{1,2})[Ee](\d{1,2})", ep_file.name)
                    if not m:
                        continue
                    sn  = int(m.group(1))
                    epn = int(m.group(2))
                    key = (title_lower, sn, epn)
                    if key not in tracked_episodes:
                        ep_file.unlink(missing_ok=True)
                        removed_files.append(f"{show_folder.name}/Season {sn:02d}/{ep_file.name}")
                        log.info(f"🧹 Cleanup: removed untracked episode file: {ep_file.name}")
                # Remove empty season dirs
                try:
                    if not any(season_dir.iterdir()):
                        season_dir.rmdir()
                except Exception:
                    pass

    total = len(removed_movies) + len(removed_series) + len(removed_files)
    log.info(f"🧹 Cleanup complete: {len(removed_movies)} movies, {len(removed_series)} series, {len(removed_files)} episode files removed")
    return {
        "ok": True,
        "removed_movies":       removed_movies,
        "removed_series":       removed_series,
        "removed_episode_files": removed_files,
        "total_removed":        total,
    }


async def _auto_add_loop(app: FastAPI):
    """Background loop — polls Overseerr and auto-adds approved requests if enabled.
    Also syncs new episodes for all tracked ongoing series on the same schedule."""
    await asyncio.sleep(60)  # wait for startup to settle
    while True:
        db: CacheDB = app.state.db
        try:
            # Always sync new episodes for tracked series, regardless of auto_add setting
            await _sync_new_episodes(app)
        except Exception as e:
            log.error(f"Episode sync loop: {e}")

        if db.get_setting("auto_add_requests", "false") == "true":
            try:
                await _run_auto_add(app)
            except Exception as e:
                log.error(f"Auto-add loop: {e}")

        interval = int(db.get_setting("auto_add_interval_minutes", "60"))
        await asyncio.sleep(max(5, interval) * 60)


async def _sync_new_episodes(app: FastAPI):
    """
    Check every tracked series in the library for newly-aired episodes.

    For each episode that has aired but has no placeholder yet:
      1. Search AllDebrid for a cached torrent
      2. Only create a placeholder + trigger resolve if a torrent is actually available
      3. Episodes with no cached torrent are skipped silently — checked again next interval

    This means placeholders only appear in Plex when there is something to stream.
    """
    db: CacheDB         = app.state.db
    lm: LibraryManager  = app.state.library
    alldebrid           = app.state.alldebrid
    if not lm or not lm.plex_root or not alldebrid:
        return

    include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"
    s_cfg              = db.get_all_settings()
    preferred_quality  = s_cfg.get("series_preferred_quality", "1080p")
    fallback_any       = s_cfg.get("series_fallback_any_quality", "true") == "true"

    series_list = db.fake_library_list(media_type="series")
    if not series_list:
        return

    log.debug(f"\U0001f4c5 Episode sync: checking {len(series_list)} series for new episodes")
    total_new = 0

    for entry in series_list:
        title    = entry["title"]
        sid      = entry.get("sonarr_id")
        year     = entry.get("year")
        is_ended = (entry.get("status", "continuing") in ("ended", "cancelled", "canceled"))
        strategy = s_cfg.get("series_completed_strategy", "series_pack") if is_ended \
                   else s_cfg.get("series_ongoing_strategy", "season_pack")
        if not sid:
            continue

        try:
            # Invalidate episode cache so air_date data is fresh
            from app.library import _cache as _lib_cache
            for k in [k for k in list(_lib_cache) if f"episodes::{sid}" in k]:
                del _lib_cache[k]

            episodes = await lm.get_episodes(sid, include_unreleased=include_unreleased)
            if not episodes:
                continue

            # Find which SxxExx already exist in plex-strm (placeholder or symlink)
            show_dir = Path(lm.plex_root) / "tv" / title
            existing: set[tuple[int, int]] = set()
            if show_dir.exists():
                for sf in show_dir.iterdir():
                    if not sf.is_dir():
                        continue
                    for f in sf.iterdir():
                        import re as _re
                        m = _re.search(r"[Ss](\d{1,2})[Ee](\d{1,2})", f.name)
                        if m:
                            existing.add((int(m.group(1)), int(m.group(2))))

            # Episodes that have aired but have no file yet
            new_eps = [ep for ep in episodes if (ep["season"], ep["episode"]) not in existing]
            if not new_eps:
                continue

            log.debug(f"\U0001f4c5 {title}: {len(new_eps)} aired episode(s) without placeholder — checking AllDebrid")

            for ep in new_eps:
                sn, epn = ep["season"], ep["episode"]
                try:
                    results = await alldebrid.search_cached(
                        title=title,
                        media_type="episode",
                        year=year,
                        season=sn,
                        episode=epn,
                        strategy=strategy,
                        preferred_quality=preferred_quality,
                        fallback_any=fallback_any,
                    )
                    if not results:
                        log.debug(f"  \u23ed  {title} S{sn:02d}E{epn:02d} — no cached torrent yet")
                        continue

                    # Torrent available — write to hash index before resolve so
                    # resolve_and_cache hits the fast path instead of re-searching
                    _sync_hi: HashIndex = getattr(app.state, "hash_index", None)
                    if _sync_hi:
                        import re as _re_sync
                        for _sr in results[:3]:
                            _hm = _re_sync.search(r"btih:([a-fA-F0-9]{40})", _sr.get("magnet",""), _re_sync.I)
                            if _hm:
                                try:
                                    _is_pack = not _re_sync.search(r"S\d{2}E\d{2}", _sr["name"], _re_sync.I)
                                    _sync_hi.upsert(
                                        media_type="season" if _is_pack else "episode",
                                        title=title, year=year,
                                        season=sn, episode=None if _is_pack else epn,
                                        info_hash=_hm.group(1).lower(),
                                        magnet=_sr["magnet"],
                                        torrent_name=_sr["name"],
                                        quality=_sr.get("quality", "unknown"),
                                        strategy=strategy,
                                        is_cached=True,
                                    )
                                except Exception:
                                    pass

                    # Torrent available — resolve on next play (no placeholder)
                    log.info(f"  \u2705 {title} S{sn:02d}E{epn:02d} — torrent found ({results[0]['name'][:50]}), indexed")
                    total_new += 1

                    from app.models import PlayEvent, MediaType
                    event = PlayEvent(
                        media_type=MediaType.episode,
                        title=title, year=year,
                        season=sn, episode=epn,
                    )
                    asyncio.create_task(resolve_and_cache(app, event))
                    await asyncio.sleep(2)

                except Exception as e:
                    log.error(f"  Episode search {title} S{sn:02d}E{epn:02d}: {e}")

        except Exception as e:
            log.error(f"Episode sync '{title}': {e}")

    if total_new:
        log.info(f"\U0001f4c5 Episode sync: added {total_new} new episode(s) with available torrents")
    else:
        log.debug("\U0001f4c5 Episode sync: no new episodes with available torrents")


async def _run_auto_add(app: FastAPI):
    """
    Fetch all approved Overseerr requests and add any not already in the library.
    Mirrors what the user does by clicking "+ Add" on the library page.
    """
    lm: LibraryManager = app.state.library
    db: CacheDB        = app.state.db

    if not lm or not lm.url or not lm.key:
        log.info("Auto-add: Overseerr not configured — skipping")
        return

    added_entries = {
        (r["media_type"], r["title"].lower())
        for r in db.fake_library_list()
    }

    movies = await lm.get_radarr_movies(force=True)
    series = await lm.get_sonarr_series(force=True)
    tmdb_key = db.get_setting("tmdb_api_key", "")
    include_unreleased        = db.get_setting("include_unreleased_episodes", "false") == "true"
    include_unreleased_movies = db.get_setting("include_unreleased_movies",  "false") == "true"
    added_count = 0

    from datetime import date as _date
    today = _date.today().isoformat()

    for movie in movies:
        key = ("movie", movie["title"].lower())
        if key in added_entries:
            continue
        try:
            title    = movie["title"]
            year     = movie.get("year")
            tmdb_id  = movie.get("tmdb_id")
            imdb_id  = movie.get("imdb_id")
            poster   = movie.get("poster", "")
            overview = movie.get("overview", "")

            # Skip unreleased movies unless setting is on
            release_date = movie.get("release_date", "")
            if not include_unreleased_movies and (not release_date or release_date > today):
                log.debug(f"⏭️  Auto-add skipping unreleased movie: {title!r} (release_date={release_date!r})")
                continue

            if not poster and tmdb_key and tmdb_id:
                poster = await _fetch_tmdb_poster(tmdb_id, title, True, tmdb_key)

            db.fake_library_add({
                "media_type": "movie",
                "title":      title,
                "year":       year,
                "tmdb_id":    tmdb_id,
                "imdb_id":    imdb_id,
                "poster_url": poster,
                "overview":   overview,
                "status":     "movie",
                "fake_path":  None,
            })
            log.info(f"🤖 Auto-added movie: {title} ({year})")
            added_entries.add(key)
            added_count += 1

            _queue_index(app, _precache_movie, app, title, year, tmdb_id, imdb_id)

        except Exception as e:
            log.error(f"Auto-add movie '{movie.get('title')}': {e}")

    for show in series:
        key = ("series", show["title"].lower())
        if key in added_entries:
            continue
        try:
            title             = show["title"]
            year              = show.get("year")
            arr_id            = show.get("id")
            tmdb_id           = show.get("tmdb_id")
            tvdb_id           = show.get("tvdb_id")
            imdb_id           = show.get("imdb_id")
            sc                = show.get("season_count", 0)
            poster            = show.get("poster", "")
            overview          = show.get("overview", "")
            is_ended          = show.get("is_ended", False)
            requested_seasons = show.get("requested_seasons", [])

            if not poster and tmdb_key and tmdb_id:
                poster = await _fetch_tmdb_poster(tmdb_id, title, False, tmdb_key)

            episodes = await lm.get_episodes(
                arr_id,
                include_unreleased=include_unreleased,
                requested_seasons=requested_seasons if requested_seasons else None,
            )
            db.fake_library_add({
                "media_type":   "series",
                "title":        title,
                "year":         year,
                "sonarr_id":    arr_id,
                "tvdb_id":      tvdb_id,
                "tmdb_id":      tmdb_id,
                "imdb_id":      imdb_id,
                "season_count": sc,
                "poster_url":   poster,
                "overview":     overview,
                "status":       "ended" if is_ended else "continuing",
                "fake_path":    None,
            })
            log.info(f"🤖 Auto-added series: {title} ({year}) — indexed, no placeholders")
            added_entries.add(key)
            added_count += 1

            _queue_index(app, _precache_series, app, title, year, episodes)

        except Exception as e:
            log.error(f"Auto-add series '{show.get('title')}': {e}")

    if added_count:
        log.info(f"🤖 Auto-add complete — {added_count} new item(s) added")
    else:
        log.debug("🤖 Auto-add complete — nothing new")


# ── Proxy / webhook / cache ───────────────────────────────────────────────────
@app.get("/webhook/test")
async def webhook_test():
    return {"status": "ok", "message": "Debridarr webhook is reachable"}

@app.get("/proxy/{cache_key}")
async def stream_proxy(cache_key: str, request: Request):
    return await proxy_stream(request, cache_key, request.app.state.db, request.app.state.alldebrid, request.app)

@app.get("/stream/{cache_key}")
async def stream_cached(cache_key: str, request: Request):
    return await stream_direct(request, cache_key, request.app.state.db, request.app.state.alldebrid)

@app.post("/resolve")
async def manual_resolve(request: Request, background_tasks: BackgroundTasks):
    body  = await request.json()
    event = PlayEvent(media_type=MediaType(body["media_type"]), title=body["title"],
                      year=body.get("year"), season=body.get("season"), episode=body.get("episode"))
    background_tasks.add_task(resolve_and_cache, request.app, event)
    s = request.app.state.settings
    return {"status": "resolving", "cache_key": event.cache_key(),
            "proxy_url": f"{s.DEBRIDARR_BASE_URL}/proxy/{event.cache_key()}"}

@app.get("/cache")
async def list_cache(request: Request): return request.app.state.db.list_all()

@app.post("/cache/{cache_key}/expire")
async def expire_cache_entry(cache_key: str, request: Request, background_tasks: BackgroundTasks):
    db        = request.app.state.db
    s         = request.app.state.settings
    alldebrid = request.app.state.alldebrid
    entry     = db.get(cache_key)
    if not entry:
        raise HTTPException(404, "Not found")
    background_tasks.add_task(_hard_expire, entry, db, s, alldebrid)
    return {"status": "ok", "message": "Expiring — symlink deleted, removed from AllDebrid"}


async def _hard_expire(entry: dict, db: "CacheDB", s, alldebrid):
    """
    Full delete for one cache entry:
    1. Delete symlink/placeholder file from plex-strm
    2. Unregister from FUSE
    3. Delete from AllDebrid
    4. Delete from DB cache table
    """
    ck           = entry["cache_key"]
    strm         = entry.get("strm_path")
    torrent_name = entry.get("torrent_name")
    magnet       = entry.get("magnet_link", "")

    # 1. Delete symlink or placeholder file entirely
    if strm:
        p = Path(strm)
        try:
            if p.exists() or p.is_symlink():
                p.unlink(missing_ok=True)
                log.info(f"🗑️  Deleted file: {p}")
        except Exception as e:
            log.debug(f"File delete {p}: {e}")

    # 2. Unregister from FUSE (only if no other cached entry uses this torrent)
    if torrent_name and FUSE_AVAILABLE:
        others = [e for e in db.list_all()
                  if e.get("torrent_name") == torrent_name
                  and e["cache_key"] != ck
                  and e["status"] == "cached"]
        if not others:
            unregister_torrent(torrent_name)

    # 3. Delete from AllDebrid by hash
    if alldebrid and magnet:
        try:
            import httpx as _hx
            m = re.search(r"btih:([a-fA-F0-9]{40})", magnet, re.I)
            if m:
                info_hash = m.group(1).lower()
                r = await _hx.AsyncClient(timeout=10).get(
                    "https://api.alldebrid.com/v4.1/magnet/status",
                    params={"agent": "debridarr", "apikey": alldebrid.api_key, "status": "ready"},
                )
                if r.status_code == 200:
                    magnets = r.json().get("data", {}).get("magnets", {})
                    if isinstance(magnets, dict):
                        magnets = list(magnets.values())
                    for t in magnets:
                        if (t.get("hash") or "").lower() == info_hash:
                            await alldebrid.delete_magnet(str(t["id"]))
                            log.info(f"🗑️  Deleted from AllDebrid: {t['id']} ({ck})")
                            break
        except Exception as e:
            log.debug(f"AllDebrid delete {ck}: {e}")

    # 4. Delete from DB
    db.delete(ck)
    log.info(f"🗑️  Expired and deleted: {ck}")
    log.info(f"🗑️  Hard expired: {ck}")


@app.delete("/cache/{cache_key}")
async def delete_cache_entry(cache_key: str, request: Request, background_tasks: BackgroundTasks):
    db    = request.app.state.db
    s     = request.app.state.settings
    alldebrid = request.app.state.alldebrid
    entry = db.get(cache_key)
    if not entry:
        raise HTTPException(404, "Not found")
    background_tasks.add_task(_hard_expire, entry, db, s, alldebrid)
    return {"status": "deleted"}

@app.get("/api/hash-index/stats")
async def api_hash_index_stats(request: Request):
    """Return stats and recent entries from the torrent hash index."""
    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    if not hi:
        raise HTTPException(503, "Hash index not initialised")
    stats = hi.stats()
    # Enrich stats with last_used info
    from app.cache import CacheDB as _CDB
    db_path = getattr(request.app.state, "db", None)
    ttl_months = 6
    if db_path:
        ttl_months = int(request.app.state.db.get_setting("hash_index_ttl_months", "6"))
    return {"status": "ok", "stats": stats, "ttl_months": ttl_months}


@app.post("/api/hash-index/reindex")
async def api_hash_index_reindex(request: Request, background_tasks: BackgroundTasks):
    """Re-index all library items (re-search AllDebrid for hashes)."""
    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    alldebrid     = request.app.state.alldebrid
    db: CacheDB   = request.app.state.db
    lm            = request.app.state.library
    if not hi or not alldebrid:
        raise HTTPException(503, "Hash index not ready")

    async def _do_reindex():
        movies = db.fake_library_list(media_type="movie")
        series = db.fake_library_list(media_type="series")
        total  = len(movies) + len(series)
        log.info(f"🔄 Hash reindex: {len(movies)} movies, {len(series)} series ({total} total)")
        done = 0
        for m in movies:
            log.info(f"🔄 Re-indexing movie {done+1}/{total}: {m['title']!r}")
            await _index_movie_hashes(request.app, m["title"], m.get("year"))
            done += 1
            await asyncio.sleep(0.5)
        for s in series:
            log.info(f"🔄 Re-indexing series {done+1}/{total}: {s['title']!r}")
            sc       = s.get("season_count", 1) or 1
            is_ended = s.get("status", "") in ("ended", "cancelled", "canceled")
            await _index_series_hashes(request.app, s["title"], s.get("year"), sc, is_ended, [])
            done += 1
            await asyncio.sleep(0.5)
        log.info(f"🔄 Hash reindex complete — {done} items processed")

    background_tasks.add_task(_do_reindex)
    total_items = len(db.fake_library_list())
    return {"status": "ok", "message": f"Re-indexing {total_items} item(s) — check Hash Log for progress"}


@app.post("/api/hash-index/sync-streams")
async def api_hash_index_sync_streams(request: Request):
    """Sync all resolved cache entries into the hash index immediately."""
    result = await _sync_streams_to_index(request.app)
    return {"status": "ok", **result,
            "message": f"Synced {result['synced']} stream(s) to hash index"}


@app.post("/api/hash-index/recheck")
async def api_hash_index_recheck(request: Request, background_tasks: BackgroundTasks):
    """Force a cache-status recheck of stale hashes."""
    hi: HashIndex  = getattr(request.app.state, "hash_index", None)
    alldebrid      = request.app.state.alldebrid
    if not hi or not alldebrid:
        raise HTTPException(503, "Hash index not ready")
    background_tasks.add_task(recheck_stale, hi, alldebrid.api_key, limit=200)
    return {"status": "ok", "message": "Recheck queued"}



@app.get("/api/hash-index/log")
async def api_hash_index_log(request: Request, n: int = 200):
    """Return last n lines of hash_index.log as JSON."""
    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    if not hi:
        raise HTTPException(503, "Hash index not initialised")
    lines = hi.recent_log_lines(n=min(n, 1000))
    return {"lines": lines, "count": len(lines)}


@app.get("/hash-index/log", response_class=HTMLResponse)
async def hash_index_log_page(request: Request, n: int = 200, q: str = ""):
    """Browser-viewable hash index log with live filtering and colour coding."""
    if _needs_setup(request):
        return _setup_redirect()
    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    stats = hi.stats() if hi else {}
    lines = hi.recent_log_lines(n=min(n, 1000)) if hi else []

    if q:
        ql = q.lower()
        lines = [l for l in lines if ql in l.lower()]


    def _colour(line: str) -> str:
        l = line.strip()
        if   "[ADD   ]" in l: cls = "ev-add"
        elif "[UPDATE]" in l: cls = "ev-update"
        elif "[HIT   ]" in l: cls = "ev-hit"
        elif "[MISS  ]" in l: cls = "ev-miss"
        elif "[EVICT ]" in l: cls = "ev-evict"
        elif "[DELETE]" in l: cls = "ev-delete"
        elif "[TOUCH ]" in l: cls = "ev-touch"
        elif l.startswith("  └─"): cls = "ev-detail"
        else: cls = "ev-other"
        return f'<span class="{cls}">{_html.escape(l)}</span>'

    rows_html = "\n".join(
        f'<div class="log-line">{_colour(l)}</div>' for l in lines
    ) or '<div class="ev-other" style="padding:40px;text-align:center">No log entries yet</div>'

    total_str = f"showing {len(lines)}" + (f" matching {q!r}" if q else f" of last {n}")

    def sc(label, value, color="#e0e0e0"):
        return (
            f'<div style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:8px;padding:14px 16px">' 
            f'<div style="font-size:1.4rem;font-weight:700;color:{color}">{value}</div>'
            f'<div style="font-size:0.75rem;color:#555;margin-top:2px">{label}</div></div>'
        )

    size_opts = "".join(
        f'<option value="{v}" {"selected" if v == n else ""}>{v} lines</option>'
        for v in [100, 200, 500, 1000]
    )

    body = f"""
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:10px">
      <h2 style="margin:0">🗄️ Hash Index Log
        <span style="font-size:0.75rem;color:#555;font-weight:normal">({total_str})</span>
      </h2>
      <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
        <div style="display:flex;gap:6px;font-size:0.72rem">
          <span class="ev-add" style="padding:2px 8px;border-radius:4px;background:#0d2e1a">ADD</span>
          <span class="ev-hit" style="padding:2px 8px;border-radius:4px;background:#162a00">HIT</span>
          <span class="ev-miss" style="padding:2px 8px;border-radius:4px;background:#2e1a00">MISS</span>
          <span class="ev-evict" style="padding:2px 8px;border-radius:4px;background:#2e0000">EVICT</span>
          <span class="ev-delete" style="padding:2px 8px;border-radius:4px;background:#2e0000">DELETE</span>
          <span class="ev-update" style="padding:2px 8px;border-radius:4px;background:#001a2e">UPDATE</span>
        </div>
        <form method="get" style="display:flex;gap:6px">
          <input name="q" value="{q}" placeholder="Filter title, hash, torrent…"
                 style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:7px;
                        padding:6px 12px;color:#e0e0e0;font-size:0.82rem;outline:none;width:200px">
          <select name="n" onchange="this.form.submit()"
                  style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:7px;
                         padding:6px 10px;color:#e0e0e0;font-size:0.82rem;cursor:pointer">
            {size_opts}
          </select>
          <button type="submit" class="btn btn-sec" style="padding:6px 12px;font-size:0.82rem">Filter</button>
          <a href="/hash-index/log" class="btn btn-sec"
             style="padding:6px 12px;font-size:0.82rem;text-decoration:none">Reset</a>
        </form>
        <button class="btn btn-sec" style="padding:6px 12px;font-size:0.82rem"
                onclick="location.reload()">🔄 Refresh</button>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:20px">
      {sc("Total hashes", stats.get("total", 0))}
      {sc("Cached on AllDebrid", stats.get("cached", 0), "#4ade80")}
      {sc("Movies", stats.get("movies", 0))}
      {sc("Season packs", stats.get("seasons", 0))}
    </div>

    <div id="log-container"
         style="background:#0a0a0f;border:1px solid #2a2a3a;border-radius:10px;
                padding:14px 16px;font-family:monospace;font-size:0.78rem;
                line-height:1.7;max-height:72vh;overflow-y:auto">
      {rows_html}
    </div>

    <style>
      .log-line  {{ white-space:pre-wrap; word-break:break-all; border-bottom:1px solid #111; }}
      .ev-add    {{ color:#4ade80; }}
      .ev-update {{ color:#60a5fa; }}
      .ev-hit    {{ color:#a3e635; }}
      .ev-miss   {{ color:#fb923c; }}
      .ev-evict  {{ color:#f87171; }}
      .ev-delete {{ color:#f87171; }}
      .ev-touch  {{ color:#444; }}
      .ev-detail {{ color:#666; }}
      .ev-other  {{ color:#555; }}
    </style>"""

    return _page("Hash Index Log", "hashlog", body)


@app.post("/api/hash-index/purge")
async def api_hash_index_purge(request: Request, months: int = 6):
    """Manually trigger a purge of hash entries unused for more than `months` months."""
    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    if not hi:
        raise HTTPException(503, "Hash index not initialised")
    months = max(1, min(months, 120))
    result = hi.purge_unused(months=months)
    return {"status": "ok", "months": months, **result}


@app.post("/api/hash-index/clear")
async def api_hash_index_clear(request: Request):
    """Clear the entire hash index. Re-populated automatically as media is played or re-indexed."""
    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    if not hi:
        raise HTTPException(503, "Hash index not initialised")
    deleted = hi.clear()
    return {"status": "ok", "deleted": deleted}


@app.get("/health")
async def health(): return {"status": "ok", "service": "debridarr", "version": "0.5.0"}


@app.get("/api/debug/settings")
async def debug_settings(request: Request):
    """
    Shows what's actually stored in the DB vs what's in env vars.
    Use this to diagnose settings not persisting after reboot.
    """
    import os
    db: CacheDB = request.app.state.db
    s           = request.app.state.settings
    ss          = db.get_all_settings()

    keys = ["ALLDEBRID_API_KEY","OVERSEERR_URL","OVERSEERR_API_KEY",
            "DEBRIDARR_BASE_URL","PLEX_ROOT","SONARR_URL","RADARR_URL",
            "precache_enabled","series_preferred_quality","cache_ttl_days"]

    from app.config import settings as cfg_settings
    return {
        "db_path":    cfg_settings.DB_PATH,
        "db_exists":  Path(cfg_settings.DB_PATH).exists(),
        "db_size_kb": round(Path(cfg_settings.DB_PATH).stat().st_size / 1024, 1) if Path(cfg_settings.DB_PATH).exists() else 0,
        "settings": {
            k: {
                "db":  ("SET" if ss.get(k) else "empty") if k.endswith("KEY") or k == "ALLDEBRID_API_KEY" else ss.get(k, "(not in db)"),
                "env": ("SET" if os.environ.get(k) else "not set") if k.endswith("KEY") or k == "ALLDEBRID_API_KEY" else os.environ.get(k, "(not in env)"),
                "active": ("SET" if getattr(s, k, None) else "not set") if k.endswith("KEY") or k == "ALLDEBRID_API_KEY" else getattr(s, k, ss.get(k, "(unknown)")),
            }
            for k in keys
        }
    }


@app.post("/api/fuse/ensure-symlinked")
@app.get("/api/fuse/ensure-symlinked")
async def fuse_ensure_symlinked(request: Request):
    """
    Walk every video file in the FUSE mount and make sure it has a
    corresponding symlink in plex-strm. Creates any that are missing.

    For each FUSE file we:
      1. Check if any cached DB entry already has strm_path pointing to it
      2. If not, look the DB entry up by torrent_name match
      3. Call _make_plex_symlink to create the symlink (removes placeholder .mp4)
      4. Update DB strm_path

    Returns a summary of what was already linked, what was fixed, and
    what couldn't be matched to a DB entry (truly orphaned torrents).
    """
    if not FUSE_AVAILABLE:
        return {"ok": False, "error": "FUSE not available", "fixed": 0, "already_linked": 0, "unmatched": []}

    db: CacheDB     = request.app.state.db
    s               = request.app.state.settings
    fuse_root       = s.FUSE_SYMLINK_ROOT
    plex_root       = s.PLEX_ROOT

    if not fuse_root or not plex_root:
        return {"ok": False, "error": "PLEX_ROOT or FUSE_SYMLINK_ROOT not set", "fixed": 0, "already_linked": 0, "unmatched": []}

    from app.fuse_mount import list_torrents, list_files, get_fuse_path

    # Build map: fuse_path_str → db_entry  (for entries that already have a strm_path)
    fuse_to_entry: dict[str, dict] = {}
    # Build map: torrent_name → [db_entry]  (for lookup when fuse_path not yet set)
    torrent_to_entries: dict[str, list] = {}

    for entry in db.list_all():
        if entry["status"] != "cached":
            continue
        strm = entry.get("strm_path") or ""
        if strm and fuse_root in strm:
            # strm_path IS the symlink file in plex-strm; its target is the fuse path
            p = Path(strm)
            if p.is_symlink():
                try:
                    target = str(p.readlink())
                    fuse_to_entry[target] = entry
                except Exception:
                    pass
        # Index by torrent_name for fallback matching
        tname = entry.get("torrent_name", "")
        if tname:
            torrent_to_entries.setdefault(tname, []).append(entry)

    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
    already_linked = 0
    fixed          = 0
    unmatched      = []

    for torrent in list_torrents():
        for filename in list_files(torrent):
            if not any(filename.lower().endswith(e) for e in video_exts):
                continue  # skip subtitles, nfo, etc.

            fuse_path = str(get_fuse_path(torrent, filename, fuse_root))

            # Already has a valid symlink pointing to this file
            if fuse_path in fuse_to_entry:
                p = Path(fuse_to_entry[fuse_path].get("strm_path", ""))
                if p.is_symlink():
                    already_linked += 1
                    continue

            # Find the DB entry for this file
            entry = None

            # 1. Exact torrent_name match
            candidates = torrent_to_entries.get(torrent, [])
            if len(candidates) == 1:
                entry = candidates[0]
            elif len(candidates) > 1:
                # Multiple entries share this torrent (season pack) — match by episode
                import re as _re
                m = _re.search(r"[Ss](\d{1,2})[Ee](\d{1,2})", filename)
                if m:
                    sn, ep = int(m.group(1)), int(m.group(2))
                    entry = next(
                        (e for e in candidates if e.get("season") == sn and e.get("episode") == ep),
                        candidates[0],  # fallback to first
                    )
                else:
                    entry = candidates[0]

            if not entry:
                unmatched.append({"torrent": torrent, "file": filename, "fuse_path": fuse_path})
                continue

            # Create the symlink
            link = _make_plex_symlink(
                entry["cache_key"],
                entry["title"], entry.get("year"),
                entry.get("season"), entry.get("episode"),
                entry["media_type"], plex_root,
                fuse_path, filename,
            )
            if link:
                db.update_cached(
                    entry["cache_key"],
                    entry.get("magnet_link", ""),
                    entry.get("stream_url", ""),
                    torrent,
                    entry.get("quality", "unknown"),
                    str(link),
                )
                log.info(f"🔗 ensure-symlinked: {filename} → {fuse_path}")
                fixed += 1
                # Update our maps so a second file in the same torrent doesn't overwrite
                fuse_to_entry[fuse_path] = entry
            else:
                unmatched.append({"torrent": torrent, "file": filename, "fuse_path": fuse_path, "error": "symlink failed"})

    log.info(f"🔗 ensure-symlinked: {already_linked} already OK, {fixed} fixed, {len(unmatched)} unmatched")
    return {
        "ok": True,
        "already_linked": already_linked,
        "fixed": fixed,
        "unmatched_count": len(unmatched),
        "unmatched": unmatched,
    }


@app.post("/webhook/tautulli")
async def tautulli_webhook(request: Request, background_tasks: BackgroundTasks):
    try:    payload = await request.json()
    except: payload = dict(await request.form())

    log.info(f"📺 Tautulli: {payload}")

    if not payload:
        log.warning(
            "📺 Tautulli webhook received empty payload — "
            "Tautulli is not configured to send parameters. "
            "Go to Settings → Tautulli Webhook and follow the setup instructions."
        )
        return {"status": "ignored", "reason": "empty payload — check Tautulli webhook JSON body configuration"}

    media_type = payload.get("media_type", "")
    title      = payload.get("grandparent_title") or payload.get("title", "")
    year       = payload.get("year") or payload.get("grandparent_year")
    season     = payload.get("parent_media_index")
    episode    = payload.get("media_index")

    if media_type not in ("movie", "episode") or not title:
        log.warning(f"📺 Tautulli webhook ignored — media_type={media_type!r} title={title!r}")
        return {"status": "ignored"}

    event = PlayEvent(
        media_type=MediaType(media_type), title=title,
        year=int(year) if year else None,
        season=int(season) if season else None,
        episode=int(episode) if episode else None,
        rating_key=payload.get("rating_key"),
        tmdb_id=payload.get("themoviedb_id") or payload.get("tmdb_id"),
        tvdb_id=payload.get("thetvdb_id") or payload.get("tvdb_id"),
        imdb_id=payload.get("imdb_id"),
    )
    log.info(f"📺 Resolving: {event.cache_key()} — {title} S{season}E{episode}")
    background_tasks.add_task(resolve_and_cache, request.app, event)
    return {"status": "accepted", "cache_key": event.cache_key()}


# ── Background helpers ────────────────────────────────────────────────────────

async def _index_movie_hashes(app: FastAPI, title: str, year):
    """Background task: search Prowlarr for a movie hash, check AD cache, store it.
    If at least one cached hash is found, write the .mp4 placeholder so Plex
    shows the title as clickable. No placeholder if nothing is cached on AD."""
    alldebrid: AllDebridClient = app.state.alldebrid
    hi: HashIndex = getattr(app.state, "hash_index", None)
    db: CacheDB   = getattr(app.state, "db", None)
    if not hi or not alldebrid or not alldebrid.api_key:
        return
    settings = db.get_all_settings() if db else {}
    try:
        n = await index_movie(
            hi,
            prowlarr_url=settings.get("PROWLARR_URL", ""),
            prowlarr_key=settings.get("PROWLARR_API_KEY", ""),
            api_key=alldebrid.api_key,
            title=title,
            year=year,
            preferred_quality=settings.get("movie_preferred_quality", "1080p"),
        )
        log.info(f"🗄️  HashIndex movie {title!r}: {n} cached hash(es) stored")
        if n > 0:
            # Cached content confirmed — write the .mp4 placeholder so Plex
            # shows this title and the user can press play to trigger resolution
            lm: LibraryManager = getattr(app.state, "library", None)
            log.info(f"🎬 Placeholder check: lm={lm is not None} plex_root={getattr(lm, 'plex_root', 'NO_LM')!r}")
            if lm and lm.plex_root:
                result = lm.create_fake_movie(title, year)
                log.info(f"🎬 Placeholder written for {title!r} → {result} ({n} cached hash(es))")
            elif lm and not lm.plex_root:
                log.warning(f"🎬 Placeholder SKIPPED for {title!r} — plex_root is empty")
            else:
                log.warning(f"🎬 Placeholder SKIPPED for {title!r} — library manager not on app.state")
        else:
            log.info(f"⏭️  No cached hash on AllDebrid for {title!r} — no placeholder created")
    except Exception as e:
        log.error(f"_index_movie_hashes {title!r}: {e}", exc_info=True)


async def _index_series_hashes(app: FastAPI, title: str, year, season_count: int, is_ended: bool, episodes: list):
    """Background task: search Prowlarr for season/series pack hashes, check AD cache, store them.
    After indexing, write .mp4 placeholders only for episodes whose season/series
    has at least one confirmed cached hash on AllDebrid. Episodes with no cached
    torrent get no placeholder — they won't appear in Plex until a hash is found."""
    alldebrid: AllDebridClient = app.state.alldebrid
    hi: HashIndex = getattr(app.state, "hash_index", None)
    db: CacheDB   = getattr(app.state, "db", None)
    if not hi or not alldebrid or not alldebrid.api_key:
        return
    settings = db.get_all_settings() if db else {}
    try:
        counts = await index_series(
            hi,
            prowlarr_url=settings.get("PROWLARR_URL", ""),
            prowlarr_key=settings.get("PROWLARR_API_KEY", ""),
            api_key=alldebrid.api_key,
            title=title,
            year=year,
            season_count=season_count or 1,
            is_ended=is_ended,
            preferred_quality=settings.get("series_preferred_quality", "1080p"),
        )
        log.info(f"🗄️  HashIndex series {title!r}: {counts}")

        total_cached = counts.get("series_packs", 0) + counts.get("season_packs", 0) + counts.get("episodes", 0)
        if total_cached == 0:
            log.info(f"⏭️  No cached hashes on AllDebrid for {title!r} — no placeholders created")
            return

        lm: LibraryManager = getattr(app.state, "library", None)
        if not lm or not lm.plex_root or not episodes:
            return

        # Determine which seasons have a cached hash (series pack covers all)
        has_series_pack = counts.get("series_packs", 0) > 0

        # Build set of seasons with a cached season or series pack
        cached_seasons: set[int] = set()
        if has_series_pack:
            # Series pack covers every season
            cached_seasons = {ep["season"] for ep in episodes}
        else:
            # Check index for each season individually
            for sn in range(1, (season_count or 1) + 1):
                candidates = hi.lookup(title, season=sn, episode=1, cached_only=True)
                if candidates:
                    cached_seasons.add(sn)

        # Write placeholders only for episodes in cached seasons
        eps_to_create = [ep for ep in episodes if ep.get("season") in cached_seasons]
        if eps_to_create:
            paths = lm.create_fake_episodes(title, year, [], eps_to_create)
            log.info(
                f"📺 Placeholders written for {title!r}: "
                f"{len(paths)} episodes across seasons {sorted(cached_seasons)} "
                f"({total_cached} cached hash(es))"
            )
        else:
            log.info(f"⏭️  {title!r}: cached hashes found but no matching episodes — no placeholders")

    except Exception as e:
        log.warning(f"_index_series_hashes {title!r}: {e}")


async def _hash_index_recheck_loop(app: FastAPI):
    """
    Periodic maintenance for the hash index:
      - Every 6 hours: re-verify stale hashes against AllDebrid
      - Every 24 hours: purge entries unused for > 6 months
    """
    await asyncio.sleep(300)  # 5-minute startup delay
    _recheck_count = 0
    while True:
        try:
            alldebrid: AllDebridClient = app.state.alldebrid
            hi: HashIndex = getattr(app.state, "hash_index", None)
            db: CacheDB   = app.state.db

            if hi and alldebrid and alldebrid.api_key:
                result = await recheck_stale(hi, alldebrid.api_key)
                log.info(f"🔄 HashIndex recheck: {result}")

            # Purge unused entries once per day (every 4th 6-hour cycle)
            _recheck_count += 1
            if _recheck_count % 4 == 0 and hi:
                months = int(db.get_setting("hash_index_ttl_months", "6"))
                purge_result = hi.purge_unused(months=months)
                if purge_result["deleted"]:
                    log.info(
                        f"🗄️  HashIndex daily purge: "
                        f"removed {purge_result['deleted']} entries unused >{months}m, "
                        f"{purge_result['remaining']} remaining"
                    )

        except Exception as e:
            log.error(f"hash_index_recheck_loop: {e}")
        await asyncio.sleep(6 * 3600)  # 6 hours


async def _sync_streams_to_index(app: FastAPI) -> dict:
    """
    Sync all resolved cache entries to the hash index.

    Every entry in the cache DB with status=cached already has a confirmed
    magnet + torrent name — write them directly to the hash index without
    going through Prowlarr or AllDebrid again.

    This is the reliable fill path: anything that has ever played gets indexed.
    Called on startup and via the /api/hash-index/sync-streams endpoint.
    """
    hi: HashIndex  = getattr(app.state, "hash_index", None)
    db: CacheDB    = getattr(app.state, "db", None)
    if not hi or not db:
        return {"synced": 0, "skipped": 0}

    entries = [e for e in db.list_all() if e.get("status") == "cached"
               and e.get("magnet_link") and e.get("torrent_name")]

    synced = skipped = 0
    for e in entries:
        title       = e.get("title", "")
        year        = e.get("year")
        media_type  = e.get("media_type", "movie")
        season      = e.get("season")
        episode     = e.get("episode")
        magnet      = e.get("magnet_link", "")
        torrent     = e.get("torrent_name", "")
        quality     = e.get("quality") or "unknown"

        if not title or not magnet:
            skipped += 1
            continue

        # Extract infohash from magnet
        import re as _re
        m = _re.search(r"btih:([a-fA-F0-9]{40})", magnet, _re.I)
        if not m:
            skipped += 1
            continue
        info_hash = m.group(1).lower()

        # Determine media_type for hash index
        if media_type == "movie":
            hi_type = "movie"
        elif season and not episode:
            hi_type = "season"
        elif season and episode:
            hi_type = "episode"
        else:
            hi_type = "series"

        try:
            hi.upsert(
                media_type=hi_type,
                title=title,
                year=year,
                season=season,
                episode=episode,
                info_hash=info_hash,
                magnet=magnet,
                torrent_name=torrent,
                quality=quality,
                strategy="stream_sync",
                is_cached=True,   # confirmed — it played
            )
            synced += 1
        except Exception as e:
            log.warning(f"sync_streams_to_index: {title!r}: {e}")
            skipped += 1

    log.info(f"🔄 Streams→HashIndex sync: {synced} synced, {skipped} skipped")
    return {"synced": synced, "skipped": skipped}


async def _precache_movie(app: FastAPI, title: str, year, tmdb_id, imdb_id):
    """Index the hash for a movie on add — no AllDebrid account changes."""
    log.info(f"🗄️  _precache_movie starting for {title!r} ({year})")
    try:
        await _index_movie_hashes(app, title, year)
        log.info(f"🗄️  _precache_movie done for {title!r}")
    except asyncio.CancelledError:
        log.info(f"🎬 Hash index cancelled for '{title}'")
        raise
    except Exception as e:
        log.error(f"Movie hash index {title!r}: {e}", exc_info=True)
    finally:
        _precache_tasks.pop(title.lower(), None)

async def _precache_series(app: FastAPI, title: str, year, episodes: list):
    """
    Index hashes for all seasons of a series on add — no AllDebrid account changes.

    Previously iterated every episode and called resolve_and_cache() which
    called add_magnet() for each one, permanently filling the AllDebrid
    account with every torrent before the user played anything.

    Now we run index_series() which:
      1. Searches TPB for series/season packs and individual episodes
      2. Probe-uploads hashes to AllDebrid to confirm they are cached
         (upload → read ready flag → delete immediately — no account side-effect)
      3. Stores confirmed hashes in the local SQLite hash index

    add_magnet() is called exactly once per item, only when the user
    presses play, via the hash-index fast path in _resolve_and_cache_inner.
    """
    try:
        db_ref: CacheDB = app.state.db
        lib_entry    = db_ref.fake_library_get("series", title, year) if db_ref else None
        is_ended     = lib_entry.get("status", "continuing") in ("ended", "cancelled", "canceled") if lib_entry else False
        season_count = lib_entry.get("season_count", 1) or 1 if lib_entry else 1
        log.info(f"🗄️  _precache_series starting for {title!r} ({year}) — {len(episodes)} episodes, {season_count} seasons")
        await _index_series_hashes(app, title, year, season_count, is_ended, episodes)
        log.info(f"🗄️  _precache_series done for {title!r}")
    except asyncio.CancelledError:
        log.info(f"📺 Hash index cancelled for '{title}'")
        raise
    except Exception as e:
        log.error(f"Series hash index {title!r}: {e}", exc_info=True)
    finally:
        _precache_tasks.pop(title.lower(), None)
async def _fetch_tmdb_poster(tmdb_id, title: str, is_movie: bool, tmdb_key: str) -> str:
    """Fetch poster URL from TMDB — by ID first, title search fallback."""
    if not tmdb_key: return ""
    import httpx as _hx
    endpoint = "movie" if is_movie else "tv"
    try:
        async with _hx.AsyncClient(timeout=8) as c:
            if tmdb_id:
                r = await c.get(f"https://api.themoviedb.org/3/{endpoint}/{tmdb_id}",
                                params={"api_key": tmdb_key})
                if r.status_code == 200:
                    p = r.json().get("poster_path")
                    if p: return f"https://image.tmdb.org/t/p/w342{p}"
            # Fallback: search by title
            r2 = await c.get(f"https://api.themoviedb.org/3/search/{endpoint}",
                             params={"api_key": tmdb_key, "query": title})
            if r2.status_code == 200:
                results = r2.json().get("results", [])
                if results and results[0].get("poster_path"):
                    return f"https://image.tmdb.org/t/p/w342{results[0]['poster_path']}"
    except Exception:
        pass
    return ""


async def _cleanup_loop(app: FastAPI):
    """
    Hourly cleanup — remove entries whose 30-day TTL has expired.
    Deletes symlink, restores placeholder, removes from AllDebrid, deletes DB entry.
    """
    while True:
        await asyncio.sleep(3600)
        db = app.state.db
        s  = app.state.settings

        for entry in db.list_expired():
            ck = entry["cache_key"]
            log.info(f"⏰ TTL expired: {ck}")
            await _hard_expire(entry, db, s, app.state.alldebrid)

        purged = db.purge_expired()
        if purged:
            log.info(f"⏰ Purged {purged} expired cache entries")


# Torrent sync loop intentionally removed.
# Comparing FUSE names against AllDebrid names is unreliable due to truncation
# and causes false-positive deletions of valid cached files.
# Cache lifecycle is managed by:
#   - TTL expiry (_cleanup_loop) — removes after 30 days
#   - User remove action (api_library_remove) — removes immediately
#   - Symlink health check (_check_and_repair_symlinks) — repairs broken symlinks hourly

async def _episode_sync_loop(app: FastAPI):
    """Run at startup (+30s) and hourly — audit episode placeholders against TMDB."""
    await asyncio.sleep(30)
    while True:
        try:   await _run_episode_sync(app)
        except Exception as e: log.error(f"Episode sync: {e}")
        await asyncio.sleep(3600)


async def _run_episode_sync(app: FastAPI):
    lm  = app.state.library
    db  = app.state.db
    s   = app.state.settings
    if not lm or not s.PLEX_ROOT: return

    lm.invalidate_cache()
    series_list        = await lm.get_sonarr_series(force=True)
    added_series       = [r for r in db.fake_library_list() if r["media_type"] == "series"]
    include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"
    total_added = total_removed = 0

    # ── Audit plex-strm/movies — remove folders not in fake_library ───────────
    added_movies = {r["title"].lower() for r in db.fake_library_list() if r["media_type"] == "movie"}
    movies_root  = Path(s.PLEX_ROOT) / "movies"
    if movies_root.exists():
        for folder in movies_root.iterdir():
            if not folder.is_dir(): continue
            # Extract title from "Title (Year)" folder name
            folder_title = folder.name.rsplit(" (", 1)[0].lower()
            if folder_title not in added_movies:
                import shutil as _shutil
                _shutil.rmtree(folder, ignore_errors=True)
                log.info(f"🗑️  Removed stale movie folder: {folder.name}")

    # ── Audit plex-strm/tv — remove folders not in fake_library ──────────────
    added_tv  = {r["title"].lower() for r in db.fake_library_list() if r["media_type"] == "series"}
    tv_root   = Path(s.PLEX_ROOT) / "tv"
    if tv_root.exists():
        for folder in tv_root.iterdir():
            if not folder.is_dir(): continue
            if folder.name.lower() not in added_tv:
                import shutil as _shutil
                _shutil.rmtree(folder, ignore_errors=True)
                log.info(f"🗑️  Removed stale TV folder: {folder.name}")

    for entry in added_series:
        title     = entry["title"]
        sonarr_id = entry.get("sonarr_id")
        year      = entry.get("year")
        if not sonarr_id: continue

        updated = next((s for s in series_list if s.get("id") == sonarr_id), None)
        if not updated: continue

        requested_seasons = updated.get("requested_seasons", [])
        result = await lm.sync_series_episodes(title, sonarr_id, year, include_unreleased,
                                                requested_seasons=requested_seasons)
        total_added   += result.get("added", 0)
        total_removed += result.get("removed", 0)

        # Audit: ensure every expected episode has placeholder or symlink
        try:
            all_eps = await lm.get_episodes(sonarr_id,
                                                    include_unreleased=include_unreleased,
                                                    requested_seasons=requested_seasons or None)
            by_season: dict[int, set] = {}
            for ep in all_eps:
                by_season.setdefault(ep["season"], set()).add(ep["episode"])

            show_folder = Path(s.PLEX_ROOT) / "tv" / title
            for sn, ep_nums in by_season.items():
                sf = show_folder / f"Season {sn:02d}"
                sf.mkdir(parents=True, exist_ok=True)
                on_mp4 = set(); on_sym = set()
                if sf.exists():
                    for f in sf.iterdir():
                        m = re.search(rf"S{sn:02d}E(\d{{2}})", f.name, re.I)
                        if m:
                            n = int(m.group(1))
                            if f.is_symlink(): on_sym.add(n)
                            elif f.suffix == ".mp4": on_mp4.add(n)
                covered = on_mp4 | on_sym
                for ep_n in on_mp4 - ep_nums:
                    ph = sf / f"{title} - S{sn:02d}E{ep_n:02d}.mp4"
                    if ph.exists() and not ph.is_symlink():
                        ph.unlink(missing_ok=True)
                        total_removed += 1
        except Exception as e:
            log.debug(f"Audit {title}: {e}")

    if total_added or total_removed:
        log.info(f"🔄 Episode sync: +{total_added} placeholders, -{total_removed} removed")
    else:
        log.info("🔄 Episode sync: all correct")


async def _sync_all_series_episodes(app: FastAPI, include_unreleased: bool):
    db = app.state.db; lm = app.state.library
    if not lm: return
    for entry in db.fake_library_list(media_type="series"):
        sid = entry.get("sonarr_id")
        if sid:
            await lm.sync_series_episodes(entry["title"], sid, entry.get("year"), include_unreleased)


async def _load_all_torrents(app: FastAPI):
    await asyncio.sleep(2)
    alldebrid = app.state.alldebrid
    s = app.state.settings
    if not alldebrid or not FUSE_AVAILABLE or not getattr(app.state, "fuse_thread", None):
        return
    try:
        torrents = await alldebrid.get_all_torrents()
        # Build hash → torrent map for reliable lookup on restart
        hash_map: dict[str, dict] = {}  # info_hash → {name, folder, files}
        for t in torrents:
            files       = t["files"]
            folder_name = t["name"]
            if files:
                stem = Path(files[0]["n"]).stem
                if stem and folder_name and stem.startswith(folder_name.rstrip("-")):
                    folder_name = stem
            register_torrent(folder_name, files)
            t["_folder"] = folder_name
            # Store by hash for reliable restart recovery
            h = t.get("hash", "").lower()
            if h:
                hash_map[h] = {"name": t["name"], "folder": folder_name, "files": files}

        log.info(f"✅ {len(torrents)} torrents loaded into FUSE")
        if s.PLEX_ROOT:
            _restore_symlinks(app, hash_map)
    except Exception as e:
        log.error(f"_load_all_torrents: {e}", exc_info=True)


def _restore_symlinks(app, hash_map: dict = None):
    """
    Restore symlinks on startup.
    Uses magnet_link hash to find the exact torrent — no name matching needed.
    Falls back to name-based FUSE search only if hash not available.
    """
    import re as _re
    db = app.state.db
    s  = app.state.settings
    if not s.PLEX_ROOT or not s.FUSE_SYMLINK_ROOT:
        return
    if hash_map is None:
        hash_map = {}

    trusted = restored = missing = 0

    for entry in db.list_all():
        if entry["status"] != "cached":
            continue
        strm = entry.get("strm_path")
        ck   = entry["cache_key"]

        # Step 1: if symlink exists on disk, try to validate/fix its FUSE target
        if strm:
            p = Path(strm)
            if p.is_symlink():
                target = str(p.readlink())
                if s.FUSE_SYMLINK_ROOT in target:
                    rel   = target.replace(s.FUSE_SYMLINK_ROOT, "").lstrip("/")
                    parts = rel.split("/", 1)
                    if len(parts) == 2:
                        folder_name, filename = parts
                        # Check if registered under this exact name
                        if get_torrent_file(folder_name, filename):
                            trusted += 1
                            continue
                        # Not registered — find the torrent by hash from magnet_link
                        magnet = entry.get("magnet_link", "")
                        m = _re.search(r"btih:([a-fA-F0-9]{40})", magnet or "", _re.I)
                        if m:
                            h = m.group(1).lower()
                            if h in hash_map:
                                # Re-register under the current folder name from AllDebrid
                                t = hash_map[h]
                                new_folder = t["folder"]
                                # Find the specific file for this episode
                                target_file = _pick_file(t["files"], entry)
                                if target_file:
                                    new_filename = target_file["n"]
                                    new_target   = get_fuse_path(new_folder, new_filename, s.FUSE_SYMLINK_ROOT)
                                    # Update symlink to point to new path
                                    p.unlink(missing_ok=True)
                                    p.symlink_to(new_target)
                                    db.update_cached(ck, magnet, entry.get("stream_url",""),
                                                     new_folder, entry.get("quality","unknown"), str(p))
                                    trusted += 1
                                    continue
                        # Hash not found — symlink exists but torrent gone from AllDebrid
                        # Keep symlink as-is; health check will handle it
                        trusted += 1
                        continue

        # Step 2: no symlink — find by hash first, then title search
        magnet = entry.get("magnet_link", "")
        m = _re.search(r"btih:([a-fA-F0-9]{40})", magnet or "", _re.I)
        torrent_data = None
        if m:
            h = m.group(1).lower()
            if h in hash_map:
                torrent_data = hash_map[h]

        if torrent_data:
            target_file = _pick_file(torrent_data["files"], entry)
            if target_file:
                folder_name = torrent_data["folder"]
                filename    = target_file["n"]
                fuse_virtual = get_fuse_path(folder_name, filename, s.FUSE_SYMLINK_ROOT)
                link = _make_plex_symlink(ck, entry["title"], entry.get("year"),
                                          entry.get("season"), entry.get("episode"),
                                          entry["media_type"], s.PLEX_ROOT, fuse_virtual, filename)
                if link:
                    db.update_cached(ck, magnet, entry.get("stream_url",""),
                                     folder_name, entry.get("quality","unknown"), str(link))
                    restored += 1
                    continue

        # Step 3: fallback — fuzzy title search in FUSE
        fuse_match = _find_in_fuse(entry["title"], entry.get("year"),
                                    entry.get("season"), entry.get("episode"))
        if not fuse_match:
            missing += 1
            continue

        torrent_name, filename, _ = fuse_match
        fuse_virtual = get_fuse_path(torrent_name, filename, s.FUSE_SYMLINK_ROOT)
        link = _make_plex_symlink(ck, entry["title"], entry.get("year"),
                                   entry.get("season"), entry.get("episode"),
                                   entry["media_type"], s.PLEX_ROOT, fuse_virtual, filename)
        if link:
            db.update_cached(ck, entry.get("magnet_link",""), entry.get("stream_url",""),
                             torrent_name, entry.get("quality","unknown"), str(link))
            restored += 1

    log.info(f"✅ Symlinks: {trusted} trusted, {restored} restored, {missing} not in FUSE")


def _pick_file(files: list, entry: dict) -> Optional[dict]:
    """Pick the right file from a torrent for this DB entry."""
    season  = entry.get("season")
    episode = entry.get("episode")
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}

    if season and episode:
        se = f"S{season:02d}E{episode:02d}".upper()
        for f in files:
            if se in f.get("n", "").upper() and any(f["n"].lower().endswith(e) for e in video_exts):
                return f

    # Fallback: largest video file
    videos = [f for f in files if any(f.get("n","").lower().endswith(e) for e in video_exts)]
    return max(videos, key=lambda f: f.get("s", 0)) if videos else None


async def _symlink_health_loop(app: FastAPI):
    # Wait for FUSE to stabilise
    prev = 0; stable = 0
    for _ in range(180):
        await asyncio.sleep(1)
        count = len(list_torrents())
        if count > 0 and count == prev:
            stable += 1
            if stable >= 5: break
        else: stable = 0
        prev = count

    log.info(f"Starting symlink health check ({prev} torrents in FUSE)")
    while True:
        try:   await _check_and_repair_symlinks(app)
        except Exception as e: log.error(f"Symlink health: {e}")
        await asyncio.sleep(3600)


async def _check_and_repair_symlinks(app: FastAPI):
    db = app.state.db; s = app.state.settings
    if not s.PLEX_ROOT: return

    cached  = [e for e in db.list_all() if e["status"] == "cached"]
    broken  = []; ok = 0

    for entry in cached:
        strm  = entry.get("strm_path")
        issue = None
        try:
            if strm:
                p = Path(strm)
                if not p.is_symlink():
                    issue = "missing"
                else:
                    target = str(p.readlink())
                    if s.FUSE_SYMLINK_ROOT in target:
                        # Symlink points into FUSE — trust it as long as it's a symlink.
                        # FUSE lazy-loads files so .exists() is unreliable.
                        # Only flag broken if the torrent folder is truly gone from FUSE
                        # AND we can't find it via title search either.
                        rel   = target.replace(s.FUSE_SYMLINK_ROOT,"").lstrip("/")
                        parts = rel.split("/", 1)
                        if len(parts) == 2:
                            if get_torrent_file(parts[0], parts[1]):
                                # Registered and found — all good
                                ok += 1
                                db.refresh_ttl(entry["cache_key"])
                            else:
                                # Not found under that key — try fuzzy search
                                m = _find_in_fuse(entry["title"], entry.get("year"),
                                                   entry.get("season"), entry.get("episode"))
                                if m:
                                    # Found under different name — re-point symlink
                                    new_folder, new_file, _ = m
                                    new_target = get_fuse_path(new_folder, new_file, s.FUSE_SYMLINK_ROOT)
                                    p.unlink(missing_ok=True)
                                    p.symlink_to(new_target)
                                    db.update_cached(entry["cache_key"],
                                                     entry.get("magnet_link",""),
                                                     entry.get("stream_url",""),
                                                     new_folder, entry.get("quality","unknown"),
                                                     str(p))
                                    ok += 1
                                    db.refresh_ttl(entry["cache_key"])
                                else:
                                    # Truly not in FUSE — needs re-resolve
                                    issue = "not in FUSE"
                        else:
                            ok += 1
                    else:
                        if p.exists(): ok += 1
                        else:          issue = "dangling"
            else:
                ok += 1  # no strm_path means no symlink expected yet
        except Exception as e:
            log.debug(f"Health check {entry['cache_key']}: {e}")

        if issue: broken.append((entry, issue))

    total = len(cached)
    if not broken:
        log.info(f"✅ Symlink check: {ok}/{total} OK"); return

    log.info(f"🔧 Symlink check: {len(broken)} broken, {ok} OK / {total}")

    # Write placeholders for all broken entries first
    for entry, _ in broken:
        try:
            mtype = entry["media_type"]; t = entry["title"]
            yr = entry.get("year"); sn = entry.get("season"); ep = entry.get("episode")
            if mtype == "movie":
                folder = Path(s.PLEX_ROOT) / "movies" / f"{t}{' ('+str(yr)+')' if yr else ''}"
                ph = folder / f"{t}{' ('+str(yr)+')' if yr else ''}.mp4"
            elif sn and ep:
                folder = Path(s.PLEX_ROOT) / "tv" / t / f"Season {sn:02d}"
                ph = folder / f"{t} - S{sn:02d}E{ep:02d}.mp4"
            else: continue
            folder.mkdir(parents=True, exist_ok=True)
            if not ph.exists() and not ph.is_symlink():
                ph.write_bytes(_FAKE_MP4)
        except Exception: pass

    for entry, issue in broken:
        log.info(f"  🔧 {entry['cache_key']}: {issue}")
        fuse_match = _find_in_fuse(entry["title"], entry.get("year"),
                                    entry.get("season"), entry.get("episode"))
        if fuse_match:
            torrent_name, filename, _ = fuse_match
            fuse_virtual = get_fuse_path(torrent_name, filename, s.FUSE_SYMLINK_ROOT)
            link = _make_plex_symlink(entry["cache_key"], entry["title"], entry.get("year"),
                                      entry.get("season"), entry.get("episode"), entry["media_type"],
                                      s.PLEX_ROOT, fuse_virtual, filename)
            if link:
                db.update_cached(entry["cache_key"], entry.get("magnet_link",""),
                                 entry.get("stream_url",""), torrent_name,
                                 entry.get("quality","unknown"), str(link))
                log.info(f"  ✅ Relinked: {entry['cache_key']}")
                continue

        # Not in FUSE — re-resolve (placeholder already written above)
        event = PlayEvent(media_type=MediaType(entry["media_type"]), title=entry["title"],
                          year=entry.get("year"), season=entry.get("season"), episode=entry.get("episode"))
        try:
            db.update_status(entry["cache_key"], "not_found")
            await resolve_and_cache(app, event)
            await asyncio.sleep(2)
        except Exception as e:
            db.update_status(entry["cache_key"], "cached")
            log.error(f"  ❌ Re-resolve failed: {entry['cache_key']}: {e}")


def _find_in_fuse(title: str, year, season, episode) -> Optional[tuple]:
    def norm(s):
        s = s.lower().replace("'","").replace("\u2019","")
        s = re.sub(r"[._]", " ", s)
        return s.split()

    title_words = norm(title)
    if not title_words: return None
    video_exts = {".mkv",".mp4",".avi",".mov",".m4v"}

    for torrent_name in list_torrents():
        t_words = norm(torrent_name)
        if not all(w in t_words for w in title_words): continue
        if year and str(year) not in torrent_name: continue
        for fname in list_files(torrent_name):
            if not any(fname.lower().endswith(e) for e in video_exts): continue
            if season and episode:
                if f"S{season:02d}E{episode:02d}".upper() not in fname.upper(): continue
            elif season:
                if f"S{season:02d}".upper() not in fname.upper(): continue
            f = get_torrent_file(torrent_name, fname)
            if f: return torrent_name, fname, f
    return None


def _detect_quality(name: str) -> str:
    n = name.lower()
    for q in ("2160p","4k","uhd","1080p","720p","480p"):
        if q in n: return q
    return "unknown"


def _parse_season_episode(filename: str) -> Optional[tuple[int, int]]:
    """Extract (season, episode) from a filename. Returns None if not found."""
    import re as _re
    m = _re.search(r'[Ss](\d{1,2})[Ee](\d{1,2})', filename)
    if m:
        return int(m.group(1)), int(m.group(2))
    return None


def _symlink_pack_episodes(
    app, db, files: list, magnet_str: str, torrent_name: str, quality: str,
    title: str, year, season: int, event_episode: int,
    media_type: str, plex_root: str, debridarr_base_url: str,
    fuse_thread, fuse_symlink_root: str,
    all_seasons: bool = False,
) -> int:
    """
    For every video file in a season/series pack, create a DB cache entry
    and a Plex symlink (or .strm if FUSE is unavailable).
    Skips the episode that was already handled by the main resolve path.

    all_seasons=True  → series pack: symlink every season in the torrent.
    all_seasons=False → season pack: only symlink the requested season.

    Returns the count of additional episodes symlinked.
    """
    import re as _re
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
    count = 0
    for f in files:
        fname = f.get("n", "")
        if not any(fname.lower().endswith(e) for e in video_exts):
            continue
        ep_info = _parse_season_episode(fname)
        if not ep_info:
            continue
        ep_season, ep_episode = ep_info
        if not all_seasons and ep_season != season:
            continue              # season pack — only handle the requested season
        if ep_season == season and ep_episode == event_episode:
            continue              # already handled by main resolve path

        ad_link = f.get("l", "")
        if not ad_link:
            continue

        # Build a PlayEvent for this episode so cache_key is correct
        from app.models import PlayEvent, MediaType
        ep_event = PlayEvent(
            media_type=MediaType.episode,
            title=title, year=year,
            season=ep_season, episode=ep_episode,
        )
        ck = ep_event.cache_key()

        existing = db.get(ck)
        if existing and existing["status"] == "cached":
            log.debug(f"  Pack episode already cached: {ck}")
            continue

        # Write DB entry
        db.upsert(ck, ep_event, status="resolving")

        # Create symlink or strm
        strm_path = None
        if plex_root:
            if FUSE_AVAILABLE and fuse_thread:
                stem = Path(fname).stem
                fuse_folder = stem if (stem and torrent_name and stem.startswith(torrent_name.rstrip("-"))) else torrent_name
                fuse_virtual = get_fuse_path(fuse_folder, fname, fuse_symlink_root)
                link = _make_plex_symlink(ck, title, year, ep_season, ep_episode,
                                          media_type, plex_root, fuse_virtual, fname)
                strm_path = str(link) if link else None
            else:
                p = write_strm(cache_key=ck, title=title, year=year,
                               season=ep_season, episode=ep_episode,
                               media_type=media_type,
                               debridarr_base_url=debridarr_base_url,
                               plex_root=plex_root)
                strm_path = str(p) if p else None

        db.update_cached(ck, magnet_str, ad_link, torrent_name, quality, strm_path)
        log.info(f"  📦 Pack episode: S{ep_season:02d}E{ep_episode:02d} → {fname}")
        count += 1

    return count


def _make_plex_symlink(cache_key, title, year, season, episode,
                       media_type, plex_root, target, video_name) -> Optional[Path]:
    """Placeholder-first symlink creation. Never leaves Plex with an empty slot."""
    if media_type == "movie":
        yp     = f" ({year})" if year else ""
        folder = Path(plex_root) / "movies" / f"{title}{yp}"
        ph     = folder / f"{title}{yp}.mp4"
    else:
        sf     = f"Season {season:02d}" if season else "Season 00"
        folder = Path(plex_root) / "tv" / title / sf
        se     = f"S{season:02d}E{episode:02d}" if (season and episode) else "S00E00"
        ph     = folder / f"{title} - {se}.mp4"

    try:
        folder.mkdir(parents=True, exist_ok=True)
        if not ph.exists() and not ph.is_symlink():
            ph.write_bytes(_FAKE_MP4)
    except Exception as e:
        log.error(f"Placeholder write {cache_key}: {e}")

    try:
        # Remove stale symlinks for this episode
        if media_type == "movie":
            for f in folder.iterdir():
                if f.is_symlink() and f.suffix in (".mkv",".mp4",".avi",".mov",".m4v"):
                    f.unlink(missing_ok=True)
        elif season and episode:
            se_pat = f"S{season:02d}E{episode:02d}".upper()
            for f in folder.iterdir():
                if f.is_symlink() and se_pat in f.name.upper():
                    f.unlink(missing_ok=True)

        link = folder / video_name
        if link.is_symlink() or link.exists(): link.unlink(missing_ok=True)
        link.symlink_to(target)

        if link.is_symlink():
            if ph.exists() and not ph.is_symlink(): ph.unlink(missing_ok=True)
            log.info(f"🔗 Symlink: {link.name} → {target}")
            return link
        else:
            if not ph.exists(): ph.write_bytes(_FAKE_MP4)
            return None
    except Exception as e:
        log.error(f"symlink {cache_key}: {e}")
        try:
            if not ph.exists() and not ph.is_symlink():
                folder.mkdir(parents=True, exist_ok=True)
                ph.write_bytes(_FAKE_MP4)
        except Exception: pass
        return None


async def _verify_episode_with_tmdb(tmdb_id, tvdb_id, season, episode, title, tmdb_key=""):
    if not tmdb_key: return season, episode
    import httpx as _hx
    try:
        if tvdb_id:
            async with _hx.AsyncClient(timeout=10) as c:
                r = await c.get(f"https://api.themoviedb.org/3/find/{tvdb_id}",
                                params={"api_key": tmdb_key, "external_source": "tvdb_id"})
                if r.status_code == 200:
                    eps = r.json().get("tv_episode_results", [])
                    if eps:
                        e   = eps[0]
                        ts  = e.get("season_number", season)
                        tep = e.get("episode_number", episode)
                        if ts != season or tep != episode:
                            log.info(f"TMDB corrected {title} S{season:02d}E{episode:02d} → S{ts:02d}E{tep:02d}")
                        return ts, tep
    except Exception as e:
        log.debug(f"TMDB lookup {title}: {e}")
    return season, episode


async def resolve_and_cache(app: FastAPI, event: PlayEvent):
    db = app.state.db; alldebrid = app.state.alldebrid; s = app.state.settings
    cache_key = event.cache_key()

    existing = db.get(cache_key)
    if existing and existing["status"] == "cached":
        log.info(f"✅ Cache hit: {cache_key}")
        return

    # Register job and acquire worker slot
    ep = f" S{event.season:02d}E{event.episode:02d}" if event.season and event.episode else ""
    jid, cancel_event = _job_start(f"{event.title}{ep}", job_type="resolve")
    sem = _get_semaphore(app)
    try:
        async with sem:
            if cancel_event.is_set():
                _job_done(jid, "cancelled")
                return
            await _resolve_and_cache_inner(app, event, cancel_event)
        _job_done(jid)
    except asyncio.CancelledError:
        _job_done(jid, "cancelled")
        raise
    except Exception as e:
        _job_done(jid, str(e))
        raise


async def _resolve_and_cache_inner(app: FastAPI, event: PlayEvent, cancel_event: asyncio.Event = None):
    db = app.state.db; alldebrid = app.state.alldebrid; s = app.state.settings
    cache_key = event.cache_key()

    log.info(f"🔍 Resolving: {cache_key}")
    db.upsert(cache_key, event, status="resolving")

    try:
        # Verify episode numbering
        if event.media_type.value == "episode" and event.season and event.episode:
            tmdb_key = db.get_setting("tmdb_api_key", "")
            cs, cep = await _verify_episode_with_tmdb(
                event.tmdb_id, event.tvdb_id, event.season, event.episode, event.title, tmdb_key)
            if cs != event.season or cep != event.episode:
                event      = event.model_copy(update={"season": cs, "episode": cep})
                cache_key  = event.cache_key()
                existing   = db.get(cache_key)
                if existing and existing["status"] == "cached":
                    log.info(f"✅ Cache hit (corrected): {cache_key}"); return
                db.upsert(cache_key, event, status="resolving")

        # Strategy
        s_cfg = db.get_all_settings()
        if event.media_type.value == "episode":
            lm = app.state.library; is_ended = False
            if lm:
                try:
                    sl = await lm.get_sonarr_series()
                    sm = next((x for x in sl if x["title"].lower() == event.title.lower()), None)
                    if sm: is_ended = sm.get("status","").lower() in ("ended","cancelled","canceled")
                except Exception: pass
            strategy         = s_cfg.get("series_completed_strategy","series_pack") if is_ended else s_cfg.get("series_ongoing_strategy","season_pack")
            preferred_quality = s_cfg.get("series_preferred_quality","1080p")
            fallback_any      = s_cfg.get("series_fallback_any_quality","true") == "true"
        else:
            strategy         = "movie"
            preferred_quality = s_cfg.get("movie_preferred_quality","1080p")
            fallback_any      = s_cfg.get("movie_fallback_any_quality","true") == "true"

        # ── Hash index fast path ────────────────────────────────────────────
        # Check the pre-built hash index before doing a live TPB search.
        # This gives sub-second resolution for anything already indexed.
        hi: HashIndex = getattr(app.state, "hash_index", None)
        if hi:
            candidates = hi.lookup(
                event.title,
                season=event.season,
                episode=event.episode,
                cached_only=True,
            )
            if candidates:
                best_hash_row = candidates[0]
                log.info(
                    f"⚡ HashIndex hit: {event.title!r} — "
                    f"{best_hash_row['torrent_name']!r} ({best_hash_row['quality']})"
                )
                # Sanitise magnet — reject proxy URLs, reconstruct from hash if needed
                _raw_magnet = best_hash_row["magnet"] or ""
                if not _raw_magnet.startswith("magnet:?xt=urn:btih:"):
                    _raw_magnet = (
                        f"magnet:?xt=urn:btih:{best_hash_row['info_hash']}"
                        f"&dn={best_hash_row.get('torrent_name','')}"
                    )
                    # Write the corrected magnet back so it doesn't fail again
                    hi.upsert(
                        media_type=best_hash_row["media_type"],
                        title=best_hash_row["title"],
                        year=best_hash_row.get("year"),
                        season=best_hash_row.get("season"),
                        episode=best_hash_row.get("episode"),
                        info_hash=best_hash_row["info_hash"],
                        magnet=_raw_magnet,
                        torrent_name=best_hash_row.get("torrent_name", ""),
                        quality=best_hash_row.get("quality", "unknown"),
                        strategy=best_hash_row.get("strategy", "unknown"),
                        is_cached=True,
                    )
                    log.info(f"🔧 Repaired invalid magnet for {best_hash_row['info_hash'][:8]}")
                result = await alldebrid.add_magnet(_raw_magnet)
                if result:
                    magnet_id, files = result
                    torrent_name = best_hash_row["torrent_name"]

                    # Find episode-specific file
                    target_file = None
                    if event.media_type.value == "episode" and event.season and event.episode:
                        se_pat = f"S{event.season:02d}E{event.episode:02d}".upper()
                        for f in files:
                            if se_pat in f.get("n", "").upper():
                                target_file = f
                                break
                    if not target_file:
                        target_file = max(files, key=lambda f: f.get("s", 0))

                    filename  = target_file.get("n", torrent_name)
                    ad_link   = target_file.get("l", "")
                    stem = Path(filename).stem if filename else torrent_name
                    fuse_folder = stem if (stem and torrent_name and stem.startswith(torrent_name.rstrip("-"))) else torrent_name

                    if ad_link and s.PLEX_ROOT:
                        fuse_thread = getattr(app.state, "fuse_thread", None)
                        if FUSE_AVAILABLE and fuse_thread:
                            register_torrent(fuse_folder, files)
                            fuse_virtual = get_fuse_path(fuse_folder, filename, s.FUSE_SYMLINK_ROOT)
                            link = _make_plex_symlink(
                                cache_key, event.title, event.year, event.season,
                                event.episode, event.media_type.value, s.PLEX_ROOT,
                                fuse_virtual, filename,
                            )
                            strm_path = str(link) if link else None
                        else:
                            p = write_strm(
                                cache_key=cache_key, title=event.title, year=event.year,
                                season=event.season, episode=event.episode,
                                media_type=event.media_type.value,
                                debridarr_base_url=s.DEBRIDARR_BASE_URL,
                                plex_root=s.PLEX_ROOT,
                            )
                            strm_path = str(p) if p else None
                    else:
                        strm_path = None

                    db.update_cached(
                        cache_key, best_hash_row["magnet"], ad_link, torrent_name,
                        best_hash_row["quality"], strm_path,
                    )
                    # Write-back: mark this hash as used and confirmed
                    hi.touch(best_hash_row["info_hash"])
                    log.info(f"✅ HashIndex resolve done: {cache_key}")
                    return
                else:
                    # add_magnet failed — hash may have been evicted from AllDebrid
                    # Mark it uncached and fall through to live search
                    log.warning(
                        f"⚠️  HashIndex hit but add_magnet failed for "
                        f"{best_hash_row['info_hash']!r} — falling back to live search"
                    )
                    hi.mark_uncached(best_hash_row["info_hash"])

        # Check FUSE first
        fuse_match = _find_in_fuse(event.title, event.year, event.season, event.episode)
        if fuse_match:
            torrent_name, filename, fuse_file = fuse_match
            log.info(f"✅ Found in FUSE — symlinking directly")
            fuse_virtual = get_fuse_path(torrent_name, filename, s.FUSE_SYMLINK_ROOT)
            link = _make_plex_symlink(cache_key, event.title, event.year, event.season,
                                      event.episode, event.media_type.value, s.PLEX_ROOT,
                                      fuse_virtual, filename)
            fuse_quality = _detect_quality(filename)
            db.update_cached(cache_key, "", fuse_file.get("l",""), torrent_name,
                             fuse_quality, str(link) if link else None)
            # Write to hash index so future plays use the fast path
            _fuse_hi: HashIndex = getattr(app.state, "hash_index", None)
            if _fuse_hi:
                import re as _re_fuse
                _fuse_magnet = fuse_file.get("l", "")  # file link, not a magnet
                # Build a minimal magnet from the torrent name for index lookup
                # The FUSE path itself is the authoritative source; magnet may be empty
                # Store the file link so mark_uncached can clean up if needed
                try:
                    _fuse_hi.upsert(
                        media_type=event.media_type.value,
                        title=event.title,
                        year=event.year,
                        season=event.season,
                        episode=event.episode,
                        info_hash="fuse_" + torrent_name[:32].replace(" ", "_").lower(),
                        magnet=_fuse_magnet or f"fuse://{torrent_name}",
                        torrent_name=torrent_name,
                        quality=fuse_quality,
                        strategy="fuse",
                        is_cached=True,
                    )
                    log.info(f"🗄️  HashIndex FUSE write-back: {event.title!r} → {torrent_name!r}")
                except Exception as _e_fuse:
                    log.debug(f"HashIndex FUSE write-back failed: {_e_fuse}")
            return

        # Check cancellation before expensive AllDebrid search
        if cancel_event and cancel_event.is_set():
            db.update_status(cache_key, "not_found")
            log.info(f"🚫 Cancelled: {cache_key}")
            return

        # Search TPB
        log.info(f"🔎 Searching TPB for: {event.title!r}")
        results = await alldebrid.search_cached(
            title=event.title, media_type=event.media_type.value,
            year=event.year, season=event.season, episode=event.episode,
            imdb_id=event.imdb_id, strategy=strategy,
            preferred_quality=preferred_quality, fallback_any=fallback_any,
        )
        if not results:
            log.warning(f"❌ No results: {cache_key}")
            db.update_status(cache_key, "not_found")

            # ── Ongoing series fallback: no pack found → try individual episodes ──
            if (event.media_type.value == "episode"
                    and event.season
                    and strategy in ("season_pack", "episode")
                    and not is_ended):
                asyncio.create_task(
                    _resolve_season_episodes(app, event, preferred_quality, fallback_any)
                )
                log.info(f"📺 Ongoing series — queuing individual episode search for {event.title} S{event.season:02d}")
            return

        best = results[0]
        log.info(f"🎯 {best['name']} cached={best['cached']} q={best.get('quality','?')}")

        result = await alldebrid.add_magnet(best["magnet"])
        if not result:
            db.update_status(cache_key, "unlock_failed"); return

        magnet_id, files = result
        torrent_name = best["name"]

        # Find episode-specific file
        target_file = None
        if event.media_type.value == "episode" and event.season and event.episode:
            se_pat = f"S{event.season:02d}E{event.episode:02d}".upper()
            for f in files:
                if se_pat in f.get("n","").upper(): target_file = f; break
        if not target_file:
            target_file = max(files, key=lambda f: f.get("s",0))

        filename  = target_file.get("n", torrent_name)
        ad_link   = target_file.get("l","")
        file_size = target_file.get("s", 0)

        # Resolve FUSE folder name (handle truncated names)
        stem = Path(filename).stem if filename else torrent_name
        fuse_folder = stem if (stem and torrent_name and stem.startswith(torrent_name.rstrip("-"))) else torrent_name

        if not ad_link:
            log.error(f"No file link for {cache_key}")
            db.update_status(cache_key, "unlock_failed"); return

        log.info(f"📁 {fuse_folder}/{filename} ({file_size} bytes)")

        strm_path = None
        fuse_thread = getattr(app.state, "fuse_thread", None)

        if s.PLEX_ROOT:
            if FUSE_AVAILABLE and fuse_thread:
                register_torrent(fuse_folder, files)
                fuse_virtual = get_fuse_path(fuse_folder, filename, s.FUSE_SYMLINK_ROOT)
                log.info(f"📂 FUSE: {fuse_virtual}")
                link = _make_plex_symlink(cache_key, event.title, event.year, event.season,
                                          event.episode, event.media_type.value, s.PLEX_ROOT,
                                          fuse_virtual, filename)
                strm_path = str(link) if link else None
                log.info(f"🔗 {link} → {fuse_virtual}")
            else:
                p = write_strm(cache_key=cache_key, title=event.title, year=event.year,
                               season=event.season, episode=event.episode,
                               media_type=event.media_type.value,
                               debridarr_base_url=s.DEBRIDARR_BASE_URL, plex_root=s.PLEX_ROOT)
                strm_path = str(p) if p else None

        db.update_cached(cache_key, best["magnet"], ad_link, torrent_name,
                         best.get("quality","unknown"), strm_path)
        log.info(f"✅ Done: {cache_key}")

        # Write resolved magnet into hash index — future plays hit fast path
        _hi2: HashIndex = getattr(app.state, "hash_index", None)
        if _hi2 and best.get("magnet"):
            import re as _re2
            _m2 = _re2.search(r"btih:([a-fA-F0-9]{40})", best["magnet"], _re2.I)
            if _m2:
                _hi2.upsert(
                    media_type=event.media_type.value,
                    title=event.title, year=event.year,
                    season=event.season, episode=event.episode,
                    info_hash=_m2.group(1).lower(),
                    magnet=best["magnet"],
                    torrent_name=torrent_name,
                    quality=best.get("quality", "unknown"),
                    strategy="live_resolve",
                    is_cached=True,
                )
                log.info(f"🗄️  Live resolve written to hash index: {event.title!r}")

        # ── Write-back: store ALL search results so future plays skip TPB ────
        # We store every cached candidate (up to 5), not just the one we used.
        # If that torrent gets evicted from AllDebrid, the next play can try
        # the next-best candidate without doing a new TPB search.
        # Season/series packs stored without episode so any episode in the pack
        # hits the index directly.
        _hi_wb: HashIndex = getattr(app.state, "hash_index", None)
        if _hi_wb:
            import re as _re_wb
            _is_pack = (
                event.media_type.value == "episode"
                and strategy in ("season_pack", "series_pack")
                and len(files) > 1
            )
            for _wb_r in results:  # results already filtered to cached only, up to 5
                _hm = _re_wb.search(r"btih:([a-fA-F0-9]{40})", _wb_r.get("magnet",""), _re_wb.I)
                if not _hm:
                    continue
                try:
                    _hi_wb.upsert(
                        media_type="season" if _is_pack else event.media_type.value,
                        title=event.title,
                        year=event.year,
                        season=event.season if strategy != "series_pack" else None,
                        episode=None if _is_pack else event.episode,
                        info_hash=_hm.group(1).lower(),
                        magnet=_wb_r["magnet"],
                        torrent_name=_wb_r.get("name", torrent_name),
                        quality=_wb_r.get("quality", "unknown"),
                        strategy=strategy,
                        is_cached=bool(_wb_r.get("cached", True)),
                    )
                except Exception as _e_wb:
                    log.debug(f"HashIndex write-back failed: {_e_wb}")
            log.info(
                f"🗄️  HashIndex write-back: {event.title!r} → "
                f"{torrent_name!r} ({strategy}, {best.get('quality','unknown')}) "
                f"[+{len(results)-1} alternates]"
            )

        # ── Season/series pack: symlink requested episode NOW, rest after 60s ──
        if (event.media_type.value == "episode"
                and event.season
                and strategy in ("season_pack", "series_pack")
                and len(files) > 1):
            # Delay the rest so the user can start watching the selected episode
            # without waiting for all other symlinks to be created first
            async def _delayed_pack_symlinks():
                await asyncio.sleep(120)
                extra = _symlink_pack_episodes(
                    app=app, db=db, files=files,
                    magnet_str=best["magnet"], torrent_name=torrent_name,
                    quality=best.get("quality", "unknown"),
                    title=event.title, year=event.year, season=event.season,
                    event_episode=event.episode,
                    media_type=event.media_type.value,
                    plex_root=s.PLEX_ROOT,
                    debridarr_base_url=s.DEBRIDARR_BASE_URL,
                    fuse_thread=getattr(app.state, "fuse_thread", None),
                    fuse_symlink_root=s.FUSE_SYMLINK_ROOT,
                    all_seasons=(strategy == "series_pack"),
                )
                if extra:
                    _pack_type = "series" if strategy == "series_pack" else f"S{event.season:02d}"
                    log.info(f"📦 Pack: symlinked {extra} remaining episodes for {event.title} {_pack_type} (after 120s delay)")
            asyncio.create_task(_delayed_pack_symlinks())
            log.info(f"📦 Pack found — requested episode ready now, rest in 120s")

    except Exception as e:
        log.error(f"❌ {cache_key}: {e}", exc_info=True)
        db.update_status(cache_key, "error")


async def _resolve_season_episodes(
    app: FastAPI,
    event: PlayEvent,
    preferred_quality: str,
    fallback_any: bool,
    delay_between: int = 10,
):
    """
    Fallback for ongoing series with no season pack available.
    Searches for each individual episode in the season and resolves them,
    starting with the requested episode and working outward.

    Called when strategy=season_pack|episode and no pack is found.
    Staggered by delay_between seconds to avoid hammering AllDebrid.
    """
    db        = app.state.db
    lm        = app.state.library
    alldebrid = app.state.alldebrid

    title  = event.title
    season = event.season
    year   = event.year
    target = event.episode

    # Get the full episode list for this season from Overseerr/Sonarr
    episodes_in_season = []
    if lm:
        try:
            sl = await lm.get_sonarr_series()
            sm = next((x for x in sl if x["title"].lower() == title.lower()), None)
            if sm:
                all_eps = await lm.get_episodes(sm["id"], include_unreleased=False)
                episodes_in_season = [
                    e["episode"] for e in all_eps
                    if e["season"] == season
                ]
        except Exception as e:
            log.warning(f"_resolve_season_episodes: could not get episode list: {e}")

    if not episodes_in_season:
        # Fallback: assume standard season of up to 20 episodes
        episodes_in_season = list(range(1, 21))

    # Sort: start with the requested episode, then forward, then backward
    before = sorted([e for e in episodes_in_season if e < target], reverse=True)
    after  = sorted([e for e in episodes_in_season if e > target])
    ordered = [target] + after + before   # target first, then forward, then backfill

    log.info(f"📺 Individual episode search for {title} S{season:02d} — {len(ordered)} episodes")

    resolved = 0
    for epn in ordered:
        ep_event = PlayEvent(
            media_type=MediaType.episode,
            title=title, year=year,
            season=season, episode=epn,
        )
        ck = ep_event.cache_key()
        existing = db.get(ck)
        if existing and existing["status"] == "cached":
            resolved += 1
            continue
        if existing and existing["status"] == "resolving":
            continue

        try:
            results = await alldebrid.search_cached(
                title=title, media_type="episode", year=year,
                season=season, episode=epn,
                strategy="episode",
                preferred_quality=preferred_quality,
                fallback_any=fallback_any,
            )
            if results:
                # Write all candidates to hash index before resolving
                _rs_hi: HashIndex = getattr(app.state, "hash_index", None)
                if _rs_hi:
                    import re as _re_rs
                    for _rsr in results:
                        _hm_rs = _re_rs.search(r"btih:([a-fA-F0-9]{40})", _rsr.get("magnet",""), _re_rs.I)
                        if _hm_rs and _rsr.get("cached"):
                            try:
                                _is_pack_rs = not _re_rs.search(r"S\d{2}E\d{2}", _rsr["name"], _re_rs.I)
                                _rs_hi.upsert(
                                    media_type="season" if _is_pack_rs else "episode",
                                    title=title, year=year,
                                    season=season, episode=None if _is_pack_rs else epn,
                                    info_hash=_hm_rs.group(1).lower(),
                                    magnet=_rsr["magnet"],
                                    torrent_name=_rsr["name"],
                                    quality=_rsr.get("quality", "unknown"),
                                    strategy="episode",
                                    is_cached=True,
                                )
                            except Exception:
                                pass
                # Resolve this episode
                asyncio.create_task(resolve_and_cache(app, ep_event))
                resolved += 1
                log.debug(f"  📺 Queued resolve: {title} S{season:02d}E{epn:02d}")
            else:
                log.debug(f"  ⏭  No torrent: {title} S{season:02d}E{epn:02d}")
        except Exception as e:
            log.error(f"  Episode search {title} S{season:02d}E{epn:02d}: {e}")

        await asyncio.sleep(delay_between)

    log.info(f"📺 Individual episode resolve queued {resolved}/{len(ordered)} for {title} S{season:02d}")





# ══════════════════════════════════════════════════════════════════════
# /hash-indexer — Hash Indexer page
# ══════════════════════════════════════════════════════════════════════



def _fmt_ts(ts) -> str:
    """Unix timestamp → human-readable relative string."""
    if not ts:
        return "never"
    try:
        dt   = datetime.fromtimestamp(int(ts), tz=timezone.utc)
        diff = (datetime.now(tz=timezone.utc) - dt).total_seconds()
        if diff < 60:        return "just now"
        if diff < 3600:      return f"{int(diff//60)}m ago"
        if diff < 86400:     return f"{int(diff//3600)}h ago"
        if diff < 86400*7:   return f"{int(diff//86400)}d ago"
        return dt.strftime("%Y-%m-%d")
    except Exception:
        return "—"


def _quality_pill(q: str) -> str:
    colours = {
        "2160p": ("#1a0a3a", "#c084fc"),
        "4k":    ("#1a0a3a", "#c084fc"),
        "uhd":   ("#1a0a3a", "#c084fc"),
        "1080p": ("#0d2640", "#60a5fa"),
        "720p":  ("#162a00", "#86efac"),
        "480p":  ("#2a1a00", "#fbbf24"),
    }
    bg, fg = colours.get((q or "").lower(), ("#1e1e2e", "#555"))
    return f'<span style="background:{bg};color:{fg};padding:2px 8px;border-radius:20px;font-size:0.68rem;font-weight:700">{_html.escape(q or "?")}</span>'


def _score_bar(score: int, max_score: int = 120) -> str:
    pct  = min(100, int(score / max(max_score, 1) * 100))
    col  = "#4ade80" if pct >= 70 else "#f97316" if pct >= 40 else "#f87171"
    return (
        f'<div style="display:flex;align-items:center;gap:6px">'
        f'<div style="width:64px;height:6px;background:#1e1e2e;border-radius:3px;overflow:hidden">'
        f'<div style="width:{pct}%;height:100%;background:{col};border-radius:3px"></div></div>'
        f'<span style="font-size:0.72rem;color:#555">{score}</span>'
        f'</div>'
    )


@app.get("/hash-indexer", response_class=HTMLResponse)
async def hash_indexer_page(
    request: Request,
    tab: str = "all",
    q: str = "",
    page: int = 1,
):
    if _needs_setup(request):
        return _setup_redirect()

    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    db: CacheDB   = request.app.state.db

    if not hi:
        return _page("Hash Indexer", "hashindexer",
                     '<div class="empty">Hash index not initialised.</div>')

    # ── Pull data ─────────────────────────────────────────────────────────────
    stats    = hi.stats()
    all_rows = hi.list_titles()

    # Cross-reference with fake_library so we can flag "in library / missing"
    lib_titles = {
        r["title"].lower()
        for r in db.fake_library_list()
    }

    # Augment each row with library membership and "missing" flag
    for row in all_rows:
        row["in_library"] = row["title"].lower() in lib_titles
        row["missing"]    = row["in_library"] and row["cached_count"] == 0

    # ── Filter by tab ─────────────────────────────────────────────────────────
    if tab == "movies":
        rows = [r for r in all_rows if r["kind"] == "movie"]
    elif tab == "tv":
        rows = [r for r in all_rows if r["kind"] == "tv"]
    elif tab == "cached":
        rows = [r for r in all_rows if r["cached_count"] > 0]
    elif tab == "missing":
        rows = [r for r in all_rows if r["missing"]]
    else:
        rows = all_rows

    # ── Search ────────────────────────────────────────────────────────────────
    if q:
        ql   = q.lower()
        rows = [r for r in rows if ql in r["title"].lower()]

    # ── Counts for tab badges ─────────────────────────────────────────────────
    n_all     = len(all_rows)
    n_movies  = sum(1 for r in all_rows if r["kind"] == "movie")
    n_tv      = sum(1 for r in all_rows if r["kind"] == "tv")
    n_cached  = sum(1 for r in all_rows if r["cached_count"] > 0)
    n_missing = sum(1 for r in all_rows if r["missing"])

    # ── Pagination ────────────────────────────────────────────────────────────
    PER_PAGE    = 50
    total       = len(rows)
    total_pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)
    page        = max(1, min(page, total_pages))
    page_rows   = rows[(page - 1) * PER_PAGE : page * PER_PAGE]

    # ── Stat cards ────────────────────────────────────────────────────────────
    def stat_card(label, value, colour="#e0e0e0"):
        return (
            f'<div style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:10px;'
            f'padding:16px 20px;min-width:110px">'
            f'<div style="font-size:1.6rem;font-weight:700;color:{colour}">{value}</div>'
            f'<div style="font-size:0.72rem;color:#555;margin-top:3px">{label}</div>'
            f'</div>'
        )

    stat_bar = (
        '<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:24px">'
        + stat_card("Total hashes",   stats["total"])
        + stat_card("Cached on AD",   stats["cached"],   "#4ade80")
        + stat_card("Movies",         stats["movies"],   "#60a5fa")
        + stat_card("Season packs",   stats["seasons"],  "#c084fc")
        + stat_card("Series packs",   stats["series"],   "#c084fc")
        + stat_card("Avg score",      stats["avg_score"])
        + stat_card("Missing",        n_missing,         "#f87171" if n_missing else "#555")
        + '</div>'
    )

    # ── Tabs ──────────────────────────────────────────────────────────────────
    def _tab(key, label, count):
        active = "active" if tab == key else ""
        return (
            f'<div class="tab {active}" onclick="location.href=\'/hash-indexer?tab={key}&q={_html.escape(q)}\'">'
            f'{label} <span style="font-size:0.72rem;opacity:0.7">({count})</span></div>'
        )

    tabs_html = (
        '<div class="tabs" style="margin-bottom:20px">'
        + _tab("all",     "All",         n_all)
        + _tab("movies",  "🎬 Movies",   n_movies)
        + _tab("tv",      "📺 TV",       n_tv)
        + _tab("cached",  "✅ Cached",   n_cached)
        + _tab("missing", "❌ Missing",  n_missing)
        + '</div>'
    )

    # ── Search bar ────────────────────────────────────────────────────────────
    search_html = f"""
    <div class="search-bar">
      <input id="q" type="text" placeholder="Search titles…" value="{_html.escape(q)}"
             onkeydown="if(event.key==='Enter')go()">
      <button class="btn btn-add" onclick="go()">Search</button>
      {'<button class="btn btn-sec" onclick="location.href=\'/hash-indexer?tab='+tab+'\'">&times; Clear</button>' if q else ''}
      <button class="btn btn-sec" onclick="triggerReindex()" style="margin-left:auto">🔄 Re-index All</button>
      <button class="btn btn-sec" onclick="triggerRecheck()">⟳ Recheck AD</button>
      <button class="btn btn-add" onclick="syncStreams()">⚡ Sync Streams→Index</button>
    </div>"""

    # ── Table rows ────────────────────────────────────────────────────────────
    def row_html(r: dict) -> str:
        title_safe = _html.escape(r["title"])
        year_str   = f' ({r["year"]})' if r.get("year") else ""

        # Cached status indicator
        if r["cached_count"] > 0:
            status = (
                f'<span style="color:#4ade80;font-size:0.75rem;font-weight:700">✅ cached</span>'
                f'<span style="color:#555;font-size:0.72rem;margin-left:4px">'
                f'{r["cached_count"]}/{r["total_hashes"]} hashes</span>'
            )
        elif r["missing"]:
            status = '<span style="color:#f87171;font-size:0.75rem;font-weight:700">❌ missing</span>'
        else:
            status = '<span style="color:#555;font-size:0.75rem">⏳ not cached</span>'

        # Pack badges
        packs = ""
        if r.get("has_series_pack"):
            packs += '<span style="background:#1a0a3a;color:#c084fc;padding:1px 6px;border-radius:10px;font-size:0.65rem;margin-right:3px">series pack</span>'
        if r.get("has_season_pack"):
            packs += '<span style="background:#0d2640;color:#60a5fa;padding:1px 6px;border-radius:10px;font-size:0.65rem;margin-right:3px">season pack</span>'

        # Season count for TV
        kind_badge = ""
        if r["kind"] == "tv":
            sc = r.get("season_count") or 0
            kind_badge = f'<span style="color:#555;font-size:0.72rem">{sc} season{"s" if sc != 1 else ""}</span>'
        else:
            kind_badge = '<span style="color:#555;font-size:0.72rem">movie</span>'

        # Library badge
        lib_badge = (
            '<span style="background:#14532d;color:#4ade80;padding:1px 6px;'
            'border-radius:10px;font-size:0.65rem">in library</span>'
            if r["in_library"] else
            '<span style="background:#1e1e2e;color:#444;padding:1px 6px;'
            'border-radius:10px;font-size:0.65rem">not in library</span>'
        )

        quality = _quality_pill(r.get("best_quality") or "")
        score   = _score_bar(r.get("best_score") or 0)

        last_checked = _fmt_ts(r.get("last_checked"))
        last_used    = _fmt_ts(r.get("last_used"))

        return (
            f'<tr data-title="{title_safe.lower()}" data-kind="{r["kind"]}" '
            f'data-cached="{1 if r["cached_count"] else 0}">'
            f'<td>'
            f'  <div style="font-weight:600;color:#e0e0e0">{title_safe}{_html.escape(year_str)}</div>'
            f'  <div style="margin-top:3px;display:flex;gap:4px;flex-wrap:wrap">'
            f'    {kind_badge} {lib_badge} {packs}'
            f'  </div>'
            f'</td>'
            f'<td>{status}</td>'
            f'<td>{quality}</td>'
            f'<td>{score}</td>'
            f'<td style="color:#555;font-size:0.78rem">{last_checked}</td>'
            f'<td style="color:#555;font-size:0.78rem">{last_used}</td>'
            f'<td style="white-space:nowrap">'
            f'  <button class="btn btn-sec" style="padding:3px 9px;font-size:0.72rem" '
            f'    onclick="showDetail(\'{title_safe.replace(chr(39), chr(92)+chr(39))}\', \'{r["kind"]}\' )">Detail</button>'
            f'  <button class="btn btn-rem" style="padding:3px 9px;font-size:0.72rem;margin-left:4px" '
            f'    onclick="reindexTitle(\'{title_safe.replace(chr(39), chr(92)+chr(39))}\')">Re-index</button>'
            f'</td>'
            f'</tr>'
        )

    table_rows = "".join(row_html(r) for r in page_rows)

    if table_rows:
        table_html = f"""
        <table>
          <thead><tr>
            <th>Title</th>
            <th>Status</th>
            <th>Quality</th>
            <th>Score</th>
            <th>Last checked</th>
            <th>Last played</th>
            <th></th>
          </tr></thead>
          <tbody>{table_rows}</tbody>
        </table>"""
    else:
        msg = f'No results for "{_html.escape(q)}"' if q else "Nothing indexed yet — add titles to your library to start indexing."
        table_html = f'<div class="empty">{msg}</div>'

    pager = _pagination("/hash-indexer", {"tab": tab, "q": q}, page, total_pages)

    count_str = f"{total} title{'s' if total != 1 else ''}"
    if q:
        count_str += f' matching "{_html.escape(q)}"'

    body = f"""
    <div style="display:flex;align-items:baseline;gap:12px;margin-bottom:20px">
      <h2 style="margin:0">🔎 Hash Indexer</h2>
      <span style="color:#555;font-size:0.82rem">{count_str}</span>
    </div>
    {stat_bar}
    {tabs_html}
    {search_html}
    <div id="result-msg" style="margin-bottom:12px;font-size:0.82rem;color:#4ade80;display:none"></div>
    {table_html}
    {pager}

    <!-- Detail drawer -->
    <div id="detail-drawer" style="display:none;position:fixed;right:0;top:0;bottom:0;width:480px;
         background:#13131a;border-left:1px solid #2a2a3a;padding:24px;overflow-y:auto;z-index:100">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
        <h2 id="detail-title" style="margin:0;font-size:1rem"></h2>
        <button onclick="closeDetail()" style="background:none;border:none;color:#888;font-size:1.3rem;cursor:pointer">✕</button>
      </div>
      <div id="detail-body" style="font-size:0.82rem"></div>
    </div>
    <div id="detail-overlay" onclick="closeDetail()"
         style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:99"></div>
    """

    extra = f"""<script>
function go() {{
  const q = encodeURIComponent(document.getElementById('q').value.trim());
  location.href = '/hash-indexer?tab={tab}&q=' + q;
}}
document.getElementById('q').addEventListener('keydown', e => {{ if(e.key==='Enter') go(); }});

async function triggerReindex() {{
  const r = await fetch('/api/hash-index/reindex', {{method:'POST'}});
  const d = await r.json();
  showMsg(d.message || 'Re-index started');
}}

async function syncStreams() {{
  const r = await fetch('/api/hash-index/sync-streams', {{method:'POST'}});
  const d = await r.json();
  showMsg(d.message || '⚡ Sync complete');
}}

async function triggerRecheck() {{
  const r = await fetch('/api/hash-index/recheck', {{method:'POST'}});
  const d = await r.json();
  showMsg(d.message || 'Recheck queued');
}}

async function reindexTitle(title) {{
  const r = await fetch('/api/hash-index/reindex-title', {{
    method: 'POST',
    headers: {{'Content-Type': 'application/json'}},
    body: JSON.stringify({{title}})
  }});
  const d = await r.json();
  showMsg(r.ok ? '🔄 Re-indexing ' + title : '❌ ' + (d.detail || 'Error'));
}}

function showMsg(msg) {{
  const el = document.getElementById('result-msg');
  el.textContent = msg;
  el.style.display = 'block';
  setTimeout(() => el.style.display = 'none', 4000);
}}

async function showDetail(title, kind) {{
  const isTV = (kind === 'tv');
  document.getElementById('detail-title').textContent = title;
  document.getElementById('detail-body').innerHTML = '<div style="color:#555">Loading…</div>';
  document.getElementById('detail-drawer').style.display = 'block';
  document.getElementById('detail-overlay').style.display = 'block';

  // Fetch both hash list and (for TV) series breakdown in parallel
  const hashReq   = fetch('/api/hash-index/detail?title=' + encodeURIComponent(title));
  const seriesReq = isTV ? fetch('/api/hash-index/series-detail?title=' + encodeURIComponent(title)) : null;

  const [hashRes, seriesRes] = await Promise.all([hashReq, seriesReq || Promise.resolve(null)]);
  const hashData   = await hashRes.json();
  const seriesData = seriesRes ? await seriesRes.json() : null;

  const rows = hashData.hashes || [];

  const qualColour = {{
    '2160p': '#c084fc', '4k': '#c084fc', 'uhd': '#c084fc',
    '1080p': '#60a5fa', '720p': '#86efac', '480p': '#fbbf24'
  }};

  // ── Build hashes tab ────────────────────────────────────────────────────────
  function buildHashesTab() {{
    if (!rows.length) return '<div style="color:#555;padding:20px 0">No hashes indexed yet.</div>';
    const topCachedIdx = rows.findIndex(h => h.is_cached);
    let html = '';
    const cachedCount = rows.filter(h => h.is_cached).length;
    html += `<div style="font-size:0.75rem;color:#555;margin-bottom:12px">
      ${{rows.length}} hash${{rows.length !== 1 ? 'es' : ''}} indexed
      · ${{cachedCount}} cached on AllDebrid
      ${{topCachedIdx >= 0
        ? '· <span style="color:#4ade80">top result will be used on play</span>'
        : '· <span style="color:#f87171">none cached — play will trigger live search</span>'}}
    </div>`;
    for (let i = 0; i < rows.length; i++) {{
      const h = rows[i];
      const isActive  = (i === topCachedIdx);
      const border    = isActive ? '1px solid #4ade80' : '1px solid #2a2a3a';
      const bg        = isActive ? '#0d2010' : '#1a1a24';
      const qcol      = qualColour[h.quality] || '#555';
      const score_pct = Math.min(100, Math.round((h.score || 0) / 120 * 100));
      const score_col = score_pct >= 70 ? '#4ade80' : score_pct >= 40 ? '#f97316' : '#f87171';
      const ts        = h.last_checked ? new Date(h.last_checked * 1000).toLocaleString() : 'never';
      const used      = h.last_used    ? new Date(h.last_used * 1000).toLocaleString()    : 'never';
      const season_ep = h.season
        ? 'S' + String(h.season).padStart(2,'0') + (h.episode ? 'E' + String(h.episode).padStart(2,'0') : ' (pack)')
        : '';
      const fullHash  = h.info_hash || '—';
      html += `<div style="background:${{bg}};border:${{border}};border-radius:8px;padding:14px;margin-bottom:10px">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px">
          <div style="flex:1;min-width:0">
            <div style="font-weight:600;color:#e0e0e0;font-size:0.84rem;word-break:break-word;line-height:1.3">${{h.torrent_name || '—'}}</div>
            ${{isActive ? '<div style="margin-top:4px"><span style="background:#14532d;color:#4ade80;font-size:0.65rem;font-weight:700;padding:2px 7px;border-radius:10px">▶ WILL USE ON PLAY</span></div>' : ''}}
          </div>
          <div style="margin-left:10px;flex-shrink:0">
            ${{h.is_cached ? '<span style="color:#4ade80;font-weight:700">✅ cached</span>' : '<span style="color:#f87171">✗ not cached</span>'}}
          </div>
        </div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:10px">
          <span style="color:${{qcol}};font-size:0.75rem;font-weight:700;background:${{qcol}}22;padding:1px 7px;border-radius:10px">${{h.quality || '?'}}</span>
          <span style="font-size:0.72rem;color:#777">${{h.media_type}}</span>
          ${{season_ep ? `<span style="font-size:0.72rem;color:#777">${{season_ep}}</span>` : ''}}
          <span style="font-size:0.72rem;color:#555">${{h.strategy || '—'}}</span>
          <div style="display:flex;align-items:center;gap:5px;margin-left:auto">
            <div style="width:56px;height:5px;background:#111;border-radius:3px;overflow:hidden">
              <div style="width:${{score_pct}}%;height:100%;background:${{score_col}};border-radius:3px"></div>
            </div>
            <span style="font-size:0.72rem;color:#888">${{h.score}}</span>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px;background:#111;border-radius:5px;padding:5px 8px">
          <span style="font-family:monospace;font-size:0.68rem;color:#666;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${{fullHash}}</span>
          <button onclick="navigator.clipboard.writeText('${{fullHash}}').then(()=>this.textContent='\u2713').catch(()=>{{}})"
                  style="background:none;border:1px solid #333;border-radius:4px;color:#666;font-size:0.65rem;padding:2px 6px;cursor:pointer;flex-shrink:0">copy</button>
        </div>
        <div style="display:flex;gap:20px;flex-wrap:wrap">
          <span style="font-size:0.68rem;color:#444">checked: ${{ts}}</span>
          <span style="font-size:0.68rem;color:#444">last played: ${{used}}</span>
          ${{h.file_size ? `<span style="font-size:0.68rem;color:#444">size: ${{(h.file_size/1e9).toFixed(1)}} GB</span>` : ''}}
        </div>
      </div>`;
    }}
    return html;
  }}

  // ── Build seasons tab (TV only) ─────────────────────────────────────────────
  function buildSeasonsTab(sd) {{
    if (!sd) return '';
    const seasons = sd.seasons || {{}};
    const seasonNums = Object.keys(seasons).map(Number).sort((a,b) => a-b);
    let html = '';

    // Series-level search button
    html += `<div style="display:flex;justify-content:space-between;align-items:center;
                         margin-bottom:16px;padding-bottom:12px;border-bottom:1px solid #2a2a3a">
      <div>
        ${{sd.has_series_pack && sd.series_pack?.is_cached
          ? '<span style="color:#4ade80;font-size:0.78rem;font-weight:700">✅ series pack cached</span>'
          : sd.has_series_pack
            ? '<span style="color:#555;font-size:0.78rem">series pack indexed (not cached)</span>'
            : '<span style="color:#555;font-size:0.78rem">no series pack indexed</span>'
        }}
        <div style="font-size:0.7rem;color:#444;margin-top:2px">
          ${{sd.total_hashes}} hashes · ${{sd.cached_hashes}} cached
        </div>
      </div>
      <button class="btn btn-add" style="padding:4px 12px;font-size:0.75rem"
              onclick="searchSeries('${{sd.title.replace(/'/g, "\\'")}}')">
        🔍 Search whole series
      </button>
    </div>`;

    if (!seasonNums.length) {{
      html += '<div style="color:#555;font-size:0.82rem">No seasons indexed yet. Use Search to populate.</div>';
      return html;
    }}

    for (const sn of seasonNums) {{
      const s = seasons[sn];
      const snPad = String(sn).padStart(2, '0');
      const epNums = Object.keys(s.episodes || {{}}).map(Number).sort((a,b) => a-b);

      const packStatus = s.has_season_pack && s.season_pack?.is_cached
        ? '<span style="color:#4ade80;font-size:0.7rem">✅ pack cached</span>'
        : s.has_season_pack
          ? '<span style="color:#555;font-size:0.7rem">pack indexed</span>'
          : '<span style="color:#3a3a4a;font-size:0.7rem">no pack</span>';

      html += `<div style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:8px;
                            margin-bottom:8px;overflow:hidden">

        <!-- Season header row -->
        <div style="display:flex;align-items:center;justify-content:space-between;
                    padding:10px 14px;cursor:pointer;user-select:none"
             onclick="toggleSeason('sn-${{snPad}}')">
          <div style="display:flex;align-items:center;gap:10px">
            <span style="color:#e0e0e0;font-weight:600;font-size:0.85rem">Season ${{sn}}</span>
            ${{packStatus}}
            <span style="color:#555;font-size:0.7rem">${{s.episode_count}} ep · ${{s.cached_episodes}} cached</span>
          </div>
          <div style="display:flex;align-items:center;gap:8px">
            <button class="btn btn-sec" style="padding:3px 9px;font-size:0.7rem"
                    onclick="event.stopPropagation();searchSeason('${{sd.title.replace(/'/g, "\\'")}}', ${{sn}})">
              🔍 Search S${{snPad}}
            </button>
            <span id="chevron-${{snPad}}" style="color:#555;font-size:0.8rem;transition:transform 0.15s">▶</span>
          </div>
        </div>

        <!-- Episode rows (collapsed by default) -->
        <div id="sn-${{snPad}}" style="display:none;border-top:1px solid #2a2a3a">`;

      if (!epNums.length) {{
        html += `<div style="padding:10px 14px;color:#555;font-size:0.78rem">
          No individual episodes indexed — season pack covers this season.</div>`;
      }} else {{
        for (const ep of epNums) {{
          const e = s.episodes[ep];
          const epPad = String(ep).padStart(2,'0');
          const qcol  = qualColour[e.quality] || '#555';
          const epCached = e.is_cached
            ? '<span style="color:#4ade80;font-size:0.68rem">✅</span>'
            : '<span style="color:#444;font-size:0.68rem">✗</span>';
          html += `<div style="display:flex;align-items:center;justify-content:space-between;
                               padding:7px 14px;border-bottom:1px solid #1e1e2e">
            <div style="display:flex;align-items:center;gap:8px">
              ${{epCached}}
              <span style="color:#888;font-size:0.78rem;font-family:monospace">S${{snPad}}E${{epPad}}</span>
              <span style="color:${{qcol}};font-size:0.68rem">${{e.quality || '?'}}</span>
              <span style="color:#444;font-size:0.68rem">score: ${{e.score}}</span>
            </div>
            <button class="btn btn-sec" style="padding:2px 7px;font-size:0.65rem"
                    onclick="searchEpisode('${{sd.title.replace(/'/g, "\\'")}}', ${{sn}}, ${{ep}})">
              🔍 S${{snPad}}E${{epPad}}
            </button>
          </div>`;
        }}
      }}

      html += `</div></div>`;
    }}

    return html;
  }}

  // ── Tab switching ───────────────────────────────────────────────────────────
  function renderTab(which) {{
    const tabs = document.querySelectorAll('.detail-tab-btn');
    tabs.forEach(t => t.style.fontWeight = t.dataset.tab === which ? '700' : '400');
    tabs.forEach(t => t.style.borderBottom = t.dataset.tab === which ? '2px solid #4ade80' : '2px solid transparent');
    const content = document.getElementById('detail-tab-content');
    if (which === 'seasons') {{
      content.innerHTML = buildSeasonsTab(seriesData);
    }} else {{
      content.innerHTML = buildHashesTab();
    }}
  }}

  // ── Assemble the drawer ─────────────────────────────────────────────────────
  let drawerHtml = '';

  if (isTV && seriesData) {{
    drawerHtml += `<div style="display:flex;gap:0;margin-bottom:16px;border-bottom:1px solid #2a2a3a">
      <button class="detail-tab-btn" data-tab="seasons"
              style="background:none;border:none;border-bottom:2px solid #4ade80;color:#e0e0e0;
                     font-size:0.82rem;font-weight:700;padding:6px 14px;cursor:pointer"
              onclick="renderTab('seasons')">📺 Seasons</button>
      <button class="detail-tab-btn" data-tab="hashes"
              style="background:none;border:none;border-bottom:2px solid transparent;color:#888;
                     font-size:0.82rem;font-weight:400;padding:6px 14px;cursor:pointer"
              onclick="renderTab('hashes')">🗄 Hashes</button>
    </div>
    <div id="detail-tab-content"></div>`;
  }} else {{
    drawerHtml += `<div id="detail-tab-content"></div>`;
  }}

  document.getElementById('detail-body').innerHTML = drawerHtml;

  // Render default tab
  if (isTV && seriesData) {{
    renderTab('seasons');
  }} else {{
    document.getElementById('detail-tab-content').innerHTML = buildHashesTab();
  }}
}}

// ── Season/episode search helpers ─────────────────────────────────────────────

async function searchSeries(title) {{
  _runSearch(title, 'episode', null, null);
}}

async function searchSeason(title, season) {{
  _runSearch(title, 'episode', season, null);
}}

async function searchEpisode(title, season, episode) {{
  _runSearch(title, 'episode', season, episode);
}}

async function _runSearch(title, mediaType, season, episode) {{
  const label = season
    ? (episode ? `S${{String(season).padStart(2,'0')}}E${{String(episode).padStart(2,'0')}}` : `Season ${{season}}`)
    : 'whole series';

  showMsg(`🔍 Searching ${{title}} ${{label}}…`);

  try {{
    const r = await fetch('/api/hash-index/search', {{
      method: 'POST',
      headers: {{'Content-Type': 'application/json'}},
      body: JSON.stringify({{ title, media_type: mediaType, season, episode }}),
    }});
    const d = await r.json();
    if (r.ok) {{
      const msg = d.cached > 0
        ? `✅ ${{d.cached}} cached hash(es) found for ${{title}} ${{label}}`
        : `⚠️ No cached results on AllDebrid for ${{title}} ${{label}}`;
      showMsg(msg);
      // Refresh the drawer with updated data
      if (d.breakdown) {{
        showDetail(title, 'tv');
      }}
    }} else {{
      showMsg('❌ Search error: ' + (d.detail || 'Unknown error'));
    }}
  }} catch(e) {{
    showMsg('❌ Search failed: ' + e.message);
  }}
}}

// ── Season expand/collapse ────────────────────────────────────────────────────

function toggleSeason(id) {{
  const el  = document.getElementById(id);
  const snPad = id.replace('sn-', '');
  const chev = document.getElementById('chevron-' + snPad);
  if (!el) return;
  const open = el.style.display !== 'none';
  el.style.display  = open ? 'none' : 'block';
  if (chev) chev.style.transform = open ? '' : 'rotate(90deg)';
}}

function closeDetail() {{function closeDetail() {{
  document.getElementById('detail-drawer').style.display = 'none';
  document.getElementById('detail-overlay').style.display = 'none';
}}

document.addEventListener('keydown', e => {{ if (e.key === 'Escape') closeDetail(); }});
</script>"""

    return _page("Hash Indexer", "hashindexer", body, extra)


# ── /api/hash-index/detail ────────────────────────────────────────────────────

@app.get("/api/hash-index/detail")
async def api_hash_index_detail(title: str, request: Request):
    """Return all hash rows for a single title — for the detail drawer."""
    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    if not hi:
        raise HTTPException(503, "Hash index not initialised")
    rows = hi.list_hashes_for_title(title)
    return {"title": title, "hashes": rows}


# ── /api/hash-index/series-detail ────────────────────────────────────────────

@app.get("/api/hash-index/series-detail")
async def api_hash_index_series_detail(title: str, request: Request):
    """Return season/episode breakdown for a TV series detail drawer."""
    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    if not hi:
        raise HTTPException(503, "Hash index not initialised")
    return hi.get_series_breakdown(title)


# ── /api/hash-index/search ────────────────────────────────────────────────────

@app.post("/api/hash-index/search")
async def api_hash_index_search(request: Request):
    """
    Targeted search for a specific title / season / episode.
    Runs search_and_index() immediately (not via queue) and returns the result.
    Used by the Hash Indexer detail drawer search buttons.
    """
    body       = await request.json()
    title      = body.get("title", "").strip()
    media_type = body.get("media_type", "episode")  # "movie" | "episode"
    season     = body.get("season")
    episode    = body.get("episode")
    year       = body.get("year")

    if not title:
        raise HTTPException(400, "title required")

    hi:        HashIndex        = getattr(request.app.state, "hash_index", None)
    alldebrid: AllDebridClient  = request.app.state.alldebrid
    db:        CacheDB          = request.app.state.db

    if not hi or not alldebrid or not alldebrid.api_key:
        raise HTTPException(503, "Hash index or AllDebrid not ready")

    settings       = db.get_all_settings()
    prowlarr_url   = settings.get("PROWLARR_URL", "")
    prowlarr_key   = settings.get("PROWLARR_API_KEY", "")
    pref_quality   = settings.get(
        "movie_preferred_quality" if media_type == "movie" else "series_preferred_quality",
        "1080p",
    )

    if not prowlarr_url or not prowlarr_key:
        raise HTTPException(400, "Prowlarr not configured in Settings")

    try:
        n = await search_and_index(
            hi,
            prowlarr_url=prowlarr_url,
            prowlarr_key=prowlarr_key,
            api_key=alldebrid.api_key,
            title=title,
            year=year,
            media_type=media_type,
            season=season,
            episode=episode,
            preferred_quality=pref_quality,
        )
        breakdown = hi.get_series_breakdown(title) if media_type != "movie" else None
        return {
            "status":    "ok",
            "cached":    n,
            "message":   f"{n} cached hash(es) found" if n else "No cached results found on AllDebrid",
            "breakdown": breakdown,
        }
    except Exception as e:
        log.error(f"hash-index search {title!r} S{season}E{episode}: {e}", exc_info=True)
        raise HTTPException(500, str(e))


# ── /api/hash-index/reindex-title ────────────────────────────────────────────

@app.post("/api/hash-index/reindex-title")
async def api_hash_index_reindex_title(request: Request, background_tasks: BackgroundTasks):
    """Re-index a single title — fires _index_movie_hashes or _index_series_hashes."""
    body  = await request.json()
    title = body.get("title", "").strip()
    if not title:
        raise HTTPException(400, "title required")

    hi: HashIndex = getattr(request.app.state, "hash_index", None)
    db: CacheDB   = request.app.state.db
    if not hi:
        raise HTTPException(503, "Hash index not initialised")

    # Try exact match first, then case-insensitive scan of library
    lib_entry = None
    for _le in db.fake_library_list():
        if _le["title"].lower() == title.lower():
            lib_entry = _le
            break
    if not lib_entry:
        raise HTTPException(404, f"'{title}' not found in library")

    if lib_entry["media_type"] == "movie":
        background_tasks.add_task(
            _index_movie_hashes, request.app, title, lib_entry.get("year")
        )
    else:
        is_ended     = lib_entry.get("status", "") in ("ended", "cancelled", "canceled")
        season_count = lib_entry.get("season_count", 1) or 1
        background_tasks.add_task(
            _index_series_hashes, request.app, title, lib_entry.get("year"),
            season_count, is_ended, []
        )

    return {"status": "ok", "message": f"Re-indexing '{title}'"}
