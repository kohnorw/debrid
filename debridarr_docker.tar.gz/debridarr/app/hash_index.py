"""
hash_index.py — SQLite torrent hash index for Debridarr.

When a movie or series is added to the library, we search AllDebrid
immediately and store the best cached torrent hash for every piece of
content (movie, season pack, episode pack) in this table.

On play:
  1. Look up hash in this table  — O(1), no network call
  2. If found: add_magnet(hash) and start streaming instantly
  3. If not found: fall back to legacy search_cached flow

Schema
------
  torrent_hash_index
    id            — autoincrement PK
    media_type    — 'movie' | 'season' | 'episode'
    title         — show/movie title (normalised lower)
    year          — release year (nullable)
    season        — season number (0 = series-level / movie)
    episode       — episode number (0 = pack / no episode)
    info_hash     — 40-char hex AllDebrid info_hash
    magnet        — full magnet URI
    torrent_name  — human-readable torrent name from TPB
    quality       — detected quality string (1080p, 720p, …)
    strategy      — search strategy that found this hash
    checked_at    — ISO datetime of last AllDebrid cache check
    is_cached     — 1 if AllDebrid confirmed cached, 0 otherwise
    UNIQUE(title, season, episode, info_hash)

NOTE: season and episode use 0 (not NULL) to represent "not applicable"
so that the UNIQUE constraint works correctly (SQLite NULLs are never equal).

Logging
-------
Every hash index event is written to a dedicated rotating log file at
/data/logs/hash_index.log (10 MB per file, 7 backups kept).

Format:
  TIMESTAMP [ACTION] title | season/ep | quality | hash[:8] | torrent_name | strategy
"""

import logging
import logging.handlers
import os
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

log = logging.getLogger("debridarr.hash_index")

# ── Dedicated hash-index event logger ─────────────────────────────────────────
# Separate from the main application log so the user can tail just hash events.
_hash_log: Optional[logging.Logger] = None


def _get_hash_log() -> logging.Logger:
    """Return (and lazily create) the dedicated hash-index file logger."""
    global _hash_log
    if _hash_log is not None:
        return _hash_log

    logger = logging.getLogger("debridarr.hash_index.events")
    logger.setLevel(logging.DEBUG)
    logger.propagate = False  # don't double-print to main log

    log_dir = Path("/data/logs")
    try:
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / "hash_index.log"
        handler = logging.handlers.RotatingFileHandler(
            log_path,
            maxBytes=10 * 1024 * 1024,  # 10 MB
            backupCount=7,
            encoding="utf-8",
        )
        handler.setFormatter(logging.Formatter(
            "%(asctime)s %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        ))
        logger.addHandler(handler)
        log.info(f"🗄️  Hash index log: {log_path}")
    except Exception as e:
        # If /data/logs isn't writable, fall back silently to main log
        log.warning(f"Could not create hash_index.log: {e} — events go to main log only")
        fallback = logging.StreamHandler()
        fallback.setFormatter(logging.Formatter("%(message)s"))
        logger.addHandler(fallback)

    _hash_log = logger
    return _hash_log


def _ep_label(season: Optional[int], episode: Optional[int]) -> str:
    """Human-readable episode label: S01E03, S01 (pack), movie, series."""
    if not season and not episode:
        return "movie/series"
    if season and episode:
        return f"S{season:02d}E{episode:02d}"
    if season:
        return f"S{season:02d} (pack)"
    return "series pack"


# Re-check hashes after this many hours (AllDebrid cache status can change)
RECHECK_HOURS = 6

# Sentinel value for "no season/episode" — avoids NULL UNIQUE issues
_NO_VAL = 0


def _s(v: Optional[int]) -> int:
    """Convert None → 0 for storage."""
    return v if v is not None else _NO_VAL


def _u(v: int) -> Optional[int]:
    """Convert 0 → None for retrieval."""
    return None if v == _NO_VAL else v


class HashIndex:
    """
    Lightweight SQLite store for pre-resolved torrent hashes.

    The index shares the same database file as CacheDB but lives in its
    own table so it can be initialised independently or alongside it.
    """

    def __init__(self, db_path: str):
        self.db_path = db_path

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        return conn

    def init(self):
        """Create/migrate the torrent_hash_index table."""
        with self._connect() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS torrent_hash_index (
                    id            INTEGER PRIMARY KEY AUTOINCREMENT,
                    media_type    TEXT NOT NULL,
                    title         TEXT NOT NULL,
                    year          INTEGER,
                    season        INTEGER NOT NULL DEFAULT 0,
                    episode       INTEGER NOT NULL DEFAULT 0,
                    info_hash     TEXT NOT NULL,
                    magnet        TEXT NOT NULL,
                    torrent_name  TEXT NOT NULL,
                    quality       TEXT NOT NULL DEFAULT 'unknown',
                    strategy      TEXT NOT NULL DEFAULT 'unknown',
                    checked_at    TEXT NOT NULL,
                    is_cached     INTEGER NOT NULL DEFAULT 0,
                    UNIQUE(title, season, episode, info_hash)
                )
            """)
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_thi_lookup "
                "ON torrent_hash_index(title, season, episode)"
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_thi_hash "
                "ON torrent_hash_index(info_hash)"
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_thi_cached "
                "ON torrent_hash_index(is_cached, checked_at)"
            )
            # Migration: add last_used if not present (existing installs)
            existing_cols = {r[1] for r in conn.execute("PRAGMA table_info(torrent_hash_index)").fetchall()}
            if "last_used" not in existing_cols:
                conn.execute("ALTER TABLE torrent_hash_index ADD COLUMN last_used TEXT")
                log.info("HashIndex migration: added last_used column")
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_thi_last_used "
                "ON torrent_hash_index(last_used)"
            )
        # Initialise the file logger now that we know /data exists
        _get_hash_log()
        log.info(f"HashIndex ready at {self.db_path}")

    # ── Writes ────────────────────────────────────────────────────────────────

    def upsert(
        self,
        *,
        media_type: str,
        title: str,
        year: Optional[int],
        season: Optional[int],
        episode: Optional[int],
        info_hash: str,
        magnet: str,
        torrent_name: str,
        quality: str,
        strategy: str,
        is_cached: bool,
    ) -> None:
        """Insert or update a hash entry, logging the event."""
        now = datetime.utcnow().isoformat()
        title_norm = title.lower().strip()

        # Detect insert vs update BEFORE executing so we can log correctly
        is_new = True
        with self._connect() as conn:
            existing = conn.execute(
                "SELECT is_cached FROM torrent_hash_index "
                "WHERE title=? AND season=? AND episode=? AND info_hash=?",
                (title_norm, _s(season), _s(episode), info_hash.lower()),
            ).fetchone()
            is_new = existing is None
            was_cached = bool(existing["is_cached"]) if existing else None

            conn.execute("""
                INSERT INTO torrent_hash_index
                    (media_type, title, year, season, episode,
                     info_hash, magnet, torrent_name, quality,
                     strategy, checked_at, is_cached)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(title, season, episode, info_hash) DO UPDATE SET
                    torrent_name = excluded.torrent_name,
                    quality      = excluded.quality,
                    strategy     = excluded.strategy,
                    checked_at   = excluded.checked_at,
                    is_cached    = excluded.is_cached,
                    magnet       = excluded.magnet
            """, (
                media_type, title_norm, year,
                _s(season), _s(episode),
                info_hash.lower(), magnet, torrent_name, quality,
                strategy, now, 1 if is_cached else 0,
            ))

        # ── Log the event ─────────────────────────────────────────────────────
        hl = _get_hash_log()
        ep_lbl    = _ep_label(season, episode)
        hash_abbr = info_hash[:8].upper()
        cached_str = "cached=YES" if is_cached else "cached=NO "
        year_str   = str(year) if year else "????"

        if is_new:
            action = "ADD   "
            hl.info(
                f"[{action}] {title!r} ({year_str}) {ep_lbl} | "
                f"{quality} | {cached_str} | {hash_abbr} | "
                f"{torrent_name} | strategy={strategy}"
            )
            log.info(
                f"🗄️  HashIndex ADD: {title!r} {ep_lbl} — "
                f"{torrent_name} ({quality}, {cached_str.strip()})"
            )
        else:
            # Update: only log if cached status changed (reduces noise)
            if was_cached != is_cached:
                action = "UPDATE"
                new_state = "cached=YES" if is_cached else "cached=NO (evicted)"
                hl.info(
                    f"[{action}] {title!r} ({year_str}) {ep_lbl} | "
                    f"{quality} | {new_state} | {hash_abbr} | {torrent_name}"
                )
                log.info(
                    f"🗄️  HashIndex UPDATE: {title!r} {ep_lbl} — "
                    f"{hash_abbr} → {new_state}"
                )
            else:
                # Routine refresh (checked_at bump) — debug only
                hl.debug(
                    f"[TOUCH ] {title!r} ({year_str}) {ep_lbl} | "
                    f"{hash_abbr} | {cached_str}"
                )

    def mark_uncached(self, info_hash: str) -> None:
        """Mark a hash as no longer cached on AllDebrid, logging the event."""
        now = datetime.utcnow().isoformat()
        hl = _get_hash_log()

        with self._connect() as conn:
            # Fetch row details for logging before updating
            row = conn.execute(
                "SELECT title, year, season, episode, torrent_name, quality "
                "FROM torrent_hash_index WHERE info_hash=?",
                (info_hash.lower(),),
            ).fetchone()

            conn.execute(
                "UPDATE torrent_hash_index SET is_cached=0, checked_at=? WHERE info_hash=?",
                (now, info_hash.lower()),
            )

        if row:
            ep_lbl = _ep_label(_u(row["season"]), _u(row["episode"]))
            title  = row["title"]
            year   = row["year"] or "????"
            hl.info(
                f"[EVICT ] {title!r} ({year}) {ep_lbl} | "
                f"{row['quality']} | {info_hash[:8].upper()} | {row['torrent_name']}"
            )
            log.info(
                f"🗄️  HashIndex EVICT: {title!r} {ep_lbl} — "
                f"{info_hash[:8].upper()} no longer on AllDebrid"
            )
        else:
            hl.info(f"[EVICT ] hash={info_hash[:8].upper()} (no DB row found)")

    def delete_for_title(self, title: str, media_type: Optional[str] = None) -> int:
        """Remove all hash entries for a title, logging the event."""
        title_norm = title.lower().strip()
        hl = _get_hash_log()

        with self._connect() as conn:
            # Count and list what we're about to delete for the log
            if media_type:
                rows = conn.execute(
                    "SELECT season, episode, quality, torrent_name FROM torrent_hash_index "
                    "WHERE title=? AND media_type=?",
                    (title_norm, media_type),
                ).fetchall()
                r = conn.execute(
                    "DELETE FROM torrent_hash_index WHERE title=? AND media_type=?",
                    (title_norm, media_type),
                )
            else:
                rows = conn.execute(
                    "SELECT season, episode, quality, torrent_name FROM torrent_hash_index "
                    "WHERE title=?",
                    (title_norm,),
                ).fetchall()
                r = conn.execute(
                    "DELETE FROM torrent_hash_index WHERE title=?",
                    (title_norm,),
                )
            count = r.rowcount

        hl.info(
            f"[DELETE] {title!r} — removed {count} hash entr{'y' if count==1 else 'ies'}"
            + (f" (type={media_type})" if media_type else "")
        )
        for row in rows:
            ep_lbl = _ep_label(_u(row["season"]), _u(row["episode"]))
            hl.info(
                f"  └─ {ep_lbl} | {row['quality']} | {row['torrent_name']}"
            )
        log.info(f"🗄️  HashIndex DELETE: {title!r} — {count} entries removed")
        return count

    def clear(self) -> int:
        """
        Delete every entry in the hash index.
        Returns the number of rows removed.
        """
        hl = _get_hash_log()
        with self._connect() as conn:
            before = conn.execute("SELECT COUNT(*) FROM torrent_hash_index").fetchone()[0]
            conn.execute("DELETE FROM torrent_hash_index")
        hl.info(f"[CLEAR ] Hash index cleared — {before} entr{'y' if before == 1 else 'ies'} removed")
        log.info(f"🗄️  HashIndex cleared: {before} entries removed")
        return before

    # ── Reads ─────────────────────────────────────────────────────────────────

    def _row_to_dict(self, row) -> dict:
        d = dict(row)
        if d.get("season") == _NO_VAL:
            d["season"] = None
        if d.get("episode") == _NO_VAL:
            d["episode"] = None
        return d

    def lookup(
        self,
        title: str,
        season: Optional[int] = None,
        episode: Optional[int] = None,
        *,
        cached_only: bool = True,
    ) -> list[dict]:
        """
        Return candidate hashes ordered by priority:
          1. Exact episode match  2. Season pack  3. Series pack

        Logs HIT or MISS to the hash index log.
        """
        title_norm = title.lower().strip()
        sn  = _s(season)
        epn = _s(episode)

        with self._connect() as conn:
            if sn == 0 and epn == 0:
                rows = conn.execute(
                    """
                    SELECT * FROM torrent_hash_index
                    WHERE title=?
                      AND season=0 AND episode=0
                      AND (? = 0 OR is_cached=1)
                    ORDER BY
                        CASE quality
                            WHEN '2160p' THEN 0 WHEN '4k' THEN 0
                            WHEN '1080p' THEN 1 WHEN '720p' THEN 2
                            ELSE 3
                        END,
                        is_cached DESC
                    """,
                    (title_norm, 1 if cached_only else 0),
                ).fetchall()
            else:
                rows = conn.execute(
                    """
                    SELECT * FROM torrent_hash_index
                    WHERE title=?
                      AND (? = 0 OR is_cached=1)
                      AND (
                          (season=? AND episode=?)
                       OR (season=? AND episode=0)
                       OR (season=0  AND episode=0)
                      )
                    ORDER BY
                        CASE
                            WHEN season=? AND episode=? THEN 0
                            WHEN season=? AND episode=0  THEN 1
                            ELSE 2
                        END,
                        CASE quality
                            WHEN '2160p' THEN 0 WHEN '4k' THEN 0
                            WHEN '1080p' THEN 1 WHEN '720p' THEN 2
                            ELSE 3
                        END,
                        is_cached DESC
                    """,
                    (
                        title_norm,
                        1 if cached_only else 0,
                        sn, epn,
                        sn,
                        sn, epn,
                        sn,
                    ),
                ).fetchall()

        results = [self._row_to_dict(r) for r in rows]
        hl = _get_hash_log()
        ep_lbl = _ep_label(season, episode)

        if results:
            best = results[0]
            match_type = (
                "exact"       if (best.get("season") == season and best.get("episode") == episode)
                else "season pack" if best.get("season") == season
                else "series pack"
            )
            hl.info(
                f"[HIT   ] {title!r} {ep_lbl} → "
                f"{best['torrent_name']} ({best['quality']}, {match_type})"
            )
            # Stamp last_used on every result that contributed to a HIT
            now_str = datetime.utcnow().isoformat()
            hit_hashes = [r["info_hash"] for r in results if r.get("info_hash")]
            if hit_hashes:
                with self._connect() as conn:
                    conn.executemany(
                        "UPDATE torrent_hash_index SET last_used=? WHERE info_hash=?",
                        [(now_str, h) for h in hit_hashes],
                    )
        else:
            hl.info(f"[MISS  ] {title!r} {ep_lbl} — not in index, live search needed")

        return results

    def stale_cached(self, hours: int = RECHECK_HOURS) -> list[dict]:
        """Return hashes that haven't been re-verified recently."""
        cutoff = (datetime.utcnow() - timedelta(hours=hours)).isoformat()
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM torrent_hash_index WHERE is_cached=1 AND checked_at < ?",
                (cutoff,),
            ).fetchall()
            return [self._row_to_dict(r) for r in rows]

    def all_for_title(self, title: str) -> list[dict]:
        title_norm = title.lower().strip()
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM torrent_hash_index WHERE title=? ORDER BY season, episode",
                (title_norm,),
            ).fetchall()
            return [self._row_to_dict(r) for r in rows]

    def stats(self) -> dict:
        with self._connect() as conn:
            total   = conn.execute("SELECT COUNT(*) FROM torrent_hash_index").fetchone()[0]
            cached  = conn.execute("SELECT COUNT(*) FROM torrent_hash_index WHERE is_cached=1").fetchone()[0]
            movies  = conn.execute("SELECT COUNT(*) FROM torrent_hash_index WHERE media_type='movie'").fetchone()[0]
            seasons = conn.execute("SELECT COUNT(*) FROM torrent_hash_index WHERE media_type='season'").fetchone()[0]
            eps     = conn.execute("SELECT COUNT(*) FROM torrent_hash_index WHERE media_type='episode'").fetchone()[0]
        return {
            "total": total, "cached": cached,
            "movies": movies, "seasons": seasons, "episodes": eps,
        }

    def purge_unused(self, months: int = 6) -> dict:
        """
        Delete hash entries that have not been used for playback in `months` months.

        A row is considered unused if:
          - last_used IS NULL  (never hit since last_used column was added)
            AND checked_at is older than `months` months
          - OR last_used < cutoff

        This keeps the index lean and removes stale torrents that the user
        no longer watches. Returns {"deleted": N, "remaining": N}.
        """
        cutoff = (datetime.utcnow() - timedelta(days=months * 30)).isoformat()
        hl = _get_hash_log()
        with self._connect() as conn:
            # Preview what will be deleted for logging
            to_delete = conn.execute(
                """
                SELECT title, season, episode, quality, torrent_name
                FROM torrent_hash_index
                WHERE (last_used IS NULL AND checked_at < ?)
                   OR (last_used IS NOT NULL AND last_used < ?)
                """,
                (cutoff, cutoff),
            ).fetchall()

            if not to_delete:
                log.info(f"🗄️  HashIndex purge: nothing to remove (>{months}m unused)")
                return {"deleted": 0, "remaining": self.stats()["total"]}

            r = conn.execute(
                """
                DELETE FROM torrent_hash_index
                WHERE (last_used IS NULL AND checked_at < ?)
                   OR (last_used IS NOT NULL AND last_used < ?)
                """,
                (cutoff, cutoff),
            )
            deleted = r.rowcount
            remaining = conn.execute("SELECT COUNT(*) FROM torrent_hash_index").fetchone()[0]

        # Log summary
        hl.info(
            f"[PURGE ] Removed {deleted} unused entr{'y' if deleted==1 else 'ies'} "
            f"(>{months} months, cutoff {cutoff[:10]}) — {remaining} remaining"
        )
        for row in to_delete[:20]:  # log first 20 for reference
            ep_lbl = _ep_label(_u(row["season"]), _u(row["episode"]))
            hl.info(f"  └─ {row['title']!r} {ep_lbl} | {row['quality']} | {row['torrent_name']}")
        if len(to_delete) > 20:
            hl.info(f"  └─ … and {len(to_delete)-20} more")
        log.info(f"🗄️  HashIndex purge: removed {deleted} unused entries, {remaining} remaining")
        return {"deleted": deleted, "remaining": remaining}

    def recent_log_lines(self, n: int = 200) -> list[str]:
        """
        Read the last n lines from hash_index.log for the UI viewer.
        Returns lines newest-first.
        """
        log_path = Path("/data/logs/hash_index.log")
        if not log_path.exists():
            return ["(log file not yet created)"]
        try:
            # Efficient tail — read last chunk of file
            with open(log_path, "rb") as f:
                f.seek(0, 2)
                size = f.tell()
                # Read last 128 KB which is plenty for 200 lines
                chunk = min(size, 128 * 1024)
                f.seek(size - chunk)
                raw = f.read().decode("utf-8", errors="replace")
            lines = raw.splitlines()
            # Return last n, newest first
            return list(reversed(lines[-n:])) if lines else []
        except Exception as e:
            return [f"(error reading log: {e})"]
