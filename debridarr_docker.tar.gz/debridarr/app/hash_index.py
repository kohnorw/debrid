"""
hash_index.py — Source of truth for all media resolution.

Maps:
    Movie / TV Show / Season / Episode
    →
    Hash · File · Provider · Status · Score

The index is the ONLY path consulted when a user hits play.
Nothing missing from the index gets a placeholder created.

Scoring pipeline (higher = better candidate):
    Stage 1 — Metadata match     40 pts max
    Stage 2 — Pack intelligence  30 pts max
    Stage 3 — File verification  50 pts max

The index grows on startup and gets smarter over time via background
recheck loops. add_magnet() is called exactly once — when the user
presses play and the index has a hit.
"""

from __future__ import annotations

import logging
import re
import sqlite3
import time
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

log = logging.getLogger("debridarr.hash_index")

# ── Score weights ─────────────────────────────────────────────────────────────

SCORE_META_TITLE_EXACT    = 20   # Stage 1: exact title match
SCORE_META_TITLE_NORM     = 10   # Stage 1: normalised match
SCORE_META_YEAR_MATCH     = 10   # Stage 1: year present and correct
SCORE_META_QUALITY_PREF   = 10   # Stage 1: preferred quality (1080p default)
SCORE_META_QUALITY_OK     = 5    # Stage 1: acceptable quality

SCORE_PACK_SERIES         = 30   # Stage 2: series pack (whole show)
SCORE_PACK_SEASON         = 20   # Stage 2: season pack
SCORE_PACK_EPISODE        = 10   # Stage 2: single episode
SCORE_PACK_MULTI_FILE     = 5    # Stage 2: bonus for >1 file in pack

SCORE_FILE_CACHED         = 40   # Stage 3: confirmed cached on AllDebrid
SCORE_FILE_SIZE_LARGE     = 10   # Stage 3: file >4 GB (likely good encode)

# ── Stage 4: source / release-quality (added to make ranking actually discriminate)
SCORE_SOURCE_REMUX        = 25   # untouched disc rip — gold standard
SCORE_SOURCE_BLURAY       = 18   # BluRay / BDRip encode
SCORE_SOURCE_WEBDL        = 15   # WEB-DL (clean stream rip)
SCORE_SOURCE_WEBRIP       = 10   # WEBRip (re-encoded stream)
SCORE_SOURCE_HDTV         = 3    # HDTV/PDTV/DSR rip
SCORE_SOURCE_DVDRIP       = 2

# Codec preference. HEVC/x265 favored for 2160p; x264 universally compatible.
SCORE_CODEC_HEVC          = 8    # x265 / HEVC / h265
SCORE_CODEC_AVC           = 5    # x264 / h264 / AVC
SCORE_CODEC_AV1           = 6

# HDR / Dolby Vision (additive — these come with HDR content)
SCORE_DV                  = 10
SCORE_HDR10P              = 6
SCORE_HDR                 = 4

# Audio (highest matching wins, not additive)
SCORE_AUDIO_ATMOS         = 8
SCORE_AUDIO_TRUEHD        = 7
SCORE_AUDIO_DTSHD         = 6
SCORE_AUDIO_DDP           = 4    # DD+ / EAC3 / E-AC3
SCORE_AUDIO_DTS           = 3
SCORE_AUDIO_AAC           = 1

# Release group reputation — known-good groups encode well, well-known to scene
SCORE_GROUP_TIER1         = 12   # top-tier scene groups (REMUX/encode masters)
SCORE_GROUP_TIER2         = 6

# Seeders availability — a sanity signal that the torrent is real and downloadable
SCORE_SEEDERS_HIGH        = 6    # 100+ seeders
SCORE_SEEDERS_MEDIUM      = 3    # 20-99 seeders

# Penalties — anything below crosses into negative
PEN_GARBAGE_SOURCE        = -100 # CAM / TS / TC / HC / R5 / WORKPRINT / TELESYNC
PEN_NON_ENGLISH           = -15  # SUBBED / DUBBED / HARDSUB for English content
PEN_LOW_QUALITY_CODEC     = -10  # XVid / DivX

SCORE_MAX = (
    SCORE_META_TITLE_EXACT + SCORE_META_YEAR_MATCH + SCORE_META_QUALITY_PREF
    + SCORE_PACK_SERIES + SCORE_PACK_MULTI_FILE
    + SCORE_FILE_CACHED + SCORE_FILE_SIZE_LARGE
    + SCORE_SOURCE_REMUX + SCORE_CODEC_HEVC + SCORE_DV
    + SCORE_AUDIO_ATMOS + SCORE_GROUP_TIER1 + SCORE_SEEDERS_HIGH
)


# ── Source / codec / group regex tables (compiled once) ───────────────────────

_RX_REMUX     = re.compile(r"\bremux\b", re.I)
_RX_BLURAY    = re.compile(r"\b(bluray|bdrip|brrip|bd[._-]?rip|blu[._-]?ray)\b", re.I)
_RX_WEBDL     = re.compile(r"\b(web[._-]?dl|webdl|amzn|nf|atvp|hmax|dsnp)\b", re.I)
_RX_WEBRIP    = re.compile(r"\bweb[._-]?rip\b", re.I)
_RX_HDTV      = re.compile(r"\b(hdtv|pdtv|dsr)\b", re.I)
_RX_DVDRIP    = re.compile(r"\b(dvdrip|dvd[._-]?rip|dvd5|dvd9)\b", re.I)

_RX_GARBAGE   = re.compile(
    r"(?ix)(?:^|[\s._\-\[\]()])"
    r"(cam(?:rip)?|hdcam|camrip|ts|hdts|telesync|tele[._\- ]?sync|"
    r"ts[._\- ]?rip|tc|telecine|r5|dvdscr|dvd[._\- ]?scr|"
    r"screener|scr|workprint|wp|hc[._\- ]?sub|hardsub|hardcoded)"
    r"(?:$|[\s._\-\[\]()])"
)

_RX_HEVC      = re.compile(r"\b(hevc|x265|h\.?265)\b", re.I)
_RX_AVC       = re.compile(r"\b(x264|h\.?264|avc)\b", re.I)
_RX_AV1       = re.compile(r"\bav1\b", re.I)
_RX_XVID      = re.compile(r"\b(xvid|divx)\b", re.I)

_RX_DV        = re.compile(r"\b(dolby[._-]?vision|dovi|dv|dvhdr)\b", re.I)
_RX_HDR10P    = re.compile(r"\b(hdr10\+|hdr10plus|hdr10p)\b", re.I)
_RX_HDR       = re.compile(r"\b(hdr|hdr10|sdr.*hdr|2160p.*hdr)\b", re.I)

_RX_ATMOS     = re.compile(r"\batmos\b", re.I)
_RX_TRUEHD    = re.compile(r"\btruehd\b", re.I)
_RX_DTSHD     = re.compile(r"\b(dts[._-]?hd|dts[._-]?ma|dts[._-]?x)\b", re.I)
_RX_DDP       = re.compile(r"\b(ddp|dd\+|e[._-]?ac3|eac3)\b", re.I)
_RX_DTS       = re.compile(r"\bdts\b", re.I)
_RX_AAC       = re.compile(r"\baac(2\.?0)?\b", re.I)

_RX_NON_EN    = re.compile(r"\b(subbed|hardsub|hardsubbed|dubbed|multi[._-]?sub)\b", re.I)
_RX_PROPER    = re.compile(r"\b(proper|repack)\b", re.I)

# Tier-1 release groups: very high-quality encodes / scene staples
_GROUPS_T1 = {
    "framestor", "fraim", "ctrlhd", "ntb", "flux", "kralimarko", "ebp",
    "decibel", "monkee", "ggez", "ggwp", "trollhd", "amiable", "geckos",
    "rovers", "sparks", "drones", "edge2020", "kingdom", "playnow", "ion265",
    "qxr", "tigole", "joy", "psa", "rarbg", "tepes", "successfulcrab", "ethel",
}
_GROUPS_T2 = {
    "yify", "yts", "evo", "fum", "deflate", "mzabi", "playweb", "skgtv",
    "kogi", "tbs", "rmteam", "f1nal", "kitsune", "judas", "mkvcage",
    "syncopy", "ftw", "shitbox", "telly", "mempheaven", "trump", "ion10",
}


def _detect_source(name: str) -> tuple[str, int]:
    """Identify the encode source. Returns (label, score)."""
    if _RX_REMUX.search(name):     return "REMUX",   SCORE_SOURCE_REMUX
    if _RX_BLURAY.search(name):    return "BluRay",  SCORE_SOURCE_BLURAY
    if _RX_WEBDL.search(name):     return "WEB-DL",  SCORE_SOURCE_WEBDL
    if _RX_WEBRIP.search(name):    return "WEBRip",  SCORE_SOURCE_WEBRIP
    if _RX_HDTV.search(name):      return "HDTV",    SCORE_SOURCE_HDTV
    if _RX_DVDRIP.search(name):    return "DVDRip",  SCORE_SOURCE_DVDRIP
    return "unknown", 0


def _detect_codec(name: str) -> tuple[str, int]:
    if _RX_HEVC.search(name):  return "HEVC", SCORE_CODEC_HEVC
    if _RX_AV1.search(name):   return "AV1",  SCORE_CODEC_AV1
    if _RX_AVC.search(name):   return "AVC",  SCORE_CODEC_AVC
    if _RX_XVID.search(name):  return "XVID", PEN_LOW_QUALITY_CODEC
    return "unknown", 0


def _detect_hdr(name: str) -> int:
    """HDR additive bonus — DV+HDR is common, both add."""
    pts = 0
    if _RX_DV.search(name):     pts += SCORE_DV
    if _RX_HDR10P.search(name): pts += SCORE_HDR10P
    elif _RX_HDR.search(name):  pts += SCORE_HDR
    return pts


def _detect_audio(name: str) -> tuple[str, int]:
    """Audio scoring — highest-tier matching wins, not additive."""
    if _RX_ATMOS.search(name):  return "Atmos",  SCORE_AUDIO_ATMOS
    if _RX_TRUEHD.search(name): return "TrueHD", SCORE_AUDIO_TRUEHD
    if _RX_DTSHD.search(name):  return "DTS-HD", SCORE_AUDIO_DTSHD
    if _RX_DDP.search(name):    return "DDP",    SCORE_AUDIO_DDP
    if _RX_DTS.search(name):    return "DTS",    SCORE_AUDIO_DTS
    if _RX_AAC.search(name):    return "AAC",    SCORE_AUDIO_AAC
    return "unknown", 0


def _detect_group(name: str) -> tuple[str, int]:
    """Release group is usually the trailing -GROUP token in the name."""
    m = re.search(r"-([A-Za-z0-9]+)$", name.replace(".mkv","").replace(".mp4","").strip())
    if not m:
        return "", 0
    g = m.group(1).lower()
    if g in _GROUPS_T1: return g, SCORE_GROUP_TIER1
    if g in _GROUPS_T2: return g, SCORE_GROUP_TIER2
    return g, 0


# ── Schema ────────────────────────────────────────────────────────────────────

_DDL = """
CREATE TABLE IF NOT EXISTS hash_index (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Media identity
    media_type    TEXT    NOT NULL,   -- 'movie' | 'episode' | 'season' | 'series'
    title         TEXT    NOT NULL,
    title_norm    TEXT    NOT NULL,   -- normalised for search
    year          INTEGER,
    season        INTEGER,
    episode       INTEGER,

    -- Hash / torrent
    info_hash     TEXT    NOT NULL UNIQUE,
    magnet        TEXT    NOT NULL,
    torrent_name  TEXT,
    file_count    INTEGER DEFAULT 1,
    file_size     INTEGER DEFAULT 0,  -- bytes, largest file in torrent

    -- Provider
    provider      TEXT    DEFAULT 'alldebrid',
    is_cached     INTEGER DEFAULT 0,  -- 1 = confirmed cached on AllDebrid

    -- Scoring
    score         INTEGER DEFAULT 0,
    quality       TEXT    DEFAULT 'unknown',
    strategy      TEXT    DEFAULT 'unknown',

    -- Lifecycle
    last_checked  INTEGER,  -- unix timestamp of last AllDebrid availability check
    last_used     INTEGER,  -- unix timestamp last time this hash served a play
    created_at    INTEGER   DEFAULT (strftime('%s','now')),
    updated_at    INTEGER   DEFAULT (strftime('%s','now'))
    -- NOTE: `blacklisted` column added below via migration so existing DBs work.
);

CREATE INDEX IF NOT EXISTS ix_hi_title_norm  ON hash_index (title_norm);
CREATE INDEX IF NOT EXISTS ix_hi_type_season ON hash_index (media_type, season, episode);
CREATE INDEX IF NOT EXISTS ix_hi_hash        ON hash_index (info_hash);
CREATE INDEX IF NOT EXISTS ix_hi_cached      ON hash_index (is_cached, score DESC);
CREATE INDEX IF NOT EXISTS ix_hi_last_used   ON hash_index (last_used);
-- ix_hi_blacklist created in _init after the column migration runs.

CREATE TABLE IF NOT EXISTS hash_index_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    ts         INTEGER DEFAULT (strftime('%s','now')),
    event      TEXT NOT NULL,  -- ADD | UPDATE | HIT | MISS | EVICT | DELETE | TOUCH | RECHECK
    title      TEXT,
    info_hash  TEXT,
    detail     TEXT
);
CREATE INDEX IF NOT EXISTS ix_hlog_ts ON hash_index_log (ts DESC);
"""


# ── Helpers ───────────────────────────────────────────────────────────────────

def _norm(s: str) -> str:
    """Normalise a title for fuzzy matching."""
    if not s:
        return ""
    s = s.lower()
    s = re.sub(r"['\u2018\u2019\u201c\u201d]", "", s)
    s = re.sub(r"[^a-z0-9 ]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _detect_quality(name: str) -> str:
    n = name.lower()
    for q in ("2160p", "4k", "uhd", "1080p", "720p", "480p"):
        if q in n:
            return q
    return "unknown"


# ── Scoring pipeline ──────────────────────────────────────────────────────────

def score_candidate(
    *,
    title: str,
    year: Optional[int],
    torrent_name: str,
    media_type: str,
    quality: str,
    is_cached: bool,
    file_count: int = 1,
    file_size: int = 0,
    seeders: int = 0,
    preferred_quality: str = "1080p",
) -> int:
    """
    Multi-stage scoring pipeline. Returns the total score for the candidate.

    Stage 1 — Metadata match     (title, year, quality)
    Stage 2 — Pack intelligence  (series/season/episode, multi-file)
    Stage 3 — File verification  (cached, file size)
    Stage 4 — Source & encode    (REMUX > BluRay > WEB-DL > ..., codec, HDR)
    Stage 5 — Audio              (Atmos > TrueHD > DTS-HD > DDP > ...)
    Stage 6 — Release group      (tier-1 scene encoders favoured)
    Stage 7 — Health             (seeders if reported by indexer)
    Garbage rejection            (CAM/TS/HC-SUB/etc → -100 → caller drops)

    The score can go negative for garbage releases (CAM, hard-coded subs);
    callers should treat anything < 0 as "do not use".
    """
    pts = 0
    name      = torrent_name or ""
    name_norm = _norm(name)
    title_norm = _norm(title)

    # ── Stage 0: Garbage rejection ────────────────────────────────────────────
    # CAM/TS/etc are unwatchable — return immediately with a strongly negative
    # score so they never beat a legitimate cached hit even if everything else
    # is missing on the legit one.
    if _RX_GARBAGE.search(name):
        return PEN_GARBAGE_SOURCE

    # ── Stage 1: Metadata match ───────────────────────────────────────────────
    if title_norm and title_norm in name_norm:
        pts += SCORE_META_TITLE_EXACT
    elif title_norm and all(w in name_norm for w in title_norm.split()):
        pts += SCORE_META_TITLE_NORM

    if year and str(year) in name:
        pts += SCORE_META_YEAR_MATCH

    if quality == preferred_quality:
        pts += SCORE_META_QUALITY_PREF
    elif quality in ("1080p", "720p") and preferred_quality in ("1080p", "720p"):
        pts += SCORE_META_QUALITY_OK

    # ── Stage 2: Pack intelligence ────────────────────────────────────────────
    if media_type == "series":
        pts += SCORE_PACK_SERIES
    elif media_type == "season":
        pts += SCORE_PACK_SEASON
    elif media_type in ("episode", "movie"):
        pts += SCORE_PACK_EPISODE

    if file_count > 1:
        pts += SCORE_PACK_MULTI_FILE

    # ── Stage 3: File verification ────────────────────────────────────────────
    if is_cached:
        pts += SCORE_FILE_CACHED
    if file_size > 4 * 1024 ** 3:
        pts += SCORE_FILE_SIZE_LARGE

    # ── Stage 4: Source / codec / HDR ─────────────────────────────────────────
    _, src_pts = _detect_source(name)
    pts += src_pts
    _, codec_pts = _detect_codec(name)
    pts += codec_pts
    pts += _detect_hdr(name)

    # ── Stage 5: Audio ────────────────────────────────────────────────────────
    _, audio_pts = _detect_audio(name)
    pts += audio_pts

    # ── Stage 6: Release group ────────────────────────────────────────────────
    _, group_pts = _detect_group(name)
    pts += group_pts

    # ── Stage 7: Seeder health ────────────────────────────────────────────────
    if seeders >= 100:
        pts += SCORE_SEEDERS_HIGH
    elif seeders >= 20:
        pts += SCORE_SEEDERS_MEDIUM

    # ── Penalties (additive, applied after positives) ─────────────────────────
    if _RX_NON_EN.search(name):
        pts += PEN_NON_ENGLISH

    return pts


# ── HashIndex ─────────────────────────────────────────────────────────────────

class HashIndex:
    """
    SQLite-backed hash index.

    All writes go through upsert(). All reads go through lookup().
    The only place add_magnet() is called is in resolve_on_play()
    (in main.py), which consumes the top-scored cached entry.
    """

    def __init__(self, db_path: str):
        self.db_path = db_path
        import threading
        self._tl = threading.local()
        self._lookup_cache: dict[tuple, tuple[float, list]] = {}
        self._cache_ttl = 5.0
        self._init()

    # ── Internals ──────────────────────────────────────────────────────────────

    @contextmanager
    def _conn(self):
        """Thread-local connection — avoids connect/close overhead on every call."""
        import threading
        tl = self._tl
        if not hasattr(tl, "conn") or tl.conn is None:
            tl.conn = sqlite3.connect(self.db_path, timeout=30,
                                      check_same_thread=False)
            tl.conn.row_factory = sqlite3.Row
            tl.conn.execute("PRAGMA journal_mode=WAL")
            tl.conn.execute("PRAGMA synchronous=NORMAL")   # safe with WAL, much faster
            tl.conn.execute("PRAGMA cache_size=-8000")     # 8 MB page cache
            tl.conn.execute("PRAGMA temp_store=MEMORY")
        conn = tl.conn
        try:
            yield conn
            conn.commit()
        except Exception:
            try: conn.rollback()
            except Exception: pass
            raise

    def _init(self):
        import threading
        self._tl = threading.local()
        with self._conn() as c:
            # Pre-migrate before the bulk DDL runs. If the user previously
            # tried an earlier build that referenced `blacklisted` in the
            # DDL itself, executescript would crash here because the table
            # exists but the column doesn't. Adding the column first heals
            # any half-applied state and lets the DDL pass cleanly.
            table_exists = c.execute(
                "SELECT name FROM sqlite_master "
                "WHERE type='table' AND name='hash_index'"
            ).fetchone() is not None
            if table_exists:
                cols = [r[1] for r in c.execute("PRAGMA table_info(hash_index)").fetchall()]
                if "blacklisted" not in cols:
                    log.info("HashIndex: migrating schema — adding 'blacklisted' column")
                    c.execute("ALTER TABLE hash_index ADD COLUMN blacklisted INTEGER DEFAULT 0")

            # Now safe to run the full DDL on either a fresh DB or a
            # migrated legacy DB.
            c.executescript(_DDL)

            # For fresh DBs the column was just created by executescript with
            # no blacklisted yet — add it now. Idempotent.
            cols = [r[1] for r in c.execute("PRAGMA table_info(hash_index)").fetchall()]
            if "blacklisted" not in cols:
                c.execute("ALTER TABLE hash_index ADD COLUMN blacklisted INTEGER DEFAULT 0")

            # Always ensure the blacklist index exists, regardless of path.
            c.execute("CREATE INDEX IF NOT EXISTS ix_hi_blacklist ON hash_index (blacklisted)")
        # Warm up the lookup cache
        self._lookup_cache: dict[tuple, tuple[float, list]] = {}
        self._cache_ttl = 5.0  # seconds — short enough to stay fresh

    # ── Buffered log — writes are batched to avoid hammering SQLite ──────────
    _log_buf: list = []

    def _log(self, conn, event: str, title: str = "", info_hash: str = "", detail: str = ""):
        """Buffer log entries; flush in batches of 50 or when explicitly called."""
        self._log_buf.append((event, title, info_hash, detail))
        if len(self._log_buf) >= 50:
            self._flush_log(conn)

    def _flush_log(self, conn=None):
        if not self._log_buf:
            return
        rows, self._log_buf = self._log_buf[:], []
        def _do(c):
            c.executemany(
                "INSERT INTO hash_index_log (event, title, info_hash, detail) VALUES (?,?,?,?)",
                rows,
            )
        if conn:
            _do(conn)
        else:
            with self._conn() as c:
                _do(c)

    # ── Write ──────────────────────────────────────────────────────────────────

    def upsert(
        self,
        *,
        media_type: str,
        title: str,
        year: Optional[int],
        season: Optional[int],
        episode: Optional[int],
        info_hash: str,
        magnet: str,
        torrent_name: str,
        quality: str = "unknown",
        strategy: str = "unknown",
        is_cached: bool = False,
        file_count: int = 1,
        file_size: int = 0,
        seeders: int = 0,
        preferred_quality: str = "1080p",
    ) -> int:
        """Insert or update a hash entry. Returns the computed score.

        If a row is already blacklisted, its is_cached / blacklisted state is
        preserved — the hash can never reappear as a usable result even if
        rediscovered via a later search.
        """
        info_hash = info_hash.lower().strip()
        if not info_hash or not magnet:
            return 0

        if quality == "unknown":
            quality = _detect_quality(torrent_name)

        pts = score_candidate(
            title=title,
            year=year,
            torrent_name=torrent_name,
            media_type=media_type,
            quality=quality,
            is_cached=is_cached,
            file_count=file_count,
            file_size=file_size,
            seeders=seeders,
            preferred_quality=preferred_quality,
        )

        if pts < 0:
            log.info(f"HashIndex: rejected banned/garbage release before index: {torrent_name!r}")
            return 0

        now = int(time.time())
        with self._conn() as c:
            existing = c.execute(
                "SELECT id, score, is_cached, blacklisted FROM hash_index WHERE info_hash = ?",
                (info_hash,),
            ).fetchone()

            if existing:
                # If the user blacklisted this hash, preserve that — never let
                # a re-discovery un-blacklist it.
                is_blacklisted = bool(existing["blacklisted"])
                # Only update score if it improved (index gets smarter over time)
                new_score = max(pts, existing["score"])
                # Blacklisted hashes also stay marked uncached so the resolver
                # can't accidentally pick them.
                new_cached = 0 if is_blacklisted else (
                    1 if (is_cached or existing["is_cached"]) else 0
                )
                c.execute(
                    """UPDATE hash_index
                       SET media_type=?, title=?, title_norm=?, year=?, season=?, episode=?,
                           magnet=?, torrent_name=?, file_count=?, file_size=?,
                           is_cached=?, score=?, quality=?, strategy=?,
                           last_checked=?, updated_at=?
                       WHERE info_hash=?""",
                    (
                        media_type, title, _norm(title), year, season, episode,
                        magnet, torrent_name, file_count, file_size,
                        new_cached, new_score, quality, strategy,
                        now, now, info_hash,
                    ),
                )
                detail = f"score={new_score} cached={new_cached} q={quality}"
                if is_blacklisted:
                    detail += " (blacklisted — kept)"
                self._log(c, "UPDATE", title, info_hash, detail)
            else:
                c.execute(
                    """INSERT INTO hash_index
                       (media_type, title, title_norm, year, season, episode,
                        info_hash, magnet, torrent_name, file_count, file_size,
                        provider, is_cached, score, quality, strategy,
                        last_checked, last_used, created_at, updated_at)
                       VALUES (?,?,?,?,?,?, ?,?,?,?,?, 'alldebrid',?,?,?,?, ?,NULL,?,?)""",
                    (
                        media_type, title, _norm(title), year, season, episode,
                        info_hash, magnet, torrent_name, file_count, file_size,
                        1 if is_cached else 0, pts, quality, strategy,
                        now, now, now,
                    ),
                )
                self._log(c, "ADD", title, info_hash,
                          f"score={pts} cached={is_cached} q={quality} type={media_type}")

        log.debug(f"[UPSERT] {title!r} {info_hash[:8]} score={pts} cached={is_cached}")
        self._invalidate_cache(title)
        return pts

    def mark_cached(self, info_hash: str, score_bonus: int = SCORE_FILE_CACHED):
        """Confirm a hash is cached on AllDebrid and bump its score."""
        now = int(time.time())
        with self._conn() as c:
            c.execute(
                """UPDATE hash_index
                   SET is_cached=1, score=score+?, last_checked=?, updated_at=?
                   WHERE info_hash=? AND is_cached=0 AND blacklisted = 0""",
                (score_bonus, now, now, info_hash.lower()),
            )
            self._log(c, "UPDATE", info_hash=info_hash, detail="confirmed cached")

    def mark_uncached(self, info_hash: str):
        """Mark a hash as no longer available on AllDebrid (evicted from cache)."""
        now = int(time.time())
        with self._conn() as c:
            c.execute(
                """UPDATE hash_index
                   SET is_cached=0, last_checked=?, updated_at=?
                   WHERE info_hash=?""",
                (now, now, info_hash.lower()),
            )
            self._log(c, "EVICT", info_hash=info_hash, detail="no longer cached")

    def touch(self, info_hash: str):
        """Record that this hash was used for a successful play."""
        now = int(time.time())
        with self._conn() as c:
            c.execute(
                "UPDATE hash_index SET last_used=?, updated_at=? WHERE info_hash=?",
                (now, now, info_hash.lower()),
            )
            self._log(c, "TOUCH", info_hash=info_hash, detail="served play request")

    # ── Read ───────────────────────────────────────────────────────────────────

    def _invalidate_cache(self, title: str):
        """Invalidate lookup cache for a title after writes."""
        norm = _norm(title)
        stale = [k for k in self._lookup_cache if k[0] == norm]
        for k in stale:
            del self._lookup_cache[k]

    def lookup(
        self,
        title: str,
        *,
        season: Optional[int] = None,
        episode: Optional[int] = None,
        cached_only: bool = True,
        limit: int = 5,
    ) -> list[dict]:
        """
        Return the best candidates for a play request, ordered by score desc.

        For episodes: returns season packs AND series packs AND exact episode
        matches — caller picks the best file from the winning torrent.

        For movies: returns direct movie matches.

        Returns empty list if nothing found (→ triggers live search).
        """
        title_norm = _norm(title)
        now = int(time.time())

        with self._conn() as c:
            if season is not None:
                # Episode lookup — accept: exact episode, season pack, series pack
                rows = c.execute(
                    """SELECT * FROM hash_index
                       WHERE title_norm = ?
                         AND blacklisted = 0
                         AND (
                               (media_type = 'episode' AND season = ? AND episode = ?)
                            OR (media_type = 'season'  AND season = ?)
                            OR (media_type = 'series')
                         )
                         AND (? = 0 OR is_cached = 1)
                       ORDER BY score DESC, is_cached DESC
                       LIMIT ?""",
                    (title_norm, season, episode, season, 1 if cached_only else 0, limit),
                ).fetchall()
            else:
                # Movie lookup
                rows = c.execute(
                    """SELECT * FROM hash_index
                       WHERE title_norm = ?
                         AND media_type = 'movie'
                         AND blacklisted = 0
                         AND (? = 0 OR is_cached = 1)
                       ORDER BY score DESC, is_cached DESC
                       LIMIT ?""",
                    (title_norm, 1 if cached_only else 0, limit),
                ).fetchall()

            if rows:
                self._log(c, "HIT", title, detail=f"season={season} ep={episode} candidates={len(rows)}")
            else:
                self._log(c, "MISS", title, detail=f"season={season} ep={episode}")

        return [dict(r) for r in rows]

    def get_stale(self, older_than_hours: int = 6, limit: int = 200) -> list[dict]:
        """Return hashes not checked recently — for background recheck loop."""
        cutoff = int(time.time()) - older_than_hours * 3600
        with self._conn() as c:
            rows = c.execute(
                """SELECT * FROM hash_index
                   WHERE blacklisted = 0
                     AND (last_checked IS NULL OR last_checked < ?)
                   ORDER BY score DESC
                   LIMIT ?""",
                (cutoff, limit),
            ).fetchall()
        return [dict(r) for r in rows]

    def delete_for_title(self, title: str) -> int:
        """Remove all hash entries for a title. Returns count deleted."""
        with self._conn() as c:
            r = c.execute(
                "DELETE FROM hash_index WHERE title_norm = ?", (_norm(title),)
            )
            self._log(c, "DELETE", title, detail=f"{r.rowcount} entries removed")
            return r.rowcount

    def delete_by_info_hash(self, info_hash: str) -> int:
        """
        Remove a single hash entry by its info_hash. Returns 1 if the row
        existed (and was deleted), 0 otherwise. Used by the UI's per-row
        Remove button so users can prune bad entries (wrong-season packs,
        misindexed series packs, etc.) without nuking the whole title.
        """
        if not info_hash:
            return 0
        with self._conn() as c:
            row = c.execute(
                "SELECT title_norm, media_type, season, episode, torrent_name "
                "FROM hash_index WHERE info_hash = ?",
                (info_hash,),
            ).fetchone()
            if not row:
                return 0
            r = c.execute(
                "DELETE FROM hash_index WHERE info_hash = ?", (info_hash,)
            )
            detail = (
                f"info_hash={info_hash[:12]} media_type={row['media_type']} "
                f"S{row['season']}E{row['episode']} {row['torrent_name'] or ''}"
            )
            self._log(c, "DELETE", row["title_norm"], detail=detail)
            return r.rowcount

    def blacklist_by_info_hash(self, info_hash: str) -> int:
        """
        Mark a hash as blacklisted. The row stays in the table (so we
        recognise it on rediscovery and skip it) but:
          - is_cached is forced to 0 so the resolver can't pick it
          - blacklisted=1 excludes it from every lookup() query
          - subsequent upserts of the same info_hash preserve the flag

        Returns 1 on success, 0 if the hash wasn't in the index.
        Use cases: bad encode, wrong-show match, broken/incomplete pack,
        contains malware/junk files, etc.
        """
        if not info_hash:
            return 0
        with self._conn() as c:
            row = c.execute(
                "SELECT title_norm, torrent_name, media_type, season, episode "
                "FROM hash_index WHERE info_hash = ?",
                (info_hash,),
            ).fetchone()
            if not row:
                return 0
            r = c.execute(
                "UPDATE hash_index SET blacklisted = 1, is_cached = 0, score = 0 "
                "WHERE info_hash = ?",
                (info_hash,),
            )
            detail = (
                f"info_hash={info_hash[:12]} media_type={row['media_type']} "
                f"S{row['season']}E{row['episode']} {row['torrent_name'] or ''}"
            )
            self._log(c, "BLACKLIST", row["title_norm"], info_hash, detail)
            self._invalidate_cache(row["title_norm"])
            return r.rowcount

    def unblacklist_by_info_hash(self, info_hash: str) -> int:
        """Reverse a blacklist. The hash returns to normal lookup eligibility
        on the next AllDebrid recheck or search-and-index pass."""
        if not info_hash:
            return 0
        with self._conn() as c:
            r = c.execute(
                "UPDATE hash_index SET blacklisted = 0 WHERE info_hash = ?",
                (info_hash,),
            )
            if r.rowcount:
                self._log(c, "UNBLACKLIST", "", info_hash, f"info_hash={info_hash[:12]}")
            return r.rowcount

    def list_blacklisted(self) -> list[dict]:
        """List all blacklisted hashes — for the management UI."""
        with self._conn() as c:
            rows = c.execute(
                "SELECT * FROM hash_index WHERE blacklisted = 1 "
                "ORDER BY updated_at DESC"
            ).fetchall()
        return [dict(r) for r in rows]

    def prune_log(self, max_rows: int = 5000) -> int:
        """Keep only the most recent max_rows log entries — prevents unbounded growth."""
        with self._conn() as c:
            count = c.execute("SELECT COUNT(*) FROM hash_index_log").fetchone()[0]
            if count > max_rows:
                to_delete = count - max_rows
                c.execute(
                    "DELETE FROM hash_index_log WHERE id IN "
                    "(SELECT id FROM hash_index_log ORDER BY id ASC LIMIT ?)",
                    (to_delete,),
                )
                return to_delete
        return 0

    def purge_unused(self, months: int = 6) -> dict:
        """Remove entries not used for playback in the given number of months."""
        cutoff = int(time.time()) - months * 30 * 86400
        with self._conn() as c:
            result = c.execute(
                """DELETE FROM hash_index
                   WHERE last_used IS NOT NULL AND last_used < ?""",
                (cutoff,),
            )
            deleted = result.rowcount
            remaining = c.execute("SELECT COUNT(*) FROM hash_index").fetchone()[0]
            self._log(c, "DELETE", detail=f"purge_unused months={months} deleted={deleted}")
        return {"deleted": deleted, "remaining": remaining}

    def clear(self) -> int:
        """Wipe the entire index. Returns count deleted."""
        with self._conn() as c:
            r = c.execute("DELETE FROM hash_index")
            self._log(c, "DELETE", detail=f"full clear: {r.rowcount} entries")
            return r.rowcount

    def clear_media_type(self, kind: str) -> int:
        """
        Wipe one media side of the hash index.

        kind='movie' removes only movie rows.
        kind='tv' removes TV rows: episode, season, and full-series packs.
        """
        k = (kind or "").lower().strip()
        if k in ("movie", "movies"):
            where = "media_type = 'movie'"
            label = "movies"
        elif k in ("tv", "show", "shows", "series"):
            where = "media_type IN ('episode','season','series')"
            label = "tv"
        else:
            raise ValueError("kind must be movie or tv")

        with self._conn() as c:
            r = c.execute(f"DELETE FROM hash_index WHERE {where}")
            self._log(c, "DELETE", detail=f"clear {label} index: {r.rowcount} entries")
            return r.rowcount

    # ── Stats / log ───────────────────────────────────────────────────────────

    def stats(self) -> dict:
        """Single-query stats — avoids 7 separate table scans."""
        with self._conn() as c:
            row = c.execute("""
                SELECT
                    COUNT(*)                                                    AS total,
                    SUM(is_cached)                                              AS cached,
                    COUNT(DISTINCT CASE WHEN media_type='movie'
                          THEN title_norm END)                                  AS movies,
                    SUM(CASE WHEN media_type='season'  THEN 1 ELSE 0 END)      AS seasons,
                    SUM(CASE WHEN media_type='series'  THEN 1 ELSE 0 END)      AS series,
                    SUM(CASE WHEN media_type='episode' THEN 1 ELSE 0 END)      AS episodes,
                    AVG(CASE WHEN is_cached=1 THEN CAST(score AS REAL) END)    AS avg_score
                FROM hash_index
            """).fetchone()
        return {
            "total":     row[0] or 0,
            "cached":    row[1] or 0,
            "movies":    row[2] or 0,
            "seasons":   row[3] or 0,
            "series":    row[4] or 0,
            "episodes":  row[5] or 0,
            "avg_score": round(row[6] or 0, 1),
        }

    def recent_log_lines(self, n: int = 200) -> list[str]:
        """Return recent log entries formatted as readable strings."""
        with self._conn() as c:
            rows = c.execute(
                """SELECT ts, event, title, info_hash, detail
                   FROM hash_index_log
                   ORDER BY ts DESC, id DESC
                   LIMIT ?""",
                (n,),
            ).fetchall()

        lines = []
        for r in rows:
            ts  = datetime.fromtimestamp(r["ts"]).strftime("%Y-%m-%d %H:%M:%S")
            ev  = f"[{r['event']:<7}]"
            tit = f" {r['title']!r}" if r["title"] else ""
            hsh = f" {r['info_hash'][:8]}" if r["info_hash"] else ""
            det = f"  └─ {r['detail']}" if r["detail"] else ""
            lines.append(f"{ts} {ev}{tit}{hsh}{det}")

        return lines

    def get_indexed_seasons(self, title: str) -> list[int]:
        """Return list of season numbers that have at least one cached hash for this title."""
        with self._conn() as c:
            rows = c.execute(
                """SELECT DISTINCT season FROM hash_index
                   WHERE title_norm = ? AND season IS NOT NULL AND is_cached = 1
                   ORDER BY season""",
                (_norm(title),),
            ).fetchall()
        return [r[0] for r in rows]

    def remove_title(self, title: str) -> int:
        """Remove all hash entries for a title. Returns count removed."""
        with self._conn() as c:
            result = c.execute(
                "DELETE FROM hash_index WHERE title_norm = ?",
                (_norm(title),),
            )
        return result.rowcount

    def list_titles(self) -> list[dict]:
        """
        Return one summary row per (title, media_type) pair — for the
        Hash Indexer page. Groups all hashes for a title and reports:
          - best_quality, best_score
          - cached_count, total_count
          - has_series_pack, has_season_pack
          - seasons covered (for TV)
          - last_checked, last_used
        """
        with self._conn() as c:
            rows = c.execute(
                """
                SELECT
                    title,
                    year,
                    CASE
                        WHEN media_type IN ('series','season','episode') THEN 'tv'
                        ELSE 'movie'
                    END AS kind,
                    COUNT(*)                                          AS total_hashes,
                    SUM(is_cached)                                    AS cached_count,
                    MAX(score)                                        AS best_score,
                    MAX(CASE WHEN is_cached=1 THEN quality END)       AS best_quality,
                    MAX(CASE WHEN media_type='series' AND is_cached=1 THEN 1 ELSE 0 END) AS has_series_pack,
                    MAX(CASE WHEN media_type='season' AND is_cached=1 THEN 1 ELSE 0 END) AS has_season_pack,
                    COUNT(DISTINCT CASE WHEN media_type IN ('season','episode') THEN season END) AS season_count,
                    MAX(last_checked)                                 AS last_checked,
                    MAX(last_used)                                    AS last_used
                FROM hash_index
                GROUP BY title_norm, kind
                ORDER BY title COLLATE NOCASE
                """
            ).fetchall()
        return [dict(r) for r in rows]

    def get_series_breakdown(self, title: str) -> dict:
        """
        Return a structured breakdown of what's indexed for a TV series.
        Used by the Hash Indexer detail drawer to show seasons + episodes.

        Returns:
        {
          "has_series_pack": bool,
          "series_pack":     {info_hash, quality, score, is_cached} | None,
          "seasons": {
            1: {
              "has_season_pack": bool,
              "season_pack":     {info_hash, quality, score, is_cached} | None,
              "cached":          bool,   # True if season or series pack is cached
              "episodes": {
                3: {is_cached, quality, score, info_hash}
              }
            }
          }
        }
        """
        with self._conn() as c:
            rows = c.execute(
                """SELECT * FROM hash_index
                   WHERE title_norm = ?
                   ORDER BY is_cached DESC, score DESC""",
                (_norm(title),),
            ).fetchall()

        rows = [dict(r) for r in rows]

        series_pack = None
        season_packs: dict[int, dict] = {}
        episodes:     dict[int, dict[int, dict]] = {}

        for r in rows:
            mt = r["media_type"]
            sn = r.get("season")
            ep = r.get("episode")

            if mt == "series":
                if series_pack is None or r["score"] > series_pack["score"]:
                    series_pack = r

            elif mt == "season" and sn:
                if sn not in season_packs or r["score"] > season_packs[sn]["score"]:
                    season_packs[sn] = r

            elif mt == "episode" and sn and ep:
                if sn not in episodes:
                    episodes[sn] = {}
                if ep not in episodes[sn] or r["score"] > episodes[sn][ep]["score"]:
                    episodes[sn][ep] = r

        # Build unified season map
        all_seasons: set[int] = set()
        all_seasons.update(season_packs.keys())
        all_seasons.update(episodes.keys())
        # If series pack exists, seasons from library tell us coverage
        # but we won't know exact season numbers without library data
        # so just use what's indexed

        seasons_out = {}
        for sn in sorted(all_seasons):
            sp   = season_packs.get(sn)
            eps  = episodes.get(sn, {})
            # Season is covered if there's a cached season pack, series pack, or any cached episode
            covered = (
                (sp and sp["is_cached"])
                or (series_pack and series_pack["is_cached"])
                or any(e["is_cached"] for e in eps.values())
            )
            seasons_out[sn] = {
                "season":         sn,
                "has_season_pack": sp is not None,
                "season_pack":     sp,
                "cached":          covered,
                "episode_count":   len(eps),
                "cached_episodes": sum(1 for e in eps.values() if e["is_cached"]),
                "episodes":        {ep: dict(e) for ep, e in sorted(eps.items())},
            }

        return {
            "title":           title,
            "has_series_pack": series_pack is not None,
            "series_pack":     series_pack,
            "total_hashes":    len(rows),
            "cached_hashes":   sum(1 for r in rows if r["is_cached"]),
            "seasons":         seasons_out,
        }

    def list_hashes_for_title(self, title: str) -> list[dict]:
        """Return every hash row for a title — for the detail drill-down."""
        with self._conn() as c:
            rows = c.execute(
                """SELECT * FROM hash_index
                   WHERE title_norm = ?
                   ORDER BY is_cached DESC, score DESC""",
                (_norm(title),),
            ).fetchall()
        return [dict(r) for r in rows]
