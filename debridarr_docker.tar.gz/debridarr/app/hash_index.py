"""Clean HashIndex implementation.

Purpose:
- one row per torrent hash
- optional pack coverage rows so TV season/series packs map to real SxxEyy slots
- download buttons operate on exact info_hash rows, not media-level dedupe
"""
from __future__ import annotations

import logging, re, sqlite3, threading, time
from contextlib import contextmanager
from typing import Optional

log = logging.getLogger("debridarr.hash_index")

SCORE_FILE_CACHED = 40

def _norm(s: str) -> str:
    if not s: return ""
    s = s.lower()
    s = re.sub(r"['\u2018\u2019\u201c\u201d]", "", s)
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()

def _detect_quality(name: str) -> str:
    n = (name or "").lower()
    if "2160p" in n or "4k" in n or "uhd" in n: return "2160p"
    for q in ("1080p","720p","480p"):
        if q in n: return q
    return "unknown"

def score_candidate(*, title: str, year: Optional[int], torrent_name: str, media_type: str,
                    quality: str, is_cached: bool, file_count: int = 1, file_size: int = 0,
                    seeders: int = 0, preferred_quality: str = "1080p") -> int:
    name = torrent_name or ""
    nn, tn = _norm(name), _norm(title)
    bad = re.search(r"\b(cam|hdcam|ts|telesync|telecine|workprint|dvdscr|screener)\b", nn, re.I)
    if bad: return -100
    pts = 0
    if tn and tn in nn: pts += 30
    elif tn and all(w in nn for w in tn.split()): pts += 15
    if year and str(year) in name: pts += 8
    if quality == preferred_quality: pts += 10
    elif quality in ("2160p","1080p","720p"): pts += 5
    pts += {"series":30,"season":25,"episode":20,"movie":20}.get(media_type,0)
    if is_cached: pts += SCORE_FILE_CACHED
    if file_count and file_count > 1: pts += 5
    if file_size and file_size > 4 * 1024**3: pts += 5
    lower = name.lower()
    if "remux" in lower: pts += 20
    elif re.search(r"blu[ ._-]?ray|bdrip|brrip", lower): pts += 15
    elif re.search(r"web[ ._-]?dl|webdl|amzn|nf|dsnp|hmax", lower): pts += 12
    if re.search(r"x265|hevc|h[ ._-]?265", lower): pts += 6
    elif re.search(r"x264|h[ ._-]?264", lower): pts += 4
    if seeders >= 100: pts += 5
    elif seeders >= 20: pts += 3
    return pts

_DDL = """
CREATE TABLE IF NOT EXISTS hash_index (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  media_type TEXT NOT NULL,
  title TEXT NOT NULL,
  title_norm TEXT NOT NULL,
  year INTEGER,
  season INTEGER,
  episode INTEGER,
  info_hash TEXT NOT NULL UNIQUE,
  magnet TEXT NOT NULL,
  torrent_name TEXT,
  file_count INTEGER DEFAULT 1,
  file_size INTEGER DEFAULT 0,
  provider TEXT DEFAULT 'alldebrid',
  is_cached INTEGER DEFAULT 0,
  score INTEGER DEFAULT 0,
  quality TEXT DEFAULT 'unknown',
  strategy TEXT DEFAULT 'unknown',
  blacklisted INTEGER DEFAULT 0,
  last_checked INTEGER,
  last_used INTEGER,
  created_at INTEGER DEFAULT (strftime('%s','now')),
  updated_at INTEGER DEFAULT (strftime('%s','now'))
);
CREATE INDEX IF NOT EXISTS ix_hi_title_norm ON hash_index(title_norm);
CREATE INDEX IF NOT EXISTS ix_hi_lookup ON hash_index(title_norm, media_type, season, episode, is_cached, score DESC);
CREATE INDEX IF NOT EXISTS ix_hi_hash ON hash_index(info_hash);
CREATE INDEX IF NOT EXISTS ix_hi_blacklisted ON hash_index(blacklisted);

CREATE TABLE IF NOT EXISTS hash_pack_coverage (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  title_norm TEXT NOT NULL,
  year INTEGER,
  season INTEGER NOT NULL,
  episode INTEGER NOT NULL,
  info_hash TEXT NOT NULL,
  pack_type TEXT NOT NULL,
  torrent_name TEXT,
  is_cached INTEGER DEFAULT 1,
  updated_at INTEGER DEFAULT (strftime('%s','now')),
  UNIQUE(title_norm, season, episode, info_hash)
);
CREATE INDEX IF NOT EXISTS ix_hpc_lookup ON hash_pack_coverage(title_norm, season, episode, is_cached);
CREATE INDEX IF NOT EXISTS ix_hpc_hash ON hash_pack_coverage(info_hash);

CREATE TABLE IF NOT EXISTS hash_index_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts INTEGER DEFAULT (strftime('%s','now')),
  event TEXT NOT NULL,
  title TEXT,
  info_hash TEXT,
  detail TEXT
);
CREATE INDEX IF NOT EXISTS ix_hlog_ts ON hash_index_log(ts DESC);
"""

class HashIndex:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._tl = threading.local()
        self._init()

    @contextmanager
    def _conn(self):
        if not getattr(self._tl, 'conn', None):
            c = sqlite3.connect(self.db_path, timeout=30, check_same_thread=False)
            c.row_factory = sqlite3.Row
            c.execute('PRAGMA journal_mode=WAL')
            c.execute('PRAGMA synchronous=NORMAL')
            self._tl.conn = c
        c = self._tl.conn
        try:
            yield c; c.commit()
        except Exception:
            c.rollback(); raise

    def _init(self):
        with self._conn() as c:
            # migrate legacy table before/after DDL
            c.executescript(_DDL)
            cols = {r[1] for r in c.execute('PRAGMA table_info(hash_index)').fetchall()}
            migrations = {
                'blacklisted':'ALTER TABLE hash_index ADD COLUMN blacklisted INTEGER DEFAULT 0',
                'file_count':'ALTER TABLE hash_index ADD COLUMN file_count INTEGER DEFAULT 1',
                'file_size':'ALTER TABLE hash_index ADD COLUMN file_size INTEGER DEFAULT 0',
                'provider':"ALTER TABLE hash_index ADD COLUMN provider TEXT DEFAULT 'alldebrid'",
                'quality':"ALTER TABLE hash_index ADD COLUMN quality TEXT DEFAULT 'unknown'",
                'strategy':"ALTER TABLE hash_index ADD COLUMN strategy TEXT DEFAULT 'unknown'",
                'last_checked':'ALTER TABLE hash_index ADD COLUMN last_checked INTEGER',
                'last_used':'ALTER TABLE hash_index ADD COLUMN last_used INTEGER',
                'created_at':"ALTER TABLE hash_index ADD COLUMN created_at INTEGER DEFAULT (strftime('%s','now'))",
                'updated_at':"ALTER TABLE hash_index ADD COLUMN updated_at INTEGER DEFAULT (strftime('%s','now'))",
            }
            for col, sql in migrations.items():
                if col not in cols:
                    try: c.execute(sql)
                    except sqlite3.OperationalError: pass
            c.executescript(_DDL)

    def _log(self, c, event, title='', info_hash='', detail=''):
        try: c.execute('INSERT INTO hash_index_log(event,title,info_hash,detail) VALUES(?,?,?,?)',(event,title,info_hash,detail))
        except Exception: pass

    def upsert(self, *, media_type: str, title: str, year=None, season=None, episode=None,
               info_hash: str, magnet: str, torrent_name: str, quality='unknown', strategy='unknown',
               is_cached=False, file_count=1, file_size=0, seeders=0, preferred_quality='1080p') -> int:
        # Normalize pack strategies at the storage boundary. Older detection code
        # sometimes classifies a season pack as an episode because the release
        # name contains SxxEyy in sample/subtitle/file metadata. The Hash Index
        # UI needs pack rows to be stored as pack rows.
        if strategy == 'series_pack':
            media_type, season, episode = 'series', None, None
        elif strategy == 'season_pack':
            media_type, episode = 'season', None
        ih = (info_hash or '').lower().strip()
        if not ih:
            m = re.search(r'btih:([a-fA-F0-9]{40}|[A-Za-z2-7]{32})', magnet or '', re.I)
            ih = m.group(1).lower() if m else ''
        if not ih: return 0
        if not magnet:
            from urllib.parse import quote
            magnet = f"magnet:?xt=urn:btih:{ih}&dn={quote(torrent_name or title or ih)}"
        if quality == 'unknown': quality = _detect_quality(torrent_name or magnet)
        pts = score_candidate(title=title, year=year, torrent_name=torrent_name or '', media_type=media_type,
                              quality=quality, is_cached=bool(is_cached), file_count=file_count or 1,
                              file_size=file_size or 0, seeders=seeders or 0, preferred_quality=preferred_quality)
        if pts < 0: return 0
        now = int(time.time())
        tn = _norm(title)
        with self._conn() as c:
            old = c.execute('SELECT * FROM hash_index WHERE info_hash=?',(ih,)).fetchone()
            if old:
                black = int(old['blacklisted'] or 0)
                cached = 0 if black else (1 if (is_cached or old['is_cached']) else 0)
                c.execute('''UPDATE hash_index SET media_type=?,title=?,title_norm=?,year=?,season=?,episode=?,magnet=?,torrent_name=?,file_count=?,file_size=?,is_cached=?,score=?,quality=?,strategy=?,last_checked=?,updated_at=? WHERE info_hash=?''',
                          (media_type,title,tn,year,season,episode,magnet,torrent_name,file_count or 1,file_size or 0,cached,max(int(old['score'] or 0),pts),quality,strategy,now,now,ih))
                self._log(c,'UPDATE',title,ih,f'{media_type} S{season}E{episode} cached={cached}')
            else:
                c.execute('''INSERT INTO hash_index(media_type,title,title_norm,year,season,episode,info_hash,magnet,torrent_name,file_count,file_size,provider,is_cached,score,quality,strategy,last_checked,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,'alldebrid',?,?,?,?,?,?,?)''',
                          (media_type,title,tn,year,season,episode,ih,magnet,torrent_name,file_count or 1,file_size or 0,1 if is_cached else 0,pts,quality,strategy,now,now,now))
                self._log(c,'ADD',title,ih,f'{media_type} S{season}E{episode} cached={is_cached}')
        return pts

    def set_pack_coverage(self, *, title: str, year=None, info_hash: str, pack_type: str, episodes: list[dict], torrent_name='', is_cached=True) -> int:
        ih=(info_hash or '').lower().strip(); now=int(time.time())
        rows=[]
        for ep in episodes or []:
            try: sn=int(ep.get('season') or 0); en=int(ep.get('episode') or 0)
            except Exception: continue
            if sn>0 and en>0: rows.append((title,_norm(title),year,sn,en,ih,pack_type,torrent_name or '',1 if is_cached else 0,now))
        if not rows or not ih: return 0
        with self._conn() as c:
            c.executemany('''INSERT INTO hash_pack_coverage(title,title_norm,year,season,episode,info_hash,pack_type,torrent_name,is_cached,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(title_norm,season,episode,info_hash) DO UPDATE SET title=excluded.title,year=excluded.year,pack_type=excluded.pack_type,torrent_name=excluded.torrent_name,is_cached=excluded.is_cached,updated_at=excluded.updated_at''', rows)
            self._log(c,'PACK_COVERAGE',title,ih,f'{pack_type} covers {len(rows)} episodes')
        return len(rows)

    def lookup(self,title,*,season=None,episode=None,cached_only=True,limit=5):
        tn=_norm(title); cache=1 if cached_only else 0
        with self._conn() as c:
            if season is not None:
                rows=c.execute('''SELECT * FROM hash_index WHERE title_norm=? AND blacklisted=0 AND ((media_type='episode' AND season=? AND (? IS NULL OR episode=?)) OR (media_type='season' AND season=?) OR media_type='series') AND (?=0 OR is_cached=1) ORDER BY CASE media_type WHEN 'episode' THEN 0 WHEN 'season' THEN 1 WHEN 'series' THEN 2 ELSE 9 END, score DESC LIMIT ?''',(tn,season,episode,episode,season,cache,limit)).fetchall()
            else:
                rows=c.execute('''SELECT * FROM hash_index WHERE title_norm=? AND blacklisted=0 AND (?=0 OR is_cached=1) ORDER BY is_cached DESC, score DESC LIMIT ?''',(tn,cache,limit)).fetchall()
        return [dict(r) for r in rows]

    def get_by_info_hash(self, info_hash: str):
        with self._conn() as c:
            r=c.execute('SELECT * FROM hash_index WHERE info_hash=?',((info_hash or '').lower().strip(),)).fetchone()
        return dict(r) if r else None

    def list_hashes_for_title(self,title):
        with self._conn() as c:
            rows=c.execute('SELECT * FROM hash_index WHERE title_norm=? ORDER BY is_cached DESC,score DESC',(_norm(title),)).fetchall()
        return [dict(r) for r in rows]

    def get_series_breakdown(self,title):
        rows=self.list_hashes_for_title(title)
        series_pack=None; season_packs={}; episodes={}
        for r in rows:
            mt=r.get('media_type'); sn=r.get('season'); en=r.get('episode')
            # Treat any row with season/episode fields as TV, even if an older
            # parser stored it with media_type='movie'. This is the bug that
            # made TV detail drawers fall back to the flat hash list.
            if mt=='series' and (series_pack is None or r.get('score',0)>series_pack.get('score',0)):
                series_pack=r
            elif sn and not en:
                sn=int(sn)
                if sn not in season_packs or r.get('score',0)>season_packs[sn].get('score',0): season_packs[sn]=r
            elif sn and en:
                sn=int(sn); en=int(en); episodes.setdefault(sn,{})
                if en not in episodes[sn] or r.get('score',0)>episodes[sn][en].get('score',0): episodes[sn][en]=r
        seasons=set(season_packs)|set(episodes)
        # Include seasons that only exist through pack coverage
        with self._conn() as c:
            cov=c.execute('SELECT season,episode,info_hash,pack_type,torrent_name,is_cached FROM hash_pack_coverage WHERE title_norm=? ORDER BY season,episode',(_norm(title),)).fetchall()
        coverage_by_season={}
        for cr in cov:
            d=dict(cr); sn=int(d['season']); en=int(d['episode']); seasons.add(sn)
            coverage_by_season.setdefault(sn,{})[en]=d
        out={}
        for sn in sorted(seasons):
            sp=season_packs.get(sn); eps=dict(episodes.get(sn,{}) or {})
            pack_cached=bool((sp and sp.get('is_cached')) or (series_pack and series_pack.get('is_cached')))
            for en, covrow in coverage_by_season.get(sn,{}).items():
                if en not in eps:
                    eps[en]={
                        'season':sn,'episode':en,'expected':True,'indexed':False,
                        'is_cached': bool(covrow.get('is_cached')) or pack_cached,
                        'hash_cached': bool(covrow.get('is_cached')) or pack_cached,
                        'covered_by_pack': True,
                        'info_hash': covrow.get('info_hash'),
                        'torrent_name': covrow.get('torrent_name'),
                        'quality': (sp or series_pack or {}).get('quality','unknown'),
                        'score': (sp or series_pack or {}).get('score',0),
                    }
            for en,e in list(eps.items()):
                e=dict(e); e.setdefault('season',sn); e.setdefault('episode',en); e.setdefault('indexed',bool(e.get('info_hash'))); e['covered_by_pack']=pack_cached or bool(coverage_by_season.get(sn,{}).get(en)); e['is_cached']=bool(e.get('is_cached')) or bool(e.get('covered_by_pack')); eps[en]=e
            cached=sum(1 for e in eps.values() if e.get('is_cached'))
            out[sn]={'season':sn,'has_season_pack':bool(sp),'season_pack':sp,'cached':bool(pack_cached or cached),'episode_count':len([e for e in eps.values() if e.get('info_hash')]),'cached_episodes':cached,'episodes':eps}
        return {'title':title,'has_series_pack':bool(series_pack),'series_pack':series_pack,'seasons':out}

    def list_titles(self):
        with self._conn() as c:
            rows=c.execute('''SELECT title,year,CASE WHEN media_type IN ('series','season','episode') OR season IS NOT NULL THEN 'tv' ELSE 'movie' END kind,COUNT(*) total_hashes,SUM(is_cached) cached_count,MAX(score) best_score,MAX(CASE WHEN is_cached=1 THEN quality END) best_quality,MAX(CASE WHEN media_type='series' AND is_cached=1 THEN 1 ELSE 0 END) has_series_pack,MAX(CASE WHEN media_type='season' AND is_cached=1 THEN 1 ELSE 0 END) has_season_pack,COUNT(DISTINCT CASE WHEN media_type IN ('season','episode') THEN season END) season_count,MAX(last_checked) last_checked,MAX(last_used) last_used FROM hash_index WHERE blacklisted=0 GROUP BY title_norm,kind ORDER BY title COLLATE NOCASE''').fetchall()
        return [dict(r) for r in rows]

    def get_indexed_seasons(self, title: str) -> list[int]:
        """Return every season represented by episode rows, season rows, or pack coverage.

        The Hash Index page uses this to decide which library seasons are still
        missing. Older builds only looked at hash_index rows, so a season pack
        with coverage could still look missing in the tab.
        """
        tn = _norm(title)
        with self._conn() as c:
            rows = c.execute('''
                SELECT DISTINCT season FROM hash_index
                 WHERE title_norm=? AND blacklisted=0 AND season IS NOT NULL
                   AND media_type IN ('season','episode')
                UNION
                SELECT DISTINCT season FROM hash_pack_coverage
                 WHERE title_norm=? AND season IS NOT NULL AND is_cached=1
                ORDER BY season
            ''', (tn, tn)).fetchall()
        out = []
        for r in rows:
            try:
                sn = int(r[0])
                if sn > 0:
                    out.append(sn)
            except Exception:
                pass
        return out

    def stats(self):
        """Return the complete stat contract expected by /hash-indexer.

        A previous rewrite returned only total/cached/tv/movies/pack_coverage.
        The page still reads stats['seasons'], stats['series'], and
        stats['avg_score'], which made the Hash Index tab fail before the
        drawer could ever render.
        """
        with self._conn() as c:
            total = c.execute('SELECT COUNT(*) FROM hash_index WHERE blacklisted=0').fetchone()[0] or 0
            cached = c.execute('SELECT COUNT(*) FROM hash_index WHERE is_cached=1 AND blacklisted=0').fetchone()[0] or 0
            tv = c.execute("SELECT COUNT(*) FROM hash_index WHERE blacklisted=0 AND media_type IN ('series','season','episode')").fetchone()[0] or 0
            movies = c.execute("SELECT COUNT(*) FROM hash_index WHERE blacklisted=0 AND media_type='movie'").fetchone()[0] or 0
            seasons = c.execute("SELECT COUNT(*) FROM hash_index WHERE blacklisted=0 AND media_type='season'").fetchone()[0] or 0
            series = c.execute("SELECT COUNT(*) FROM hash_index WHERE blacklisted=0 AND media_type='series'").fetchone()[0] or 0
            episodes = c.execute("SELECT COUNT(*) FROM hash_index WHERE blacklisted=0 AND media_type='episode'").fetchone()[0] or 0
            cov = c.execute('SELECT COUNT(*) FROM hash_pack_coverage').fetchone()[0] or 0
            avg = c.execute('SELECT COALESCE(AVG(score),0) FROM hash_index WHERE blacklisted=0').fetchone()[0] or 0
            blacklisted = c.execute('SELECT COUNT(*) FROM hash_index WHERE blacklisted=1').fetchone()[0] or 0
        return {
            'total': int(total),
            'cached': int(cached),
            'tv': int(tv),
            'movies': int(movies),
            'seasons': int(seasons),
            'series': int(series),
            'episodes': int(episodes),
            'pack_coverage': int(cov),
            'avg_score': int(round(float(avg or 0))),
            'blacklisted': int(blacklisted),
        }

    def mark_cached(self,info_hash,score_bonus=SCORE_FILE_CACHED):
        with self._conn() as c: c.execute('UPDATE hash_index SET is_cached=1,score=score+?,last_checked=?,updated_at=? WHERE info_hash=? AND blacklisted=0',(score_bonus,int(time.time()),int(time.time()),(info_hash or '').lower()))
    def mark_uncached(self,info_hash):
        with self._conn() as c:
            c.execute('UPDATE hash_index SET is_cached=0,last_checked=?,updated_at=? WHERE info_hash=?',(int(time.time()),int(time.time()),(info_hash or '').lower()))
            c.execute('UPDATE hash_pack_coverage SET is_cached=0,updated_at=? WHERE info_hash=?',(int(time.time()),(info_hash or '').lower()))
    def touch(self,info_hash):
        with self._conn() as c: c.execute('UPDATE hash_index SET last_used=?,updated_at=? WHERE info_hash=?',(int(time.time()),int(time.time()),(info_hash or '').lower()))
    def get_stale(self,older_than_hours=6,limit=200):
        cutoff=int(time.time())-older_than_hours*3600
        with self._conn() as c: rows=c.execute('SELECT * FROM hash_index WHERE blacklisted=0 AND (last_checked IS NULL OR last_checked<?) ORDER BY score DESC LIMIT ?',(cutoff,limit)).fetchall()
        return [dict(r) for r in rows]
    def delete_for_title(self,title):
        with self._conn() as c:
            r=c.execute('DELETE FROM hash_index WHERE title_norm=?',(_norm(title),)); c.execute('DELETE FROM hash_pack_coverage WHERE title_norm=?',(_norm(title),)); return r.rowcount

    def remove_title(self, title):
        """Compatibility alias used by library-delete flows."""
        return self.delete_for_title(title)

    def recent_log_lines(self, limit: int = 500) -> list[str]:
        limit = max(1, min(int(limit or 500), 5000))
        with self._conn() as c:
            rows = c.execute('''SELECT ts,event,title,info_hash,detail
                                  FROM hash_index_log
                              ORDER BY ts DESC, id DESC LIMIT ?''', (limit,)).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            try:
                stamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(int(d.get('ts') or 0)))
            except Exception:
                stamp = str(d.get('ts') or '')
            title = d.get('title') or ''
            ih = (d.get('info_hash') or '')
            ihs = (ih[:12] + '…') if ih else ''
            detail = d.get('detail') or ''
            parts = [stamp, d.get('event') or 'LOG']
            if title: parts.append(title)
            if ihs: parts.append(ihs)
            if detail: parts.append(detail)
            out.append(' | '.join(str(x) for x in parts if x is not None))
        return out

    def prune_log(self, max_rows: int = 5000) -> int:
        max_rows = max(100, int(max_rows or 5000))
        with self._conn() as c:
            r = c.execute('''DELETE FROM hash_index_log
                              WHERE id NOT IN (
                                SELECT id FROM hash_index_log ORDER BY ts DESC, id DESC LIMIT ?
                              )''', (max_rows,))
            return r.rowcount
    def delete_by_info_hash(self,info_hash):
        ih=(info_hash or '').lower();
        with self._conn() as c:
            r=c.execute('DELETE FROM hash_index WHERE info_hash=?',(ih,)); c.execute('DELETE FROM hash_pack_coverage WHERE info_hash=?',(ih,)); return r.rowcount
    def blacklist_by_info_hash(self,info_hash):
        ih=(info_hash or '').lower();
        with self._conn() as c:
            r=c.execute('UPDATE hash_index SET blacklisted=1,is_cached=0,score=0 WHERE info_hash=?',(ih,)); c.execute('UPDATE hash_pack_coverage SET is_cached=0 WHERE info_hash=?',(ih,)); return r.rowcount
    def unblacklist_by_info_hash(self,info_hash):
        with self._conn() as c: r=c.execute('UPDATE hash_index SET blacklisted=0 WHERE info_hash=?',((info_hash or '').lower(),)); return r.rowcount
    def list_blacklisted(self):
        with self._conn() as c: rows=c.execute('SELECT * FROM hash_index WHERE blacklisted=1 ORDER BY updated_at DESC').fetchall()
        return [dict(r) for r in rows]
    def purge_unused(self,months=6):
        cutoff=int(time.time())-months*30*86400
        with self._conn() as c:
            r=c.execute('DELETE FROM hash_index WHERE last_used IS NOT NULL AND last_used<?',(cutoff,)); return {'deleted':r.rowcount,'months':months}
    def clear(self):
        with self._conn() as c:
            n=c.execute('SELECT COUNT(*) FROM hash_index').fetchone()[0]; c.execute('DELETE FROM hash_index'); c.execute('DELETE FROM hash_pack_coverage'); return n
    def clear_media_type(self,kind):
        with self._conn() as c:
            if kind=='tv': r=c.execute("DELETE FROM hash_index WHERE media_type IN ('series','season','episode')")
            elif kind=='movie': r=c.execute("DELETE FROM hash_index WHERE media_type='movie'")
            else: return 0
            # coverage is TV-only
            if kind=='tv': c.execute('DELETE FROM hash_pack_coverage')
            return r.rowcount
