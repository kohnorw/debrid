"""
hash_index.py — Source of truth for all media resolution.

Maps:
    Movie / TV Show / Season / Episode
    →
    Hash · File · Provider · Status · Score

The index is the ONLY path consulted when a user hits play.
Nothing missing from the index gets a placeholder created.

Scoring pipeline (higher = better candidate):
    Stage 1 — Metadata match     40 pts max
    Stage 2 — Pack intelligence  30 pts max
    Stage 3 — File verification  50 pts max

The index grows on startup and gets smarter over time via background
recheck loops. add_magnet() is called exactly once — when the user
presses play and the index has a hit.
"""

from __future__ import annotations

import logging
import re
import sqlite3
import time
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

log = logging.getLogger("debridarr.hash_index")

# ── Score weights ─────────────────────────────────────────────────────────────

SCORE_META_TITLE_EXACT    = 20   # Stage 1: exact title match
SCORE_META_TITLE_NORM     = 10   # Stage 1: normalised match
SCORE_META_YEAR_MATCH     = 10   # Stage 1: year present and correct
SCORE_META_QUALITY_PREF   = 10   # Stage 1: preferred quality (1080p default)
SCORE_META_QUALITY_OK     = 5    # Stage 1: acceptable quality

SCORE_PACK_SERIES         = 30   # Stage 2: series pack (whole show)
SCORE_PACK_SEASON         = 20   # Stage 2: season pack
SCORE_PACK_EPISODE        = 10   # Stage 2: single episode
SCORE_PACK_MULTI_FILE     = 5    # Stage 2: bonus for >1 file in pack

SCORE_FILE_CACHED         = 40   # Stage 3: confirmed cached on AllDebrid
SCORE_FILE_SIZE_LARGE     = 10   # Stage 3: file >4 GB (likely good encode)

SCORE_MAX = (
    SCORE_META_TITLE_EXACT + SCORE_META_YEAR_MATCH + SCORE_META_QUALITY_PREF
    + SCORE_PACK_SERIES + SCORE_PACK_MULTI_FILE
    + SCORE_FILE_CACHED + SCORE_FILE_SIZE_LARGE
)


# ── Schema ────────────────────────────────────────────────────────────────────

_DDL = """
CREATE TABLE IF NOT EXISTS hash_index (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Media identity
    media_type    TEXT    NOT NULL,   -- 'movie' | 'episode' | 'season' | 'series'
    title         TEXT    NOT NULL,
    title_norm    TEXT    NOT NULL,   -- normalised for search
    year          INTEGER,
    season        INTEGER,
    episode       INTEGER,

    -- Hash / torrent
    info_hash     TEXT    NOT NULL UNIQUE,
    magnet        TEXT    NOT NULL,
    torrent_name  TEXT,
    file_count    INTEGER DEFAULT 1,
    file_size     INTEGER DEFAULT 0,  -- bytes, largest file in torrent

    -- Provider
    provider      TEXT    DEFAULT 'alldebrid',
    is_cached     INTEGER DEFAULT 0,  -- 1 = confirmed cached on AllDebrid

    -- Scoring
    score         INTEGER DEFAULT 0,
    quality       TEXT    DEFAULT 'unknown',
    strategy      TEXT    DEFAULT 'unknown',

    -- Lifecycle
    last_checked  INTEGER,  -- unix timestamp of last AllDebrid availability check
    last_used     INTEGER,  -- unix timestamp last time this hash served a play
    created_at    INTEGER   DEFAULT (strftime('%s','now')),
    updated_at    INTEGER   DEFAULT (strftime('%s','now'))
);

CREATE INDEX IF NOT EXISTS ix_hi_title_norm  ON hash_index (title_norm);
CREATE INDEX IF NOT EXISTS ix_hi_type_season ON hash_index (media_type, season, episode);
CREATE INDEX IF NOT EXISTS ix_hi_hash        ON hash_index (info_hash);
CREATE INDEX IF NOT EXISTS ix_hi_cached      ON hash_index (is_cached, score DESC);
CREATE INDEX IF NOT EXISTS ix_hi_last_used   ON hash_index (last_used);

CREATE TABLE IF NOT EXISTS hash_index_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    ts         INTEGER DEFAULT (strftime('%s','now')),
    event      TEXT NOT NULL,  -- ADD | UPDATE | HIT | MISS | EVICT | DELETE | TOUCH | RECHECK
    title      TEXT,
    info_hash  TEXT,
    detail     TEXT
);
CREATE INDEX IF NOT EXISTS ix_hlog_ts ON hash_index_log (ts DESC);
"""


# ── Helpers ───────────────────────────────────────────────────────────────────

def _norm(s: str) -> str:
    """Normalise a title for fuzzy matching."""
    if not s:
        return ""
    s = s.lower()
    s = re.sub(r"['\u2018\u2019\u201c\u201d]", "", s)
    s = re.sub(r"[^a-z0-9 ]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _detect_quality(name: str) -> str:
    n = name.lower()
    for q in ("2160p", "4k", "uhd", "1080p", "720p", "480p"):
        if q in n:
            return q
    return "unknown"


# ── Scoring pipeline ──────────────────────────────────────────────────────────

def score_candidate(
    *,
    title: str,
    year: Optional[int],
    torrent_name: str,
    media_type: str,
    quality: str,
    is_cached: bool,
    file_count: int = 1,
    file_size: int = 0,
    preferred_quality: str = "1080p",
) -> int:
    """
    Run the three-stage scoring pipeline and return a total score.

    Stage 1 — Metadata match (40 pts max)
    Stage 2 — Pack intelligence (30 pts max)
    Stage 3 — File verification (50 pts max)
    """
    pts = 0
    name_norm = _norm(torrent_name)
    title_norm = _norm(title)

    # ── Stage 1: Metadata match ───────────────────────────────────────────────
    if title_norm and title_norm in name_norm:
        pts += SCORE_META_TITLE_EXACT
    elif title_norm and all(w in name_norm for w in title_norm.split()):
        pts += SCORE_META_TITLE_NORM

    if year and str(year) in torrent_name:
        pts += SCORE_META_YEAR_MATCH

    if quality == preferred_quality:
        pts += SCORE_META_QUALITY_PREF
    elif quality in ("1080p", "720p") and preferred_quality in ("1080p", "720p"):
        pts += SCORE_META_QUALITY_OK

    # ── Stage 2: Pack intelligence ────────────────────────────────────────────
    if media_type in ("series",):
        pts += SCORE_PACK_SERIES
    elif media_type in ("season",):
        pts += SCORE_PACK_SEASON
    elif media_type in ("episode", "movie"):
        pts += SCORE_PACK_EPISODE

    if file_count > 1:
        pts += SCORE_PACK_MULTI_FILE

    # ── Stage 3: File verification ────────────────────────────────────────────
    if is_cached:
        pts += SCORE_FILE_CACHED

    if file_size > 4 * 1024 ** 3:  # >4 GB
        pts += SCORE_FILE_SIZE_LARGE

    return pts


# ── HashIndex ─────────────────────────────────────────────────────────────────

class HashIndex:
    """
    SQLite-backed hash index.

    All writes go through upsert(). All reads go through lookup().
    The only place add_magnet() is called is in resolve_on_play()
    (in main.py), which consumes the top-scored cached entry.
    """

    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init()

    # ── Internals ──────────────────────────────────────────────────────────────

    @contextmanager
    def _conn(self):
        conn = sqlite3.connect(self.db_path, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init(self):
        with self._conn() as c:
            c.executescript(_DDL)

    def _log(self, conn, event: str, title: str = "", info_hash: str = "", detail: str = ""):
        conn.execute(
            "INSERT INTO hash_index_log (event, title, info_hash, detail) VALUES (?,?,?,?)",
            (event, title, info_hash, detail),
        )

    # ── Write ──────────────────────────────────────────────────────────────────

    def upsert(
        self,
        *,
        media_type: str,
        title: str,
        year: Optional[int],
        season: Optional[int],
        episode: Optional[int],
        info_hash: str,
        magnet: str,
        torrent_name: str,
        quality: str = "unknown",
        strategy: str = "unknown",
        is_cached: bool = False,
        file_count: int = 1,
        file_size: int = 0,
        preferred_quality: str = "1080p",
    ) -> int:
        """Insert or update a hash entry. Returns the computed score."""
        info_hash = info_hash.lower().strip()
        if not info_hash or not magnet:
            return 0

        if quality == "unknown":
            quality = _detect_quality(torrent_name)

        pts = score_candidate(
            title=title,
            year=year,
            torrent_name=torrent_name,
            media_type=media_type,
            quality=quality,
            is_cached=is_cached,
            file_count=file_count,
            file_size=file_size,
            preferred_quality=preferred_quality,
        )

        now = int(time.time())
        with self._conn() as c:
            existing = c.execute(
                "SELECT id, score, is_cached FROM hash_index WHERE info_hash = ?",
                (info_hash,),
            ).fetchone()

            if existing:
                # Only update score if it improved (index gets smarter over time)
                new_score = max(pts, existing["score"])
                new_cached = 1 if (is_cached or existing["is_cached"]) else 0
                c.execute(
                    """UPDATE hash_index
                       SET media_type=?, title=?, title_norm=?, year=?, season=?, episode=?,
                           magnet=?, torrent_name=?, file_count=?, file_size=?,
                           is_cached=?, score=?, quality=?, strategy=?,
                           last_checked=?, updated_at=?
                       WHERE info_hash=?""",
                    (
                        media_type, title, _norm(title), year, season, episode,
                        magnet, torrent_name, file_count, file_size,
                        new_cached, new_score, quality, strategy,
                        now, now, info_hash,
                    ),
                )
                self._log(c, "UPDATE", title, info_hash,
                          f"score={new_score} cached={new_cached} q={quality}")
            else:
                c.execute(
                    """INSERT INTO hash_index
                       (media_type, title, title_norm, year, season, episode,
                        info_hash, magnet, torrent_name, file_count, file_size,
                        provider, is_cached, score, quality, strategy,
                        last_checked, last_used, created_at, updated_at)
                       VALUES (?,?,?,?,?,?, ?,?,?,?,?, 'alldebrid',?,?,?,?, ?,NULL,?,?)""",
                    (
                        media_type, title, _norm(title), year, season, episode,
                        info_hash, magnet, torrent_name, file_count, file_size,
                        1 if is_cached else 0, pts, quality, strategy,
                        now, now, now,
                    ),
                )
                self._log(c, "ADD", title, info_hash,
                          f"score={pts} cached={is_cached} q={quality} type={media_type}")

        log.debug(f"[UPSERT] {title!r} {info_hash[:8]} score={pts} cached={is_cached}")
        return pts

    def mark_cached(self, info_hash: str, score_bonus: int = SCORE_FILE_CACHED):
        """Confirm a hash is cached on AllDebrid and bump its score."""
        now = int(time.time())
        with self._conn() as c:
            c.execute(
                """UPDATE hash_index
                   SET is_cached=1, score=score+?, last_checked=?, updated_at=?
                   WHERE info_hash=? AND is_cached=0""",
                (score_bonus, now, now, info_hash.lower()),
            )
            self._log(c, "UPDATE", info_hash=info_hash, detail="confirmed cached")

    def mark_uncached(self, info_hash: str):
        """Mark a hash as no longer available on AllDebrid (evicted from cache)."""
        now = int(time.time())
        with self._conn() as c:
            c.execute(
                """UPDATE hash_index
                   SET is_cached=0, last_checked=?, updated_at=?
                   WHERE info_hash=?""",
                (now, now, info_hash.lower()),
            )
            self._log(c, "EVICT", info_hash=info_hash, detail="no longer cached")

    def touch(self, info_hash: str):
        """Record that this hash was used for a successful play."""
        now = int(time.time())
        with self._conn() as c:
            c.execute(
                "UPDATE hash_index SET last_used=?, updated_at=? WHERE info_hash=?",
                (now, now, info_hash.lower()),
            )
            self._log(c, "TOUCH", info_hash=info_hash, detail="served play request")

    # ── Read ───────────────────────────────────────────────────────────────────

    def lookup(
        self,
        title: str,
        *,
        season: Optional[int] = None,
        episode: Optional[int] = None,
        cached_only: bool = True,
        limit: int = 5,
    ) -> list[dict]:
        """
        Return the best candidates for a play request, ordered by score desc.

        For episodes: returns season packs AND series packs AND exact episode
        matches — caller picks the best file from the winning torrent.

        For movies: returns direct movie matches.

        Returns empty list if nothing found (→ triggers live search).
        """
        title_norm = _norm(title)
        now = int(time.time())

        with self._conn() as c:
            if season is not None:
                # Episode lookup — accept: exact episode, season pack, series pack
                rows = c.execute(
                    """SELECT * FROM hash_index
                       WHERE title_norm = ?
                         AND (
                               (media_type = 'episode' AND season = ? AND episode = ?)
                            OR (media_type = 'season'  AND season = ?)
                            OR (media_type = 'series')
                         )
                         AND (? = 0 OR is_cached = 1)
                       ORDER BY score DESC, is_cached DESC
                       LIMIT ?""",
                    (title_norm, season, episode, season, 1 if cached_only else 0, limit),
                ).fetchall()
            else:
                # Movie lookup
                rows = c.execute(
                    """SELECT * FROM hash_index
                       WHERE title_norm = ?
                         AND media_type = 'movie'
                         AND (? = 0 OR is_cached = 1)
                       ORDER BY score DESC, is_cached DESC
                       LIMIT ?""",
                    (title_norm, 1 if cached_only else 0, limit),
                ).fetchall()

            if rows:
                self._log(c, "HIT", title, detail=f"season={season} ep={episode} candidates={len(rows)}")
            else:
                self._log(c, "MISS", title, detail=f"season={season} ep={episode}")

        return [dict(r) for r in rows]

    def get_stale(self, older_than_hours: int = 6, limit: int = 200) -> list[dict]:
        """Return hashes not checked recently — for background recheck loop."""
        cutoff = int(time.time()) - older_than_hours * 3600
        with self._conn() as c:
            rows = c.execute(
                """SELECT * FROM hash_index
                   WHERE last_checked IS NULL OR last_checked < ?
                   ORDER BY score DESC
                   LIMIT ?""",
                (cutoff, limit),
            ).fetchall()
        return [dict(r) for r in rows]

    def delete_for_title(self, title: str) -> int:
        """Remove all hash entries for a title. Returns count deleted."""
        with self._conn() as c:
            r = c.execute(
                "DELETE FROM hash_index WHERE title_norm = ?", (_norm(title),)
            )
            self._log(c, "DELETE", title, detail=f"{r.rowcount} entries removed")
            return r.rowcount

    def purge_unused(self, months: int = 6) -> dict:
        """Remove entries not used for playback in the given number of months."""
        cutoff = int(time.time()) - months * 30 * 86400
        with self._conn() as c:
            result = c.execute(
                """DELETE FROM hash_index
                   WHERE last_used IS NOT NULL AND last_used < ?""",
                (cutoff,),
            )
            deleted = result.rowcount
            remaining = c.execute("SELECT COUNT(*) FROM hash_index").fetchone()[0]
            self._log(c, "DELETE", detail=f"purge_unused months={months} deleted={deleted}")
        return {"deleted": deleted, "remaining": remaining}

    def clear(self) -> int:
        """Wipe the entire index. Returns count deleted."""
        with self._conn() as c:
            r = c.execute("DELETE FROM hash_index")
            self._log(c, "DELETE", detail=f"full clear: {r.rowcount} entries")
            return r.rowcount

    # ── Stats / log ───────────────────────────────────────────────────────────

    def stats(self) -> dict:
        with self._conn() as c:
            total   = c.execute("SELECT COUNT(*) FROM hash_index").fetchone()[0]
            cached  = c.execute("SELECT COUNT(*) FROM hash_index WHERE is_cached=1").fetchone()[0]
            movies  = c.execute("SELECT COUNT(*) FROM hash_index WHERE media_type='movie'").fetchone()[0]
            seasons = c.execute("SELECT COUNT(*) FROM hash_index WHERE media_type='season'").fetchone()[0]
            series  = c.execute("SELECT COUNT(*) FROM hash_index WHERE media_type='series'").fetchone()[0]
            eps     = c.execute("SELECT COUNT(*) FROM hash_index WHERE media_type='episode'").fetchone()[0]
            avg_s   = c.execute("SELECT AVG(score) FROM hash_index WHERE is_cached=1").fetchone()[0]
        return {
            "total":    total,
            "cached":   cached,
            "movies":   movies,
            "seasons":  seasons,
            "series":   series,
            "episodes": eps,
            "avg_score": round(avg_s or 0, 1),
        }

    def recent_log_lines(self, n: int = 200) -> list[str]:
        """Return recent log entries formatted as readable strings."""
        with self._conn() as c:
            rows = c.execute(
                """SELECT ts, event, title, info_hash, detail
                   FROM hash_index_log
                   ORDER BY ts DESC, id DESC
                   LIMIT ?""",
                (n,),
            ).fetchall()

        lines = []
        for r in rows:
            ts  = datetime.fromtimestamp(r["ts"]).strftime("%Y-%m-%d %H:%M:%S")
            ev  = f"[{r['event']:<7}]"
            tit = f" {r['title']!r}" if r["title"] else ""
            hsh = f" {r['info_hash'][:8]}" if r["info_hash"] else ""
            det = f"  └─ {r['detail']}" if r["detail"] else ""
            lines.append(f"{ts} {ev}{tit}{hsh}{det}")

        return lines

    def list_titles(self) -> list[dict]:
        """
        Return one summary row per (title, media_type) pair — for the
        Hash Indexer page. Groups all hashes for a title and reports:
          - best_quality, best_score
          - cached_count, total_count
          - has_series_pack, has_season_pack
          - seasons covered (for TV)
          - last_checked, last_used
        """
        with self._conn() as c:
            rows = c.execute(
                """
                SELECT
                    title,
                    year,
                    CASE
                        WHEN media_type IN ('series','season','episode') THEN 'tv'
                        ELSE 'movie'
                    END AS kind,
                    COUNT(*)                                          AS total_hashes,
                    SUM(is_cached)                                    AS cached_count,
                    MAX(score)                                        AS best_score,
                    MAX(CASE WHEN is_cached=1 THEN quality END)       AS best_quality,
                    MAX(CASE WHEN media_type='series' AND is_cached=1 THEN 1 ELSE 0 END) AS has_series_pack,
                    MAX(CASE WHEN media_type='season' AND is_cached=1 THEN 1 ELSE 0 END) AS has_season_pack,
                    COUNT(DISTINCT CASE WHEN media_type IN ('season','episode') THEN season END) AS season_count,
                    MAX(last_checked)                                 AS last_checked,
                    MAX(last_used)                                    AS last_used
                FROM hash_index
                GROUP BY title_norm, kind
                ORDER BY title COLLATE NOCASE
                """
            ).fetchall()
        return [dict(r) for r in rows]

    def list_hashes_for_title(self, title: str) -> list[dict]:
        """Return every hash row for a title — for the detail drill-down."""
        with self._conn() as c:
            rows = c.execute(
                """SELECT * FROM hash_index
                   WHERE title_norm = ?
                   ORDER BY is_cached DESC, score DESC""",
                (_norm(title),),
            ).fetchall()
        return [dict(r) for r in rows]
