"""
resolver.py — Play-triggered resolution.

This is the ONLY path that calls add_magnet() on AllDebrid.
It is invoked exclusively when a user presses play in Plex.

Flow:
    1. Plex webhook / Tautulli fires → PlayEvent created
    2. resolve_on_play() consults the Hash Index
    3a. HIT  → add_magnet() → register in FUSE → create symlink → done
    3b. MISS → search_and_index() populates the index → retry lookup
              → if still nothing: log miss, return (no placeholder created)

Nothing outside this module calls add_magnet().
Nothing in this module creates placeholders.
"""

from __future__ import annotations

import asyncio
import logging
import re
from pathlib import Path
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from fastapi import FastAPI

from .hash_index import HashIndex
from .indexer import search_and_index

log = logging.getLogger("debridarr.resolver")

_HASH_RE    = re.compile(r"btih:([a-fA-F0-9]{40})", re.I)
_VIDEO_EXTS = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}


def _detect_quality(name: str) -> str:
    n = name.lower()
    for q in ("2160p", "4k", "uhd", "1080p", "720p", "480p"):
        if q in n:
            return q
    return "unknown"


def _pick_file(files: list[dict], season: Optional[int], episode: Optional[int]) -> Optional[dict]:
    """Pick the best file from a torrent's file list for a given episode."""
    videos = [f for f in files if any(f.get("n", "").lower().endswith(e) for e in _VIDEO_EXTS)]
    if not videos:
        return None

    if season and episode:
        pat = f"S{season:02d}E{episode:02d}".upper()
        for f in videos:
            if pat in f.get("n", "").upper():
                return f

    # Largest file as fallback
    return max(videos, key=lambda f: f.get("s", 0))


async def resolve_on_play(
    app: "FastAPI",
    *,
    title: str,
    year: Optional[int],
    media_type: str,
    season: Optional[int],
    episode: Optional[int],
    cache_key: str,
) -> bool:
    """
    Resolve a play request. Returns True if resolved, False if not found.

    On True: the symlink exists in plex_root and the DB entry is 'cached'.
    On False: nothing is created. Plex will show the item as unavailable.
    """
    from .fuse_mount import (
        FUSE_AVAILABLE,
        register_torrent,
        get_fuse_path,
    )

    hi:        HashIndex   = getattr(app.state, "hash_index", None)
    alldebrid              = app.state.alldebrid
    db                     = app.state.db
    s                      = app.state.settings
    settings               = db.get_all_settings()
    preferred_quality      = settings.get(
        "movie_preferred_quality" if media_type == "movie" else "series_preferred_quality",
        "1080p",
    )
    jackett_url = settings.get("JACKETT_URL", "")
    jackett_key = settings.get("JACKETT_API_KEY", "")

    if not hi or not alldebrid or not alldebrid.api_key:
        log.error("resolver: hash index or alldebrid not ready")
        return False

    # ── 1. Hash index lookup ──────────────────────────────────────────────────
    candidates = hi.lookup(
        title,
        season=season,
        episode=episode,
        cached_only=True,
    )

    # ── 2. Miss path — search Jackett, populate index, retry ─────────────────
    if not candidates:
        log.info(f"[MISS] {title!r} S{season}E{episode} — triggering live search")
        db.update_status(cache_key, "resolving")

        if jackett_url and jackett_key:
            found = await search_and_index(
                hi,
                jackett_url=jackett_url,
                jackett_key=jackett_key,
                api_key=alldebrid.api_key,
                title=title,
                year=year,
                media_type=media_type,
                season=season,
                episode=episode,
                preferred_quality=preferred_quality,
            )
            if found:
                candidates = hi.lookup(title, season=season, episode=episode, cached_only=True)

        if not candidates:
            log.warning(f"[NOT FOUND] {title!r} — nothing cached on AllDebrid")
            db.update_status(cache_key, "not_found")
            return False

    # ── 3. Hit path — add_magnet, register FUSE, create symlink ──────────────
    best = candidates[0]
    log.info(
        f"[HIT] {title!r} — {best['torrent_name']!r} "
        f"score={best['score']} q={best['quality']}"
    )
    db.update_status(cache_key, "resolving")

    # add_magnet — the ONE place this is called
    result = await alldebrid.add_magnet(best["magnet"])
    if not result:
        log.warning(
            f"add_magnet failed for {best['info_hash']!r} — marking uncached, "
            f"will retry next play"
        )
        hi.mark_uncached(best["info_hash"])
        db.update_status(cache_key, "not_found")
        return False

    magnet_id, files = result
    torrent_name     = best["torrent_name"]

    # Pick the right file
    target_file = _pick_file(files, season, episode)
    if not target_file:
        log.error(f"No video file found in torrent for {cache_key}")
        db.update_status(cache_key, "error")
        return False

    filename  = target_file.get("n", torrent_name)
    ad_link   = target_file.get("l", "")
    file_size = target_file.get("s", 0)

    # FUSE folder name — handle name truncation
    stem        = Path(filename).stem
    fuse_folder = stem if (stem and torrent_name and stem.startswith(torrent_name.rstrip("-"))) else torrent_name
    quality     = _detect_quality(filename) or best["quality"]

    # Update hash index: this hash was used, update file count/size
    hi.upsert(
        media_type=best["media_type"],
        title=title, year=year,
        season=best.get("season"), episode=best.get("episode"),
        info_hash=best["info_hash"],
        magnet=best["magnet"],
        torrent_name=torrent_name,
        quality=quality,
        strategy=best.get("strategy", "unknown"),
        is_cached=True,
        file_count=len(files),
        file_size=file_size,
    )
    hi.touch(best["info_hash"])

    # Register all files in FUSE and create symlink
    strm_path = None
    fuse_thread = getattr(app.state, "fuse_thread", None)

    if s.PLEX_ROOT:
        if FUSE_AVAILABLE and fuse_thread:
            register_torrent(fuse_folder, files)
            fuse_virtual = get_fuse_path(fuse_folder, filename, s.FUSE_SYMLINK_ROOT)
            link = _make_symlink(
                cache_key=cache_key,
                title=title, year=year,
                season=season, episode=episode,
                media_type=media_type,
                plex_root=s.PLEX_ROOT,
                target=fuse_virtual,
                video_name=filename,
            )
            strm_path = str(link) if link else None
        else:
            # FUSE unavailable — write .strm redirect file
            from .proxy import write_strm
            p = write_strm(
                cache_key=cache_key,
                title=title, year=year,
                season=season, episode=episode,
                media_type=media_type,
                debridarr_base_url=s.DEBRIDARR_BASE_URL,
                plex_root=s.PLEX_ROOT,
            )
            strm_path = str(p) if p else None

    db.update_cached(cache_key, best["magnet"], ad_link, torrent_name, quality, strm_path)
    log.info(f"[DONE] {cache_key} → {strm_path}")

    # Symlink remaining pack episodes in the background (120s delay)
    if (
        media_type == "episode"
        and season
        and len(files) > 1
        and best["media_type"] in ("season", "series")
    ):
        asyncio.create_task(
            _symlink_pack_rest(
                app=app,
                files=files,
                magnet=best["magnet"],
                torrent_name=torrent_name,
                fuse_folder=fuse_folder,
                quality=quality,
                title=title, year=year,
                season=season,
                played_episode=episode,
                media_type=media_type,
                is_series_pack=(best["media_type"] == "series"),
            )
        )

    return True


def _make_symlink(
    *,
    cache_key: str,
    title: str,
    year: Optional[int],
    season: Optional[int],
    episode: Optional[int],
    media_type: str,
    plex_root: str,
    target: str,
    video_name: str,
) -> Optional[Path]:
    """
    Create a symlink in plex_root pointing to the FUSE virtual path.
    No placeholder files are created — if the symlink can't be made,
    we return None and the DB entry stays 'not_found'.
    """
    try:
        if media_type == "movie":
            yp     = f" ({year})" if year else ""
            folder = Path(plex_root) / "movies" / f"{title}{yp}"
            link   = folder / video_name
        else:
            sf     = f"Season {season:02d}" if season else "Season 00"
            folder = Path(plex_root) / "tv" / title / sf
            link   = folder / video_name

        folder.mkdir(parents=True, exist_ok=True)

        # Remove any stale symlink for this episode slot
        if media_type != "movie" and season and episode:
            pat = f"S{season:02d}E{episode:02d}".upper()
            for f in folder.iterdir():
                if f.is_symlink() and pat in f.name.upper():
                    f.unlink(missing_ok=True)

        if link.is_symlink() or link.exists():
            link.unlink(missing_ok=True)

        link.symlink_to(target)
        log.info(f"[SYMLINK] {link.name} → {target}")
        return link

    except Exception as e:
        log.error(f"[SYMLINK] Failed for {cache_key}: {e}")
        return None


async def _symlink_pack_rest(
    *,
    app: "FastAPI",
    files: list[dict],
    magnet: str,
    torrent_name: str,
    fuse_folder: str,
    quality: str,
    title: str,
    year: Optional[int],
    season: int,
    played_episode: Optional[int],
    media_type: str,
    is_series_pack: bool,
):
    """
    After a 120s delay, symlink all remaining episodes in a pack.
    Only creates entries for episodes in the hash index — no new
    placeholders for episodes not already known.
    """
    await asyncio.sleep(120)

    from .fuse_mount import FUSE_AVAILABLE, get_fuse_path
    from .models import PlayEvent, MediaType

    db  = app.state.db
    s   = app.state.settings
    hi: HashIndex = getattr(app.state, "hash_index", None)

    if not s.PLEX_ROOT:
        return

    fuse_thread = getattr(app.state, "fuse_thread", None)

    for f in files:
        fname = f.get("n", "")
        if not any(fname.lower().endswith(e) for e in _VIDEO_EXTS):
            continue

        m = re.search(r"[Ss](\d{1,2})[Ee](\d{1,2})", fname)
        if not m:
            continue

        ep_season  = int(m.group(1))
        ep_episode = int(m.group(2))

        # Skip the episode already handled by the main resolve path
        if ep_season == season and ep_episode == played_episode:
            continue
        # Season pack: only handle the requested season
        if not is_series_pack and ep_season != season:
            continue

        ad_link = f.get("l", "")
        if not ad_link:
            continue

        ep_event = PlayEvent(
            media_type=MediaType.episode,
            title=title, year=year,
            season=ep_season, episode=ep_episode,
        )
        ck = ep_event.cache_key()

        existing = db.get(ck)
        if existing and existing["status"] == "cached":
            continue

        db.upsert(ck, ep_event, status="resolving")

        strm_path = None
        if FUSE_AVAILABLE and fuse_thread:
            fuse_virtual = get_fuse_path(fuse_folder, fname, s.FUSE_SYMLINK_ROOT)
            link = _make_symlink(
                cache_key=ck,
                title=title, year=year,
                season=ep_season, episode=ep_episode,
                media_type=media_type,
                plex_root=s.PLEX_ROOT,
                target=fuse_virtual,
                video_name=fname,
            )
            strm_path = str(link) if link else None

        db.update_cached(ck, magnet, ad_link, torrent_name, quality, strm_path)

        # Write-back to hash index
        if hi:
            h = _HASH_RE.search(magnet)
            if h:
                hi.upsert(
                    media_type="episode",
                    title=title, year=year,
                    season=ep_season, episode=ep_episode,
                    info_hash=h.group(1).lower(),
                    magnet=magnet,
                    torrent_name=torrent_name,
                    quality=quality,
                    strategy="season_pack" if not is_series_pack else "series_pack",
                    is_cached=True,
                    file_size=f.get("s", 0),
                )

        log.info(f"[PACK] S{ep_season:02d}E{ep_episode:02d} → {fname}")
