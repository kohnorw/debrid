"""
SQLite cache for Debridarr.
Tables:
  cache          — resolved AllDebrid links (30-day TTL)
  fake_library   — items added to the Plex placeholder library
  app_settings   — all app + search settings
"""

import sqlite3
import logging
from datetime import datetime, timedelta
from typing import Optional
from app.models import PlayEvent, MediaType

log = logging.getLogger("debridarr.cache")

TTL_DAYS = 30  # default, overridden by DB setting

SEARCH_DEFAULTS = {
    # Series search strategy
    "series_completed_strategy":  "series_pack",   # series_pack | season_pack | episode
    "series_ongoing_strategy":    "season_pack",    # season_pack | episode
    "series_preferred_quality":   "1080p",          # 1080p | 720p | any
    "series_fallback_any_quality": "true",          # fall back to any quality if preferred not found
    # Movie search strategy
    "movie_preferred_quality":    "1080p",
    "movie_fallback_any_quality": "true",
    # General
    "cache_ttl_days":             "30",
    "symlink_retention_days":     "30",
    "auto_add_requests":          "false",
    "auto_add_interval_minutes":   "60",
    "precache_enabled":           "true",
    "precache_cooldown_minutes":  "1",
    "include_unreleased_episodes": "false",
    "allow_uncached_downloads": "true",
    "tmdb_api_key":               "",
    # Prowlarr safety / anti-ban guardrails
    "PROWLARR_MIN_SECONDS_BETWEEN_SEARCHES": "3",
    "PROWLARR_SEARCH_LIMIT": "50",
    "PROWLARR_RATE_LIMIT_COOLDOWN_SECONDS": "900",
    "PROWLARR_UNAVAILABLE_COOLDOWN_SECONDS": "300",
}


class CacheDB:
    def __init__(self, db_path: str):
        self.db_path = db_path

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        return conn

    def init(self):
        with self._connect() as conn:
            # ── Resolved link cache ──────────────────────────────────────────
            conn.execute("""
                CREATE TABLE IF NOT EXISTS pin_exemptions (
                    id         INTEGER PRIMARY KEY AUTOINCREMENT,
                    title      TEXT    NOT NULL UNIQUE,
                    media_type TEXT    NOT NULL DEFAULT 'movie',
                    note       TEXT,
                    created_at INTEGER DEFAULT (strftime('%s','now'))
                )""")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS upcoming_episodes (
                    id           INTEGER PRIMARY KEY AUTOINCREMENT,
                    title        TEXT    NOT NULL,
                    year         INTEGER,
                    sonarr_id    INTEGER,
                    season       INTEGER NOT NULL,
                    episode      INTEGER NOT NULL,
                    air_date     TEXT    NOT NULL,
                    indexed      INTEGER DEFAULT 0,
                    placeholder  INTEGER DEFAULT 0,
                    created_at   INTEGER DEFAULT (strftime('%s','now')),
                    updated_at   INTEGER DEFAULT (strftime('%s','now')),
                    UNIQUE(title, season, episode)
                )""")
            conn.execute("CREATE INDEX IF NOT EXISTS ix_ue_air_date ON upcoming_episodes (air_date)")
            conn.execute("CREATE INDEX IF NOT EXISTS ix_ue_title ON upcoming_episodes (title)")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS cache (
                    cache_key         TEXT PRIMARY KEY,
                    media_type        TEXT NOT NULL,
                    title             TEXT NOT NULL,
                    year              INTEGER,
                    season            INTEGER,
                    episode           INTEGER,
                    quality           TEXT,
                    torrent_name      TEXT,
                    magnet_link       TEXT,
                    stream_url        TEXT,
                    strm_path         TEXT,
                    status            TEXT NOT NULL DEFAULT 'pending',
                    link_refreshed_at TEXT,
                    created_at        TEXT NOT NULL,
                    expires_at        TEXT NOT NULL,
                    last_accessed     TEXT
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_cache_expires ON cache(expires_at)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_cache_status  ON cache(status)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_cache_title   ON cache(title)")

            # Migrations
            existing_cols = {r[1] for r in conn.execute("PRAGMA table_info(cache)").fetchall()}
            if "strm_path" not in existing_cols:
                conn.execute("ALTER TABLE cache ADD COLUMN strm_path TEXT")

            # ── Fake library ─────────────────────────────────────────────────
            conn.execute("""
                CREATE TABLE IF NOT EXISTS fake_library (
                    id            INTEGER PRIMARY KEY AUTOINCREMENT,
                    media_type    TEXT NOT NULL,
                    title         TEXT NOT NULL,
                    year          INTEGER,
                    sonarr_id     INTEGER,
                    radarr_id     INTEGER,
                    tvdb_id       INTEGER,
                    tmdb_id       INTEGER,
                    imdb_id       TEXT,
                    season_count  INTEGER,
                    poster_url    TEXT,
                    overview      TEXT,
                    status        TEXT DEFAULT 'ended',
                    fake_path     TEXT,
                    added_at      TEXT NOT NULL,
                    UNIQUE(media_type, title, year)
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_fake_type ON fake_library(media_type)")

            # Migrations for fake_library
            fl_cols = {r[1] for r in conn.execute("PRAGMA table_info(fake_library)").fetchall()}
            for col, typ in [("poster_url", "TEXT"), ("overview", "TEXT"), ("status", "TEXT")]:
                if col not in fl_cols:
                    conn.execute(f"ALTER TABLE fake_library ADD COLUMN {col} {typ}")

            # ── App + search settings ─────────────────────────────────────────
            conn.execute("""
                CREATE TABLE IF NOT EXISTS app_settings (
                    key   TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                )
            """)
            for k, v in SEARCH_DEFAULTS.items():
                conn.execute(
                    "INSERT OR IGNORE INTO app_settings (key, value) VALUES (?,?)", (k, v)
                )

            # ── Uncached torrent download queue ────────────────────────────────
            conn.execute("""
                CREATE TABLE IF NOT EXISTS downloads (
                    id            INTEGER PRIMARY KEY AUTOINCREMENT,
                    magnet_id     TEXT,
                    info_hash     TEXT,
                    magnet        TEXT NOT NULL,
                    torrent_name  TEXT,
                    title         TEXT,
                    media_type    TEXT DEFAULT 'movie',
                    year          INTEGER,
                    season        INTEGER,
                    episode       INTEGER,
                    quality       TEXT DEFAULT 'unknown',
                    seeders       INTEGER DEFAULT 0,
                    size          INTEGER DEFAULT 0,
                    status        TEXT DEFAULT 'queued',
                    progress      REAL DEFAULT 0,
                    source        TEXT DEFAULT 'search',
                    error         TEXT,
                    created_at    INTEGER DEFAULT (strftime('%s','now')),
                    updated_at    INTEGER DEFAULT (strftime('%s','now')),
                    UNIQUE(info_hash)
                )""")
            conn.execute("CREATE INDEX IF NOT EXISTS ix_downloads_status ON downloads(status)")
            conn.execute("CREATE INDEX IF NOT EXISTS ix_downloads_hash ON downloads(info_hash)")

        log.info(f"Cache DB ready at {self.db_path}")

    def ttl_days(self) -> int:
        """Retention window for played/pre-symlinked media.

        symlink_retention_days is the preferred setting. cache_ttl_days is
        kept as a backwards-compatible fallback for older installs.
        """
        try:
            return int(self.get_setting("symlink_retention_days", "") or self.get_setting("cache_ttl_days", "30") or "30")
        except (TypeError, ValueError):
            return 30

    # ── Cache reads ────────────────────────────────────────────────────────────

    def get(self, cache_key: str) -> Optional[dict]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM cache WHERE cache_key = ?", (cache_key,)
            ).fetchone()
            if not row:
                return None
            conn.execute(
                "UPDATE cache SET last_accessed = ? WHERE cache_key = ?",
                (datetime.utcnow().isoformat(), cache_key),
            )
            return dict(row)

    def list_all(self) -> list[dict]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM cache ORDER BY created_at DESC"
            ).fetchall()
            return [dict(r) for r in rows]

    def list_expired(self) -> list[dict]:
        now = datetime.utcnow().isoformat()
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM cache WHERE expires_at < ?", (now,)
            ).fetchall()
            return [dict(r) for r in rows]

    # ── Cache writes ───────────────────────────────────────────────────────────

    def upsert(self, cache_key: str, event: PlayEvent, status: str = "pending"):
        now = datetime.utcnow()
        expires = now + timedelta(days=self.ttl_days())
        with self._connect() as conn:
            conn.execute("""
                INSERT INTO cache
                    (cache_key, media_type, title, year, season, episode, status, created_at, expires_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(cache_key) DO UPDATE SET
                    status = excluded.status,
                    last_accessed = ?
            """, (
                cache_key,
                event.media_type.value,
                event.title,
                event.year,
                event.season,
                event.episode,
                status,
                now.isoformat(),
                expires.isoformat(),
                now.isoformat(),
            ))

    def update_status(self, cache_key: str, status: str):
        with self._connect() as conn:
            conn.execute(
                "UPDATE cache SET status = ? WHERE cache_key = ?",
                (status, cache_key),
            )

    def update_cached(self, cache_key: str, magnet: str, stream_url: str,
                      torrent_name: str, quality: str, strm_path: Optional[str] = None):
        now = datetime.utcnow()
        expires = now + timedelta(days=self.ttl_days())
        with self._connect() as conn:
            conn.execute("""
                UPDATE cache SET
                    status            = 'cached',
                    magnet_link       = ?,
                    stream_url        = ?,
                    torrent_name      = ?,
                    quality           = ?,
                    strm_path         = ?,
                    link_refreshed_at = ?,
                    expires_at        = ?
                WHERE cache_key = ?
            """, (magnet, stream_url, torrent_name, quality,
                  strm_path, now.isoformat(), expires.isoformat(), cache_key))

    def update_stream_url(self, cache_key: str, stream_url: str):
        now = datetime.utcnow()
        with self._connect() as conn:
            conn.execute(
                "UPDATE cache SET stream_url = ?, link_refreshed_at = ? WHERE cache_key = ?",
                (stream_url, now.isoformat(), cache_key),
            )

    def delete(self, cache_key: str):
        with self._connect() as conn:
            conn.execute("DELETE FROM cache WHERE cache_key = ?", (cache_key,))

    def refresh_ttl(self, cache_key: str):
        """Extend TTL for an active entry — called when symlink is confirmed working."""
        expires = (datetime.utcnow() + timedelta(days=self.ttl_days())).isoformat()
        with self._connect() as conn:
            conn.execute(
                "UPDATE cache SET expires_at=?, last_accessed=? WHERE cache_key=?",
                (expires, datetime.utcnow().isoformat(), cache_key)
            )

    def purge_expired(self) -> int:
        """Delete all expired entries from DB (symlinks already removed by _hard_expire)."""
        now = datetime.utcnow().isoformat()
        with self._connect() as conn:
            result = conn.execute("DELETE FROM cache WHERE expires_at < ?", (now,))
            return result.rowcount

    # ── App settings ─────────────────────────────────────────────────────────

    def get_setting(self, key: str, default: str = "") -> str:
        with self._connect() as conn:
            row = conn.execute("SELECT value FROM app_settings WHERE key=?", (key,)).fetchone()
            return row[0] if row else default

    def set_setting(self, key: str, value: str):
        with self._connect() as conn:
            conn.execute("INSERT OR REPLACE INTO app_settings (key, value) VALUES (?,?)", (key, value))

    def get_all_settings(self) -> dict:
        with self._connect() as conn:
            rows = conn.execute("SELECT key, value FROM app_settings").fetchall()
            return {r[0]: r[1] for r in rows}

    def set_settings(self, settings: dict):
        with self._connect() as conn:
            for k, v in settings.items():
                conn.execute("INSERT OR REPLACE INTO app_settings (key, value) VALUES (?,?)", (k, str(v)))


    # ── Downloads queue ───────────────────────────────────────────────────────

    def upsert_download(self, *, magnet: str, info_hash: str = "", magnet_id: str = "",
                        torrent_name: str = "", title: str = "", media_type: str = "movie",
                        year=None, season=None, episode=None, quality: str = "unknown",
                        seeders: int = 0, size: int = 0, status: str = "queued",
                        progress: float = 0, source: str = "search", error: str = "") -> int:
        now = int(__import__('time').time())
        info_hash = (info_hash or "").lower().strip()
        with self._connect() as conn:
            conn.execute(
                """INSERT INTO downloads
                   (magnet_id, info_hash, magnet, torrent_name, title, media_type,
                    year, season, episode, quality, seeders, size, status, progress,
                    source, error, created_at, updated_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(info_hash) DO UPDATE SET
                     magnet_id=COALESCE(NULLIF(excluded.magnet_id,''), downloads.magnet_id),
                     magnet=excluded.magnet,
                     torrent_name=excluded.torrent_name,
                     title=excluded.title,
                     media_type=excluded.media_type,
                     year=excluded.year,
                     season=excluded.season,
                     episode=excluded.episode,
                     quality=excluded.quality,
                     seeders=excluded.seeders,
                     size=excluded.size,
                     status=excluded.status,
                     progress=excluded.progress,
                     source=excluded.source,
                     error=excluded.error,
                     updated_at=excluded.updated_at""",
                (magnet_id, info_hash, magnet, torrent_name, title, media_type,
                 year, season, episode, quality, seeders, size, status, progress,
                 source, error, now, now),
            )
            row = conn.execute("SELECT id FROM downloads WHERE info_hash=?", (info_hash,)).fetchone()
            return int(row[0]) if row else 0

    def update_download(self, info_hash: str = "", magnet_id: str = "", **fields):
        allowed = {"magnet_id", "status", "progress", "error", "updated_at"}
        fields["updated_at"] = int(__import__('time').time())
        pairs = [(k, v) for k, v in fields.items() if k in allowed]
        if not pairs:
            return 0
        where = "info_hash=?" if info_hash else "magnet_id=?"
        val = (info_hash or magnet_id)
        with self._connect() as conn:
            cur = conn.execute(
                "UPDATE downloads SET " + ", ".join(f"{k}=?" for k, _ in pairs) + f" WHERE {where}",
                [v for _, v in pairs] + [val],
            )
            return cur.rowcount

    def list_downloads(self) -> list[dict]:
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM downloads ORDER BY updated_at DESC, created_at DESC").fetchall()
        return [dict(r) for r in rows]

    def get_download(self, info_hash: str) -> dict | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM downloads WHERE info_hash=?", ((info_hash or '').lower(),)).fetchone()
        return dict(row) if row else None

    def delete_download(self, info_hash: str = "", magnet_id: str = "") -> int:
        with self._connect() as conn:
            if info_hash:
                r = conn.execute("DELETE FROM downloads WHERE info_hash=?", ((info_hash or '').lower(),))
            else:
                r = conn.execute("DELETE FROM downloads WHERE magnet_id=?", (magnet_id,))
            return r.rowcount

    # ── Upcoming episodes ─────────────────────────────────────────────────────

    def upsert_upcoming(self, title: str, year: int, sonarr_id: int,
                        season: int, episode: int, air_date: str):
        """Track an upcoming episode. air_date is ISO YYYY-MM-DD."""
        with self._connect() as conn:
            conn.execute(
                """INSERT INTO upcoming_episodes
                   (title, year, sonarr_id, season, episode, air_date, updated_at)
                   VALUES (?,?,?,?,?,?, strftime('%s','now'))
                   ON CONFLICT(title, season, episode) DO UPDATE SET
                     air_date=excluded.air_date,
                     updated_at=strftime('%s','now')""",
                (title, year, sonarr_id, season, episode, air_date),
            )

    def get_due_upcoming(self) -> list[dict]:
        """Return upcoming episodes whose air_date has passed and haven't been indexed yet."""
        today = __import__('datetime').date.today().isoformat()
        with self._connect() as conn:
            rows = conn.execute(
                """SELECT * FROM upcoming_episodes
                   WHERE air_date <= ? AND indexed = 0
                   ORDER BY air_date""",
                (today,),
            ).fetchall()
        return [dict(r) for r in rows]

    def get_all_upcoming(self) -> list[dict]:
        """Return all upcoming episodes not yet aired."""
        today = __import__('datetime').date.today().isoformat()
        with self._connect() as conn:
            rows = conn.execute(
                """SELECT * FROM upcoming_episodes
                   WHERE air_date > ? AND placeholder = 0
                   ORDER BY air_date""",
                (today,),
            ).fetchall()
        return [dict(r) for r in rows]

    def mark_upcoming_indexed(self, title: str, season: int, episode: int):
        with self._connect() as conn:
            conn.execute(
                """UPDATE upcoming_episodes
                   SET indexed=1, updated_at=strftime('%s','now')
                   WHERE title=? AND season=? AND episode=?""",
                (title, season, episode),
            )

    def mark_upcoming_placeholder(self, title: str, season: int, episode: int):
        with self._connect() as conn:
            conn.execute(
                """UPDATE upcoming_episodes
                   SET placeholder=1, updated_at=strftime('%s','now')
                   WHERE title=? AND season=? AND episode=?""",
                (title, season, episode),
            )

    def remove_upcoming(self, title: str, season: int = None, episode: int = None):
        with self._connect() as conn:
            if season and episode:
                conn.execute(
                    "DELETE FROM upcoming_episodes WHERE title=? AND season=? AND episode=?",
                    (title, season, episode),
                )
            else:
                conn.execute("DELETE FROM upcoming_episodes WHERE title=?", (title,))

    # ── Pin exemptions ────────────────────────────────────────────────────────

    def add_pin_exemption(self, title: str, media_type: str = "movie", note: str = ""):
        """Exempt a title from TTL expiry — it will be re-resolved every 30 days instead."""
        with self._connect() as conn:
            conn.execute(
                """INSERT INTO pin_exemptions (title, media_type, note)
                   VALUES (?,?,?)
                   ON CONFLICT(title) DO UPDATE SET media_type=excluded.media_type,
                   note=excluded.note""",
                (title, media_type, note),
            )

    def remove_pin_exemption(self, title: str):
        with self._connect() as conn:
            conn.execute("DELETE FROM pin_exemptions WHERE title=?", (title,))

    def list_pin_exemptions(self) -> list[dict]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM pin_exemptions ORDER BY title"
            ).fetchall()
        return [dict(r) for r in rows]

    def is_pinned(self, title: str) -> bool:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT 1 FROM pin_exemptions WHERE title=?", (title,)
            ).fetchone()
        return row is not None

    def bootstrap_from_env(self):
        """Seed app_settings from environment variables on first run.
        Only writes a key if it isn't already set in the DB."""
        import os
        env_keys = [
            "ALLDEBRID_API_KEY", "OVERSEERR_URL", "OVERSEERR_API_KEY",
            "DEBRIDARR_BASE_URL", "PLEX_ROOT", "SONARR_URL", "SONARR_API_KEY",
            "RADARR_URL", "RADARR_API_KEY", "PROWLARR_URL", "PROWLARR_API_KEY",
            "PROWLARR_MIN_SECONDS_BETWEEN_SEARCHES", "PROWLARR_SEARCH_LIMIT",
            "PROWLARR_RATE_LIMIT_COOLDOWN_SECONDS", "PROWLARR_UNAVAILABLE_COOLDOWN_SECONDS",
            "symlink_retention_days",
            "TZ", "PUID", "PGID",
        ]
        with self._connect() as conn:
            for key in env_keys:
                val = os.environ.get(key, "")
                if val:
                    conn.execute(
                        "INSERT OR IGNORE INTO app_settings (key, value) VALUES (?,?)",
                        (key, val),
                    )

    # ── Fake library ──────────────────────────────────────────────────────────

    def fake_library_add(self, entry: dict) -> bool:
        now = datetime.utcnow().isoformat()
        try:
            with self._connect() as conn:
                conn.execute("""
                    INSERT INTO fake_library
                        (media_type, title, year, sonarr_id, radarr_id,
                         tvdb_id, tmdb_id, imdb_id, season_count,
                         poster_url, overview, status, fake_path, added_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(media_type, title, year) DO UPDATE SET
                        fake_path    = excluded.fake_path,
                        season_count = excluded.season_count,
                        poster_url   = excluded.poster_url,
                        overview     = excluded.overview,
                        status       = excluded.status,
                        added_at     = excluded.added_at
                """, (
                    entry["media_type"],
                    entry["title"],
                    entry.get("year"),
                    entry.get("sonarr_id"),
                    entry.get("radarr_id"),
                    entry.get("tvdb_id"),
                    entry.get("tmdb_id"),
                    entry.get("imdb_id"),
                    entry.get("season_count"),
                    entry.get("poster_url"),
                    entry.get("overview"),
                    entry.get("status", "ended"),
                    entry.get("fake_path"),
                    now,
                ))
            return True
        except Exception as e:
            log.error(f"fake_library_add failed: {e}")
            return False

    def fake_library_remove(self, media_type: str, title: str, year: Optional[int]) -> bool:
        with self._connect() as conn:
            conn.execute(
                "DELETE FROM fake_library WHERE media_type=? AND title=? AND year IS ?",
                (media_type, title, year),
            )
        return True

    def fake_library_list(self, media_type: Optional[str] = None) -> list[dict]:
        with self._connect() as conn:
            if media_type:
                rows = conn.execute(
                    "SELECT * FROM fake_library WHERE media_type=? ORDER BY title",
                    (media_type,),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM fake_library ORDER BY media_type, title"
                ).fetchall()
            return [dict(r) for r in rows]

    def fake_library_get(self, media_type: str, title: str, year: Optional[int]) -> Optional[dict]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM fake_library WHERE media_type=? AND title=? AND year IS ?",
                (media_type, title, year),
            ).fetchone()
            return dict(row) if row else None

    def fake_library_set_season_count(self, title: str, media_type: str, season_count: int) -> int:
        """
        Update the stored season_count for a library entry. Used when TMDB
        reports a different count than what Overseerr/Sonarr originally
        provided — TMDB is authoritative. Returns rows affected (0 if title
        isn't in the library).
        """
        with self._connect() as conn:
            r = conn.execute(
                "UPDATE fake_library SET season_count = ? "
                "WHERE media_type = ? AND title = ?",
                (int(season_count), media_type, title),
            )
            return r.rowcount
