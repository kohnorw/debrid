"""Data models for Debridarr."""

import re
from enum import Enum
from typing import Optional

from pydantic import BaseModel


class MediaType(str, Enum):
    movie = "movie"
    episode = "episode"


class PlayEvent(BaseModel):
    media_type: MediaType
    title: str
    year: Optional[int] = None
    season: Optional[int] = None
    episode: Optional[int] = None
    rating_key: Optional[str] = None
    imdb_id: Optional[str] = None
    tmdb_id: Optional[str] = None
    tvdb_id: Optional[str] = None

    @classmethod
    def from_cache_key(cls, key: str) -> "PlayEvent":
        """Reconstruct a minimal PlayEvent from a cache key (best-effort, for on-play resolve)."""
        if key.startswith("movie_"):
            rest = key[len("movie_"):]
            # title may contain year suffix _YYYY
            m = re.match(r"^(.+?)(?:_(\d{4}))?$", rest)
            title_raw = m.group(1) if m else rest
            year = int(m.group(2)) if (m and m.group(2)) else None
            title = title_raw.replace("_", " ").title()
            return cls(media_type=MediaType.movie, title=title, year=year)
        elif key.startswith("episode_"):
            rest = key[len("episode_"):]
            m = re.match(r"^(.+?)_s(\d+)e(\d+)$", rest)
            if m:
                title = m.group(1).replace("_", " ").title()
                return cls(media_type=MediaType.episode, title=title,
                           season=int(m.group(2)), episode=int(m.group(3)))
            return cls(media_type=MediaType.episode, title=rest.replace("_", " ").title())
        raise ValueError(f"Cannot parse cache_key: {key!r}")

    def cache_key(self) -> str:
        """Generate a stable, filesystem-safe cache key for this media item."""
        clean = re.sub(r"[^\w\s]", "", self.title).strip().lower().replace(" ", "_")
        if self.media_type == MediaType.movie:
            year_part = f"_{self.year}" if self.year else ""
            return f"movie_{clean}{year_part}"
        else:
            s = f"_s{self.season:02d}" if self.season else ""
            e = f"e{self.episode:02d}" if self.episode else ""
            return f"episode_{clean}{s}{e}"


class CachedLink(BaseModel):
    cache_key: str
    media_type: MediaType
    title: str
    year: Optional[int] = None
    season: Optional[int] = None
    episode: Optional[int] = None
    quality: str
    torrent_name: str
    stream_url: str
    status: str
    expires_at: str
