"""
Simulation tests for Debridarr rewrite.
Tests core logic without needing a running server or AllDebrid account.
"""
import asyncio
import sys
import os
sys.path.insert(0, "/home/claude/debridarr")
os.chdir("/home/claude/debridarr")

from app.alldebrid import (
    SearchConfig, _make_magnet, _is_cam, _is_foreign,
    _detect_quality, filter_by_season, filter_by_quality,
    _title_matches, _sanitize
)
from app.models import PlayEvent, MediaType

PASS = 0; FAIL = 0

def test(name, val, expect):
    global PASS, FAIL
    if val == expect:
        print(f"  ✅ {name}")
        PASS += 1
    else:
        print(f"  ❌ {name}: got {val!r}, expected {expect!r}")
        FAIL += 1

# ── SearchConfig.build_query ──────────────────────────────────────────────────
print("\n── SearchConfig.build_query ──")
cfg = SearchConfig.from_db({
    "template_movie": "{title} {year}",
    "template_episode": "{title} S{season}E{episode}",
    "template_season_pack": "{title} S{season}",
    "template_series_pack": "{title}",
    "search_extra_movie": "",
    "search_extra_series": "",
})
test("movie", cfg.build_query("Dune", 2021, None, None, "episode", "movie"), "Dune 2021")
test("episode", cfg.build_query("Breaking Bad", 2008, 3, 7, "episode", "series"), "Breaking Bad S03E07")
test("season_pack", cfg.build_query("Breaking Bad", 2008, 3, None, "season_pack", "series"), "Breaking Bad S03")
test("series_pack", cfg.build_query("Breaking Bad", 2008, None, None, "series_pack", "series"), "Breaking Bad")

cfg2 = SearchConfig.from_db({"template_movie": "{title} {year} 1080p", "search_extra_series": "WEB-DL"})
test("movie_suffix", cfg2.build_query("Alien", 2024, None, None, "episode", "movie"), "Alien 1080p")
test("series_extra", cfg2.build_query("Ted", 2024, 1, 1, "episode", "series"), "Ted S01E01 WEB-DL")

# ── _is_cam ───────────────────────────────────────────────────────────────────
print("\n── CAM/Foreign detection ──")
test("cam_ts", _is_cam("Movie.2025.TS.1080p.x264"), True)
test("cam_hdcam", _is_cam("Movie.2025.HDCAM"), True)
test("cam_ok", _is_cam("Movie.2025.WEB-DL.1080p"), False)
test("foreign_fr", _is_foreign("Movie.2025.FRENCH.1080p"), True)
test("foreign_ok", _is_foreign("Movie.2025.WEB-DL.1080p"), False)

# ── filter_by_season ──────────────────────────────────────────────────────────
print("\n── filter_by_season ──")
results = [
    {"name": "Show S01E03 1080p"},
    {"name": "Show S02E03 1080p"},
    {"name": "Show S01E04 1080p"},
]
s1e3 = filter_by_season(results, 1, 3, "episode")
test("ep_filter", [r["name"] for r in s1e3], ["Show S01E03 1080p"])

season_results = [
    {"name": "Show S01 Complete"},
    {"name": "Show S01E01 1080p"},
]
packs = filter_by_season(season_results, 1, None, "season_pack")
test("season_pack_filter", [r["name"] for r in packs], ["Show S01 Complete"])

# ── filter_by_quality ─────────────────────────────────────────────────────────
print("\n── filter_by_quality ──")
qresults = [
    {"name": "Movie 1080p WEB-DL"},
    {"name": "Movie 720p"},
    {"name": "Movie HDRip"},
]
q1080 = filter_by_quality(qresults, "1080p", False)
test("quality_1080p_no_fallback", len(q1080), 1)
q1080fb = filter_by_quality(qresults, "1080p", True)
test("quality_1080p_fallback", len(q1080fb), 3)  # preferred + fallback
q480 = filter_by_quality(qresults, "2160p", False)
test("quality_no_match_no_fallback", len(q480), 0)

# ── _title_matches ─────────────────────────────────────────────────────────────
print("\n── _title_matches ──")
test("title_match_basic", _title_matches("Breaking.Bad.S01E01.1080p", "Breaking Bad"), True)
test("title_match_fail", _title_matches("Better.Call.Saul.S01E01", "Breaking Bad"), False)
test("title_match_special", _title_matches("It's.Always.Sunny.S01E01", "Its Always Sunny"), True)

# ── _make_magnet ──────────────────────────────────────────────────────────────
print("\n── _make_magnet ──")
t = {"info_hash": "abc123", "name": "Test Movie 1080p"}
m = _make_magnet(t)
test("magnet_prefix", m.startswith("magnet:?xt=urn:btih:abc123"), True)
test("magnet_dn", "Test+Movie+1080p" in m or "Test%20Movie%201080p" in m or "Test" in m, True)

# ── PlayEvent.cache_key ───────────────────────────────────────────────────────
print("\n── PlayEvent.cache_key ──")
e1 = PlayEvent(media_type=MediaType.movie, title="Dune Part Two", year=2024)
test("movie_key", e1.cache_key(), "movie_dune_part_two_2024")
e2 = PlayEvent(media_type=MediaType.episode, title="Breaking Bad", year=2008, season=3, episode=7)
test("ep_key", e2.cache_key(), "episode_breaking_bad_s03e07")
e3 = PlayEvent(media_type=MediaType.episode, title="It's Always Sunny", season=1, episode=1)
test("ep_key_special", "sunny" in e3.cache_key(), True)

# ── Good quality gate (movies) ────────────────────────────────────────────────
print("\n── Movie quality gate ──")
import re
GOOD_Q = re.compile(r'\b(2160p?|1080p?|720p?|4k|uhd|web-?dl|webdl|bluray|blu-?ray|remux)\b', re.I)
good = [
    "Movie.2025.1080p.WEB-DL.x264",
    "Movie.2025.720p.BluRay",
    "Movie.2025.4K.UHD.REMUX",
]
bad = [
    "Movie.2025.HDRip.x264",
    "Movie.2025.DVDRip",
    "Movie.2025.HDCAM",
    "Movie.2025.XviD",
]
for name in good:
    test(f"good: {name[:30]}", bool(GOOD_Q.search(name)), True)
for name in bad:
    test(f"bad:  {name[:30]}", bool(GOOD_Q.search(name)), False)

# ── check_cache mock ──────────────────────────────────────────────────────────
print("\n── check_cache (mock) ──")
async def test_check_cache():
    """
    Verify check_cache collects ALL magnet IDs before checking errors,
    so everything gets deleted even if some magnets have errors.
    """
    ids_deleted = []
    
    mock_response = {
        "status": "success",
        "data": {"magnets": [
            {"id": 100, "hash": "aaa", "ready": True},   # cached
            {"id": 101, "hash": "bbb", "ready": False},  # not cached
            {"id": 102, "error": {"code": "MAGNET_INVALID"}},  # error — no id sometimes
            {"id": 103, "hash": "ccc", "ready": True},   # cached
        ]}
    }
    
    ready_map = {}
    ids_to_delete = []
    
    for m in mock_response["data"]["magnets"]:
        mid = m.get("id")
        if mid:
            ids_to_delete.append(mid)
        if m.get("error"):
            continue
        h = (m.get("hash") or "").lower()
        if h:
            ready_map[h] = bool(m.get("ready", False))
    
    test("all_ids_collected", sorted(ids_to_delete), [100, 101, 102, 103])
    test("cached_aaa", ready_map.get("aaa"), True)
    test("not_cached_bbb", ready_map.get("bbb"), False)
    test("cached_ccc", ready_map.get("ccc"), True)
    test("error_not_in_map", "error" not in str(ready_map), True)
    test("error_id_still_deleted", 102 in ids_to_delete, True)

asyncio.run(test_check_cache())

# ── Settings loading ──────────────────────────────────────────────────────────
print("\n── Settings ──")
from app.cache import CacheDB, SEARCH_DEFAULTS
import tempfile, os
with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
    db_path = f.name
db = CacheDB(db_path)
db.init()
settings = db.get_all_settings()
test("defaults_loaded", settings.get("no_cam"), "true")
test("template_movie", settings.get("template_movie"), "{title} {year}")
db.set_setting("no_cam", "false")
test("setting_updated", db.get_setting("no_cam"), "false")
os.unlink(db_path)

print(f"\n{'='*40}")
print(f"Results: {PASS} passed, {FAIL} failed")
sys.exit(0 if FAIL == 0 else 1)
