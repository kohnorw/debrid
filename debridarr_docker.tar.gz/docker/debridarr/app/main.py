"""
Debridarr - On-the-fly AllDebrid streaming for Plex

Flow:
  1. First run → setup wizard at /setup collects all config, tests live connections,
     writes /data/.env, reinitialises app without restart.
  2. User opens /library → browses Overseerr requests → clicks Add → zero-byte .mp4 created
  3. Plex scans the fake library, shows titles normally
  4. User hits Play → Tautulli webhook → Debridarr resolves real stream via AllDebrid
  5. /proxy/<key> streams bytes transparently, refreshing AllDebrid URLs as needed
"""

import asyncio
import importlib
import logging
import sys
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from app.alldebrid import AllDebridClient
from app.cache import CacheDB
from app.config import settings
from app.library import LibraryManager
from app.models import MediaType, PlayEvent
from app.proxy import proxy_stream, write_strm, delete_strm
from app.fuse_mount import (
    start_fuse_mount, stop_fuse_mount,
    register_torrent, unregister_torrent, get_fuse_path, list_torrents, list_files,
    FUSE_AVAILABLE, update_dfs_settings, get_dfs_settings,
)
from app.setup import (
    is_setup_complete, mark_setup_complete,
    load_saved_config, write_env,
    test_alldebrid, test_overseerr, test_plex_root,
)

logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("debridarr")




def _schedule_restart(delay: float = 2.0):
    """Schedule a container restart after a short delay."""
    import threading, subprocess, time
    def _do_restart():
        time.sleep(delay)
        log.info("🔄 Restarting container...")
        # Graceful: send SIGTERM to PID 1 (entrypoint), Docker will restart
        try:
            subprocess.run(["kill", "-TERM", "1"], check=False)
        except Exception as e:
            log.error(f"Restart failed: {e}")
    threading.Thread(target=_do_restart, daemon=True).start()


def _init_clients(app: FastAPI):
    """Initialise (or re-initialise) clients directly from os.environ.
    Never uses importlib.reload — that reads stale module-level values."""
    import os

    class _S:
        ALLDEBRID_API_KEY = os.environ.get("ALLDEBRID_API_KEY", "")
        OVERSEERR_URL     = os.environ.get("OVERSEERR_URL", "")
        OVERSEERR_API_KEY = os.environ.get("OVERSEERR_API_KEY", "")

        PLEX_ROOT         = os.environ.get("PLEX_ROOT", "/plex-strm")
        DEBRIDARR_BASE_URL= os.environ.get("DEBRIDARR_BASE_URL", "")
        DB_PATH           = os.environ.get("DB_PATH", "/data/debridarr.db")
        PORT              = int(os.environ.get("PORT", "7474"))
        LOG_LEVEL         = os.environ.get("LOG_LEVEL", "INFO")
        CACHE_TTL_DAYS    = int(os.environ.get("CACHE_TTL_DAYS", "30"))
        FUSE_MOUNT        = os.environ.get("FUSE_MOUNT", "/mnt/alldebrid")
        # Host path written into symlinks so Plex (outside container) resolves them
        FUSE_SYMLINK_ROOT = os.environ.get("FUSE_SYMLINK_ROOT", "/docker/debridarr/mnt-alldebrid")

    s = _S()
    app.state.alldebrid = AllDebridClient(s.ALLDEBRID_API_KEY)
    app.state.library = LibraryManager(
        overseerr_url=s.OVERSEERR_URL,
        overseerr_key=s.OVERSEERR_API_KEY,
        plex_root=s.PLEX_ROOT,
    )
    app.state.settings = s
    app.state.fuse_thread = getattr(app.state, "fuse_thread", None)  # preserve existing
    log.info(f"✅ Clients initialised — overseerr={s.OVERSEERR_URL or 'not set'}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info("🚀 Debridarr starting up...")
    # Suppress noisy third-party loggers (must be set after uvicorn configures logging)
    for noisy in ("httpx", "httpcore", "multipart", "uvicorn.access"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    # Load /data/.env into os.environ first — this is where the wizard saves config.
    # Docker env vars take precedence if already set (so compose overrides still work).
    import os
    from pathlib import Path as _Path
    _data_env = _Path("/data/.env")
    if _data_env.exists():
        log.info(f"📂 Loading saved config from {_data_env}")
        for line in _data_env.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            k = k.strip()
            v = v.strip()
            # Only set if not already provided by Docker (compose env vars win)
            if k and v and not os.environ.get(k):
                os.environ[k] = v
                log.debug(f"  Loaded {k} from /data/.env")

    db = CacheDB(settings.DB_PATH)
    db.init()
    app.state.db = db
    app.state.setup_complete = is_setup_complete()

    # Always init clients — LibraryManager works with empty Overseerr URL
    _init_clients(app)
    s = app.state.settings
    log.info(f"✅ Debridarr ready  plex_root={s.PLEX_ROOT or 'NOT SET'}")

    if not app.state.setup_complete:
        log.info("⚙️  Setup incomplete — visit /settings to configure Overseerr")

    # Load saved DFS settings from DB
    try:
        import json as _json
        saved_dfs = db.get_setting("dfs_settings")
        if saved_dfs:
            update_dfs_settings(_json.loads(saved_dfs))
            log.info("📂 Loaded DFS settings from DB")
        else:
            # Apply env-based default for cache_dir
            cache_dir = s.FUSE_SYMLINK_ROOT.replace("mnt-alldebrid", "tmp/cache") if s.FUSE_SYMLINK_ROOT else "/docker/debridarr/tmp/cache"
            update_dfs_settings({"cache_dir": cache_dir})
    except Exception as _e:
        log.debug(f"No saved DFS settings: {_e}")

    # Ensure cache dir exists
    try:
        from pathlib import Path as _P
        from app.fuse_mount import get_dfs_settings as _gdfs
        _P(_gdfs()["cache_dir"]).mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

    # Start FUSE
    if FUSE_AVAILABLE:
        _loop = asyncio.get_event_loop()
        _t = start_fuse_mount(s.FUSE_MOUNT, app.state.alldebrid, _loop)
        app.state.fuse_thread = _t
        app._fuse_started = True
        if _t:
            log.info(f"🗂️  FUSE mount started at {s.FUSE_MOUNT}")
            asyncio.create_task(_load_all_torrents(app))
            asyncio.create_task(_torrent_sync_loop(app))
    else:
        app.state.fuse_thread = None
        log.warning("⚠️  FUSE unavailable — using HTTP proxy fallback")

    async def cleanup_loop():
        while True:
            await asyncio.sleep(3600)
            if not app.state.setup_complete:
                continue
            s = app.state.settings
            expired = db.list_expired()
            for entry in expired:
                ck         = entry["cache_key"]
                title      = entry["title"]
                year       = entry.get("year")
                season     = entry.get("season")
                episode    = entry.get("episode")
                media_type = entry["media_type"]
                torrent    = entry.get("torrent_name", "")

                # Remove from FUSE
                if torrent and FUSE_AVAILABLE:
                    unregister_torrent(torrent)

                # Remove symlink + restore placeholder
                if s.PLEX_ROOT:
                    _restore_placeholder(ck, title, year, season, episode,
                                        media_type, s.PLEX_ROOT)

                log.info(f"⏰ Expired: {ck} — symlink removed, placeholder restored")

            purged = db.purge_expired()
            if purged:
                log.info(f"🗑️  Purged {purged} expired cache entries ({db._ttl_days()}d TTL)")

    asyncio.create_task(cleanup_loop())
    asyncio.create_task(_symlink_health_loop(app))
    yield
    # Shutdown
    if getattr(app.state, "fuse_thread", None):
        s = app.state.settings
        stop_fuse_mount(s.FUSE_MOUNT)


app = FastAPI(title="Debridarr", version="0.4.0", lifespan=lifespan)

# ── Setup guard — simple helper, no middleware ────────────────────────────────
def _needs_setup(request: Request) -> bool:
    """Return True if setup has not been completed."""
    return not getattr(request.app.state, "setup_complete", False)

def _setup_redirect():
    return RedirectResponse("/setup", status_code=302)


# ─────────────────────────────────────────────────────────────────────────────
# Shared styles
# ─────────────────────────────────────────────────────────────────────────────
_BASE_STYLE = """
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
       background: #0f0f13; color: #e0e0e0; min-height: 100vh; }
header { background: #1a1a24; border-bottom: 1px solid #2a2a3a;
         padding: 14px 28px; display: flex; align-items: center; gap: 16px; }
header h1 { font-size: 1.3rem; color: #fff; }
header .ver { font-size: 0.75rem; background: #f97316; color: #fff;
              border-radius: 4px; padding: 2px 8px; }
nav { display: flex; gap: 4px; margin-left: auto; }
nav a { color: #aaa; text-decoration: none; padding: 6px 14px; border-radius: 6px;
        font-size: 0.85rem; transition: background .15s; }
nav a:hover, nav a.active { background: #2a2a3a; color: #fff; }
main { padding: 28px; max-width: 1400px; margin: 0 auto; }
h2 { font-size: 1.05rem; color: #ccc; margin-bottom: 18px; }
.card-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 16px; }
.card { background: #1a1a24; border: 1px solid #2a2a3a; border-radius: 10px; overflow: hidden; position: relative; }
.card img { width: 100%; aspect-ratio: 2/3; object-fit: cover; background: #111; display: block; }
.card .info { padding: 10px 12px; }
.card .title { font-size: 0.88rem; font-weight: 600; color: #e0e0e0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.card .meta  { font-size: 0.75rem; color: #666; margin-top: 2px; }
.card .actions { padding: 0 12px 12px; display: flex; gap: 6px; }
.btn { display: inline-block; padding: 5px 12px; border-radius: 6px; font-size: 0.78rem;
       font-weight: 600; border: none; cursor: pointer; text-decoration: none; transition: opacity .15s; }
.btn-add  { background: #f97316; color: #fff; }
.btn-add:hover { opacity: .85; }
.btn-rem  { background: #3b1f00; color: #fb923c; }
.btn-sec  { background: #1e3a5f; color: #60a5fa; }
.badge-in { position: absolute; top: 8px; right: 8px; background: #14532d;
            color: #4ade80; font-size: 0.7rem; font-weight: 700; padding: 2px 7px; border-radius: 20px; }
.search-bar { display: flex; gap: 10px; margin-bottom: 20px; }
.search-bar input { flex: 1; background: #1a1a24; border: 1px solid #2a2a3a;
                    border-radius: 8px; padding: 9px 14px; color: #e0e0e0; font-size: 0.9rem; outline: none; }
.search-bar input:focus { border-color: #f97316; }
.tabs { display: flex; gap: 2px; margin-bottom: 20px; }
.tab { padding: 8px 20px; border-radius: 8px; cursor: pointer; font-size: 0.85rem;
       font-weight: 600; border: 1px solid #2a2a3a; background: #1a1a24; color: #888; }
.tab.active { background: #f97316; color: #fff; border-color: #f97316; }
.empty { text-align: center; padding: 60px; color: #444; font-size: 0.9rem; }
.toast { position: fixed; bottom: 24px; right: 24px; background: #1a1a24; border: 1px solid #2a2a3a;
         border-radius: 10px; padding: 12px 20px; font-size: 0.85rem; opacity: 0; transition: opacity .3s; z-index: 999; }
.toast.show { opacity: 1; }
table { width: 100%; border-collapse: collapse; background: #1a1a24; border-radius: 10px; overflow: hidden; }
th { text-align: left; padding: 11px 14px; font-size: 0.72rem; text-transform: uppercase;
     color: #555; border-bottom: 1px solid #2a2a3a; }
td { padding: 11px 14px; border-bottom: 1px solid #1e1e2e; font-size: 0.875rem; }
tr:last-child td { border-bottom: none; }
.pill { padding: 2px 9px; border-radius: 20px; font-size: 0.72rem; font-weight: 600; display: inline-block; }
.pill-ok   { background: #14532d; color: #4ade80; }
.pill-res  { background: #1e3a5f; color: #60a5fa; }
.pill-err  { background: #3b0000; color: #f87171; }
.pill-pend { background: #2d2d00; color: #facc15; }
.pill-nf   { background: #3b1f00; color: #fb923c; }
"""

_NAV = lambda active: f"""
<nav>
  <a href="/library"    class="{'active' if active=='library'    else ''}">📚 Add to Library</a>
  <a href="/my-library" class="{'active' if active=='my-library' else ''}">🎬 My Library</a>
  <a href="/streams"    class="{'active' if active=='streams'    else ''}">⚡ Streams</a>
  <a href="/settings"   class="{'active' if active=='settings'   else ''}">⚙️ Settings</a>
</nav>"""

_TOAST_JS = """
function toast(msg, ok=true) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.style.borderColor = ok ? '#4ade80' : '#f87171';
  t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 3500);
}"""

def _page(title: str, nav_active: str, body: str, extra_head: str = "") -> HTMLResponse:
    return HTMLResponse(f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>{title} — Debridarr</title>
  <style>{_BASE_STYLE}</style>{extra_head}
</head>
<body>
  <header>
    <h1>🎬 Debridarr</h1><span class="ver">v0.4.0</span>
    {_NAV(nav_active)}
  </header>
  <main>{body}</main>
  <div id="toast" class="toast"></div>
  <script>{_TOAST_JS}</script>
</body>
</html>""")


# ─────────────────────────────────────────────────────────────────────────────
# Setup wizard styles (standalone, no nav)
# ─────────────────────────────────────────────────────────────────────────────
_SETUP_STYLE = _BASE_STYLE + """
.wizard { max-width: 620px; margin: 60px auto; }
.wizard-card { background: #1a1a24; border: 1px solid #2a2a3a; border-radius: 14px; padding: 36px; }
.wizard h2 { font-size: 1.4rem; color: #fff; margin-bottom: 6px; }
.wizard .sub { color: #666; font-size: 0.88rem; margin-bottom: 28px; line-height: 1.5; }
.steps { display: flex; gap: 0; margin-bottom: 32px; }
.step { flex: 1; text-align: center; font-size: 0.7rem; color: #444; padding-bottom: 8px;
        border-bottom: 2px solid #2a2a3a; position: relative; }
.step.done  { color: #4ade80; border-color: #4ade80; }
.step.active{ color: #f97316; border-color: #f97316; font-weight: 700; }
.field { margin-bottom: 20px; }
.field label { display: block; font-size: 0.8rem; color: #888; margin-bottom: 6px; font-weight: 600; }
.field input { width: 100%; background: #0f0f13; border: 1px solid #2a2a3a; border-radius: 8px;
               padding: 10px 14px; color: #e0e0e0; font-size: 0.9rem; outline: none;
               font-family: monospace; }
.field input:focus { border-color: #f97316; }
.field .hint { font-size: 0.75rem; color: #555; margin-top: 5px; line-height: 1.4; }
.field .hint a { color: #f97316; }
.test-result { margin-top: 10px; padding: 8px 12px; border-radius: 6px; font-size: 0.82rem;
               display: none; }
.test-result.ok  { background: #14532d; color: #4ade80; display: block; }
.test-result.err { background: #3b0000; color: #f87171; display: block; }
.test-result.testing { background: #1e1e2e; color: #aaa; display: block; }
.row { display: flex; gap: 10px; }
.row .field { flex: 1; }
.actions { display: flex; gap: 10px; margin-top: 28px; justify-content: flex-end; }
.btn-primary { background: #f97316; color: #fff; padding: 10px 24px; border-radius: 8px;
               font-size: 0.9rem; font-weight: 600; border: none; cursor: pointer; }
.btn-primary:hover { opacity: .85; }
.btn-primary:disabled { opacity: .4; cursor: not-allowed; }
.btn-ghost { background: transparent; color: #666; padding: 10px 16px; border-radius: 8px;
             font-size: 0.9rem; border: 1px solid #2a2a3a; cursor: pointer; }
.btn-ghost:hover { color: #ccc; border-color: #444; }
.welcome-icon { font-size: 4rem; text-align: center; margin-bottom: 20px; }
.confirm-row { display: flex; justify-content: space-between; padding: 10px 0;
               border-bottom: 1px solid #1e1e2e; font-size: 0.875rem; }
.confirm-row:last-child { border-bottom: none; }
.confirm-row .lbl { color: #666; }
.confirm-row .val { color: #e0e0e0; font-family: monospace; font-size: 0.82rem; }
"""

def _setup_page(body: str, step: str) -> HTMLResponse:
    step_names = ["Welcome", "AllDebrid", "Overseerr", "Plex Path", "Confirm"]
    step_keys  = ["welcome", "alldebrid", "overseerr", "plex", "confirm"]
    idx = step_keys.index(step) if step in step_keys else 0
    steps_html = "".join(
        f'<div class="step {"done" if i < idx else "active" if i == idx else ""}">{n}</div>'
        for i, n in enumerate(step_names)
    )
    return HTMLResponse(f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Debridarr Setup</title>
  <style>{_SETUP_STYLE}</style>
</head>
<body>
  <header>
    <h1>🎬 Debridarr</h1><span class="ver">v0.4.0</span>
    <span style="margin-left:auto;color:#555;font-size:0.8rem">First-run setup</span>
  </header>
  <div class="wizard">
    <div class="steps">{steps_html}</div>
    <div class="wizard-card">{body}</div>
  </div>
  <div id="toast" class="toast"></div>
  <script>{_TOAST_JS}</script>
</body>
</html>""")


# ─────────────────────────────────────────────────────────────────────────────
# Setup wizard pages
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/setup", response_class=HTMLResponse)
async def setup_get(request: Request, step: str = "welcome"):
    try:
        cfg = load_saved_config()
    except Exception:
        cfg = {}

    if step == "welcome":
        body = """
        <div class="welcome-icon">🎬</div>
        <h2>Welcome to Debridarr</h2>
        <p class="sub">This wizard will connect Debridarr to AllDebrid and Overseerr.
        It takes about 2 minutes. All settings are tested live before saving.</p>
        <div class="actions">
          <a href="/setup?step=alldebrid" class="btn-primary" style="text-decoration:none;display:inline-block;padding:10px 24px">Get Started →</a>
        </div>"""
        return _setup_page(body, "welcome")

    if step == "alldebrid":
        val = cfg.get("ALLDEBRID_API_KEY", "")
        body = f"""
        <h2>AllDebrid</h2>
        <p class="sub">Debridarr uses AllDebrid to find and stream cached torrents instantly.</p>
        <div class="field">
          <label>API Key</label>
          <input id="api_key" type="password" value="{val}" placeholder="Paste your AllDebrid API key">
          <div class="hint">Get yours at <a href="https://alldebrid.com/apikeys" target="_blank">alldebrid.com/apikeys</a> → Create a key → Copy it here.</div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="actions">
          <a href="/setup?step=welcome" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="test-btn" onclick="testAndNext()">Test & Continue →</button>
        </div>
        <script>
        async function testAndNext() {{
          const key = document.getElementById('api_key').value.trim();
          const res = document.getElementById('test-result');
          const btn = document.getElementById('test-btn');
          if (!key) {{ res.className='test-result err'; res.textContent='API key required'; return; }}
          res.className='test-result testing'; res.textContent='Testing connection...';
          btn.disabled = true;
          const r = await fetch('/setup/test', {{
            method:'POST', headers:{{'Content-Type':'application/json'}},
            body: JSON.stringify({{step:'alldebrid', api_key: key}})
          }});
          const d = await r.json();
          btn.disabled = false;
          if (d.ok) {{
            res.className='test-result ok'; res.textContent='✅ ' + d.message;
            setTimeout(() => window.location='/setup?step=overseerr&alldebrid_key=' + encodeURIComponent(key), 800);
          }} else {{
            res.className='test-result err'; res.textContent='❌ ' + d.message;
          }}
        }}
        document.getElementById('api_key').addEventListener('keydown', e => {{ if(e.key==='Enter') testAndNext(); }});
        </script>"""
        return _setup_page(body, "alldebrid")

    if step == "overseerr":
        url_val = cfg.get("OVERSEERR_URL", "http://192.168.1.x:5055")
        key_val = cfg.get("OVERSEERR_API_KEY", "")
        alldebrid_key = request.query_params.get("alldebrid_key", cfg.get("ALLDEBRID_API_KEY",""))
        body = f"""
        <h2>Overseerr</h2>
        <p class="sub">Connect to your Overseerr instance so Debridarr can browse your request library.</p>
        <div class="row">
          <div class="field">
            <label>Overseerr URL</label>
            <input id="overseerr_url" type="text" value="{url_val}" placeholder="http://192.168.1.x:5055">
            <div class="hint">Use the LAN IP of the machine running Overseerr.</div>
          </div>
        </div>
        <div class="field">
          <label>API Key</label>
          <input id="overseerr_key" type="password" value="{key_val}" placeholder="Overseerr API key">
          <div class="hint">Overseerr → Settings → General → API Key</div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="actions">
          <a href="/setup?step=alldebrid" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="test-btn" onclick="testAndNext()">Test & Continue →</button>
        </div>
        <input type="hidden" id="alldebrid_key" value="{alldebrid_key}">
        <script>
        async function testAndNext() {{
          const url = document.getElementById('overseerr_url').value.trim();
          const key = document.getElementById('overseerr_key').value.trim();
          const akey = document.getElementById('alldebrid_key').value;
          const res = document.getElementById('test-result');
          const btn = document.getElementById('test-btn');
          res.className='test-result testing'; res.textContent='Testing connection...';
          btn.disabled = true;
          const r = await fetch('/setup/test', {{
            method:'POST', headers:{{'Content-Type':'application/json'}},
            body: JSON.stringify({{step:'overseerr', url, api_key: key}})
          }});
          const d = await r.json();
          btn.disabled = false;
          if (d.ok) {{
            res.className='test-result ok'; res.textContent='✅ ' + d.message;
            setTimeout(() => window.location='/setup?step=plex&alldebrid_key='+encodeURIComponent(akey)+'&overseerr_url='+encodeURIComponent(url)+'&overseerr_key='+encodeURIComponent(key), 800);
          }} else {{
            res.className='test-result err'; res.textContent='❌ ' + d.message;
          }}
        }}
        </script>"""
        return _setup_page(body, "overseerr")



    if step == "plex":
        qs = dict(request.query_params)
        hidden = "".join(f'<input type="hidden" id="{k}" value="{v}">' for k, v in qs.items() if k != "step")
        tz_val = cfg.get("TZ", "America/Edmonton")
        puid_val = cfg.get("PUID", "1000")
        pgid_val = cfg.get("PGID", "1000")
        base_url_val = cfg.get("DEBRIDARR_BASE_URL", "http://192.168.1.x:7474")
        body = f"""
        <h2>Plex Integration</h2>
        <p class="sub">Tell Debridarr where to write fake library files, and how Plex reaches it over the network.</p>
        <div class="field">
          <label>Plex Library Path <span style="color:#555">(inside this container)</span></label>
          <input id="plex_root" type="text" value="/plex-strm" placeholder="/plex-strm">
          <div class="hint">This must be bind-mounted into both Debridarr and Plex. The default <code>/plex-strm</code> matches the docker-compose volume.</div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="field">
          <label>Debridarr Base URL <span style="color:#555">(as seen by Plex)</span></label>
          <input id="base_url" type="text" value="{base_url_val}" placeholder="http://192.168.1.x:7474">
          <div class="hint">Written into every .strm file. Plex must be able to reach this address. Use your server's LAN IP.</div>
        </div>
        <div class="row">
          <div class="field">
            <label>Timezone</label>
            <input id="tz" type="text" value="{tz_val}" placeholder="America/Edmonton">
            <div class="hint"><a href="https://en.wikipedia.org/wiki/List_of_tz_database_time_zones" target="_blank">TZ list</a></div>
          </div>
          <div class="field">
            <label>PUID</label>
            <input id="puid" type="text" value="{puid_val}" placeholder="1000">
            <div class="hint">Run: <code>id -u</code></div>
          </div>
          <div class="field">
            <label>PGID</label>
            <input id="pgid" type="text" value="{pgid_val}" placeholder="1000">
            <div class="hint">Run: <code>id -g</code></div>
          </div>
        </div>
        {hidden}
        <div class="actions">
          <a href="/setup?step=overseerr" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="test-btn" onclick="testAndNext()">Test & Continue →</button>
        </div>
        <script>
        async function testAndNext() {{
          const plex_root = document.getElementById('plex_root').value.trim();
          const res = document.getElementById('test-result');
          const btn = document.getElementById('test-btn');
          res.className='test-result testing'; res.textContent='Checking path is writable...';
          btn.disabled = true;
          const r = await fetch('/setup/test', {{
            method:'POST', headers:{{'Content-Type':'application/json'}},
            body: JSON.stringify({{step:'plex', plex_root}})
          }});
          const d = await r.json();
          btn.disabled = false;
          if (d.ok) {{
            res.className='test-result ok'; res.textContent='✅ ' + d.message;
            const prev = {{}};
            document.querySelectorAll('input[type=hidden]').forEach(i => prev[i.id]=i.value);
            const params = new URLSearchParams({{
              ...prev, step:'confirm',
              plex_root, base_url: document.getElementById('base_url').value.trim(),
              tz: document.getElementById('tz').value.trim(),
              puid: document.getElementById('puid').value.trim(),
              pgid: document.getElementById('pgid').value.trim(),
            }});
            setTimeout(() => window.location='/setup?' + params.toString(), 800);
          }} else {{
            res.className='test-result err'; res.textContent='❌ ' + d.message;
          }}
        }}
        </script>"""
        return _setup_page(body, "plex")

    if step == "confirm":
        qs = dict(request.query_params)
        def row(label, key, mask=False):
            val = qs.get(key, "—")
            display = ("*" * 8 + val[-4:]) if mask and val and val != "—" else val
            return f'<div class="confirm-row"><span class="lbl">{label}</span><span class="val">{display}</span></div>'

        hidden = "".join(f'<input type="hidden" name="{k}" value="{v}">' for k, v in qs.items() if k != "step")
        body = f"""
        <h2>Confirm & Save</h2>
        <p class="sub">Everything looks good. Review your settings and click Save to finish setup.</p>
        <div style="margin-bottom:24px">
          {row("AllDebrid API Key", "alldebrid_key", mask=True)}
          {row("Overseerr URL", "overseerr_url")}
          {row("Overseerr API Key", "overseerr_key", mask=True)}
          {row("Plex Library Path", "plex_root")}
          {row("Debridarr Base URL", "base_url")}
          {row("Timezone", "tz")}
          {row("PUID / PGID", "puid")} 
        </div>
        <form method="POST" action="/setup/save">
          {hidden}
          <div class="actions">
            <a href="/setup?step=plex" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
            <button type="submit" class="btn-primary">💾 Save & Finish</button>
          </div>
        </form>"""
        return _setup_page(body, "confirm")

    return RedirectResponse("/setup")


# ── Setup: live test endpoint ─────────────────────────────────────────────────
@app.post("/setup/test")
async def setup_test(request: Request):
    body = await request.json()
    step = body.get("step")

    if step == "alldebrid":
        ok, msg = await test_alldebrid(body.get("api_key", ""))
    elif step == "overseerr":
        ok, msg = await test_overseerr(body.get("url", ""), body.get("api_key", ""))
    elif step == "plex":
        ok, msg = await test_plex_root(body.get("plex_root", ""))
    else:
        ok, msg = False, "Unknown step"

    return JSONResponse({"ok": ok, "message": msg})


# ── Setup: save config and finish ─────────────────────────────────────────────
@app.post("/setup/save")
async def setup_save(request: Request):
    form = dict(await request.form())

    config = {
        "ALLDEBRID_API_KEY": form.get("alldebrid_key", ""),
        "OVERSEERR_URL":     form.get("overseerr_url", ""),
        "OVERSEERR_API_KEY": form.get("overseerr_key", ""),
        "DEBRIDARR_BASE_URL":form.get("base_url", "http://debridarr:7474"),
        "TZ":                form.get("tz", "America/Edmonton"),
        "PUID":              form.get("puid", "1000"),
        "PGID":              form.get("pgid", "1000"),
    }

    # Write /data/.env
    write_env(config)

    # Push into os.environ FIRST — _init_clients reads directly from os.environ
    import os
    for k, v in config.items():
        os.environ[k] = v
    os.environ["PLEX_ROOT"] = form.get("plex_root", "/plex-strm")

    # Mark complete BEFORE _init_clients so guards pass immediately
    mark_setup_complete()
    request.app.state.setup_complete = True

    # Now reinitialise clients with fresh env
    _init_clients(request.app)

    log.info("✅ Setup complete — config saved, restarting container...")
    _schedule_restart(delay=2.0)

    return HTMLResponse(f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta http-equiv="refresh" content="6;url=/library">
  <title>Setup Complete</title>
  <style>{_SETUP_STYLE}</style>
</head>
<body>
  <header><h1>🎬 Debridarr</h1><span class="ver">v0.4.0</span></header>
  <div class="wizard">
    <div class="wizard-card" style="text-align:center;padding:48px">
      <div style="font-size:3rem;margin-bottom:16px">🎉</div>
      <h2 style="color:#4ade80;margin-bottom:12px">Setup Complete!</h2>
      <p style="color:#888;margin-bottom:24px">Your config has been saved. Redirecting to the library browser...</p>
      <a href="/library" style="color:#f97316">Click here if not redirected</a>
    </div>
  </div>
</body>
</html>""")


# ─────────────────────────────────────────────────────────────────────────────
# / redirect
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    if _needs_setup(request):
        return _setup_redirect()
    return RedirectResponse("/library")


# ─────────────────────────────────────────────────────────────────────────────
# /library — browse Overseerr requests, add to fake library
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/library", response_class=HTMLResponse)
async def library_browse(request: Request, tab: str = "movies", q: str = ""):
    if _needs_setup(request):
        return _setup_redirect()
    lm: LibraryManager = request.app.state.library
    db: CacheDB = request.app.state.db

    if lm is None:
        return HTMLResponse("<h2>Setup required — please complete the <a href='/setup'>setup wizard</a> first.</h2>", status_code=503)

    already_added = {
        (r["media_type"], r["title"], r["year"])
        for r in db.fake_library_list()
    }

    if tab == "movies":
        items = await lm.get_radarr_movies()
    else:
        items = await lm.get_sonarr_series()

    if q:
        ql = q.lower()
        items = [i for i in items if ql in i["title"].lower()]

    cards = ""
    for item in items:
        media_type = "movie" if tab == "movies" else "series"
        year = item.get("year")
        in_lib = (media_type, item["title"], year) in already_added
        poster = item.get("poster", "")
        img = f'<img src="{poster}" onerror="this.style.display=\'none\'" loading="lazy">' if poster else '<div style="aspect-ratio:2/3;background:#111"></div>'
        badge = '<span class="badge-in">✓ Added</span>' if in_lib else ""
        sc = item.get('season_count', 0)
        season_info = f"{sc} season{'s' if sc != 1 else ''}" if tab == "tv" and sc else ("? seasons" if tab == "tv" else "")
        meta = f"{year or ''}" + (f" · {season_info}" if season_info else "")
        safe_title = item['title'].replace("'", "\\'").replace('"', '&quot;')

        if in_lib:
            action = f"""<button class="btn btn-rem" onclick="removeItem('{media_type}','{safe_title}',{year or 'null'})">Remove</button>"""
        else:
            sc = item.get('season_count', 0)
            action = f"""<button class="btn btn-add" onclick="addItem('{media_type}',{item.get('id','null')},'{safe_title}',{year or 'null'},{sc})">+ Add</button>"""

        cards += f"""
        <div class="card">
          {badge}{img}
          <div class="info">
            <div class="title" title="{item['title']}">{item['title']}</div>
            <div class="meta">{meta}</div>
          </div>
          <div class="actions">{action}</div>
        </div>"""

    if not cards:
        cards = f'<div class="empty">{"No results for &quot;"+q+"&quot;" if q else "Nothing found in Overseerr — check your API key in Settings"}</div>'

    movie_count = len(await lm.get_radarr_movies()) if lm else 0
    tv_count = len(await lm.get_sonarr_series()) if lm else 0
    tab_movies = "active" if tab == "movies" else ""
    tab_tv = "active" if tab == "tv" else ""

    body = f"""
    <h2>Browse Library</h2>
    <div class="tabs">
      <div class="tab {tab_movies}" onclick="location.href='/library?tab=movies&q={q}'">🎬 Movies ({movie_count})</div>
      <div class="tab {tab_tv}"     onclick="location.href='/library?tab=tv&q={q}'">📺 TV Shows ({tv_count})</div>
    </div>
    <div class="search-bar">
      <input id="q" type="text" placeholder="Search..." value="{q}"
             onkeydown="if(event.key==='Enter')location.href='/library?tab={tab}&q='+encodeURIComponent(this.value)">
      <button class="btn btn-add" onclick="location.href='/library?tab={tab}&q='+encodeURIComponent(document.getElementById('q').value)">Search</button>
      {'<button class="btn btn-sec" onclick="location.href=\'/library?tab='+tab+'\'">Clear</button>' if q else ''}
      <button class="btn btn-sec" id="refresh-btn" onclick="refreshLibrary()">🔄 Refresh</button>
    </div>
    <div class="card-grid">{cards}</div>"""

    extra = f"""<script>
async function addItem(type, id, title, year, season_count) {{
  const r = await fetch('/api/library/add', {{method:'POST',headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{media_type:type,arr_id:id,title,year,season_count}})}});
  const d = await r.json();
  if (r.ok) {{ toast('✅ ' + title + ' added'); setTimeout(()=>location.reload(),1200); }}
  else {{ toast('❌ ' + (d.detail||'Error'), false); }}
}}
async function removeItem(type, title, year) {{
  const r = await fetch('/api/library/remove',{{method:'POST',headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{media_type:type,title,year}})}});
  if (r.ok) {{ toast('🗑️ Removed'); setTimeout(()=>location.reload(),1200); }}
  else {{ toast('❌ Error', false); }}
}}
async function refreshLibrary() {{
  const btn = document.getElementById('refresh-btn');
  btn.textContent = '⏳ Refreshing...';
  btn.disabled = true;
  try {{
    const r = await fetch('/api/library/refresh', {{method:'POST'}});
    const d = await r.json();
    toast('✅ Refreshed — ' + (d.synced||0) + ' series updated');
    setTimeout(() => location.reload(), 1200);
  }} catch(e) {{
    btn.textContent = '🔄 Refresh';
    btn.disabled = false;
    toast('❌ Refresh failed', false);
  }}
}}
</script>"""
    return _page("Browse Library", "library", body, extra)


# ─────────────────────────────────────────────────────────────────────────────
# /my-library
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/library/cache-info")
async def api_library_cache_info(request: Request, title: str, media_type: str):
    """Return all cached stream entries for a title."""
    db: CacheDB = request.app.state.db
    all_entries = db.list_all()
    # fake_library uses "series" but cache uses "episode" for TV
    db_types = ["episode"] if media_type == "series" else [media_type]
    entries = [
        e for e in all_entries
        if e["title"].lower() == title.lower()
        and e["media_type"] in db_types
        and e["status"] == "cached"
    ]
    entries.sort(key=lambda e: (e.get("season") or 0, e.get("episode") or 0))
    return {
        "title": title,
        "media_type": media_type,
        "cached_count": len(entries),
        "entries": [
            {
                "cache_key":    e["cache_key"],
                "season":       e.get("season"),
                "episode":      e.get("episode"),
                "quality":      e.get("quality", "—") or "—",
                "torrent_name": e.get("torrent_name", "") or "",
                "expires_at":   e.get("expires_at", ""),
                "status":       e["status"],
            }
            for e in entries
        ]
    }


@app.get("/my-library", response_class=HTMLResponse)
async def my_library(request: Request):
    if _needs_setup(request):
        return _setup_redirect()
    db: CacheDB = request.app.state.db
    items = db.fake_library_list()
    if not items:
        body = "<div class='empty'>Your library is empty. <a href='/library' style='color:#f97316'>Browse Library</a> to add titles.</div>"
        return _page("My Library", "my-library", body, "")

    movies = [i for i in items if i["media_type"] == "movie"]
    shows  = [i for i in items if i["media_type"] == "series"]

    # Build cached-count map — DB stores "episode" for TV, "movie" for movies
    all_cached = [e for e in db.list_all() if e["status"] == "cached"]
    cached_counts: dict[str, int] = {}
    for e in all_cached:
        # Normalize to match the fake_library media_type
        mt = "movie" if e["media_type"] == "movie" else "series"
        k = f"{mt}::{e['title'].lower()}"
        cached_counts[k] = cached_counts.get(k, 0) + 1

    # Pull posters from TMDB — by ID first, title search as fallback
    tmdb_key = db.get_setting("tmdb_api_key", "")

    async def _fetch_tmdb_poster(tmdb_id, title: str, is_movie: bool) -> str:
        if not tmdb_key:
            return ""
        import httpx as _hx
        endpoint = "movie" if is_movie else "tv"
        async with _hx.AsyncClient(timeout=8) as c:
            try:
                # Method 1: direct ID lookup
                if tmdb_id:
                    r = await c.get(
                        f"https://api.themoviedb.org/3/{endpoint}/{tmdb_id}",
                        params={"api_key": tmdb_key},
                    )
                    if r.status_code == 200:
                        p = r.json().get("poster_path")
                        if p:
                            return f"https://image.tmdb.org/t/p/w342{p}"
                # Method 2: search by title (for items without tmdb_id stored)
                r2 = await c.get(
                    f"https://api.themoviedb.org/3/search/{endpoint}",
                    params={"api_key": tmdb_key, "query": title},
                )
                if r2.status_code == 200:
                    results = r2.json().get("results", [])
                    if results and results[0].get("poster_path"):
                        return f"https://image.tmdb.org/t/p/w342{results[0]['poster_path']}"
            except Exception:
                pass
        return ""

    for item in movies + shows:
        stored   = item.get("poster_url") or ""
        # Only fetch if poster not already stored (avoids unnecessary API calls)
        if not stored and tmdb_key:
            is_movie = item["media_type"] == "movie"
            poster   = await _fetch_tmdb_poster(item.get("tmdb_id"), item["title"], is_movie)
            if poster:
                item["poster_url"] = poster
                # Save back to DB so next page load is instant
                db.fake_library_add({**item, "fake_path": item.get("fake_path")})
        # item["poster_url"] is either stored or just-fetched — card uses it directly

    def card(item, mtype):
        title      = item["title"]
        year       = item.get("year") or ""
        safe_title = title.replace("'","&#39;").replace('"','&quot;')
        poster     = item.get("poster_url") or ""
        overview   = (item.get("overview") or "")[:120]
        sc         = item.get("season_count") or 0
        status     = item.get("status", "")
        added      = ""
        if item.get("added_at"):
            try: added = datetime.fromisoformat(item["added_at"]).strftime("%b %d, %Y")
            except: pass

        k = f"{mtype}::{title.lower()}"
        n = cached_counts.get(k, 0)

        # Badge
        if n:
            if mtype == "movie":
                badge = '<span class="badge-green">✅ Cached</span>'
            else:
                badge = f'<span class="badge-green">✅ {n} ep{"s" if n!=1 else ""}</span>'
        else:
            badge = '<span class="badge-grey">⏳ Not cached</span>'

        # Status pill for series
        status_pill = ""
        if mtype == "series" and status:
            col = "#ef4444" if status == "ended" else "#22c55e"
            lbl = "Ended" if status == "ended" else "Continuing"
            status_pill = f'<span style="font-size:0.65rem;background:{col}22;color:{col};border-radius:4px;padding:1px 6px;border:1px solid {col}44">{lbl}</span>'

        sub = f"{sc} season{'s' if sc!=1 else ''}" if mtype=="series" else str(year)

        # Cover art or placeholder
        if poster:
            img_html = f'<img src="{poster}" alt="{safe_title}" style="width:100%;aspect-ratio:2/3;object-fit:cover;display:block;background:#111">'
        else:
            initials = "".join(w[0].upper() for w in title.split()[:2])
            img_html = f'<div style="width:100%;aspect-ratio:2/3;background:#1a1a2e;display:flex;align-items:center;justify-content:center;font-size:2rem;color:#444">{initials}</div>'

        yr       = item.get("year") or "null"
        hover_in  = "onmouseenter=\"this.style.borderColor='#f97316'\"" if n else ""
        hover_out = "onmouseleave=\"this.style.borderColor='#2a2a3a'\"" if n else ""
        border    = "border-color:#f97316" if n else ""
        onclick   = f"onclick=\"showCache('{ safe_title }','{ mtype }')\"" if n else ""
        cursor    = 'style="cursor:pointer"' if n else ""

        parts = [
            f'<div class="card" {cursor} {onclick} {hover_in} {hover_out} style="overflow:hidden;{border}">',
            img_html,
            '<div style="padding:10px">',
            f'<div style="font-weight:700;font-size:0.88rem;color:#e8e8e8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="{safe_title}">{title}</div>',
            f'<div style="font-size:0.75rem;color:#666;margin:2px 0 6px">{sub} {status_pill}</div>',
        ]
        if overview:
            ov_suffix = "…" if len(overview) == 120 else ""
            parts.append(f'<div style="font-size:0.7rem;color:#555;line-height:1.3;margin-bottom:6px">{overview}{ov_suffix}</div>')
        parts += [
            '<div style="display:flex;align-items:center;justify-content:space-between;gap:4px">',
            badge,
            f'<button class="btn btn-rem" style="padding:3px 8px;font-size:0.72rem" onclick="event.stopPropagation();rem(\'{mtype}\',\'{safe_title}\',{yr})">Remove</button>',
            '</div></div></div>',
        ]
        return "".join(parts)

    def section(label, rows, mtype):
        if not rows:
            return f'<h2 style="margin:24px 0 12px">{label}</h2><div class="empty" style="padding:16px">Nothing added yet</div>'
        cards = "".join(card(r, mtype) for r in rows)
        return f'<h2 style="margin:24px 0 12px">{label} <span style="font-size:0.8rem;color:#888;font-weight:normal">({len(rows)})</span></h2><div class="card-grid" style="grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:14px">{cards}</div>'

    body = section("🎬 Movies", movies, "movie") + section("📺 TV Shows", shows, "series")

    extra = """<style>
.badge-green{display:inline-flex;align-items:center;background:#14532d;color:#4ade80;border-radius:20px;padding:2px 8px;font-size:0.7rem;font-weight:600}
.badge-grey{display:inline-flex;align-items:center;background:#1a1a24;color:#555;border-radius:20px;padding:2px 8px;font-size:0.7rem;border:1px solid #2a2a3a}
</style>
<script>
async function rem(type, title, year) {
  const t = title.replace(/&#39;/g,"'").replace(/&quot;/g,'"');
  if (!confirm('Remove "'+t+'" from your library?')) return;
  const r = await fetch('/api/library/remove',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({media_type:type,title:t,year})});
  if (r.ok){toast('🗑️ Removed');setTimeout(()=>location.reload(),1200);}
  else{toast('❌ Error',false);}
}

async function showCache(rawTitle, mediaType) {
  const title = rawTitle.replace(/&#39;/g,"'").replace(/&quot;/g,'"');
  const r = await fetch('/api/library/cache-info?title='+encodeURIComponent(title)+'&media_type='+mediaType);
  const d = await r.json();
  if (!d.entries.length) { toast('No cached streams yet'); return; }
  const modal = document.getElementById('cache-modal');
  const content = document.getElementById('cache-content');
  let html = '<h3 style="margin:0 0 16px;color:#e8e8e8">'+title+'</h3>';
  if (d.entries[0]?.season != null) {
    const bySeason = {};
    for (const e of d.entries) { const s=e.season||0; if(!bySeason[s])bySeason[s]=[]; bySeason[s].push(e); }
    for (const [s,eps] of Object.entries(bySeason).sort((a,b)=>+a[0]-+b[0])) {
      html += '<div style="margin-bottom:14px"><div style="color:#f97316;font-weight:700;margin-bottom:6px">Season '+s+'</div>';
      html += '<div style="display:flex;flex-wrap:wrap;gap:6px">';
      for (const e of eps) {
        const ep='E'+String(e.episode).padStart(2,'0');
        const exp=e.expires_at?new Date(e.expires_at).toLocaleDateString():'—';
        html+='<div title="'+e.torrent_name+'" style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:6px;padding:5px 9px;font-size:0.78rem">';
        html+='<span style="color:#f97316;font-weight:700">'+ep+'</span> <span style="color:#888">'+e.quality+'</span>';
        html+='<div style="color:#555;font-size:0.68rem;margin-top:2px">exp '+exp+'</div></div>';
      }
      html+='</div></div>';
    }
  } else {
    const e=d.entries[0];
    const exp=e.expires_at?new Date(e.expires_at).toLocaleDateString():'—';
    html+='<table style="width:100%;border-collapse:collapse;font-size:0.85rem">';
    html+='<tr><td style="color:#666;padding:4px 0;width:100px">Quality</td><td style="color:#e8e8e8">'+e.quality+'</td></tr>';
    html+='<tr><td style="color:#666;padding:4px 0">Torrent</td><td style="color:#aaa;font-size:0.78rem;word-break:break-all">'+e.torrent_name+'</td></tr>';
    html+='<tr><td style="color:#666;padding:4px 0">Expires</td><td style="color:#e8e8e8">'+exp+'</td></tr>';
    html+='</table>';
  }
  content.innerHTML = html;
  modal.style.display = 'flex';
}
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal()});
function closeModal(){document.getElementById('cache-modal').style.display='none';}
</script>
<div id="cache-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.75);z-index:1000;align-items:center;justify-content:center" onclick="if(event.target===this)closeModal()">
  <div style="background:#12121a;border:1px solid #2a2a3a;border-radius:14px;padding:28px;max-width:600px;width:90%;max-height:80vh;overflow-y:auto;position:relative">
    <button onclick="closeModal()" style="position:absolute;top:14px;right:18px;background:none;border:none;color:#555;font-size:1.5rem;cursor:pointer;line-height:1">✕</button>
    <div id="cache-content"></div>
  </div>
</div>"""
    return _page("My Library", "my-library", body, extra)


@app.post("/api/library/remove")
async def api_library_remove(request: Request):
    body = await request.json()
    media_type, title, year = body.get("media_type"), body.get("title","").strip(), body.get("year")
    lm = request.app.state.library
    db = request.app.state.db
    if media_type == "movie": lm.remove_fake_movie(title, year)
    else: lm.remove_fake_series(title)
    db.fake_library_remove(media_type, title, year)
    return {"status": "removed"}


async def _add_to_library(lm, db, media_type, arr_id, title, year, season_count=0):
    try:
        if media_type == "movie":
            path = lm.create_fake_movie(title, year)
            db.fake_library_add({"media_type":"movie","title":title,"year":year,
                                  "radarr_id":arr_id,
                                  "tmdb_id":   movie.get("tmdb_id"),
                                  "imdb_id":   movie.get("imdb_id"),
                                  "poster_url":movie.get("poster",""),
                                  "overview":  movie.get("overview",""),
                                  "status":    "movie",
                                  "fake_path": str(path) if path else None})
        else:
            # Fetch fresh series data to get seasons + episodes
            series_list = await lm.get_sonarr_series()
            series = next((s for s in series_list if s["id"] == arr_id), None)
            # Use passed season_count as fallback if series not found in cache
            sc = series.get("season_count", season_count) if series else season_count
            seasons = series.get("seasons", []) if series else []
            tvdb_id = series.get("tvdb_id") if series else None
            # Pass requested seasons so we only create placeholders for what was requested
            requested_seasons = series.get("requested_seasons", []) if series else []
            include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"
            episodes = await lm.get_sonarr_episodes(
                arr_id, include_unreleased=include_unreleased,
                requested_seasons=requested_seasons if requested_seasons else None
            )
            paths = lm.create_fake_episodes(title, year, seasons, episodes)
            db.fake_library_add({"media_type":"series","title":title,"year":year,
                                  "sonarr_id":  arr_id,
                                  "tvdb_id":    tvdb_id,
                                  "tmdb_id":    series.get("tmdb_id") if series else None,
                                  "imdb_id":    series.get("imdb_id") if series else None,
                                  "season_count": sc,
                                  "poster_url": series.get("poster","") if series else "",
                                  "overview":   series.get("overview","") if series else "",
                                  "status":     "ended" if (series and series.get("is_ended")) else "continuing",
                                  "fake_path":  str(Path(lm.plex_root)/"tv"/title) if lm.plex_root else None})
            log.info(f"📺 {title}: {len(paths)} fake episodes, {sc} seasons")
    except Exception as e:
        log.error(f"Failed adding '{title}': {e}", exc_info=True)


@app.post("/webhook/tautulli")
async def tautulli_webhook(request: Request, background_tasks: BackgroundTasks):
    try:
        payload = await request.json()
    except Exception:
        payload = dict(await request.form())

    # Log the full raw payload so we can see exactly what Tautulli sends
    log.info(f"📺 Tautulli webhook received: {payload}")

    media_type = payload.get("media_type", "")
    title = payload.get("grandparent_title") or payload.get("title", "")
    year = payload.get("year") or payload.get("grandparent_year")
    season = payload.get("parent_media_index")
    episode = payload.get("media_index")

    if media_type not in ("movie", "episode"):
        log.warning(
            f"📺 Tautulli webhook ignored — media_type={repr(media_type)} "
            f"title={repr(title)} (expected 'movie' or 'episode')"
        )
        return {"status": "ignored", "reason": f"media_type={repr(media_type)} not supported"}

    if not title:
        log.warning(f"📺 Tautulli webhook ignored — no title in payload")
        return {"status": "ignored", "reason": "no title"}

    event = PlayEvent(
        media_type=MediaType(media_type),
        title=title,
        year=int(year) if year else None,
        season=int(season) if season else None,
        episode=int(episode) if episode else None,
        rating_key=payload.get("rating_key"),
        tmdb_id=payload.get("themoviedb_id") or payload.get("tmdb_id"),
        tvdb_id=payload.get("thetvdb_id") or payload.get("tvdb_id"),
        imdb_id=payload.get("imdb_id"),
    )
    log.info(f"📺 Resolving: {event.cache_key()} — {title} S{season}E{episode}")
    background_tasks.add_task(resolve_and_cache, request.app, event)
    return {"status": "accepted", "cache_key": event.cache_key()}



@app.get("/webhook/test")
async def webhook_test():
    """Quick endpoint to verify webhook connectivity."""
    return {"status": "ok", "message": "Debridarr webhook endpoint is reachable"}


@app.get("/proxy/{cache_key}")
async def stream_proxy(cache_key: str, request: Request):
    return await proxy_stream(request, cache_key, request.app.state.db, request.app.state.alldebrid)


@app.post("/resolve")
async def manual_resolve(request: Request, background_tasks: BackgroundTasks):
    body = await request.json()
    event = PlayEvent(media_type=MediaType(body["media_type"]), title=body["title"],
                      year=body.get("year"), season=body.get("season"), episode=body.get("episode"))
    background_tasks.add_task(resolve_and_cache, request.app, event)
    s = request.app.state.settings
    return {"status":"resolving","cache_key":event.cache_key(),
            "proxy_url":f"{s.DEBRIDARR_BASE_URL}/proxy/{event.cache_key()}"}


@app.get("/cache")
async def list_cache(request: Request): return request.app.state.db.list_all()


@app.delete("/cache/{cache_key}")
async def delete_cache_entry(cache_key: str, request: Request):
    db = request.app.state.db
    entry = db.get(cache_key)
    s = request.app.state.settings
    if entry and s.PLEX_ROOT:
        delete_strm(cache_key=cache_key, title=entry["title"], year=entry.get("year"),
                    season=entry.get("season"), episode=entry.get("episode"),
                    media_type=entry["media_type"], plex_root=s.PLEX_ROOT)
    db.delete(cache_key)
    return {"status":"deleted"}



# ─────────────────────────────────────────────────────────────────────────────
# /settings — view and update config, test connections
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/streams", response_class=HTMLResponse)
async def streams_page(request: Request):
    if _needs_setup(request):
        return _setup_redirect()
    db: CacheDB = request.app.state.db
    entries = db.list_all()

    def pill(s):
        cls = {"cached":"pill-ok","resolving":"pill-res","error":"pill-err","not_found":"pill-nf"}.get(s,"pill-pend")
        return f'<span class="pill {cls}">{s}</span>'

    def ep_str(e):
        s  = f"S{str(e['season']).zfill(2)}"  if e.get("season")  else ""
        ep = f"E{str(e['episode']).zfill(2)}" if e.get("episode") else ""
        return s + ep

    rows = ""
    for e in entries:
        t = e.get("torrent_name","") or ""
        t_short = (t[:55] + "…") if len(t) > 55 else t
        t_html = f'<br><small style="color:#888;font-size:0.72rem">{t_short}</small>' if t and t != "None" else ""
        exp = datetime.fromisoformat(e["expires_at"]).strftime("%Y-%m-%d") if e.get("expires_at") else "—"
        rows += f"""<tr>
      <td><span style="font-size:0.8rem;color:#888">{e['media_type']}</span></td>
      <td><strong>{e['title']}</strong>{t_html}</td>
      <td style="font-family:monospace;white-space:nowrap">{ep_str(e)}</td>
      <td>{e.get('quality','—') or '—'}</td>
      <td style="white-space:nowrap">{exp}</td>
      <td>{pill(e['status'])}</td>
      <td><button class="btn btn-rem" onclick="del_('{e['cache_key']}')">Del</button></td>
    </tr>"""

    count = len(entries)
    del_all = '<button class="btn btn-rem" onclick="delAll()" style="padding:8px 16px">🗑️ Delete All</button>' if entries else ""
    header = f'<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px"><h2 style="margin:0">Resolved Streams <span style="font-size:0.85rem;color:#888;font-weight:normal">({count})</span></h2>{del_all}</div>'

    if entries:
        body = header + f'<table><thead><tr><th>Type</th><th>Title</th><th>Ep</th><th>Quality</th><th>Expires</th><th>Status</th><th></th></tr></thead><tbody>{rows}</tbody></table>'
    else:
        body = header + '<div class="empty">No resolved streams yet.</div>'

    extra = """<script>
async function del_(k){await fetch('/cache/'+k,{method:'DELETE'});toast('🗑️ Deleted');setTimeout(()=>location.reload(),1200);}
async function delAll(){
  const btns=[...document.querySelectorAll('tbody button')];
  if(!confirm('Delete all '+btns.length+' cached streams?'))return;
  const keys=btns.map(b=>b.getAttribute('onclick').match(/'([^']+)'/)[1]);
  for(const k of keys)await fetch('/cache/'+k,{method:'DELETE'});
  toast('🗑️ All deleted');setTimeout(()=>location.reload(),1000);
}
</script>"""
    return _page("Streams", "streams", body, extra)


@app.get("/settings", response_class=HTMLResponse)
async def settings_page(request: Request):
    if _needs_setup(request):
        return _setup_redirect()
    cfg = load_saved_config()
    s = request.app.state.settings
    db: CacheDB = request.app.state.db
    # Inject DB-stored keys so field() can show saved indicator
    cfg["TMDB_API_KEY"] = db.get_setting("tmdb_api_key", "") if db else ""

    def field(label, key, hint="", typ="text", placeholder=""):
        val = cfg.get(key) or getattr(s, key, "") or ""
        masked = typ == "password"
        input_type = "password" if masked else "text"
        # Never pre-fill password fields — show a placeholder dot pattern instead
        show_val = val if not masked else ""
        is_saved = bool(val) and masked
        ph = "••••••• (saved — leave blank to keep)" if is_saved else (placeholder or "")
        saved_attr = ' data-saved="true"' if is_saved else ""
        return f"""
        <div class="field">
          <label>{label}{'<span class="saved-badge">saved</span>' if is_saved else ""}</label>
          <input id="{key}" name="{key}" type="{input_type}" value="{show_val}" placeholder="{ph}" autocomplete="off"{saved_attr}>
          {'<div class="hint">' + hint + '</div>' if hint else ''}
        </div>"""

    body = f"""
    <div style="max-width:700px">
      <h2 style="margin-bottom:4px">⚙️ Settings</h2>
      <p style="color:#555;font-size:0.85rem;margin-bottom:28px">Changes are saved immediately and applied without restarting.</p>

      <div class="settings-section">
        <div class="section-title">AllDebrid</div>
        {field("API Key", "ALLDEBRID_API_KEY", 'Get yours at <a href="https://alldebrid.com/apikeys" target="_blank">alldebrid.com/apikeys</a>', "password")}
        <button class="btn btn-sec" onclick="testConn('alldebrid')">Test Connection</button>
        <div id="test-alldebrid" class="test-result"></div>
      </div>

      <div class="settings-section">
        <div class="section-title">Overseerr</div>
        {field("URL", "OVERSEERR_URL", "Your Overseerr instance URL", placeholder="http://192.168.1.x:5055")}
        {field("API Key", "OVERSEERR_API_KEY", "Overseerr → Settings → General → API Key", "password")}
        <button class="btn btn-sec" onclick="testConn('overseerr')">Test Connection</button>
        <div id="test-overseerr" class="test-result"></div>
      </div>

      <div class="settings-section">
        <div class="section-title">TMDB</div>
        {field("API Key", "TMDB_API_KEY", 'Used for cover art and episode number verification. <a href="https://www.themoviedb.org/settings/api" target="_blank" style="color:#f97316">Get a free key →</a>', "password")}
      </div>

      <div class="settings-section">
        <div class="section-title">Plex</div>
        {field("Debridarr Base URL", "DEBRIDARR_BASE_URL", "URL Plex uses to reach Debridarr — written into every .strm file", placeholder="http://192.168.1.x:7474")}
        {field("Plex Library Path", "PLEX_ROOT", "Path inside this container where fake .mkv files are written", placeholder="/plex-strm")}
        <button class="btn btn-sec" onclick="testConn('plex')">Test Path</button>
        <div id="test-plex" class="test-result"></div>
      </div>

      <div class="settings-section">
        <div class="section-title">Library Behaviour</div>
        <div class="toggle-row">
          <div>
            <div class="toggle-label">Include unreleased episodes</div>
            <div class="toggle-hint">When enabled, fake .mkv files are created for episodes that haven't aired yet. Useful for future-proofing your library. Requires re-adding the show to take effect.</div>
          </div>
          <label class="toggle">
            <input type="checkbox" id="include_unreleased_episodes" onchange="saveSetting('include_unreleased_episodes', this.checked)">
            <span class="slider"></span>
          </label>
        </div>
        <div id="test-settings" class="test-result" style="margin-top:10px"></div>
      </div>

      <div class="settings-section">
        <div class="section-title">🗂️ DFS Cache (Streaming Performance)</div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">
          <div class="field">
            <label>Cache Directory</label>
            <input id="dfs_cache_dir" type="text" value="/docker/debridarr/tmp/cache" placeholder="/docker/debridarr/tmp/cache">
            <div class="hint">Directory for chunk cache files</div>
          </div>
          <div class="field">
            <label>Disk Cache Size (GB)</label>
            <input id="dfs_disk_cache_size_gb" type="number" value="30" min="1" max="1000">
            <div class="hint">Maximum disk cache size</div>
          </div>
          <div class="field">
            <label>Cache Expiry (hours)</label>
            <input id="dfs_cache_expiry_h" type="number" value="24" min="1" max="168">
            <div class="hint">How long to keep cached chunks</div>
          </div>
          <div class="field">
            <label>Chunk Size (MB)</label>
            <input id="dfs_chunk_size_mb" type="number" value="8" min="1" max="64">
            <div class="hint">Fetch unit from CDN</div>
          </div>
          <div class="field">
            <label>Read Ahead (MB)</label>
            <input id="dfs_read_ahead_mb" type="number" value="500" min="0" max="2000">
            <div class="hint">Pre-fetch buffer size</div>
          </div>
          <div class="field">
            <label>Cleanup Interval (min)</label>
            <input id="dfs_cleanup_interval_m" type="number" value="20" min="1" max="1440">
            <div class="hint">How often to clean cache</div>
          </div>
        </div>
        <button class="btn btn-sec" onclick="saveDFS()" style="margin-top:8px;padding:8px 20px;font-size:0.85rem">💾 Save DFS Settings</button>
        <div id="dfs-result" class="test-result" style="margin-top:10px"></div>
      </div>

      <div class="settings-section">
        <div class="section-title">🔍 Torrent Search</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">

          <div class="field">
            <label>Completed Series Strategy</label>
            <select id="series_completed_strategy">
              <option value="series_pack">Series Pack (entire show, 1 torrent)</option>
              <option value="season_pack">Season Pack (per season)</option>
              <option value="episode">Per Episode</option>
            </select>
            <div class="hint">Search strategy when a show has ended</div>
          </div>

          <div class="field">
            <label>Ongoing Series Strategy</label>
            <select id="series_ongoing_strategy">
              <option value="season_pack">Season Pack (per season)</option>
              <option value="episode">Per Episode</option>
              <option value="series_pack">Series Pack</option>
            </select>
            <div class="hint">Search strategy for currently airing shows</div>
          </div>

          <div class="field">
            <label>Series Preferred Quality</label>
            <select id="series_preferred_quality">
              <option value="1080p">1080p</option>
              <option value="720p">720p</option>
              <option value="any">Any</option>
            </select>
          </div>

          <div class="field">
            <label>Series Quality Fallback</label>
            <select id="series_fallback_any_quality">
              <option value="true">Yes — use any quality if preferred not found</option>
              <option value="false">No — skip if preferred quality not available</option>
            </select>
          </div>

          <div class="field">
            <label>Movie Preferred Quality</label>
            <select id="movie_preferred_quality">
              <option value="1080p">1080p</option>
              <option value="720p">720p</option>
              <option value="any">Any</option>
            </select>
          </div>

          <div class="field">
            <label>Movie Quality Fallback</label>
            <select id="movie_fallback_any_quality">
              <option value="true">Yes — use any quality if preferred not found</option>
              <option value="false">No — skip if preferred quality not available</option>
            </select>
          </div>

          <div class="field">
            <label>Pre-cache Cooldown (minutes)</label>
            <input id="precache_cooldown_minutes" type="number" min="0" max="60" value="1">
            <div class="hint">Wait time between pre-caching each episode in a season</div>
          </div>

          <div class="field">
            <label>Cache TTL (days)</label>
            <input id="cache_ttl_days" type="number" min="1" max="90" value="30">
            <div class="hint">How long cached streams and symlinks stay active</div>
          </div>

        </div>
        <button class="btn btn-sec" onclick="saveSearch()" style="padding:8px 20px;font-size:0.85rem">💾 Save Search Settings</button>
        <div id="search-result" class="test-result" style="margin-top:10px"></div>
      </div>

      <div class="settings-section">
        <div class="section-title">System</div>
        {field("Timezone", "TZ", 'e.g. America/Edmonton — <a href="https://en.wikipedia.org/wiki/List_of_tz_database_time_zones" target="_blank">full list</a>', placeholder="America/Edmonton")}
        <div style="display:flex;gap:12px">
          <div style="flex:1">{field("PUID", "PUID", "Run: id -u", placeholder="1000")}</div>
          <div style="flex:1">{field("PGID", "PGID", "Run: id -g", placeholder="1000")}</div>
        </div>
      </div>

      <div style="display:flex;gap:12px;margin-top:8px">
        <button class="btn btn-add" onclick="saveAll()" style="padding:10px 28px;font-size:0.9rem">💾 Save All Settings</button>
        <button class="btn btn-sec" onclick="testAll()" style="padding:10px 20px;font-size:0.9rem">🔌 Test All Connections</button>
      </div>
      <div id="save-result" class="test-result" style="margin-top:14px"></div>
    </div>"""

    extra = """<style>
.settings-section { background:#1a1a24; border:1px solid #2a2a3a; border-radius:10px;
                    padding:20px 24px; margin-bottom:16px; }
.section-title { font-size:0.75rem; font-weight:700; text-transform:uppercase;
                 color:#f97316; letter-spacing:.08em; margin-bottom:16px; }
.field { margin-bottom:14px; }
.field label { display:block; font-size:0.8rem; color:#888; margin-bottom:5px; font-weight:600; }
.field input { width:100%; background:#0f0f13; border:1px solid #2a2a3a; border-radius:7px;
               padding:9px 13px; color:#e0e0e0; font-size:0.875rem; outline:none; font-family:monospace; }
.field input:focus { border-color:#f97316; }
.field select { width:100%; background:#0f0f13; border:1px solid #2a2a3a; border-radius:7px;
                padding:9px 13px; color:#e0e0e0; font-size:0.875rem; outline:none; cursor:pointer; }
.field select:focus { border-color:#f97316; }
.field select { width:100%; background:#0f0f13; border:1px solid #2a2a3a; border-radius:7px;
                padding:9px 13px; color:#e0e0e0; font-size:0.875rem; outline:none; cursor:pointer; }
.field select:focus { border-color:#f97316; }
.field .hint { font-size:0.74rem; color:#555; margin-top:4px; line-height:1.4; }
.field .hint a { color:#f97316; }
.saved-badge { display:inline-block; margin-left:8px; font-size:0.68rem; font-weight:700;
               background:#14532d; color:#4ade80; border-radius:4px; padding:1px 6px;
               text-transform:uppercase; letter-spacing:.04em; vertical-align:middle; }
.test-result { margin-top:10px; padding:8px 12px; border-radius:6px; font-size:0.82rem; display:none; }
.test-result.ok      { background:#14532d; color:#4ade80; display:block; }
.test-result.err     { background:#3b0000; color:#f87171; display:block; }
.test-result.testing { background:#1e1e2e; color:#aaa;    display:block; }
.toggle-row { display:flex; align-items:flex-start; justify-content:space-between; gap:20px; padding:4px 0; }
.toggle-label { font-size:0.875rem; color:#e0e0e0; font-weight:600; margin-bottom:4px; }
.toggle-hint  { font-size:0.75rem; color:#555; line-height:1.5; max-width:480px; }
.toggle { position:relative; display:inline-block; width:44px; height:24px; flex-shrink:0; margin-top:2px; }
.toggle input { opacity:0; width:0; height:0; }
.slider { position:absolute; cursor:pointer; inset:0; background:#2a2a3a; border-radius:24px; transition:.2s; }
.slider:before { position:absolute; content:""; height:18px; width:18px; left:3px; bottom:3px;
                 background:#555; border-radius:50%; transition:.2s; }
input:checked + .slider { background:#f97316; }
input:checked + .slider:before { transform:translateX(20px); background:#fff; }
</style>
<script>
function getVal(id) { return document.getElementById(id)?.value?.trim() || ''; }

function setResult(id, ok, msg) {
  const el = document.getElementById('test-' + id);
  if (!el) return;
  el.className = 'test-result ' + (ok ? 'ok' : 'err');
  el.textContent = (ok ? '✅ ' : '❌ ') + msg;
}

async function testConn(service) {
  const el = document.getElementById('test-' + service);
  el.className = 'test-result testing'; el.textContent = 'Testing...';
  let body = { step: service };
  if (service === 'alldebrid') body.api_key = getVal('ALLDEBRID_API_KEY');
  if (service === 'overseerr') { body.url = getVal('OVERSEERR_URL'); body.api_key = getVal('OVERSEERR_API_KEY'); }
  if (service === 'overseerr') { body.url = getVal('OVERSEERR_URL'); body.api_key = getVal('OVERSEERR_API_KEY'); }
  if (service === 'plex')      body.plex_root = getVal('PLEX_ROOT');
  const r = await fetch('/setup/test', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
  const d = await r.json();
  setResult(service, d.ok, d.message);
}

async function testAll() {
  await Promise.all(['alldebrid','overseerr','plex'].map(testConn));
}

async function loadSettings() {
  const r = await fetch('/api/settings/get');
  if (!r.ok) return;
  const d = await r.json();
  const cb = document.getElementById('include_unreleased_episodes');
  if (cb) cb.checked = d.include_unreleased_episodes === 'true';
  // Load DFS settings
  try {
    const dfsR = await fetch('/api/settings/dfs');
    const dfs = await dfsR.json();
    const map = {
      cache_dir: 'dfs_cache_dir', disk_cache_size_gb: 'dfs_disk_cache_size_gb',
      cache_expiry_h: 'dfs_cache_expiry_h', chunk_size_mb: 'dfs_chunk_size_mb',
      read_ahead_mb: 'dfs_read_ahead_mb', cleanup_interval_m: 'dfs_cleanup_interval_m',
    };
    for (const [k,id] of Object.entries(map)) {
      const el = document.getElementById(id);
      if (el && dfs[k] !== undefined) el.value = dfs[k];
    }
  } catch(e) {}
  // Load search settings
  try {
    const ss = d.search_settings || {};
    const searchMap = [
      'series_completed_strategy','series_ongoing_strategy',
      'series_preferred_quality','series_fallback_any_quality',
      'movie_preferred_quality','movie_fallback_any_quality',
      'precache_cooldown_minutes','cache_ttl_days',
    ];
    for (const id of searchMap) {
      const el = document.getElementById(id);
      if (el && ss[id] !== undefined) el.value = ss[id];
    }
  } catch(e) {}
}

async function saveSearch() {
  const res = document.getElementById('search-result');
  res.className = 'test-result testing'; res.style.display='block'; res.textContent = 'Saving...';
  const payload = {
    series_completed_strategy:   document.getElementById('series_completed_strategy').value,
    series_ongoing_strategy:     document.getElementById('series_ongoing_strategy').value,
    series_preferred_quality:    document.getElementById('series_preferred_quality').value,
    series_fallback_any_quality: document.getElementById('series_fallback_any_quality').value,
    movie_preferred_quality:     document.getElementById('movie_preferred_quality').value,
    movie_fallback_any_quality:  document.getElementById('movie_fallback_any_quality').value,
    precache_cooldown_minutes:   document.getElementById('precache_cooldown_minutes').value,
    cache_ttl_days:              document.getElementById('cache_ttl_days').value,
  };
  const r = await fetch('/api/settings/search', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)});
  const d = await r.json();
  if (r.ok) { res.className='test-result ok'; res.textContent='✅ Saved'; }
  else       { res.className='test-result err'; res.textContent='❌ Save failed'; }
}

async function saveSetting(key, value) {
  const res = document.getElementById('test-settings');
  res.className = 'test-result testing'; res.textContent = 'Saving...';
  const r = await fetch('/api/settings/behaviour', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({key, value: value.toString()})
  });
  const d = await r.json();
  if (r.ok) { res.className='test-result ok'; res.textContent='✅ ' + d.message; }
  else       { res.className='test-result err'; res.textContent='❌ ' + (d.detail || 'Error'); }
}

loadSettings();

function getFieldVal(id) {
  const el = document.getElementById(id);
  if (!el) return null;
  const val = el.value.trim();
  // If it's a password field with a saved value and the user left it blank, skip it
  if (!val && el.type === 'password' && el.dataset.saved === 'true') return null;
  return val || null;
}

async function saveDFS() {
  const res = document.getElementById('dfs-result');
  res.className = 'test-result testing'; res.style.display='block'; res.textContent = 'Saving...';
  const payload = {
    cache_dir:          document.getElementById('dfs_cache_dir').value || '/docker/debridarr/tmp/cache',
    disk_cache_size_gb: parseInt(document.getElementById('dfs_disk_cache_size_gb').value),
    cache_expiry_h:     parseInt(document.getElementById('dfs_cache_expiry_h').value),
    chunk_size_mb:      parseInt(document.getElementById('dfs_chunk_size_mb').value),
    read_ahead_mb:      parseInt(document.getElementById('dfs_read_ahead_mb').value),
    cleanup_interval_m: parseInt(document.getElementById('dfs_cleanup_interval_m').value),
  };
  const r = await fetch('/api/settings/dfs', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)});
  const d = await r.json();
  if (r.ok) { res.className='test-result ok'; res.textContent='✅ DFS settings saved'; }
  else       { res.className='test-result err'; res.textContent='❌ Save failed'; }
}

async function saveAll() {
  const res = document.getElementById('save-result');
  res.className = 'test-result testing'; res.textContent = 'Saving...';
  // Only include fields that have a value — null means "don't overwrite"
  const raw = {
    ALLDEBRID_API_KEY:  getFieldVal('ALLDEBRID_API_KEY'),
    OVERSEERR_URL:      getFieldVal('OVERSEERR_URL'),
    OVERSEERR_API_KEY:  getFieldVal('OVERSEERR_API_KEY'),
    TMDB_API_KEY:       getFieldVal('TMDB_API_KEY'),

    DEBRIDARR_BASE_URL: getFieldVal('DEBRIDARR_BASE_URL'),
    PLEX_ROOT:          getFieldVal('PLEX_ROOT'),
    TZ:                 getFieldVal('TZ'),
    PUID:               getFieldVal('PUID'),
    PGID:               getFieldVal('PGID'),
  };
  // Strip nulls before sending
  const payload = Object.fromEntries(Object.entries(raw).filter(([_, v]) => v !== null));
  const r = await fetch('/api/settings/save', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
  const d = await r.json();
  if (r.ok) { res.className='test-result ok'; res.textContent='✅ ' + d.message; }
  else       { res.className='test-result err'; res.textContent='❌ ' + (d.detail || 'Save failed'); }
}
</script>"""

    return _page("Settings", "settings", body, extra)


@app.post("/api/settings/save")
async def api_settings_save(request: Request):
    """Save updated settings to /data/.env and reinitialise clients."""
    body = await request.json()

    # Merge with existing config so we don't blank fields not on this page
    cfg = load_saved_config()
    allowed = {
        "ALLDEBRID_API_KEY", "OVERSEERR_URL", "OVERSEERR_API_KEY", "DEBRIDARR_BASE_URL",
        "PLEX_ROOT", "TZ", "PUID", "PGID",
    }
    for k, v in body.items():
        if k in allowed and v:
            cfg[k] = v

    # TMDB key stored in DB (not .env — it's optional metadata)
    if body.get("TMDB_API_KEY"):
        db: CacheDB = request.app.state.db
        db.set_setting("tmdb_api_key", body["TMDB_API_KEY"])
        # Update live library manager
        if request.app.state.library:
            request.app.state.library.tmdb_key = body["TMDB_API_KEY"]

    write_env(cfg)

    # Push into os.environ FIRST — _init_clients reads directly from os.environ
    import os
    for k, v in cfg.items():
        os.environ[k] = v

    # Reinitialise clients with new settings
    _init_clients(request.app)
    if request.app.state.library:
        request.app.state.library.invalidate_cache()

    log.info("⚙️  Settings updated — restarting container...")
    _schedule_restart(delay=2.0)
    return {"status": "ok", "message": "Settings saved — restarting..."}


@app.post("/api/library/refresh")
async def api_library_refresh(request: Request):
    """Force-refresh the Overseerr library cache and sync new season requests."""
    lm = request.app.state.library
    db = request.app.state.db
    s  = request.app.state.settings
    if not lm:
        return {"status": "error", "message": "Library not configured"}

    # Invalidate cache so next fetch is fresh
    lm.invalidate_cache()

    # Re-fetch everything from Overseerr
    movies = await lm.get_radarr_movies(force=True)
    series = await lm.get_sonarr_series(force=True)

    # Sync seasons for existing series in fake library
    # This adds new season placeholders if more seasons were requested
    added_series = [r for r in db.fake_library_list() if r["media_type"] == "series"]
    synced = 0
    include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"
    for entry in added_series:
        title = entry["title"]
        series_id = entry.get("sonarr_id")
        year = entry.get("year")
        if not series_id:
            continue
        # Find updated series info from Overseerr (may have new seasons)
        updated = next((s for s in series if s["id"] == series_id), None)
        if not updated:
            continue
        requested_seasons = updated.get("requested_seasons", [])
        result = await lm.sync_series_episodes(
            title, series_id, year, include_unreleased,
            requested_seasons=requested_seasons
        )
        if result.get("added", 0) > 0:
            log.info(f"🔄 Synced new episodes for '{title}': +{result['added']}")
            synced += 1

    log.info(f"🔄 Library refresh: {len(movies)} movies, {len(series)} series, {synced} series updated")
    return {"status": "ok", "movies": len(movies), "series": len(series), "synced": synced}


@app.post("/api/settings/search")
async def api_settings_search(request: Request):
    """Save search strategy settings to DB."""
    db: CacheDB = request.app.state.db
    payload = await request.json()
    allowed = {"series_completed_strategy","series_ongoing_strategy",
               "series_preferred_quality","series_fallback_any_quality",
               "precache_cooldown_minutes","movie_preferred_quality",
               "movie_fallback_any_quality","cache_ttl_days"}
    for k, v in payload.items():
        if k in allowed:
            db.set_setting(k, str(v))
    log.info("⚙️  Search settings updated — restarting...")
    _schedule_restart(delay=2.0)
    return {"status": "ok", "message": "Search settings saved — restarting..."}


@app.get("/api/settings/get")
async def api_settings_get(request: Request):
    """Return current behaviour settings."""
    db: CacheDB = request.app.state.db
    return db.get_all_settings()


@app.post("/api/settings/behaviour")
async def api_settings_behaviour(request: Request, background_tasks: BackgroundTasks):
    """Save a single behaviour toggle and apply it immediately."""
    body = await request.json()
    key = body.get("key", "").strip()
    value = body.get("value", "").strip()
    allowed = {"include_unreleased_episodes"}
    if key not in allowed:
        raise HTTPException(400, f"Unknown setting: {key}")

    db: CacheDB = request.app.state.db
    db.set_setting(key, value)
    log.info(f"⚙️  Setting {key} = {value}")

    # If the unreleased toggle changed, sync all series in the fake library immediately
    if key == "include_unreleased_episodes":
        background_tasks.add_task(
            _sync_all_series_episodes, request.app, value == "true"
        )
        return {"status": "ok", "message": f"Saved — syncing episode files in background"}

    return {"status": "ok", "message": f"{key} set to {value}"}


async def _sync_all_series_episodes(app: FastAPI, include_unreleased: bool):
    """Background task: sync fake episode files for every series in the library."""
    db: CacheDB = app.state.db
    lm = app.state.library
    if not lm:
        return

    series_entries = db.fake_library_list(media_type="series")
    if not series_entries:
        log.info("🔄 No series in fake library to sync")
        return

    log.info(f"🔄 Syncing {len(series_entries)} series (include_unreleased={include_unreleased})")
    total_added = total_removed = 0

    for entry in series_entries:
        series_id = entry.get("sonarr_id") or entry.get("series_id")
        title = entry["title"]
        year = entry.get("year")
        if not series_id:
            log.warning(f"No series_id for '{title}', skipping sync")
            continue
        result = await lm.sync_series_episodes(title, series_id, year, include_unreleased)
        total_added   += result["added"]
        total_removed += result["removed"]

    log.info(f"🔄 Sync complete — +{total_added} added, -{total_removed} removed across {len(series_entries)} series")

@app.get("/api/settings/dfs")
async def api_settings_dfs_get():
    """Get current DFS settings."""
    return get_dfs_settings()


@app.post("/api/settings/dfs")
async def api_settings_dfs_save(request: Request, background_tasks: BackgroundTasks):
    """Save DFS settings and apply immediately."""
    body = await request.json()
    allowed = {
        "cache_dir", "disk_cache_size_gb", "cache_expiry_h",
        "chunk_size_mb", "read_ahead_mb", "cleanup_interval_m",
    }
    settings = {k: v for k, v in body.items() if k in allowed}
    # Type coerce numerics
    for k in ("disk_cache_size_gb","cache_expiry_h","chunk_size_mb","read_ahead_mb","cleanup_interval_m"):
        if k in settings:
            try:
                settings[k] = float(settings[k]) if "." in str(settings[k]) else int(settings[k])
            except Exception:
                pass
    update_dfs_settings(settings)
    # Persist to DB
    db: CacheDB = request.app.state.db
    import json
    db.set_setting("dfs_settings", json.dumps(settings))
    return {"status": "ok", "settings": get_dfs_settings()}




@app.get("/health")
async def health(): return {"status":"ok","service":"debridarr","version":"0.4.0"}


async def _torrent_sync_loop(app: FastAPI):
    """Every 5 minutes, check AllDebrid for removed torrents and restore placeholders."""
    await asyncio.sleep(60)
    while True:
        try:
            await _sync_removed_torrents(app)
        except Exception as e:
            log.error(f"Torrent sync error: {e}")
        await asyncio.sleep(300)


async def _sync_removed_torrents(app: FastAPI):
    alldebrid = app.state.alldebrid
    db        = app.state.db
    s         = app.state.settings
    if not alldebrid:
        return

    live = await alldebrid.get_all_torrents()
    # Build a set of ALL names and stems that are live on AllDebrid
    live_names: set[str] = set()
    for t in live:
        live_names.add(t["name"])
        # Also add the raw AllDebrid name (before stem resolution) as fallback
        for f in t.get("files", []):
            stem = Path(f["n"]).stem
            if stem:
                live_names.add(stem)

    current_fuse = set(list_torrents())
    removed = current_fuse - live_names
    if not removed:
        log.debug("Torrent sync: all live")
        return

    # Before acting on "removed" — check if they have active symlinks
    # If yes, keep them in FUSE (AllDebrid name format may differ)
    truly_removed = []
    has_symlink_skip = []
    for torrent_name in removed:
        has_active_symlink = False
        if s.PLEX_ROOT:
            entries = [e for e in db.list_all()
                       if e.get("torrent_name") == torrent_name and e["status"] == "cached"]
            for entry in entries:
                strm = entry.get("strm_path")
                if strm and Path(strm).is_symlink():
                    has_active_symlink = True
                    break
        if has_active_symlink:
            has_symlink_skip.append(torrent_name)
        else:
            truly_removed.append(torrent_name)

    if has_symlink_skip:
        log.debug(f"Torrent sync: keeping {len(has_symlink_skip)} FUSE entries with active symlinks")

    if not truly_removed:
        return

    log.info(f"🗑️  {len(truly_removed)} torrents removed from AllDebrid (no active symlinks)")
    for torrent_name in truly_removed:
        entries = [e for e in db.list_all() if e.get("torrent_name") == torrent_name]
        for entry in entries:
            if s.PLEX_ROOT:
                _restore_placeholder(
                    entry["cache_key"], entry["title"], entry.get("year"),
                    entry.get("season"), entry.get("episode"),
                    entry["media_type"], s.PLEX_ROOT
                )
            db.update_status(entry["cache_key"], "not_found")
        unregister_torrent(torrent_name)


def _restore_placeholder(cache_key, title, year, season, episode, media_type, plex_root):
    from app.library import _FAKE_MP4
    try:
        if media_type == "movie":
            year_part = f" ({year})" if year else ""
            folder = Path(plex_root) / "movies" / f"{title}{year_part}"
            for f in folder.glob("*.mkv"):
                if f.is_symlink(): f.unlink()
            placeholder = folder / f"{title}{year_part}.mp4"
            if not placeholder.exists():
                placeholder.write_bytes(_FAKE_MP4)
        else:
            if not season or not episode:
                return
            season_folder = Path(plex_root) / "tv" / title / f"Season {season:02d}"
            se = f"S{season:02d}E{episode:02d}"
            for f in season_folder.glob(f"*{se}*.mkv"):
                if f.is_symlink(): f.unlink()
            placeholder = season_folder / f"{title} - {se}.mp4"
            if not placeholder.exists():
                season_folder.mkdir(parents=True, exist_ok=True)
                placeholder.write_bytes(_FAKE_MP4)
    except Exception as e:
        log.error(f"Failed to restore placeholder for {cache_key}: {e}")


async def _overseerr_sync_loop(app: FastAPI):
    """Hourly sync — picks up new season requests from Overseerr."""
    await asyncio.sleep(3600)  # wait 1h before first sync
    while True:
        try:
            lm = app.state.library
            db = app.state.db
            s  = app.state.settings
            if lm and s.PLEX_ROOT:
                lm.invalidate_cache()
                series_list = await lm.get_sonarr_series(force=True)
                added = [r for r in db.fake_library_list() if r["media_type"] == "series"]
                include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"
                for entry in added:
                    updated = next((s for s in series_list if s["id"] == entry.get("sonarr_id")), None)
                    if not updated:
                        continue
                    requested_seasons = updated.get("requested_seasons", [])
                    result = await lm.sync_series_episodes(
                        entry["title"], entry["sonarr_id"], entry.get("year"),
                        include_unreleased, requested_seasons=requested_seasons
                    )
                    if result.get("added", 0) > 0:
                        log.info(f"🔄 Overseerr sync: new episodes for '{entry['title']}' +{result['added']}")
                log.info("🔄 Overseerr hourly sync complete")
        except Exception as e:
            log.error(f"Overseerr sync error: {e}")
        await asyncio.sleep(3600)


async def _load_all_torrents(app: FastAPI):
    """Load all torrents from AllDebrid account into FUSE on startup."""
    await asyncio.sleep(2)  # Let FUSE settle
    alldebrid = app.state.alldebrid
    s = app.state.settings
    if not alldebrid or not FUSE_AVAILABLE or not getattr(app.state, "fuse_thread", None):
        return
    try:
        torrents = await alldebrid.get_all_torrents()
        for t in torrents:
            # Use video filename stem as FUSE folder when torrent name is truncated
            files = t["files"]
            folder_name = t["name"]
            if files:
                stem = Path(files[0]["n"]).stem
                if stem and folder_name and stem.startswith(folder_name.rstrip("-")):
                    folder_name = stem
            register_torrent(folder_name, files)
            # Store resolved folder name back so _restore_symlinks can use it
            t["_folder"] = folder_name
        log.info(f"✅ {len(torrents)} torrents loaded into FUSE")
        # Recreate any missing symlinks for cached DB entries
        if s.PLEX_ROOT:
            _restore_symlinks(app, torrents)
    except Exception as e:
        log.error(f"_load_all_torrents failed: {e}", exc_info=True)


def _restore_symlinks(app, torrents: list):
    """
    Recreate plex-strm symlinks immediately after torrents load on startup.
    
    IMPORTANT: Do NOT check Path.exists() on symlinks — FUSE files appear
    non-existent until first read. Only check that the symlink points into
    the FUSE mount directory and the torrent is registered.
    """
    db = app.state.db
    s  = app.state.settings
    if not s.PLEX_ROOT or not s.FUSE_SYMLINK_ROOT:
        return
    restored = 0
    skipped  = 0
    missing  = 0

    for entry in db.list_all():
        if entry["status"] != "cached":
            continue

        strm = entry.get("strm_path")

        # Check if existing symlink points into FUSE mount — if so, trust it
        # Don't use .exists() because FUSE files aren't readable until accessed
        if strm:
            p = Path(strm)
            if p.is_symlink():
                target = str(p.readlink())
                if s.FUSE_SYMLINK_ROOT in target:
                    # Symlink points to FUSE — check the torrent is registered
                    rel = target.replace(s.FUSE_SYMLINK_ROOT, "").lstrip("/")
                    parts = rel.split("/", 1)
                    if len(parts) == 2:
                        from app.fuse_mount import get_torrent_file as _gtf
                        if _gtf(parts[0], parts[1]):
                            skipped += 1
                            continue
                        # Torrent registered under different key — fall through to re-link

        title   = entry["title"]
        year    = entry.get("year")
        season  = entry.get("season")
        episode = entry.get("episode")

        fuse_match = _find_in_fuse(title, year, season, episode)
        if not fuse_match:
            missing += 1
            continue

        torrent_name, filename, _ = fuse_match
        fuse_virtual = get_fuse_path(torrent_name, filename, s.FUSE_SYMLINK_ROOT)
        link = _make_plex_symlink(
            cache_key=entry["cache_key"], title=title,
            year=year, season=season, episode=episode,
            media_type=entry["media_type"],
            plex_root=s.PLEX_ROOT, target=fuse_virtual, video_name=filename,
        )
        if link:
            db.update_cached(
                entry["cache_key"],
                entry.get("magnet_link", ""),
                entry.get("stream_url", ""),
                torrent_name,
                entry.get("quality", "unknown"),
                str(link),
            )
            restored += 1

    log.info(f"✅ Symlinks: {skipped} OK, {restored} restored, {missing} not in FUSE")


async def _symlink_health_loop(app: FastAPI):
    """
    On startup (after all torrents load) and every hour — repair broken symlinks.
    Never destructive: only creates/re-creates, never deletes.
    """
    # Wait for _load_all_torrents to finish
    # It logs "✅ N torrents loaded into FUSE" — we detect stabilisation
    prev_count = 0
    stable_for = 0
    for _ in range(180):  # up to 3 min
        await asyncio.sleep(1)
        count = len(list_torrents())
        if count > 0 and count == prev_count:
            stable_for += 1
            if stable_for >= 5:  # stable for 5s = done loading
                break
        else:
            stable_for = 0
        prev_count = count

    log.info(f"Starting symlink health check ({prev_count} torrents in FUSE)")

    while True:
        try:
            await _check_and_repair_symlinks(app)
        except Exception as e:
            log.error(f"Symlink health check error: {e}")
        await asyncio.sleep(3600)  # every hour


async def _check_and_repair_symlinks(app: FastAPI):
    db    = app.state.db
    s     = app.state.settings
    if not s.PLEX_ROOT:
        return

    entries = db.list_all()
    cached  = [e for e in entries if e["status"] == "cached"]
    if not cached:
        return

    broken   = []
    ok_count = 0

    for entry in cached:
        media_type = entry["media_type"]
        title      = entry["title"]
        year       = entry.get("year")
        season     = entry.get("season")
        episode    = entry.get("episode")
        strm_path  = entry.get("strm_path")

        issue = None
        try:
            if strm_path:
                p = Path(strm_path)
                if not p.is_symlink():
                    issue = "symlink missing"
                else:
                    target = str(p.readlink())
                    if s.FUSE_SYMLINK_ROOT in target:
                        # FUSE symlink — check by registry not .exists() (FUSE lazy-loads)
                        rel = target.replace(s.FUSE_SYMLINK_ROOT, "").lstrip("/")
                        parts = rel.split("/", 1)
                        if len(parts) == 2:
                            from app.fuse_mount import get_torrent_file as _gtf
                            if _gtf(parts[0], parts[1]):
                                ok_count += 1  # registered in FUSE — good
                            else:
                                # Not registered — try to find under different key
                                fuse_match = _find_in_fuse(title, year, season, episode)
                                issue = "FUSE key mismatch" if fuse_match else "not in FUSE"
                        else:
                            ok_count += 1
                    else:
                        # Non-FUSE path — use .exists() normally
                        if p.exists():
                            ok_count += 1
                        else:
                            issue = "dangling symlink"
            else:
                # No strm_path recorded — check plex-strm on disk
                if media_type == "movie":
                    year_part = f" ({year})" if year else ""
                    folder = Path(s.PLEX_ROOT) / "movies" / f"{title}{year_part}"
                    has_symlink = folder.exists() and any(
                        f.is_symlink() and f.exists() for f in folder.iterdir()
                    )
                else:
                    if not season or not episode:
                        continue
                    se = f"S{season:02d}E{episode:02d}"
                    season_folder = Path(s.PLEX_ROOT) / "tv" / title / f"Season {season:02d}"
                    has_symlink = False
                    if season_folder.exists():
                        for f in season_folder.iterdir():
                            if f.is_symlink() and se.upper() in f.name.upper():
                                if f.exists():
                                    has_symlink = True
                                else:
                                    f.unlink(missing_ok=True)
                                break
                if not has_symlink:
                    issue = "no symlink found in plex-strm"
                else:
                    ok_count += 1

            if issue:
                broken.append((entry, issue))

        except Exception as e:
            log.debug(f"Health check error for {entry['cache_key']}: {e}")

    total = len(cached)
    if not broken:
        log.info(f"✅ Symlink check: all {ok_count}/{total} OK")
        return

    log.info(f"🔧 Symlink check: {len(broken)} broken, {ok_count} OK out of {total}")
    for entry, issue in broken:
        log.info(f"  🔧 {entry['cache_key']}: {issue}")

    # Write placeholders for all broken entries BEFORE starting repairs
    # so Plex sees episodes during the re-resolve window
    from app.library import _FAKE_MP4
    for entry, _ in broken:
        try:
            mtype = entry["media_type"]
            t     = entry["title"]
            yr    = entry.get("year")
            sn    = entry.get("season")
            ep    = entry.get("episode")
            if mtype == "movie":
                yp = f" ({yr})" if yr else ""
                folder = Path(s.PLEX_ROOT) / "movies" / f"{t}{yp}"
                ph = folder / f"{t}{yp}.mp4"
            elif sn and ep:
                folder = Path(s.PLEX_ROOT) / "tv" / t / f"Season {sn:02d}"
                ph = folder / f"{t} - S{sn:02d}E{ep:02d}.mp4"
            else:
                continue
            folder.mkdir(parents=True, exist_ok=True)
            if not ph.exists() and not ph.is_symlink():
                ph.write_bytes(_FAKE_MP4)
                log.debug(f"  📄 Placeholder: {ph.name}")
        except Exception:
            pass

    for entry, issue in broken:
        title   = entry["title"]
        year    = entry.get("year")
        season  = entry.get("season")
        episode = entry.get("episode")
        mtype   = entry["media_type"]

        # First try FUSE directly — fastest, no API calls
        fuse_match = _find_in_fuse(title, year, season, episode)
        if fuse_match:
            torrent_name, filename, _ = fuse_match
            s = app.state.db  # reuse db ref
            fuse_virtual = get_fuse_path(torrent_name, filename, app.state.settings.FUSE_SYMLINK_ROOT)
            link = _make_plex_symlink(
                cache_key=entry["cache_key"], title=title, year=year,
                season=season, episode=episode, media_type=mtype,
                plex_root=app.state.settings.PLEX_ROOT,
                target=fuse_virtual, video_name=filename,
            )
            if link:
                db.update_cached(
                    entry["cache_key"],
                    entry.get("magnet_link", ""),
                    entry.get("stream_url", ""),
                    torrent_name,
                    entry.get("quality", "unknown"),
                    str(link),
                )
                log.info(f"  ✅ Relinked from FUSE: {entry['cache_key']}")
                await asyncio.sleep(0.1)
                continue

        # FUSE miss — mark for re-resolution via TPB (keeps placeholder in place)
        log.info(f"  ↺  Re-resolving (FUSE miss): {entry['cache_key']}")
        # Keep status as cached so placeholder logic doesn't restore mp4 prematurely
        # resolve_and_cache will overwrite when it succeeds
        event = PlayEvent(
            media_type=MediaType(mtype),
            title=title, year=year,
            season=season, episode=episode,
        )
        try:
            # Temporarily mark as not_found ONLY right before re-resolve
            db.update_status(entry["cache_key"], "not_found")
            await resolve_and_cache(app, event)
            await asyncio.sleep(2)
        except Exception as e:
            # Re-resolve failed — restore cached status so placeholder stays
            db.update_status(entry["cache_key"], "cached")
            log.error(f"  ❌ Re-resolve failed for {entry['cache_key']}: {e}")


async def _get_tmdb_key(app) -> str:
    """Get TMDB API key from DB settings."""
    try:
        db = app.state.db
        return db.get_setting("tmdb_api_key", "")
    except Exception:
        return ""


def _detect_quality_from_name(name: str) -> str:
    n = name.lower()
    for q in ["2160p", "4k", "uhd", "1080p", "720p", "480p"]:
        if q in n:
            return q
    return "unknown"


def _find_in_fuse(
    title: str, year, season, episode
) -> "Optional[tuple[str, str, dict]]":
    """
    Search FUSE-mounted torrents for a file matching the title + episode/movie.
    Returns (torrent_name, filename, file_dict) or None.
    Searches by title words appearing in torrent name, then S##E## in filename.
    """
    import re as _re

    def normalize(s):
        s = s.lower().replace("'","").replace("’","")
        s = _re.sub(r"[._]", " ", s)
        return s.split()

    title_words = normalize(title)
    if not title_words:
        return None

    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}

    for torrent_name in list_torrents():
        t_words = normalize(torrent_name)
        # All title words must appear in the torrent name
        if not all(w in t_words for w in title_words):
            continue
        # Year check for movies
        if year and str(year) not in torrent_name:
            continue

        files = list_files(torrent_name)
        for fname in files:
            if not any(fname.lower().endswith(e) for e in video_exts):
                continue
            if season and episode:
                se = f"S{season:02d}E{episode:02d}".upper()
                if se not in fname.upper():
                    continue
            elif season and not episode:
                s_pat = f"S{season:02d}".upper()
                if s_pat not in fname.upper():
                    continue
            from app.fuse_mount import get_torrent_file as _gtf
            f = _gtf(torrent_name, fname)
            if f:
                return torrent_name, fname, f
    return None


async def _verify_episode_with_tmdb(
    tmdb_id: str, tvdb_id: str, season: int, episode: int, title: str,
    tmdb_key: str = ""
) -> tuple[int, int]:
    """
    Verify episode season/number via TMDB API.
    Returns (season, episode) — corrected if TMDB disagrees with Plex.
    Falls back to original values if TMDB is unavailable.

    Plex sometimes uses absolute episode numbering (e.g. E153) instead of
    season-based (S06E01). TMDB tells us the correct S##E## for the airdate.
    """
    import httpx as _httpx

    if not tmdb_key:
        return season, episode

    try:
        if tvdb_id:
            # Look up by TVDB ID first — most reliable for TV
            async with _httpx.AsyncClient(timeout=10) as c:
                r = await c.get(
                    f"https://api.themoviedb.org/3/find/{tvdb_id}",
                    params={"api_key": tmdb_key,
                            "external_source": "tvdb_id"},
                )
                if r.status_code == 200:
                    data = r.json()
                    eps = data.get("tv_episode_results", [])
                    if eps:
                        ep = eps[0]
                        tmdb_s  = ep.get("season_number", season)
                        tmdb_ep = ep.get("episode_number", episode)
                        if tmdb_s != season or tmdb_ep != episode:
                            log.info(f"🎬 TMDB corrected {title} S{season:02d}E{episode:02d} → S{tmdb_s:02d}E{tmdb_ep:02d}")
                        return tmdb_s, tmdb_ep

        if tmdb_id:
            # Look up via TMDB episode ID directly
            async with _httpx.AsyncClient(timeout=10) as c:
                r = await c.get(
                    f"https://api.themoviedb.org/3/tv/{tmdb_id}/season/{season}/episode/{episode}",
                    params={"api_key": tmdb_key},
                )
                if r.status_code == 200:
                    ep = r.json()
                    tmdb_s  = ep.get("season_number", season)
                    tmdb_ep = ep.get("episode_number", episode)
                    return tmdb_s, tmdb_ep

    except Exception as e:
        log.debug(f"TMDB lookup failed for {title}: {e}")

    return season, episode


async def resolve_and_cache(app: FastAPI, event: PlayEvent):
    db = app.state.db
    alldebrid = app.state.alldebrid
    s = app.state.settings
    cache_key = event.cache_key()

    existing = db.get(cache_key)
    if existing and existing["status"] == "cached":
        log.info(f"✅ Cache hit: {cache_key}")
        # Re-register in FUSE if lost after restart
        _reregister_in_fuse(cache_key, existing, app)
        return

    log.info(f"🔍 Resolving: {cache_key}")
    db.upsert(cache_key, event, status="resolving")

    try:
        # 0. Verify episode numbering via TMDB (corrects Plex absolute numbering)
        if event.media_type.value == "episode" and event.season and event.episode:
            tmdb_key = db.get_setting("tmdb_api_key", "")
            corrected_s, corrected_ep = await _verify_episode_with_tmdb(
                tmdb_id=event.tmdb_id,
                tvdb_id=event.tvdb_id,
                season=event.season,
                episode=event.episode,
                title=event.title,
                tmdb_key=tmdb_key,
            )
            if corrected_s != event.season or corrected_ep != event.episode:
                # Re-check cache with corrected numbers
                event = event.model_copy(update={"season": corrected_s, "episode": corrected_ep})
                cache_key = event.cache_key()
                existing = db.get(cache_key)
                if existing and existing["status"] == "cached":
                    log.info(f"✅ Cache hit (corrected): {cache_key}")
                    _reregister_in_fuse(cache_key, existing, app)
                    return
                db.upsert(cache_key, event, status="resolving")

        # 1. Determine search strategy from DB settings
        s_cfg = db.get_all_settings()
        if event.media_type.value == "episode":
            # Check if series is ended to pick strategy
            lm = app.state.library
            is_ended = False
            series_status = "continuing"
            if lm:
                try:
                    series_list = await lm.get_sonarr_series()
                    series_meta = next((s for s in series_list
                                       if s["title"].lower() == event.title.lower()), None)
                    if series_meta:
                        series_status = series_meta.get("status", "continuing").lower()
                        is_ended = series_status in ("ended", "cancelled", "canceled")
                except Exception:
                    pass

            if is_ended:
                strategy = s_cfg.get("series_completed_strategy", "series_pack")
            else:
                strategy = s_cfg.get("series_ongoing_strategy", "season_pack")
            preferred_quality = s_cfg.get("series_preferred_quality", "1080p")
            fallback_any      = s_cfg.get("series_fallback_any_quality", "true") == "true"
        else:
            strategy          = "movie"
            preferred_quality = s_cfg.get("movie_preferred_quality", "1080p")
            fallback_any      = s_cfg.get("movie_fallback_any_quality", "true") == "true"

        # 1. Check FUSE mount first — if we already have the file, skip TPB entirely
        fuse_match = _find_in_fuse(event.title, event.year, event.season, event.episode)
        if fuse_match:
            torrent_name, filename, fuse_file = fuse_match
            log.info(f"✅ Found in FUSE — symlinking directly (no search needed)")
            fuse_virtual = get_fuse_path(torrent_name, filename, s.FUSE_SYMLINK_ROOT)
            symlink_path = _make_plex_symlink(
                cache_key=cache_key,
                title=event.title, year=event.year,
                season=event.season, episode=event.episode,
                media_type=event.media_type.value,
                plex_root=s.PLEX_ROOT,
                target=fuse_virtual,
                video_name=filename,
            )
            ad_link = fuse_file.get("l", "")
            db.update_cached(cache_key, "", ad_link, torrent_name,
                             _detect_quality_from_name(filename), str(symlink_path) if symlink_path else None)
            log.info(f"✅ Symlinked from FUSE: {cache_key}")
            return

        # 2. Not in FUSE — search TPB for a cached torrent on AllDebrid
        log.info(f"🔎 Searching TPB for: {event.title!r}")
        results = await alldebrid.search_cached(
            title=event.title,
            media_type=event.media_type.value,
            year=event.year,
            season=event.season,
            episode=event.episode,
            imdb_id=event.imdb_id,
            strategy=strategy,
            preferred_quality=preferred_quality,
            fallback_any=fallback_any,
        )
        if not results:
            log.warning(f"❌ No results: {cache_key}")
            db.update_status(cache_key, "not_found")
            return

        best = results[0]
        log.info(f"🎯 Best: {best['name']} cached={best['cached']} quality={best.get('quality','?')}")

        # 2. Add magnet to AllDebrid → get file list
        result = await alldebrid.add_magnet(best["magnet"])
        if not result:
            db.update_status(cache_key, "unlock_failed")
            return

        magnet_id, files = result

        # Use torrent name as the FUSE directory (mirrors decypharr structure)
        torrent_name = best["name"]

        # For episodes: find the file matching this specific S##E##
        # This prevents using S01E08 file for every pre-cached episode
        target_file = None
        if event.media_type.value == "episode" and event.season and event.episode:
            se_pat = f"S{event.season:02d}E{event.episode:02d}".upper()
            for f in files:
                if se_pat in f.get("n", "").upper():
                    target_file = f
                    break

        if not target_file:
            # Fallback: largest file (movies, or season packs without clear ep names)
            target_file = max(files, key=lambda f: f.get("s", 0))

        filename  = target_file.get("n", torrent_name)
        ad_link   = target_file.get("l", "")
        file_size = target_file.get("s", 0)

        # AllDebrid sometimes truncates torrent_name in the status response.
        # The file's 'n' field has the full filename — use its stem as the FUSE folder
        # if the torrent_name looks like a truncated version of the filename stem.
        filename_stem = Path(filename).stem if filename else torrent_name
        if filename_stem and torrent_name and filename_stem.startswith(torrent_name.rstrip("-")):
            # filename has more chars than torrent_name — use filename stem as folder
            fuse_folder_name = filename_stem
            log.debug(f"Using filename stem as FUSE folder: {fuse_folder_name!r} (was {torrent_name!r})")
        else:
            fuse_folder_name = torrent_name

        if not ad_link:
            log.error(f"No file link for {cache_key}")
            db.update_status(cache_key, "unlock_failed")
            return

        log.info(f"📁 {torrent_name}/{filename} ({file_size} bytes)")

        # 3. Register ALL files in FUSE under the torrent name
        fuse_thread = getattr(app.state, "fuse_thread", None)
        strm_path = None

        if s.PLEX_ROOT:
            if FUSE_AVAILABLE and fuse_thread:
                # /mnt/alldebrid/<fuse_folder_name>/<filename>
                register_torrent(fuse_folder_name, files)

                # Symlink uses host path so Plex can resolve it
                fuse_virtual = get_fuse_path(fuse_folder_name, filename, s.FUSE_SYMLINK_ROOT)
                log.info(f"📂 FUSE: {fuse_virtual}")

                symlink_path = _make_plex_symlink(
                    cache_key=cache_key,
                    title=event.title, year=event.year,
                    season=event.season, episode=event.episode,
                    media_type=event.media_type.value,
                    plex_root=s.PLEX_ROOT,
                    target=fuse_virtual,
                    video_name=filename,
                )
                strm_path = str(symlink_path) if symlink_path else None
                log.info(f"🔗 {symlink_path} → {fuse_virtual}")
            else:
                p = write_strm(cache_key=cache_key, title=event.title, year=event.year,
                               season=event.season, episode=event.episode,
                               media_type=event.media_type.value,
                               debridarr_base_url=s.DEBRIDARR_BASE_URL, plex_root=s.PLEX_ROOT)
                strm_path = str(p) if p else None

        db.update_cached(cache_key, best["magnet"], ad_link, torrent_name,
                         best.get("quality", "1080p"), strm_path)
        log.info(f"✅ Done: {cache_key}")

        # Pre-cache rest of season in background (with cooldown)
        if event.media_type.value == "episode" and event.season and event.episode:
            cooldown = int(db.get_setting("precache_cooldown_minutes", "1"))
            asyncio.create_task(_precache_next_episodes(app, event, cooldown_minutes=cooldown))

    except Exception as e:
        log.error(f"❌ {cache_key}: {e}", exc_info=True)
        db.update_status(cache_key, "error")



async def _precache_next_episodes(app: FastAPI, event: PlayEvent, count: int = 3, cooldown_minutes: int = 1):
    """
    Pre-cache ALL episodes in the season, skipping the current one and any already cached.
    Order: episodes before current (1..E-1) then episodes after (E+1..N).
    Only makes API calls for episodes not already in DB as cached/resolving.
    """
    await asyncio.sleep(5)  # let current resolve finish first
    db    = app.state.db
    lm    = app.state.library
    title   = event.title
    season  = event.season
    episode = event.episode
    year    = event.year

    # Get episode count for this season from Overseerr cache (no extra API hit if cached)
    season_size = None
    if lm:
        try:
            series_list = await lm.get_sonarr_series()
            series = next((s for s in series_list if s["title"].lower() == title.lower()), None)
            if series:
                curr = next((s for s in series.get("seasons", []) if s["season_number"] == season), None)
                if curr:
                    season_size = curr.get("episode_count")
        except Exception as e:
            log.debug(f"Could not get season size: {e}")

    if not season_size:
        log.debug(f"⏭️  Unknown season size for '{title}' S{season:02d} — skipping pre-cache")
        return

    log.info(f"⏭️  Pre-caching '{title}' S{season:02d} ({season_size} eps), played E{episode:02d}")

    # Build ordered list: episodes before current, then episodes after
    before = list(range(1, episode))           # E01..E(N-1)
    after  = list(range(episode + 1, season_size + 1))  # E(N+1)..end
    all_eps = before + after  # current episode already being resolved

    for ep in all_eps:
        fake_event = PlayEvent(
            media_type=event.media_type,
            title=title, year=year,
            season=season, episode=ep,
        )
        ck = fake_event.cache_key()

        # Check DB only — no API hit
        existing = db.get(ck)
        if existing and existing["status"] in ("cached", "resolving"):
            log.debug(f"⏭️  {ck} already {existing['status']} — skip")
            continue

        log.info(f"⏭️  Pre-caching {ck}")
        try:
            await resolve_and_cache(app, fake_event)
            await asyncio.sleep(max(3, cooldown_minutes * 60))  # rate-limit between resolves
        except Exception as e:
            log.debug(f"Pre-cache failed {ck}: {e}")


def _reregister_in_fuse(cache_key: str, entry: dict, app):
    """No-op — _load_all_torrents handles re-registration at startup."""
    pass


def _make_plex_symlink(
    cache_key: str, title: str, year, season, episode,
    media_type: str, plex_root: str, target: "Path", video_name: str
) -> "Optional[Path]":
    """
    Create a symlink in the Plex library pointing to the FUSE virtual file.

    Strategy (placeholder-first):
      1. Ensure placeholder .mp4 exists (write it if missing)
      2. Create the new symlink
      3. Only remove placeholder AFTER symlink is confirmed in place
      4. On any failure, restore placeholder so Plex always sees the episode

    Movie:   /plex-strm/movies/<Title> (<Year>)/<filename.mkv>  → FUSE
    Episode: /plex-strm/tv/<Title>/Season NN/<filename.mkv>     → FUSE
    """
    from pathlib import Path as _P
    from app.library import _FAKE_MP4

    # Determine folder and placeholder path up front
    if media_type == "movie":
        year_part = f" ({year})" if year else ""
        folder = _P(plex_root) / "movies" / f"{title}{year_part}"
        placeholder = folder / f"{title}{year_part}.mp4"
    else:
        season_folder = f"Season {season:02d}" if season else "Season 00"
        folder = _P(plex_root) / "tv" / title / season_folder
        se = f"S{season:02d}E{episode:02d}" if (season and episode) else "S00E00"
        placeholder = folder / f"{title} - {se}.mp4"

    # Step 1: Ensure placeholder exists before touching anything
    try:
        folder.mkdir(parents=True, exist_ok=True)
        if not placeholder.exists() and not placeholder.is_symlink():
            placeholder.write_bytes(_FAKE_MP4)
            log.debug(f"📄 Placeholder written: {placeholder.name}")
    except Exception as e:
        log.error(f"Could not write placeholder for {cache_key}: {e}")

    try:
        # Step 2: Remove stale symlinks for this episode (different filename/release)
        if media_type == "movie":
            for f in folder.iterdir():
                if f.is_symlink() and f.suffix in (".mkv", ".mp4", ".avi", ".mov", ".m4v"):
                    f.unlink(missing_ok=True)
        elif season and episode:
            se_pat = f"S{season:02d}E{episode:02d}".upper()
            for f in folder.iterdir():
                if f.is_symlink() and se_pat in f.name.upper():
                    f.unlink(missing_ok=True)

        # Step 3: Create symlink
        link = folder / video_name
        if link.is_symlink() or link.exists():
            link.unlink(missing_ok=True)
        link.symlink_to(target)

        # Step 4: Verify symlink is in place, then remove placeholder
        if link.is_symlink():
            if placeholder.exists() and not placeholder.is_symlink():
                placeholder.unlink(missing_ok=True)
            log.info(f"🔗 Symlink: {link.name} → {target}")
            return link
        else:
            # Symlink creation failed silently — restore placeholder
            if not placeholder.exists():
                placeholder.write_bytes(_FAKE_MP4)
            log.error(f"Symlink creation failed silently for {cache_key}")
            return None

    except Exception as e:
        log.error(f"Failed to create symlink for {cache_key}: {e}")
        # Always restore placeholder on failure
        try:
            if not placeholder.exists() and not placeholder.is_symlink():
                folder.mkdir(parents=True, exist_ok=True)
                placeholder.write_bytes(_FAKE_MP4)
        except Exception:
            pass
        return None

from pathlib import Path
