"""
Debridarr - On-the-fly AllDebrid streaming for Plex

Flow:
  1. User opens /library → browses Sonarr/Radarr libraries → clicks Add
  2. Debridarr creates zero-byte .mkv placeholder files → Plex scans + indexes them
  3. User hits Play in Plex → Tautulli fires webhook → Debridarr resolves real stream
  4. /proxy/<key> serves bytes transparently, refreshing AllDebrid URLs as needed
"""

import asyncio
import logging
import sys
from contextlib import asynccontextmanager
from datetime import datetime

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse

from app.alldebrid import AllDebridClient
from app.cache import CacheDB
from app.config import settings
from app.library import LibraryManager
from app.models import MediaType, PlayEvent
from app.proxy import proxy_stream, write_strm, delete_strm

logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("debridarr")


@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info("🚀 Debridarr starting up...")
    db = CacheDB(settings.DB_PATH)
    db.init()
    app.state.db = db
    app.state.alldebrid = AllDebridClient(settings.ALLDEBRID_API_KEY)
    app.state.library = LibraryManager(
        sonarr_url=settings.SONARR_URL,
        sonarr_key=settings.SONARR_API_KEY,
        radarr_url=settings.RADARR_URL,
        radarr_key=settings.RADARR_API_KEY,
        plex_root=settings.PLEX_ROOT,
    )

    async def cleanup_loop():
        while True:
            await asyncio.sleep(3600)
            expired = db.list_expired()
            for entry in expired:
                delete_strm(
                    cache_key=entry["cache_key"],
                    title=entry["title"],
                    year=entry.get("year"),
                    season=entry.get("season"),
                    episode=entry.get("episode"),
                    media_type=entry["media_type"],
                    plex_root=settings.PLEX_ROOT,
                )
            purged = db.purge_expired()
            if purged:
                log.info(f"🗑️  Purged {purged} expired cache entries")

    asyncio.create_task(cleanup_loop())
    log.info(f"✅ Debridarr ready  plex_root={settings.PLEX_ROOT or 'NOT SET'}")
    yield


app = FastAPI(title="Debridarr", version="0.3.0", lifespan=lifespan)


# ─────────────────────────────────────────────────────────────────────────────
# Shared CSS / JS snippets
# ─────────────────────────────────────────────────────────────────────────────
_BASE_STYLE = """
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
       background: #0f0f13; color: #e0e0e0; min-height: 100vh; }
header { background: #1a1a24; border-bottom: 1px solid #2a2a3a;
         padding: 14px 28px; display: flex; align-items: center; gap: 16px; }
header h1 { font-size: 1.3rem; color: #fff; }
header .ver { font-size: 0.75rem; background: #f97316; color: #fff;
              border-radius: 4px; padding: 2px 8px; }
nav { display: flex; gap: 4px; margin-left: auto; }
nav a { color: #aaa; text-decoration: none; padding: 6px 14px; border-radius: 6px;
        font-size: 0.85rem; transition: background .15s; }
nav a:hover, nav a.active { background: #2a2a3a; color: #fff; }
main { padding: 28px; max-width: 1400px; margin: 0 auto; }
h2 { font-size: 1.05rem; color: #ccc; margin-bottom: 18px; }
.card-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
             gap: 16px; }
.card { background: #1a1a24; border: 1px solid #2a2a3a; border-radius: 10px;
        overflow: hidden; position: relative; cursor: default; }
.card img { width: 100%; aspect-ratio: 2/3; object-fit: cover;
            background: #111; display: block; }
.card .info { padding: 10px 12px; }
.card .title { font-size: 0.88rem; font-weight: 600; color: #e0e0e0;
               white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.card .meta  { font-size: 0.75rem; color: #666; margin-top: 2px; }
.card .actions { padding: 0 12px 12px; display: flex; gap: 6px; }
btn, .btn { display: inline-block; padding: 5px 12px; border-radius: 6px;
            font-size: 0.78rem; font-weight: 600; border: none; cursor: pointer;
            text-decoration: none; transition: opacity .15s; }
.btn-add  { background: #f97316; color: #fff; }
.btn-add:hover { opacity: .85; }
.btn-rem  { background: #3b1f00; color: #fb923c; }
.btn-rem:hover { opacity: .85; }
.btn-sec  { background: #1e3a5f; color: #60a5fa; }
.badge-in { position: absolute; top: 8px; right: 8px; background: #14532d;
            color: #4ade80; font-size: 0.7rem; font-weight: 700;
            padding: 2px 7px; border-radius: 20px; }
.search-bar { display: flex; gap: 10px; margin-bottom: 20px; }
.search-bar input { flex: 1; background: #1a1a24; border: 1px solid #2a2a3a;
                    border-radius: 8px; padding: 9px 14px; color: #e0e0e0;
                    font-size: 0.9rem; outline: none; }
.search-bar input:focus { border-color: #f97316; }
.tabs { display: flex; gap: 2px; margin-bottom: 20px; }
.tab { padding: 8px 20px; border-radius: 8px; cursor: pointer; font-size: 0.85rem;
       font-weight: 600; border: 1px solid #2a2a3a; background: #1a1a24; color: #888; }
.tab.active { background: #f97316; color: #fff; border-color: #f97316; }
.empty { text-align: center; padding: 60px; color: #444; font-size: 0.9rem; }
.toast { position: fixed; bottom: 24px; right: 24px; background: #1a1a24;
         border: 1px solid #2a2a3a; border-radius: 10px; padding: 12px 20px;
         font-size: 0.85rem; opacity: 0; transition: opacity .3s; z-index: 999; }
.toast.show { opacity: 1; }
table { width: 100%; border-collapse: collapse; background: #1a1a24;
        border-radius: 10px; overflow: hidden; }
th { text-align: left; padding: 11px 14px; font-size: 0.72rem;
     text-transform: uppercase; color: #555; border-bottom: 1px solid #2a2a3a; }
td { padding: 11px 14px; border-bottom: 1px solid #1e1e2e; font-size: 0.875rem; }
tr:last-child td { border-bottom: none; }
.pill { padding: 2px 9px; border-radius: 20px; font-size: 0.72rem; font-weight: 600; display: inline-block; }
.pill-ok  { background: #14532d; color: #4ade80; }
.pill-res { background: #1e3a5f; color: #60a5fa; }
.pill-err { background: #3b0000; color: #f87171; }
.pill-pend{ background: #2d2d00; color: #facc15; }
.pill-nf  { background: #3b1f00; color: #fb923c; }
"""

_NAV = lambda active: f"""
<nav>
  <a href="/library" class="{'active' if active=='library' else ''}">📚 Add to Library</a>
  <a href="/my-library" class="{'active' if active=='my-library' else ''}">🎬 My Library</a>
  <a href="/streams" class="{'active' if active=='streams' else ''}">⚡ Streams</a>
</nav>"""

_TOAST_JS = """
function toast(msg, ok=true) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.style.borderColor = ok ? '#4ade80' : '#f87171';
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3000);
}
"""


def _page(title: str, nav_active: str, body: str, extra_head: str = "") -> HTMLResponse:
    return HTMLResponse(f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{title} — Debridarr</title>
  <style>{_BASE_STYLE}</style>
  {extra_head}
</head>
<body>
  <header>
    <h1>🎬 Debridarr</h1><span class="ver">v0.3.0</span>
    {_NAV(nav_active)}
  </header>
  <main>{body}</main>
  <div id="toast" class="toast"></div>
  <script>{_TOAST_JS}</script>
</body>
</html>""")


# ─────────────────────────────────────────────────────────────────────────────
# / redirect
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def root():
    from fastapi.responses import RedirectResponse
    return RedirectResponse("/library")


# ─────────────────────────────────────────────────────────────────────────────
# /library — browse Sonarr/Radarr, add to fake library
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/library", response_class=HTMLResponse)
async def library_browse(request: Request, tab: str = "movies", q: str = ""):
    lm: LibraryManager = request.app.state.library
    db: CacheDB = request.app.state.db

    already_added = {
        (r["media_type"], r["title"], r["year"])
        for r in db.fake_library_list()
    }

    if tab == "movies":
        items = await lm.get_radarr_movies()
    else:
        items = await lm.get_sonarr_series()

    if q:
        ql = q.lower()
        items = [i for i in items if ql in i["title"].lower()]

    cards = ""
    for item in items:
        media_type = "movie" if tab == "movies" else "series"
        year = item.get("year")
        in_lib = (media_type, item["title"], year) in already_added
        poster = item.get("poster", "")
        img = f'<img src="{poster}" onerror="this.src=\'/static/no-poster.png\'" loading="lazy">' if poster else '<div style="aspect-ratio:2/3;background:#111"></div>'
        badge = '<span class="badge-in">✓ Added</span>' if in_lib else ""
        season_info = f"{item.get('season_count', 0)} seasons" if tab == "tv" else ""
        meta = f"{year or ''}" + (f" · {season_info}" if season_info else "")

        if in_lib:
            action_btn = f"""<button class="btn btn-rem" onclick="removeItem('{media_type}','{item['title'].replace("'","\\'") }',{year or 'null'})">Remove</button>"""
        else:
            sonarr_id = item.get("id", "") if tab == "tv" else ""
            radarr_id = item.get("id", "") if tab == "movies" else ""
            seasons_json = str(item.get("seasons", [])).replace("'", '"') if tab == "tv" else "[]"
            action_btn = f"""<button class="btn btn-add" onclick="addItem('{media_type}',{item.get('id','null')},'{item['title'].replace("'","\\'")}',{year or 'null'})">+ Add</button>"""

        cards += f"""
        <div class="card" id="card-{media_type}-{item.get('id','0')}">
          {badge}{img}
          <div class="info">
            <div class="title" title="{item['title']}">{item['title']}</div>
            <div class="meta">{meta}</div>
          </div>
          <div class="actions">{action_btn}</div>
        </div>"""

    if not cards:
        cards = f'<div class="empty">{"No results" if q else "Nothing in your Sonarr/Radarr library yet"}</div>'

    tab_movies = "active" if tab == "movies" else ""
    tab_tv = "active" if tab == "tv" else ""

    body = f"""
    <h2>Browse Library — pick what to add to Plex</h2>
    <div class="tabs">
      <div class="tab {tab_movies}" onclick="location.href='/library?tab=movies&q={q}'">🎬 Movies ({len(await lm.get_radarr_movies())})</div>
      <div class="tab {tab_tv}"     onclick="location.href='/library?tab=tv&q={q}'">📺 TV Shows ({len(await lm.get_sonarr_series())})</div>
    </div>
    <div class="search-bar">
      <input id="q" type="text" placeholder="Search..." value="{q}"
             onkeydown="if(event.key==='Enter') location.href='/library?tab={tab}&q='+encodeURIComponent(this.value)">
      <button class="btn btn-add" onclick="location.href='/library?tab={tab}&q='+encodeURIComponent(document.getElementById('q').value)">Search</button>
      {'<button class="btn btn-sec" onclick="location.href=\'/library?tab='+tab+'\'">Clear</button>' if q else ''}
    </div>
    <div class="card-grid">{cards}</div>"""

    extra = f"""<script>
const tab = '{tab}';
async function addItem(type, id, title, year) {{
  const res = await fetch('/api/library/add', {{
    method: 'POST',
    headers: {{'Content-Type':'application/json'}},
    body: JSON.stringify({{media_type: type, arr_id: id, title, year}})
  }});
  const data = await res.json();
  if (res.ok) {{ toast('✅ ' + title + ' added to library'); setTimeout(()=>location.reload(),1200); }}
  else {{ toast('❌ ' + (data.detail || 'Error'), false); }}
}}
async function removeItem(type, title, year) {{
  const res = await fetch('/api/library/remove', {{
    method: 'POST',
    headers: {{'Content-Type':'application/json'}},
    body: JSON.stringify({{media_type: type, title, year}})
  }});
  if (res.ok) {{ toast('🗑️ Removed'); setTimeout(()=>location.reload(),1200); }}
  else {{ toast('❌ Error removing', false); }}
}}
</script>"""

    return _page("Browse Library", "library", body, extra)


# ─────────────────────────────────────────────────────────────────────────────
# /my-library — view what's been added
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/my-library", response_class=HTMLResponse)
async def my_library(request: Request):
    db: CacheDB = request.app.state.db
    items = db.fake_library_list()
    movies = [i for i in items if i["media_type"] == "movie"]
    shows = [i for i in items if i["media_type"] == "series"]

    def section(title_str, rows, media_type):
        if not rows:
            return f"<h2>{title_str}</h2><div class='empty'>Nothing added yet</div>"
        trs = ""
        for r in rows:
            added = datetime.fromisoformat(r["added_at"]).strftime("%b %d, %Y")
            year = r.get("year") or "—"
            seasons = r.get("season_count") or "—"
            path = r.get("fake_path") or "—"
            extra = f"{seasons} seasons" if media_type == "series" else str(year)
            trs += f"""<tr>
              <td><strong>{r['title']}</strong></td>
              <td>{extra}</td>
              <td style="font-size:0.75rem;color:#555;font-family:monospace">{path}</td>
              <td>{added}</td>
              <td>
                <button class="btn btn-rem" onclick="removeItem('{media_type}','{r['title'].replace("'","\\'")}',{r.get('year') or 'null'})">Remove</button>
              </td>
            </tr>"""
        return f"""<h2>{title_str}</h2>
        <table style="margin-bottom:32px">
          <thead><tr><th>Title</th><th>Info</th><th>Path</th><th>Added</th><th></th></tr></thead>
          <tbody>{trs}</tbody>
        </table>"""

    body = f"""
    {section('🎬 Movies in Fake Library', movies, 'movie')}
    {section('📺 TV Shows in Fake Library', shows, 'series')}"""

    if not items:
        body = "<div class='empty'>Your fake library is empty.<br>Go to <a href='/library' style='color:#f97316'>Browse Library</a> to add titles.</div>"

    extra = """<script>
async function removeItem(type, title, year) {
  const res = await fetch('/api/library/remove', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({media_type: type, title, year})
  });
  if (res.ok) { toast('🗑️ Removed'); setTimeout(()=>location.reload(),1200); }
  else { toast('❌ Error removing', false); }
}
</script>"""

    return _page("My Library", "my-library", body, extra)


# ─────────────────────────────────────────────────────────────────────────────
# /streams — active resolved streams
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/streams", response_class=HTMLResponse)
async def streams_page(request: Request):
    db: CacheDB = request.app.state.db
    entries = db.list_all()

    def pill(s):
        cls = {"cached":"pill-ok","resolving":"pill-res","error":"pill-err",
               "not_found":"pill-nf"}.get(s,"pill-pend")
        return f'<span class="pill {cls}">{s}</span>'

    rows = ""
    for e in entries:
        expires = datetime.fromisoformat(e["expires_at"]).strftime("%Y-%m-%d")
        ep = ""
        if e.get("season"):
            ep = f"S{int(e['season']):02d}"
            if e.get("episode"):
                ep += f"E{int(e['episode']):02d}"
        rows += f"""<tr>
          <td>{e['media_type']}</td>
          <td><strong>{e['title']}</strong><br>
              <small style="color:#555;font-size:0.75rem">{e.get('torrent_name','')}</small></td>
          <td style="font-family:monospace">{ep}</td>
          <td>{e.get('quality','—')}</td>
          <td>{expires}</td>
          <td>{pill(e['status'])}</td>
          <td><button class="btn btn-rem" onclick="delEntry('{e['cache_key']}')">Del</button></td>
        </tr>"""

    table = f"""<table>
      <thead><tr><th>Type</th><th>Title</th><th>Ep</th><th>Quality</th><th>Expires</th><th>Status</th><th></th></tr></thead>
      <tbody>{rows}</tbody>
    </table>""" if entries else "<div class='empty'>No resolved streams yet. Play something in Plex.</div>"

    body = f"<h2>Resolved Streams</h2>{table}"
    extra = """<script>
async function delEntry(key) {
  await fetch('/cache/' + key, {method:'DELETE'});
  toast('🗑️ Deleted'); setTimeout(()=>location.reload(),1200);
}
</script>"""
    return _page("Streams", "streams", body, extra)


# ─────────────────────────────────────────────────────────────────────────────
# API — add / remove from fake library
# ─────────────────────────────────────────────────────────────────────────────
@app.post("/api/library/add")
async def api_library_add(request: Request, background_tasks: BackgroundTasks):
    body = await request.json()
    media_type = body.get("media_type")
    title = body.get("title", "").strip()
    year = body.get("year")
    arr_id = body.get("arr_id")

    if media_type not in ("movie", "series"):
        raise HTTPException(400, "media_type must be movie or series")
    if not title:
        raise HTTPException(400, "title required")

    lm: LibraryManager = request.app.state.library
    db: CacheDB = request.app.state.db

    background_tasks.add_task(_add_to_library, lm, db, media_type, arr_id, title, year)
    return {"status": "adding", "title": title}


@app.post("/api/library/remove")
async def api_library_remove(request: Request):
    body = await request.json()
    media_type = body.get("media_type")
    title = body.get("title", "").strip()
    year = body.get("year")

    lm: LibraryManager = request.app.state.library
    db: CacheDB = request.app.state.db

    # Remove fake files from disk
    if media_type == "movie":
        lm.remove_fake_movie(title, year)
    else:
        lm.remove_fake_series(title)

    db.fake_library_remove(media_type, title, year)
    return {"status": "removed", "title": title}


async def _add_to_library(
    lm: LibraryManager, db: CacheDB,
    media_type: str, arr_id: int, title: str, year: int
):
    """Background task: fetch episodes if TV, create fake files, record in DB."""
    try:
        if media_type == "movie":
            path = lm.create_fake_movie(title, year)
            db.fake_library_add({
                "media_type": "movie",
                "title": title,
                "year": year,
                "radarr_id": arr_id,
                "fake_path": str(path) if path else None,
            })
            log.info(f"🎬 Added movie to fake library: {title} ({year})")

        else:  # series
            series_list = await lm.get_sonarr_series()
            series = next((s for s in series_list if s["id"] == arr_id), None)
            if not series:
                log.error(f"Series id={arr_id} not found in Sonarr")
                return

            episodes = await lm.get_sonarr_episodes(arr_id)
            paths = lm.create_fake_episodes(title, year, series.get("seasons", []), episodes)

            db.fake_library_add({
                "media_type": "series",
                "title": title,
                "year": year,
                "sonarr_id": arr_id,
                "tvdb_id": series.get("tvdb_id"),
                "season_count": series.get("season_count", 0),
                "fake_path": str(Path(lm.plex_root) / "tv" / title) if lm.plex_root else None,
            })
            log.info(f"📺 Added series to fake library: {title} — {len(paths)} episodes")

    except Exception as e:
        log.error(f"Failed to add '{title}' to fake library: {e}", exc_info=True)


# ─────────────────────────────────────────────────────────────────────────────
# Tautulli webhook — fires on play, triggers real stream resolution
# ─────────────────────────────────────────────────────────────────────────────
@app.post("/webhook/tautulli")
async def tautulli_webhook(request: Request, background_tasks: BackgroundTasks):
    try:
        payload = await request.json()
    except Exception:
        payload = dict(await request.form())

    media_type = payload.get("media_type", "")
    title = payload.get("grandparent_title") or payload.get("title", "")
    year = payload.get("year") or payload.get("grandparent_year")
    season = payload.get("parent_media_index")
    episode = payload.get("media_index")

    log.info(f"📺 Play event: {media_type} '{title}' S{season}E{episode}")

    if media_type not in ("movie", "episode"):
        return {"status": "ignored"}

    event = PlayEvent(
        media_type=MediaType(media_type),
        title=title,
        year=int(year) if year else None,
        season=int(season) if season else None,
        episode=int(episode) if episode else None,
        rating_key=payload.get("rating_key"),
    )

    background_tasks.add_task(resolve_and_cache, request.app, event)
    return {"status": "accepted", "cache_key": event.cache_key()}


@app.post("/webhook/sonarr")
async def sonarr_webhook(request: Request):
    payload = await request.json()
    log.info(f"📡 Sonarr: {payload.get('eventType')}")
    request.app.state.library.invalidate_cache()
    return {"status": "ok"}


@app.post("/webhook/radarr")
async def radarr_webhook(request: Request):
    payload = await request.json()
    log.info(f"📡 Radarr: {payload.get('eventType')}")
    request.app.state.library.invalidate_cache()
    return {"status": "ok"}


# ─────────────────────────────────────────────────────────────────────────────
# Proxy — stable URL Plex always hits
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/proxy/{cache_key}")
async def stream_proxy(cache_key: str, request: Request):
    return await proxy_stream(request, cache_key, request.app.state.db, request.app.state.alldebrid)


# ─────────────────────────────────────────────────────────────────────────────
# Misc API
# ─────────────────────────────────────────────────────────────────────────────
@app.post("/resolve")
async def manual_resolve(request: Request, background_tasks: BackgroundTasks):
    body = await request.json()
    event = PlayEvent(
        media_type=MediaType(body["media_type"]),
        title=body["title"],
        year=body.get("year"),
        season=body.get("season"),
        episode=body.get("episode"),
    )
    background_tasks.add_task(resolve_and_cache, request.app, event)
    return {"status": "resolving", "cache_key": event.cache_key(),
            "proxy_url": f"{settings.DEBRIDARR_BASE_URL}/proxy/{event.cache_key()}"}


@app.get("/cache")
async def list_cache(request: Request):
    return request.app.state.db.list_all()


@app.delete("/cache/{cache_key}")
async def delete_cache_entry(cache_key: str, request: Request):
    db: CacheDB = request.app.state.db
    entry = db.get(cache_key)
    if entry and settings.PLEX_ROOT:
        delete_strm(cache_key=cache_key, title=entry["title"], year=entry.get("year"),
                    season=entry.get("season"), episode=entry.get("episode"),
                    media_type=entry["media_type"], plex_root=settings.PLEX_ROOT)
    db.delete(cache_key)
    return {"status": "deleted"}


@app.get("/health")
async def health():
    return {"status": "ok", "service": "debridarr", "version": "0.3.0"}


# ─────────────────────────────────────────────────────────────────────────────
# Resolution logic
# ─────────────────────────────────────────────────────────────────────────────
async def resolve_and_cache(app: FastAPI, event: PlayEvent):
    db: CacheDB = app.state.db
    alldebrid: AllDebridClient = app.state.alldebrid

    cache_key = event.cache_key()
    existing = db.get(cache_key)
    if existing and existing["status"] == "cached":
        log.info(f"✅ Cache hit: {cache_key}")
        return

    log.info(f"🔍 Resolving: {cache_key}")
    db.upsert(cache_key, event, status="resolving")

    try:
        if event.media_type == MediaType.movie:
            query = f"{event.title} {event.year or ''} 1080p".strip()
        else:
            s = f"S{event.season:02d}" if event.season else ""
            e = f"E{event.episode:02d}" if event.episode else ""
            query = f"{event.title} {s}{e} 1080p"

        results = await alldebrid.search_cached(query, media_type=event.media_type.value)
        if not results:
            log.warning(f"❌ No results: {query}")
            db.update_status(cache_key, "not_found")
            return

        best = results[0]
        stream_url = await alldebrid.unlock_magnet(best["magnet"])
        if not stream_url:
            db.update_status(cache_key, "unlock_failed")
            return

        strm_path = None
        if settings.PLEX_ROOT:
            p = write_strm(cache_key=cache_key, title=event.title, year=event.year,
                           season=event.season, episode=event.episode,
                           media_type=event.media_type.value,
                           debridarr_base_url=settings.DEBRIDARR_BASE_URL,
                           plex_root=settings.PLEX_ROOT)
            strm_path = str(p) if p else None

        db.update_cached(cache_key, best["magnet"], stream_url,
                         best["name"], best.get("quality", "1080p"), strm_path)
        log.info(f"✅ Resolved: {cache_key}")

    except Exception as e:
        log.error(f"❌ Resolution failed for {cache_key}: {e}", exc_info=True)
        db.update_status(cache_key, "error")


# needed for _add_to_library
from pathlib import Path
