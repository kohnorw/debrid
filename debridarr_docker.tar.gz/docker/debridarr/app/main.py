"""
Debridarr - On-the-fly AllDebrid streaming for Plex

Flow:
  1. First run → setup wizard at /setup collects all config, tests live connections,
     writes /data/.env, reinitialises app without restart.
  2. User opens /library → browses Sonarr/Radarr → clicks Add → zero-byte .mkv created
  3. Plex scans the fake library, shows titles normally
  4. User hits Play → Tautulli webhook → Debridarr resolves real stream via AllDebrid
  5. /proxy/<key> streams bytes transparently, refreshing AllDebrid URLs as needed
"""

import asyncio
import importlib
import logging
import sys
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from app.alldebrid import AllDebridClient
from app.cache import CacheDB
from app.config import settings
from app.library import LibraryManager
from app.models import MediaType, PlayEvent
from app.proxy import proxy_stream, write_strm, delete_strm
from app.setup import (
    is_setup_complete, mark_setup_complete,
    load_saved_config, write_env,
    test_alldebrid, test_sonarr, test_radarr, test_plex_root,
)

logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("debridarr")


def _init_clients(app: FastAPI):
    """Initialise (or re-initialise) AllDebrid + Library clients from current settings."""
    # Re-read settings from env (which may have just been written by setup wizard)
    import importlib
    import app.config as cfg_module
    importlib.reload(cfg_module)
    from app.config import settings as s

    app.state.alldebrid = AllDebridClient(s.ALLDEBRID_API_KEY)
    app.state.library = LibraryManager(
        sonarr_url=s.SONARR_URL,
        sonarr_key=s.SONARR_API_KEY,
        radarr_url=s.RADARR_URL,
        radarr_key=s.RADARR_API_KEY,
        plex_root=s.PLEX_ROOT,
    )
    app.state.settings = s


@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info("🚀 Debridarr starting up...")
    db = CacheDB(settings.DB_PATH)
    db.init()
    app.state.db = db
    app.state.setup_complete = is_setup_complete()

    if app.state.setup_complete:
        _init_clients(app)
        log.info(f"✅ Debridarr ready  plex_root={settings.PLEX_ROOT or 'NOT SET'}")
    else:
        log.info("⚙️  First run — setup wizard active at http://localhost:7474/setup")
        app.state.alldebrid = None
        app.state.library = None
        app.state.settings = settings

    async def cleanup_loop():
        while True:
            await asyncio.sleep(3600)
            if not app.state.setup_complete:
                continue
            s = app.state.settings
            expired = db.list_expired()
            for entry in expired:
                delete_strm(
                    cache_key=entry["cache_key"], title=entry["title"],
                    year=entry.get("year"), season=entry.get("season"),
                    episode=entry.get("episode"), media_type=entry["media_type"],
                    plex_root=s.PLEX_ROOT,
                )
            purged = db.purge_expired()
            if purged:
                log.info(f"🗑️  Purged {purged} expired entries")

    asyncio.create_task(cleanup_loop())
    yield


app = FastAPI(title="Debridarr", version="0.4.0", lifespan=lifespan)

# ── Setup guard — simple helper, no middleware ────────────────────────────────
def _needs_setup(request: Request) -> bool:
    """Return True if setup has not been completed."""
    return not getattr(request.app.state, "setup_complete", False)

def _setup_redirect():
    return RedirectResponse("/setup", status_code=302)


# ─────────────────────────────────────────────────────────────────────────────
# Shared styles
# ─────────────────────────────────────────────────────────────────────────────
_BASE_STYLE = """
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
       background: #0f0f13; color: #e0e0e0; min-height: 100vh; }
header { background: #1a1a24; border-bottom: 1px solid #2a2a3a;
         padding: 14px 28px; display: flex; align-items: center; gap: 16px; }
header h1 { font-size: 1.3rem; color: #fff; }
header .ver { font-size: 0.75rem; background: #f97316; color: #fff;
              border-radius: 4px; padding: 2px 8px; }
nav { display: flex; gap: 4px; margin-left: auto; }
nav a { color: #aaa; text-decoration: none; padding: 6px 14px; border-radius: 6px;
        font-size: 0.85rem; transition: background .15s; }
nav a:hover, nav a.active { background: #2a2a3a; color: #fff; }
main { padding: 28px; max-width: 1400px; margin: 0 auto; }
h2 { font-size: 1.05rem; color: #ccc; margin-bottom: 18px; }
.card-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 16px; }
.card { background: #1a1a24; border: 1px solid #2a2a3a; border-radius: 10px; overflow: hidden; position: relative; }
.card img { width: 100%; aspect-ratio: 2/3; object-fit: cover; background: #111; display: block; }
.card .info { padding: 10px 12px; }
.card .title { font-size: 0.88rem; font-weight: 600; color: #e0e0e0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.card .meta  { font-size: 0.75rem; color: #666; margin-top: 2px; }
.card .actions { padding: 0 12px 12px; display: flex; gap: 6px; }
.btn { display: inline-block; padding: 5px 12px; border-radius: 6px; font-size: 0.78rem;
       font-weight: 600; border: none; cursor: pointer; text-decoration: none; transition: opacity .15s; }
.btn-add  { background: #f97316; color: #fff; }
.btn-add:hover { opacity: .85; }
.btn-rem  { background: #3b1f00; color: #fb923c; }
.btn-sec  { background: #1e3a5f; color: #60a5fa; }
.badge-in { position: absolute; top: 8px; right: 8px; background: #14532d;
            color: #4ade80; font-size: 0.7rem; font-weight: 700; padding: 2px 7px; border-radius: 20px; }
.search-bar { display: flex; gap: 10px; margin-bottom: 20px; }
.search-bar input { flex: 1; background: #1a1a24; border: 1px solid #2a2a3a;
                    border-radius: 8px; padding: 9px 14px; color: #e0e0e0; font-size: 0.9rem; outline: none; }
.search-bar input:focus { border-color: #f97316; }
.tabs { display: flex; gap: 2px; margin-bottom: 20px; }
.tab { padding: 8px 20px; border-radius: 8px; cursor: pointer; font-size: 0.85rem;
       font-weight: 600; border: 1px solid #2a2a3a; background: #1a1a24; color: #888; }
.tab.active { background: #f97316; color: #fff; border-color: #f97316; }
.empty { text-align: center; padding: 60px; color: #444; font-size: 0.9rem; }
.toast { position: fixed; bottom: 24px; right: 24px; background: #1a1a24; border: 1px solid #2a2a3a;
         border-radius: 10px; padding: 12px 20px; font-size: 0.85rem; opacity: 0; transition: opacity .3s; z-index: 999; }
.toast.show { opacity: 1; }
table { width: 100%; border-collapse: collapse; background: #1a1a24; border-radius: 10px; overflow: hidden; }
th { text-align: left; padding: 11px 14px; font-size: 0.72rem; text-transform: uppercase;
     color: #555; border-bottom: 1px solid #2a2a3a; }
td { padding: 11px 14px; border-bottom: 1px solid #1e1e2e; font-size: 0.875rem; }
tr:last-child td { border-bottom: none; }
.pill { padding: 2px 9px; border-radius: 20px; font-size: 0.72rem; font-weight: 600; display: inline-block; }
.pill-ok   { background: #14532d; color: #4ade80; }
.pill-res  { background: #1e3a5f; color: #60a5fa; }
.pill-err  { background: #3b0000; color: #f87171; }
.pill-pend { background: #2d2d00; color: #facc15; }
.pill-nf   { background: #3b1f00; color: #fb923c; }
"""

_NAV = lambda active: f"""
<nav>
  <a href="/library"    class="{'active' if active=='library'    else ''}">📚 Add to Library</a>
  <a href="/my-library" class="{'active' if active=='my-library' else ''}">🎬 My Library</a>
  <a href="/streams"    class="{'active' if active=='streams'    else ''}">⚡ Streams</a>
  <a href="/setup"      class="{'active' if active=='setup'      else ''}">⚙️ Setup</a>
</nav>"""

_TOAST_JS = """
function toast(msg, ok=true) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.style.borderColor = ok ? '#4ade80' : '#f87171';
  t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 3500);
}"""

def _page(title: str, nav_active: str, body: str, extra_head: str = "") -> HTMLResponse:
    return HTMLResponse(f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>{title} — Debridarr</title>
  <style>{_BASE_STYLE}</style>{extra_head}
</head>
<body>
  <header>
    <h1>🎬 Debridarr</h1><span class="ver">v0.4.0</span>
    {_NAV(nav_active)}
  </header>
  <main>{body}</main>
  <div id="toast" class="toast"></div>
  <script>{_TOAST_JS}</script>
</body>
</html>""")


# ─────────────────────────────────────────────────────────────────────────────
# Setup wizard styles (standalone, no nav)
# ─────────────────────────────────────────────────────────────────────────────
_SETUP_STYLE = _BASE_STYLE + """
.wizard { max-width: 620px; margin: 60px auto; }
.wizard-card { background: #1a1a24; border: 1px solid #2a2a3a; border-radius: 14px; padding: 36px; }
.wizard h2 { font-size: 1.4rem; color: #fff; margin-bottom: 6px; }
.wizard .sub { color: #666; font-size: 0.88rem; margin-bottom: 28px; line-height: 1.5; }
.steps { display: flex; gap: 0; margin-bottom: 32px; }
.step { flex: 1; text-align: center; font-size: 0.7rem; color: #444; padding-bottom: 8px;
        border-bottom: 2px solid #2a2a3a; position: relative; }
.step.done  { color: #4ade80; border-color: #4ade80; }
.step.active{ color: #f97316; border-color: #f97316; font-weight: 700; }
.field { margin-bottom: 20px; }
.field label { display: block; font-size: 0.8rem; color: #888; margin-bottom: 6px; font-weight: 600; }
.field input { width: 100%; background: #0f0f13; border: 1px solid #2a2a3a; border-radius: 8px;
               padding: 10px 14px; color: #e0e0e0; font-size: 0.9rem; outline: none;
               font-family: monospace; }
.field input:focus { border-color: #f97316; }
.field .hint { font-size: 0.75rem; color: #555; margin-top: 5px; line-height: 1.4; }
.field .hint a { color: #f97316; }
.test-result { margin-top: 10px; padding: 8px 12px; border-radius: 6px; font-size: 0.82rem;
               display: none; }
.test-result.ok  { background: #14532d; color: #4ade80; display: block; }
.test-result.err { background: #3b0000; color: #f87171; display: block; }
.test-result.testing { background: #1e1e2e; color: #aaa; display: block; }
.row { display: flex; gap: 10px; }
.row .field { flex: 1; }
.actions { display: flex; gap: 10px; margin-top: 28px; justify-content: flex-end; }
.btn-primary { background: #f97316; color: #fff; padding: 10px 24px; border-radius: 8px;
               font-size: 0.9rem; font-weight: 600; border: none; cursor: pointer; }
.btn-primary:hover { opacity: .85; }
.btn-primary:disabled { opacity: .4; cursor: not-allowed; }
.btn-ghost { background: transparent; color: #666; padding: 10px 16px; border-radius: 8px;
             font-size: 0.9rem; border: 1px solid #2a2a3a; cursor: pointer; }
.btn-ghost:hover { color: #ccc; border-color: #444; }
.welcome-icon { font-size: 4rem; text-align: center; margin-bottom: 20px; }
.confirm-row { display: flex; justify-content: space-between; padding: 10px 0;
               border-bottom: 1px solid #1e1e2e; font-size: 0.875rem; }
.confirm-row:last-child { border-bottom: none; }
.confirm-row .lbl { color: #666; }
.confirm-row .val { color: #e0e0e0; font-family: monospace; font-size: 0.82rem; }
"""

def _setup_page(body: str, step: str) -> HTMLResponse:
    step_names = ["Welcome", "AllDebrid", "Sonarr", "Radarr", "Plex Path", "Confirm"]
    step_keys  = ["welcome", "alldebrid", "sonarr", "radarr", "plex", "confirm"]
    idx = step_keys.index(step) if step in step_keys else 0
    steps_html = "".join(
        f'<div class="step {"done" if i < idx else "active" if i == idx else ""}">{n}</div>'
        for i, n in enumerate(step_names)
    )
    return HTMLResponse(f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Debridarr Setup</title>
  <style>{_SETUP_STYLE}</style>
</head>
<body>
  <header>
    <h1>🎬 Debridarr</h1><span class="ver">v0.4.0</span>
    <span style="margin-left:auto;color:#555;font-size:0.8rem">First-run setup</span>
  </header>
  <div class="wizard">
    <div class="steps">{steps_html}</div>
    <div class="wizard-card">{body}</div>
  </div>
  <div id="toast" class="toast"></div>
  <script>{_TOAST_JS}</script>
</body>
</html>""")


# ─────────────────────────────────────────────────────────────────────────────
# Setup wizard pages
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/setup", response_class=HTMLResponse)
async def setup_get(request: Request, step: str = "welcome"):
    try:
        cfg = load_saved_config()
    except Exception:
        cfg = {}

    if step == "welcome":
        body = """
        <div class="welcome-icon">🎬</div>
        <h2>Welcome to Debridarr</h2>
        <p class="sub">This wizard will connect Debridarr to AllDebrid, Sonarr, and Radarr.
        It takes about 2 minutes. All settings are tested live before saving.</p>
        <div class="actions">
          <a href="/setup?step=alldebrid" class="btn-primary" style="text-decoration:none;display:inline-block;padding:10px 24px">Get Started →</a>
        </div>"""
        return _setup_page(body, "welcome")

    if step == "alldebrid":
        val = cfg.get("ALLDEBRID_API_KEY", "")
        body = f"""
        <h2>AllDebrid</h2>
        <p class="sub">Debridarr uses AllDebrid to find and stream cached torrents instantly.</p>
        <div class="field">
          <label>API Key</label>
          <input id="api_key" type="password" value="{val}" placeholder="Paste your AllDebrid API key">
          <div class="hint">Get yours at <a href="https://alldebrid.com/apikeys" target="_blank">alldebrid.com/apikeys</a> → Create a key → Copy it here.</div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="actions">
          <a href="/setup?step=welcome" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="test-btn" onclick="testAndNext()">Test & Continue →</button>
        </div>
        <script>
        async function testAndNext() {{
          const key = document.getElementById('api_key').value.trim();
          const res = document.getElementById('test-result');
          const btn = document.getElementById('test-btn');
          if (!key) {{ res.className='test-result err'; res.textContent='API key required'; return; }}
          res.className='test-result testing'; res.textContent='Testing connection...';
          btn.disabled = true;
          const r = await fetch('/setup/test', {{
            method:'POST', headers:{{'Content-Type':'application/json'}},
            body: JSON.stringify({{step:'alldebrid', api_key: key}})
          }});
          const d = await r.json();
          btn.disabled = false;
          if (d.ok) {{
            res.className='test-result ok'; res.textContent='✅ ' + d.message;
            setTimeout(() => window.location='/setup?step=sonarr&alldebrid_key=' + encodeURIComponent(key), 800);
          }} else {{
            res.className='test-result err'; res.textContent='❌ ' + d.message;
          }}
        }}
        document.getElementById('api_key').addEventListener('keydown', e => {{ if(e.key==='Enter') testAndNext(); }});
        </script>"""
        return _setup_page(body, "alldebrid")

    if step == "sonarr":
        url_val = cfg.get("SONARR_URL", "http://192.168.1.x:8989")
        key_val = cfg.get("SONARR_API_KEY", "")
        alldebrid_key = request.query_params.get("alldebrid_key", cfg.get("ALLDEBRID_API_KEY",""))
        body = f"""
        <h2>Sonarr</h2>
        <p class="sub">Connect to your existing Sonarr instance so Debridarr can browse your TV library.</p>
        <div class="row">
          <div class="field">
            <label>Sonarr URL</label>
            <input id="sonarr_url" type="text" value="{url_val}" placeholder="http://192.168.1.x:8989">
            <div class="hint">Use the LAN IP of the machine running Sonarr.</div>
          </div>
        </div>
        <div class="field">
          <label>API Key</label>
          <input id="sonarr_key" type="password" value="{key_val}" placeholder="Sonarr API key">
          <div class="hint">Sonarr → Settings → General → Security → API Key</div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="actions">
          <a href="/setup?step=alldebrid" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="test-btn" onclick="testAndNext()">Test & Continue →</button>
        </div>
        <input type="hidden" id="alldebrid_key" value="{alldebrid_key}">
        <script>
        async function testAndNext() {{
          const url = document.getElementById('sonarr_url').value.trim();
          const key = document.getElementById('sonarr_key').value.trim();
          const akey = document.getElementById('alldebrid_key').value;
          const res = document.getElementById('test-result');
          const btn = document.getElementById('test-btn');
          res.className='test-result testing'; res.textContent='Testing connection...';
          btn.disabled = true;
          const r = await fetch('/setup/test', {{
            method:'POST', headers:{{'Content-Type':'application/json'}},
            body: JSON.stringify({{step:'sonarr', url, api_key: key}})
          }});
          const d = await r.json();
          btn.disabled = false;
          if (d.ok) {{
            res.className='test-result ok'; res.textContent='✅ ' + d.message;
            setTimeout(() => window.location='/setup?step=radarr&alldebrid_key='+encodeURIComponent(akey)+'&sonarr_url='+encodeURIComponent(url)+'&sonarr_key='+encodeURIComponent(key), 800);
          }} else {{
            res.className='test-result err'; res.textContent='❌ ' + d.message;
          }}
        }}
        </script>"""
        return _setup_page(body, "sonarr")

    if step == "radarr":
        url_val = cfg.get("RADARR_URL", "http://192.168.1.x:7878")
        key_val = cfg.get("RADARR_API_KEY", "")
        qs = dict(request.query_params)
        hidden = "".join(f'<input type="hidden" id="{k}" value="{v}">' for k, v in qs.items())
        body = f"""
        <h2>Radarr</h2>
        <p class="sub">Connect to your existing Radarr instance for your movie library.</p>
        <div class="field">
          <label>Radarr URL</label>
          <input id="radarr_url" type="text" value="{url_val}" placeholder="http://192.168.1.x:7878">
          <div class="hint">Use the LAN IP of the machine running Radarr.</div>
        </div>
        <div class="field">
          <label>API Key</label>
          <input id="radarr_key" type="password" value="{key_val}" placeholder="Radarr API key">
          <div class="hint">Radarr → Settings → General → Security → API Key</div>
          <div id="test-result" class="test-result"></div>
        </div>
        {hidden}
        <div class="actions">
          <a href="/setup?step=sonarr" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="test-btn" onclick="testAndNext()">Test & Continue →</button>
        </div>
        <script>
        async function testAndNext() {{
          const url = document.getElementById('radarr_url').value.trim();
          const key = document.getElementById('radarr_key').value.trim();
          const res = document.getElementById('test-result');
          const btn = document.getElementById('test-btn');
          res.className='test-result testing'; res.textContent='Testing connection...';
          btn.disabled = true;
          const r = await fetch('/setup/test', {{
            method:'POST', headers:{{'Content-Type':'application/json'}},
            body: JSON.stringify({{step:'radarr', url, api_key: key}})
          }});
          const d = await r.json();
          btn.disabled = false;
          if (d.ok) {{
            res.className='test-result ok'; res.textContent='✅ ' + d.message;
            const prev = {{}};
            document.querySelectorAll('input[type=hidden]').forEach(i => prev[i.id]=i.value);
            const params = new URLSearchParams({{...prev, step:'plex', radarr_url:url, radarr_key:key}});
            setTimeout(() => window.location='/setup?' + params.toString(), 800);
          }} else {{
            res.className='test-result err'; res.textContent='❌ ' + d.message;
          }}
        }}
        </script>"""
        return _setup_page(body, "radarr")

    if step == "plex":
        qs = dict(request.query_params)
        hidden = "".join(f'<input type="hidden" id="{k}" value="{v}">' for k, v in qs.items() if k != "step")
        tz_val = cfg.get("TZ", "America/Edmonton")
        puid_val = cfg.get("PUID", "1000")
        pgid_val = cfg.get("PGID", "1000")
        base_url_val = cfg.get("DEBRIDARR_BASE_URL", "http://192.168.1.x:7474")
        body = f"""
        <h2>Plex Integration</h2>
        <p class="sub">Tell Debridarr where to write fake library files, and how Plex reaches it over the network.</p>
        <div class="field">
          <label>Plex Library Path <span style="color:#555">(inside this container)</span></label>
          <input id="plex_root" type="text" value="/plex-strm" placeholder="/plex-strm">
          <div class="hint">This must be bind-mounted into both Debridarr and Plex. The default <code>/plex-strm</code> matches the docker-compose volume.</div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="field">
          <label>Debridarr Base URL <span style="color:#555">(as seen by Plex)</span></label>
          <input id="base_url" type="text" value="{base_url_val}" placeholder="http://192.168.1.x:7474">
          <div class="hint">Written into every .strm file. Plex must be able to reach this address. Use your server's LAN IP.</div>
        </div>
        <div class="row">
          <div class="field">
            <label>Timezone</label>
            <input id="tz" type="text" value="{tz_val}" placeholder="America/Edmonton">
            <div class="hint"><a href="https://en.wikipedia.org/wiki/List_of_tz_database_time_zones" target="_blank">TZ list</a></div>
          </div>
          <div class="field">
            <label>PUID</label>
            <input id="puid" type="text" value="{puid_val}" placeholder="1000">
            <div class="hint">Run: <code>id -u</code></div>
          </div>
          <div class="field">
            <label>PGID</label>
            <input id="pgid" type="text" value="{pgid_val}" placeholder="1000">
            <div class="hint">Run: <code>id -g</code></div>
          </div>
        </div>
        {hidden}
        <div class="actions">
          <a href="/setup?step=radarr" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="test-btn" onclick="testAndNext()">Test & Continue →</button>
        </div>
        <script>
        async function testAndNext() {{
          const plex_root = document.getElementById('plex_root').value.trim();
          const res = document.getElementById('test-result');
          const btn = document.getElementById('test-btn');
          res.className='test-result testing'; res.textContent='Checking path is writable...';
          btn.disabled = true;
          const r = await fetch('/setup/test', {{
            method:'POST', headers:{{'Content-Type':'application/json'}},
            body: JSON.stringify({{step:'plex', plex_root}})
          }});
          const d = await r.json();
          btn.disabled = false;
          if (d.ok) {{
            res.className='test-result ok'; res.textContent='✅ ' + d.message;
            const prev = {{}};
            document.querySelectorAll('input[type=hidden]').forEach(i => prev[i.id]=i.value);
            const params = new URLSearchParams({{
              ...prev, step:'confirm',
              plex_root, base_url: document.getElementById('base_url').value.trim(),
              tz: document.getElementById('tz').value.trim(),
              puid: document.getElementById('puid').value.trim(),
              pgid: document.getElementById('pgid').value.trim(),
            }});
            setTimeout(() => window.location='/setup?' + params.toString(), 800);
          }} else {{
            res.className='test-result err'; res.textContent='❌ ' + d.message;
          }}
        }}
        </script>"""
        return _setup_page(body, "plex")

    if step == "confirm":
        qs = dict(request.query_params)
        def row(label, key, mask=False):
            val = qs.get(key, "—")
            display = ("*" * 8 + val[-4:]) if mask and val and val != "—" else val
            return f'<div class="confirm-row"><span class="lbl">{label}</span><span class="val">{display}</span></div>'

        hidden = "".join(f'<input type="hidden" name="{k}" value="{v}">' for k, v in qs.items() if k != "step")
        body = f"""
        <h2>Confirm & Save</h2>
        <p class="sub">Everything looks good. Review your settings and click Save to finish setup.</p>
        <div style="margin-bottom:24px">
          {row("AllDebrid API Key", "alldebrid_key", mask=True)}
          {row("Sonarr URL", "sonarr_url")}
          {row("Sonarr API Key", "sonarr_key", mask=True)}
          {row("Radarr URL", "radarr_url")}
          {row("Radarr API Key", "radarr_key", mask=True)}
          {row("Plex Library Path", "plex_root")}
          {row("Debridarr Base URL", "base_url")}
          {row("Timezone", "tz")}
          {row("PUID / PGID", "puid")} 
        </div>
        <form method="POST" action="/setup/save">
          {hidden}
          <div class="actions">
            <a href="/setup?step=plex" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
            <button type="submit" class="btn-primary">💾 Save & Finish</button>
          </div>
        </form>"""
        return _setup_page(body, "confirm")

    return RedirectResponse("/setup")


# ── Setup: live test endpoint ─────────────────────────────────────────────────
@app.post("/setup/test")
async def setup_test(request: Request):
    body = await request.json()
    step = body.get("step")

    if step == "alldebrid":
        ok, msg = await test_alldebrid(body.get("api_key", ""))
    elif step == "sonarr":
        ok, msg = await test_sonarr(body.get("url", ""), body.get("api_key", ""))
    elif step == "radarr":
        ok, msg = await test_radarr(body.get("url", ""), body.get("api_key", ""))
    elif step == "plex":
        ok, msg = await test_plex_root(body.get("plex_root", ""))
    else:
        ok, msg = False, "Unknown step"

    return JSONResponse({"ok": ok, "message": msg})


# ── Setup: save config and finish ─────────────────────────────────────────────
@app.post("/setup/save")
async def setup_save(request: Request):
    form = dict(await request.form())

    config = {
        "ALLDEBRID_API_KEY": form.get("alldebrid_key", ""),
        "SONARR_URL":        form.get("sonarr_url", ""),
        "SONARR_API_KEY":    form.get("sonarr_key", ""),
        "RADARR_URL":        form.get("radarr_url", ""),
        "RADARR_API_KEY":    form.get("radarr_key", ""),
        "DEBRIDARR_BASE_URL":form.get("base_url", "http://debridarr:7474"),
        "TZ":                form.get("tz", "America/Edmonton"),
        "PUID":              form.get("puid", "1000"),
        "PGID":              form.get("pgid", "1000"),
    }

    # Write /data/.env
    write_env(config)

    # Push new values into the running process environment
    import os
    for k, v in config.items():
        os.environ[k] = v
    # PLEX_ROOT is fixed to /plex-strm inside the container
    os.environ["PLEX_ROOT"] = form.get("plex_root", "/plex-strm")

    # Reinitialise clients without restart
    _init_clients(request.app)
    request.app.state.setup_complete = True
    mark_setup_complete()

    log.info("✅ Setup complete — config saved, clients reinitialised")

    return HTMLResponse(f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta http-equiv="refresh" content="3;url=/library">
  <title>Setup Complete</title>
  <style>{_SETUP_STYLE}</style>
</head>
<body>
  <header><h1>🎬 Debridarr</h1><span class="ver">v0.4.0</span></header>
  <div class="wizard">
    <div class="wizard-card" style="text-align:center;padding:48px">
      <div style="font-size:3rem;margin-bottom:16px">🎉</div>
      <h2 style="color:#4ade80;margin-bottom:12px">Setup Complete!</h2>
      <p style="color:#888;margin-bottom:24px">Your config has been saved. Redirecting to the library browser...</p>
      <a href="/library" style="color:#f97316">Click here if not redirected</a>
    </div>
  </div>
</body>
</html>""")


# ─────────────────────────────────────────────────────────────────────────────
# / redirect
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    if _needs_setup(request):
        return _setup_redirect()
    return RedirectResponse("/library")


# ─────────────────────────────────────────────────────────────────────────────
# /library — browse Sonarr/Radarr, add to fake library
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/library", response_class=HTMLResponse)
async def library_browse(request: Request, tab: str = "movies", q: str = ""):
    if _needs_setup(request):
        return _setup_redirect()
    lm: LibraryManager = request.app.state.library
    db: CacheDB = request.app.state.db

    already_added = {
        (r["media_type"], r["title"], r["year"])
        for r in db.fake_library_list()
    }

    if tab == "movies":
        items = await lm.get_radarr_movies()
    else:
        items = await lm.get_sonarr_series()

    if q:
        ql = q.lower()
        items = [i for i in items if ql in i["title"].lower()]

    cards = ""
    for item in items:
        media_type = "movie" if tab == "movies" else "series"
        year = item.get("year")
        in_lib = (media_type, item["title"], year) in already_added
        poster = item.get("poster", "")
        img = f'<img src="{poster}" onerror="this.style.display=\'none\'" loading="lazy">' if poster else '<div style="aspect-ratio:2/3;background:#111"></div>'
        badge = '<span class="badge-in">✓ Added</span>' if in_lib else ""
        season_info = f"{item.get('season_count', 0)} seasons" if tab == "tv" else ""
        meta = f"{year or ''}" + (f" · {season_info}" if season_info else "")
        safe_title = item['title'].replace("'", "\\'").replace('"', '&quot;')

        if in_lib:
            action = f"""<button class="btn btn-rem" onclick="removeItem('{media_type}','{safe_title}',{year or 'null'})">Remove</button>"""
        else:
            action = f"""<button class="btn btn-add" onclick="addItem('{media_type}',{item.get('id','null')},'{safe_title}',{year or 'null'})">+ Add</button>"""

        cards += f"""
        <div class="card">
          {badge}{img}
          <div class="info">
            <div class="title" title="{item['title']}">{item['title']}</div>
            <div class="meta">{meta}</div>
          </div>
          <div class="actions">{action}</div>
        </div>"""

    if not cards:
        cards = f'<div class="empty">{"No results for &quot;"+q+"&quot;" if q else "Nothing in your Sonarr/Radarr library"}</div>'

    movie_count = len(await lm.get_radarr_movies())
    tv_count = len(await lm.get_sonarr_series())
    tab_movies = "active" if tab == "movies" else ""
    tab_tv = "active" if tab == "tv" else ""

    body = f"""
    <h2>Browse Library</h2>
    <div class="tabs">
      <div class="tab {tab_movies}" onclick="location.href='/library?tab=movies&q={q}'">🎬 Movies ({movie_count})</div>
      <div class="tab {tab_tv}"     onclick="location.href='/library?tab=tv&q={q}'">📺 TV Shows ({tv_count})</div>
    </div>
    <div class="search-bar">
      <input id="q" type="text" placeholder="Search..." value="{q}"
             onkeydown="if(event.key==='Enter')location.href='/library?tab={tab}&q='+encodeURIComponent(this.value)">
      <button class="btn btn-add" onclick="location.href='/library?tab={tab}&q='+encodeURIComponent(document.getElementById('q').value)">Search</button>
      {'<button class="btn btn-sec" onclick="location.href=\'/library?tab='+tab+'\'">Clear</button>' if q else ''}
    </div>
    <div class="card-grid">{cards}</div>"""

    extra = f"""<script>
async function addItem(type, id, title, year) {{
  const r = await fetch('/api/library/add', {{method:'POST',headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{media_type:type,arr_id:id,title,year}})}});
  const d = await r.json();
  if (r.ok) {{ toast('✅ ' + title + ' added'); setTimeout(()=>location.reload(),1200); }}
  else {{ toast('❌ ' + (d.detail||'Error'), false); }}
}}
async function removeItem(type, title, year) {{
  const r = await fetch('/api/library/remove',{{method:'POST',headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{media_type:type,title,year}})}});
  if (r.ok) {{ toast('🗑️ Removed'); setTimeout(()=>location.reload(),1200); }}
  else {{ toast('❌ Error', false); }}
}}
</script>"""
    return _page("Browse Library", "library", body, extra)


# ─────────────────────────────────────────────────────────────────────────────
# /my-library
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/my-library", response_class=HTMLResponse)
async def my_library(request: Request):
    if _needs_setup(request):
        return _setup_redirect()
    db: CacheDB = request.app.state.db
    items = db.fake_library_list()
    movies = [i for i in items if i["media_type"] == "movie"]
    shows  = [i for i in items if i["media_type"] == "series"]

    def section(title_str, rows, media_type):
        if not rows:
            return f"<h2>{title_str}</h2><div class='empty' style='padding:24px'>Nothing added yet</div>"
        trs = ""
        for r in rows:
            added = datetime.fromisoformat(r["added_at"]).strftime("%b %d, %Y")
            extra = f"{r.get('season_count') or '—'} seasons" if media_type == "series" else str(r.get("year") or "—")
            path = r.get("fake_path") or "—"
            safe = r['title'].replace("'","\\'")
            trs += f"""<tr>
              <td><strong>{r['title']}</strong></td><td>{extra}</td>
              <td style="font-size:0.75rem;color:#555;font-family:monospace">{path}</td>
              <td>{added}</td>
              <td><button class="btn btn-rem" onclick="rem('{media_type}','{safe}',{r.get('year') or 'null'})">Remove</button></td>
            </tr>"""
        return f"""<h2>{title_str}</h2>
        <table style="margin-bottom:32px">
          <thead><tr><th>Title</th><th>Info</th><th>Path</th><th>Added</th><th></th></tr></thead>
          <tbody>{trs}</tbody>
        </table>"""

    body = section("🎬 Movies", movies, "movie") + section("📺 TV Shows", shows, "series")
    if not items:
        body = "<div class='empty'>Your library is empty. <a href='/library' style='color:#f97316'>Browse Library</a> to add titles.</div>"

    extra = """<script>
async function rem(type, title, year) {
  const r = await fetch('/api/library/remove',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({media_type:type,title,year})});
  if (r.ok){toast('🗑️ Removed');setTimeout(()=>location.reload(),1200);}
  else{toast('❌ Error',false);}
}
</script>"""
    return _page("My Library", "my-library", body, extra)


# ─────────────────────────────────────────────────────────────────────────────
# /streams
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/streams", response_class=HTMLResponse)
async def streams_page(request: Request):
    if _needs_setup(request):
        return _setup_redirect()
    db: CacheDB = request.app.state.db
    entries = db.list_all()

    def pill(s):
        cls = {"cached":"pill-ok","resolving":"pill-res","error":"pill-err","not_found":"pill-nf"}.get(s,"pill-pend")
        return f'<span class="pill {cls}">{s}</span>'

    rows = "".join(f"""<tr>
      <td>{e['media_type']}</td>
      <td><strong>{e['title']}</strong><br><small style="color:#555">{e.get('torrent_name','')}</small></td>
      <td style="font-family:monospace">{'S'+str(e['season']).zfill(2) if e.get('season') else ''}{'E'+str(e['episode']).zfill(2) if e.get('episode') else ''}</td>
      <td>{e.get('quality','—')}</td>
      <td>{datetime.fromisoformat(e['expires_at']).strftime('%Y-%m-%d')}</td>
      <td>{pill(e['status'])}</td>
      <td><button class="btn btn-rem" onclick="del_('{e['cache_key']}')">Del</button></td>
    </tr>""" for e in entries)

    table = f'<table><thead><tr><th>Type</th><th>Title</th><th>Ep</th><th>Quality</th><th>Expires</th><th>Status</th><th></th></tr></thead><tbody>{rows}</tbody></table>' if entries else "<div class='empty'>No resolved streams yet.</div>"
    extra = """<script>async function del_(k){await fetch('/cache/'+k,{method:'DELETE'});toast('🗑️ Deleted');setTimeout(()=>location.reload(),1200);}</script>"""
    return _page("Streams", "streams", f"<h2>Resolved Streams</h2>{table}", extra)


# ─────────────────────────────────────────────────────────────────────────────
# API
# ─────────────────────────────────────────────────────────────────────────────
@app.post("/api/library/add")
async def api_library_add(request: Request, background_tasks: BackgroundTasks):
    body = await request.json()
    media_type = body.get("media_type")
    title = body.get("title", "").strip()
    year = body.get("year")
    arr_id = body.get("arr_id")
    if media_type not in ("movie", "series"): raise HTTPException(400, "bad media_type")
    if not title: raise HTTPException(400, "title required")
    lm = request.app.state.library
    db = request.app.state.db
    background_tasks.add_task(_add_to_library, lm, db, media_type, arr_id, title, year)
    return {"status": "adding", "title": title}


@app.post("/api/library/remove")
async def api_library_remove(request: Request):
    body = await request.json()
    media_type, title, year = body.get("media_type"), body.get("title","").strip(), body.get("year")
    lm = request.app.state.library
    db = request.app.state.db
    if media_type == "movie": lm.remove_fake_movie(title, year)
    else: lm.remove_fake_series(title)
    db.fake_library_remove(media_type, title, year)
    return {"status": "removed"}


async def _add_to_library(lm, db, media_type, arr_id, title, year):
    try:
        if media_type == "movie":
            path = lm.create_fake_movie(title, year)
            db.fake_library_add({"media_type":"movie","title":title,"year":year,
                                  "radarr_id":arr_id,"fake_path":str(path) if path else None})
        else:
            series_list = await lm.get_sonarr_series()
            series = next((s for s in series_list if s["id"] == arr_id), None)
            if not series: log.error(f"Series {arr_id} not found"); return
            episodes = await lm.get_sonarr_episodes(arr_id)
            paths = lm.create_fake_episodes(title, year, series.get("seasons",[]), episodes)
            db.fake_library_add({"media_type":"series","title":title,"year":year,
                                  "sonarr_id":arr_id,"tvdb_id":series.get("tvdb_id"),
                                  "season_count":series.get("season_count",0),
                                  "fake_path":str(Path(lm.plex_root)/"tv"/title) if lm.plex_root else None})
            log.info(f"📺 {title}: {len(paths)} fake episodes created")
    except Exception as e:
        log.error(f"Failed adding '{title}': {e}", exc_info=True)


@app.post("/webhook/tautulli")
async def tautulli_webhook(request: Request, background_tasks: BackgroundTasks):
    try: payload = await request.json()
    except: payload = dict(await request.form())
    media_type = payload.get("media_type","")
    title = payload.get("grandparent_title") or payload.get("title","")
    year = payload.get("year") or payload.get("grandparent_year")
    season = payload.get("parent_media_index")
    episode = payload.get("media_index")
    if media_type not in ("movie","episode"): return {"status":"ignored"}
    event = PlayEvent(media_type=MediaType(media_type), title=title,
                      year=int(year) if year else None,
                      season=int(season) if season else None,
                      episode=int(episode) if episode else None,
                      rating_key=payload.get("rating_key"))
    background_tasks.add_task(resolve_and_cache, request.app, event)
    return {"status":"accepted","cache_key":event.cache_key()}


@app.post("/webhook/sonarr")
async def sonarr_webhook(request: Request):
    payload = await request.json()
    log.info(f"📡 Sonarr: {payload.get('eventType')}")
    if request.app.state.library: request.app.state.library.invalidate_cache()
    return {"status":"ok"}


@app.post("/webhook/radarr")
async def radarr_webhook(request: Request):
    payload = await request.json()
    log.info(f"📡 Radarr: {payload.get('eventType')}")
    if request.app.state.library: request.app.state.library.invalidate_cache()
    return {"status":"ok"}


@app.get("/proxy/{cache_key}")
async def stream_proxy(cache_key: str, request: Request):
    return await proxy_stream(request, cache_key, request.app.state.db, request.app.state.alldebrid)


@app.post("/resolve")
async def manual_resolve(request: Request, background_tasks: BackgroundTasks):
    body = await request.json()
    event = PlayEvent(media_type=MediaType(body["media_type"]), title=body["title"],
                      year=body.get("year"), season=body.get("season"), episode=body.get("episode"))
    background_tasks.add_task(resolve_and_cache, request.app, event)
    s = request.app.state.settings
    return {"status":"resolving","cache_key":event.cache_key(),
            "proxy_url":f"{s.DEBRIDARR_BASE_URL}/proxy/{event.cache_key()}"}


@app.get("/cache")
async def list_cache(request: Request): return request.app.state.db.list_all()


@app.delete("/cache/{cache_key}")
async def delete_cache_entry(cache_key: str, request: Request):
    db = request.app.state.db
    entry = db.get(cache_key)
    s = request.app.state.settings
    if entry and s.PLEX_ROOT:
        delete_strm(cache_key=cache_key, title=entry["title"], year=entry.get("year"),
                    season=entry.get("season"), episode=entry.get("episode"),
                    media_type=entry["media_type"], plex_root=s.PLEX_ROOT)
    db.delete(cache_key)
    return {"status":"deleted"}


@app.get("/health")
async def health(): return {"status":"ok","service":"debridarr","version":"0.4.0"}


async def resolve_and_cache(app: FastAPI, event: PlayEvent):
    db = app.state.db
    alldebrid = app.state.alldebrid
    s = app.state.settings
    cache_key = event.cache_key()
    if db.get(cache_key) and db.get(cache_key)["status"] == "cached":
        log.info(f"✅ Cache hit: {cache_key}"); return
    log.info(f"🔍 Resolving: {cache_key}")
    db.upsert(cache_key, event, status="resolving")
    try:
        if event.media_type == MediaType.movie:
            query = f"{event.title} {event.year or ''} 1080p".strip()
        else:
            se = f"S{event.season:02d}E{event.episode:02d}" if event.season and event.episode else ""
            query = f"{event.title} {se} 1080p"
        results = await alldebrid.search_cached(query, media_type=event.media_type.value)
        if not results: db.update_status(cache_key, "not_found"); return
        best = results[0]
        stream_url = await alldebrid.unlock_magnet(best["magnet"])
        if not stream_url: db.update_status(cache_key, "unlock_failed"); return
        strm_path = None
        if s.PLEX_ROOT:
            p = write_strm(cache_key=cache_key, title=event.title, year=event.year,
                           season=event.season, episode=event.episode,
                           media_type=event.media_type.value,
                           debridarr_base_url=s.DEBRIDARR_BASE_URL, plex_root=s.PLEX_ROOT)
            strm_path = str(p) if p else None
        db.update_cached(cache_key, best["magnet"], stream_url, best["name"], best.get("quality","1080p"), strm_path)
        log.info(f"✅ Resolved: {cache_key}")
    except Exception as e:
        log.error(f"❌ {cache_key}: {e}", exc_info=True)
        db.update_status(cache_key, "error")

from pathlib import Path
