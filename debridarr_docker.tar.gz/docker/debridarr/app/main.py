"""
Debridarr - On-the-fly AllDebrid streaming for Plex
"""

import asyncio
import logging
import re
import sys
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path
from typing import Optional

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from app.alldebrid import AllDebridClient
from app.cache import CacheDB
from app.config import settings
from app.library import LibraryManager, _FAKE_MP4
from app.models import MediaType, PlayEvent
from app.proxy import proxy_stream, write_strm, delete_strm
from app.fuse_mount import (
    start_fuse_mount, stop_fuse_mount,
    register_torrent, unregister_torrent, get_fuse_path,
    list_torrents, list_files, get_torrent_file,
    FUSE_AVAILABLE, update_dfs_settings, get_dfs_settings,
)
from app.setup import (
    is_setup_complete, mark_setup_complete,
    load_saved_config, write_env,
    test_alldebrid, test_overseerr, test_plex_root,
)

logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("debridarr")


# ── Helpers ───────────────────────────────────────────────────────────────────

def _schedule_restart(delay: float = 2.0):
    import threading, subprocess, time
    def _do():
        time.sleep(delay)
        log.info("🔄 Restarting...")
        try: subprocess.run(["kill", "-TERM", "1"], check=False)
        except Exception as e: log.error(f"Restart failed: {e}")
    threading.Thread(target=_do, daemon=True).start()


def _init_clients(app: FastAPI):
    import os
    class _S:
        ALLDEBRID_API_KEY  = os.environ.get("ALLDEBRID_API_KEY", "")
        OVERSEERR_URL      = os.environ.get("OVERSEERR_URL", "")
        OVERSEERR_API_KEY  = os.environ.get("OVERSEERR_API_KEY", "")
        PLEX_ROOT          = os.environ.get("PLEX_ROOT", "/plex-strm")
        DEBRIDARR_BASE_URL = os.environ.get("DEBRIDARR_BASE_URL", "")
        DB_PATH            = os.environ.get("DB_PATH", "/data/debridarr.db")
        PORT               = int(os.environ.get("PORT", "7474"))
        LOG_LEVEL          = os.environ.get("LOG_LEVEL", "INFO")
        FUSE_MOUNT         = os.environ.get("FUSE_MOUNT", "/mnt/alldebrid")
        FUSE_SYMLINK_ROOT  = os.environ.get("FUSE_SYMLINK_ROOT", "/docker/debridarr/mnt-alldebrid")

    s = _S()
    db: CacheDB = getattr(app.state, "db", None)
    tmdb_key = db.get_setting("tmdb_api_key", "") if db else ""

    app.state.alldebrid = AllDebridClient(s.ALLDEBRID_API_KEY)
    app.state.library   = LibraryManager(
        overseerr_url=s.OVERSEERR_URL,
        overseerr_key=s.OVERSEERR_API_KEY,
        plex_root=s.PLEX_ROOT,
        tmdb_api_key=tmdb_key,
    )
    app.state.settings  = s
    app.state.fuse_thread = getattr(app.state, "fuse_thread", None)
    log.info(f"✅ Clients initialised — overseerr={s.OVERSEERR_URL or 'not set'}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info("🚀 Debridarr starting up...")
    for noisy in ("httpx", "httpcore", "multipart", "uvicorn.access"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    import os
    _data_env = Path("/data/.env")
    if _data_env.exists():
        log.info(f"📂 Loading config from {_data_env}")
        for line in _data_env.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            k, v = k.strip(), v.strip()
            if k and v and not os.environ.get(k):
                os.environ[k] = v

    db = CacheDB(settings.DB_PATH)
    db.init()
    app.state.db = db
    app.state.setup_complete = is_setup_complete()

    _init_clients(app)
    s = app.state.settings
    log.info(f"✅ Debridarr ready — plex_root={s.PLEX_ROOT or 'NOT SET'}")

    # Load DFS settings
    try:
        import json as _json
        saved_dfs = db.get_setting("dfs_settings")
        if saved_dfs:
            update_dfs_settings(_json.loads(saved_dfs))
        else:
            cache_dir = s.FUSE_SYMLINK_ROOT.replace("mnt-alldebrid", "tmp/cache") if s.FUSE_SYMLINK_ROOT else "/docker/debridarr/tmp/cache"
            update_dfs_settings({"cache_dir": cache_dir})
    except Exception as e:
        log.debug(f"DFS settings: {e}")

    try:
        Path(get_dfs_settings()["cache_dir"]).mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

    # Start FUSE
    if FUSE_AVAILABLE:
        _loop = asyncio.get_event_loop()
        _t = start_fuse_mount(s.FUSE_MOUNT, app.state.alldebrid, _loop)
        app.state.fuse_thread = _t
        if _t:
            log.info(f"🗂️  FUSE at {s.FUSE_MOUNT}")
            asyncio.create_task(_load_all_torrents(app))
    else:
        app.state.fuse_thread = None
        log.warning("⚠️  FUSE unavailable")

    asyncio.create_task(_cleanup_loop(app))
    asyncio.create_task(_symlink_health_loop(app))
    asyncio.create_task(_episode_sync_loop(app))

    yield

    if getattr(app.state, "fuse_thread", None):
        stop_fuse_mount(app.state.settings.FUSE_MOUNT)


app = FastAPI(title="Debridarr", version="0.5.0", lifespan=lifespan)


def _needs_setup(request: Request) -> bool:
    return not getattr(request.app.state, "setup_complete", False)

def _setup_redirect():
    return RedirectResponse("/setup", status_code=302)


# ── Styles ────────────────────────────────────────────────────────────────────
_CSS = """
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
       background: #0f0f13; color: #e0e0e0; min-height: 100vh; }
header { background: #1a1a24; border-bottom: 1px solid #2a2a3a;
         padding: 14px 28px; display: flex; align-items: center; gap: 16px; }
header h1 { font-size: 1.3rem; color: #fff; }
header .ver { font-size: 0.75rem; background: #f97316; color: #fff;
              border-radius: 4px; padding: 2px 8px; }
nav { display: flex; gap: 4px; margin-left: auto; }
nav a { color: #aaa; text-decoration: none; padding: 6px 14px; border-radius: 6px;
        font-size: 0.85rem; transition: background .15s; }
nav a:hover, nav a.active { background: #2a2a3a; color: #fff; }
main { padding: 28px; max-width: 1400px; margin: 0 auto; }
h2 { font-size: 1.05rem; color: #ccc; margin-bottom: 18px; }
.card-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 14px; }
.card { background: #1a1a24; border: 1px solid #2a2a3a; border-radius: 10px; overflow: hidden; }
.card img { width: 100%; aspect-ratio: 2/3; object-fit: cover; background: #111; display: block; }
.card .no-poster { width: 100%; aspect-ratio: 2/3; background: #1a1a2e;
                   display: flex; align-items: center; justify-content: center;
                   font-size: 2rem; color: #333; }
.card .info { padding: 10px 12px; }
.card .title { font-size: 0.85rem; font-weight: 600; color: #e0e0e0;
               white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.card .meta  { font-size: 0.72rem; color: #555; margin-top: 3px; }
.card .actions { padding: 0 10px 10px; display: flex; gap: 6px; flex-wrap: wrap; }
.btn { display: inline-block; padding: 5px 12px; border-radius: 6px; font-size: 0.78rem;
       font-weight: 600; border: none; cursor: pointer; text-decoration: none; transition: opacity .15s; }
.btn-add  { background: #f97316; color: #fff; }
.btn-add:hover { opacity: .85; }
.btn-rem  { background: #3b1f00; color: #fb923c; }
.btn-sec  { background: #1e3a5f; color: #60a5fa; }
.badge-in { display: inline-block; background: #14532d; color: #4ade80;
            font-size: 0.68rem; font-weight: 700; padding: 2px 7px; border-radius: 20px; }
.badge-grey { display: inline-block; background: #1a1a24; color: #555;
              font-size: 0.68rem; padding: 2px 7px; border-radius: 20px; border: 1px solid #2a2a3a; }
.search-bar { display: flex; gap: 10px; margin-bottom: 20px; }
.search-bar input { flex: 1; background: #1a1a24; border: 1px solid #2a2a3a;
                    border-radius: 8px; padding: 9px 14px; color: #e0e0e0; font-size: 0.9rem; outline: none; }
.search-bar input:focus { border-color: #f97316; }
.tabs { display: flex; gap: 2px; margin-bottom: 20px; }
.tab { padding: 8px 20px; border-radius: 8px; cursor: pointer; font-size: 0.85rem;
       font-weight: 600; border: 1px solid #2a2a3a; background: #1a1a24; color: #888; }
.tab.active { background: #f97316; color: #fff; border-color: #f97316; }
.empty { text-align: center; padding: 60px; color: #444; font-size: 0.9rem; }
.toast { position: fixed; bottom: 24px; right: 24px; background: #1a1a24;
         border: 1px solid #2a2a3a; border-radius: 10px; padding: 12px 20px;
         font-size: 0.85rem; opacity: 0; transition: opacity .3s; z-index: 999; }
.toast.show { opacity: 1; }
table { width: 100%; border-collapse: collapse; background: #1a1a24;
        border-radius: 10px; overflow: hidden; }
th { text-align: left; padding: 11px 14px; font-size: 0.72rem; text-transform: uppercase;
     color: #555; border-bottom: 1px solid #2a2a3a; }
td { padding: 10px 14px; border-bottom: 1px solid #1e1e2e; font-size: 0.85rem; }
tr:last-child td { border-bottom: none; }
.pill { padding: 2px 9px; border-radius: 20px; font-size: 0.72rem; font-weight: 600; }
.pill-ok   { background: #14532d; color: #4ade80; }
.pill-res  { background: #1e3a5f; color: #60a5fa; }
.pill-err  { background: #3b0000; color: #f87171; }
.pill-pend { background: #2d2d00; color: #facc15; }
.pill-nf   { background: #3b1f00; color: #fb923c; }
"""

_NAV = lambda active: f"""
<nav>
  <a href="/library"  class="{'active' if active=='library'  else ''}">📚 Add to Library</a>
  <a href="/streams"  class="{'active' if active=='streams'  else ''}">⚡ Streams</a>
  <a href="/settings" class="{'active' if active=='settings' else ''}">⚙️ Settings</a>
</nav>"""

_TOAST_JS = """
function toast(msg, ok=true) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.style.borderColor = ok ? '#4ade80' : '#f87171';
  t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 3500);
}"""

def _page(title, nav_active, body, extra=""):
    return HTMLResponse(f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>{title} — Debridarr</title>
  <style>{_CSS}</style>{extra}
</head>
<body>
  <header>
    <h1>🎬 Debridarr</h1><span class="ver">v0.5.0</span>
    {_NAV(nav_active)}
  </header>
  <main>{body}</main>
  <div id="toast" class="toast"></div>
  <script>{_TOAST_JS}</script>
</body>
</html>""")


# ── Setup ─────────────────────────────────────────────────────────────────────
_SETUP_CSS = _CSS + """
.wizard { max-width: 620px; margin: 60px auto; }
.wizard-card { background: #1a1a24; border: 1px solid #2a2a3a; border-radius: 14px; padding: 36px; }
.wizard h2 { font-size: 1.4rem; color: #fff; margin-bottom: 6px; }
.wizard .sub { color: #666; font-size: 0.88rem; margin-bottom: 28px; line-height: 1.5; }
.steps { display: flex; gap: 0; margin-bottom: 32px; }
.step { flex: 1; text-align: center; font-size: 0.7rem; color: #444; padding-bottom: 8px;
        border-bottom: 2px solid #2a2a3a; }
.step.done   { color: #4ade80; border-color: #4ade80; }
.step.active { color: #f97316; border-color: #f97316; font-weight: 700; }
.field { margin-bottom: 20px; }
.field label { display: block; font-size: 0.8rem; color: #888; margin-bottom: 6px; font-weight: 600; }
.field input { width: 100%; background: #0f0f13; border: 1px solid #2a2a3a; border-radius: 8px;
               padding: 10px 14px; color: #e0e0e0; font-size: 0.9rem; outline: none; font-family: monospace; }
.field input:focus { border-color: #f97316; }
.field .hint { font-size: 0.75rem; color: #555; margin-top: 5px; line-height: 1.4; }
.field .hint a { color: #f97316; }
.test-result { margin-top: 10px; padding: 8px 12px; border-radius: 6px; font-size: 0.82rem; display: none; }
.test-result.ok      { background: #14532d; color: #4ade80; display: block; }
.test-result.err     { background: #3b0000; color: #f87171; display: block; }
.test-result.testing { background: #1e1e2e; color: #aaa; display: block; }
.row { display: flex; gap: 10px; }
.row .field { flex: 1; }
.actions { display: flex; gap: 10px; margin-top: 28px; justify-content: flex-end; }
.btn-primary { background: #f97316; color: #fff; padding: 10px 24px; border-radius: 8px;
               font-size: 0.9rem; font-weight: 600; border: none; cursor: pointer; }
.btn-primary:hover { opacity: .85; }
.btn-primary:disabled { opacity: .4; cursor: not-allowed; }
.btn-ghost { background: transparent; color: #666; padding: 10px 16px; border-radius: 8px;
             font-size: 0.9rem; border: 1px solid #2a2a3a; cursor: pointer; }
.btn-ghost:hover { color: #ccc; border-color: #444; }
.confirm-row { display: flex; justify-content: space-between; padding: 10px 0;
               border-bottom: 1px solid #1e1e2e; font-size: 0.875rem; }
.confirm-row:last-child { border-bottom: none; }
.confirm-row .lbl { color: #666; }
.confirm-row .val { color: #e0e0e0; font-family: monospace; font-size: 0.82rem; }
"""

def _setup_page(body, step):
    step_names = ["Welcome", "AllDebrid", "Overseerr", "Plex", "Confirm"]
    step_keys  = ["welcome", "alldebrid", "overseerr", "plex", "confirm"]
    idx = step_keys.index(step) if step in step_keys else 0
    steps_html = "".join(
        f'<div class="step {"done" if i < idx else "active" if i == idx else ""}">{n}</div>'
        for i, n in enumerate(step_names)
    )
    return HTMLResponse(f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Debridarr Setup</title>
  <style>{_SETUP_CSS}</style>
</head>
<body>
  <header>
    <h1>🎬 Debridarr</h1><span class="ver">v0.5.0</span>
    <span style="margin-left:auto;color:#555;font-size:0.8rem">First-run setup</span>
  </header>
  <div class="wizard">
    <div class="steps">{steps_html}</div>
    <div class="wizard-card">{body}</div>
  </div>
  <div id="toast" class="toast"></div>
  <script>{_TOAST_JS}</script>
</body>
</html>""")


@app.get("/setup", response_class=HTMLResponse)
async def setup_get(request: Request, step: str = "welcome"):
    cfg = load_saved_config()

    if step == "welcome":
        return _setup_page("""
        <div style="font-size:4rem;text-align:center;margin-bottom:20px">🎬</div>
        <h2>Welcome to Debridarr</h2>
        <p class="sub">Connect Debridarr to AllDebrid and Overseerr. Takes ~2 minutes.</p>
        <div class="actions">
          <a href="/setup?step=alldebrid" class="btn-primary" style="text-decoration:none;display:inline-block;padding:10px 24px">Get Started →</a>
        </div>""", "welcome")

    if step == "alldebrid":
        val = cfg.get("ALLDEBRID_API_KEY", "")
        return _setup_page(f"""
        <h2>AllDebrid</h2>
        <p class="sub">Debridarr uses AllDebrid to stream cached torrents instantly.</p>
        <div class="field">
          <label>API Key</label>
          <input id="api_key" type="password" value="{val}" placeholder="Paste your AllDebrid API key">
          <div class="hint">Get yours at <a href="https://alldebrid.com/apikeys" target="_blank">alldebrid.com/apikeys</a></div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="actions">
          <a href="/setup?step=welcome" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="btn" onclick="go()">Test & Continue →</button>
        </div>
        <script>
        async function go() {{
          const key = document.getElementById('api_key').value.trim();
          const res = document.getElementById('test-result');
          const btn = document.getElementById('btn');
          if (!key) {{ res.className='test-result err'; res.textContent='API key required'; return; }}
          res.className='test-result testing'; res.textContent='Testing...'; btn.disabled=true;
          const r = await fetch('/setup/test', {{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{step:'alldebrid',api_key:key}})}});
          const d = await r.json(); btn.disabled=false;
          if (d.ok) {{ res.className='test-result ok'; res.textContent='✅ '+d.message;
            setTimeout(()=>window.location='/setup?step=overseerr&akey='+encodeURIComponent(key),800); }}
          else {{ res.className='test-result err'; res.textContent='❌ '+d.message; }}
        }}
        document.getElementById('api_key').addEventListener('keydown',e=>{{if(e.key==='Enter')go();}});
        </script>""", "alldebrid")

    if step == "overseerr":
        url_val = cfg.get("OVERSEERR_URL", "http://192.168.1.x:5055")
        key_val = cfg.get("OVERSEERR_API_KEY", "")
        akey    = request.query_params.get("akey", cfg.get("ALLDEBRID_API_KEY", ""))
        return _setup_page(f"""
        <h2>Overseerr</h2>
        <p class="sub">Connect to your Overseerr instance to browse your request library.</p>
        <div class="field">
          <label>Overseerr URL</label>
          <input id="url" type="text" value="{url_val}" placeholder="http://192.168.1.x:5055">
        </div>
        <div class="field">
          <label>API Key</label>
          <input id="key" type="password" value="{key_val}" placeholder="Overseerr API key">
          <div class="hint">Overseerr → Settings → General → API Key</div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="actions">
          <a href="/setup?step=alldebrid" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="btn" onclick="go()">Test & Continue →</button>
        </div>
        <input type="hidden" id="akey" value="{akey}">
        <script>
        async function go() {{
          const url=document.getElementById('url').value.trim();
          const key=document.getElementById('key').value.trim();
          const akey=document.getElementById('akey').value;
          const res=document.getElementById('test-result'); const btn=document.getElementById('btn');
          res.className='test-result testing'; res.textContent='Testing...'; btn.disabled=true;
          const r=await fetch('/setup/test',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{step:'overseerr',url,api_key:key}})}});
          const d=await r.json(); btn.disabled=false;
          if(d.ok){{res.className='test-result ok';res.textContent='✅ '+d.message;
            setTimeout(()=>window.location='/setup?step=plex&akey='+encodeURIComponent(akey)+'&ourl='+encodeURIComponent(url)+'&okey='+encodeURIComponent(key),800);}}
          else{{res.className='test-result err';res.textContent='❌ '+d.message;}}
        }}
        </script>""", "overseerr")

    if step == "plex":
        qs = dict(request.query_params)
        hidden = "".join(f'<input type="hidden" id="{k}" value="{v}">' for k, v in qs.items() if k != "step")
        tz_val   = cfg.get("TZ", "America/Edmonton")
        puid_val = cfg.get("PUID", "1000")
        pgid_val = cfg.get("PGID", "1000")
        base_url = cfg.get("DEBRIDARR_BASE_URL", "http://192.168.1.x:7474")
        return _setup_page(f"""
        <h2>Plex Integration</h2>
        <p class="sub">Where to write library files and how Plex reaches Debridarr.</p>
        <div class="field">
          <label>Plex Library Path (inside container)</label>
          <input id="plex_root" type="text" value="/plex-strm" placeholder="/plex-strm">
          <div class="hint">Must be bind-mounted into both Debridarr and Plex.</div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="field">
          <label>Debridarr Base URL (as seen by Plex)</label>
          <input id="base_url" type="text" value="{base_url}" placeholder="http://192.168.1.x:7474">
        </div>
        <div class="row">
          <div class="field"><label>Timezone</label><input id="tz" value="{tz_val}"></div>
          <div class="field"><label>PUID</label><input id="puid" value="{puid_val}"></div>
          <div class="field"><label>PGID</label><input id="pgid" value="{pgid_val}"></div>
        </div>
        {hidden}
        <div class="actions">
          <a href="/setup?step=overseerr" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="btn" onclick="go()">Test & Continue →</button>
        </div>
        <script>
        async function go(){{
          const plex_root=document.getElementById('plex_root').value.trim();
          const res=document.getElementById('test-result'); const btn=document.getElementById('btn');
          res.className='test-result testing'; res.textContent='Checking...'; btn.disabled=true;
          const r=await fetch('/setup/test',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{step:'plex',plex_root}})}});
          const d=await r.json(); btn.disabled=false;
          if(d.ok){{res.className='test-result ok';res.textContent='✅ '+d.message;
            const prev={{}};
            document.querySelectorAll('input[type=hidden]').forEach(i=>prev[i.id]=i.value);
            const p=new URLSearchParams({{...prev,step:'confirm',plex_root,
              base_url:document.getElementById('base_url').value.trim(),
              tz:document.getElementById('tz').value.trim(),
              puid:document.getElementById('puid').value.trim(),
              pgid:document.getElementById('pgid').value.trim()}});
            setTimeout(()=>window.location='/setup?'+p.toString(),800);}}
          else{{res.className='test-result err';res.textContent='❌ '+d.message;}}
        }}
        </script>""", "plex")

    if step == "confirm":
        qs = dict(request.query_params)
        def row(lbl, key, mask=False):
            val = qs.get(key, "—")
            display = ("•" * 8 + val[-4:]) if mask and val and val != "—" else val
            return f'<div class="confirm-row"><span class="lbl">{lbl}</span><span class="val">{display}</span></div>'
        hidden = "".join(f'<input type="hidden" name="{k}" value="{v}">' for k, v in qs.items() if k != "step")
        return _setup_page(f"""
        <h2>Confirm & Save</h2>
        <p class="sub">Review settings and click Save to finish.</p>
        <div style="margin-bottom:24px">
          {row("AllDebrid API Key", "akey", mask=True)}
          {row("Overseerr URL", "ourl")}
          {row("Overseerr API Key", "okey", mask=True)}
          {row("Plex Library Path", "plex_root")}
          {row("Debridarr Base URL", "base_url")}
          {row("Timezone", "tz")}
        </div>
        <form method="POST" action="/setup/save">
          {hidden}
          <div class="actions">
            <a href="/setup?step=plex" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
            <button type="submit" class="btn-primary">💾 Save & Finish</button>
          </div>
        </form>""", "confirm")

    return RedirectResponse("/setup")


@app.post("/setup/test")
async def setup_test(request: Request):
    body = await request.json()
    step = body.get("step")
    if step == "alldebrid":  ok, msg = await test_alldebrid(body.get("api_key", ""))
    elif step == "overseerr": ok, msg = await test_overseerr(body.get("url", ""), body.get("api_key", ""))
    elif step == "plex":      ok, msg = await test_plex_root(body.get("plex_root", ""))
    else:                     ok, msg = False, "Unknown step"
    return JSONResponse({"ok": ok, "message": msg})


@app.post("/setup/save")
async def setup_save(request: Request):
    form = dict(await request.form())
    config = {
        "ALLDEBRID_API_KEY":  form.get("akey", ""),
        "OVERSEERR_URL":      form.get("ourl", ""),
        "OVERSEERR_API_KEY":  form.get("okey", ""),
        "DEBRIDARR_BASE_URL": form.get("base_url", ""),
        "TZ":                 form.get("tz", "America/Edmonton"),
        "PUID":               form.get("puid", "1000"),
        "PGID":               form.get("pgid", "1000"),
    }
    write_env(config)
    import os
    for k, v in config.items(): os.environ[k] = v
    os.environ["PLEX_ROOT"] = form.get("plex_root", "/plex-strm")
    mark_setup_complete()
    request.app.state.setup_complete = True
    _init_clients(request.app)
    log.info("✅ Setup complete — restarting...")
    _schedule_restart(delay=2.0)
    return HTMLResponse(f"""<!DOCTYPE html><html><head><meta charset="UTF-8">
<meta http-equiv="refresh" content="6;url=/library">
<style>{_SETUP_CSS}</style></head><body>
<header><h1>🎬 Debridarr</h1><span class="ver">v0.5.0</span></header>
<div class="wizard"><div class="wizard-card" style="text-align:center;padding:48px">
<div style="font-size:3rem;margin-bottom:16px">🎉</div>
<h2 style="color:#4ade80;margin-bottom:12px">Setup Complete!</h2>
<p style="color:#888;margin-bottom:24px">Redirecting to library...</p>
<a href="/library" style="color:#f97316">Click here if not redirected</a>
</div></div></body></html>""")


# ── / redirect ────────────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    if _needs_setup(request): return _setup_redirect()
    return RedirectResponse("/library")


# ── /library — browse Overseerr ───────────────────────────────────────────────
@app.get("/library", response_class=HTMLResponse)
async def library_browse(request: Request, tab: str = "movies", q: str = ""):
    if _needs_setup(request): return _setup_redirect()
    lm: LibraryManager = request.app.state.library
    db: CacheDB = request.app.state.db

    already_added = {(r["media_type"], r["title"].lower()) for r in db.fake_library_list()}

    if tab == "movies":
        items = await lm.get_radarr_movies()
    else:
        items = await lm.get_sonarr_series()

    if q:
        ql = q.lower()
        items = [i for i in items if ql in i["title"].lower()]

    cards = ""
    for item in items:
        mtype = "movie" if tab == "movies" else "series"
        year  = item.get("year")
        in_lib = (mtype, item["title"].lower()) in already_added
        poster = item.get("poster", "")
        img = f'<img src="{poster}" onerror="this.style.display=\'none\'" loading="lazy">' if poster else f'<div class="no-poster">{item["title"][:1]}</div>'
        safe = item["title"].replace("'", "\\'").replace('"', '&quot;')
        sc  = item.get("season_count", 0)
        meta = str(year or "")
        if tab != "movies" and sc:
            meta += f" · {sc} season{'s' if sc != 1 else ''}"
        badge = '<div class="actions"><span class="badge-in">✓ In Library</span>' if in_lib else ""

        if in_lib:
            action = f'<button class="btn btn-rem" onclick="removeItem(\'{mtype}\',\'{safe}\',{year or "null"})">Remove</button>'
        else:
            action = f'<button class="btn btn-add" onclick="addItem(\'{mtype}\',{item.get("id","null")},\'{safe}\',{year or "null"},{sc})">+ Add</button>'

        cards += f"""<div class="card">
          {img}
          <div class="info">
            <div class="title" title="{item['title']}">{item['title']}</div>
            <div class="meta">{meta}</div>
          </div>
          <div class="actions">{action}</div>
        </div>"""

    if not cards:
        cards = f'<div class="empty">{"No results for &quot;"+q+"&quot;" if q else "Nothing found — check Overseerr settings"}</div>'

    movie_count = len(await lm.get_radarr_movies())
    tv_count    = len(await lm.get_sonarr_series())

    body = f"""
    <h2>Browse Library</h2>
    <div class="tabs">
      <div class="tab {'active' if tab=='movies' else ''}" onclick="location.href='/library?tab=movies&q={q}'">🎬 Movies ({movie_count})</div>
      <div class="tab {'active' if tab=='tv'     else ''}" onclick="location.href='/library?tab=tv&q={q}'">📺 TV Shows ({tv_count})</div>
    </div>
    <div class="search-bar">
      <input id="q" type="text" placeholder="Search..." value="{q}"
             onkeydown="if(event.key==='Enter')location.href='/library?tab={tab}&q='+encodeURIComponent(this.value)">
      <button class="btn btn-add" onclick="location.href='/library?tab={tab}&q='+encodeURIComponent(document.getElementById('q').value)">Search</button>
      {'<button class="btn btn-sec" onclick="location.href=\'/library?tab='+tab+'\'">Clear</button>' if q else ''}
      <button class="btn btn-sec" onclick="refreshLib()">🔄 Refresh</button>
    </div>
    <div class="card-grid">{cards}</div>"""

    extra = """<script>
async function addItem(type, id, title, year, sc) {
  const r = await fetch('/api/library/add', {method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({media_type:type,arr_id:id,title,year,season_count:sc})});
  const d = await r.json();
  if (r.ok) { toast('✅ '+title+' added'); setTimeout(()=>location.reload(),1200); }
  else { toast('❌ '+(d.detail||d.message||'Error'), false); }
}
async function removeItem(type, title, year) {
  if (!confirm('Remove "'+title+'" from library?')) return;
  const r = await fetch('/api/library/remove',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({media_type:type,title,year})});
  if (r.ok) { toast('🗑️ Removed'); setTimeout(()=>location.reload(),1200); }
  else { toast('❌ Error', false); }
}
async function refreshLib() {
  const r = await fetch('/api/library/refresh',{method:'POST'});
  const d = await r.json();
  toast('✅ Refreshed — '+d.synced+' series updated');
  setTimeout(()=>location.reload(),1200);
}
</script>"""
    return _page("Browse Library", "library", body, extra)


# ── /api/library/add ─────────────────────────────────────────────────────────
@app.post("/api/library/add")
async def api_library_add(request: Request, background_tasks: BackgroundTasks):
    body = await request.json()
    media_type   = body.get("media_type", "movie")
    arr_id       = body.get("arr_id")
    title        = body.get("title", "").strip()
    year         = body.get("year")
    season_count = body.get("season_count", 0)

    if not title:
        raise HTTPException(400, "title required")

    lm: LibraryManager = request.app.state.library
    db: CacheDB         = request.app.state.db
    tmdb_key            = db.get_setting("tmdb_api_key", "")

    if media_type == "movie":
        # Fetch full movie details from Overseerr to get poster/overview/tmdb_id
        movies = await lm.get_radarr_movies()
        movie  = next((m for m in movies if m.get("id") == arr_id or m["title"].lower() == title.lower()), None)

        path = lm.create_fake_movie(title, year)

        poster_url = movie.get("poster", "") if movie else ""
        tmdb_id    = movie.get("tmdb_id") if movie else None
        imdb_id    = movie.get("imdb_id") if movie else None
        overview   = movie.get("overview", "") if movie else ""

        # Fetch poster from TMDB if not from Overseerr
        if not poster_url and tmdb_key and tmdb_id:
            poster_url = await _fetch_tmdb_poster(tmdb_id, title, True, tmdb_key)

        db.fake_library_add({
            "media_type": "movie",
            "title":      title,
            "year":       year,
            "radarr_id":  arr_id,
            "tmdb_id":    tmdb_id,
            "imdb_id":    imdb_id,
            "poster_url": poster_url,
            "overview":   overview,
            "status":     "movie",
            "fake_path":  str(path) if path else None,
        })
        log.info(f"🎬 Added movie: {title} ({year})")
        background_tasks.add_task(_precache_movie, request.app, title, year, tmdb_id, imdb_id)
        return {"status": "ok", "message": f"Added {title}"}

    else:
        # Series — fetch details synchronously so we can return a useful response
        series_list = await lm.get_sonarr_series()
        series = next((s for s in series_list if s.get("id") == arr_id), None)

        sc                = series.get("season_count", season_count) if series else season_count
        tvdb_id           = series.get("tvdb_id") if series else None
        tmdb_id           = series.get("tmdb_id") if series else None
        imdb_id           = series.get("imdb_id") if series else None
        poster_url        = series.get("poster", "") if series else ""
        overview          = series.get("overview", "") if series else ""
        is_ended          = series.get("is_ended", False) if series else False
        requested_seasons = series.get("requested_seasons", []) if series else []

        if not poster_url and tmdb_key and tmdb_id:
            poster_url = await _fetch_tmdb_poster(tmdb_id, title, False, tmdb_key)

        include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"

        # Fetch ALL aired episodes from Overseerr/TMDB
        episodes = await lm.get_episodes(
            arr_id,
            include_unreleased=include_unreleased,
            requested_seasons=requested_seasons if requested_seasons else None,
        )

        log.info(f"📺 {title}: {len(episodes)} episodes from Overseerr for seasons {requested_seasons}")

        # Write placeholder .mp4 for every episode immediately
        paths = lm.create_fake_episodes(title, year, [], episodes)

        db.fake_library_add({
            "media_type":   "series",
            "title":        title,
            "year":         year,
            "sonarr_id":    arr_id,
            "tvdb_id":      tvdb_id,
            "tmdb_id":      tmdb_id,
            "imdb_id":      imdb_id,
            "season_count": sc,
            "poster_url":   poster_url,
            "overview":     overview,
            "status":       "ended" if is_ended else "continuing",
            "fake_path":    str(Path(lm.plex_root) / "tv" / title) if lm.plex_root else None,
        })

        log.info(f"📺 Added {title!r} — {len(paths)}/{len(episodes)} placeholders written")

        # Cache all episodes in background (so play works immediately)
        background_tasks.add_task(_precache_series, request.app, title, year, episodes)
        return {"status": "ok", "message": f"Added {title} — {len(episodes)} episodes"}


@app.post("/api/library/remove")
async def api_library_remove(request: Request):
    body  = await request.json()
    mtype = body.get("media_type")
    title = body.get("title", "").strip()
    year  = body.get("year")
    lm    = request.app.state.library
    db    = request.app.state.db

    # Remove files from plex-strm
    if mtype == "movie": lm.remove_fake_movie(title, year)
    else:                lm.remove_fake_series(title)

    # Remove from fake_library DB
    db.fake_library_remove(mtype, title, year)

    # Remove all cache entries for this title so they don't linger
    all_entries = db.list_all()
    db_types = ["movie"] if mtype == "movie" else ["episode", "series"]
    for entry in all_entries:
        if entry["title"].lower() == title.lower() and entry["media_type"] in db_types:
            db.delete(entry["cache_key"])

    log.info(f"🗑️  Removed '{title}' from library and cache")
    return {"status": "removed"}


@app.post("/api/library/refresh")
async def api_library_refresh(request: Request):
    lm = request.app.state.library
    db = request.app.state.db
    if not lm: return {"status": "error", "message": "Not configured"}
    lm.invalidate_cache()
    movies = await lm.get_radarr_movies(force=True)
    series = await lm.get_sonarr_series(force=True)
    added  = [r for r in db.fake_library_list() if r["media_type"] == "series"]
    include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"
    synced = 0
    for entry in added:
        sid = entry.get("sonarr_id")
        if not sid: continue
        updated = next((s for s in series if s.get("id") == sid), None)
        if not updated: continue
        result = await lm.sync_series_episodes(entry["title"], sid, entry.get("year"),
                                                include_unreleased,
                                                requested_seasons=updated.get("requested_seasons", []))
        if result.get("added", 0) > 0: synced += 1
    return {"status": "ok", "movies": len(movies), "series": len(series), "synced": synced}


# ── /streams — resolved streams + search ─────────────────────────────────────
@app.get("/streams", response_class=HTMLResponse)
async def streams_page(request: Request, q: str = "", filter_type: str = "all"):
    if _needs_setup(request): return _setup_redirect()
    db: CacheDB = request.app.state.db
    tmdb_key = db.get_setting("tmdb_api_key", "")

    # Get library items for the search/poster display
    lib_items = db.fake_library_list()
    movies_lib = [i for i in lib_items if i["media_type"] == "movie"]
    shows_lib  = [i for i in lib_items if i["media_type"] == "series"]

    # Cached counts per title
    all_cached = [e for e in db.list_all() if e["status"] == "cached"]
    cached_counts: dict[str, int] = {}
    for e in all_cached:
        mt = "movie" if e["media_type"] == "movie" else "series"
        k  = f"{mt}::{e['title'].lower()}"
        cached_counts[k] = cached_counts.get(k, 0) + 1

    # Streams table (filtered)
    entries = db.list_all()
    if q:
        ql = q.lower()
        entries = [e for e in entries if ql in e["title"].lower()]
    if filter_type != "all":
        entries = [e for e in entries if e["status"] == filter_type]

    def pill(s):
        cls = {"cached":"pill-ok","resolving":"pill-res","error":"pill-err","not_found":"pill-nf"}.get(s,"pill-pend")
        return f'<span class="pill {cls}">{s}</span>'

    rows = ""
    for e in entries:
        t = e.get("torrent_name","") or ""
        t_short = (t[:60]+"…") if len(t) > 60 else t
        ep  = ""
        if e.get("season"):  ep += f"S{str(e['season']).zfill(2)}"
        if e.get("episode"): ep += f"E{str(e['episode']).zfill(2)}"
        exp = datetime.fromisoformat(e["expires_at"]).strftime("%Y-%m-%d") if e.get("expires_at") else "—"
        rows += f"""<tr>
          <td style="color:#888;font-size:0.8rem">{e['media_type']}</td>
          <td><strong>{e['title']}</strong><br><small style="color:#555;font-size:0.72rem">{t_short}</small></td>
          <td style="font-family:monospace">{ep}</td>
          <td>{e.get('quality','—') or '—'}</td>
          <td>{exp}</td>
          <td>{pill(e['status'])}</td>
          <td style="white-space:nowrap">
            <button class="btn btn-rem" style="padding:3px 8px;font-size:0.72rem" onclick="del_('{e['cache_key']}')">Del</button>
            <button class="btn btn-sec" style="padding:3px 8px;font-size:0.72rem;margin-left:4px" onclick="expireNow('{e['cache_key']}')">⏰ Expire</button>
          </td>
        </tr>"""

    count = len(entries)
    total = len(db.list_all())

    # My Library cards section
    def lib_card(item, mtype):
        title  = item["title"]
        safe   = title.replace("'","&#39;").replace('"','&quot;')
        poster = item.get("poster_url") or ""
        sc     = item.get("season_count") or 0
        status = item.get("status","")
        year   = item.get("year") or ""
        n      = cached_counts.get(f"{mtype}::{title.lower()}", 0)

        if poster:
            img = f'<img src="{poster}" alt="{safe}" style="width:100%;aspect-ratio:2/3;object-fit:cover;display:block">'
        else:
            initials = "".join(w[0].upper() for w in title.split()[:2])
            img = f'<div class="no-poster">{initials}</div>'

        badge = f'<span class="badge-in">✅ {n} ep{"s" if n!=1 else ""}</span>' if n and mtype=="series" else \
                (f'<span class="badge-in">✅ Cached</span>' if n else \
                 '<span class="badge-grey">⏳ Not cached</span>')

        status_pill = ""
        if mtype == "series":
            col = "#ef4444" if status == "ended" else "#22c55e"
            lbl = "Ended" if status == "ended" else "Continuing"
            status_pill = f'<span style="font-size:0.65rem;color:{col};margin-left:4px">({lbl})</span>'

        sub = f"{sc} season{'s' if sc!=1 else ''}{status_pill}" if mtype=="series" else str(year)

        return f"""<div class="card" style="cursor:pointer" onclick="filterByTitle('{safe}')">
          {img}
          <div class="info">
            <div class="title" title="{safe}">{title}</div>
            <div class="meta">{sub}</div>
          </div>
          <div class="actions">
            {badge}
            <button class="btn btn-rem" style="padding:3px 8px;font-size:0.7rem"
              onclick="event.stopPropagation();rem('{mtype}','{safe}',{item.get('year') or 'null'})">Remove</button>
          </div>
        </div>"""

    lib_section = ""
    if movies_lib:
        lib_section += f'<h2 style="margin:0 0 12px">🎬 Movies <span style="color:#555;font-size:0.8rem;font-weight:normal">({len(movies_lib)})</span></h2>'
        lib_section += f'<div class="card-grid" style="margin-bottom:32px">{"".join(lib_card(i,"movie") for i in movies_lib)}</div>'
    if shows_lib:
        lib_section += f'<h2 style="margin:0 0 12px">📺 TV Shows <span style="color:#555;font-size:0.8rem;font-weight:normal">({len(shows_lib)})</span></h2>'
        lib_section += f'<div class="card-grid" style="margin-bottom:32px">{"".join(lib_card(i,"series") for i in shows_lib)}</div>'
    if not lib_section:
        lib_section = f'<div class="empty"><a href="/library" style="color:#f97316">Browse Library</a> to add titles.</div>'

    # Streams table
    del_all = f'<button class="btn btn-rem" onclick="delAll()" style="padding:6px 14px">🗑️ Delete All</button>' if entries else ""
    streams_section = f"""
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
      <h2 style="margin:0">⚡ Resolved Streams <span style="color:#555;font-size:0.8rem;font-weight:normal">({count}/{total})</span></h2>
      {del_all}
    </div>
    <div class="search-bar" style="margin-bottom:14px">
      <input id="sq" type="text" placeholder="Search streams..." value="{q}"
             onkeydown="if(event.key==='Enter')goSearch()">
      <button class="btn btn-sec" onclick="goSearch()">Search</button>
      {'<button class="btn btn-sec" onclick="location.href=\'/streams\'">Clear</button>' if q else ''}
      <select onchange="location.href='/streams?q={q}&filter_type='+this.value"
              style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:8px;padding:8px 12px;color:#e0e0e0;font-size:0.85rem;outline:none">
        <option value="all" {'selected' if filter_type=='all' else ''}>All statuses</option>
        <option value="cached" {'selected' if filter_type=='cached' else ''}>Cached</option>
        <option value="not_found" {'selected' if filter_type=='not_found' else ''}>Not found</option>
        <option value="error" {'selected' if filter_type=='error' else ''}>Error</option>
      </select>
    </div>
    {"<table><thead><tr><th>Type</th><th>Title</th><th>Ep</th><th>Quality</th><th>Expires</th><th>Status</th><th></th></tr></thead><tbody>"+rows+"</tbody></table>" if rows else '<div class="empty">No streams match.</div>'}"""

    body = lib_section + '<hr style="border:none;border-top:1px solid #2a2a3a;margin:32px 0">' + streams_section

    extra = """<script>
function goSearch() { location.href='/streams?q='+encodeURIComponent(document.getElementById('sq').value)+'&filter_type=all'; }
function filterByTitle(title) {
  const t = title.replace(/&#39;/g,"'").replace(/&quot;/g,'"');
  document.getElementById('sq').value = t;
  goSearch();
}
async function expireNow(k) {
  if (!confirm('Hard reset this cached stream?\n\nThis will:\n• Delete the symlink\n• Restore the placeholder\n• Remove from AllDebrid\n\nIt will re-cache automatically when played again.')) return;
  const r = await fetch('/cache/'+k+'/expire', {method:'POST'});
  const d = await r.json();
  toast(r.ok ? '⏰ Reset — placeholder restored, re-caches on play' : '❌ Error', r.ok);
  setTimeout(()=>location.reload(), 1800);
}
async function del_(k){
  await fetch('/cache/'+k,{method:'DELETE'});
  toast('🗑️ Deleted'); setTimeout(()=>location.reload(),1200);
}
async function delAll(){
  const btns=[...document.querySelectorAll('tbody button')];
  if(!confirm('Delete all '+btns.length+' streams?'))return;
  const keys=btns.map(b=>b.getAttribute('onclick').match(/'([^']+)'/)[1]);
  for(const k of keys) await fetch('/cache/'+k,{method:'DELETE'});
  toast('🗑️ All deleted'); setTimeout(()=>location.reload(),1000);
}
async function rem(type, title, year) {
  const t = title.replace(/&#39;/g,"'").replace(/&quot;/g,'"');
  if (!confirm('Remove "'+t+'" from library?')) return;
  const r = await fetch('/api/library/remove',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({media_type:type,title:t,year})});
  if (r.ok) { toast('🗑️ Removed'); setTimeout(()=>location.reload(),1200); }
  else { toast('❌ Error', false); }
}
</script>"""
    return _page("Streams", "streams", body, extra)


# ── /settings ────────────────────────────────────────────────────────────────
@app.get("/settings", response_class=HTMLResponse)
async def settings_page(request: Request):
    if _needs_setup(request): return _setup_redirect()
    cfg = load_saved_config()
    s   = request.app.state.settings
    db: CacheDB = request.app.state.db
    cfg["TMDB_API_KEY"] = db.get_setting("tmdb_api_key", "")

    def field(label, key, hint="", typ="text", placeholder=""):
        val    = cfg.get(key) or getattr(s, key, "") or ""
        masked = typ == "password"
        is_saved = bool(val) and masked
        ph     = "••••••• (saved — leave blank to keep)" if is_saved else (placeholder or "")
        saved_attr = ' data-saved="true"' if is_saved else ""
        return f"""<div class="field">
          <label>{label}{'<span class="saved-badge">saved</span>' if is_saved else ""}</label>
          <input id="{key}" name="{key}" type="{typ}" value="{'' if masked else val}"
                 placeholder="{ph}" autocomplete="off"{saved_attr}>
          {'<div class="hint">'+hint+'</div>' if hint else ''}
        </div>"""

    all_settings = db.get_all_settings()

    body = f"""
    <div style="max-width:720px">
      <h2 style="margin-bottom:4px">⚙️ Settings</h2>
      <p style="color:#555;font-size:0.85rem;margin-bottom:28px">Changes require saving to take effect.</p>

      <div class="s-sect">
        <div class="s-title">AllDebrid</div>
        {field("API Key","ALLDEBRID_API_KEY",'<a href="https://alldebrid.com/apikeys" target="_blank">alldebrid.com/apikeys</a>',"password")}
        <button class="btn btn-sec" onclick="testConn('alldebrid')">Test</button>
        <div id="test-alldebrid" class="test-result"></div>
      </div>

      <div class="s-sect">
        <div class="s-title">Overseerr</div>
        {field("URL","OVERSEERR_URL","","text","http://192.168.1.x:5055")}
        {field("API Key","OVERSEERR_API_KEY","Overseerr → Settings → General → API Key","password")}
        <button class="btn btn-sec" onclick="testConn('overseerr')">Test</button>
        <div id="test-overseerr" class="test-result"></div>
      </div>

      <div class="s-sect">
        <div class="s-title">TMDB</div>
        {field("API Key","TMDB_API_KEY",'For cover art. <a href="https://www.themoviedb.org/settings/api" target="_blank" style="color:#f97316">Get free key →</a>',"password")}
      </div>

      <div class="s-sect">
        <div class="s-title">Plex</div>
        {field("Debridarr Base URL","DEBRIDARR_BASE_URL","URL Plex uses to reach Debridarr","text","http://192.168.1.x:7474")}
        {field("Plex Library Path","PLEX_ROOT","Path inside container where fake files are written","text","/plex-strm")}
        <button class="btn btn-sec" onclick="testConn('plex')">Test</button>
        <div id="test-plex" class="test-result"></div>
      </div>

      <div class="s-sect">
        <div class="s-title">Library</div>
        <div style="display:flex;align-items:center;justify-content:space-between;gap:20px">
          <div>
            <div style="font-size:0.875rem;font-weight:600;margin-bottom:4px">Include unreleased episodes</div>
            <div style="font-size:0.75rem;color:#555">Create placeholders for episodes not yet aired</div>
          </div>
          <label class="toggle">
            <input type="checkbox" id="include_unreleased_episodes"
                   onchange="saveSetting('include_unreleased_episodes',this.checked)">
            <span class="slider"></span>
          </label>
        </div>
      </div>

      <div class="s-sect">
        <div class="s-title">🔍 Torrent Search</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px">
          <div class="field"><label>Completed Series Strategy</label>
            <select id="series_completed_strategy">
              <option value="series_pack">Series Pack (whole show)</option>
              <option value="season_pack">Season Pack</option>
              <option value="episode">Per Episode</option>
            </select></div>
          <div class="field"><label>Ongoing Series Strategy</label>
            <select id="series_ongoing_strategy">
              <option value="season_pack">Season Pack</option>
              <option value="episode">Per Episode</option>
              <option value="series_pack">Series Pack</option>
            </select></div>
          <div class="field"><label>Series Quality</label>
            <select id="series_preferred_quality">
              <option value="1080p">1080p</option><option value="720p">720p</option><option value="any">Any</option>
            </select></div>
          <div class="field"><label>Series Fallback Quality</label>
            <select id="series_fallback_any_quality">
              <option value="true">Yes — any quality</option><option value="false">No</option>
            </select></div>
          <div class="field"><label>Movie Quality</label>
            <select id="movie_preferred_quality">
              <option value="1080p">1080p</option><option value="720p">720p</option><option value="any">Any</option>
            </select></div>
          <div class="field"><label>Movie Fallback Quality</label>
            <select id="movie_fallback_any_quality">
              <option value="true">Yes — any quality</option><option value="false">No</option>
            </select></div>
          <div class="field"><label>Pre-cache Cooldown (min)</label>
            <input id="precache_cooldown_minutes" type="number" min="0" max="60" value="1"></div>
          <div class="field"><label>Cache TTL (days)</label>
            <input id="cache_ttl_days" type="number" min="1" max="90" value="30"></div>
        </div>
        <button class="btn btn-sec" onclick="saveSearch()" style="padding:8px 20px">💾 Save Search Settings</button>
        <div id="search-result" class="test-result" style="margin-top:10px"></div>
      </div>

      <div class="s-sect">
        <div class="s-title">🗂️ DFS Cache</div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:14px">
          <div class="field"><label>Cache Directory</label>
            <input id="dfs_cache_dir" type="text" value="/docker/debridarr/tmp/cache"></div>
          <div class="field"><label>Max Size (GB)</label>
            <input id="dfs_disk_cache_size_gb" type="number" value="30" min="1" max="1000"></div>
          <div class="field"><label>Expiry (hours)</label>
            <input id="dfs_cache_expiry_h" type="number" value="24" min="1" max="168"></div>
          <div class="field"><label>Chunk Size (MB)</label>
            <input id="dfs_chunk_size_mb" type="number" value="8" min="1" max="64"></div>
          <div class="field"><label>Read Ahead (MB)</label>
            <input id="dfs_read_ahead_mb" type="number" value="500" min="0" max="2000"></div>
          <div class="field"><label>Cleanup (min)</label>
            <input id="dfs_cleanup_interval_m" type="number" value="20" min="1" max="1440"></div>
        </div>
        <button class="btn btn-sec" onclick="saveDFS()" style="padding:8px 20px">💾 Save DFS</button>
        <div id="dfs-result" class="test-result" style="margin-top:10px"></div>
      </div>

      <div class="s-sect">
        <div class="s-title">System</div>
        {field("Timezone","TZ","","text","America/Edmonton")}
        <div style="display:flex;gap:12px">
          <div style="flex:1">{field("PUID","PUID","","text","1000")}</div>
          <div style="flex:1">{field("PGID","PGID","","text","1000")}</div>
        </div>
      </div>

      <div style="display:flex;gap:12px;margin-top:8px">
        <button class="btn btn-add" onclick="saveAll()" style="padding:10px 28px;font-size:0.9rem">💾 Save All Settings</button>
        <button class="btn btn-sec" onclick="testAll()" style="padding:10px 20px;font-size:0.9rem">🔌 Test All</button>
      </div>
      <div id="save-result" class="test-result" style="margin-top:14px"></div>
    </div>"""

    extra = f"""<style>
.s-sect {{ background:#1a1a24;border:1px solid #2a2a3a;border-radius:10px;padding:20px 24px;margin-bottom:16px; }}
.s-title {{ font-size:0.75rem;font-weight:700;text-transform:uppercase;color:#f97316;letter-spacing:.08em;margin-bottom:16px; }}
.field {{ margin-bottom:14px; }}
.field label {{ display:block;font-size:0.8rem;color:#888;margin-bottom:5px;font-weight:600; }}
.field input,.field select {{ width:100%;background:#0f0f13;border:1px solid #2a2a3a;border-radius:7px;
  padding:9px 13px;color:#e0e0e0;font-size:0.875rem;outline:none;font-family:monospace; }}
.field input:focus,.field select:focus {{ border-color:#f97316; }}
.field select {{ cursor:pointer;font-family:inherit; }}
.field .hint {{ font-size:0.74rem;color:#555;margin-top:4px;line-height:1.4; }}
.field .hint a {{ color:#f97316; }}
.saved-badge {{ display:inline-block;margin-left:8px;font-size:0.68rem;font-weight:700;
  background:#14532d;color:#4ade80;border-radius:4px;padding:1px 6px;text-transform:uppercase; }}
.test-result {{ margin-top:10px;padding:8px 12px;border-radius:6px;font-size:0.82rem;display:none; }}
.test-result.ok {{ background:#14532d;color:#4ade80;display:block; }}
.test-result.err {{ background:#3b0000;color:#f87171;display:block; }}
.test-result.testing {{ background:#1e1e2e;color:#aaa;display:block; }}
.toggle {{ position:relative;display:inline-block;width:44px;height:24px;flex-shrink:0; }}
.toggle input {{ opacity:0;width:0;height:0; }}
.slider {{ position:absolute;cursor:pointer;inset:0;background:#2a2a3a;border-radius:24px;transition:.2s; }}
.slider:before {{ position:absolute;content:"";height:18px;width:18px;left:3px;bottom:3px;
  background:#555;border-radius:50%;transition:.2s; }}
input:checked + .slider {{ background:#f97316; }}
input:checked + .slider:before {{ transform:translateX(20px);background:#fff; }}
</style>
<script>
const _SS = {all_settings!r};

function getVal(id) {{ const e=document.getElementById(id); return e?.value?.trim()||''; }}
function getFieldVal(id) {{
  const e=document.getElementById(id);
  if(!e) return null;
  const v=e.value.trim();
  if(!v && e.type==='password' && e.dataset.saved==='true') return null;
  return v||null;
}}

async function testConn(svc) {{
  const el=document.getElementById('test-'+svc);
  el.className='test-result testing'; el.textContent='Testing...';
  let body={{step:svc}};
  if(svc==='alldebrid') body.api_key=getVal('ALLDEBRID_API_KEY');
  if(svc==='overseerr') {{ body.url=getVal('OVERSEERR_URL'); body.api_key=getVal('OVERSEERR_API_KEY'); }}
  if(svc==='plex') body.plex_root=getVal('PLEX_ROOT');
  const r=await fetch('/setup/test',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify(body)}});
  const d=await r.json();
  el.className='test-result '+(d.ok?'ok':'err');
  el.textContent=(d.ok?'✅ ':'❌ ')+d.message;
}}

async function testAll() {{ await Promise.all(['alldebrid','overseerr','plex'].map(testConn)); }}

function loadSettings() {{
  const cb=document.getElementById('include_unreleased_episodes');
  if(cb) cb.checked=_SS.include_unreleased_episodes==='true';
  const searchKeys=['series_completed_strategy','series_ongoing_strategy','series_preferred_quality',
    'series_fallback_any_quality','movie_preferred_quality','movie_fallback_any_quality',
    'precache_cooldown_minutes','cache_ttl_days'];
  for(const k of searchKeys){{
    const e=document.getElementById(k);
    if(e&&_SS[k]!==undefined) e.value=_SS[k];
  }}
  fetch('/api/settings/dfs').then(r=>r.json()).then(dfs=>{{
    const m={{cache_dir:'dfs_cache_dir',disk_cache_size_gb:'dfs_disk_cache_size_gb',
      cache_expiry_h:'dfs_cache_expiry_h',chunk_size_mb:'dfs_chunk_size_mb',
      read_ahead_mb:'dfs_read_ahead_mb',cleanup_interval_m:'dfs_cleanup_interval_m'}};
    for(const[k,id] of Object.entries(m)){{
      const e=document.getElementById(id); if(e&&dfs[k]!==undefined) e.value=dfs[k];
    }}
  }}).catch(()=>{{}});
}}

async function saveSetting(key,value) {{
  const r=await fetch('/api/settings/behaviour',{{method:'POST',
    headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{key,value:value.toString()}})}});
  const d=await r.json();
  toast(r.ok?'✅ '+d.message:'❌ '+(d.detail||'Error'), r.ok);
}}

async function saveSearch() {{
  const res=document.getElementById('search-result');
  res.className='test-result testing'; res.style.display='block'; res.textContent='Saving...';
  const payload={{}};
  ['series_completed_strategy','series_ongoing_strategy','series_preferred_quality',
   'series_fallback_any_quality','movie_preferred_quality','movie_fallback_any_quality',
   'precache_cooldown_minutes','cache_ttl_days'].forEach(k=>{{
    const e=document.getElementById(k); if(e) payload[k]=e.value;
  }});
  const r=await fetch('/api/settings/search',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify(payload)}});
  const d=await r.json();
  res.className='test-result '+(r.ok?'ok':'err');
  res.textContent=r.ok?'✅ Saved':'❌ Save failed';
}}

async function saveDFS() {{
  const res=document.getElementById('dfs-result');
  res.className='test-result testing'; res.style.display='block'; res.textContent='Saving...';
  const payload={{
    cache_dir:document.getElementById('dfs_cache_dir').value||'/docker/debridarr/tmp/cache',
    disk_cache_size_gb:+document.getElementById('dfs_disk_cache_size_gb').value,
    cache_expiry_h:+document.getElementById('dfs_cache_expiry_h').value,
    chunk_size_mb:+document.getElementById('dfs_chunk_size_mb').value,
    read_ahead_mb:+document.getElementById('dfs_read_ahead_mb').value,
    cleanup_interval_m:+document.getElementById('dfs_cleanup_interval_m').value,
  }};
  const r=await fetch('/api/settings/dfs',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify(payload)}});
  const d=await r.json();
  res.className='test-result '+(r.ok?'ok':'err');
  res.textContent=r.ok?'✅ DFS settings saved':'❌ Save failed';
}}

async function saveAll() {{
  const res=document.getElementById('save-result');
  res.className='test-result testing'; res.textContent='Saving...';
  const raw={{
    ALLDEBRID_API_KEY:getFieldVal('ALLDEBRID_API_KEY'),
    OVERSEERR_URL:getFieldVal('OVERSEERR_URL'),
    OVERSEERR_API_KEY:getFieldVal('OVERSEERR_API_KEY'),
    TMDB_API_KEY:getFieldVal('TMDB_API_KEY'),
    DEBRIDARR_BASE_URL:getFieldVal('DEBRIDARR_BASE_URL'),
    PLEX_ROOT:getFieldVal('PLEX_ROOT'),
    TZ:getFieldVal('TZ'),
    PUID:getFieldVal('PUID'),
    PGID:getFieldVal('PGID'),
  }};
  const payload=Object.fromEntries(Object.entries(raw).filter(([_,v])=>v!==null));
  const r=await fetch('/api/settings/save',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify(payload)}});
  const d=await r.json();
  res.className='test-result '+(r.ok?'ok':'err');
  res.textContent=r.ok?'✅ '+d.message:'❌ '+(d.detail||'Save failed');
}}

loadSettings();
</script>"""
    return _page("Settings", "settings", body, extra)


# ── Settings API ──────────────────────────────────────────────────────────────
@app.post("/api/settings/save")
async def api_settings_save(request: Request):
    body = await request.json()
    cfg  = load_saved_config()
    allowed = {"ALLDEBRID_API_KEY","OVERSEERR_URL","OVERSEERR_API_KEY",
               "DEBRIDARR_BASE_URL","PLEX_ROOT","TZ","PUID","PGID"}
    for k, v in body.items():
        if k in allowed and v: cfg[k] = v
    if body.get("TMDB_API_KEY"):
        db: CacheDB = request.app.state.db
        db.set_setting("tmdb_api_key", body["TMDB_API_KEY"])
        if request.app.state.library:
            request.app.state.library.tmdb_key = body["TMDB_API_KEY"]
    write_env(cfg)
    import os
    for k, v in cfg.items(): os.environ[k] = v
    _init_clients(request.app)
    if request.app.state.library: request.app.state.library.invalidate_cache()
    log.info("⚙️  Settings updated — restarting...")
    _schedule_restart(delay=2.0)
    return {"status": "ok", "message": "Settings saved — restarting..."}


@app.post("/api/settings/search")
async def api_settings_search(request: Request):
    db: CacheDB = request.app.state.db
    payload = await request.json()
    allowed = {"series_completed_strategy","series_ongoing_strategy",
               "series_preferred_quality","series_fallback_any_quality",
               "precache_cooldown_minutes","movie_preferred_quality",
               "movie_fallback_any_quality","cache_ttl_days"}
    for k, v in payload.items():
        if k in allowed: db.set_setting(k, str(v))
    return {"status": "ok"}


@app.get("/api/settings/get")
async def api_settings_get(request: Request):
    db: CacheDB = request.app.state.db
    return db.get_all_settings()


@app.post("/api/settings/behaviour")
async def api_settings_behaviour(request: Request, background_tasks: BackgroundTasks):
    body  = await request.json()
    key   = body.get("key", "").strip()
    value = body.get("value", "").strip()
    if key not in {"include_unreleased_episodes"}:
        raise HTTPException(400, f"Unknown setting: {key}")
    db: CacheDB = request.app.state.db
    db.set_setting(key, value)
    if key == "include_unreleased_episodes":
        background_tasks.add_task(_sync_all_series_episodes, request.app, value == "true")
    return {"status": "ok", "message": f"{key} = {value}"}


@app.get("/api/settings/dfs")
async def api_settings_dfs_get():
    return get_dfs_settings()


@app.post("/api/settings/dfs")
async def api_settings_dfs_save(request: Request):
    body = await request.json()
    allowed = {"cache_dir","disk_cache_size_gb","cache_expiry_h","chunk_size_mb","read_ahead_mb","cleanup_interval_m"}
    cfg = {k: v for k, v in body.items() if k in allowed}
    for k in ("disk_cache_size_gb","cache_expiry_h","chunk_size_mb","read_ahead_mb","cleanup_interval_m"):
        if k in cfg:
            try: cfg[k] = int(cfg[k])
            except Exception: pass
    update_dfs_settings(cfg)
    db: CacheDB = request.app.state.db
    import json
    db.set_setting("dfs_settings", json.dumps(cfg))
    return {"status": "ok", "settings": get_dfs_settings()}


# ── Proxy / webhook / cache ───────────────────────────────────────────────────
@app.get("/webhook/test")
async def webhook_test():
    return {"status": "ok", "message": "Debridarr webhook is reachable"}

@app.get("/proxy/{cache_key}")
async def stream_proxy(cache_key: str, request: Request):
    return await proxy_stream(request, cache_key, request.app.state.db, request.app.state.alldebrid)

@app.post("/resolve")
async def manual_resolve(request: Request, background_tasks: BackgroundTasks):
    body  = await request.json()
    event = PlayEvent(media_type=MediaType(body["media_type"]), title=body["title"],
                      year=body.get("year"), season=body.get("season"), episode=body.get("episode"))
    background_tasks.add_task(resolve_and_cache, request.app, event)
    s = request.app.state.settings
    return {"status": "resolving", "cache_key": event.cache_key(),
            "proxy_url": f"{s.DEBRIDARR_BASE_URL}/proxy/{event.cache_key()}"}

@app.get("/cache")
async def list_cache(request: Request): return request.app.state.db.list_all()

@app.post("/cache/{cache_key}/expire")
async def expire_cache_entry(cache_key: str, request: Request, background_tasks: BackgroundTasks):
    """Hard reset a cache entry — deletes symlink, restores placeholder, removes from AllDebrid."""
    db        = request.app.state.db
    alldebrid = request.app.state.alldebrid
    s         = request.app.state.settings
    entry     = db.get(cache_key)
    if not entry:
        raise HTTPException(404, "Cache entry not found")

    # 1. Delete the symlink
    strm = entry.get("strm_path")
    if strm:
        p = Path(strm)
        if p.is_symlink():
            p.unlink(missing_ok=True)
            log.info(f"⏰ Expire {cache_key}: symlink deleted")

    # 2. Restore placeholder so Plex still sees the episode/movie
    if s.PLEX_ROOT:
        _restore_placeholder(cache_key, entry["title"], entry.get("year"),
                             entry.get("season"), entry.get("episode"),
                             entry["media_type"], s.PLEX_ROOT)

    # 3. Unregister from FUSE
    torrent_name = entry.get("torrent_name")
    if torrent_name and FUSE_AVAILABLE:
        # Only unregister if no other cached entry with an active symlink uses this torrent
        others = [e for e in db.list_all()
                  if e.get("torrent_name") == torrent_name
                  and e["cache_key"] != cache_key
                  and e["status"] == "cached"
                  and e.get("strm_path") and Path(e["strm_path"]).is_symlink()]
        if not others:
            unregister_torrent(torrent_name)
            log.info(f"⏰ Expire {cache_key}: FUSE unregistered {torrent_name!r}")

    # 4. Delete magnet from AllDebrid account
    background_tasks.add_task(_delete_from_alldebrid, alldebrid, entry.get("magnet_link"), cache_key)

    # 5. Mark as not_found in DB (not deleted — keeps the title visible in streams)
    db.update_status(cache_key, "not_found")

    log.info(f"⏰ Hard-expired {cache_key} — will re-cache on next play")
    return {"status": "expired", "cache_key": cache_key, "message": "Symlink removed — will re-cache on play"}


async def _delete_from_alldebrid(alldebrid, magnet_link: str, cache_key: str):
    """Delete magnet from AllDebrid account by matching info hash."""
    if not alldebrid or not magnet_link:
        return
    try:
        import re as _re
        m = _re.search(r"btih:([a-fA-F0-9]{40})", magnet_link or "", _re.I)
        if not m:
            log.debug(f"AllDebrid delete {cache_key}: no hash in magnet link")
            return
        info_hash = m.group(1).lower()

        # Get all torrents and find by hash
        import httpx as _hx
        import os as _os
        r = await _hx.AsyncClient(timeout=10).get(
            "https://api.alldebrid.com/v4.1/magnet/status",
            params={"agent": "debridarr", "apikey": alldebrid.api_key, "status": "ready"},
        )
        if r.status_code != 200:
            return
        data = r.json()
        magnets = data.get("data", {}).get("magnets", {})
        if isinstance(magnets, dict):
            magnets = list(magnets.values())

        for t in magnets:
            t_hash = t.get("hash", "").lower()
            if t_hash == info_hash:
                await alldebrid.delete_magnet(str(t["id"]))
                log.info(f"⏰ Deleted magnet {t['id']} from AllDebrid ({cache_key})")
                return
        log.debug(f"AllDebrid delete {cache_key}: hash {info_hash[:8]}... not found in account")
    except Exception as e:
        log.debug(f"AllDebrid delete {cache_key}: {e}")


@app.delete("/cache/{cache_key}")
async def delete_cache_entry(cache_key: str, request: Request):
    db = request.app.state.db
    entry = db.get(cache_key)
    s = request.app.state.settings
    if entry and s.PLEX_ROOT:
        delete_strm(cache_key=cache_key, title=entry["title"], year=entry.get("year"),
                    season=entry.get("season"), episode=entry.get("episode"),
                    media_type=entry["media_type"], plex_root=s.PLEX_ROOT)
    db.delete(cache_key)
    return {"status": "deleted"}

@app.get("/health")
async def health(): return {"status": "ok", "service": "debridarr", "version": "0.5.0"}


@app.post("/webhook/tautulli")
async def tautulli_webhook(request: Request, background_tasks: BackgroundTasks):
    try:    payload = await request.json()
    except: payload = dict(await request.form())

    log.info(f"📺 Tautulli: {payload}")
    media_type = payload.get("media_type", "")
    title      = payload.get("grandparent_title") or payload.get("title", "")
    year       = payload.get("year") or payload.get("grandparent_year")
    season     = payload.get("parent_media_index")
    episode    = payload.get("media_index")

    if media_type not in ("movie", "episode") or not title:
        return {"status": "ignored"}

    event = PlayEvent(
        media_type=MediaType(media_type), title=title,
        year=int(year) if year else None,
        season=int(season) if season else None,
        episode=int(episode) if episode else None,
        rating_key=payload.get("rating_key"),
        tmdb_id=payload.get("themoviedb_id") or payload.get("tmdb_id"),
        tvdb_id=payload.get("thetvdb_id") or payload.get("tvdb_id"),
        imdb_id=payload.get("imdb_id"),
    )
    log.info(f"📺 Resolving: {event.cache_key()} — {title} S{season}E{episode}")
    background_tasks.add_task(resolve_and_cache, request.app, event)
    return {"status": "accepted", "cache_key": event.cache_key()}


# ── Background helpers ────────────────────────────────────────────────────────

async def _precache_movie(app: FastAPI, title: str, year, tmdb_id, imdb_id):
    """Resolve and cache a movie immediately after it's added."""
    await asyncio.sleep(2)
    event = PlayEvent(
        media_type=MediaType.movie,
        title=title, year=year,
        tmdb_id=str(tmdb_id) if tmdb_id else None,
        imdb_id=str(imdb_id) if imdb_id else None,
    )
    log.info(f"🎬 Pre-caching movie: {title!r}")
    try:
        await resolve_and_cache(app, event)
    except Exception as e:
        log.error(f"Movie pre-cache {title!r}: {e}")


async def _precache_series(app: FastAPI, title: str, year, episodes: list):
    """
    Cache all episodes immediately after a series is added.
    Checks FUSE first (instant), falls back to TPB search.
    Skips episodes already cached or resolving.
    """
    if not episodes:
        log.info(f"📺 No episodes to pre-cache for {title!r}")
        return

    await asyncio.sleep(3)
    db       = app.state.db
    cooldown = int(db.get_setting("precache_cooldown_minutes", "1"))

    log.info(f"📺 Pre-caching {len(episodes)} episodes for {title!r}")
    cached_count = 0

    for ep in episodes:
        event = PlayEvent(
            media_type=MediaType.episode,
            title=title, year=year,
            season=ep["season"], episode=ep["episode"],
        )
        ck = event.cache_key()
        existing = db.get(ck)
        if existing and existing["status"] in ("cached", "resolving"):
            cached_count += 1
            continue
        try:
            await resolve_and_cache(app, event)
            cached_count += 1
            await asyncio.sleep(max(2, cooldown * 60))
        except Exception as e:
            log.debug(f"Episode pre-cache {ck}: {e}")

    log.info(f"📺 Pre-cache done: {title!r} — {cached_count}/{len(episodes)} episodes")


async def _fetch_tmdb_poster(tmdb_id, title: str, is_movie: bool, tmdb_key: str) -> str:
    """Fetch poster URL from TMDB — by ID first, title search fallback."""
    if not tmdb_key: return ""
    import httpx as _hx
    endpoint = "movie" if is_movie else "tv"
    try:
        async with _hx.AsyncClient(timeout=8) as c:
            if tmdb_id:
                r = await c.get(f"https://api.themoviedb.org/3/{endpoint}/{tmdb_id}",
                                params={"api_key": tmdb_key})
                if r.status_code == 200:
                    p = r.json().get("poster_path")
                    if p: return f"https://image.tmdb.org/t/p/w342{p}"
            # Fallback: search by title
            r2 = await c.get(f"https://api.themoviedb.org/3/search/{endpoint}",
                             params={"api_key": tmdb_key, "query": title})
            if r2.status_code == 200:
                results = r2.json().get("results", [])
                if results and results[0].get("poster_path"):
                    return f"https://image.tmdb.org/t/p/w342{results[0]['poster_path']}"
    except Exception:
        pass
    return ""


async def _cleanup_loop(app: FastAPI):
    """
    Hourly cleanup — only removes entries that have TRULY expired.
    If a symlink is still active, extend the TTL rather than deleting.
    Cache lifecycle:
      - Active symlink → extend TTL (keep streaming)
      - Expired + no symlink → remove from DB
      - User removes title → immediate cleanup via api_library_remove
    """
    while True:
        await asyncio.sleep(3600)
        db = app.state.db
        s  = app.state.settings
        from datetime import timedelta

        for entry in db.list_expired():
            ck   = entry["cache_key"]
            strm = entry.get("strm_path")

            # If symlink still exists → extend TTL by another TTL period
            # The file is still being used — don't pull it out from under Plex
            if strm and Path(strm).is_symlink():
                ttl = db.ttl_days()
                new_expires = (datetime.utcnow() + timedelta(days=ttl)).isoformat()
                with db._connect() as conn:
                    conn.execute(
                        "UPDATE cache SET expires_at=?, status='cached' WHERE cache_key=?",
                        (new_expires, ck)
                    )
                log.debug(f"⏰ Extended TTL for {ck} (symlink still active)")
                continue

            # No symlink — safe to clean up
            if entry.get("torrent_name") and FUSE_AVAILABLE:
                # Only unregister if no other cached entry uses this torrent
                others = [e for e in db.list_all()
                          if e.get("torrent_name") == entry["torrent_name"]
                          and e["cache_key"] != ck
                          and e["status"] == "cached"
                          and e.get("strm_path") and Path(e["strm_path"]).is_symlink()]
                if not others:
                    unregister_torrent(entry["torrent_name"])

            if s.PLEX_ROOT:
                _restore_placeholder(ck, entry["title"], entry.get("year"),
                                     entry.get("season"), entry.get("episode"),
                                     entry["media_type"], s.PLEX_ROOT)

        purged = db.purge_expired()
        if purged: log.info(f"⏰ Purged {purged} expired entries (no active symlinks)")


# Torrent sync loop intentionally removed.
# Comparing FUSE names against AllDebrid names is unreliable due to truncation
# and causes false-positive deletions of valid cached files.
# Cache lifecycle is managed by:
#   - TTL expiry (_cleanup_loop) — removes after 30 days
#   - User remove action (api_library_remove) — removes immediately
#   - Symlink health check (_check_and_repair_symlinks) — repairs broken symlinks hourly


def _restore_placeholder(cache_key, title, year, season, episode, media_type, plex_root):
    try:
        if media_type == "movie":
            yp     = f" ({year})" if year else ""
            folder = Path(plex_root) / "movies" / f"{title}{yp}"
            ph     = folder / f"{title}{yp}.mp4"
            # Remove stale symlinks before restoring placeholder
            if folder.exists():
                for f in folder.iterdir():
                    if f.is_symlink() and f.suffix in (".mkv",".mp4",".avi",".mov",".m4v"):
                        f.unlink(missing_ok=True)
        else:
            if not season or not episode: return
            folder = Path(plex_root) / "tv" / title / f"Season {season:02d}"
            se     = f"S{season:02d}E{episode:02d}"
            ph     = folder / f"{title} - {se}.mp4"
            if folder.exists():
                for f in folder.glob(f"*{se}*.mkv"):
                    if f.is_symlink(): f.unlink(missing_ok=True)
        folder.mkdir(parents=True, exist_ok=True)
        if not ph.exists() and not ph.is_symlink():
            ph.write_bytes(_FAKE_MP4)
    except Exception as e:
        log.error(f"restore_placeholder {cache_key}: {e}")


async def _episode_sync_loop(app: FastAPI):
    """Run at startup (+30s) and hourly — audit episode placeholders against TMDB."""
    await asyncio.sleep(30)
    while True:
        try:   await _run_episode_sync(app)
        except Exception as e: log.error(f"Episode sync: {e}")
        await asyncio.sleep(3600)


async def _run_episode_sync(app: FastAPI):
    lm  = app.state.library
    db  = app.state.db
    s   = app.state.settings
    if not lm or not s.PLEX_ROOT: return

    lm.invalidate_cache()
    series_list        = await lm.get_sonarr_series(force=True)
    added_series       = [r for r in db.fake_library_list() if r["media_type"] == "series"]
    include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"
    total_added = total_removed = 0

    # ── Audit plex-strm/movies — remove folders not in fake_library ───────────
    added_movies = {r["title"].lower() for r in db.fake_library_list() if r["media_type"] == "movie"}
    movies_root  = Path(s.PLEX_ROOT) / "movies"
    if movies_root.exists():
        for folder in movies_root.iterdir():
            if not folder.is_dir(): continue
            # Extract title from "Title (Year)" folder name
            folder_title = folder.name.rsplit(" (", 1)[0].lower()
            if folder_title not in added_movies:
                import shutil as _shutil
                _shutil.rmtree(folder, ignore_errors=True)
                log.info(f"🗑️  Removed stale movie folder: {folder.name}")

    # ── Audit plex-strm/tv — remove folders not in fake_library ──────────────
    added_tv  = {r["title"].lower() for r in db.fake_library_list() if r["media_type"] == "series"}
    tv_root   = Path(s.PLEX_ROOT) / "tv"
    if tv_root.exists():
        for folder in tv_root.iterdir():
            if not folder.is_dir(): continue
            if folder.name.lower() not in added_tv:
                import shutil as _shutil
                _shutil.rmtree(folder, ignore_errors=True)
                log.info(f"🗑️  Removed stale TV folder: {folder.name}")

    for entry in added_series:
        title     = entry["title"]
        sonarr_id = entry.get("sonarr_id")
        year      = entry.get("year")
        if not sonarr_id: continue

        updated = next((s for s in series_list if s.get("id") == sonarr_id), None)
        if not updated: continue

        requested_seasons = updated.get("requested_seasons", [])
        result = await lm.sync_series_episodes(title, sonarr_id, year, include_unreleased,
                                                requested_seasons=requested_seasons)
        total_added   += result.get("added", 0)
        total_removed += result.get("removed", 0)

        # Audit: ensure every expected episode has placeholder or symlink
        try:
            all_eps = await lm.get_episodes(sonarr_id,
                                                    include_unreleased=include_unreleased,
                                                    requested_seasons=requested_seasons or None)
            by_season: dict[int, set] = {}
            for ep in all_eps:
                by_season.setdefault(ep["season"], set()).add(ep["episode"])

            show_folder = Path(s.PLEX_ROOT) / "tv" / title
            for sn, ep_nums in by_season.items():
                sf = show_folder / f"Season {sn:02d}"
                sf.mkdir(parents=True, exist_ok=True)
                on_mp4 = set(); on_sym = set()
                if sf.exists():
                    for f in sf.iterdir():
                        m = re.search(rf"S{sn:02d}E(\d{{2}})", f.name, re.I)
                        if m:
                            n = int(m.group(1))
                            if f.is_symlink(): on_sym.add(n)
                            elif f.suffix == ".mp4": on_mp4.add(n)
                covered = on_mp4 | on_sym
                for ep_n in ep_nums - covered:
                    (sf / f"{title} - S{sn:02d}E{ep_n:02d}.mp4").write_bytes(_FAKE_MP4)
                    total_added += 1
                for ep_n in on_mp4 - ep_nums:
                    ph = sf / f"{title} - S{sn:02d}E{ep_n:02d}.mp4"
                    if ph.exists() and not ph.is_symlink():
                        ph.unlink(missing_ok=True)
                        total_removed += 1
        except Exception as e:
            log.debug(f"Audit {title}: {e}")

    if total_added or total_removed:
        log.info(f"🔄 Episode sync: +{total_added} placeholders, -{total_removed} removed")
    else:
        log.info("🔄 Episode sync: all correct")


async def _sync_all_series_episodes(app: FastAPI, include_unreleased: bool):
    db = app.state.db; lm = app.state.library
    if not lm: return
    for entry in db.fake_library_list(media_type="series"):
        sid = entry.get("sonarr_id")
        if sid:
            await lm.sync_series_episodes(entry["title"], sid, entry.get("year"), include_unreleased)


async def _load_all_torrents(app: FastAPI):
    await asyncio.sleep(2)
    alldebrid = app.state.alldebrid
    s = app.state.settings
    if not alldebrid or not FUSE_AVAILABLE or not getattr(app.state, "fuse_thread", None):
        return
    try:
        torrents = await alldebrid.get_all_torrents()
        for t in torrents:
            files       = t["files"]
            folder_name = t["name"]
            if files:
                stem = Path(files[0]["n"]).stem
                if stem and folder_name and stem.startswith(folder_name.rstrip("-")):
                    folder_name = stem
            register_torrent(folder_name, files)
            t["_folder"] = folder_name
        log.info(f"✅ {len(torrents)} torrents loaded into FUSE")
        if s.PLEX_ROOT:
            _restore_symlinks(app)
    except Exception as e:
        log.error(f"_load_all_torrents: {e}", exc_info=True)


def _restore_symlinks(app):
    """Recreate symlinks on startup using FUSE registry (never .exists() on FUSE paths)."""
    db = app.state.db; s = app.state.settings
    if not s.PLEX_ROOT or not s.FUSE_SYMLINK_ROOT: return
    restored = skipped = missing = 0

    for entry in db.list_all():
        if entry["status"] != "cached": continue
        strm = entry.get("strm_path")
        if strm:
            p = Path(strm)
            if p.is_symlink():
                target = str(p.readlink())
                if s.FUSE_SYMLINK_ROOT in target:
                    rel   = target.replace(s.FUSE_SYMLINK_ROOT, "").lstrip("/")
                    parts = rel.split("/", 1)
                    if len(parts) == 2 and get_torrent_file(parts[0], parts[1]):
                        skipped += 1; continue

        fuse_match = _find_in_fuse(entry["title"], entry.get("year"),
                                    entry.get("season"), entry.get("episode"))
        if not fuse_match: missing += 1; continue

        torrent_name, filename, _ = fuse_match
        fuse_virtual = get_fuse_path(torrent_name, filename, s.FUSE_SYMLINK_ROOT)
        link = _make_plex_symlink(
            entry["cache_key"], entry["title"], entry.get("year"),
            entry.get("season"), entry.get("episode"), entry["media_type"],
            s.PLEX_ROOT, fuse_virtual, filename,
        )
        if link:
            db.update_cached(entry["cache_key"], entry.get("magnet_link",""),
                             entry.get("stream_url",""), torrent_name,
                             entry.get("quality","unknown"), str(link))
            restored += 1

    log.info(f"✅ Symlinks: {skipped} OK, {restored} restored, {missing} not in FUSE")


async def _symlink_health_loop(app: FastAPI):
    # Wait for FUSE to stabilise
    prev = 0; stable = 0
    for _ in range(180):
        await asyncio.sleep(1)
        count = len(list_torrents())
        if count > 0 and count == prev:
            stable += 1
            if stable >= 5: break
        else: stable = 0
        prev = count

    log.info(f"Starting symlink health check ({prev} torrents in FUSE)")
    while True:
        try:   await _check_and_repair_symlinks(app)
        except Exception as e: log.error(f"Symlink health: {e}")
        await asyncio.sleep(3600)


async def _check_and_repair_symlinks(app: FastAPI):
    db = app.state.db; s = app.state.settings
    if not s.PLEX_ROOT: return

    cached  = [e for e in db.list_all() if e["status"] == "cached"]
    broken  = []; ok = 0

    for entry in cached:
        strm  = entry.get("strm_path")
        issue = None
        try:
            if strm:
                p = Path(strm)
                if not p.is_symlink():
                    issue = "missing"
                else:
                    target = str(p.readlink())
                    if s.FUSE_SYMLINK_ROOT in target:
                        rel   = target.replace(s.FUSE_SYMLINK_ROOT,"").lstrip("/")
                        parts = rel.split("/", 1)
                        if len(parts) == 2:
                            if get_torrent_file(parts[0], parts[1]):
                                ok += 1
                                db.refresh_ttl(ck)  # extend TTL while symlink is active
                            else:
                                m = _find_in_fuse(entry["title"], entry.get("year"),
                                                   entry.get("season"), entry.get("episode"))
                                issue = "FUSE key mismatch" if m else "not in FUSE"
                        else: ok += 1
                    else:
                        if p.exists(): ok += 1
                        else:          issue = "dangling"
            else:
                ok += 1  # no strm_path means no symlink expected yet
        except Exception as e:
            log.debug(f"Health check {entry['cache_key']}: {e}")

        if issue: broken.append((entry, issue))

    total = len(cached)
    if not broken:
        log.info(f"✅ Symlink check: {ok}/{total} OK"); return

    log.info(f"🔧 Symlink check: {len(broken)} broken, {ok} OK / {total}")

    # Write placeholders for all broken entries first
    for entry, _ in broken:
        try:
            mtype = entry["media_type"]; t = entry["title"]
            yr = entry.get("year"); sn = entry.get("season"); ep = entry.get("episode")
            if mtype == "movie":
                folder = Path(s.PLEX_ROOT) / "movies" / f"{t}{' ('+str(yr)+')' if yr else ''}"
                ph = folder / f"{t}{' ('+str(yr)+')' if yr else ''}.mp4"
            elif sn and ep:
                folder = Path(s.PLEX_ROOT) / "tv" / t / f"Season {sn:02d}"
                ph = folder / f"{t} - S{sn:02d}E{ep:02d}.mp4"
            else: continue
            folder.mkdir(parents=True, exist_ok=True)
            if not ph.exists() and not ph.is_symlink():
                ph.write_bytes(_FAKE_MP4)
        except Exception: pass

    for entry, issue in broken:
        log.info(f"  🔧 {entry['cache_key']}: {issue}")
        fuse_match = _find_in_fuse(entry["title"], entry.get("year"),
                                    entry.get("season"), entry.get("episode"))
        if fuse_match:
            torrent_name, filename, _ = fuse_match
            fuse_virtual = get_fuse_path(torrent_name, filename, s.FUSE_SYMLINK_ROOT)
            link = _make_plex_symlink(entry["cache_key"], entry["title"], entry.get("year"),
                                      entry.get("season"), entry.get("episode"), entry["media_type"],
                                      s.PLEX_ROOT, fuse_virtual, filename)
            if link:
                db.update_cached(entry["cache_key"], entry.get("magnet_link",""),
                                 entry.get("stream_url",""), torrent_name,
                                 entry.get("quality","unknown"), str(link))
                log.info(f"  ✅ Relinked: {entry['cache_key']}")
                continue

        # Not in FUSE — re-resolve (placeholder already written above)
        event = PlayEvent(media_type=MediaType(entry["media_type"]), title=entry["title"],
                          year=entry.get("year"), season=entry.get("season"), episode=entry.get("episode"))
        try:
            db.update_status(entry["cache_key"], "not_found")
            await resolve_and_cache(app, event)
            await asyncio.sleep(2)
        except Exception as e:
            db.update_status(entry["cache_key"], "cached")
            log.error(f"  ❌ Re-resolve failed: {entry['cache_key']}: {e}")


def _find_in_fuse(title: str, year, season, episode) -> Optional[tuple]:
    def norm(s):
        s = s.lower().replace("'","").replace("\u2019","")
        s = re.sub(r"[._]", " ", s)
        return s.split()

    title_words = norm(title)
    if not title_words: return None
    video_exts = {".mkv",".mp4",".avi",".mov",".m4v"}

    for torrent_name in list_torrents():
        t_words = norm(torrent_name)
        if not all(w in t_words for w in title_words): continue
        if year and str(year) not in torrent_name: continue
        for fname in list_files(torrent_name):
            if not any(fname.lower().endswith(e) for e in video_exts): continue
            if season and episode:
                if f"S{season:02d}E{episode:02d}".upper() not in fname.upper(): continue
            elif season:
                if f"S{season:02d}".upper() not in fname.upper(): continue
            f = get_torrent_file(torrent_name, fname)
            if f: return torrent_name, fname, f
    return None


def _detect_quality(name: str) -> str:
    n = name.lower()
    for q in ("2160p","4k","uhd","1080p","720p","480p"):
        if q in n: return q
    return "unknown"


def _make_plex_symlink(cache_key, title, year, season, episode,
                       media_type, plex_root, target, video_name) -> Optional[Path]:
    """Placeholder-first symlink creation. Never leaves Plex with an empty slot."""
    if media_type == "movie":
        yp     = f" ({year})" if year else ""
        folder = Path(plex_root) / "movies" / f"{title}{yp}"
        ph     = folder / f"{title}{yp}.mp4"
    else:
        sf     = f"Season {season:02d}" if season else "Season 00"
        folder = Path(plex_root) / "tv" / title / sf
        se     = f"S{season:02d}E{episode:02d}" if (season and episode) else "S00E00"
        ph     = folder / f"{title} - {se}.mp4"

    try:
        folder.mkdir(parents=True, exist_ok=True)
        if not ph.exists() and not ph.is_symlink():
            ph.write_bytes(_FAKE_MP4)
    except Exception as e:
        log.error(f"Placeholder write {cache_key}: {e}")

    try:
        # Remove stale symlinks for this episode
        if media_type == "movie":
            for f in folder.iterdir():
                if f.is_symlink() and f.suffix in (".mkv",".mp4",".avi",".mov",".m4v"):
                    f.unlink(missing_ok=True)
        elif season and episode:
            se_pat = f"S{season:02d}E{episode:02d}".upper()
            for f in folder.iterdir():
                if f.is_symlink() and se_pat in f.name.upper():
                    f.unlink(missing_ok=True)

        link = folder / video_name
        if link.is_symlink() or link.exists(): link.unlink(missing_ok=True)
        link.symlink_to(target)

        if link.is_symlink():
            if ph.exists() and not ph.is_symlink(): ph.unlink(missing_ok=True)
            log.info(f"🔗 Symlink: {link.name} → {target}")
            return link
        else:
            if not ph.exists(): ph.write_bytes(_FAKE_MP4)
            return None
    except Exception as e:
        log.error(f"symlink {cache_key}: {e}")
        try:
            if not ph.exists() and not ph.is_symlink():
                folder.mkdir(parents=True, exist_ok=True)
                ph.write_bytes(_FAKE_MP4)
        except Exception: pass
        return None


async def _verify_episode_with_tmdb(tmdb_id, tvdb_id, season, episode, title, tmdb_key=""):
    if not tmdb_key: return season, episode
    import httpx as _hx
    try:
        if tvdb_id:
            async with _hx.AsyncClient(timeout=10) as c:
                r = await c.get(f"https://api.themoviedb.org/3/find/{tvdb_id}",
                                params={"api_key": tmdb_key, "external_source": "tvdb_id"})
                if r.status_code == 200:
                    eps = r.json().get("tv_episode_results", [])
                    if eps:
                        e   = eps[0]
                        ts  = e.get("season_number", season)
                        tep = e.get("episode_number", episode)
                        if ts != season or tep != episode:
                            log.info(f"TMDB corrected {title} S{season:02d}E{episode:02d} → S{ts:02d}E{tep:02d}")
                        return ts, tep
    except Exception as e:
        log.debug(f"TMDB lookup {title}: {e}")
    return season, episode


async def resolve_and_cache(app: FastAPI, event: PlayEvent):
    db = app.state.db; alldebrid = app.state.alldebrid; s = app.state.settings
    cache_key = event.cache_key()

    existing = db.get(cache_key)
    if existing and existing["status"] == "cached":
        log.info(f"✅ Cache hit: {cache_key}")
        return

    log.info(f"🔍 Resolving: {cache_key}")
    db.upsert(cache_key, event, status="resolving")

    try:
        # Verify episode numbering
        if event.media_type.value == "episode" and event.season and event.episode:
            tmdb_key = db.get_setting("tmdb_api_key", "")
            cs, cep = await _verify_episode_with_tmdb(
                event.tmdb_id, event.tvdb_id, event.season, event.episode, event.title, tmdb_key)
            if cs != event.season or cep != event.episode:
                event      = event.model_copy(update={"season": cs, "episode": cep})
                cache_key  = event.cache_key()
                existing   = db.get(cache_key)
                if existing and existing["status"] == "cached":
                    log.info(f"✅ Cache hit (corrected): {cache_key}"); return
                db.upsert(cache_key, event, status="resolving")

        # Strategy
        s_cfg = db.get_all_settings()
        if event.media_type.value == "episode":
            lm = app.state.library; is_ended = False
            if lm:
                try:
                    sl = await lm.get_sonarr_series()
                    sm = next((x for x in sl if x["title"].lower() == event.title.lower()), None)
                    if sm: is_ended = sm.get("status","").lower() in ("ended","cancelled","canceled")
                except Exception: pass
            strategy         = s_cfg.get("series_completed_strategy","series_pack") if is_ended else s_cfg.get("series_ongoing_strategy","season_pack")
            preferred_quality = s_cfg.get("series_preferred_quality","1080p")
            fallback_any      = s_cfg.get("series_fallback_any_quality","true") == "true"
        else:
            strategy         = "movie"
            preferred_quality = s_cfg.get("movie_preferred_quality","1080p")
            fallback_any      = s_cfg.get("movie_fallback_any_quality","true") == "true"

        # Check FUSE first
        fuse_match = _find_in_fuse(event.title, event.year, event.season, event.episode)
        if fuse_match:
            torrent_name, filename, fuse_file = fuse_match
            log.info(f"✅ Found in FUSE — symlinking directly")
            fuse_virtual = get_fuse_path(torrent_name, filename, s.FUSE_SYMLINK_ROOT)
            link = _make_plex_symlink(cache_key, event.title, event.year, event.season,
                                      event.episode, event.media_type.value, s.PLEX_ROOT,
                                      fuse_virtual, filename)
            db.update_cached(cache_key, "", fuse_file.get("l",""), torrent_name,
                             _detect_quality(filename), str(link) if link else None)
            return

        # Search TPB
        log.info(f"🔎 Searching TPB for: {event.title!r}")
        results = await alldebrid.search_cached(
            title=event.title, media_type=event.media_type.value,
            year=event.year, season=event.season, episode=event.episode,
            imdb_id=event.imdb_id, strategy=strategy,
            preferred_quality=preferred_quality, fallback_any=fallback_any,
        )
        if not results:
            log.warning(f"❌ No results: {cache_key}")
            db.update_status(cache_key, "not_found"); return

        best = results[0]
        log.info(f"🎯 {best['name']} cached={best['cached']} q={best.get('quality','?')}")

        result = await alldebrid.add_magnet(best["magnet"])
        if not result:
            db.update_status(cache_key, "unlock_failed"); return

        magnet_id, files = result
        torrent_name = best["name"]

        # Find episode-specific file
        target_file = None
        if event.media_type.value == "episode" and event.season and event.episode:
            se_pat = f"S{event.season:02d}E{event.episode:02d}".upper()
            for f in files:
                if se_pat in f.get("n","").upper(): target_file = f; break
        if not target_file:
            target_file = max(files, key=lambda f: f.get("s",0))

        filename  = target_file.get("n", torrent_name)
        ad_link   = target_file.get("l","")
        file_size = target_file.get("s", 0)

        # Resolve FUSE folder name (handle truncated names)
        stem = Path(filename).stem if filename else torrent_name
        fuse_folder = stem if (stem and torrent_name and stem.startswith(torrent_name.rstrip("-"))) else torrent_name

        if not ad_link:
            log.error(f"No file link for {cache_key}")
            db.update_status(cache_key, "unlock_failed"); return

        log.info(f"📁 {fuse_folder}/{filename} ({file_size} bytes)")

        strm_path = None
        fuse_thread = getattr(app.state, "fuse_thread", None)

        if s.PLEX_ROOT:
            if FUSE_AVAILABLE and fuse_thread:
                register_torrent(fuse_folder, files)
                fuse_virtual = get_fuse_path(fuse_folder, filename, s.FUSE_SYMLINK_ROOT)
                log.info(f"📂 FUSE: {fuse_virtual}")
                link = _make_plex_symlink(cache_key, event.title, event.year, event.season,
                                          event.episode, event.media_type.value, s.PLEX_ROOT,
                                          fuse_virtual, filename)
                strm_path = str(link) if link else None
                log.info(f"🔗 {link} → {fuse_virtual}")
            else:
                p = write_strm(cache_key=cache_key, title=event.title, year=event.year,
                               season=event.season, episode=event.episode,
                               media_type=event.media_type.value,
                               debridarr_base_url=s.DEBRIDARR_BASE_URL, plex_root=s.PLEX_ROOT)
                strm_path = str(p) if p else None

        db.update_cached(cache_key, best["magnet"], ad_link, torrent_name,
                         best.get("quality","unknown"), strm_path)
        log.info(f"✅ Done: {cache_key}")

        if event.media_type.value == "episode" and event.season and event.episode:
            cooldown = int(db.get_setting("precache_cooldown_minutes","1"))
            asyncio.create_task(_precache_next_episodes(app, event, cooldown_minutes=cooldown))

    except Exception as e:
        log.error(f"❌ {cache_key}: {e}", exc_info=True)
        db.update_status(cache_key, "error")


async def _precache_next_episodes(app: FastAPI, event: PlayEvent, count: int = 3, cooldown_minutes: int = 1):
    await asyncio.sleep(5)
    db = app.state.db; lm = app.state.library
    title = event.title; season = event.season; episode = event.episode; year = event.year

    season_size = None
    if lm:
        try:
            sl = await lm.get_sonarr_series()
            series = next((s for s in sl if s["title"].lower() == title.lower()), None)
            if series:
                curr = next((s for s in series.get("seasons",[]) if s.get("season_number") == season), None)
                if curr: season_size = curr.get("episode_count")
        except Exception: pass

    if not season_size: return
    log.info(f"⏭️  Pre-caching '{title}' S{season:02d} ({season_size} eps)")

    all_eps = list(range(1, episode)) + list(range(episode+1, season_size+1))
    for ep in all_eps:
        fake = PlayEvent(media_type=event.media_type, title=title, year=year, season=season, episode=ep)
        ck   = fake.cache_key()
        existing = db.get(ck)
        if existing and existing["status"] in ("cached","resolving"): continue
        try:
            await resolve_and_cache(app, fake)
            await asyncio.sleep(max(3, cooldown_minutes * 60))
        except Exception as e:
            log.debug(f"Pre-cache {ck}: {e}")
