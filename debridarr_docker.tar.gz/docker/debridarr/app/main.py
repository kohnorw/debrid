"""
Debridarr - On-the-fly AllDebrid streaming for Plex

Flow:
  1. First run → setup wizard at /setup collects all config, tests live connections,
     writes /data/.env, reinitialises app without restart.
  2. User opens /library → browses Sonarr/Radarr → clicks Add → zero-byte .mkv created
  3. Plex scans the fake library, shows titles normally
  4. User hits Play → Tautulli webhook → Debridarr resolves real stream via AllDebrid
  5. /proxy/<key> streams bytes transparently, refreshing AllDebrid URLs as needed
"""

import asyncio
import importlib
import logging
import sys
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from app.alldebrid import AllDebridClient
from app.cache import CacheDB
from app.config import settings
from app.library import LibraryManager
from app.models import MediaType, PlayEvent
from app.proxy import proxy_stream, write_strm, delete_strm
from app.fuse_mount import (
    start_fuse_mount, stop_fuse_mount,
    register_torrent, unregister_torrent, get_fuse_path, list_torrents,
    FUSE_AVAILABLE, update_dfs_settings, get_dfs_settings,
)
from app.setup import (
    is_setup_complete, mark_setup_complete,
    load_saved_config, write_env,
    test_alldebrid, test_sonarr, test_radarr, test_plex_root,
)

logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("debridarr")


def _init_clients(app: FastAPI):
    """Initialise (or re-initialise) clients directly from os.environ.
    Never uses importlib.reload — that reads stale module-level values."""
    import os

    class _S:
        ALLDEBRID_API_KEY = os.environ.get("ALLDEBRID_API_KEY", "")
        OVERSEERR_URL     = os.environ.get("OVERSEERR_URL", "")
        OVERSEERR_API_KEY = os.environ.get("OVERSEERR_API_KEY", "")
        SONARR_URL        = os.environ.get("SONARR_URL", "")
        SONARR_API_KEY    = os.environ.get("SONARR_API_KEY", "")
        RADARR_URL        = os.environ.get("RADARR_URL", "")
        RADARR_API_KEY    = os.environ.get("RADARR_API_KEY", "")
        PLEX_ROOT         = os.environ.get("PLEX_ROOT", "/plex-strm")
        DEBRIDARR_BASE_URL= os.environ.get("DEBRIDARR_BASE_URL", "")
        DB_PATH           = os.environ.get("DB_PATH", "/data/debridarr.db")
        PORT              = int(os.environ.get("PORT", "7474"))
        LOG_LEVEL         = os.environ.get("LOG_LEVEL", "INFO")
        CACHE_TTL_DAYS    = int(os.environ.get("CACHE_TTL_DAYS", "30"))
        FUSE_MOUNT        = os.environ.get("FUSE_MOUNT", "/mnt/alldebrid")
        # Host path written into symlinks so Plex (outside container) resolves them
        FUSE_SYMLINK_ROOT = os.environ.get("FUSE_SYMLINK_ROOT", "/docker/debridarr/mnt-alldebrid")

    s = _S()
    app.state.alldebrid = AllDebridClient(s.ALLDEBRID_API_KEY)
    app.state.library = LibraryManager(
        overseerr_url=s.OVERSEERR_URL,
        overseerr_key=s.OVERSEERR_API_KEY,
        plex_root=s.PLEX_ROOT,
    )
    app.state.settings = s
    app.state.fuse_thread = getattr(app.state, "fuse_thread", None)  # preserve existing
    log.info(f"✅ Clients initialised — overseerr={s.OVERSEERR_URL or 'not set'}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info("🚀 Debridarr starting up...")

    # Load /data/.env into os.environ first — this is where the wizard saves config.
    # Docker env vars take precedence if already set (so compose overrides still work).
    import os
    from pathlib import Path as _Path
    _data_env = _Path("/data/.env")
    if _data_env.exists():
        log.info(f"📂 Loading saved config from {_data_env}")
        for line in _data_env.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            k = k.strip()
            v = v.strip()
            # Only set if not already provided by Docker (compose env vars win)
            if k and v and not os.environ.get(k):
                os.environ[k] = v
                log.debug(f"  Loaded {k} from /data/.env")

    db = CacheDB(settings.DB_PATH)
    db.init()
    app.state.db = db
    app.state.setup_complete = is_setup_complete()

    if app.state.setup_complete:
        _init_clients(app)
        s = app.state.settings
        log.info(f"✅ Debridarr ready  plex_root={s.PLEX_ROOT or 'NOT SET'}")
        # Load saved DFS settings from DB
    try:
        import json as _json
        saved_dfs = db.get_setting("dfs_settings")
        if saved_dfs:
            update_dfs_settings(_json.loads(saved_dfs))
            log.info("📂 Loaded DFS settings from DB")
    except Exception as _e:
        log.debug(f"No saved DFS settings: {_e}")

    # Start FUSE with the actual running event loop (must be async context)
        if FUSE_AVAILABLE:
            _loop = asyncio.get_event_loop()
            _t = start_fuse_mount(s.FUSE_MOUNT, app.state.alldebrid, _loop)
            app.state.fuse_thread = _t
            app._fuse_started = True
            if _t:
                log.info(f"🗂️  FUSE mount started at {s.FUSE_MOUNT}")
                # Load ALL torrents from AllDebrid account into FUSE on startup
                asyncio.create_task(_load_all_torrents(app))
                asyncio.create_task(_torrent_sync_loop(app))
        else:
            app.state.fuse_thread = None
            log.warning("⚠️  FUSE unavailable — using HTTP proxy fallback")



    else:
        log.info("⚙️  First run — setup wizard active at http://localhost:7474/setup")
        app.state.alldebrid = None
        app.state.library = None
        app.state.settings = settings

    async def cleanup_loop():
        while True:
            await asyncio.sleep(3600)
            if not app.state.setup_complete:
                continue
            s = app.state.settings
            expired = db.list_expired()
            for entry in expired:
                ck         = entry["cache_key"]
                title      = entry["title"]
                year       = entry.get("year")
                season     = entry.get("season")
                episode    = entry.get("episode")
                media_type = entry["media_type"]
                torrent    = entry.get("torrent_name", "")

                # Remove from FUSE
                if torrent and FUSE_AVAILABLE:
                    unregister_torrent(torrent)

                # Remove symlink + restore placeholder
                if s.PLEX_ROOT:
                    _restore_placeholder(ck, title, year, season, episode,
                                        media_type, s.PLEX_ROOT)

                log.info(f"⏰ Expired: {ck} — symlink removed, placeholder restored")

            purged = db.purge_expired()
            if purged:
                log.info(f"🗑️  Purged {purged} expired cache entries ({db._ttl_days()}d TTL)")

    asyncio.create_task(cleanup_loop())
    yield
    # Shutdown
    if getattr(app.state, "fuse_thread", None):
        s = app.state.settings
        stop_fuse_mount(s.FUSE_MOUNT)


app = FastAPI(title="Debridarr", version="0.4.0", lifespan=lifespan)

# ── Setup guard — simple helper, no middleware ────────────────────────────────
def _needs_setup(request: Request) -> bool:
    """Return True if setup has not been completed."""
    return not getattr(request.app.state, "setup_complete", False)

def _setup_redirect():
    return RedirectResponse("/setup", status_code=302)


# ─────────────────────────────────────────────────────────────────────────────
# Shared styles
# ─────────────────────────────────────────────────────────────────────────────
_BASE_STYLE = """
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
       background: #0f0f13; color: #e0e0e0; min-height: 100vh; }
header { background: #1a1a24; border-bottom: 1px solid #2a2a3a;
         padding: 14px 28px; display: flex; align-items: center; gap: 16px; }
header h1 { font-size: 1.3rem; color: #fff; }
header .ver { font-size: 0.75rem; background: #f97316; color: #fff;
              border-radius: 4px; padding: 2px 8px; }
nav { display: flex; gap: 4px; margin-left: auto; }
nav a { color: #aaa; text-decoration: none; padding: 6px 14px; border-radius: 6px;
        font-size: 0.85rem; transition: background .15s; }
nav a:hover, nav a.active { background: #2a2a3a; color: #fff; }
main { padding: 28px; max-width: 1400px; margin: 0 auto; }
h2 { font-size: 1.05rem; color: #ccc; margin-bottom: 18px; }
.card-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 16px; }
.card { background: #1a1a24; border: 1px solid #2a2a3a; border-radius: 10px; overflow: hidden; position: relative; }
.card img { width: 100%; aspect-ratio: 2/3; object-fit: cover; background: #111; display: block; }
.card .info { padding: 10px 12px; }
.card .title { font-size: 0.88rem; font-weight: 600; color: #e0e0e0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.card .meta  { font-size: 0.75rem; color: #666; margin-top: 2px; }
.card .actions { padding: 0 12px 12px; display: flex; gap: 6px; }
.btn { display: inline-block; padding: 5px 12px; border-radius: 6px; font-size: 0.78rem;
       font-weight: 600; border: none; cursor: pointer; text-decoration: none; transition: opacity .15s; }
.btn-add  { background: #f97316; color: #fff; }
.btn-add:hover { opacity: .85; }
.btn-rem  { background: #3b1f00; color: #fb923c; }
.btn-sec  { background: #1e3a5f; color: #60a5fa; }
.badge-in { position: absolute; top: 8px; right: 8px; background: #14532d;
            color: #4ade80; font-size: 0.7rem; font-weight: 700; padding: 2px 7px; border-radius: 20px; }
.search-bar { display: flex; gap: 10px; margin-bottom: 20px; }
.search-bar input { flex: 1; background: #1a1a24; border: 1px solid #2a2a3a;
                    border-radius: 8px; padding: 9px 14px; color: #e0e0e0; font-size: 0.9rem; outline: none; }
.search-bar input:focus { border-color: #f97316; }
.tabs { display: flex; gap: 2px; margin-bottom: 20px; }
.tab { padding: 8px 20px; border-radius: 8px; cursor: pointer; font-size: 0.85rem;
       font-weight: 600; border: 1px solid #2a2a3a; background: #1a1a24; color: #888; }
.tab.active { background: #f97316; color: #fff; border-color: #f97316; }
.empty { text-align: center; padding: 60px; color: #444; font-size: 0.9rem; }
.toast { position: fixed; bottom: 24px; right: 24px; background: #1a1a24; border: 1px solid #2a2a3a;
         border-radius: 10px; padding: 12px 20px; font-size: 0.85rem; opacity: 0; transition: opacity .3s; z-index: 999; }
.toast.show { opacity: 1; }
table { width: 100%; border-collapse: collapse; background: #1a1a24; border-radius: 10px; overflow: hidden; }
th { text-align: left; padding: 11px 14px; font-size: 0.72rem; text-transform: uppercase;
     color: #555; border-bottom: 1px solid #2a2a3a; }
td { padding: 11px 14px; border-bottom: 1px solid #1e1e2e; font-size: 0.875rem; }
tr:last-child td { border-bottom: none; }
.pill { padding: 2px 9px; border-radius: 20px; font-size: 0.72rem; font-weight: 600; display: inline-block; }
.pill-ok   { background: #14532d; color: #4ade80; }
.pill-res  { background: #1e3a5f; color: #60a5fa; }
.pill-err  { background: #3b0000; color: #f87171; }
.pill-pend { background: #2d2d00; color: #facc15; }
.pill-nf   { background: #3b1f00; color: #fb923c; }
"""

_NAV = lambda active: f"""
<nav>
  <a href="/library"    class="{'active' if active=='library'    else ''}">📚 Add to Library</a>
  <a href="/my-library" class="{'active' if active=='my-library' else ''}">🎬 My Library</a>
  <a href="/streams"    class="{'active' if active=='streams'    else ''}">⚡ Streams</a>
  <a href="/settings"   class="{'active' if active=='settings'   else ''}">⚙️ Settings</a>
</nav>"""

_TOAST_JS = """
function toast(msg, ok=true) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.style.borderColor = ok ? '#4ade80' : '#f87171';
  t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 3500);
}"""

def _page(title: str, nav_active: str, body: str, extra_head: str = "") -> HTMLResponse:
    return HTMLResponse(f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>{title} — Debridarr</title>
  <style>{_BASE_STYLE}</style>{extra_head}
</head>
<body>
  <header>
    <h1>🎬 Debridarr</h1><span class="ver">v0.4.0</span>
    {_NAV(nav_active)}
  </header>
  <main>{body}</main>
  <div id="toast" class="toast"></div>
  <script>{_TOAST_JS}</script>
</body>
</html>""")


# ─────────────────────────────────────────────────────────────────────────────
# Setup wizard styles (standalone, no nav)
# ─────────────────────────────────────────────────────────────────────────────
_SETUP_STYLE = _BASE_STYLE + """
.wizard { max-width: 620px; margin: 60px auto; }
.wizard-card { background: #1a1a24; border: 1px solid #2a2a3a; border-radius: 14px; padding: 36px; }
.wizard h2 { font-size: 1.4rem; color: #fff; margin-bottom: 6px; }
.wizard .sub { color: #666; font-size: 0.88rem; margin-bottom: 28px; line-height: 1.5; }
.steps { display: flex; gap: 0; margin-bottom: 32px; }
.step { flex: 1; text-align: center; font-size: 0.7rem; color: #444; padding-bottom: 8px;
        border-bottom: 2px solid #2a2a3a; position: relative; }
.step.done  { color: #4ade80; border-color: #4ade80; }
.step.active{ color: #f97316; border-color: #f97316; font-weight: 700; }
.field { margin-bottom: 20px; }
.field label { display: block; font-size: 0.8rem; color: #888; margin-bottom: 6px; font-weight: 600; }
.field input { width: 100%; background: #0f0f13; border: 1px solid #2a2a3a; border-radius: 8px;
               padding: 10px 14px; color: #e0e0e0; font-size: 0.9rem; outline: none;
               font-family: monospace; }
.field input:focus { border-color: #f97316; }
.field .hint { font-size: 0.75rem; color: #555; margin-top: 5px; line-height: 1.4; }
.field .hint a { color: #f97316; }
.test-result { margin-top: 10px; padding: 8px 12px; border-radius: 6px; font-size: 0.82rem;
               display: none; }
.test-result.ok  { background: #14532d; color: #4ade80; display: block; }
.test-result.err { background: #3b0000; color: #f87171; display: block; }
.test-result.testing { background: #1e1e2e; color: #aaa; display: block; }
.row { display: flex; gap: 10px; }
.row .field { flex: 1; }
.actions { display: flex; gap: 10px; margin-top: 28px; justify-content: flex-end; }
.btn-primary { background: #f97316; color: #fff; padding: 10px 24px; border-radius: 8px;
               font-size: 0.9rem; font-weight: 600; border: none; cursor: pointer; }
.btn-primary:hover { opacity: .85; }
.btn-primary:disabled { opacity: .4; cursor: not-allowed; }
.btn-ghost { background: transparent; color: #666; padding: 10px 16px; border-radius: 8px;
             font-size: 0.9rem; border: 1px solid #2a2a3a; cursor: pointer; }
.btn-ghost:hover { color: #ccc; border-color: #444; }
.welcome-icon { font-size: 4rem; text-align: center; margin-bottom: 20px; }
.confirm-row { display: flex; justify-content: space-between; padding: 10px 0;
               border-bottom: 1px solid #1e1e2e; font-size: 0.875rem; }
.confirm-row:last-child { border-bottom: none; }
.confirm-row .lbl { color: #666; }
.confirm-row .val { color: #e0e0e0; font-family: monospace; font-size: 0.82rem; }
"""

def _setup_page(body: str, step: str) -> HTMLResponse:
    step_names = ["Welcome", "AllDebrid", "Sonarr", "Radarr", "Plex Path", "Confirm"]
    step_keys  = ["welcome", "alldebrid", "sonarr", "radarr", "plex", "confirm"]
    idx = step_keys.index(step) if step in step_keys else 0
    steps_html = "".join(
        f'<div class="step {"done" if i < idx else "active" if i == idx else ""}">{n}</div>'
        for i, n in enumerate(step_names)
    )
    return HTMLResponse(f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Debridarr Setup</title>
  <style>{_SETUP_STYLE}</style>
</head>
<body>
  <header>
    <h1>🎬 Debridarr</h1><span class="ver">v0.4.0</span>
    <span style="margin-left:auto;color:#555;font-size:0.8rem">First-run setup</span>
  </header>
  <div class="wizard">
    <div class="steps">{steps_html}</div>
    <div class="wizard-card">{body}</div>
  </div>
  <div id="toast" class="toast"></div>
  <script>{_TOAST_JS}</script>
</body>
</html>""")


# ─────────────────────────────────────────────────────────────────────────────
# Setup wizard pages
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/setup", response_class=HTMLResponse)
async def setup_get(request: Request, step: str = "welcome"):
    try:
        cfg = load_saved_config()
    except Exception:
        cfg = {}

    if step == "welcome":
        body = """
        <div class="welcome-icon">🎬</div>
        <h2>Welcome to Debridarr</h2>
        <p class="sub">This wizard will connect Debridarr to AllDebrid, Sonarr, and Radarr.
        It takes about 2 minutes. All settings are tested live before saving.</p>
        <div class="actions">
          <a href="/setup?step=alldebrid" class="btn-primary" style="text-decoration:none;display:inline-block;padding:10px 24px">Get Started →</a>
        </div>"""
        return _setup_page(body, "welcome")

    if step == "alldebrid":
        val = cfg.get("ALLDEBRID_API_KEY", "")
        body = f"""
        <h2>AllDebrid</h2>
        <p class="sub">Debridarr uses AllDebrid to find and stream cached torrents instantly.</p>
        <div class="field">
          <label>API Key</label>
          <input id="api_key" type="password" value="{val}" placeholder="Paste your AllDebrid API key">
          <div class="hint">Get yours at <a href="https://alldebrid.com/apikeys" target="_blank">alldebrid.com/apikeys</a> → Create a key → Copy it here.</div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="actions">
          <a href="/setup?step=welcome" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="test-btn" onclick="testAndNext()">Test & Continue →</button>
        </div>
        <script>
        async function testAndNext() {{
          const key = document.getElementById('api_key').value.trim();
          const res = document.getElementById('test-result');
          const btn = document.getElementById('test-btn');
          if (!key) {{ res.className='test-result err'; res.textContent='API key required'; return; }}
          res.className='test-result testing'; res.textContent='Testing connection...';
          btn.disabled = true;
          const r = await fetch('/setup/test', {{
            method:'POST', headers:{{'Content-Type':'application/json'}},
            body: JSON.stringify({{step:'alldebrid', api_key: key}})
          }});
          const d = await r.json();
          btn.disabled = false;
          if (d.ok) {{
            res.className='test-result ok'; res.textContent='✅ ' + d.message;
            setTimeout(() => window.location='/setup?step=sonarr&alldebrid_key=' + encodeURIComponent(key), 800);
          }} else {{
            res.className='test-result err'; res.textContent='❌ ' + d.message;
          }}
        }}
        document.getElementById('api_key').addEventListener('keydown', e => {{ if(e.key==='Enter') testAndNext(); }});
        </script>"""
        return _setup_page(body, "alldebrid")

    if step == "sonarr":
        url_val = cfg.get("SONARR_URL", "http://192.168.1.x:8989")
        key_val = cfg.get("SONARR_API_KEY", "")
        alldebrid_key = request.query_params.get("alldebrid_key", cfg.get("ALLDEBRID_API_KEY",""))
        body = f"""
        <h2>Sonarr</h2>
        <p class="sub">Connect to your existing Sonarr instance so Debridarr can browse your TV library.</p>
        <div class="row">
          <div class="field">
            <label>Sonarr URL</label>
            <input id="sonarr_url" type="text" value="{url_val}" placeholder="http://192.168.1.x:8989">
            <div class="hint">Use the LAN IP of the machine running Sonarr.</div>
          </div>
        </div>
        <div class="field">
          <label>API Key</label>
          <input id="sonarr_key" type="password" value="{key_val}" placeholder="Sonarr API key">
          <div class="hint">Sonarr → Settings → General → Security → API Key</div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="actions">
          <a href="/setup?step=alldebrid" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="test-btn" onclick="testAndNext()">Test & Continue →</button>
        </div>
        <input type="hidden" id="alldebrid_key" value="{alldebrid_key}">
        <script>
        async function testAndNext() {{
          const url = document.getElementById('sonarr_url').value.trim();
          const key = document.getElementById('sonarr_key').value.trim();
          const akey = document.getElementById('alldebrid_key').value;
          const res = document.getElementById('test-result');
          const btn = document.getElementById('test-btn');
          res.className='test-result testing'; res.textContent='Testing connection...';
          btn.disabled = true;
          const r = await fetch('/setup/test', {{
            method:'POST', headers:{{'Content-Type':'application/json'}},
            body: JSON.stringify({{step:'sonarr', url, api_key: key}})
          }});
          const d = await r.json();
          btn.disabled = false;
          if (d.ok) {{
            res.className='test-result ok'; res.textContent='✅ ' + d.message;
            setTimeout(() => window.location='/setup?step=radarr&alldebrid_key='+encodeURIComponent(akey)+'&sonarr_url='+encodeURIComponent(url)+'&sonarr_key='+encodeURIComponent(key), 800);
          }} else {{
            res.className='test-result err'; res.textContent='❌ ' + d.message;
          }}
        }}
        </script>"""
        return _setup_page(body, "sonarr")

    if step == "radarr":
        url_val = cfg.get("RADARR_URL", "http://192.168.1.x:7878")
        key_val = cfg.get("RADARR_API_KEY", "")
        qs = dict(request.query_params)
        hidden = "".join(f'<input type="hidden" id="{k}" value="{v}">' for k, v in qs.items())
        body = f"""
        <h2>Radarr</h2>
        <p class="sub">Connect to your existing Radarr instance for your movie library.</p>
        <div class="field">
          <label>Radarr URL</label>
          <input id="radarr_url" type="text" value="{url_val}" placeholder="http://192.168.1.x:7878">
          <div class="hint">Use the LAN IP of the machine running Radarr.</div>
        </div>
        <div class="field">
          <label>API Key</label>
          <input id="radarr_key" type="password" value="{key_val}" placeholder="Radarr API key">
          <div class="hint">Radarr → Settings → General → Security → API Key</div>
          <div id="test-result" class="test-result"></div>
        </div>
        {hidden}
        <div class="actions">
          <a href="/setup?step=sonarr" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="test-btn" onclick="testAndNext()">Test & Continue →</button>
        </div>
        <script>
        async function testAndNext() {{
          const url = document.getElementById('radarr_url').value.trim();
          const key = document.getElementById('radarr_key').value.trim();
          const res = document.getElementById('test-result');
          const btn = document.getElementById('test-btn');
          res.className='test-result testing'; res.textContent='Testing connection...';
          btn.disabled = true;
          const r = await fetch('/setup/test', {{
            method:'POST', headers:{{'Content-Type':'application/json'}},
            body: JSON.stringify({{step:'radarr', url, api_key: key}})
          }});
          const d = await r.json();
          btn.disabled = false;
          if (d.ok) {{
            res.className='test-result ok'; res.textContent='✅ ' + d.message;
            const prev = {{}};
            document.querySelectorAll('input[type=hidden]').forEach(i => prev[i.id]=i.value);
            const params = new URLSearchParams({{...prev, step:'plex', radarr_url:url, radarr_key:key}});
            setTimeout(() => window.location='/setup?' + params.toString(), 800);
          }} else {{
            res.className='test-result err'; res.textContent='❌ ' + d.message;
          }}
        }}
        </script>"""
        return _setup_page(body, "radarr")

    if step == "plex":
        qs = dict(request.query_params)
        hidden = "".join(f'<input type="hidden" id="{k}" value="{v}">' for k, v in qs.items() if k != "step")
        tz_val = cfg.get("TZ", "America/Edmonton")
        puid_val = cfg.get("PUID", "1000")
        pgid_val = cfg.get("PGID", "1000")
        base_url_val = cfg.get("DEBRIDARR_BASE_URL", "http://192.168.1.x:7474")
        body = f"""
        <h2>Plex Integration</h2>
        <p class="sub">Tell Debridarr where to write fake library files, and how Plex reaches it over the network.</p>
        <div class="field">
          <label>Plex Library Path <span style="color:#555">(inside this container)</span></label>
          <input id="plex_root" type="text" value="/plex-strm" placeholder="/plex-strm">
          <div class="hint">This must be bind-mounted into both Debridarr and Plex. The default <code>/plex-strm</code> matches the docker-compose volume.</div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="field">
          <label>Debridarr Base URL <span style="color:#555">(as seen by Plex)</span></label>
          <input id="base_url" type="text" value="{base_url_val}" placeholder="http://192.168.1.x:7474">
          <div class="hint">Written into every .strm file. Plex must be able to reach this address. Use your server's LAN IP.</div>
        </div>
        <div class="row">
          <div class="field">
            <label>Timezone</label>
            <input id="tz" type="text" value="{tz_val}" placeholder="America/Edmonton">
            <div class="hint"><a href="https://en.wikipedia.org/wiki/List_of_tz_database_time_zones" target="_blank">TZ list</a></div>
          </div>
          <div class="field">
            <label>PUID</label>
            <input id="puid" type="text" value="{puid_val}" placeholder="1000">
            <div class="hint">Run: <code>id -u</code></div>
          </div>
          <div class="field">
            <label>PGID</label>
            <input id="pgid" type="text" value="{pgid_val}" placeholder="1000">
            <div class="hint">Run: <code>id -g</code></div>
          </div>
        </div>
        {hidden}
        <div class="actions">
          <a href="/setup?step=radarr" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="test-btn" onclick="testAndNext()">Test & Continue →</button>
        </div>
        <script>
        async function testAndNext() {{
          const plex_root = document.getElementById('plex_root').value.trim();
          const res = document.getElementById('test-result');
          const btn = document.getElementById('test-btn');
          res.className='test-result testing'; res.textContent='Checking path is writable...';
          btn.disabled = true;
          const r = await fetch('/setup/test', {{
            method:'POST', headers:{{'Content-Type':'application/json'}},
            body: JSON.stringify({{step:'plex', plex_root}})
          }});
          const d = await r.json();
          btn.disabled = false;
          if (d.ok) {{
            res.className='test-result ok'; res.textContent='✅ ' + d.message;
            const prev = {{}};
            document.querySelectorAll('input[type=hidden]').forEach(i => prev[i.id]=i.value);
            const params = new URLSearchParams({{
              ...prev, step:'confirm',
              plex_root, base_url: document.getElementById('base_url').value.trim(),
              tz: document.getElementById('tz').value.trim(),
              puid: document.getElementById('puid').value.trim(),
              pgid: document.getElementById('pgid').value.trim(),
            }});
            setTimeout(() => window.location='/setup?' + params.toString(), 800);
          }} else {{
            res.className='test-result err'; res.textContent='❌ ' + d.message;
          }}
        }}
        </script>"""
        return _setup_page(body, "plex")

    if step == "confirm":
        qs = dict(request.query_params)
        def row(label, key, mask=False):
            val = qs.get(key, "—")
            display = ("*" * 8 + val[-4:]) if mask and val and val != "—" else val
            return f'<div class="confirm-row"><span class="lbl">{label}</span><span class="val">{display}</span></div>'

        hidden = "".join(f'<input type="hidden" name="{k}" value="{v}">' for k, v in qs.items() if k != "step")
        body = f"""
        <h2>Confirm & Save</h2>
        <p class="sub">Everything looks good. Review your settings and click Save to finish setup.</p>
        <div style="margin-bottom:24px">
          {row("AllDebrid API Key", "alldebrid_key", mask=True)}
          {row("Sonarr URL", "sonarr_url")}
          {row("Sonarr API Key", "sonarr_key", mask=True)}
          {row("Radarr URL", "radarr_url")}
          {row("Radarr API Key", "radarr_key", mask=True)}
          {row("Plex Library Path", "plex_root")}
          {row("Debridarr Base URL", "base_url")}
          {row("Timezone", "tz")}
          {row("PUID / PGID", "puid")} 
        </div>
        <form method="POST" action="/setup/save">
          {hidden}
          <div class="actions">
            <a href="/setup?step=plex" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
            <button type="submit" class="btn-primary">💾 Save & Finish</button>
          </div>
        </form>"""
        return _setup_page(body, "confirm")

    return RedirectResponse("/setup")


# ── Setup: live test endpoint ─────────────────────────────────────────────────
@app.post("/setup/test")
async def setup_test(request: Request):
    body = await request.json()
    step = body.get("step")

    if step == "alldebrid":
        ok, msg = await test_alldebrid(body.get("api_key", ""))
    elif step == "sonarr":
        ok, msg = await test_sonarr(body.get("url", ""), body.get("api_key", ""))
    elif step == "radarr":
        ok, msg = await test_radarr(body.get("url", ""), body.get("api_key", ""))
    elif step == "plex":
        ok, msg = await test_plex_root(body.get("plex_root", ""))
    else:
        ok, msg = False, "Unknown step"

    return JSONResponse({"ok": ok, "message": msg})


# ── Setup: save config and finish ─────────────────────────────────────────────
@app.post("/setup/save")
async def setup_save(request: Request):
    form = dict(await request.form())

    config = {
        "ALLDEBRID_API_KEY": form.get("alldebrid_key", ""),
        "SONARR_URL":        form.get("sonarr_url", ""),
        "SONARR_API_KEY":    form.get("sonarr_key", ""),
        "RADARR_URL":        form.get("radarr_url", ""),
        "RADARR_API_KEY":    form.get("radarr_key", ""),
        "DEBRIDARR_BASE_URL":form.get("base_url", "http://debridarr:7474"),
        "TZ":                form.get("tz", "America/Edmonton"),
        "PUID":              form.get("puid", "1000"),
        "PGID":              form.get("pgid", "1000"),
    }

    # Write /data/.env
    write_env(config)

    # Push into os.environ FIRST — _init_clients reads directly from os.environ
    import os
    for k, v in config.items():
        os.environ[k] = v
    os.environ["PLEX_ROOT"] = form.get("plex_root", "/plex-strm")

    # Mark complete BEFORE _init_clients so guards pass immediately
    mark_setup_complete()
    request.app.state.setup_complete = True

    # Now reinitialise clients with fresh env
    _init_clients(request.app)

    log.info("✅ Setup complete — config saved, clients reinitialised")

    return HTMLResponse(f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta http-equiv="refresh" content="3;url=/library">
  <title>Setup Complete</title>
  <style>{_SETUP_STYLE}</style>
</head>
<body>
  <header><h1>🎬 Debridarr</h1><span class="ver">v0.4.0</span></header>
  <div class="wizard">
    <div class="wizard-card" style="text-align:center;padding:48px">
      <div style="font-size:3rem;margin-bottom:16px">🎉</div>
      <h2 style="color:#4ade80;margin-bottom:12px">Setup Complete!</h2>
      <p style="color:#888;margin-bottom:24px">Your config has been saved. Redirecting to the library browser...</p>
      <a href="/library" style="color:#f97316">Click here if not redirected</a>
    </div>
  </div>
</body>
</html>""")


# ─────────────────────────────────────────────────────────────────────────────
# / redirect
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    if _needs_setup(request):
        return _setup_redirect()
    return RedirectResponse("/library")


# ─────────────────────────────────────────────────────────────────────────────
# /library — browse Sonarr/Radarr, add to fake library
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/library", response_class=HTMLResponse)
async def library_browse(request: Request, tab: str = "movies", q: str = ""):
    if _needs_setup(request):
        return _setup_redirect()
    lm: LibraryManager = request.app.state.library
    db: CacheDB = request.app.state.db

    if lm is None:
        return HTMLResponse("<h2>Setup required — please complete the <a href='/setup'>setup wizard</a> first.</h2>", status_code=503)

    already_added = {
        (r["media_type"], r["title"], r["year"])
        for r in db.fake_library_list()
    }

    if tab == "movies":
        items = await lm.get_radarr_movies()
    else:
        items = await lm.get_sonarr_series()

    if q:
        ql = q.lower()
        items = [i for i in items if ql in i["title"].lower()]

    cards = ""
    for item in items:
        media_type = "movie" if tab == "movies" else "series"
        year = item.get("year")
        in_lib = (media_type, item["title"], year) in already_added
        poster = item.get("poster", "")
        img = f'<img src="{poster}" onerror="this.style.display=\'none\'" loading="lazy">' if poster else '<div style="aspect-ratio:2/3;background:#111"></div>'
        badge = '<span class="badge-in">✓ Added</span>' if in_lib else ""
        sc = item.get('season_count', 0)
        season_info = f"{sc} season{'s' if sc != 1 else ''}" if tab == "tv" and sc else ("? seasons" if tab == "tv" else "")
        meta = f"{year or ''}" + (f" · {season_info}" if season_info else "")
        safe_title = item['title'].replace("'", "\\'").replace('"', '&quot;')

        if in_lib:
            action = f"""<button class="btn btn-rem" onclick="removeItem('{media_type}','{safe_title}',{year or 'null'})">Remove</button>"""
        else:
            sc = item.get('season_count', 0)
            action = f"""<button class="btn btn-add" onclick="addItem('{media_type}',{item.get('id','null')},'{safe_title}',{year or 'null'},{sc})">+ Add</button>"""

        cards += f"""
        <div class="card">
          {badge}{img}
          <div class="info">
            <div class="title" title="{item['title']}">{item['title']}</div>
            <div class="meta">{meta}</div>
          </div>
          <div class="actions">{action}</div>
        </div>"""

    if not cards:
        cards = f'<div class="empty">{"No results for &quot;"+q+"&quot;" if q else "Nothing in your Sonarr/Radarr library"}</div>'

    movie_count = len(await lm.get_radarr_movies())
    tv_count = len(await lm.get_sonarr_series())
    tab_movies = "active" if tab == "movies" else ""
    tab_tv = "active" if tab == "tv" else ""

    body = f"""
    <h2>Browse Library</h2>
    <div class="tabs">
      <div class="tab {tab_movies}" onclick="location.href='/library?tab=movies&q={q}'">🎬 Movies ({movie_count})</div>
      <div class="tab {tab_tv}"     onclick="location.href='/library?tab=tv&q={q}'">📺 TV Shows ({tv_count})</div>
    </div>
    <div class="search-bar">
      <input id="q" type="text" placeholder="Search..." value="{q}"
             onkeydown="if(event.key==='Enter')location.href='/library?tab={tab}&q='+encodeURIComponent(this.value)">
      <button class="btn btn-add" onclick="location.href='/library?tab={tab}&q='+encodeURIComponent(document.getElementById('q').value)">Search</button>
      {'<button class="btn btn-sec" onclick="location.href=\'/library?tab='+tab+'\'">Clear</button>' if q else ''}
    </div>
    <div class="card-grid">{cards}</div>"""

    extra = f"""<script>
async function addItem(type, id, title, year, season_count) {{
  const r = await fetch('/api/library/add', {{method:'POST',headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{media_type:type,arr_id:id,title,year,season_count}})}});
  const d = await r.json();
  if (r.ok) {{ toast('✅ ' + title + ' added'); setTimeout(()=>location.reload(),1200); }}
  else {{ toast('❌ ' + (d.detail||'Error'), false); }}
}}
async function removeItem(type, title, year) {{
  const r = await fetch('/api/library/remove',{{method:'POST',headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{media_type:type,title,year}})}});
  if (r.ok) {{ toast('🗑️ Removed'); setTimeout(()=>location.reload(),1200); }}
  else {{ toast('❌ Error', false); }}
}}
</script>"""
    return _page("Browse Library", "library", body, extra)


# ─────────────────────────────────────────────────────────────────────────────
# /my-library
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/my-library", response_class=HTMLResponse)
async def my_library(request: Request):
    if _needs_setup(request):
        return _setup_redirect()
    db: CacheDB = request.app.state.db
    items = db.fake_library_list()
    movies = [i for i in items if i["media_type"] == "movie"]
    shows  = [i for i in items if i["media_type"] == "series"]

    def section(title_str, rows, media_type):
        if not rows:
            return f"<h2>{title_str}</h2><div class='empty' style='padding:24px'>Nothing added yet</div>"
        trs = ""
        for r in rows:
            added = datetime.fromisoformat(r["added_at"]).strftime("%b %d, %Y")
            sc = r.get('season_count')
            extra = (f"{sc} season{'s' if sc != 1 else ''}" if sc else "? seasons") if media_type == "series" else str(r.get("year") or "—")
            path = r.get("fake_path") or "—"
            safe = r['title'].replace("'","\\'")
            trs += f"""<tr>
              <td><strong>{r['title']}</strong></td><td>{extra}</td>
              <td style="font-size:0.75rem;color:#555;font-family:monospace">{path}</td>
              <td>{added}</td>
              <td><button class="btn btn-rem" onclick="rem('{media_type}','{safe}',{r.get('year') or 'null'})">Remove</button></td>
            </tr>"""
        return f"""<h2>{title_str}</h2>
        <table style="margin-bottom:32px">
          <thead><tr><th>Title</th><th>Info</th><th>Path</th><th>Added</th><th></th></tr></thead>
          <tbody>{trs}</tbody>
        </table>"""

    body = section("🎬 Movies", movies, "movie") + section("📺 TV Shows", shows, "series")
    if not items:
        body = "<div class='empty'>Your library is empty. <a href='/library' style='color:#f97316'>Browse Library</a> to add titles.</div>"

    extra = """<script>
async function rem(type, title, year) {
  const r = await fetch('/api/library/remove',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({media_type:type,title,year})});
  if (r.ok){toast('🗑️ Removed');setTimeout(()=>location.reload(),1200);}
  else{toast('❌ Error',false);}
}
</script>"""
    return _page("My Library", "my-library", body, extra)


# ─────────────────────────────────────────────────────────────────────────────
# /streams
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/streams", response_class=HTMLResponse)
async def streams_page(request: Request):
    if _needs_setup(request):
        return _setup_redirect()
    db: CacheDB = request.app.state.db
    entries = db.list_all()

    def pill(s):
        cls = {"cached":"pill-ok","resolving":"pill-res","error":"pill-err","not_found":"pill-nf"}.get(s,"pill-pend")
        return f'<span class="pill {cls}">{s}</span>'

    rows = "".join(f"""<tr>
      <td>{e['media_type']}</td>
      <td><strong>{e['title']}</strong><br><small style="color:#555">{e.get('torrent_name','')}</small></td>
      <td style="font-family:monospace">{'S'+str(e['season']).zfill(2) if e.get('season') else ''}{'E'+str(e['episode']).zfill(2) if e.get('episode') else ''}</td>
      <td>{e.get('quality','—')}</td>
      <td>{datetime.fromisoformat(e['expires_at']).strftime('%Y-%m-%d')}</td>
      <td>{pill(e['status'])}</td>
      <td><button class="btn btn-rem" onclick="del_('{e['cache_key']}')">Del</button></td>
    </tr>""" for e in entries)

    table = f'<table><thead><tr><th>Type</th><th>Title</th><th>Ep</th><th>Quality</th><th>Expires</th><th>Status</th><th></th></tr></thead><tbody>{rows}</tbody></table>' if entries else "<div class='empty'>No resolved streams yet.</div>"
    extra = """<script>async function del_(k){await fetch('/cache/'+k,{method:'DELETE'});toast('🗑️ Deleted');setTimeout(()=>location.reload(),1200);}</script>"""
    return _page("Streams", "streams", f"<h2>Resolved Streams</h2>{table}", extra)


# ─────────────────────────────────────────────────────────────────────────────
# API
# ─────────────────────────────────────────────────────────────────────────────
@app.post("/api/library/add")
async def api_library_add(request: Request, background_tasks: BackgroundTasks):
    body = await request.json()
    media_type = body.get("media_type")
    title = body.get("title", "").strip()
    year = body.get("year")
    arr_id = body.get("arr_id")
    season_count = body.get("season_count", 0)
    if media_type not in ("movie", "series"): raise HTTPException(400, "bad media_type")
    if not title: raise HTTPException(400, "title required")
    lm = request.app.state.library
    db = request.app.state.db
    background_tasks.add_task(_add_to_library, lm, db, media_type, arr_id, title, year, season_count)
    return {"status": "adding", "title": title}


@app.post("/api/library/remove")
async def api_library_remove(request: Request):
    body = await request.json()
    media_type, title, year = body.get("media_type"), body.get("title","").strip(), body.get("year")
    lm = request.app.state.library
    db = request.app.state.db
    if media_type == "movie": lm.remove_fake_movie(title, year)
    else: lm.remove_fake_series(title)
    db.fake_library_remove(media_type, title, year)
    return {"status": "removed"}


async def _add_to_library(lm, db, media_type, arr_id, title, year, season_count=0):
    try:
        if media_type == "movie":
            path = lm.create_fake_movie(title, year)
            db.fake_library_add({"media_type":"movie","title":title,"year":year,
                                  "radarr_id":arr_id,"fake_path":str(path) if path else None})
        else:
            # Fetch fresh series data to get seasons + episodes
            series_list = await lm.get_sonarr_series()
            series = next((s for s in series_list if s["id"] == arr_id), None)
            # Use passed season_count as fallback if series not found in cache
            sc = series.get("season_count", season_count) if series else season_count
            seasons = series.get("seasons", []) if series else []
            tvdb_id = series.get("tvdb_id") if series else None
            include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"
            episodes = await lm.get_sonarr_episodes(arr_id, include_unreleased=include_unreleased)
            paths = lm.create_fake_episodes(title, year, seasons, episodes)
            db.fake_library_add({"media_type":"series","title":title,"year":year,
                                  "sonarr_id":arr_id,"tvdb_id":tvdb_id,
                                  "season_count":sc,
                                  "fake_path":str(Path(lm.plex_root)/"tv"/title) if lm.plex_root else None})
            log.info(f"📺 {title}: {len(paths)} fake episodes, {sc} seasons")
    except Exception as e:
        log.error(f"Failed adding '{title}': {e}", exc_info=True)


@app.post("/webhook/tautulli")
async def tautulli_webhook(request: Request, background_tasks: BackgroundTasks):
    try:
        payload = await request.json()
    except Exception:
        payload = dict(await request.form())

    # Log the full raw payload so we can see exactly what Tautulli sends
    log.info(f"📺 Tautulli webhook received: {payload}")

    media_type = payload.get("media_type", "")
    title = payload.get("grandparent_title") or payload.get("title", "")
    year = payload.get("year") or payload.get("grandparent_year")
    season = payload.get("parent_media_index")
    episode = payload.get("media_index")

    if media_type not in ("movie", "episode"):
        log.warning(
            f"📺 Tautulli webhook ignored — media_type={repr(media_type)} "
            f"title={repr(title)} (expected 'movie' or 'episode')"
        )
        return {"status": "ignored", "reason": f"media_type={repr(media_type)} not supported"}

    if not title:
        log.warning(f"📺 Tautulli webhook ignored — no title in payload")
        return {"status": "ignored", "reason": "no title"}

    event = PlayEvent(
        media_type=MediaType(media_type),
        title=title,
        year=int(year) if year else None,
        season=int(season) if season else None,
        episode=int(episode) if episode else None,
        rating_key=payload.get("rating_key"),
    )
    log.info(f"📺 Resolving: {event.cache_key()} — {title} S{season}E{episode}")
    background_tasks.add_task(resolve_and_cache, request.app, event)
    return {"status": "accepted", "cache_key": event.cache_key()}


@app.post("/webhook/sonarr")
async def sonarr_webhook(request: Request):
    payload = await request.json()
    log.info(f"📡 Sonarr: {payload.get('eventType')}")
    if request.app.state.library: request.app.state.library.invalidate_cache()
    return {"status":"ok"}


@app.post("/webhook/radarr")
async def radarr_webhook(request: Request):
    payload = await request.json()
    log.info(f"📡 Radarr: {payload.get('eventType')}")
    if request.app.state.library: request.app.state.library.invalidate_cache()
    return {"status":"ok"}


@app.get("/proxy/{cache_key}")
async def stream_proxy(cache_key: str, request: Request):
    return await proxy_stream(request, cache_key, request.app.state.db, request.app.state.alldebrid)


@app.post("/resolve")
async def manual_resolve(request: Request, background_tasks: BackgroundTasks):
    body = await request.json()
    event = PlayEvent(media_type=MediaType(body["media_type"]), title=body["title"],
                      year=body.get("year"), season=body.get("season"), episode=body.get("episode"))
    background_tasks.add_task(resolve_and_cache, request.app, event)
    s = request.app.state.settings
    return {"status":"resolving","cache_key":event.cache_key(),
            "proxy_url":f"{s.DEBRIDARR_BASE_URL}/proxy/{event.cache_key()}"}


@app.get("/cache")
async def list_cache(request: Request): return request.app.state.db.list_all()


@app.delete("/cache/{cache_key}")
async def delete_cache_entry(cache_key: str, request: Request):
    db = request.app.state.db
    entry = db.get(cache_key)
    s = request.app.state.settings
    if entry and s.PLEX_ROOT:
        delete_strm(cache_key=cache_key, title=entry["title"], year=entry.get("year"),
                    season=entry.get("season"), episode=entry.get("episode"),
                    media_type=entry["media_type"], plex_root=s.PLEX_ROOT)
    db.delete(cache_key)
    return {"status":"deleted"}



# ─────────────────────────────────────────────────────────────────────────────
# /settings — view and update config, test connections
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/settings", response_class=HTMLResponse)
async def settings_page(request: Request):
    if _needs_setup(request):
        return _setup_redirect()
    cfg = load_saved_config()
    s = request.app.state.settings

    def field(label, key, hint="", typ="text", placeholder=""):
        val = cfg.get(key) or getattr(s, key, "") or ""
        masked = typ == "password"
        input_type = "password" if masked else "text"
        # Never pre-fill password fields — show a placeholder dot pattern instead
        show_val = val if not masked else ""
        is_saved = bool(val) and masked
        ph = "••••••• (saved — leave blank to keep)" if is_saved else (placeholder or "")
        saved_attr = ' data-saved="true"' if is_saved else ""
        return f"""
        <div class="field">
          <label>{label}{'<span class="saved-badge">saved</span>' if is_saved else ""}</label>
          <input id="{key}" name="{key}" type="{input_type}" value="{show_val}" placeholder="{ph}" autocomplete="off"{saved_attr}>
          {'<div class="hint">' + hint + '</div>' if hint else ''}
        </div>"""

    body = f"""
    <div style="max-width:700px">
      <h2 style="margin-bottom:4px">⚙️ Settings</h2>
      <p style="color:#555;font-size:0.85rem;margin-bottom:28px">Changes are saved immediately and applied without restarting.</p>

      <div class="settings-section">
        <div class="section-title">AllDebrid</div>
        {field("API Key", "ALLDEBRID_API_KEY", 'Get yours at <a href="https://alldebrid.com/apikeys" target="_blank">alldebrid.com/apikeys</a>', "password")}
        <button class="btn btn-sec" onclick="testConn('alldebrid')">Test Connection</button>
        <div id="test-alldebrid" class="test-result"></div>
      </div>

      <div class="settings-section">
        <div class="section-title">Overseerr</div>
        {field("URL", "OVERSEERR_URL", "Your Overseerr instance URL", placeholder="http://192.168.1.x:5055")}
        {field("API Key", "OVERSEERR_API_KEY", "Overseerr → Settings → General → API Key", "password")}
        <button class="btn btn-sec" onclick="testConn('overseerr')">Test Connection</button>
        <div id="test-overseerr" class="test-result"></div>
      </div>

      <div class="settings-section">
        <div class="section-title">Plex</div>
        {field("Debridarr Base URL", "DEBRIDARR_BASE_URL", "URL Plex uses to reach Debridarr — written into every .strm file", placeholder="http://192.168.1.x:7474")}
        {field("Plex Library Path", "PLEX_ROOT", "Path inside this container where fake .mkv files are written", placeholder="/plex-strm")}
        <button class="btn btn-sec" onclick="testConn('plex')">Test Path</button>
        <div id="test-plex" class="test-result"></div>
      </div>

      <div class="settings-section">
        <div class="section-title">Library Behaviour</div>
        <div class="toggle-row">
          <div>
            <div class="toggle-label">Include unreleased episodes</div>
            <div class="toggle-hint">When enabled, fake .mkv files are created for episodes that haven't aired yet. Useful for future-proofing your library. Requires re-adding the show to take effect.</div>
          </div>
          <label class="toggle">
            <input type="checkbox" id="include_unreleased_episodes" onchange="saveSetting('include_unreleased_episodes', this.checked)">
            <span class="slider"></span>
          </label>
        </div>
        <div id="test-settings" class="test-result" style="margin-top:10px"></div>
      </div>

      <div class="settings-section">
        <div class="section-title">🗂️ DFS Cache (Streaming Performance)</div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">
          <div class="field">
            <label>Cache Directory</label>
            <input id="dfs_cache_dir" type="text" value="/tmp/cache" placeholder="/tmp/cache">
            <div class="hint">Directory for chunk cache files</div>
          </div>
          <div class="field">
            <label>Disk Cache Size (GB)</label>
            <input id="dfs_disk_cache_size_gb" type="number" value="30" min="1" max="1000">
            <div class="hint">Maximum disk cache size</div>
          </div>
          <div class="field">
            <label>Cache Expiry (hours)</label>
            <input id="dfs_cache_expiry_h" type="number" value="24" min="1" max="168">
            <div class="hint">How long to keep cached chunks</div>
          </div>
          <div class="field">
            <label>Chunk Size (MB)</label>
            <input id="dfs_chunk_size_mb" type="number" value="8" min="1" max="64">
            <div class="hint">Fetch unit from CDN</div>
          </div>
          <div class="field">
            <label>Read Ahead (MB)</label>
            <input id="dfs_read_ahead_mb" type="number" value="500" min="0" max="2000">
            <div class="hint">Pre-fetch buffer size</div>
          </div>
          <div class="field">
            <label>Cleanup Interval (min)</label>
            <input id="dfs_cleanup_interval_m" type="number" value="20" min="1" max="1440">
            <div class="hint">How often to clean cache</div>
          </div>
        </div>
        <button class="btn btn-sec" onclick="saveDFS()" style="margin-top:8px;padding:8px 20px;font-size:0.85rem">💾 Save DFS Settings</button>
        <div id="dfs-result" class="test-result" style="margin-top:10px"></div>
      </div>

      <div class="settings-section">
        <div class="section-title">System</div>
        {field("Timezone", "TZ", 'e.g. America/Edmonton — <a href="https://en.wikipedia.org/wiki/List_of_tz_database_time_zones" target="_blank">full list</a>', placeholder="America/Edmonton")}
        <div style="display:flex;gap:12px">
          <div style="flex:1">{field("PUID", "PUID", "Run: id -u", placeholder="1000")}</div>
          <div style="flex:1">{field("PGID", "PGID", "Run: id -g", placeholder="1000")}</div>
        </div>
      </div>

      <div style="display:flex;gap:12px;margin-top:8px">
        <button class="btn btn-add" onclick="saveAll()" style="padding:10px 28px;font-size:0.9rem">💾 Save All Settings</button>
        <button class="btn btn-sec" onclick="testAll()" style="padding:10px 20px;font-size:0.9rem">🔌 Test All Connections</button>
      </div>
      <div id="save-result" class="test-result" style="margin-top:14px"></div>
    </div>"""

    extra = """<style>
.settings-section { background:#1a1a24; border:1px solid #2a2a3a; border-radius:10px;
                    padding:20px 24px; margin-bottom:16px; }
.section-title { font-size:0.75rem; font-weight:700; text-transform:uppercase;
                 color:#f97316; letter-spacing:.08em; margin-bottom:16px; }
.field { margin-bottom:14px; }
.field label { display:block; font-size:0.8rem; color:#888; margin-bottom:5px; font-weight:600; }
.field input { width:100%; background:#0f0f13; border:1px solid #2a2a3a; border-radius:7px;
               padding:9px 13px; color:#e0e0e0; font-size:0.875rem; outline:none; font-family:monospace; }
.field input:focus { border-color:#f97316; }
.field .hint { font-size:0.74rem; color:#555; margin-top:4px; line-height:1.4; }
.field .hint a { color:#f97316; }
.saved-badge { display:inline-block; margin-left:8px; font-size:0.68rem; font-weight:700;
               background:#14532d; color:#4ade80; border-radius:4px; padding:1px 6px;
               text-transform:uppercase; letter-spacing:.04em; vertical-align:middle; }
.test-result { margin-top:10px; padding:8px 12px; border-radius:6px; font-size:0.82rem; display:none; }
.test-result.ok      { background:#14532d; color:#4ade80; display:block; }
.test-result.err     { background:#3b0000; color:#f87171; display:block; }
.test-result.testing { background:#1e1e2e; color:#aaa;    display:block; }
.toggle-row { display:flex; align-items:flex-start; justify-content:space-between; gap:20px; padding:4px 0; }
.toggle-label { font-size:0.875rem; color:#e0e0e0; font-weight:600; margin-bottom:4px; }
.toggle-hint  { font-size:0.75rem; color:#555; line-height:1.5; max-width:480px; }
.toggle { position:relative; display:inline-block; width:44px; height:24px; flex-shrink:0; margin-top:2px; }
.toggle input { opacity:0; width:0; height:0; }
.slider { position:absolute; cursor:pointer; inset:0; background:#2a2a3a; border-radius:24px; transition:.2s; }
.slider:before { position:absolute; content:""; height:18px; width:18px; left:3px; bottom:3px;
                 background:#555; border-radius:50%; transition:.2s; }
input:checked + .slider { background:#f97316; }
input:checked + .slider:before { transform:translateX(20px); background:#fff; }
</style>
<script>
function getVal(id) { return document.getElementById(id)?.value?.trim() || ''; }

function setResult(id, ok, msg) {
  const el = document.getElementById('test-' + id);
  if (!el) return;
  el.className = 'test-result ' + (ok ? 'ok' : 'err');
  el.textContent = (ok ? '✅ ' : '❌ ') + msg;
}

async function testConn(service) {
  const el = document.getElementById('test-' + service);
  el.className = 'test-result testing'; el.textContent = 'Testing...';
  let body = { step: service };
  if (service === 'alldebrid') body.api_key = getVal('ALLDEBRID_API_KEY');
  if (service === 'overseerr') { body.url = getVal('OVERSEERR_URL'); body.api_key = getVal('OVERSEERR_API_KEY'); }
  if (service === 'sonarr')    { body.url = getVal('SONARR_URL'); body.api_key = getVal('SONARR_API_KEY'); }
  if (service === 'radarr')    { body.url = getVal('RADARR_URL'); body.api_key = getVal('RADARR_API_KEY'); }
  if (service === 'plex')      body.plex_root = getVal('PLEX_ROOT');
  const r = await fetch('/setup/test', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
  const d = await r.json();
  setResult(service, d.ok, d.message);
}

async function testAll() {
  await Promise.all(['alldebrid','sonarr','radarr','plex'].map(testConn));
}

async function loadSettings() {
  const r = await fetch('/api/settings/get');
  if (!r.ok) return;
  const d = await r.json();
  const cb = document.getElementById('include_unreleased_episodes');
  if (cb) cb.checked = d.include_unreleased_episodes === 'true';
  // Load DFS settings
  try {
    const dfsR = await fetch('/api/settings/dfs');
    const dfs = await dfsR.json();
    const map = {
      cache_dir: 'dfs_cache_dir', disk_cache_size_gb: 'dfs_disk_cache_size_gb',
      cache_expiry_h: 'dfs_cache_expiry_h', chunk_size_mb: 'dfs_chunk_size_mb',
      read_ahead_mb: 'dfs_read_ahead_mb', cleanup_interval_m: 'dfs_cleanup_interval_m',
    };
    for (const [k,id] of Object.entries(map)) {
      const el = document.getElementById(id);
      if (el && dfs[k] !== undefined) el.value = dfs[k];
    }
  } catch(e) {}
}

async function saveSetting(key, value) {
  const res = document.getElementById('test-settings');
  res.className = 'test-result testing'; res.textContent = 'Saving...';
  const r = await fetch('/api/settings/behaviour', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({key, value: value.toString()})
  });
  const d = await r.json();
  if (r.ok) { res.className='test-result ok'; res.textContent='✅ ' + d.message; }
  else       { res.className='test-result err'; res.textContent='❌ ' + (d.detail || 'Error'); }
}

loadSettings();

function getFieldVal(id) {
  const el = document.getElementById(id);
  if (!el) return null;
  const val = el.value.trim();
  // If it's a password field with a saved value and the user left it blank, skip it
  if (!val && el.type === 'password' && el.dataset.saved === 'true') return null;
  return val || null;
}

async function saveDFS() {
  const res = document.getElementById('dfs-result');
  res.className = 'test-result testing'; res.style.display='block'; res.textContent = 'Saving...';
  const payload = {
    cache_dir:          document.getElementById('dfs_cache_dir').value,
    disk_cache_size_gb: parseInt(document.getElementById('dfs_disk_cache_size_gb').value),
    cache_expiry_h:     parseInt(document.getElementById('dfs_cache_expiry_h').value),
    chunk_size_mb:      parseInt(document.getElementById('dfs_chunk_size_mb').value),
    read_ahead_mb:      parseInt(document.getElementById('dfs_read_ahead_mb').value),
    cleanup_interval_m: parseInt(document.getElementById('dfs_cleanup_interval_m').value),
  };
  const r = await fetch('/api/settings/dfs', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)});
  const d = await r.json();
  if (r.ok) { res.className='test-result ok'; res.textContent='✅ DFS settings saved'; }
  else       { res.className='test-result err'; res.textContent='❌ Save failed'; }
}

async function saveAll() {
  const res = document.getElementById('save-result');
  res.className = 'test-result testing'; res.textContent = 'Saving...';
  // Only include fields that have a value — null means "don't overwrite"
  const raw = {
    ALLDEBRID_API_KEY:  getFieldVal('ALLDEBRID_API_KEY'),
    OVERSEERR_URL:      getFieldVal('OVERSEERR_URL'),
    OVERSEERR_API_KEY:  getFieldVal('OVERSEERR_API_KEY'),
    SONARR_URL:         getFieldVal('SONARR_URL'),
    SONARR_API_KEY:     getFieldVal('SONARR_API_KEY'),
    RADARR_URL:         getFieldVal('RADARR_URL'),
    RADARR_API_KEY:     getFieldVal('RADARR_API_KEY'),
    DEBRIDARR_BASE_URL: getFieldVal('DEBRIDARR_BASE_URL'),
    PLEX_ROOT:          getFieldVal('PLEX_ROOT'),
    TZ:                 getFieldVal('TZ'),
    PUID:               getFieldVal('PUID'),
    PGID:               getFieldVal('PGID'),
  };
  // Strip nulls before sending
  const payload = Object.fromEntries(Object.entries(raw).filter(([_, v]) => v !== null));
  const r = await fetch('/api/settings/save', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
  const d = await r.json();
  if (r.ok) { res.className='test-result ok'; res.textContent='✅ ' + d.message; }
  else       { res.className='test-result err'; res.textContent='❌ ' + (d.detail || 'Save failed'); }
}
</script>"""

    return _page("Settings", "settings", body, extra)


@app.post("/api/settings/save")
async def api_settings_save(request: Request):
    """Save updated settings to /data/.env and reinitialise clients."""
    body = await request.json()

    # Merge with existing config so we don't blank fields not on this page
    cfg = load_saved_config()
    allowed = {
        "ALLDEBRID_API_KEY", "SONARR_URL", "SONARR_API_KEY",
        "RADARR_URL", "RADARR_API_KEY", "DEBRIDARR_BASE_URL",
        "PLEX_ROOT", "TZ", "PUID", "PGID",
    }
    for k, v in body.items():
        if k in allowed and v:  # only update non-empty values
            cfg[k] = v

    write_env(cfg)

    # Push into os.environ FIRST — _init_clients reads directly from os.environ
    import os
    for k, v in cfg.items():
        os.environ[k] = v

    # Reinitialise clients with new settings
    _init_clients(request.app)
    if request.app.state.library:
        request.app.state.library.invalidate_cache()

    log.info("⚙️  Settings updated and clients reinitialised")
    return {"status": "ok", "message": "Settings saved — clients reinitialised"}


@app.get("/api/settings/get")
async def api_settings_get(request: Request):
    """Return current behaviour settings."""
    db: CacheDB = request.app.state.db
    return db.get_all_settings()


@app.post("/api/settings/behaviour")
async def api_settings_behaviour(request: Request, background_tasks: BackgroundTasks):
    """Save a single behaviour toggle and apply it immediately."""
    body = await request.json()
    key = body.get("key", "").strip()
    value = body.get("value", "").strip()
    allowed = {"include_unreleased_episodes"}
    if key not in allowed:
        raise HTTPException(400, f"Unknown setting: {key}")

    db: CacheDB = request.app.state.db
    db.set_setting(key, value)
    log.info(f"⚙️  Setting {key} = {value}")

    # If the unreleased toggle changed, sync all series in the fake library immediately
    if key == "include_unreleased_episodes":
        background_tasks.add_task(
            _sync_all_series_episodes, request.app, value == "true"
        )
        return {"status": "ok", "message": f"Saved — syncing episode files in background"}

    return {"status": "ok", "message": f"{key} set to {value}"}


async def _sync_all_series_episodes(app: FastAPI, include_unreleased: bool):
    """Background task: sync fake episode files for every series in the library."""
    db: CacheDB = app.state.db
    lm = app.state.library
    if not lm:
        return

    series_entries = db.fake_library_list(media_type="series")
    if not series_entries:
        log.info("🔄 No series in fake library to sync")
        return

    log.info(f"🔄 Syncing {len(series_entries)} series (include_unreleased={include_unreleased})")
    total_added = total_removed = 0

    for entry in series_entries:
        sonarr_id = entry.get("sonarr_id")
        title = entry["title"]
        year = entry.get("year")
        if not sonarr_id:
            log.warning(f"No sonarr_id for '{title}', skipping sync")
            continue
        result = await lm.sync_series_episodes(title, sonarr_id, year, include_unreleased)
        total_added   += result["added"]
        total_removed += result["removed"]

    log.info(f"🔄 Sync complete — +{total_added} added, -{total_removed} removed across {len(series_entries)} series")

@app.get("/api/settings/dfs")
async def api_settings_dfs_get():
    """Get current DFS settings."""
    return get_dfs_settings()


@app.post("/api/settings/dfs")
async def api_settings_dfs_save(request: Request, background_tasks: BackgroundTasks):
    """Save DFS settings and apply immediately."""
    body = await request.json()
    allowed = {
        "cache_dir", "disk_cache_size_gb", "cache_expiry_h",
        "chunk_size_mb", "read_ahead_mb", "cleanup_interval_m",
    }
    settings = {k: v for k, v in body.items() if k in allowed}
    # Type coerce numerics
    for k in ("disk_cache_size_gb","cache_expiry_h","chunk_size_mb","read_ahead_mb","cleanup_interval_m"):
        if k in settings:
            try:
                settings[k] = float(settings[k]) if "." in str(settings[k]) else int(settings[k])
            except Exception:
                pass
    update_dfs_settings(settings)
    # Persist to DB
    db: CacheDB = request.app.state.db
    import json
    db.set_setting("dfs_settings", json.dumps(settings))
    return {"status": "ok", "settings": get_dfs_settings()}




@app.get("/health")
async def health(): return {"status":"ok","service":"debridarr","version":"0.4.0"}


async def _load_all_torrents(app: FastAPI):
    """Load all torrents from AllDebrid account into FUSE on startup."""
    await asyncio.sleep(2)  # Let FUSE settle
    alldebrid = app.state.alldebrid
    s = app.state.settings
    if not alldebrid or not FUSE_AVAILABLE or not getattr(app.state, "fuse_thread", None):
        return
    try:
        torrents = await alldebrid.get_all_torrents()
        for t in torrents:
            register_torrent(t["name"], t["files"])
        log.info(f"✅ Loaded {len(torrents)} torrents from AllDebrid into FUSE")
        # Recreate any missing symlinks for cached DB entries
        if s.PLEX_ROOT:
            _restore_symlinks(app, torrents)
    except Exception as e:
        log.error(f"_load_all_torrents failed: {e}", exc_info=True)


def _restore_symlinks(app, torrents: list):
    """Recreate plex-strm symlinks for items already in DB cache."""
    db = app.state.db
    s  = app.state.settings
    torrent_map = {t["name"]: t for t in torrents}
    for entry in db.list_all():
        if entry["status"] != "cached":
            continue
        torrent_name = entry.get("torrent_name", "")
        if torrent_name not in torrent_map:
            continue
        t = torrent_map[torrent_name]
        # Pick largest video file
        best = max(t["files"], key=lambda f: f.get("s", 0))
        filename = best["n"]
        fuse_virtual = get_fuse_path(torrent_name, filename, s.FUSE_SYMLINK_ROOT)
        _make_plex_symlink(
            cache_key=entry["cache_key"], title=entry["title"],
            year=entry.get("year"), season=entry.get("season"),
            episode=entry.get("episode"), media_type=entry["media_type"],
            plex_root=s.PLEX_ROOT, target=fuse_virtual, video_name=filename,
        )


async def resolve_and_cache(app: FastAPI, event: PlayEvent):
    db = app.state.db
    alldebrid = app.state.alldebrid
    s = app.state.settings
    cache_key = event.cache_key()

    existing = db.get(cache_key)
    if existing and existing["status"] == "cached":
        log.info(f"✅ Cache hit: {cache_key}")
        # Re-register in FUSE if lost after restart
        _reregister_in_fuse(cache_key, existing, app)
        return

    log.info(f"🔍 Resolving: {cache_key}")
    db.upsert(cache_key, event, status="resolving")

    try:
        # 1. Search TPB → find cached torrents on AllDebrid
        results = await alldebrid.search_cached(
            title=event.title,
            media_type=event.media_type.value,
            year=event.year,
            season=event.season,
            episode=event.episode,
            imdb_id=event.imdb_id,
        )
        if not results:
            log.warning(f"❌ No results: {cache_key}")
            db.update_status(cache_key, "not_found")
            return

        best = results[0]
        log.info(f"🎯 Best: {best['name']} cached={best['cached']} quality={best.get('quality','?')}")

        # 2. Add magnet to AllDebrid → get file list
        result = await alldebrid.add_magnet(best["magnet"])
        if not result:
            db.update_status(cache_key, "unlock_failed")
            return

        magnet_id, files = result

        # Use torrent name as the FUSE directory (mirrors decypharr structure)
        torrent_name = best["name"]
        best_file    = max(files, key=lambda f: f.get("s", 0))
        filename     = best_file.get("n", torrent_name)
        ad_link      = best_file.get("l", "")
        file_size    = best_file.get("s", 0)

        if not ad_link:
            log.error(f"No file link for {cache_key}")
            db.update_status(cache_key, "unlock_failed")
            return

        log.info(f"📁 {torrent_name}/{filename} ({file_size} bytes)")

        # 3. Register ALL files in FUSE under the torrent name
        fuse_thread = getattr(app.state, "fuse_thread", None)
        strm_path = None

        if s.PLEX_ROOT:
            if FUSE_AVAILABLE and fuse_thread:
                # /mnt/alldebrid/<torrent_name>/<filename>
                register_torrent(torrent_name, files)

                # Symlink uses host path so Plex can resolve it
                fuse_virtual = get_fuse_path(torrent_name, filename, s.FUSE_SYMLINK_ROOT)
                log.info(f"📂 FUSE: {fuse_virtual}")

                symlink_path = _make_plex_symlink(
                    cache_key=cache_key,
                    title=event.title, year=event.year,
                    season=event.season, episode=event.episode,
                    media_type=event.media_type.value,
                    plex_root=s.PLEX_ROOT,
                    target=fuse_virtual,
                    video_name=filename,
                )
                strm_path = str(symlink_path) if symlink_path else None
                log.info(f"🔗 {symlink_path} → {fuse_virtual}")
            else:
                p = write_strm(cache_key=cache_key, title=event.title, year=event.year,
                               season=event.season, episode=event.episode,
                               media_type=event.media_type.value,
                               debridarr_base_url=s.DEBRIDARR_BASE_URL, plex_root=s.PLEX_ROOT)
                strm_path = str(p) if p else None

        db.update_cached(cache_key, best["magnet"], ad_link, torrent_name,
                         best.get("quality", "1080p"), strm_path)
        log.info(f"✅ Done: {cache_key}")

    except Exception as e:
        log.error(f"❌ {cache_key}: {e}", exc_info=True)
        db.update_status(cache_key, "error")



def _reregister_in_fuse(cache_key: str, entry: dict, app):
    """No-op — _load_all_torrents handles re-registration at startup."""
    pass


def _make_plex_symlink(
    cache_key: str, title: str, year, season, episode,
    media_type: str, plex_root: str, target: "Path", video_name: str
) -> "Optional[Path]":
    """
    Create a symlink in the Plex library pointing to the FUSE virtual file.

    Removes ALL existing files/symlinks in the folder first (placeholder .mp4
    and any stale symlinks), then creates one symlink using the real filename
    from AllDebrid so Plex gets the correct file extension.

    Movie:   /plex-strm/movies/<Title> (<Year>)/<filename.mkv>  → FUSE
    Episode: /plex-strm/tv/<Title>/Season NN/<filename.mkv>     → FUSE
    """
    from pathlib import Path as _P
    try:
        if media_type == "movie":
            year_part = f" ({year})" if year else ""
            folder = _P(plex_root) / "movies" / f"{title}{year_part}"
        else:
            s_str = f"S{season:02d}" if season else "S00"
            e_str = f"E{episode:02d}" if episode else "E00"
            season_folder = f"Season {season:02d}" if season else "Season 00"
            folder = _P(plex_root) / "tv" / title / season_folder

        folder.mkdir(parents=True, exist_ok=True)

        # Only remove the specific placeholder for THIS episode/movie
        # For movies: remove the placeholder .mp4 with the same stem
        # For episodes: remove the placeholder matching this S##E## pattern
        # Never wipe other episode placeholders in the same season folder
        video_stem = Path(video_name).stem
        for existing in folder.iterdir():
            if not (existing.is_file() or existing.is_symlink()):
                continue
            # Remove if it's already a symlink pointing to this cache_key (stale)
            if existing.is_symlink() and str(existing.readlink()).find(cache_key) != -1:
                existing.unlink()
                continue
            # For movies: remove the single placeholder (whole folder is one movie)
            if media_type == "movie" and existing.suffix in (".mp4", ".mkv", ".avi"):
                existing.unlink()
                continue
            # For episodes: only remove placeholder matching this exact S##E## code
            if media_type != "movie" and season and episode:
                se = f"S{season:02d}E{episode:02d}"
                if se.upper() in existing.name.upper():
                    existing.unlink()

        # Create symlink with the real filename from AllDebrid
        link = folder / video_name
        if link.exists() or link.is_symlink():
            link.unlink()
        link.symlink_to(target)
        log.info(f"🔗 Symlink: {link} → {target}")
        return link
    except Exception as e:
        log.error(f"Failed to create symlink for {cache_key}: {e}")
        return None

from pathlib import Path
