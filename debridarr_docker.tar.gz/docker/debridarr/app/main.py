"""
Debridarr - On-the-fly AllDebrid streaming for Plex
"""

import asyncio
import logging
import re
import sys
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path
from typing import Optional

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from app.alldebrid import AllDebridClient
from app.cache import CacheDB
from app.config import settings
from app.library import LibraryManager, _FAKE_MP4
from app.models import MediaType, PlayEvent
from app.proxy import proxy_stream, write_strm, delete_strm
from app.fuse_mount import (
    start_fuse_mount, stop_fuse_mount,
    register_torrent, unregister_torrent, get_fuse_path,
    list_torrents, list_files, get_torrent_file,
    FUSE_AVAILABLE, update_dfs_settings, get_dfs_settings,
)
from app.setup import (
    is_setup_complete, mark_setup_complete,
    load_saved_config, write_env,
    test_alldebrid, test_overseerr, test_plex_root,
)

logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("debridarr")


# ── Helpers ───────────────────────────────────────────────────────────────────

def _schedule_restart(delay: float = 2.0):
    import threading, subprocess, time
    def _do():
        time.sleep(delay)
        log.info("🔄 Restarting...")
        try: subprocess.run(["kill", "-TERM", "1"], check=False)
        except Exception as e: log.error(f"Restart failed: {e}")
    threading.Thread(target=_do, daemon=True).start()


def _init_clients(app: FastAPI):
    import os
    class _S:
        ALLDEBRID_API_KEY  = os.environ.get("ALLDEBRID_API_KEY", "")
        OVERSEERR_URL      = os.environ.get("OVERSEERR_URL", "")
        OVERSEERR_API_KEY  = os.environ.get("OVERSEERR_API_KEY", "")
        PLEX_ROOT          = os.environ.get("PLEX_ROOT", "/plex-strm")
        DEBRIDARR_BASE_URL = os.environ.get("DEBRIDARR_BASE_URL", "")
        DB_PATH            = os.environ.get("DB_PATH", "/data/debridarr.db")
        PORT               = int(os.environ.get("PORT", "7474"))
        LOG_LEVEL          = os.environ.get("LOG_LEVEL", "INFO")
        FUSE_MOUNT         = os.environ.get("FUSE_MOUNT", "/mnt/alldebrid")
        FUSE_SYMLINK_ROOT  = os.environ.get("FUSE_SYMLINK_ROOT", "/docker/debridarr/mnt-alldebrid")

    s = _S()
    db: CacheDB = getattr(app.state, "db", None)
    tmdb_key = db.get_setting("tmdb_api_key", "") if db else ""

    app.state.alldebrid = AllDebridClient(s.ALLDEBRID_API_KEY)
    app.state.library   = LibraryManager(
        overseerr_url=s.OVERSEERR_URL,
        overseerr_key=s.OVERSEERR_API_KEY,
        plex_root=s.PLEX_ROOT,
        tmdb_api_key=tmdb_key,
    )
    app.state.settings  = s
    app.state.fuse_thread = getattr(app.state, "fuse_thread", None)
    log.info(f"✅ Clients initialised — overseerr={s.OVERSEERR_URL or 'not set'}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info("🚀 Debridarr starting up...")
    for noisy in ("httpx", "httpcore", "multipart", "uvicorn.access"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    import os
    _data_env = Path("/data/.env")
    if _data_env.exists():
        log.info(f"📂 Loading config from {_data_env}")
        for line in _data_env.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            k, v = k.strip(), v.strip()
            if k and v and not os.environ.get(k):
                os.environ[k] = v

    db = CacheDB(settings.DB_PATH)
    db.init()
    app.state.db = db
    app.state.setup_complete = is_setup_complete()

    # Reset any entries stuck in "resolving" from a previous crashed run
    # Also recover entries that had symlinks (were cached) but got stuck
    stuck = 0
    recovered_symlinks = 0
    with db._connect() as conn:
        result = conn.execute(
            "UPDATE cache SET status='not_found' WHERE status='resolving'"
        )
        stuck = result.rowcount
        # Any not_found entry that still has a valid symlink path → restore to cached
        # These are entries that were cached, then something went wrong on restart
        not_found = conn.execute(
            "SELECT cache_key, strm_path FROM cache WHERE status='not_found' AND strm_path IS NOT NULL"
        ).fetchall()
        for row in not_found:
            strm = row[1]
            if strm and Path(strm).is_symlink():
                conn.execute(
                    "UPDATE cache SET status='cached' WHERE cache_key=?", (row[0],)
                )
                recovered_symlinks += 1
    if stuck:
        log.info(f"🔄 Reset {stuck} stuck 'resolving' entries → 'not_found'")
    if recovered_symlinks:
        log.info(f"🔄 Recovered {recovered_symlinks} entries with existing symlinks → 'cached'")

    _init_clients(app)
    s = app.state.settings
    log.info(f"✅ Debridarr ready — plex_root={s.PLEX_ROOT or 'NOT SET'}")

    # Load DFS settings
    try:
        import json as _json
        saved_dfs = db.get_setting("dfs_settings")
        if saved_dfs:
            update_dfs_settings(_json.loads(saved_dfs))
        else:
            cache_dir = s.FUSE_SYMLINK_ROOT.replace("mnt-alldebrid", "tmp/cache") if s.FUSE_SYMLINK_ROOT else "/docker/debridarr/tmp/cache"
            update_dfs_settings({"cache_dir": cache_dir})
    except Exception as e:
        log.debug(f"DFS settings: {e}")

    try:
        Path(get_dfs_settings()["cache_dir"]).mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

    # Start FUSE
    if FUSE_AVAILABLE:
        _loop = asyncio.get_event_loop()
        _t = start_fuse_mount(s.FUSE_MOUNT, app.state.alldebrid, _loop)
        app.state.fuse_thread = _t
        if _t:
            log.info(f"🗂️  FUSE at {s.FUSE_MOUNT}")
            asyncio.create_task(_load_all_torrents(app))
    else:
        app.state.fuse_thread = None
        log.warning("⚠️  FUSE unavailable")

    asyncio.create_task(_cleanup_loop(app))
    asyncio.create_task(_symlink_health_loop(app))
    asyncio.create_task(_episode_sync_loop(app))
    asyncio.create_task(_auto_add_loop(app))
    asyncio.create_task(_theater_release_loop(app))

    yield

    if getattr(app.state, "fuse_thread", None):
        stop_fuse_mount(app.state.settings.FUSE_MOUNT)


app = FastAPI(title="Debridarr", version="0.5.0", lifespan=lifespan)


def _pg_html(total: int, page: int, n_pages: int, per_page: int,
             base_url: str, pp_options: list[int]) -> str:
    """Reusable pagination bar — renders .pg div with prev/next/ellipsis/per-page."""
    if n_pages <= 1 and total <= min(pp_options):
        return ""
    parts = []
    if page > 1:
        parts.append(f'<a href="{base_url}&page={page-1}&per_page={per_page}">← Prev</a>')
    if n_pages <= 7:
        for p in range(1, n_pages+1):
            cls = ' class="cur"' if p == page else ""
            parts.append(f'<a href="{base_url}&page={p}&per_page={per_page}"{cls}>{p}</a>')
    else:
        def _l(p):
            cls = ' class="cur"' if p == page else ""
            return f'<a href="{base_url}&page={p}&per_page={per_page}"{cls}>{p}</a>'
        parts.append(_l(1))
        if page > 3:   parts.append('<span class="dots">…</span>')
        for p in range(max(2, page-1), min(n_pages, page+2)): parts.append(_l(p))
        if page < n_pages-2: parts.append('<span class="dots">…</span>')
        parts.append(_l(n_pages))
    if page < n_pages:
        parts.append(f'<a href="{base_url}&page={page+1}&per_page={per_page}">Next →</a>')
    parts.append(f'<span style="color:#555;font-size:0.75rem">{total} total</span>')
    opts = "".join(
        f'<option value="{base_url}&page=1&per_page={n}" {"selected" if n==per_page else ""}>{n}/page</option>'
        for n in pp_options
    )
    parts.append(f'<select onchange="location.href=this.value" style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:6px;padding:5px 10px;color:#aaa;font-size:0.78rem;cursor:pointer">{opts}</select>')
    return '<div class="pg" style="margin:14px 0">' + " ".join(parts) + "</div>"


def _needs_setup(request: Request) -> bool:
    return not getattr(request.app.state, "setup_complete", False)

def _setup_redirect():
    return RedirectResponse("/setup", status_code=302)


# ── Styles ────────────────────────────────────────────────────────────────────
_CSS = """
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
       background: #0f0f13; color: #e0e0e0; min-height: 100vh; }
header { background: #1a1a24; border-bottom: 1px solid #2a2a3a;
         padding: 14px 28px; display: flex; align-items: center; gap: 16px; }
header h1 { font-size: 1.3rem; color: #fff; }
header .ver { font-size: 0.75rem; background: #f97316; color: #fff;
              border-radius: 4px; padding: 2px 8px; }
nav { display: flex; gap: 4px; margin-left: auto; }
nav a { color: #aaa; text-decoration: none; padding: 6px 14px; border-radius: 6px;
        font-size: 0.85rem; transition: background .15s; }
nav a:hover, nav a.active { background: #2a2a3a; color: #fff; }
main { padding: 28px; max-width: 1400px; margin: 0 auto; }
h2 { font-size: 1.05rem; color: #ccc; margin-bottom: 18px; }
.card-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 14px; }
.card { background: #1a1a24; border: 1px solid #2a2a3a; border-radius: 10px; overflow: hidden; }
.card img { width: 100%; aspect-ratio: 2/3; object-fit: cover; background: #111; display: block; }
.card .no-poster { width: 100%; aspect-ratio: 2/3; background: #1a1a2e;
                   display: flex; align-items: center; justify-content: center;
                   font-size: 2rem; color: #333; }
.card .info { padding: 10px 12px; }
.card .title { font-size: 0.85rem; font-weight: 600; color: #e0e0e0;
               white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.card .meta  { font-size: 0.72rem; color: #555; margin-top: 3px; }
.card .actions { padding: 0 10px 10px; display: flex; gap: 6px; flex-wrap: wrap; }
.btn { display: inline-block; padding: 5px 12px; border-radius: 6px; font-size: 0.78rem;
       font-weight: 600; border: none; cursor: pointer; text-decoration: none; transition: opacity .15s; }
.btn-add  { background: #f97316; color: #fff; }
.btn-add:hover { opacity: .85; }
.btn-rem  { background: #3b1f00; color: #fb923c; }
.btn-sec  { background: #1e3a5f; color: #60a5fa; }
.badge-in { display: inline-block; background: #14532d; color: #4ade80;
            font-size: 0.68rem; font-weight: 700; padding: 2px 7px; border-radius: 20px; }
.badge-grey { display: inline-block; background: #1a1a24; color: #555;
              font-size: 0.68rem; padding: 2px 7px; border-radius: 20px; border: 1px solid #2a2a3a; }
.search-bar { display: flex; gap: 10px; margin-bottom: 20px; }
.search-bar input { flex: 1; background: #1a1a24; border: 1px solid #2a2a3a;
                    border-radius: 8px; padding: 9px 14px; color: #e0e0e0; font-size: 0.9rem; outline: none; }
.search-bar input:focus { border-color: #f97316; }
.tabs { display: flex; gap: 2px; margin-bottom: 20px; }
.tab { padding: 8px 20px; border-radius: 8px; cursor: pointer; font-size: 0.85rem;
       font-weight: 600; border: 1px solid #2a2a3a; background: #1a1a24; color: #888; }
.tab.active { background: #f97316; color: #fff; border-color: #f97316; }
.empty { text-align: center; padding: 60px; color: #444; font-size: 0.9rem; }
.toast { position: fixed; bottom: 24px; right: 24px; background: #1a1a24;
         border: 1px solid #2a2a3a; border-radius: 10px; padding: 12px 20px;
         font-size: 0.85rem; opacity: 0; transition: opacity .3s; z-index: 999; }
.toast.show { opacity: 1; }
table { width: 100%; border-collapse: collapse; background: #1a1a24;
        border-radius: 10px; overflow: hidden; }
th { text-align: left; padding: 11px 14px; font-size: 0.72rem; text-transform: uppercase;
     color: #555; border-bottom: 1px solid #2a2a3a; }
td { padding: 10px 14px; border-bottom: 1px solid #1e1e2e; font-size: 0.85rem; }
tr:last-child td { border-bottom: none; }
.pill { padding: 2px 9px; border-radius: 20px; font-size: 0.72rem; font-weight: 600; }
.pill-ok   { background: #14532d; color: #4ade80; }
.pill-res  { background: #1e3a5f; color: #60a5fa; }
.pill-err  { background: #3b0000; color: #f87171; }
.pill-pend { background: #2d2d00; color: #facc15; }
.pill-nf   { background: #3b1f00; color: #fb923c; }
.pill-thtr { background: #2d1a4e; color: #c084fc; }
.pg { display:flex; align-items:center; gap:6px; flex-wrap:wrap; margin:12px 0; }
.pg a, .pg .cur, .pg .dots { display:inline-flex; align-items:center; justify-content:center;
    min-width:32px; height:32px; padding:0 8px; border-radius:6px; font-size:0.82rem;
    text-decoration:none; border:1px solid #2a2a3a; background:#1a1a24; color:#aaa; }
.pg a:hover { border-color:#f97316; color:#f97316; }
.pg .cur { background:#f97316; color:#fff; border-color:#f97316; font-weight:700; }
.pg .dots { background:transparent; border-color:transparent; color:#444; min-width:20px; }
"""

_NAV = lambda active: f"""
<nav>
  <a href="/library"  class="{'active' if active=='library'  else ''}">📚 Library</a>
  <a href="/movies"   class="{'active' if active=='movies'   else ''}">🎬 Movies</a>
  <a href="/series"   class="{'active' if active=='series'   else ''}">📺 Series</a>
  <a href="/missing"  class="{'active' if active=='missing'  else ''}">🔍 Missing</a>
  <a href="/settings" class="{'active' if active=='settings' else ''}">⚙️ Settings</a>
</nav>"""

_TOAST_JS = """
function toast(msg, ok=true) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.style.borderColor = ok ? '#4ade80' : '#f87171';
  t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 3500);
}"""

def _page(title, nav_active, body, extra=""):
    return HTMLResponse(f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>{title} — Debridarr</title>
  <style>{_CSS}</style>{extra}
</head>
<body>
  <header>
    <h1>🎬 Debridarr</h1><span class="ver">v0.5.0</span>
    {_NAV(nav_active)}
  </header>
  <main>{body}</main>
  <div id="toast" class="toast"></div>
  <script>{_TOAST_JS}</script>
</body>
</html>""")


# ── Setup ─────────────────────────────────────────────────────────────────────
_SETUP_CSS = _CSS + """
.wizard { max-width: 620px; margin: 60px auto; }
.wizard-card { background: #1a1a24; border: 1px solid #2a2a3a; border-radius: 14px; padding: 36px; }
.wizard h2 { font-size: 1.4rem; color: #fff; margin-bottom: 6px; }
.wizard .sub { color: #666; font-size: 0.88rem; margin-bottom: 28px; line-height: 1.5; }
.steps { display: flex; gap: 0; margin-bottom: 32px; }
.step { flex: 1; text-align: center; font-size: 0.7rem; color: #444; padding-bottom: 8px;
        border-bottom: 2px solid #2a2a3a; }
.step.done   { color: #4ade80; border-color: #4ade80; }
.step.active { color: #f97316; border-color: #f97316; font-weight: 700; }
.field { margin-bottom: 20px; }
.field label { display: block; font-size: 0.8rem; color: #888; margin-bottom: 6px; font-weight: 600; }
.field input { width: 100%; background: #0f0f13; border: 1px solid #2a2a3a; border-radius: 8px;
               padding: 10px 14px; color: #e0e0e0; font-size: 0.9rem; outline: none; font-family: monospace; }
.field input:focus { border-color: #f97316; }
.field .hint { font-size: 0.75rem; color: #555; margin-top: 5px; line-height: 1.4; }
.field .hint a { color: #f97316; }
.test-result { margin-top: 10px; padding: 8px 12px; border-radius: 6px; font-size: 0.82rem; display: none; }
.test-result.ok      { background: #14532d; color: #4ade80; display: block; }
.test-result.err     { background: #3b0000; color: #f87171; display: block; }
.test-result.testing { background: #1e1e2e; color: #aaa; display: block; }
.row { display: flex; gap: 10px; }
.row .field { flex: 1; }
.actions { display: flex; gap: 10px; margin-top: 28px; justify-content: flex-end; }
.btn-primary { background: #f97316; color: #fff; padding: 10px 24px; border-radius: 8px;
               font-size: 0.9rem; font-weight: 600; border: none; cursor: pointer; }
.btn-primary:hover { opacity: .85; }
.btn-primary:disabled { opacity: .4; cursor: not-allowed; }
.btn-ghost { background: transparent; color: #666; padding: 10px 16px; border-radius: 8px;
             font-size: 0.9rem; border: 1px solid #2a2a3a; cursor: pointer; }
.btn-ghost:hover { color: #ccc; border-color: #444; }
.confirm-row { display: flex; justify-content: space-between; padding: 10px 0;
               border-bottom: 1px solid #1e1e2e; font-size: 0.875rem; }
.confirm-row:last-child { border-bottom: none; }
.confirm-row .lbl { color: #666; }
.confirm-row .val { color: #e0e0e0; font-family: monospace; font-size: 0.82rem; }
"""

def _setup_page(body, step):
    step_names = ["Welcome", "AllDebrid", "Overseerr", "Plex", "Confirm"]
    step_keys  = ["welcome", "alldebrid", "overseerr", "plex", "confirm"]
    idx = step_keys.index(step) if step in step_keys else 0
    steps_html = "".join(
        f'<div class="step {"done" if i < idx else "active" if i == idx else ""}">{n}</div>'
        for i, n in enumerate(step_names)
    )
    return HTMLResponse(f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Debridarr Setup</title>
  <style>{_SETUP_CSS}</style>
</head>
<body>
  <header>
    <h1>🎬 Debridarr</h1><span class="ver">v0.5.0</span>
    <span style="margin-left:auto;color:#555;font-size:0.8rem">First-run setup</span>
  </header>
  <div class="wizard">
    <div class="steps">{steps_html}</div>
    <div class="wizard-card">{body}</div>
  </div>
  <div id="toast" class="toast"></div>
  <script>{_TOAST_JS}</script>
</body>
</html>""")


@app.get("/setup", response_class=HTMLResponse)
async def setup_get(request: Request, step: str = "welcome"):
    cfg = load_saved_config()

    if step == "welcome":
        return _setup_page("""
        <div style="font-size:4rem;text-align:center;margin-bottom:20px">🎬</div>
        <h2>Welcome to Debridarr</h2>
        <p class="sub">Connect Debridarr to AllDebrid and Overseerr. Takes ~2 minutes.</p>
        <div class="actions">
          <a href="/setup?step=alldebrid" class="btn-primary" style="text-decoration:none;display:inline-block;padding:10px 24px">Get Started →</a>
        </div>""", "welcome")

    if step == "alldebrid":
        val = cfg.get("ALLDEBRID_API_KEY", "")
        return _setup_page(f"""
        <h2>AllDebrid</h2>
        <p class="sub">Debridarr uses AllDebrid to stream cached torrents instantly.</p>
        <div class="field">
          <label>API Key</label>
          <input id="api_key" type="password" value="{val}" placeholder="Paste your AllDebrid API key">
          <div class="hint">Get yours at <a href="https://alldebrid.com/apikeys" target="_blank">alldebrid.com/apikeys</a></div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="actions">
          <a href="/setup?step=welcome" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="btn" onclick="go()">Test & Continue →</button>
        </div>
        <script>
        async function go() {{
          const key = document.getElementById('api_key').value.trim();
          const res = document.getElementById('test-result');
          const btn = document.getElementById('btn');
          if (!key) {{ res.className='test-result err'; res.textContent='API key required'; return; }}
          res.className='test-result testing'; res.textContent='Testing...'; btn.disabled=true;
          const r = await fetch('/setup/test', {{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{step:'alldebrid',api_key:key}})}});
          const d = await r.json(); btn.disabled=false;
          if (d.ok) {{ res.className='test-result ok'; res.textContent='✅ '+d.message;
            setTimeout(()=>window.location='/setup?step=overseerr&akey='+encodeURIComponent(key),800); }}
          else {{ res.className='test-result err'; res.textContent='❌ '+d.message; }}
        }}
        document.getElementById('api_key').addEventListener('keydown',e=>{{if(e.key==='Enter')go();}});
        </script>""", "alldebrid")

    if step == "overseerr":
        url_val = cfg.get("OVERSEERR_URL", "http://192.168.1.x:5055")
        key_val = cfg.get("OVERSEERR_API_KEY", "")
        akey    = request.query_params.get("akey", cfg.get("ALLDEBRID_API_KEY", ""))
        return _setup_page(f"""
        <h2>Overseerr</h2>
        <p class="sub">Connect to your Overseerr instance to browse your request library.</p>
        <div class="field">
          <label>Overseerr URL</label>
          <input id="url" type="text" value="{url_val}" placeholder="http://192.168.1.x:5055">
        </div>
        <div class="field">
          <label>API Key</label>
          <input id="key" type="password" value="{key_val}" placeholder="Overseerr API key">
          <div class="hint">Overseerr → Settings → General → API Key</div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="actions">
          <a href="/setup?step=alldebrid" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="btn" onclick="go()">Test & Continue →</button>
        </div>
        <input type="hidden" id="akey" value="{akey}">
        <script>
        async function go() {{
          const url=document.getElementById('url').value.trim();
          const key=document.getElementById('key').value.trim();
          const akey=document.getElementById('akey').value;
          const res=document.getElementById('test-result'); const btn=document.getElementById('btn');
          res.className='test-result testing'; res.textContent='Testing...'; btn.disabled=true;
          const r=await fetch('/setup/test',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{step:'overseerr',url,api_key:key}})}});
          const d=await r.json(); btn.disabled=false;
          if(d.ok){{res.className='test-result ok';res.textContent='✅ '+d.message;
            setTimeout(()=>window.location='/setup?step=plex&akey='+encodeURIComponent(akey)+'&ourl='+encodeURIComponent(url)+'&okey='+encodeURIComponent(key),800);}}
          else{{res.className='test-result err';res.textContent='❌ '+d.message;}}
        }}
        </script>""", "overseerr")

    if step == "plex":
        qs = dict(request.query_params)
        hidden = "".join(f'<input type="hidden" id="{k}" value="{v}">' for k, v in qs.items() if k != "step")
        tz_val   = cfg.get("TZ", "America/Edmonton")
        puid_val = cfg.get("PUID", "1000")
        pgid_val = cfg.get("PGID", "1000")
        base_url = cfg.get("DEBRIDARR_BASE_URL", "http://192.168.1.x:7474")
        return _setup_page(f"""
        <h2>Plex Integration</h2>
        <p class="sub">Where to write library files and how Plex reaches Debridarr.</p>
        <div class="field">
          <label>Plex Library Path (inside container)</label>
          <input id="plex_root" type="text" value="/plex-strm" placeholder="/plex-strm">
          <div class="hint">Must be bind-mounted into both Debridarr and Plex.</div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="field">
          <label>Debridarr Base URL (as seen by Plex)</label>
          <input id="base_url" type="text" value="{base_url}" placeholder="http://192.168.1.x:7474">
        </div>
        <div class="row">
          <div class="field"><label>Timezone</label><input id="tz" value="{tz_val}"></div>
          <div class="field"><label>PUID</label><input id="puid" value="{puid_val}"></div>
          <div class="field"><label>PGID</label><input id="pgid" value="{pgid_val}"></div>
        </div>
        {hidden}
        <div class="actions">
          <a href="/setup?step=overseerr" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="btn" onclick="go()">Test & Continue →</button>
        </div>
        <script>
        async function go(){{
          const plex_root=document.getElementById('plex_root').value.trim();
          const res=document.getElementById('test-result'); const btn=document.getElementById('btn');
          res.className='test-result testing'; res.textContent='Checking...'; btn.disabled=true;
          const r=await fetch('/setup/test',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{step:'plex',plex_root}})}});
          const d=await r.json(); btn.disabled=false;
          if(d.ok){{res.className='test-result ok';res.textContent='✅ '+d.message;
            const prev={{}};
            document.querySelectorAll('input[type=hidden]').forEach(i=>prev[i.id]=i.value);
            const p=new URLSearchParams({{...prev,step:'confirm',plex_root,
              base_url:document.getElementById('base_url').value.trim(),
              tz:document.getElementById('tz').value.trim(),
              puid:document.getElementById('puid').value.trim(),
              pgid:document.getElementById('pgid').value.trim()}});
            setTimeout(()=>window.location='/setup?'+p.toString(),800);}}
          else{{res.className='test-result err';res.textContent='❌ '+d.message;}}
        }}
        </script>""", "plex")

    if step == "confirm":
        qs = dict(request.query_params)
        def row(lbl, key, mask=False):
            val = qs.get(key, "—")
            display = ("•" * 8 + val[-4:]) if mask and val and val != "—" else val
            return f'<div class="confirm-row"><span class="lbl">{lbl}</span><span class="val">{display}</span></div>'
        hidden = "".join(f'<input type="hidden" name="{k}" value="{v}">' for k, v in qs.items() if k != "step")
        return _setup_page(f"""
        <h2>Confirm & Save</h2>
        <p class="sub">Review settings and click Save to finish.</p>
        <div style="margin-bottom:24px">
          {row("AllDebrid API Key", "akey", mask=True)}
          {row("Overseerr URL", "ourl")}
          {row("Overseerr API Key", "okey", mask=True)}
          {row("Plex Library Path", "plex_root")}
          {row("Debridarr Base URL", "base_url")}
          {row("Timezone", "tz")}
        </div>
        <form method="POST" action="/setup/save">
          {hidden}
          <div class="actions">
            <a href="/setup?step=plex" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
            <button type="submit" class="btn-primary">💾 Save & Finish</button>
          </div>
        </form>""", "confirm")

    return RedirectResponse("/setup")


@app.post("/setup/test")
async def setup_test(request: Request):
    body = await request.json()
    step = body.get("step")
    if step == "alldebrid":  ok, msg = await test_alldebrid(body.get("api_key", ""))
    elif step == "overseerr": ok, msg = await test_overseerr(body.get("url", ""), body.get("api_key", ""))
    elif step == "plex":      ok, msg = await test_plex_root(body.get("plex_root", ""))
    else:                     ok, msg = False, "Unknown step"
    return JSONResponse({"ok": ok, "message": msg})


@app.post("/setup/save")
async def setup_save(request: Request):
    form = dict(await request.form())
    config = {
        "ALLDEBRID_API_KEY":  form.get("akey", ""),
        "OVERSEERR_URL":      form.get("ourl", ""),
        "OVERSEERR_API_KEY":  form.get("okey", ""),
        "DEBRIDARR_BASE_URL": form.get("base_url", ""),
        "TZ":                 form.get("tz", "America/Edmonton"),
        "PUID":               form.get("puid", "1000"),
        "PGID":               form.get("pgid", "1000"),
    }
    write_env(config)
    import os
    for k, v in config.items(): os.environ[k] = v
    os.environ["PLEX_ROOT"] = form.get("plex_root", "/plex-strm")
    mark_setup_complete()
    request.app.state.setup_complete = True
    _init_clients(request.app)
    log.info("✅ Setup complete — restarting...")
    _schedule_restart(delay=2.0)
    return HTMLResponse(f"""<!DOCTYPE html><html><head><meta charset="UTF-8">
<meta http-equiv="refresh" content="6;url=/library">
<style>{_SETUP_CSS}</style></head><body>
<header><h1>🎬 Debridarr</h1><span class="ver">v0.5.0</span></header>
<div class="wizard"><div class="wizard-card" style="text-align:center;padding:48px">
<div style="font-size:3rem;margin-bottom:16px">🎉</div>
<h2 style="color:#4ade80;margin-bottom:12px">Setup Complete!</h2>
<p style="color:#888;margin-bottom:24px">Redirecting to library...</p>
<a href="/library" style="color:#f97316">Click here if not redirected</a>
</div></div></body></html>""")


# ── / redirect ────────────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    if _needs_setup(request): return _setup_redirect()
    return RedirectResponse("/library")


# ── /library — browse Overseerr ───────────────────────────────────────────────
@app.get("/library", response_class=HTMLResponse)
async def library_browse(request: Request, tab: str = "movies", q: str = "",
                         page: int = 1, per_page: int = 24):
    if _needs_setup(request): return _setup_redirect()
    lm: LibraryManager = request.app.state.library
    db: CacheDB = request.app.state.db

    already_added = {(r["media_type"], r["title"].lower()) for r in db.fake_library_list()}

    if tab == "movies":
        all_items = await lm.get_radarr_movies()
    else:
        all_items = await lm.get_sonarr_series()

    if q:
        ql = q.lower()
        all_items = [i for i in all_items if ql in i["title"].lower()]

    total       = len(all_items)
    n_pages     = max(1, (total + per_page - 1) // per_page)
    page        = max(1, min(page, n_pages))
    items       = all_items[(page-1)*per_page : page*per_page]

    def _card(item):
        mtype  = "movie" if tab == "movies" else "series"
        year   = item.get("year")
        in_lib = (mtype, item["title"].lower()) in already_added
        poster = item.get("poster", "")
        t      = item["title"].replace('"', '&quot;')
        sc     = item.get("season_count", 0)
        meta   = str(year or "")
        if tab != "movies" and sc:
            meta += f" · {sc} season{'s' if sc != 1 else ''}"

        if poster:
            img = (f'<img src="{poster}" loading="lazy" '
                   f'onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'flex\'">'
                   f'<div class="no-poster" style="display:none">{item["title"][:1]}</div>')
        else:
            img = f'<div class="no-poster">{item["title"][:1]}</div>'

        if in_lib:
            action = (f'<span class="badge-in" style="font-size:0.7rem">✓ In Library</span>'
                      f'<button class="btn btn-rem btn-sm" data-mtype="{mtype}" data-title="{t}" '
                      f'data-year="{year or ""}" onclick="remCard(this)">Remove</button>')
        else:
            action = (f'<button class="btn btn-add btn-sm" data-mtype="{mtype}" '
                      f'data-id="{item.get("id","")}" data-title="{t}" '
                      f'data-year="{year or ""}" data-sc="{sc}" onclick="addCard(this)">+ Add</button>')

        return (f'<div class="card">{img}'
                f'<div class="info"><div class="title" title="{t}">{item["title"]}</div>'
                f'<div class="meta">{meta}</div></div>'
                f'<div class="actions">{action}</div></div>')

    cards = "".join(_card(i) for i in items)
    if not cards:
        cards = f'<div class="empty">{"No results for &quot;"+q+"&quot;" if q else "Nothing found — check Overseerr settings"}</div>'

    movie_count = len(await lm.get_radarr_movies())
    tv_count    = len(await lm.get_sonarr_series())

    # Pagination
    base = f"/library?tab={tab}&q={q}"
    def pg_link(p, lbl=None):
        h   = f"{base}&page={p}&per_page={per_page}"
        cls = ' class="cur"' if p == page else ""
        return f'<a href="{h}"{cls}>{lbl or p}</a>'

    pg_parts = []
    if page > 1: pg_parts.append(pg_link(page-1, "← Prev"))
    if n_pages <= 7:
        for p in range(1, n_pages+1): pg_parts.append(pg_link(p))
    else:
        pg_parts.append(pg_link(1))
        if page > 3: pg_parts.append('<span class="dots">…</span>')
        for p in range(max(2, page-1), min(n_pages, page+2)): pg_parts.append(pg_link(p))
        if page < n_pages-2: pg_parts.append('<span class="dots">…</span>')
        pg_parts.append(pg_link(n_pages))
    if page < n_pages: pg_parts.append(pg_link(page+1, "Next →"))
    pg_parts.append(f'<span style="color:#555;font-size:0.75rem">{total} total</span>')
    pp_opts = "".join(
        f'<option value="{base}&page=1&per_page={n}" {"selected" if n==per_page else ""}>{n}/page</option>'
        for n in [12, 24, 48, 96]
    )
    pg_parts.append(f'<select onchange="location.href=this.value" style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:6px;padding:5px 10px;color:#aaa;font-size:0.78rem;cursor:pointer">{pp_opts}</select>')
    pg_html = '<div class="pg" style="margin:14px 0">' + " ".join(pg_parts) + "</div>"

    body = f"""
    <h2>Browse Library</h2>
    <div class="tabs">
      <div class="tab {'active' if tab=='movies' else ''}" onclick="location.href='/library?tab=movies&q={q}'">🎬 Movies ({movie_count})</div>
      <div class="tab {'active' if tab=='tv'     else ''}" onclick="location.href='/library?tab=tv&q={q}'">📺 TV Shows ({tv_count})</div>
    </div>
    <div class="search-bar">
      <input id="q" type="text" placeholder="Search..." value="{q}"
             onkeydown="if(event.key==='Enter')location.href='/library?tab={tab}&q='+encodeURIComponent(this.value)">
      <button class="btn btn-add" onclick="location.href='/library?tab={tab}&q='+encodeURIComponent(document.getElementById('q').value)">Search</button>
      {'<button class="btn btn-sec" onclick="location.href=\'/library?tab='+tab+'\'">Clear</button>' if q else ''}
      <button class="btn btn-sec" onclick="refreshLib()">🔄 Refresh</button>
    </div>
    {pg_html}
    <div class="card-grid">{cards}</div>
    {pg_html}"""

    extra = """<script>
function addCard(btn) {
  const type  = btn.dataset.mtype;
  const id    = parseInt(btn.dataset.id) || null;
  const title = btn.dataset.title;
  const year  = btn.dataset.year ? parseInt(btn.dataset.year) : null;
  const sc    = parseInt(btn.dataset.sc) || 0;
  addItem(type, id, title, year, sc);
}
function removeCard(btn) {
  const type  = btn.dataset.mtype;
  const title = btn.dataset.title;
  const year  = btn.dataset.year ? parseInt(btn.dataset.year) : null;
  removeItem(type, title, year);
}
async function addItem(type, id, title, year, sc) {
  const r = await fetch('/api/library/add', {method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({media_type:type,arr_id:id,title,year,season_count:sc})});
  const d = await r.json();
  if (r.ok) { toast('✅ '+title+' added'); setTimeout(()=>location.reload(),1200); }
  else { toast('❌ '+(d.detail||d.message||'Error'), false); }
}
async function removeItem(type, title, year) {
  if (!confirm('Remove "'+title+'" from library?\n\nThis will delete ALL cached streams, symlinks, and remove torrents from AllDebrid.')) return;
  const r = await fetch('/api/library/remove',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({media_type:type,title,year})});
  if (r.ok) { toast('🗑️ Removed'); setTimeout(()=>location.reload(),1200); }
  else { toast('❌ Error', false); }
}
async function refreshLib() {
  const r = await fetch('/api/library/refresh',{method:'POST'});
  const d = await r.json();
  toast('✅ Refreshed — '+d.synced+' series updated');
  setTimeout(()=>location.reload(),1200);
}
</script>"""
    return _page("Browse Library", "library", body, extra)


# ── /api/library/add ─────────────────────────────────────────────────────────
@app.post("/api/library/add")
async def api_library_add(request: Request, background_tasks: BackgroundTasks):
    body = await request.json()
    media_type   = body.get("media_type", "movie")
    arr_id       = body.get("arr_id")
    title        = body.get("title", "").strip()
    year         = body.get("year")
    season_count = body.get("season_count", 0)

    if not title:
        raise HTTPException(400, "title required")

    lm: LibraryManager = request.app.state.library
    db: CacheDB         = request.app.state.db
    tmdb_key            = db.get_setting("tmdb_api_key", "")

    if media_type == "movie":
        # Fetch full movie details from Overseerr to get poster/overview/tmdb_id
        movies = await lm.get_radarr_movies()
        movie  = next((m for m in movies if m.get("id") == arr_id or m["title"].lower() == title.lower()), None)

        path = lm.create_fake_movie(title, year)

        poster_url = movie.get("poster", "") if movie else ""
        tmdb_id    = movie.get("tmdb_id") if movie else None
        imdb_id    = movie.get("imdb_id") if movie else None
        overview   = movie.get("overview", "") if movie else ""

        # Fetch poster from TMDB if not from Overseerr
        if not poster_url and tmdb_key and tmdb_id:
            poster_url = await _fetch_tmdb_poster(tmdb_id, title, True, tmdb_key)

        db.fake_library_add({
            "media_type": "movie",
            "title":      title,
            "year":       year,
            "radarr_id":  arr_id,
            "tmdb_id":    tmdb_id,
            "imdb_id":    imdb_id,
            "poster_url": poster_url,
            "overview":   overview,
            "status":     "movie",
            "fake_path":  str(path) if path else None,
        })
        log.info(f"🎬 Added movie: {title} ({year})")
        background_tasks.add_task(_precache_movie, request.app, title, year, tmdb_id, imdb_id)
        return {"status": "ok", "message": f"Added {title}"}

    else:
        # Series — fetch details synchronously so we can return a useful response
        series_list = await lm.get_sonarr_series()
        series = next((s for s in series_list if s.get("id") == arr_id), None)

        sc                = series.get("season_count", season_count) if series else season_count
        tvdb_id           = series.get("tvdb_id") if series else None
        tmdb_id           = series.get("tmdb_id") if series else None
        imdb_id           = series.get("imdb_id") if series else None
        poster_url        = series.get("poster", "") if series else ""
        overview          = series.get("overview", "") if series else ""
        is_ended          = series.get("is_ended", False) if series else False
        requested_seasons = series.get("requested_seasons", []) if series else []

        if not poster_url and tmdb_key and tmdb_id:
            poster_url = await _fetch_tmdb_poster(tmdb_id, title, False, tmdb_key)

        include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"

        # Fetch ALL aired episodes from Overseerr/TMDB
        episodes = await lm.get_episodes(
            arr_id,
            include_unreleased=include_unreleased,
            requested_seasons=requested_seasons if requested_seasons else None,
        )

        log.info(f"📺 {title}: {len(episodes)} episodes from Overseerr for seasons {requested_seasons}")

        # Write placeholder .mp4 for every episode immediately
        paths = lm.create_fake_episodes(title, year, [], episodes)

        db.fake_library_add({
            "media_type":   "series",
            "title":        title,
            "year":         year,
            "sonarr_id":    arr_id,
            "tvdb_id":      tvdb_id,
            "tmdb_id":      tmdb_id,
            "imdb_id":      imdb_id,
            "season_count": sc,
            "poster_url":   poster_url,
            "overview":     overview,
            "status":       "ended" if is_ended else "continuing",
            "fake_path":    str(Path(lm.plex_root) / "tv" / title) if lm.plex_root else None,
        })

        log.info(f"📺 Added {title!r} — {len(paths)}/{len(episodes)} placeholders written")

        # Cache all episodes in background (so play works immediately)
        background_tasks.add_task(_precache_series, request.app, title, year, episodes)
        return {"status": "ok", "message": f"Added {title} — {len(episodes)} episodes"}


@app.post("/api/library/remove")
async def api_library_remove(request: Request):
    body      = await request.json()
    mtype     = body.get("media_type")
    title     = body.get("title", "").strip()
    year      = body.get("year")
    lm        = request.app.state.library
    db        = request.app.state.db
    s         = request.app.state.settings
    alldebrid = request.app.state.alldebrid

    # 1. Hard-expire every cache entry for this title:
    #    — deletes its plex-strm symlink
    #    — removes from AllDebrid
    #    — unregisters from FUSE
    #    — deletes the DB row
    db_types = ["movie"] if mtype == "movie" else ["episode", "series"]
    entries  = [e for e in db.list_all()
                if e["title"].lower() == title.lower() and e["media_type"] in db_types]
    for entry in entries:
        await _hard_expire(entry, db, s, alldebrid)
    log.info(f"🗑️  Hard-expired {len(entries)} cache entries for '{title}'")

    # 2. Remove the entire plex-strm folder (catches any stragglers not in DB)
    if mtype == "movie": lm.remove_fake_movie(title, year)
    else:                lm.remove_fake_series(title)

    # 3. Remove from fake_library DB
    db.fake_library_remove(mtype, title, year)

    # 4. Clear search cache so re-adding gets a fresh search
    from app.alldebrid import _search_cache
    for k in [k for k in list(_search_cache.keys()) if title.lower() in k.lower()]:
        del _search_cache[k]

    log.info(f"✅ Fully removed '{title}' ({mtype}) — {len(entries)} streams cleaned up")
    return {"status": "removed", "streams_cleaned": len(entries)}


@app.post("/api/library/refresh")
async def api_library_refresh(request: Request):
    lm = request.app.state.library
    db = request.app.state.db
    if not lm: return {"status": "error", "message": "Not configured"}
    lm.invalidate_cache()
    movies = await lm.get_radarr_movies(force=True)
    series = await lm.get_sonarr_series(force=True)
    added  = [r for r in db.fake_library_list() if r["media_type"] == "series"]
    include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"
    synced = 0
    for entry in added:
        sid = entry.get("sonarr_id")
        if not sid: continue
        updated = next((s for s in series if s.get("id") == sid), None)
        if not updated: continue
        result = await lm.sync_series_episodes(entry["title"], sid, entry.get("year"),
                                                include_unreleased,
                                                requested_seasons=updated.get("requested_seasons", []))
        if result.get("added", 0) > 0: synced += 1
    return {"status": "ok", "movies": len(movies), "series": len(series), "synced": synced}


# ── /streams redirect ────────────────────────────────────────────────────────
@app.get("/streams")
async def streams_redirect():
    from fastapi.responses import RedirectResponse
    return RedirectResponse("/movies", status_code=302)


# ── /movies — cached movies ──────────────────────────────────────────────────
@app.get("/movies", response_class=HTMLResponse)
async def movies_page(request: Request, q: str = "", filter_status: str = "all",
                      page: int = 1, per_page: int = 24):
    if _needs_setup(request): return _setup_redirect()
    db: CacheDB = request.app.state.db
    s           = request.app.state.settings
    plex_root   = getattr(s, "PLEX_ROOT", "") or ""

    # ── Metadata from fake_library (posters, year, etc.) ──────────────────────
    lib_meta: dict[str, dict] = {
        r["title"].lower(): r for r in db.fake_library_list(media_type="movie")
    }

    # ── Status from cache DB ───────────────────────────────────────────────────
    db_cache: dict[str, dict] = {}
    for e in db.list_all():
        if e["media_type"] == "movie":
            db_cache[e["title"].lower()] = e

    # ── FUSE mount scan — source of truth for what's actually cached ───────────
    fuse_movies: dict[str, dict] = {}   # title_lower → {title, year, status, quality}
    if plex_root:
        movies_root = Path(plex_root) / "movies"
        if movies_root.exists():
            for d in sorted(movies_root.iterdir()):
                if not d.is_dir():
                    continue
                m_f = re.match(r"^(.+?)\s*\((\d{4})\)\s*$", d.name)
                title = m_f.group(1).strip() if m_f else d.name.strip()
                year  = int(m_f.group(2)) if m_f else None
                has_symlink = any(f.is_symlink() for f in d.iterdir())
                has_mp4     = any(not f.is_symlink() and f.suffix == ".mp4"
                                  for f in d.iterdir())
                fuse_status = "cached" if has_symlink else ("pending" if has_mp4 else None)
                if fuse_status:
                    fuse_movies[title.lower()] = {
                        "title": title, "year": year, "fuse_status": fuse_status
                    }

    # ── Build unified item list: FUSE + library, FUSE status takes priority ────
    seen: set[str] = set()
    items: list[dict] = []

    # First: everything from fake_library (has poster/metadata)
    for title_l, meta in lib_meta.items():
        seen.add(title_l)
        fuse  = fuse_movies.get(title_l, {})
        cache = db_cache.get(title_l, {})
        # FUSE symlink overrides DB "not_found" etc.
        if fuse.get("fuse_status") == "cached":
            status = "cached"
        else:
            status = cache.get("status", "pending")
        items.append({
            **meta,
            "_status":       status,
            "_quality":      cache.get("quality", ""),
            "_key":          cache.get("cache_key", ""),
            "_fuse":         bool(fuse),
            "_unregistered": False,
        })

    # Second: FUSE items NOT in fake_library (auto-discovered)
    for title_l, fuse in fuse_movies.items():
        if title_l in seen:
            continue
        seen.add(title_l)
        cache = db_cache.get(title_l, {})
        items.append({
            "title":         fuse["title"],
            "year":          fuse["year"],
            "poster_url":    "",
            "_status":       "cached" if fuse["fuse_status"] == "cached" else "pending",
            "_quality":      cache.get("quality", ""),
            "_key":          cache.get("cache_key", ""),
            "_fuse":         True,
            "_unregistered": True,
        })

    # ── Filter ─────────────────────────────────────────────────────────────────
    if q:
        ql = q.lower()
        items = [i for i in items if ql in i["title"].lower()]
    if filter_status != "all":
        items = [i for i in items if i["_status"] == filter_status]
    items.sort(key=lambda x: x["title"].lower())

    # ── Pagination ─────────────────────────────────────────────────────────────
    total   = len(items)
    n_pages = max(1, (total + per_page - 1) // per_page)
    page    = max(1, min(page, n_pages))
    items   = items[(page-1)*per_page : page*per_page]

    base = f"/movies?q={q}&filter_status={filter_status}"
    pg   = _pg_html(total, page, n_pages, per_page, base, [12, 24, 48, 96])

    def _status_pill(status):
        cfg = {
            "cached":           ("pill-ok",   "✅ Cached"),
            "resolving":        ("pill-res",   "⚙️ Resolving"),
            "not_found":        ("pill-nf",    "❌ Not found"),
            "awaiting_release": ("pill-thtr",  "🎭 In theaters"),
            "error":            ("pill-err",   "⚠️ Error"),
        }
        cls, lbl = cfg.get(status, ("pill-pend", "⏳ Pending"))
        return f'<span class="pill {cls}" style="font-size:0.68rem">{lbl}</span>'

    def _card(item):
        title          = item["title"]
        year           = item.get("year") or ""
        poster         = item.get("poster_url") or ""
        status         = item["_status"]
        quality        = item["_quality"]
        key            = item["_key"]
        unregistered   = item["_unregistered"]
        safe           = title.replace('"', '&quot;')
        t_js           = title.replace("'", "\\'")
        yr_js          = str(year) if year else "null"

        if poster:
            img = (f'<img src="{poster}" style="width:100%;aspect-ratio:2/3;object-fit:cover;display:block" '
                   f'loading="lazy" onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'flex\'">'
                   f'<div style="width:100%;aspect-ratio:2/3;background:#0f0f13;display:none;'
                   f'align-items:center;justify-content:center;font-size:2.5rem">🎬</div>')
        else:
            img = (f'<div style="width:100%;aspect-ratio:2/3;background:#0f0f13;display:flex;'
                   f'align-items:center;justify-content:center;font-size:2.5rem">🎬</div>')

        q_badge = (f'<span style="font-size:0.65rem;background:#1e3a5f;color:#60a5fa;'
                   f'padding:1px 5px;border-radius:3px;margin-left:4px">{quality}</span>') if quality else ""

        unreg_badge = (
            '<span style="font-size:0.62rem;background:#2d1a4e;color:#c084fc;'
            'padding:1px 5px;border-radius:3px;display:block;margin-top:3px">📂 On disk / unregistered</span>'
        ) if unregistered else ""

        actions = ""
        if unregistered:
            actions = (f'<button class="btn btn-add btn-sm" '
                       f'onclick="registerMovie(\'{t_js}\', {yr_js})">+ Register</button>')
        elif status == "cached" and key:
            actions = (f'<button class="btn btn-sec btn-sm" onclick="expireNow(\'{key}\')" '
                       f'title="Reset and re-cache">🔄 Re-cache</button>')
        elif status in ("not_found", "awaiting_release", "error"):
            actions = (f'<button class="btn btn-sec btn-sm" onclick="cacheMovie(\'{t_js}\', {yr_js})" '
                       f'title="Try caching now">🔎 Cache</button>')

        remove_btn = (
            f'<button class="btn btn-rem btn-sm" data-mtype="movie" data-title="{safe}" '
            f'data-year="{year}" onclick="remCard(this)">Remove</button>'
            if not unregistered else ""
        )

        return (
            f'<div class="card">{img}'
            f'<div class="info">'
            f'<div class="title" title="{safe}">{title}</div>'
            f'<div class="meta">{year}{q_badge}</div>'
            f'{_status_pill(status)}'
            f'{unreg_badge}'
            f'</div>'
            f'<div class="actions">{actions}{remove_btn}</div></div>'
        )

    cards = "".join(_card(i) for i in items)
    if not cards:
        cards = '<div class="empty">No movies match.</div>'

    # Stats
    all_items_unfiltered = [i for i in (list(lib_meta.values())) if True]  # recompute quickly
    total_lib     = len(lib_meta)
    cached_count  = sum(1 for k in lib_meta if
                        fuse_movies.get(k, {}).get("fuse_status") == "cached" or
                        db_cache.get(k, {}).get("status") == "cached")
    fuse_only     = sum(1 for k in fuse_movies if k not in lib_meta)

    status_opts = {"all": "All", "cached": "✅ Cached", "not_found": "❌ Not found",
                   "awaiting_release": "🎭 In theaters", "resolving": "⚙️ Resolving", "pending": "⏳ Pending"}
    sel = "".join(
        f'<option value="{v}" {"selected" if v==filter_status else ""}>{l}</option>'
        for v, l in status_opts.items()
    )

    fuse_note = (f' <span style="font-size:0.78rem;color:#555">· {fuse_only} on disk / unregistered</span>'
                 if fuse_only else "")

    body = f"""
    <h2>🎬 Movies <span style="color:#555;font-size:0.9rem;font-weight:normal">({cached_count} cached of {total_lib}){fuse_note}</span></h2>
    <div class="search-bar" style="margin-bottom:16px">
      <input id="mq" type="text" placeholder="Search movies..." value="{q}"
             onkeydown="if(event.key==='Enter')location.href='/movies?q='+encodeURIComponent(this.value)+'&filter_status={filter_status}'">
      <button class="btn btn-sec" onclick="location.href='/movies?q='+encodeURIComponent(document.getElementById('mq').value)+'&filter_status={filter_status}'">Search</button>
      {'<button class="btn btn-sec" onclick="location.href=\'/movies\'">Clear</button>' if q else ''}
      <select onchange="location.href='/movies?q={q}&filter_status='+this.value"
              style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:8px;padding:8px 12px;color:#e0e0e0;font-size:0.85rem;outline:none">
        {sel}
      </select>
    </div>
    {pg}
    <div class="card-grid">{cards}</div>
    {pg}"""

    extra = """<script>
async function registerMovie(title, year) {
  const r = await fetch('/api/import/plex', {method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({title, year, media_type:'movie'})});
  const d = await r.json();
  toast(r.ok ? '✅ ' + d.message : '❌ '+(d.detail||'Error'), r.ok);
  if (r.ok) setTimeout(()=>location.reload(), 1500);
}
async function cacheMovie(title, year) {
  const r = await fetch('/api/cache/movie', {method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({title, year})});
  const d = await r.json();
  toast(r.ok ? '⚙️ ' + d.message : '❌ ' + (d.detail||'Error'), r.ok);
}
async function expireNow(key) {
  if (!confirm('Reset this cached movie? It will be re-cached on next play.')) return;
  const r = await fetch('/cache/'+key+'/expire', {method:'POST'});
  toast(r.ok ? '🔄 Reset' : '❌ Error', r.ok);
  setTimeout(()=>location.reload(), 1200);
}
async function remCard(btn) {
  const title = btn.dataset.title.replace(/&quot;/g,'"');
  const year  = btn.dataset.year ? parseInt(btn.dataset.year) : null;
  if (!confirm('Remove "'+title+'" from library?\\n\\nThis deletes all cached streams, symlinks, and removes from AllDebrid.')) return;
  const r = await fetch('/api/library/remove', {method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({media_type:'movie', title, year})});
  if (r.ok) { toast('🗑️ Removed'); setTimeout(()=>location.reload(),1200); }
  else { toast('❌ Error', false); }
}
</script>"""
    return _page("Movies", "movies", body, extra)


# ── /series — cached TV series episodes ──────────────────────────────────────
@app.get("/series", response_class=HTMLResponse)
async def series_page(request: Request, q: str = "", page: int = 1, per_page: int = 20):
    if _needs_setup(request): return _setup_redirect()
    db: CacheDB = request.app.state.db
    s           = request.app.state.settings
    plex_root   = getattr(s, "PLEX_ROOT", "") or ""

    series_lib = db.fake_library_list(media_type="series")
    lib_meta:  dict[str, dict] = {r["title"].lower(): r for r in series_lib}

    # ── FUSE scan — source of truth for episode cache status ──────────────────
    # fuse_data[title_lower] = {cached: {sn: set(ep)}, placeholder: {sn: set(ep)}}
    fuse_data: dict[str, dict] = {}
    if plex_root:
        tv_root = Path(plex_root) / "tv"
        if tv_root.exists():
            for show_dir in sorted(tv_root.iterdir()):
                if not show_dir.is_dir():
                    continue
                title_l = show_dir.name.lower()
                cached_eps:  dict[int, set] = {}
                ph_eps:      dict[int, set] = {}
                for sf in show_dir.iterdir():
                    if not sf.is_dir(): continue
                    m = re.match(r"Season\s+(\d+)", sf.name, re.I)
                    if not m: continue
                    sn = int(m.group(1))
                    for f in sf.iterdir():
                        em = re.search(r"E(\d{2})", f.name, re.I)
                        if not em: continue
                        ep = int(em.group(1))
                        if f.is_symlink():
                            cached_eps.setdefault(sn, set()).add(ep)
                        elif f.suffix == ".mp4":
                            ph_eps.setdefault(sn, set()).add(ep)
                if cached_eps or ph_eps:
                    fuse_data[title_l] = {
                        "title":       show_dir.name,
                        "cached":      cached_eps,
                        "placeholder": ph_eps,
                    }

    # ── Merge: library + FUSE-only (auto-discovered series) ───────────────────
    seen:  set[str]  = set()
    items: list[dict] = []

    for title_l, meta in lib_meta.items():
        seen.add(title_l)
        fuse = fuse_data.get(title_l, {"cached": {}, "placeholder": {}})
        items.append({**meta, "_fuse": fuse, "_unregistered": False})

    for title_l, fuse in fuse_data.items():
        if title_l in seen:
            continue
        seen.add(title_l)
        items.append({
            "title":    fuse["title"], "year": None, "poster_url": "",
            "status":   "continuing",  "season_count": 0,
            "_fuse":    fuse,          "_unregistered": True,
        })

    # ── Filter & sort ──────────────────────────────────────────────────────────
    if q:
        ql = q.lower()
        items = [i for i in items if ql in i["title"].lower()]
    items.sort(key=lambda x: x["title"].lower())

    total   = len(items)
    n_pages = max(1, (total + per_page - 1) // per_page)
    page    = max(1, min(page, n_pages))
    page_items = items[(page-1)*per_page : page*per_page]

    base = f"/series?q={q}"
    pg   = _pg_html(total, page, n_pages, per_page, base, [10, 20, 50])

    def _series_card(entry):
        title        = entry["title"]
        year         = entry.get("year") or ""
        poster       = entry.get("poster_url") or ""
        sc           = entry.get("season_count") or 0
        lib_status   = entry.get("status", "")
        unregistered = entry["_unregistered"]
        fuse         = entry["_fuse"]
        safe         = title.replace('"', '&quot;')
        t_js         = title.replace("'", "\\'")
        yr_js        = str(year) if year else "null"

        # Episode truth: symlinks (cached) vs placeholders (pending)
        cached_seasons: dict[int, set] = fuse.get("cached", {})
        ph_seasons:     dict[int, set] = fuse.get("placeholder", {})
        all_seasons = set(cached_seasons) | set(ph_seasons)

        if poster:
            img = (f'<img src="{poster}" style="width:64px;height:96px;object-fit:cover;'
                   f'border-radius:6px;flex-shrink:0;display:block" loading="lazy" '
                   f'onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'flex\'">'
                   f'<div style="width:64px;height:96px;background:#0f0f13;border-radius:6px;'
                   f'flex-shrink:0;display:none;align-items:center;justify-content:center;'
                   f'font-size:1.8rem">📺</div>')
        else:
            img = (f'<div style="width:64px;height:96px;background:#0f0f13;border-radius:6px;'
                   f'flex-shrink:0;display:flex;align-items:center;justify-content:center;'
                   f'font-size:1.8rem">📺</div>')

        status_color = "#ef4444" if lib_status == "ended" else "#22c55e"
        status_lbl   = "Ended" if lib_status == "ended" else ("Continuing" if not unregistered else "On disk / unregistered")
        status_col   = status_color if not unregistered else "#c084fc"
        year_str     = f" ({year})" if year else ""

        total_cached = sum(len(v) for v in cached_seasons.values())
        total_eps    = total_cached + sum(
            len(ph_seasons.get(sn, set()) - cached_seasons.get(sn, set()))
            for sn in all_seasons
        )

        season_rows = ""
        for sn in sorted(all_seasons):
            s_cached = cached_seasons.get(sn, set())
            s_ph     = ph_seasons.get(sn, set()) - s_cached  # placeholders without symlink
            all_eps  = sorted(s_cached | s_ph)
            n_c      = len(s_cached)
            n_total  = len(all_eps)
            pct      = int(n_c / n_total * 100) if n_total else 0
            bar_col  = "#4ade80" if pct == 100 else ("#f97316" if pct > 0 else "#2a2a2a")
            chips    = "".join(
                f'<span style="display:inline-flex;align-items:center;justify-content:center;'
                f'min-width:34px;height:20px;padding:0 4px;border-radius:4px;font-size:0.62rem;'
                f'font-weight:700;background:{"#14532d" if ep in s_cached else "#2a2a2a"};'
                f'color:{"#4ade80" if ep in s_cached else "#444"};margin:2px">E{ep:02d}</span>'
                for ep in all_eps
            )
            pack_btn = (
                f'<button class="btn btn-sec" style="padding:2px 8px;font-size:0.68rem;margin-left:6px" '
                f'onclick="cacheSeason(\'{t_js}\', {yr_js}, {sn})">🔎 Pack</button>'
            )
            season_rows += (
                f'<div style="margin-bottom:10px">'
                f'<div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;flex-wrap:wrap">'
                f'<span style="font-size:0.75rem;font-weight:700;color:#aaa;min-width:62px">Season {sn}</span>'
                f'<div style="flex:1;max-width:100px;height:4px;background:#1a1a1a;border-radius:2px;overflow:hidden">'
                f'<div style="width:{pct}%;height:100%;background:{bar_col};border-radius:2px"></div></div>'
                f'<span style="font-size:0.7rem;color:#555">{n_c}/{n_total}</span>'
                f'{pack_btn}'
                f'</div>'
                f'<div style="line-height:1.8">{chips}</div>'
                f'</div>'
            )

        if not season_rows and not unregistered:
            season_rows = '<span style="color:#333;font-size:0.8rem">No episodes found on FUSE mount</span>'
        elif not season_rows and unregistered:
            season_rows = '<span style="color:#555;font-size:0.8rem">Register this series to start caching</span>'

        action_buttons = ""
        if unregistered:
            action_buttons = (f'<button class="btn btn-add" style="padding:4px 10px;font-size:0.72rem;flex-shrink:0" '
                              f'onclick="registerSeries(\'{t_js}\', {yr_js})">+ Register</button>')
        else:
            action_buttons = (f'<button class="btn btn-rem" style="padding:4px 10px;font-size:0.72rem;flex-shrink:0" '
                              f'data-mtype="series" data-title="{safe}" data-year="{year}" '
                              f'onclick="remCard(this)">Remove</button>')

        return (
            f'<div style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:10px;'
            f'padding:18px;margin-bottom:14px">'
            f'<div style="display:flex;gap:14px;align-items:flex-start">'
            f'<div style="flex-shrink:0">{img}</div>'
            f'<div style="flex:1;min-width:0">'
            f'<div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-bottom:10px">'
            f'<div>'
            f'<div style="font-size:0.95rem;font-weight:700;color:#e0e0e0">{title}{year_str}</div>'
            f'<div style="font-size:0.72rem;color:{status_col};margin-top:2px">{status_lbl}'
            f'{"  ·  "+str(sc)+" seasons" if sc else ""}'
            f'  ·  <span style="color:#4ade80">{total_cached}/{total_eps} eps cached</span></div>'
            f'</div>'
            f'{action_buttons}'
            f'</div>'
            f'{season_rows}'
            f'</div></div></div>'
        )

    cards_html = "".join(_series_card(i) for i in page_items)
    if not cards_html:
        cards_html = '<div class="empty">No series match.</div>'

    fuse_only  = sum(1 for i in items if i["_unregistered"])
    total_lib  = len(series_lib)
    total_cached_shows = sum(
        1 for i in items
        if not i["_unregistered"] and any(i["_fuse"].get("cached", {}).values())
    )

    body = f"""
    <h2>📺 TV Series <span style="color:#555;font-size:0.9rem;font-weight:normal">
      ({total_cached_shows} with cached episodes of {total_lib}
      {f'· {fuse_only} on disk / unregistered' if fuse_only else ''})
    </span></h2>
    <div class="search-bar" style="margin-bottom:16px">
      <input id="sq" type="text" placeholder="Search series..." value="{q}"
             onkeydown="if(event.key==='Enter')location.href='/series?q='+encodeURIComponent(this.value)">
      <button class="btn btn-sec" onclick="location.href='/series?q='+encodeURIComponent(document.getElementById('sq').value)">Search</button>
      {'<button class="btn btn-sec" onclick="location.href=\'/series\'">Clear</button>' if q else ''}
    </div>
    {pg}
    {cards_html}
    {pg}"""

    extra = """<script>
async function registerSeries(title, year) {
  const r = await fetch('/api/import/plex', {method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({title, year, media_type:'series'})});
  const d = await r.json();
  toast(r.ok ? '✅ ' + d.message : '❌ '+(d.detail||'Error'), r.ok);
  if (r.ok) setTimeout(()=>location.reload(), 1500);
}
async function cacheSeason(title, year, season) {
  const r = await fetch('/api/cache/season', {method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({title, year, season})});
  const d = await r.json();
  toast(r.ok ? '⚙️ Season pack queued' : '❌ ' + (d.detail||'Error'), r.ok);
}
async function remCard(btn) {
  const title = btn.dataset.title.replace(/&quot;/g,'"');
  const year  = btn.dataset.year ? parseInt(btn.dataset.year) : null;
  if (!confirm('Remove "'+title+'" from library?\\n\\nThis deletes all cached streams, symlinks, and removes from AllDebrid.')) return;
  const r = await fetch('/api/library/remove', {method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({media_type:'series', title, year})});
  if (r.ok) { toast('🗑️ Removed'); setTimeout(()=>location.reload(),1200); }
  else { toast('❌ Error', false); }
}
</script>"""
    return _page("Series", "series", body, extra)


# ── /missing — Missing episodes + Overseerr import ────────────────────────────
@app.get("/missing", response_class=HTMLResponse)
async def missing_page(request: Request, tab: str = "missing",
                       page: int = 1, per_page: int = 20,
                       mp: int = 1, mpp: int = 24,   # import: movie page / per-page
                       sp: int = 1, spp: int = 24):  # import: series page / per-page
    if _needs_setup(request): return _setup_redirect()
    db: CacheDB        = request.app.state.db
    s                  = request.app.state.settings
    lm: LibraryManager = request.app.state.library

    def _tab(t, label):
        active = "active" if tab == t else ""
        return f'<div class="tab {active}" onclick="location.href=\'/missing?tab={t}\'">{label}</div>'

    tabs_html = (
        _tab("missing", "❌ Missing") +
        _tab("import",  "📂 Import from Plex / Overseerr")
    )

    if tab == "import":
        body_content = await _overseerr_import_html(db, lm, mp, mpp, sp, spp)
    else:
        body_content = _missing_episodes_html(db, s, page, per_page)

    body = f"""
    <h2>Missing &amp; Import</h2>
    <div class="tabs">{tabs_html}</div>
    {body_content}"""

    extra = """<script>
async function cacheMovie(title, year) {
  const r = await fetch('/api/cache/movie', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({title, year})
  });
  const d = await r.json();
  toast(r.ok ? '⚙️ Movie cache queued' : '❌ ' + (d.detail || 'Error'), r.ok);
}
async function cacheSeason(title, year, season) {
  const r = await fetch('/api/cache/season', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({title, year, season})
  });
  const d = await r.json();
  toast(r.ok ? '⚙️ Season pack search queued' : '❌ ' + (d.detail || 'Error'), r.ok);
}
async function importItem(btn) {
  btn.disabled = true;
  btn.textContent = 'Adding…';
  const r = await fetch('/api/import/plex', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      title:      btn.dataset.title,
      year:       btn.dataset.year ? parseInt(btn.dataset.year) : null,
      media_type: btn.dataset.mtype,
      arr_id:     btn.dataset.id ? parseInt(btn.dataset.id) : null,
      season_count: btn.dataset.sc ? parseInt(btn.dataset.sc) : 0
    })
  });
  const d = await r.json();
  if (r.ok) {
    toast('✅ ' + d.message);
    btn.textContent = '✓ Added';
    btn.classList.remove('btn-add');
    btn.classList.add('btn-rem');
  } else {
    toast('❌ ' + (d.detail || d.message || 'Error'), false);
    btn.disabled = false;
    btn.textContent = '+ Add';
  }
}
async function importAll() {
  const btns = [...document.querySelectorAll('.import-btn:not([disabled])')];
  if (!btns.length) { toast('Nothing left to import'); return; }
  if (!confirm('Add all ' + btns.length + ' items to the Debridarr library?')) return;
  for (const btn of btns) await importItem(btn);
  toast('✅ All items imported — caching in background');
}
</script>"""
    return _page("Missing & Import", "missing", body, extra)


async def _fetch_tautulli_library(db: CacheDB) -> list[dict]:
    """
    Query Tautulli for all media across all Plex libraries.
    Returns list of {title, year, mtype} dicts.
    Falls back gracefully to [] if not configured or unavailable.
    """
    url = db.get_setting("tautulli_url", "").rstrip("/")
    key = db.get_setting("tautulli_api_key", "")
    if not url or not key:
        return []

    import httpx as _hx
    results: list[dict] = []

    try:
        async with _hx.AsyncClient(timeout=15) as client:
            # Step 1: get all library sections
            r = await client.get(f"{url}/api/v2",
                                 params={"apikey": key, "cmd": "get_libraries"})
            if r.status_code != 200:
                log.warning(f"Tautulli get_libraries HTTP {r.status_code}")
                return []
            libs = r.json().get("response", {}).get("data", [])

            for lib in libs:
                section_id   = lib.get("section_id")
                section_type = lib.get("section_type", "")   # "movie" | "show"
                if section_type not in ("movie", "show"):
                    continue
                mtype = "movie" if section_type == "movie" else "series"

                # Step 2: get all media in this section (up to 100 k items)
                r2 = await client.get(
                    f"{url}/api/v2",
                    params={"apikey": key, "cmd": "get_library_media_info",
                            "section_id": section_id, "length": 100_000},
                )
                if r2.status_code != 200:
                    continue
                data = r2.json().get("response", {}).get("data", {})
                # API returns {"data": [...], "recordsTotal": N}
                items = data.get("data", []) if isinstance(data, dict) else data
                for item in items:
                    title = item.get("title", "").strip()
                    year  = item.get("year")
                    if title:
                        results.append({
                            "title": title,
                            "year":  int(year) if year else None,
                            "mtype": mtype,
                        })

    except Exception as e:
        log.warning(f"Tautulli library fetch failed: {e}")

    log.info(f"📺 Tautulli: {len(results)} items across all libraries")
    return results


async def _overseerr_import_html(db: CacheDB, lm: LibraryManager,
                                  mp: int = 1, mpp: int = 24,
                                  sp: int = 1, spp: int = 24) -> str:
    """
    Import tab — three sources merged, split into Movies and TV sections,
    each independently paginated (mp/mpp for movies, sp/spp for series).
    """
    added_movies = {r["title"].lower() for r in db.fake_library_list() if r["media_type"] == "movie"}
    added_series = {r["title"].lower() for r in db.fake_library_list() if r["media_type"] == "series"}

    # ── Source 1: Tautulli ─────────────────────────────────────────────────────
    tautulli_items = await _fetch_tautulli_library(db)
    tautulli_found = [
        {**i, "source": "tautulli", "poster": "", "id": None, "sc": 0}
        for i in tautulli_items
        if (i["mtype"] == "movie"  and i["title"].lower() not in added_movies)
        or (i["mtype"] == "series" and i["title"].lower() not in added_series)
    ]

    # ── Source 2: Overseerr ────────────────────────────────────────────────────
    overseerr_found: list[dict] = []
    if lm.url:
        try:
            all_movies = await lm.get_radarr_movies()
            overseerr_found += [
                {"title": m["title"], "year": m.get("year"), "mtype": "movie",
                 "poster": m.get("poster", ""), "id": m.get("id"), "sc": 0, "source": "overseerr"}
                for m in all_movies if m["title"].lower() not in added_movies
            ]
        except Exception as e:
            log.debug(f"Import tab movies: {e}")
        try:
            all_series = await lm.get_sonarr_series()
            overseerr_found += [
                {"title": s["title"], "year": s.get("year"), "mtype": "series",
                 "poster": s.get("poster", ""), "id": s.get("id"),
                 "sc": s.get("season_count", 0), "source": "overseerr"}
                for s in all_series if s["title"].lower() not in added_series
            ]
        except Exception as e:
            log.debug(f"Import tab series: {e}")

    # ── Source 3: plex-strm folders ────────────────────────────────────────────
    plex_root  = getattr(lm, "plex_root", "") or ""
    plex_found: list[dict] = []
    if plex_root:
        for mtype, subdir, added_set in [
            ("movie",  "movies", added_movies),
            ("series", "tv",     added_series),
        ]:
            folder = Path(plex_root) / subdir
            if not folder.exists():
                continue
            for d in sorted(folder.iterdir()):
                if not d.is_dir():
                    continue
                m = re.match(r"^(.+?)\s*\((\d{4})\)\s*$", d.name)
                title = m.group(1).strip() if m else d.name.strip()
                year  = int(m.group(2)) if m else None
                if title.lower() in added_set:
                    continue
                plex_found.append({
                    "title": title, "year": year, "mtype": mtype,
                    "poster": "", "id": None, "sc": 0, "source": "plex-strm",
                })

    # ── Merge, Overseerr first (has posters/ids) ───────────────────────────────
    seen: set[tuple] = set()
    all_found: list[dict] = []
    for item in overseerr_found + tautulli_found + plex_found:
        key = (item["title"].lower(), item["mtype"])
        if key not in seen:
            seen.add(key)
            all_found.append(item)

    all_movies_found = sorted([i for i in all_found if i["mtype"] == "movie"],  key=lambda x: x["title"])
    all_series_found = sorted([i for i in all_found if i["mtype"] == "series"], key=lambda x: x["title"])
    total = len(all_movies_found) + len(all_series_found)

    if total == 0:
        hint = ""
        if not db.get_setting("tautulli_url"):
            hint = ('<br><br><span style="color:#555;font-size:0.82rem">💡 Configure '
                    '<a href="/settings" style="color:#f97316">Tautulli in Settings</a> '
                    'to scan all Plex libraries automatically.</span>')
        return f'<div class="empty">✅ Everything is already in Debridarr.{hint}</div>'

    # ── Source badge ───────────────────────────────────────────────────────────
    def _badge(source):
        styles = {
            "overseerr": ("background:#2d1a00;color:#fb923c", "Overseerr"),
            "tautulli":  ("background:#1a2d1a;color:#4ade80", "Tautulli"),
            "plex-strm": ("background:#1e3a5f;color:#60a5fa", "Plex"),
        }
        bg, lbl = styles.get(source, ("background:#2a2a2a;color:#888", source))
        return f'<span style="font-size:0.6rem;{bg};padding:1px 5px;border-radius:3px;margin-left:3px">{lbl}</span>'

    # ── Card builder — same poster-fallback pattern as missing tab ─────────────
    def _card(item):
        title  = item["title"]
        year   = item.get("year")
        poster = item.get("poster") or ""
        mtype  = item["mtype"]
        sc     = item.get("sc", 0)
        iid    = item.get("id") or ""
        source = item.get("source", "")
        safe   = title.replace('"', '&quot;')
        icon   = "🎬" if mtype == "movie" else "📺"
        meta   = str(year or "")
        if mtype == "series" and sc:
            meta += f" · {sc}s"

        if poster:
            img = (
                f'<img src="{poster}" style="width:100%;aspect-ratio:2/3;object-fit:cover;display:block" '
                f'loading="lazy" onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'flex\'">'
                f'<div style="width:100%;aspect-ratio:2/3;background:#1a1a2e;display:none;'
                f'align-items:center;justify-content:center;font-size:2rem;color:#333">{icon}</div>'
            )
        else:
            img = (
                f'<div style="width:100%;aspect-ratio:2/3;background:#1a1a2e;display:flex;'
                f'align-items:center;justify-content:center;font-size:2rem;color:#333">{icon}</div>'
            )

        return (
            f'<div class="card">{img}'
            f'<div class="info">'
            f'<div class="title" title="{safe}">{title}</div>'
            f'<div class="meta">{meta}{_badge(source)}</div>'
            f'</div>'
            f'<div class="actions">'
            f'<button class="btn btn-add btn-sm import-btn"'
            f' data-title="{safe}" data-year="{year or ""}"'
            f' data-mtype="{mtype}" data-id="{iid}" data-sc="{sc}"'
            f' onclick="importItem(this)">+ Add</button>'
            f'</div></div>'
        )

    # ── Pagination helper ──────────────────────────────────────────────────────
    def _pg(items, cur_page, per_pg, page_param, pp_param):
        """Returns (page_items, pagination_html)."""
        n_total = len(items)
        n_pages = max(1, (n_total + per_pg - 1) // per_pg)
        cur_page = max(1, min(cur_page, n_pages))
        page_items = items[(cur_page - 1) * per_pg : cur_page * per_pg]

        if n_pages <= 1 and per_pg >= n_total:
            return page_items, ""

        def href(p, new_pp=None):
            return (f"/missing?tab=import"
                    f"&mp={mp if page_param != 'mp' else p}"
                    f"&mpp={new_pp if (page_param == 'mp' and new_pp) else mpp}"
                    f"&sp={sp if page_param != 'sp' else p}"
                    f"&spp={new_pp if (page_param == 'sp' and new_pp) else spp}")

        def page_link(p, label=None):
            h = href(p)
            if p == cur_page:
                return f'<span class="cur">{label or p}</span>'
            return f'<a href="{h}">{label or p}</a>'

        parts = []
        if cur_page > 1:
            parts.append(f'<a href="{href(cur_page - 1)}">← Prev</a>')

        # Page numbers with ellipsis
        if n_pages <= 7:
            for p in range(1, n_pages + 1):
                parts.append(page_link(p))
        else:
            parts.append(page_link(1))
            if cur_page > 3:
                parts.append('<span class="dots">…</span>')
            for p in range(max(2, cur_page - 1), min(n_pages, cur_page + 2)):
                parts.append(page_link(p))
            if cur_page < n_pages - 2:
                parts.append('<span class="dots">…</span>')
            parts.append(page_link(n_pages))

        if cur_page < n_pages:
            parts.append(f'<a href="{href(cur_page + 1)}">Next →</a>')

        parts.append(f'<span style="color:#555;font-size:0.75rem">{n_total} total</span>')

        # Per-page selector
        opts = "".join(
            f'<option value="{href(1, n)}" {"selected" if n == per_pg else ""}>{n} / page</option>'
            for n in [12, 24, 48, 96]
        )
        parts.append(
            f'<select onchange="location.href=this.value" '
            f'style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:6px;'
            f'padding:5px 10px;color:#aaa;font-size:0.78rem;cursor:pointer">{opts}</select>'
        )

        return page_items, '<div class="pg" style="margin:12px 0 6px">' + " ".join(parts) + "</div>"

    # ── Source counts for header ───────────────────────────────────────────────
    src_counts: dict[str, int] = {}
    for i in all_found:
        src_counts[i["source"]] = src_counts.get(i["source"], 0) + 1
    src_parts = []
    if src_counts.get("tautulli"):  src_parts.append(f'{src_counts["tautulli"]} Tautulli')
    if src_counts.get("overseerr"): src_parts.append(f'{src_counts["overseerr"]} Overseerr')
    if src_counts.get("plex-strm"): src_parts.append(f'{src_counts["plex-strm"]} Plex folder')
    note = " · ".join(src_parts)

    has_tautulli = bool(db.get_setting("tautulli_url"))
    tautulli_hint = "" if has_tautulli else (
        '<div style="background:#1a2a1a;border:1px solid #2a3a2a;border-radius:8px;'
        'padding:10px 14px;margin-bottom:14px;font-size:0.82rem;color:#555">'
        '💡 Configure <a href="/settings" style="color:#f97316">Tautulli in Settings</a> '
        'to scan all your Plex libraries.</div>'
    )

    html = f"""
    {tautulli_hint}
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;flex-wrap:wrap;gap:10px">
      <p style="color:#555;font-size:0.85rem;margin:0">
        <strong style="color:#e0e0e0">{total}</strong> items not in Debridarr
        <span style="color:#444"> ({note})</span>
      </p>
      <button class="btn btn-add" onclick="importAll()" style="padding:7px 18px">⬇️ Import All ({total})</button>
    </div>"""

    # ── Movies section ─────────────────────────────────────────────────────────
    if all_movies_found:
        movie_page_items, movie_pg = _pg(all_movies_found, mp, mpp, "mp", "mpp")
        movie_cards = "".join(_card(i) for i in movie_page_items)
        html += f'<h2 style="margin:0 0 10px">🎬 Movies ({len(all_movies_found)})</h2>'
        html += movie_pg
        html += f'<div class="card-grid" style="margin-bottom:8px">{movie_cards}</div>'
        html += movie_pg  # pagination below grid too

    # ── Series section ─────────────────────────────────────────────────────────
    if all_series_found:
        series_page_items, series_pg = _pg(all_series_found, sp, spp, "sp", "spp")
        series_cards = "".join(_card(i) for i in series_page_items)
        html += f'<h2 style="margin:28px 0 10px">📺 TV Shows ({len(all_series_found)})</h2>'
        html += series_pg
        html += f'<div class="card-grid">{series_cards}</div>'
        html += series_pg

    return html


def _missing_episodes_html(db: CacheDB, s, page: int = 1, per_page: int = 20) -> str:
    """
    Missing tab — two sections:
    1. Movies in library with no cached stream
    2. Series with uncached placeholder episodes (paginated)
    Posters use an inline fallback div that shows when the image fails to load.
    """
    plex_root = getattr(s, "PLEX_ROOT", "")

    # ── Poster helper — always renders a fallback div alongside the img ────────
    def _poster(url: str, icon: str, w: int = 52, h: int = 78) -> str:
        """
        Renders an img + a sibling fallback div.
        If url is empty or the img fails to load, the fallback div is shown.
        """
        base = (f'style="width:{w}px;height:{h}px;background:#1a1a2e;border-radius:6px;'
                f'align-items:center;justify-content:center;font-size:1.4rem;flex-shrink:0"')
        if url:
            return (
                f'<img src="{url}" '
                f'style="width:{w}px;height:{h}px;object-fit:cover;border-radius:6px;'
                f'flex-shrink:0;display:block" loading="lazy" '
                f'onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'flex\'">'
                f'<div {base} style="display:none;width:{w}px;height:{h}px;background:#1a1a2e;'
                f'border-radius:6px;align-items:center;justify-content:center;font-size:1.4rem;'
                f'flex-shrink:0">{icon}</div>'
            )
        return f'<div {base} style="display:flex;">{icon}</div>'

    html_parts = []

    # ── Quick Pack Import panel ────────────────────────────────────────────────
    html_parts.append("""
    <div style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:10px;padding:18px;margin-bottom:24px">
      <div style="font-size:0.78rem;font-weight:700;color:#f97316;text-transform:uppercase;letter-spacing:.06em;margin-bottom:12px">
        ⚡ Quick Pack Search
      </div>
      <p style="font-size:0.82rem;color:#555;margin-bottom:14px">
        Search and cache a full season pack or series pack immediately — no episode-by-episode wait.
      </p>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <input id="qp-title" type="text" placeholder="Show or movie title…"
               style="flex:2;min-width:180px;background:#0f0f13;border:1px solid #2a2a3a;border-radius:8px;padding:9px 14px;color:#e0e0e0;font-size:0.9rem;outline:none"
               onkeydown="if(event.key==='Enter')quickPackSearch()">
        <select id="qp-type" style="background:#0f0f13;border:1px solid #2a2a3a;border-radius:8px;padding:9px 14px;color:#e0e0e0;font-size:0.85rem;outline:none">
          <option value="season_pack">Season Pack</option>
          <option value="series_pack">Series Pack (all seasons)</option>
          <option value="movie">Movie</option>
        </select>
        <input id="qp-season" type="number" min="1" max="99" placeholder="Season #"
               style="width:100px;background:#0f0f13;border:1px solid #2a2a3a;border-radius:8px;padding:9px 14px;color:#e0e0e0;font-size:0.9rem;outline:none">
        <input id="qp-year" type="number" min="1900" max="2030" placeholder="Year"
               style="width:90px;background:#0f0f13;border:1px solid #2a2a3a;border-radius:8px;padding:9px 14px;color:#e0e0e0;font-size:0.9rem;outline:none">
        <button class="btn btn-add" onclick="quickPackSearch()" style="padding:9px 20px">🔎 Search &amp; Cache</button>
      </div>
      <div id="qp-result" style="margin-top:10px;font-size:0.82rem;display:none"></div>
    </div>
    <script>
    // Hide season input when type is movie or series_pack
    document.getElementById('qp-type').addEventListener('change', function() {
      document.getElementById('qp-season').style.display = this.value === 'season_pack' ? '' : 'none';
    });
    async function quickPackSearch() {
      const title  = document.getElementById('qp-title').value.trim();
      const type   = document.getElementById('qp-type').value;
      const season = document.getElementById('qp-season').value;
      const year   = document.getElementById('qp-year').value;
      const res    = document.getElementById('qp-result');
      if (!title) { toast('❌ Enter a title first', false); return; }
      if (type === 'season_pack' && !season) { toast('❌ Enter a season number', false); return; }
      res.style.display = 'block';
      res.style.color = '#aaa';
      res.textContent = '⏳ Queuing…';
      const body = { title, year: year ? parseInt(year) : null };
      let url;
      if (type === 'movie') {
        url = '/api/cache/movie';
      } else if (type === 'season_pack') {
        body.season = parseInt(season);
        url = '/api/cache/season';
      } else {
        url = '/api/cache/series';
      }
      const r = await fetch(url, { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(body) });
      const d = await r.json();
      if (r.ok) {
        res.style.color = '#4ade80';
        res.textContent = '✅ ' + (d.message || 'Queued — check Workers tab for progress');
      } else {
        res.style.color = '#f87171';
        res.textContent = '❌ ' + (d.detail || d.message || 'Error');
      }
    }
    </script>""")


    movies_list = db.fake_library_list(media_type="movie")
    if movies_list:
        cached_movie_titles = {
            e["title"].lower() for e in db.list_all()
            if e["media_type"] == "movie" and e["status"] == "cached"
        }
        missing_movies = [
            m for m in movies_list
            if m["title"].lower() not in cached_movie_titles
        ]
        missing_movies.sort(key=lambda x: x["title"])

        if missing_movies:
            movie_cards = ""
            for m in missing_movies:
                title  = m["title"]
                year   = m.get("year")
                poster = m.get("poster_url") or ""
                safe   = title.replace('"', '&quot;')
                t_js   = title.replace("'", "\\'")
                yr_js  = str(year) if year else "null"
                movie_cards += (
                    f'<div style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:10px;'
                    f'overflow:hidden;display:flex;flex-direction:column">'
                    f'<div style="position:relative">'
                    f'{_poster(poster, "🎬", 160, 240)}'
                    f'</div>'
                    f'<div style="padding:10px 12px;flex:1">'
                    f'<div style="font-size:0.85rem;font-weight:600;color:#e0e0e0;'
                    f'white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="{safe}">{title}</div>'
                    f'<div style="font-size:0.72rem;color:#555;margin-top:3px">{year or ""}</div>'
                    f'</div>'
                    f'<div style="padding:0 10px 10px">'
                    f'<button class="btn btn-add btn-sm" style="width:100%" '
                    f'onclick="cacheMovie(\'{t_js}\', {yr_js})">🔎 Cache Now</button>'
                    f'</div></div>'
                )

            html_parts.append(
                f'<h2 style="margin:0 0 14px">🎬 Missing Movies ({len(missing_movies)})</h2>'
                f'<div class="card-grid" style="margin-bottom:32px">{movie_cards}</div>'
            )

    # ── Section 2: Missing Series Episodes ────────────────────────────────────
    series_list = db.fake_library_list(media_type="series")

    # Scan plex-strm and compute missing episodes per series
    missing_series_data = []  # list of (entry, missing_by_season, cached_by_season)

    for entry in sorted(series_list, key=lambda x: x["title"]):
        title  = entry["title"]
        year   = entry.get("year")

        cached_by_season:      dict[int, set[int]] = {}
        placeholder_by_season: dict[int, set[int]] = {}

        if plex_root:
            show_folder = Path(plex_root) / "tv" / title
            if show_folder.exists():
                for sf in sorted(show_folder.iterdir()):
                    if not sf.is_dir():
                        continue
                    m = re.match(r"Season\s+(\d+)", sf.name, re.I)
                    if not m:
                        continue
                    sn = int(m.group(1))
                    for f in sorted(sf.iterdir()):
                        em = re.search(r"E(\d{2})", f.name, re.I)
                        if not em:
                            continue
                        ep = int(em.group(1))
                        if f.is_symlink():
                            cached_by_season.setdefault(sn, set()).add(ep)
                        elif f.suffix == ".mp4":
                            placeholder_by_season.setdefault(sn, set()).add(ep)

        # Cross-reference: only truly missing if placeholder exists but NO symlink
        missing_by_season: dict[int, list[int]] = {}
        for sn, ph_eps in placeholder_by_season.items():
            truly = sorted(ph_eps - cached_by_season.get(sn, set()))
            if truly:
                missing_by_season[sn] = truly

        if missing_by_season:
            missing_series_data.append((entry, missing_by_season, cached_by_season))

    if missing_series_data:
        total_series = len(missing_series_data)
        total_pages  = max(1, (total_series + per_page - 1) // per_page)
        page         = max(1, min(page, total_pages))
        page_data    = missing_series_data[(page-1)*per_page : page*per_page]

        series_cards = ""
        for entry, missing_by_season, cached_by_season in page_data:
            title      = entry["title"]
            year       = entry.get("year")
            poster     = entry.get("poster_url") or ""
            total_miss = sum(len(v) for v in missing_by_season.values())
            yr_js      = str(year) if year else "null"
            t_js       = title.replace("'", "\\'")
            year_str   = f" ({year})" if year else ""

            season_rows = ""
            for sn in sorted(missing_by_season.keys()):
                miss_eps   = missing_by_season[sn]
                cached_eps = sorted(cached_by_season.get(sn, set()))
                miss_chips = "".join(
                    f'<span style="display:inline-block;padding:2px 8px;border-radius:4px;'
                    f'font-size:0.72rem;font-weight:600;background:#3b1f00;color:#fb923c;margin:2px">'
                    f'E{ep:02d}</span>'
                    for ep in miss_eps
                )
                cached_chips = "".join(
                    f'<span style="display:inline-block;padding:2px 8px;border-radius:4px;'
                    f'font-size:0.72rem;font-weight:600;background:#14532d;color:#4ade80;margin:2px">'
                    f'E{ep:02d}</span>'
                    for ep in cached_eps
                )
                cached_note = (
                    f'<span style="font-size:0.72rem;color:#4ade80">{len(cached_eps)} cached</span>'
                    if cached_eps else ""
                )
                season_rows += f"""
                <div style="margin-bottom:12px">
                  <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;flex-wrap:wrap">
                    <span style="font-size:0.78rem;font-weight:700;color:#aaa;min-width:70px">Season {sn}</span>
                    <span style="font-size:0.72rem;color:#fb923c">{len(miss_eps)} missing</span>
                    {cached_note}
                    <button class="btn btn-sec" style="padding:3px 10px;font-size:0.72rem"
                            onclick="cacheSeason('{t_js}', {yr_js}, {sn})">🔎 Season pack</button>
                  </div>
                  <div style="line-height:2.2">{miss_chips}{cached_chips}</div>
                </div>"""

            series_cards += (
                f'<div style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:10px;'
                f'padding:18px;margin-bottom:14px">'
                f'<div style="display:flex;gap:14px;align-items:flex-start">'
                f'<div style="flex-shrink:0">{_poster(poster, "📺")}</div>'
                f'<div style="flex:1;min-width:0">'
                f'<div style="font-size:0.95rem;font-weight:700;color:#e0e0e0;margin-bottom:10px">'
                f'{title}{year_str} '
                f'<span style="font-size:0.75rem;color:#fb923c;font-weight:normal">'
                f'{total_miss} missing</span></div>'
                f'{season_rows}</div></div></div>'
            )

        # Pagination
        def pg_link(p, label):
            href = f"/missing?tab=missing&page={p}&per_page={per_page}"
            cls  = ' style="background:#f97316;color:#fff;border-color:#f97316"' if p == page else ""
            return f'<a href="{href}"{cls}>{label}</a>'

        pg_html = ""
        if total_pages > 1:
            pg_html = '<div class="pagination" style="margin:16px 0 8px">'
            if page > 1: pg_html += pg_link(page-1, "← Prev")
            for p2 in range(max(1, page-2), min(total_pages+1, page+3)):
                pg_html += pg_link(p2, str(p2))
            if page < total_pages: pg_html += pg_link(page+1, "Next →")
            pg_html += (
                f'<span style="color:#555;font-size:0.75rem">{total_series} series</span>'
                f'<select onchange="location.href=\'/missing?tab=missing&page=1&per_page=\'+this.value" '
                f'style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:6px;'
                f'padding:4px 8px;color:#aaa;font-size:0.78rem">'
            )
            for n in [10, 20, 50]:
                pg_html += f'<option value="{n}" {"selected" if n==per_page else ""}>{n}/page</option>'
            pg_html += '</select></div>'

        html_parts.append(
            f'<h2 style="margin:0 0 14px">📺 Missing Episodes ({len(missing_series_data)} series)</h2>'
            + pg_html
            + series_cards
            + (pg_html if total_pages > 1 and len(page_data) > 3 else "")
        )

    if not html_parts:
        return '<div class="empty">🎉 Everything is cached. Nothing missing!</div>'

    return "\n".join(html_parts)


@app.post("/api/import/plex")
async def api_import_plex(request: Request, background_tasks: BackgroundTasks):
    body         = await request.json()
    title        = body.get("title", "").strip()
    year         = body.get("year")
    media_type   = body.get("media_type", "series")
    arr_id       = body.get("arr_id")          # Overseerr/Radarr/Sonarr id from card
    season_count = body.get("season_count", 0)
    if not title:
        raise HTTPException(400, "title is required")

    db: CacheDB        = request.app.state.db
    lm: LibraryManager = request.app.state.library
    tmdb_key           = db.get_setting("tmdb_api_key", "")

    if db.fake_library_get(media_type, title, year):
        return {"status": "already_added", "message": f"'{title}' is already in the library"}

    # Enrich with Overseerr metadata (poster, ids, etc.)
    meta = None
    try:
        if media_type == "movie":
            items = await lm.get_radarr_movies()
        else:
            items = await lm.get_sonarr_series()
        meta = next(
            (i for i in items if i.get("id") == arr_id or i["title"].lower() == title.lower()),
            None
        )
    except Exception as e:
        log.debug(f"Overseerr lookup for '{title}': {e}")

    poster_url = (meta.get("poster", "") if meta else "")
    tmdb_id    = meta.get("tmdb_id") if meta else None
    if not poster_url and tmdb_key and tmdb_id:
        poster_url = await _fetch_tmdb_poster(tmdb_id, title, media_type == "movie", tmdb_key)

    is_ended = meta.get("is_ended", False) if meta else False

    db.fake_library_add({
        "media_type":   media_type,
        "title":        title,
        "year":         year or (meta.get("year") if meta else None),
        "sonarr_id":    arr_id if media_type == "series" else None,
        "radarr_id":    arr_id if media_type == "movie"  else None,
        "tvdb_id":      meta.get("tvdb_id")      if meta else None,
        "tmdb_id":      tmdb_id,
        "imdb_id":      meta.get("imdb_id")      if meta else None,
        "season_count": (meta.get("season_count") if meta else None) or season_count,
        "poster_url":   poster_url,
        "overview":     meta.get("overview", "") if meta else "",
        "status":       "movie" if media_type == "movie" else ("ended" if is_ended else "continuing"),
        "fake_path":    None,
    })

    if media_type == "movie":
        imdb_id = meta.get("imdb_id") if meta else None
        # Write placeholder file
        lm.create_fake_movie(title, year)
        background_tasks.add_task(_precache_movie, request.app, title, year, tmdb_id, imdb_id)
        return {"status": "ok", "message": f"Added '{title}' — caching in background"}
    else:
        req_seasons = meta.get("requested_seasons", []) if meta else []
        inc         = db.get_setting("include_unreleased_episodes", "false") == "true"
        episodes    = []
        if arr_id:
            try:
                episodes = await lm.get_episodes(
                    arr_id, include_unreleased=inc,
                    requested_seasons=req_seasons if req_seasons else None
                )
            except Exception as e:
                log.debug(f"Episodes for '{title}': {e}")
        # Write placeholder files
        lm.create_fake_episodes(title, year, [], episodes)
        background_tasks.add_task(_precache_series, request.app, title, year, episodes)
        return {"status": "ok", "message": f"Added '{title}' — {len(episodes)} episodes queued"}


@app.post("/api/cache/movie")
async def api_cache_movie(request: Request, background_tasks: BackgroundTasks):
    body  = await request.json()
    title = body.get("title", "").strip()
    year  = body.get("year")
    if not title:
        raise HTTPException(400, "title required")
    event = PlayEvent(media_type=MediaType.movie, title=title, year=year)
    background_tasks.add_task(resolve_and_cache, request.app, event)
    return {"status": "queued", "title": title, "message": f"Movie '{title}' queued for caching"}


@app.post("/api/cache/series")
async def api_cache_series(request: Request, background_tasks: BackgroundTasks):
    """Queue a full series pack search — tries to get every season in one torrent."""
    body  = await request.json()
    title = body.get("title", "").strip()
    year  = body.get("year")
    if not title:
        raise HTTPException(400, "title required")
    # Use episode 1 season 1 as the trigger — series_pack strategy will find the full show
    event = PlayEvent(media_type=MediaType.episode, title=title, year=year, season=1, episode=1)
    db: CacheDB = request.app.state.db
    # Temporarily override strategy to series_pack for this search
    original = db.get_setting("series_completed_strategy", "series_pack")
    db.set_setting("series_completed_strategy", "series_pack")
    db.set_setting("series_ongoing_strategy",   "series_pack")
    background_tasks.add_task(resolve_and_cache, request.app, event)
    # Restore strategy after a short delay (background task)
    async def _restore():
        await asyncio.sleep(5)
        db.set_setting("series_completed_strategy", original)
        db.set_setting("series_ongoing_strategy",   db.get_setting("series_ongoing_strategy", "season_pack"))
    background_tasks.add_task(_restore)
    return {"status": "queued", "title": title, "message": f"Series pack for '{title}' queued — check Workers tab"}


@app.post("/api/cache/season")
async def api_cache_season(request: Request, background_tasks: BackgroundTasks):
    body   = await request.json()
    title  = body.get("title", "").strip()
    year   = body.get("year")
    season = body.get("season")
    if not title or season is None:
        raise HTTPException(400, "title and season required")
    event = PlayEvent(media_type=MediaType.episode, title=title, year=year, season=int(season), episode=1)
    background_tasks.add_task(resolve_and_cache, request.app, event)
    return {"status": "queued", "title": title, "season": season}


# ── /settings ────────────────────────────────────────────────────────────────
@app.get("/settings", response_class=HTMLResponse)
async def settings_page(request: Request):
    if _needs_setup(request): return _setup_redirect()
    cfg = load_saved_config()
    s   = request.app.state.settings
    db: CacheDB = request.app.state.db
    cfg["TMDB_API_KEY"]      = db.get_setting("tmdb_api_key", "")
    cfg["TAUTULLI_URL"]      = db.get_setting("tautulli_url", "")
    cfg["TAUTULLI_API_KEY"]  = db.get_setting("tautulli_api_key", "")

    def field(label, key, hint="", typ="text", placeholder=""):
        val    = cfg.get(key) or getattr(s, key, "") or ""
        masked = typ == "password"
        is_saved = bool(val) and masked
        ph     = "••••••• (saved — leave blank to keep)" if is_saved else (placeholder or "")
        saved_attr = ' data-saved="true"' if is_saved else ""
        return f"""<div class="field">
          <label>{label}{'<span class="saved-badge">saved</span>' if is_saved else ""}</label>
          <input id="{key}" name="{key}" type="{typ}" value="{'' if masked else val}"
                 placeholder="{ph}" autocomplete="off"{saved_attr}>
          {'<div class="hint">'+hint+'</div>' if hint else ''}
        </div>"""

    all_settings = db.get_all_settings()

    body = f"""
    <div style="max-width:720px">
      <h2 style="margin-bottom:4px">⚙️ Settings</h2>
      <p style="color:#555;font-size:0.85rem;margin-bottom:28px">Changes require saving to take effect.</p>

      <div class="s-sect">
        <div class="s-title">AllDebrid</div>
        {field("API Key","ALLDEBRID_API_KEY",'<a href="https://alldebrid.com/apikeys" target="_blank">alldebrid.com/apikeys</a>',"password")}
        <button class="btn btn-sec" onclick="testConn('alldebrid')">Test</button>
        <div id="test-alldebrid" class="test-result"></div>
      </div>

      <div class="s-sect">
        <div class="s-title">Overseerr</div>
        {field("URL","OVERSEERR_URL","","text","http://192.168.1.x:5055")}
        {field("API Key","OVERSEERR_API_KEY","Overseerr → Settings → General → API Key","password")}
        <button class="btn btn-sec" onclick="testConn('overseerr')">Test</button>
        <div id="test-overseerr" class="test-result"></div>
      </div>

      <div class="s-sect">
        <div class="s-title">TMDB</div>
        {field("API Key","TMDB_API_KEY",'For cover art. <a href="https://www.themoviedb.org/settings/api" target="_blank" style="color:#f97316">Get free key →</a>',"password")}
      </div>

      <div class="s-sect">
        <div class="s-title">Plex</div>
        {field("Debridarr Base URL","DEBRIDARR_BASE_URL","URL Plex uses to reach Debridarr","text","http://192.168.1.x:7474")}
        {field("Plex Library Path","PLEX_ROOT","Path inside container where fake files are written","text","/plex-strm")}
        <button class="btn btn-sec" onclick="testConn('plex')">Test</button>
        <div id="test-plex" class="test-result"></div>
      </div>

      <div class="s-sect">
        <div class="s-title">Tautulli</div>
        <div style="font-size:0.8rem;color:#555;margin-bottom:14px;line-height:1.5">
          Used by the <strong style="color:#aaa">Missing &amp; Import</strong> tab to scan all your Plex libraries and find titles not yet in Debridarr.
        </div>
        {field("Tautulli URL","TAUTULLI_URL","","text","http://192.168.1.x:8181")}
        {field("Tautulli API Key","TAUTULLI_API_KEY","Tautulli → Settings → Web Interface → API Key","password")}
        <button class="btn btn-sec" onclick="testTautulli()">Test Connection</button>
        <div id="test-tautulli" class="test-result"></div>
      </div>

      <div class="s-sect">
        <div class="s-title">Library</div>
        <div style="display:flex;align-items:center;justify-content:space-between;gap:20px;margin-bottom:16px">
          <div>
            <div style="font-size:0.875rem;font-weight:600;margin-bottom:4px">🤖 Auto-Add from Overseerr</div>
            <div style="font-size:0.75rem;color:#555">Automatically add every approved Overseerr request to Debridarr and start caching. Checks every 15 minutes.</div>
          </div>
          <label class="toggle">
            <input type="checkbox" id="auto_add"
                   onchange="saveSetting('auto_add',this.checked)">
            <span class="slider"></span>
          </label>
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;gap:20px">
          <div>
            <div style="font-size:0.875rem;font-weight:600;margin-bottom:4px">Include unreleased episodes</div>
            <div style="font-size:0.75rem;color:#555">Create placeholders for episodes not yet aired</div>
          </div>
          <label class="toggle">
            <input type="checkbox" id="include_unreleased_episodes"
                   onchange="saveSetting('include_unreleased_episodes',this.checked)">
            <span class="slider"></span>
          </label>
        </div>
      </div>

      <div class="s-sect">
        <div class="s-title">🔍 Torrent Search</div>

        <div style="margin-bottom:18px">
          <div style="font-size:0.78rem;font-weight:700;color:#aaa;text-transform:uppercase;letter-spacing:.05em;margin-bottom:10px">Content Filters</div>
          <div style="display:flex;align-items:center;justify-content:space-between;gap:20px;padding:10px 0;border-bottom:1px solid #1e1e2e">
            <div>
              <div style="font-size:0.875rem;font-weight:600;margin-bottom:2px">🇬🇧 English releases only</div>
              <div style="font-size:0.75rem;color:#555">Skip torrents with French, German, Spanish and other language tags</div>
            </div>
            <label class="toggle">
              <input type="checkbox" id="english_only" onchange="saveSetting('english_only',this.checked)">
              <span class="slider"></span>
            </label>
          </div>
          <div style="display:flex;align-items:center;justify-content:space-between;gap:20px;padding:10px 0">
            <div>
              <div style="font-size:0.875rem;font-weight:600;margin-bottom:2px">🚫 Block CAM / Telesync releases</div>
              <div style="font-size:0.75rem;color:#555">Skip CAM, TS, HDCAM, Telesync, Screener sources — keeps quality high</div>
            </div>
            <label class="toggle">
              <input type="checkbox" id="no_cam" onchange="saveSetting('no_cam',this.checked)">
              <span class="slider"></span>
            </label>
          </div>
        </div>

        <div style="font-size:0.78rem;font-weight:700;color:#aaa;text-transform:uppercase;letter-spacing:.05em;margin-bottom:10px">Strategy</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px">
          <div class="field">
            <label>Completed / Ended Shows</label>
            <select id="series_completed_strategy">
              <option value="series_pack">Series Pack (all seasons)</option>
              <option value="season_pack">Season Pack</option>
              <option value="episode">Per Episode</option>
            </select>
            <div class="hint">Best for binge-watching ended shows</div>
          </div>
          <div class="field">
            <label>Ongoing / Airing Shows</label>
            <select id="series_ongoing_strategy">
              <option value="season_pack">Season Pack (recommended)</option>
              <option value="episode">Per Episode</option>
              <option value="series_pack">Series Pack</option>
            </select>
            <div class="hint">Season pack covers the whole current season at once</div>
          </div>
          <div class="field"><label>Series Quality</label>
            <select id="series_preferred_quality">
              <option value="1080p">1080p</option><option value="720p">720p</option><option value="any">Any</option>
            </select></div>
          <div class="field"><label>Series Fallback Quality</label>
            <select id="series_fallback_any_quality">
              <option value="true">Yes — any quality</option><option value="false">No — preferred only</option>
            </select></div>
          <div class="field"><label>Movie Quality</label>
            <select id="movie_preferred_quality">
              <option value="1080p">1080p</option><option value="720p">720p</option><option value="any">Any</option>
            </select></div>
          <div class="field"><label>Movie Fallback Quality</label>
            <select id="movie_fallback_any_quality">
              <option value="true">Yes — any quality</option><option value="false">No — preferred only</option>
            </select></div>
          <div class="field"><label>Pre-cache Cooldown (min)</label>
            <input id="precache_cooldown_minutes" type="number" min="0" max="60" value="1"></div>
          <div class="field"><label>Cache TTL (days)</label>
            <input id="cache_ttl_days" type="number" min="1" max="90" value="30"></div>
        </div>
        <button class="btn btn-sec" onclick="saveSearch()" style="padding:8px 20px">💾 Save Search Settings</button>
        <div id="search-result" class="test-result" style="margin-top:10px"></div>
      </div>

      <div class="s-sect">
        <div class="s-title">🗂️ DFS Cache</div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:14px">
          <div class="field"><label>Cache Directory</label>
            <input id="dfs_cache_dir" type="text" value="/docker/debridarr/tmp/cache"></div>
          <div class="field"><label>Max Size (GB)</label>
            <input id="dfs_disk_cache_size_gb" type="number" value="30" min="1" max="1000"></div>
          <div class="field"><label>Expiry (hours)</label>
            <input id="dfs_cache_expiry_h" type="number" value="24" min="1" max="168"></div>
          <div class="field"><label>Chunk Size (MB)</label>
            <input id="dfs_chunk_size_mb" type="number" value="8" min="1" max="64"></div>
          <div class="field"><label>Read Ahead (MB)</label>
            <input id="dfs_read_ahead_mb" type="number" value="500" min="0" max="2000"></div>
          <div class="field"><label>Cleanup (min)</label>
            <input id="dfs_cleanup_interval_m" type="number" value="20" min="1" max="1440"></div>
        </div>
        <button class="btn btn-sec" onclick="saveDFS()" style="padding:8px 20px">💾 Save DFS</button>
        <div id="dfs-result" class="test-result" style="margin-top:10px"></div>
      </div>

      <div class="s-sect">
        <div class="s-title">System</div>
        {field("Timezone","TZ","","text","America/Edmonton")}
        <div style="display:flex;gap:12px">
          <div style="flex:1">{field("PUID","PUID","","text","1000")}</div>
          <div style="flex:1">{field("PGID","PGID","","text","1000")}</div>
        </div>
      </div>

      <div style="display:flex;gap:12px;margin-top:8px">
        <button class="btn btn-add" onclick="saveAll()" style="padding:10px 28px;font-size:0.9rem">💾 Save All Settings</button>
        <button class="btn btn-sec" onclick="testAll()" style="padding:10px 20px;font-size:0.9rem">🔌 Test All</button>
      </div>
      <div id="save-result" class="test-result" style="margin-top:14px"></div>
    </div>"""

    extra = f"""<style>
.s-sect {{ background:#1a1a24;border:1px solid #2a2a3a;border-radius:10px;padding:20px 24px;margin-bottom:16px; }}
.s-title {{ font-size:0.75rem;font-weight:700;text-transform:uppercase;color:#f97316;letter-spacing:.08em;margin-bottom:16px; }}
.field {{ margin-bottom:14px; }}
.field label {{ display:block;font-size:0.8rem;color:#888;margin-bottom:5px;font-weight:600; }}
.field input,.field select {{ width:100%;background:#0f0f13;border:1px solid #2a2a3a;border-radius:7px;
  padding:9px 13px;color:#e0e0e0;font-size:0.875rem;outline:none;font-family:monospace; }}
.field input:focus,.field select:focus {{ border-color:#f97316; }}
.field select {{ cursor:pointer;font-family:inherit; }}
.field .hint {{ font-size:0.74rem;color:#555;margin-top:4px;line-height:1.4; }}
.field .hint a {{ color:#f97316; }}
.saved-badge {{ display:inline-block;margin-left:8px;font-size:0.68rem;font-weight:700;
  background:#14532d;color:#4ade80;border-radius:4px;padding:1px 6px;text-transform:uppercase; }}
.test-result {{ margin-top:10px;padding:8px 12px;border-radius:6px;font-size:0.82rem;display:none; }}
.test-result.ok {{ background:#14532d;color:#4ade80;display:block; }}
.test-result.err {{ background:#3b0000;color:#f87171;display:block; }}
.test-result.testing {{ background:#1e1e2e;color:#aaa;display:block; }}
.toggle {{ position:relative;display:inline-block;width:44px;height:24px;flex-shrink:0; }}
.toggle input {{ opacity:0;width:0;height:0; }}
.slider {{ position:absolute;cursor:pointer;inset:0;background:#2a2a3a;border-radius:24px;transition:.2s; }}
.slider:before {{ position:absolute;content:"";height:18px;width:18px;left:3px;bottom:3px;
  background:#555;border-radius:50%;transition:.2s; }}
input:checked + .slider {{ background:#f97316; }}
input:checked + .slider:before {{ transform:translateX(20px);background:#fff; }}
</style>
<script>
const _SS = {all_settings!r};

function getVal(id) {{ const e=document.getElementById(id); return e?.value?.trim()||''; }}
function getFieldVal(id) {{
  const e=document.getElementById(id);
  if(!e) return null;
  const v=e.value.trim();
  if(!v && e.type==='password' && e.dataset.saved==='true') return null;
  return v||null;
}}

async function testConn(svc) {{
  const el=document.getElementById('test-'+svc);
  el.className='test-result testing'; el.textContent='Testing...';
  let body={{step:svc}};
  if(svc==='alldebrid') body.api_key=getVal('ALLDEBRID_API_KEY');
  if(svc==='overseerr') {{ body.url=getVal('OVERSEERR_URL'); body.api_key=getVal('OVERSEERR_API_KEY'); }}
  if(svc==='plex') body.plex_root=getVal('PLEX_ROOT');
  const r=await fetch('/setup/test',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify(body)}});
  const d=await r.json();
  el.className='test-result '+(d.ok?'ok':'err');
  el.textContent=(d.ok?'✅ ':'❌ ')+d.message;
}}

async function testAll() {{ await Promise.all(['alldebrid','overseerr','plex'].map(testConn)); }}

async function testTautulli() {{
  const el = document.getElementById('test-tautulli');
  el.className = 'test-result testing'; el.textContent = 'Testing...';
  const url = getVal('TAUTULLI_URL');
  const key = getVal('TAUTULLI_API_KEY');
  if (!url || !key) {{
    el.className = 'test-result err'; el.textContent = '❌ URL and API key required';
    return;
  }}
  const r = await fetch('/api/settings/test-tautulli', {{
    method: 'POST',
    headers: {{'Content-Type': 'application/json'}},
    body: JSON.stringify({{url, api_key: key}})
  }});
  const d = await r.json();
  el.className = 'test-result ' + (d.ok ? 'ok' : 'err');
  el.textContent = (d.ok ? '✅ ' : '❌ ') + d.message;
}}

function loadSettings() {{
  const toggleKeys = ['include_unreleased_episodes', 'auto_add', 'english_only', 'no_cam'];
  for (const k of toggleKeys) {{
    const cb = document.getElementById(k);
    if (cb) cb.checked = _SS[k] === 'true';
  }}
  const searchKeys=['series_completed_strategy','series_ongoing_strategy','series_preferred_quality',
    'series_fallback_any_quality','movie_preferred_quality','movie_fallback_any_quality',
    'precache_cooldown_minutes','cache_ttl_days'];
  for(const k of searchKeys){{
    const e=document.getElementById(k);
    if(e&&_SS[k]!==undefined) e.value=_SS[k];
  }}
  fetch('/api/settings/dfs').then(r=>r.json()).then(dfs=>{{
    const m={{cache_dir:'dfs_cache_dir',disk_cache_size_gb:'dfs_disk_cache_size_gb',
      cache_expiry_h:'dfs_cache_expiry_h',chunk_size_mb:'dfs_chunk_size_mb',
      read_ahead_mb:'dfs_read_ahead_mb',cleanup_interval_m:'dfs_cleanup_interval_m'}};
    for(const[k,id] of Object.entries(m)){{
      const e=document.getElementById(id); if(e&&dfs[k]!==undefined) e.value=dfs[k];
    }}
  }}).catch(()=>{{}});
}}

async function saveSetting(key,value) {{
  const r=await fetch('/api/settings/behaviour',{{method:'POST',
    headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{key,value:value.toString()}})}});
  const d=await r.json();
  toast(r.ok?'✅ '+d.message:'❌ '+(d.detail||'Error'), r.ok);
}}

async function saveSearch() {{
  const res=document.getElementById('search-result');
  res.className='test-result testing'; res.style.display='block'; res.textContent='Saving...';
  const payload={{}};
  ['series_completed_strategy','series_ongoing_strategy','series_preferred_quality',
   'series_fallback_any_quality','movie_preferred_quality','movie_fallback_any_quality',
   'precache_cooldown_minutes','cache_ttl_days'].forEach(k=>{{
    const e=document.getElementById(k); if(e) payload[k]=e.value;
  }});
  const r=await fetch('/api/settings/search',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify(payload)}});
  const d=await r.json();
  res.className='test-result '+(r.ok?'ok':'err');
  res.textContent=r.ok?'✅ Saved':'❌ Save failed';
}}

async function saveDFS() {{
  const res=document.getElementById('dfs-result');
  res.className='test-result testing'; res.style.display='block'; res.textContent='Saving...';
  const payload={{
    cache_dir:document.getElementById('dfs_cache_dir').value||'/docker/debridarr/tmp/cache',
    disk_cache_size_gb:+document.getElementById('dfs_disk_cache_size_gb').value,
    cache_expiry_h:+document.getElementById('dfs_cache_expiry_h').value,
    chunk_size_mb:+document.getElementById('dfs_chunk_size_mb').value,
    read_ahead_mb:+document.getElementById('dfs_read_ahead_mb').value,
    cleanup_interval_m:+document.getElementById('dfs_cleanup_interval_m').value,
  }};
  const r=await fetch('/api/settings/dfs',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify(payload)}});
  const d=await r.json();
  res.className='test-result '+(r.ok?'ok':'err');
  res.textContent=r.ok?'✅ DFS settings saved':'❌ Save failed';
}}

async function saveAll() {{
  const res=document.getElementById('save-result');
  res.className='test-result testing'; res.textContent='Saving...';
  const raw={{
    ALLDEBRID_API_KEY:getFieldVal('ALLDEBRID_API_KEY'),
    OVERSEERR_URL:getFieldVal('OVERSEERR_URL'),
    OVERSEERR_API_KEY:getFieldVal('OVERSEERR_API_KEY'),
    TMDB_API_KEY:getFieldVal('TMDB_API_KEY'),
    DEBRIDARR_BASE_URL:getFieldVal('DEBRIDARR_BASE_URL'),
    PLEX_ROOT:getFieldVal('PLEX_ROOT'),
    TZ:getFieldVal('TZ'),
    PUID:getFieldVal('PUID'),
    PGID:getFieldVal('PGID'),
  }};
  // Save Tautulli credentials to DB (not .env — they're runtime settings)
  const tUrl = getFieldVal('TAUTULLI_URL');
  const tKey = getFieldVal('TAUTULLI_API_KEY');
  if (tUrl) await fetch('/api/settings/behaviour', {{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{key:'tautulli_url',value:tUrl}})}});
  if (tKey) await fetch('/api/settings/behaviour', {{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{key:'tautulli_api_key',value:tKey}})}});
  const payload=Object.fromEntries(Object.entries(raw).filter(([_,v])=>v!==null));
  const r=await fetch('/api/settings/save',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify(payload)}});
  const d=await r.json();
  res.className='test-result '+(r.ok?'ok':'err');
  res.textContent=r.ok?'✅ '+d.message:'❌ '+(d.detail||'Save failed');
}}

loadSettings();
</script>"""
    return _page("Settings", "settings", body, extra)


# ── Settings API ──────────────────────────────────────────────────────────────
@app.post("/api/settings/save")
async def api_settings_save(request: Request):
    body = await request.json()
    cfg  = load_saved_config()
    allowed = {"ALLDEBRID_API_KEY","OVERSEERR_URL","OVERSEERR_API_KEY",
               "DEBRIDARR_BASE_URL","PLEX_ROOT","TZ","PUID","PGID"}
    for k, v in body.items():
        if k in allowed and v: cfg[k] = v
    if body.get("TMDB_API_KEY"):
        db: CacheDB = request.app.state.db
        db.set_setting("tmdb_api_key", body["TMDB_API_KEY"])
        if request.app.state.library:
            request.app.state.library.tmdb_key = body["TMDB_API_KEY"]
    write_env(cfg)
    import os
    for k, v in cfg.items(): os.environ[k] = v
    _init_clients(request.app)
    if request.app.state.library: request.app.state.library.invalidate_cache()
    log.info("⚙️  Settings updated — restarting...")
    _schedule_restart(delay=2.0)
    return {"status": "ok", "message": "Settings saved — restarting..."}


@app.post("/api/settings/search")
async def api_settings_search(request: Request):
    db: CacheDB = request.app.state.db
    payload = await request.json()
    allowed = {"series_completed_strategy","series_ongoing_strategy",
               "series_preferred_quality","series_fallback_any_quality",
               "precache_cooldown_minutes","movie_preferred_quality",
               "movie_fallback_any_quality","cache_ttl_days"}
    for k, v in payload.items():
        if k in allowed: db.set_setting(k, str(v))
    return {"status": "ok"}


@app.get("/api/settings/get")
async def api_settings_get(request: Request):
    db: CacheDB = request.app.state.db
    return db.get_all_settings()


@app.post("/api/settings/behaviour")
async def api_settings_behaviour(request: Request, background_tasks: BackgroundTasks):
    body  = await request.json()
    key   = body.get("key", "").strip()
    value = body.get("value", "").strip()
    allowed = {"include_unreleased_episodes", "auto_add", "tautulli_url", "tautulli_api_key",
               "english_only", "no_cam"}
    if key not in allowed:
        raise HTTPException(400, f"Unknown setting: {key}")
    db: CacheDB = request.app.state.db
    db.set_setting(key, value)
    if key == "include_unreleased_episodes":
        background_tasks.add_task(_sync_all_series_episodes, request.app, value == "true")
    if key == "auto_add" and value == "true":
        background_tasks.add_task(_run_auto_add, request.app)
    label = "enabled" if value == "true" else "disabled"
    return {"status": "ok", "message": f"Auto-add {label}" if key == "auto_add" else f"{key} saved"}


@app.post("/api/settings/test-tautulli")
async def api_test_tautulli(request: Request):
    body = await request.json()
    url  = body.get("url", "").rstrip("/")
    key  = body.get("api_key", "")
    if not url or not key:
        return {"ok": False, "message": "URL and API key are required"}
    try:
        import httpx as _hx
        r = await _hx.AsyncClient(timeout=8).get(
            f"{url}/api/v2",
            params={"apikey": key, "cmd": "get_server_info"},
        )
        if r.status_code != 200:
            return {"ok": False, "message": f"HTTP {r.status_code}"}
        d = r.json()
        if d.get("response", {}).get("result") != "success":
            return {"ok": False, "message": d.get("response", {}).get("message", "Invalid response")}
        server = d["response"]["data"].get("pms_name", "Plex")
        # Also save if test passes
        db: CacheDB = request.app.state.db
        db.set_setting("tautulli_url", url)
        db.set_setting("tautulli_api_key", key)
        return {"ok": True, "message": f"Connected to {server}"}
    except Exception as e:
        return {"ok": False, "message": str(e)}


@app.get("/api/settings/dfs")
async def api_settings_dfs_get():
    return get_dfs_settings()


@app.post("/api/settings/dfs")
async def api_settings_dfs_save(request: Request):
    body = await request.json()
    allowed = {"cache_dir","disk_cache_size_gb","cache_expiry_h","chunk_size_mb","read_ahead_mb","cleanup_interval_m"}
    cfg = {k: v for k, v in body.items() if k in allowed}
    for k in ("disk_cache_size_gb","cache_expiry_h","chunk_size_mb","read_ahead_mb","cleanup_interval_m"):
        if k in cfg:
            try: cfg[k] = int(cfg[k])
            except Exception: pass
    update_dfs_settings(cfg)
    db: CacheDB = request.app.state.db
    import json
    db.set_setting("dfs_settings", json.dumps(cfg))
    return {"status": "ok", "settings": get_dfs_settings()}


# ── Proxy / webhook / cache ───────────────────────────────────────────────────
@app.get("/webhook/test")
async def webhook_test():
    return {"status": "ok", "message": "Debridarr webhook is reachable"}

@app.get("/proxy/{cache_key}")
async def stream_proxy(cache_key: str, request: Request):
    return await proxy_stream(request, cache_key, request.app.state.db, request.app.state.alldebrid)

@app.post("/resolve")
async def manual_resolve(request: Request, background_tasks: BackgroundTasks):
    body  = await request.json()
    event = PlayEvent(media_type=MediaType(body["media_type"]), title=body["title"],
                      year=body.get("year"), season=body.get("season"), episode=body.get("episode"))
    background_tasks.add_task(resolve_and_cache, request.app, event)
    s = request.app.state.settings
    return {"status": "resolving", "cache_key": event.cache_key(),
            "proxy_url": f"{s.DEBRIDARR_BASE_URL}/proxy/{event.cache_key()}"}

@app.get("/cache")
async def list_cache(request: Request): return request.app.state.db.list_all()

@app.post("/cache/{cache_key}/expire")
@app.post("/cache/{cache_key}/expire")
async def expire_cache_entry(cache_key: str, request: Request, background_tasks: BackgroundTasks):
    db        = request.app.state.db
    s         = request.app.state.settings
    alldebrid = request.app.state.alldebrid
    entry     = db.get(cache_key)
    if not entry:
        raise HTTPException(404, "Not found")
    background_tasks.add_task(_hard_expire, entry, db, s, alldebrid)
    return {"status": "ok", "message": "Expiring — symlink deleted, removed from AllDebrid"}


async def _hard_expire(entry: dict, db: "CacheDB", s, alldebrid):
    """
    Full cleanup for one cache entry:
    1. Delete symlink
    2. Restore placeholder
    3. Unregister from FUSE
    4. Delete from AllDebrid
    5. Delete from DB
    """
    ck           = entry["cache_key"]
    strm         = entry.get("strm_path")
    torrent_name = entry.get("torrent_name")
    magnet       = entry.get("magnet_link", "")

    # 1. Delete symlink
    if strm:
        p = Path(strm)
        if p.is_symlink():
            p.unlink(missing_ok=True)

    # 2. Restore placeholder
    if s.PLEX_ROOT:
        _restore_placeholder(ck, entry["title"], entry.get("year"),
                             entry.get("season"), entry.get("episode"),
                             entry["media_type"], s.PLEX_ROOT)

    # 3. Unregister from FUSE (only if no other cached entry uses this torrent)
    if torrent_name and FUSE_AVAILABLE:
        others = [e for e in db.list_all()
                  if e.get("torrent_name") == torrent_name
                  and e["cache_key"] != ck
                  and e["status"] == "cached"]
        if not others:
            unregister_torrent(torrent_name)

    # 4. Delete from AllDebrid by hash
    if alldebrid and magnet:
        try:
            import httpx as _hx
            m = re.search(r"btih:([a-fA-F0-9]{40})", magnet, re.I)
            if m:
                info_hash = m.group(1).lower()
                r = await _hx.AsyncClient(timeout=10).get(
                    "https://api.alldebrid.com/v4.1/magnet/status",
                    params={"agent": "debridarr", "apikey": alldebrid.api_key, "status": "ready"},
                )
                if r.status_code == 200:
                    magnets = r.json().get("data", {}).get("magnets", {})
                    if isinstance(magnets, dict):
                        magnets = list(magnets.values())
                    for t in magnets:
                        if (t.get("hash") or "").lower() == info_hash:
                            await alldebrid.delete_magnet(str(t["id"]))
                            log.info(f"🗑️  Deleted from AllDebrid: {t['id']} ({ck})")
                            break
        except Exception as e:
            log.debug(f"AllDebrid delete {ck}: {e}")

    # 5. Delete from DB
    db.delete(ck)
    log.info(f"🗑️  Hard expired: {ck}")


@app.delete("/cache/{cache_key}")
async def delete_cache_entry(cache_key: str, request: Request, background_tasks: BackgroundTasks):
    db    = request.app.state.db
    s     = request.app.state.settings
    alldebrid = request.app.state.alldebrid
    entry = db.get(cache_key)
    if not entry:
        raise HTTPException(404, "Not found")
    background_tasks.add_task(_hard_expire, entry, db, s, alldebrid)
    return {"status": "deleted"}

@app.get("/health")
async def health(): return {"status": "ok", "service": "debridarr", "version": "0.5.0"}


@app.post("/webhook/tautulli")
async def tautulli_webhook(request: Request, background_tasks: BackgroundTasks):
    try:    payload = await request.json()
    except: payload = dict(await request.form())

    log.info(f"📺 Tautulli: {payload}")
    media_type = payload.get("media_type", "")
    title      = payload.get("grandparent_title") or payload.get("title", "")
    year       = payload.get("year") or payload.get("grandparent_year")
    season     = payload.get("parent_media_index")
    episode    = payload.get("media_index")

    if media_type not in ("movie", "episode") or not title:
        return {"status": "ignored"}

    event = PlayEvent(
        media_type=MediaType(media_type), title=title,
        year=int(year) if year else None,
        season=int(season) if season else None,
        episode=int(episode) if episode else None,
        rating_key=payload.get("rating_key"),
        tmdb_id=payload.get("themoviedb_id") or payload.get("tmdb_id"),
        tvdb_id=payload.get("thetvdb_id") or payload.get("tvdb_id"),
        imdb_id=payload.get("imdb_id"),
    )
    log.info(f"📺 Resolving: {event.cache_key()} — {title} S{season}E{episode}")
    background_tasks.add_task(resolve_and_cache, request.app, event)
    return {"status": "accepted", "cache_key": event.cache_key()}


# ── Background helpers ────────────────────────────────────────────────────────

async def _precache_movie(app: FastAPI, title: str, year, tmdb_id, imdb_id):
    """Resolve and cache a movie immediately after it's added."""
    await asyncio.sleep(2)
    event = PlayEvent(
        media_type=MediaType.movie,
        title=title, year=year,
        tmdb_id=str(tmdb_id) if tmdb_id else None,
        imdb_id=str(imdb_id) if imdb_id else None,
    )
    log.info(f"🎬 Pre-caching movie: {title!r}")
    try:
        await resolve_and_cache(app, event)
    except Exception as e:
        log.error(f"Movie pre-cache {title!r}: {e}")


async def _precache_series(app: FastAPI, title: str, year, episodes: list):
    """
    Cache all episodes immediately after a series is added.
    Checks FUSE first (instant), falls back to TPB search.
    Skips episodes already cached or resolving.
    """
    if not episodes:
        log.info(f"📺 No episodes to pre-cache for {title!r}")
        return

    await asyncio.sleep(3)
    db       = app.state.db
    cooldown = int(db.get_setting("precache_cooldown_minutes", "1"))

    log.info(f"📺 Pre-caching {len(episodes)} episodes for {title!r}")
    cached_count = 0

    for ep in episodes:
        event = PlayEvent(
            media_type=MediaType.episode,
            title=title, year=year,
            season=ep["season"], episode=ep["episode"],
        )
        ck = event.cache_key()
        existing = db.get(ck)
        if existing and existing["status"] in ("cached", "resolving"):
            cached_count += 1
            continue
        try:
            await resolve_and_cache(app, event)
            cached_count += 1
            await asyncio.sleep(max(2, cooldown * 60))
        except Exception as e:
            log.debug(f"Episode pre-cache {ck}: {e}")

    log.info(f"📺 Pre-cache done: {title!r} — {cached_count}/{len(episodes)} episodes")


async def _fetch_tmdb_poster(tmdb_id, title: str, is_movie: bool, tmdb_key: str) -> str:
    """Fetch poster URL from TMDB — by ID first, title search fallback."""
    if not tmdb_key: return ""
    import httpx as _hx
    endpoint = "movie" if is_movie else "tv"
    try:
        async with _hx.AsyncClient(timeout=8) as c:
            if tmdb_id:
                r = await c.get(f"https://api.themoviedb.org/3/{endpoint}/{tmdb_id}",
                                params={"api_key": tmdb_key})
                if r.status_code == 200:
                    p = r.json().get("poster_path")
                    if p: return f"https://image.tmdb.org/t/p/w342{p}"
            # Fallback: search by title
            r2 = await c.get(f"https://api.themoviedb.org/3/search/{endpoint}",
                             params={"api_key": tmdb_key, "query": title})
            if r2.status_code == 200:
                results = r2.json().get("results", [])
                if results and results[0].get("poster_path"):
                    return f"https://image.tmdb.org/t/p/w342{results[0]['poster_path']}"
    except Exception:
        pass
    return ""


async def _cleanup_loop(app: FastAPI):
    """
    Hourly cleanup — remove entries whose 30-day TTL has expired.
    Deletes symlink, restores placeholder, removes from AllDebrid, deletes DB entry.
    """
    while True:
        await asyncio.sleep(3600)
        db = app.state.db
        s  = app.state.settings

        for entry in db.list_expired():
            ck = entry["cache_key"]
            log.info(f"⏰ TTL expired: {ck}")
            await _hard_expire(entry, db, s, app.state.alldebrid)

        purged = db.purge_expired()
        if purged:
            log.info(f"⏰ Purged {purged} expired cache entries")


# Torrent sync loop intentionally removed.
# Comparing FUSE names against AllDebrid names is unreliable due to truncation
# and causes false-positive deletions of valid cached files.
# Cache lifecycle is managed by:
#   - TTL expiry (_cleanup_loop) — removes after 30 days
#   - User remove action (api_library_remove) — removes immediately
#   - Symlink health check (_check_and_repair_symlinks) — repairs broken symlinks hourly


def _restore_placeholder(cache_key, title, year, season, episode, media_type, plex_root):
    try:
        if media_type == "movie":
            yp     = f" ({year})" if year else ""
            folder = Path(plex_root) / "movies" / f"{title}{yp}"
            ph     = folder / f"{title}{yp}.mp4"
            # Remove stale symlinks before restoring placeholder
            if folder.exists():
                for f in folder.iterdir():
                    if f.is_symlink() and f.suffix in (".mkv",".mp4",".avi",".mov",".m4v"):
                        f.unlink(missing_ok=True)
        else:
            if not season or not episode: return
            folder = Path(plex_root) / "tv" / title / f"Season {season:02d}"
            se     = f"S{season:02d}E{episode:02d}"
            ph     = folder / f"{title} - {se}.mp4"
            if folder.exists():
                for f in folder.glob(f"*{se}*.mkv"):
                    if f.is_symlink(): f.unlink(missing_ok=True)
        folder.mkdir(parents=True, exist_ok=True)
        if not ph.exists() and not ph.is_symlink():
            ph.write_bytes(_FAKE_MP4)
    except Exception as e:
        log.error(f"restore_placeholder {cache_key}: {e}")


async def _episode_sync_loop(app: FastAPI):
    """Run at startup (+30s) and hourly — audit episode placeholders against TMDB."""
    await asyncio.sleep(30)
    while True:
        try:   await _run_episode_sync(app)
        except Exception as e: log.error(f"Episode sync: {e}")
        await asyncio.sleep(3600)


async def _run_episode_sync(app: FastAPI):
    lm  = app.state.library
    db  = app.state.db
    s   = app.state.settings
    if not lm or not s.PLEX_ROOT: return

    lm.invalidate_cache()
    series_list        = await lm.get_sonarr_series(force=True)
    added_series       = [r for r in db.fake_library_list() if r["media_type"] == "series"]
    include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"
    total_added = total_removed = 0

    # ── Audit plex-strm/movies — remove folders not in fake_library ───────────
    added_movies = {r["title"].lower() for r in db.fake_library_list() if r["media_type"] == "movie"}
    movies_root  = Path(s.PLEX_ROOT) / "movies"
    if movies_root.exists():
        for folder in movies_root.iterdir():
            if not folder.is_dir(): continue
            # Extract title from "Title (Year)" folder name
            folder_title = folder.name.rsplit(" (", 1)[0].lower()
            if folder_title not in added_movies:
                import shutil as _shutil
                _shutil.rmtree(folder, ignore_errors=True)
                log.info(f"🗑️  Removed stale movie folder: {folder.name}")

    # ── Audit plex-strm/tv — remove folders not in fake_library ──────────────
    added_tv  = {r["title"].lower() for r in db.fake_library_list() if r["media_type"] == "series"}
    tv_root   = Path(s.PLEX_ROOT) / "tv"
    if tv_root.exists():
        for folder in tv_root.iterdir():
            if not folder.is_dir(): continue
            if folder.name.lower() not in added_tv:
                import shutil as _shutil
                _shutil.rmtree(folder, ignore_errors=True)
                log.info(f"🗑️  Removed stale TV folder: {folder.name}")

    for entry in added_series:
        title     = entry["title"]
        sonarr_id = entry.get("sonarr_id")
        year      = entry.get("year")
        if not sonarr_id: continue

        updated = next((s for s in series_list if s.get("id") == sonarr_id), None)
        if not updated: continue

        requested_seasons = updated.get("requested_seasons", [])
        result = await lm.sync_series_episodes(title, sonarr_id, year, include_unreleased,
                                                requested_seasons=requested_seasons)
        total_added   += result.get("added", 0)
        total_removed += result.get("removed", 0)

        # Audit: ensure every expected episode has placeholder or symlink
        try:
            all_eps = await lm.get_episodes(sonarr_id,
                                                    include_unreleased=include_unreleased,
                                                    requested_seasons=requested_seasons or None)
            by_season: dict[int, set] = {}
            for ep in all_eps:
                by_season.setdefault(ep["season"], set()).add(ep["episode"])

            show_folder = Path(s.PLEX_ROOT) / "tv" / title
            for sn, ep_nums in by_season.items():
                sf = show_folder / f"Season {sn:02d}"
                sf.mkdir(parents=True, exist_ok=True)
                on_mp4 = set(); on_sym = set()
                if sf.exists():
                    for f in sf.iterdir():
                        m = re.search(rf"S{sn:02d}E(\d{{2}})", f.name, re.I)
                        if m:
                            n = int(m.group(1))
                            if f.is_symlink(): on_sym.add(n)
                            elif f.suffix == ".mp4": on_mp4.add(n)
                covered = on_mp4 | on_sym
                for ep_n in ep_nums - covered:
                    (sf / f"{title} - S{sn:02d}E{ep_n:02d}.mp4").write_bytes(_FAKE_MP4)
                    total_added += 1
                for ep_n in on_mp4 - ep_nums:
                    ph = sf / f"{title} - S{sn:02d}E{ep_n:02d}.mp4"
                    if ph.exists() and not ph.is_symlink():
                        ph.unlink(missing_ok=True)
                        total_removed += 1
        except Exception as e:
            log.debug(f"Audit {title}: {e}")

    if total_added or total_removed:
        log.info(f"🔄 Episode sync: +{total_added} placeholders, -{total_removed} removed")
    else:
        log.info("🔄 Episode sync: all correct")


async def _sync_all_series_episodes(app: FastAPI, include_unreleased: bool):
    db = app.state.db; lm = app.state.library
    if not lm: return
    for entry in db.fake_library_list(media_type="series"):
        sid = entry.get("sonarr_id")
        if sid:
            await lm.sync_series_episodes(entry["title"], sid, entry.get("year"), include_unreleased)


async def _load_all_torrents(app: FastAPI):
    await asyncio.sleep(2)
    alldebrid = app.state.alldebrid
    s = app.state.settings
    if not alldebrid or not FUSE_AVAILABLE or not getattr(app.state, "fuse_thread", None):
        return
    try:
        torrents = await alldebrid.get_all_torrents()
        # Build hash → torrent map for reliable lookup on restart
        hash_map: dict[str, dict] = {}  # info_hash → {name, folder, files}
        for t in torrents:
            files       = t["files"]
            folder_name = t["name"]
            if files:
                stem = Path(files[0]["n"]).stem
                if stem and folder_name and stem.startswith(folder_name.rstrip("-")):
                    folder_name = stem
            register_torrent(folder_name, files)
            t["_folder"] = folder_name
            # Store by hash for reliable restart recovery
            h = t.get("hash", "").lower()
            if h:
                hash_map[h] = {"name": t["name"], "folder": folder_name, "files": files}

        log.info(f"✅ {len(torrents)} torrents loaded into FUSE")
        if s.PLEX_ROOT:
            _restore_symlinks(app, hash_map)
    except Exception as e:
        log.error(f"_load_all_torrents: {e}", exc_info=True)


def _restore_symlinks(app, hash_map: dict = None):
    """
    Restore symlinks on startup.
    Uses magnet_link hash to find the exact torrent — no name matching needed.
    Falls back to name-based FUSE search only if hash not available.
    """
    import re as _re
    db = app.state.db
    s  = app.state.settings
    if not s.PLEX_ROOT or not s.FUSE_SYMLINK_ROOT:
        return
    if hash_map is None:
        hash_map = {}

    trusted = restored = missing = 0

    for entry in db.list_all():
        if entry["status"] != "cached":
            continue
        strm = entry.get("strm_path")
        ck   = entry["cache_key"]

        # Step 1: if symlink exists on disk, try to validate/fix its FUSE target
        if strm:
            p = Path(strm)
            if p.is_symlink():
                target = str(p.readlink())
                if s.FUSE_SYMLINK_ROOT in target:
                    rel   = target.replace(s.FUSE_SYMLINK_ROOT, "").lstrip("/")
                    parts = rel.split("/", 1)
                    if len(parts) == 2:
                        folder_name, filename = parts
                        # Check if registered under this exact name
                        if get_torrent_file(folder_name, filename):
                            trusted += 1
                            continue
                        # Not registered — find the torrent by hash from magnet_link
                        magnet = entry.get("magnet_link", "")
                        m = _re.search(r"btih:([a-fA-F0-9]{40})", magnet or "", _re.I)
                        if m:
                            h = m.group(1).lower()
                            if h in hash_map:
                                # Re-register under the current folder name from AllDebrid
                                t = hash_map[h]
                                new_folder = t["folder"]
                                # Find the specific file for this episode
                                target_file = _pick_file(t["files"], entry)
                                if target_file:
                                    new_filename = target_file["n"]
                                    new_target   = get_fuse_path(new_folder, new_filename, s.FUSE_SYMLINK_ROOT)
                                    # Update symlink to point to new path
                                    p.unlink(missing_ok=True)
                                    p.symlink_to(new_target)
                                    db.update_cached(ck, magnet, entry.get("stream_url",""),
                                                     new_folder, entry.get("quality","unknown"), str(p))
                                    trusted += 1
                                    continue
                        # Hash not found — symlink exists but torrent gone from AllDebrid
                        # Keep symlink as-is; health check will handle it
                        trusted += 1
                        continue

        # Step 2: no symlink — find by hash first, then title search
        magnet = entry.get("magnet_link", "")
        m = _re.search(r"btih:([a-fA-F0-9]{40})", magnet or "", _re.I)
        torrent_data = None
        if m:
            h = m.group(1).lower()
            if h in hash_map:
                torrent_data = hash_map[h]

        if torrent_data:
            target_file = _pick_file(torrent_data["files"], entry)
            if target_file:
                folder_name = torrent_data["folder"]
                filename    = target_file["n"]
                fuse_virtual = get_fuse_path(folder_name, filename, s.FUSE_SYMLINK_ROOT)
                link = _make_plex_symlink(ck, entry["title"], entry.get("year"),
                                          entry.get("season"), entry.get("episode"),
                                          entry["media_type"], s.PLEX_ROOT, fuse_virtual, filename)
                if link:
                    db.update_cached(ck, magnet, entry.get("stream_url",""),
                                     folder_name, entry.get("quality","unknown"), str(link))
                    restored += 1
                    continue

        # Step 3: fallback — fuzzy title search in FUSE
        fuse_match = _find_in_fuse(entry["title"], entry.get("year"),
                                    entry.get("season"), entry.get("episode"))
        if not fuse_match:
            missing += 1
            continue

        torrent_name, filename, _ = fuse_match
        fuse_virtual = get_fuse_path(torrent_name, filename, s.FUSE_SYMLINK_ROOT)
        link = _make_plex_symlink(ck, entry["title"], entry.get("year"),
                                   entry.get("season"), entry.get("episode"),
                                   entry["media_type"], s.PLEX_ROOT, fuse_virtual, filename)
        if link:
            db.update_cached(ck, entry.get("magnet_link",""), entry.get("stream_url",""),
                             torrent_name, entry.get("quality","unknown"), str(link))
            restored += 1

    log.info(f"✅ Symlinks: {trusted} trusted, {restored} restored, {missing} not in FUSE")


def _pick_file(files: list, entry: dict) -> Optional[dict]:
    """Pick the right file from a torrent for this DB entry."""
    season  = entry.get("season")
    episode = entry.get("episode")
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}

    if season and episode:
        se = f"S{season:02d}E{episode:02d}".upper()
        for f in files:
            if se in f.get("n", "").upper() and any(f["n"].lower().endswith(e) for e in video_exts):
                return f

    # Fallback: largest video file
    videos = [f for f in files if any(f.get("n","").lower().endswith(e) for e in video_exts)]
    return max(videos, key=lambda f: f.get("s", 0)) if videos else None


async def _symlink_health_loop(app: FastAPI):
    # Wait for FUSE to stabilise
    prev = 0; stable = 0
    for _ in range(180):
        await asyncio.sleep(1)
        count = len(list_torrents())
        if count > 0 and count == prev:
            stable += 1
            if stable >= 5: break
        else: stable = 0
        prev = count

    log.info(f"Starting symlink health check ({prev} torrents in FUSE)")
    while True:
        try:   await _check_and_repair_symlinks(app)
        except Exception as e: log.error(f"Symlink health: {e}")
        await asyncio.sleep(3600)


async def _check_and_repair_symlinks(app: FastAPI):
    db = app.state.db; s = app.state.settings
    if not s.PLEX_ROOT: return

    cached  = [e for e in db.list_all() if e["status"] == "cached"]
    broken  = []; ok = 0

    for entry in cached:
        strm  = entry.get("strm_path")
        issue = None
        try:
            if strm:
                p = Path(strm)
                if not p.is_symlink():
                    issue = "missing"
                else:
                    target = str(p.readlink())
                    if s.FUSE_SYMLINK_ROOT in target:
                        # Symlink points into FUSE — trust it as long as it's a symlink.
                        # FUSE lazy-loads files so .exists() is unreliable.
                        # Only flag broken if the torrent folder is truly gone from FUSE
                        # AND we can't find it via title search either.
                        rel   = target.replace(s.FUSE_SYMLINK_ROOT,"").lstrip("/")
                        parts = rel.split("/", 1)
                        if len(parts) == 2:
                            if get_torrent_file(parts[0], parts[1]):
                                # Registered and found — all good
                                ok += 1
                                db.refresh_ttl(entry["cache_key"])
                            else:
                                # Not found under that key — try fuzzy search
                                m = _find_in_fuse(entry["title"], entry.get("year"),
                                                   entry.get("season"), entry.get("episode"))
                                if m:
                                    # Found under different name — re-point symlink
                                    new_folder, new_file, _ = m
                                    new_target = get_fuse_path(new_folder, new_file, s.FUSE_SYMLINK_ROOT)
                                    p.unlink(missing_ok=True)
                                    p.symlink_to(new_target)
                                    db.update_cached(entry["cache_key"],
                                                     entry.get("magnet_link",""),
                                                     entry.get("stream_url",""),
                                                     new_folder, entry.get("quality","unknown"),
                                                     str(p))
                                    ok += 1
                                    db.refresh_ttl(entry["cache_key"])
                                else:
                                    # Truly not in FUSE — needs re-resolve
                                    issue = "not in FUSE"
                        else:
                            ok += 1
                    else:
                        if p.exists(): ok += 1
                        else:          issue = "dangling"
            else:
                ok += 1  # no strm_path means no symlink expected yet
        except Exception as e:
            log.debug(f"Health check {entry['cache_key']}: {e}")

        if issue: broken.append((entry, issue))

    total = len(cached)
    if not broken:
        log.info(f"✅ Symlink check: {ok}/{total} OK"); return

    log.info(f"🔧 Symlink check: {len(broken)} broken, {ok} OK / {total}")

    # Write placeholders for all broken entries first
    for entry, _ in broken:
        try:
            mtype = entry["media_type"]; t = entry["title"]
            yr = entry.get("year"); sn = entry.get("season"); ep = entry.get("episode")
            if mtype == "movie":
                folder = Path(s.PLEX_ROOT) / "movies" / f"{t}{' ('+str(yr)+')' if yr else ''}"
                ph = folder / f"{t}{' ('+str(yr)+')' if yr else ''}.mp4"
            elif sn and ep:
                folder = Path(s.PLEX_ROOT) / "tv" / t / f"Season {sn:02d}"
                ph = folder / f"{t} - S{sn:02d}E{ep:02d}.mp4"
            else: continue
            folder.mkdir(parents=True, exist_ok=True)
            if not ph.exists() and not ph.is_symlink():
                ph.write_bytes(_FAKE_MP4)
        except Exception: pass

    for entry, issue in broken:
        log.info(f"  🔧 {entry['cache_key']}: {issue}")
        fuse_match = _find_in_fuse(entry["title"], entry.get("year"),
                                    entry.get("season"), entry.get("episode"))
        if fuse_match:
            torrent_name, filename, _ = fuse_match
            fuse_virtual = get_fuse_path(torrent_name, filename, s.FUSE_SYMLINK_ROOT)
            link = _make_plex_symlink(entry["cache_key"], entry["title"], entry.get("year"),
                                      entry.get("season"), entry.get("episode"), entry["media_type"],
                                      s.PLEX_ROOT, fuse_virtual, filename)
            if link:
                db.update_cached(entry["cache_key"], entry.get("magnet_link",""),
                                 entry.get("stream_url",""), torrent_name,
                                 entry.get("quality","unknown"), str(link))
                log.info(f"  ✅ Relinked: {entry['cache_key']}")
                continue

        # Not in FUSE — re-resolve (placeholder already written above)
        event = PlayEvent(media_type=MediaType(entry["media_type"]), title=entry["title"],
                          year=entry.get("year"), season=entry.get("season"), episode=entry.get("episode"))
        try:
            db.update_status(entry["cache_key"], "not_found")
            await resolve_and_cache(app, event)
            await asyncio.sleep(2)
        except Exception as e:
            db.update_status(entry["cache_key"], "cached")
            log.error(f"  ❌ Re-resolve failed: {entry['cache_key']}: {e}")


def _find_in_fuse(title: str, year, season, episode) -> Optional[tuple]:
    def norm(s):
        s = s.lower().replace("'","").replace("\u2019","")
        s = re.sub(r"[._]", " ", s)
        return s.split()

    title_words = norm(title)
    if not title_words: return None
    video_exts = {".mkv",".mp4",".avi",".mov",".m4v"}

    for torrent_name in list_torrents():
        t_words = norm(torrent_name)
        if not all(w in t_words for w in title_words): continue
        if year and str(year) not in torrent_name: continue
        for fname in list_files(torrent_name):
            if not any(fname.lower().endswith(e) for e in video_exts): continue
            if season and episode:
                if f"S{season:02d}E{episode:02d}".upper() not in fname.upper(): continue
            elif season:
                if f"S{season:02d}".upper() not in fname.upper(): continue
            f = get_torrent_file(torrent_name, fname)
            if f: return torrent_name, fname, f
    return None


def _detect_quality(name: str) -> str:
    n = name.lower()
    for q in ("2160p","4k","uhd","1080p","720p","480p"):
        if q in n: return q
    return "unknown"


def _make_plex_symlink(cache_key, title, year, season, episode,
                       media_type, plex_root, target, video_name) -> Optional[Path]:
    """Placeholder-first symlink creation. Never leaves Plex with an empty slot."""
    if media_type == "movie":
        yp     = f" ({year})" if year else ""
        folder = Path(plex_root) / "movies" / f"{title}{yp}"
        ph     = folder / f"{title}{yp}.mp4"
    else:
        sf     = f"Season {season:02d}" if season else "Season 00"
        folder = Path(plex_root) / "tv" / title / sf
        se     = f"S{season:02d}E{episode:02d}" if (season and episode) else "S00E00"
        ph     = folder / f"{title} - {se}.mp4"

    try:
        folder.mkdir(parents=True, exist_ok=True)
        if not ph.exists() and not ph.is_symlink():
            ph.write_bytes(_FAKE_MP4)
    except Exception as e:
        log.error(f"Placeholder write {cache_key}: {e}")

    try:
        # Remove stale symlinks for this episode
        if media_type == "movie":
            for f in folder.iterdir():
                if f.is_symlink() and f.suffix in (".mkv",".mp4",".avi",".mov",".m4v"):
                    f.unlink(missing_ok=True)
        elif season and episode:
            se_pat = f"S{season:02d}E{episode:02d}".upper()
            for f in folder.iterdir():
                if f.is_symlink() and se_pat in f.name.upper():
                    f.unlink(missing_ok=True)

        link = folder / video_name
        if link.is_symlink() or link.exists(): link.unlink(missing_ok=True)
        link.symlink_to(target)

        if link.is_symlink():
            if ph.exists() and not ph.is_symlink(): ph.unlink(missing_ok=True)
            log.info(f"🔗 Symlink: {link.name} → {target}")
            return link
        else:
            if not ph.exists(): ph.write_bytes(_FAKE_MP4)
            return None
    except Exception as e:
        log.error(f"symlink {cache_key}: {e}")
        try:
            if not ph.exists() and not ph.is_symlink():
                folder.mkdir(parents=True, exist_ok=True)
                ph.write_bytes(_FAKE_MP4)
        except Exception: pass
        return None


async def _verify_episode_with_tmdb(tmdb_id, tvdb_id, season, episode, title, tmdb_key=""):
    if not tmdb_key: return season, episode
    import httpx as _hx
    try:
        if tvdb_id:
            async with _hx.AsyncClient(timeout=10) as c:
                r = await c.get(f"https://api.themoviedb.org/3/find/{tvdb_id}",
                                params={"api_key": tmdb_key, "external_source": "tvdb_id"})
                if r.status_code == 200:
                    eps = r.json().get("tv_episode_results", [])
                    if eps:
                        e   = eps[0]
                        ts  = e.get("season_number", season)
                        tep = e.get("episode_number", episode)
                        if ts != season or tep != episode:
                            log.info(f"TMDB corrected {title} S{season:02d}E{episode:02d} → S{ts:02d}E{tep:02d}")
                        return ts, tep
    except Exception as e:
        log.debug(f"TMDB lookup {title}: {e}")
    return season, episode


async def _auto_add_loop(app: FastAPI):
    """
    Background loop — when auto_add is enabled, periodically checks Overseerr
    for new approved requests and adds any not already in fake_library.
    Runs at startup (after a short delay) and then every N minutes.
    """
    await asyncio.sleep(60)  # Give everything time to stabilise on startup
    while True:
        db: CacheDB = app.state.db
        try:
            if db.get_setting("auto_add", "false") == "true":
                await _run_auto_add(app)
        except Exception as e:
            log.error(f"Auto-add loop error: {e}")
        interval = int(db.get_setting("auto_add_interval_minutes", "15"))
        await asyncio.sleep(max(5, interval) * 60)


async def _run_auto_add(app: FastAPI):
    """
    One pass of auto-add — checks BOTH Tautulli (all Plex libraries) and Overseerr
    for titles not yet in fake_library, then adds and starts caching each one.
    Safe to call multiple times; skips already-added titles.
    """
    db: CacheDB        = app.state.db
    lm: LibraryManager = app.state.library
    tmdb_key           = db.get_setting("tmdb_api_key", "")
    inc                = db.get_setting("include_unreleased_episodes", "false") == "true"

    added_movies = {r["title"].lower() for r in db.fake_library_list() if r["media_type"] == "movie"}
    added_series = {r["title"].lower() for r in db.fake_library_list() if r["media_type"] == "series"}

    # ── Source 1: Tautulli — all Plex libraries ───────────────────────────────
    tautulli_items = await _fetch_tautulli_library(db)
    tautulli_new = [
        i for i in tautulli_items
        if (i["mtype"] == "movie"  and i["title"].lower() not in added_movies)
        or (i["mtype"] == "series" and i["title"].lower() not in added_series)
    ]

    # ── Source 2: Overseerr ────────────────────────────────────────────────────
    overseerr_movies: list[dict] = []
    overseerr_series: list[dict] = []
    if lm and lm.url:
        try:
            all_movies = await lm.get_radarr_movies()
            overseerr_movies = [m for m in all_movies if m["title"].lower() not in added_movies]
        except Exception as e:
            log.warning(f"Auto-add: Overseerr movies failed: {e}")
        try:
            all_series = await lm.get_sonarr_series()
            overseerr_series = [s for s in all_series if s["title"].lower() not in added_series]
        except Exception as e:
            log.warning(f"Auto-add: Overseerr series failed: {e}")

    # Build a lookup of rich Overseerr metadata keyed by lowercase title
    overseerr_movie_meta = {m["title"].lower(): m for m in overseerr_movies}
    overseerr_series_meta = {s["title"].lower(): s for s in overseerr_series}

    # ── Merge: Tautulli items enriched with Overseerr metadata where available ─
    # Collect all unique titles to add, prefer Overseerr metadata when available.
    to_add_movies: list[dict] = []
    to_add_series: list[dict] = []
    seen_movies: set[str] = set()
    seen_series: set[str] = set()

    # Overseerr first (has rich metadata: arr_id, poster, episodes)
    for m in overseerr_movies:
        key = m["title"].lower()
        if key not in seen_movies:
            seen_movies.add(key)
            to_add_movies.append({"source": "overseerr", **m})

    for s in overseerr_series:
        key = s["title"].lower()
        if key not in seen_series:
            seen_series.add(key)
            to_add_series.append({"source": "overseerr", **s})

    # Then Tautulli items not already covered by Overseerr
    for item in tautulli_new:
        key = item["title"].lower()
        if item["mtype"] == "movie" and key not in seen_movies:
            seen_movies.add(key)
            # Try to enrich from Overseerr metadata
            meta = overseerr_movie_meta.get(key, {})
            to_add_movies.append({"source": "tautulli", "title": item["title"],
                                   "year": item.get("year") or meta.get("year"),
                                   **{k: meta.get(k) for k in ("id","tmdb_id","imdb_id","poster","overview") if meta.get(k)}})
        elif item["mtype"] == "series" and key not in seen_series:
            seen_series.add(key)
            meta = overseerr_series_meta.get(key, {})
            to_add_series.append({"source": "tautulli", "title": item["title"],
                                   "year": item.get("year") or meta.get("year"),
                                   **{k: meta.get(k) for k in ("id","tmdb_id","tvdb_id","imdb_id","poster","overview","season_count","requested_seasons","is_ended") if meta.get(k)}})

    total_new = len(to_add_movies) + len(to_add_series)
    if total_new == 0:
        log.debug("🤖 Auto-add: nothing new")
        return

    log.info(f"🤖 Auto-add: {len(to_add_movies)} movies, {len(to_add_series)} series "
             f"(Tautulli + Overseerr)")

    # ── Add movies ─────────────────────────────────────────────────────────────
    for movie in to_add_movies:
        title   = movie["title"]
        year    = movie.get("year")
        arr_id  = movie.get("id")
        tmdb_id = movie.get("tmdb_id")
        imdb_id = movie.get("imdb_id")
        poster  = movie.get("poster", "")
        source  = movie.get("source", "unknown")
        if not poster and tmdb_key and tmdb_id:
            try: poster = await _fetch_tmdb_poster(tmdb_id, title, True, tmdb_key)
            except Exception: pass
        try:
            lm.create_fake_movie(title, year)
            db.fake_library_add({
                "media_type": "movie", "title": title, "year": year,
                "radarr_id": arr_id, "tmdb_id": tmdb_id, "imdb_id": imdb_id,
                "poster_url": poster, "overview": movie.get("overview", ""),
                "status": "movie", "fake_path": None,
            })
            log.info(f"🤖 Auto-added movie [{source}]: {title}")
            await _precache_movie(app, title, year, tmdb_id, imdb_id)
        except Exception as e:
            log.error(f"Auto-add movie '{title}': {e}")
        await asyncio.sleep(1)

    # ── Add series ─────────────────────────────────────────────────────────────
    for series in to_add_series:
        title    = series["title"]
        year     = series.get("year")
        arr_id   = series.get("id")
        tmdb_id  = series.get("tmdb_id")
        tvdb_id  = series.get("tvdb_id")
        imdb_id  = series.get("imdb_id")
        poster   = series.get("poster", "")
        is_ended = series.get("is_ended", False)
        req_seas = series.get("requested_seasons", [])
        sc       = series.get("season_count", 0)
        source   = series.get("source", "unknown")
        if not poster and tmdb_key and tmdb_id:
            try: poster = await _fetch_tmdb_poster(tmdb_id, title, False, tmdb_key)
            except Exception: pass
        try:
            episodes = []
            if arr_id:
                episodes = await lm.get_episodes(
                    arr_id, include_unreleased=inc,
                    requested_seasons=req_seas if req_seas else None
                )
            lm.create_fake_episodes(title, year, [], episodes)
            db.fake_library_add({
                "media_type": "series", "title": title, "year": year,
                "sonarr_id": arr_id, "tvdb_id": tvdb_id, "tmdb_id": tmdb_id, "imdb_id": imdb_id,
                "season_count": sc, "poster_url": poster, "overview": series.get("overview", ""),
                "status": "ended" if is_ended else "continuing", "fake_path": None,
            })
            log.info(f"🤖 Auto-added series [{source}]: {title} ({len(episodes)} eps)")
            await _precache_series(app, title, year, episodes)
        except Exception as e:
            log.error(f"Auto-add series '{title}': {e}")
        await asyncio.sleep(1)


async def _theater_release_loop(app: FastAPI):
    """
    Every 6 hours, retry all movies marked 'awaiting_release'.
    These are movies that only had CAM/Telesync releases when last checked.
    Once a proper copy (web-dl, bluray, etc.) is found, cache it immediately.
    """
    await asyncio.sleep(3600)  # First check 1 hour after startup
    while True:
        try:
            db: CacheDB = app.state.db
            waiting = [
                e for e in db.list_all()
                if e["status"] == "awaiting_release" and e["media_type"] == "movie"
            ]
            if waiting:
                log.info(f"🎭 Checking {len(waiting)} theater-release movies for good copies...")
                s_cfg = db.get_all_settings()
                no_cam = s_cfg.get("no_cam", "true") == "true"
                english_only = s_cfg.get("english_only", "false") == "true"
                for entry in waiting:
                    event = PlayEvent(
                        media_type=MediaType.movie,
                        title=entry["title"],
                        year=entry.get("year"),
                        imdb_id=entry.get("magnet_link"),  # reuse stored imdb_id if any
                    )
                    # Reset to not_found so resolve_and_cache will try again
                    db.update_status(entry["cache_key"], "not_found")
                    try:
                        await resolve_and_cache(app, event)
                        new = db.get(entry["cache_key"])
                        if new and new["status"] == "cached":
                            log.info(f"✅ Good release found: {entry['title']}")
                        elif new and new["status"] == "awaiting_release":
                            log.debug(f"🎭 Still theater-only: {entry['title']}")
                    except Exception as e:
                        log.debug(f"Theater retry {entry['title']}: {e}")
                    await asyncio.sleep(2)
        except Exception as e:
            log.error(f"Theater release loop: {e}")

        interval_hours = 6
        await asyncio.sleep(interval_hours * 3600)


async def resolve_and_cache(app: FastAPI, event: PlayEvent):
    db = app.state.db; alldebrid = app.state.alldebrid; s = app.state.settings
    cache_key = event.cache_key()

    existing = db.get(cache_key)
    if existing and existing["status"] == "cached":
        log.info(f"✅ Cache hit: {cache_key}")
        return

    log.info(f"🔍 Resolving: {cache_key}")
    db.upsert(cache_key, event, status="resolving")

    try:
        # Verify episode numbering
        if event.media_type.value == "episode" and event.season and event.episode:
            tmdb_key = db.get_setting("tmdb_api_key", "")
            cs, cep = await _verify_episode_with_tmdb(
                event.tmdb_id, event.tvdb_id, event.season, event.episode, event.title, tmdb_key)
            if cs != event.season or cep != event.episode:
                event      = event.model_copy(update={"season": cs, "episode": cep})
                cache_key  = event.cache_key()
                existing   = db.get(cache_key)
                if existing and existing["status"] == "cached":
                    log.info(f"✅ Cache hit (corrected): {cache_key}"); return
                db.upsert(cache_key, event, status="resolving")

        # Strategy
        s_cfg = db.get_all_settings()
        if event.media_type.value == "episode":
            lm = app.state.library; is_ended = False
            if lm:
                try:
                    sl = await lm.get_sonarr_series()
                    sm = next((x for x in sl if x["title"].lower() == event.title.lower()), None)
                    if sm: is_ended = sm.get("status","").lower() in ("ended","cancelled","canceled")
                except Exception: pass
            strategy         = s_cfg.get("series_completed_strategy","series_pack") if is_ended else s_cfg.get("series_ongoing_strategy","season_pack")
            preferred_quality = s_cfg.get("series_preferred_quality","1080p")
            fallback_any      = s_cfg.get("series_fallback_any_quality","true") == "true"
        else:
            strategy         = "movie"
            preferred_quality = s_cfg.get("movie_preferred_quality","1080p")
            fallback_any      = s_cfg.get("movie_fallback_any_quality","true") == "true"

        # Check FUSE first
        fuse_match = _find_in_fuse(event.title, event.year, event.season, event.episode)
        if fuse_match:
            torrent_name, filename, fuse_file = fuse_match
            log.info(f"✅ Found in FUSE — symlinking directly")
            fuse_virtual = get_fuse_path(torrent_name, filename, s.FUSE_SYMLINK_ROOT)
            link = _make_plex_symlink(cache_key, event.title, event.year, event.season,
                                      event.episode, event.media_type.value, s.PLEX_ROOT,
                                      fuse_virtual, filename)
            db.update_cached(cache_key, "", fuse_file.get("l",""), torrent_name,
                             _detect_quality(filename), str(link) if link else None)
            return

        # Search TPB
        english_only = s_cfg.get("english_only", "false") == "true"
        no_cam       = s_cfg.get("no_cam",       "true")  == "true"
        log.info(f"🔎 Searching: {event.title!r} strategy={strategy} english_only={english_only} no_cam={no_cam}")
        results = await alldebrid.search_cached(
            title=event.title, media_type=event.media_type.value,
            year=event.year, season=event.season, episode=event.episode,
            imdb_id=event.imdb_id, strategy=strategy,
            preferred_quality=preferred_quality, fallback_any=fallback_any,
            english_only=english_only, no_cam=no_cam,
        )
        if not results:
            # If no_cam is enabled and this is a movie, check whether there are
            # CAM/TS results at all — if yes, the movie is still in theaters.
            # Mark as awaiting_release so we retry automatically when a good copy drops.
            if no_cam and event.media_type.value == "movie":
                raw = await alldebrid.search_cached(
                    title=event.title, media_type=event.media_type.value,
                    year=event.year, season=event.season, episode=event.episode,
                    imdb_id=event.imdb_id, strategy=strategy,
                    preferred_quality="any", fallback_any=True,
                    english_only=False, no_cam=False,  # no filters — see everything
                )
                if raw:
                    log.info(f"🎭 Theater release only: {cache_key} — {raw[0]['name']} (CAM/TS). Will retry when good copy drops.")
                    db.update_status(cache_key, "awaiting_release")
                    return
            log.warning(f"❌ No results: {cache_key}")
            db.update_status(cache_key, "not_found"); return

        best = results[0]
        log.info(f"🎯 {best['name']} cached={best['cached']} q={best.get('quality','?')}")

        result = await alldebrid.add_magnet(best["magnet"])
        if not result:
            db.update_status(cache_key, "unlock_failed"); return

        magnet_id, files = result
        torrent_name = best["name"]

        # Find episode-specific file
        target_file = None
        if event.media_type.value == "episode" and event.season and event.episode:
            se_pat = f"S{event.season:02d}E{event.episode:02d}".upper()
            for f in files:
                if se_pat in f.get("n","").upper(): target_file = f; break
        if not target_file:
            target_file = max(files, key=lambda f: f.get("s",0))

        filename  = target_file.get("n", torrent_name)
        ad_link   = target_file.get("l","")
        file_size = target_file.get("s", 0)

        # Resolve FUSE folder name (handle truncated names)
        stem = Path(filename).stem if filename else torrent_name
        fuse_folder = stem if (stem and torrent_name and stem.startswith(torrent_name.rstrip("-"))) else torrent_name

        if not ad_link:
            log.error(f"No file link for {cache_key}")
            db.update_status(cache_key, "unlock_failed"); return

        log.info(f"📁 {fuse_folder}/{filename} ({file_size} bytes)")

        strm_path = None
        fuse_thread = getattr(app.state, "fuse_thread", None)

        if s.PLEX_ROOT:
            if FUSE_AVAILABLE and fuse_thread:
                register_torrent(fuse_folder, files)
                fuse_virtual = get_fuse_path(fuse_folder, filename, s.FUSE_SYMLINK_ROOT)
                log.info(f"📂 FUSE: {fuse_virtual}")
                link = _make_plex_symlink(cache_key, event.title, event.year, event.season,
                                          event.episode, event.media_type.value, s.PLEX_ROOT,
                                          fuse_virtual, filename)
                strm_path = str(link) if link else None
                log.info(f"🔗 {link} → {fuse_virtual}")
            else:
                p = write_strm(cache_key=cache_key, title=event.title, year=event.year,
                               season=event.season, episode=event.episode,
                               media_type=event.media_type.value,
                               debridarr_base_url=s.DEBRIDARR_BASE_URL, plex_root=s.PLEX_ROOT)
                strm_path = str(p) if p else None

        db.update_cached(cache_key, best["magnet"], ad_link, torrent_name,
                         best.get("quality","unknown"), strm_path)
        log.info(f"✅ Done: {cache_key}")

        if event.media_type.value == "episode" and event.season and event.episode:
            cooldown = int(db.get_setting("precache_cooldown_minutes","1"))
            asyncio.create_task(_precache_next_episodes(app, event, cooldown_minutes=cooldown))

    except Exception as e:
        log.error(f"❌ {cache_key}: {e}", exc_info=True)
        db.update_status(cache_key, "error")


async def _precache_next_episodes(app: FastAPI, event: PlayEvent, count: int = 3, cooldown_minutes: int = 1):
    await asyncio.sleep(5)
    db = app.state.db; lm = app.state.library
    title = event.title; season = event.season; episode = event.episode; year = event.year

    season_size = None
    if lm:
        try:
            sl = await lm.get_sonarr_series()
            series = next((s for s in sl if s["title"].lower() == title.lower()), None)
            if series:
                curr = next((s for s in series.get("seasons",[]) if s.get("season_number") == season), None)
                if curr: season_size = curr.get("episode_count")
        except Exception: pass

    if not season_size: return
    log.info(f"⏭️  Pre-caching '{title}' S{season:02d} ({season_size} eps)")

    all_eps = list(range(1, episode)) + list(range(episode+1, season_size+1))
    for ep in all_eps:
        fake = PlayEvent(media_type=event.media_type, title=title, year=year, season=season, episode=ep)
        ck   = fake.cache_key()
        existing = db.get(ck)
        if existing and existing["status"] in ("cached","resolving"): continue
        try:
            await resolve_and_cache(app, fake)
            await asyncio.sleep(max(3, cooldown_minutes * 60))
        except Exception as e:
            log.debug(f"Pre-cache {ck}: {e}")
