"""
Debridarr - On-the-fly AllDebrid streaming for Plex
"""

import asyncio
import logging
import re
import sys
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path
from typing import Optional

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from app.alldebrid import AllDebridClient
from app.cache import CacheDB
from app.config import settings
from app.library import LibraryManager, _FAKE_MP4
from app.models import MediaType, PlayEvent
from app.proxy import proxy_stream, stream_direct, write_strm
from app.fuse_mount import (
    start_fuse_mount, stop_fuse_mount,
    register_torrent, unregister_torrent, get_fuse_path,
    list_torrents, list_files, get_torrent_file,
    FUSE_AVAILABLE, update_dfs_settings, get_dfs_settings,
)
from app.setup import (
    is_setup_complete, mark_setup_complete,
    load_saved_config, write_env,
    test_alldebrid, test_overseerr, test_plex_root,
)

logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("debridarr")


# ── Helpers ───────────────────────────────────────────────────────────────────

def _schedule_restart(delay: float = 2.0):
    import threading, subprocess, time
    def _do():
        time.sleep(delay)
        log.info("🔄 Restarting...")
        try: subprocess.run(["kill", "-TERM", "1"], check=False)
        except Exception as e: log.error(f"Restart failed: {e}")
    threading.Thread(target=_do, daemon=True).start()


def _init_clients(app: FastAPI):
    import os
    db: CacheDB = getattr(app.state, "db", None)

    def _cfg(key: str, env_key: str = None, default: str = "") -> str:
        """Read from DB first, fall back to env var, then hardcoded default."""
        if db:
            val = db.get_setting(key, "")
            if val:
                return val
        env_key = env_key or key
        return os.environ.get(env_key, default)

    class _S:
        ALLDEBRID_API_KEY  = _cfg("ALLDEBRID_API_KEY")
        OVERSEERR_URL      = _cfg("OVERSEERR_URL")
        OVERSEERR_API_KEY  = _cfg("OVERSEERR_API_KEY")
        PLEX_ROOT          = _cfg("PLEX_ROOT", default="/plex-strm")
        DEBRIDARR_BASE_URL = _cfg("DEBRIDARR_BASE_URL")
        DB_PATH            = os.environ.get("DB_PATH", "/data/debridarr.db")
        PORT               = int(os.environ.get("PORT", "7474"))
        LOG_LEVEL          = os.environ.get("LOG_LEVEL", "INFO")
        FUSE_MOUNT         = os.environ.get("FUSE_MOUNT", "/mnt/alldebrid")
        FUSE_SYMLINK_ROOT  = os.environ.get("FUSE_SYMLINK_ROOT", "/docker/debridarr/mnt-alldebrid")

    s = _S()
    tmdb_key = db.get_setting("tmdb_api_key", "") if db else ""

    app.state.alldebrid = AllDebridClient(s.ALLDEBRID_API_KEY)
    app.state.library   = LibraryManager(
        overseerr_url=s.OVERSEERR_URL,
        overseerr_key=s.OVERSEERR_API_KEY,
        plex_root=s.PLEX_ROOT,
        tmdb_api_key=tmdb_key,
    )
    app.state.settings  = s
    app.state.fuse_thread = getattr(app.state, "fuse_thread", None)
    log.info(f"✅ Clients initialised — overseerr={s.OVERSEERR_URL or 'not set'}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info("🚀 Debridarr starting up...")
    for noisy in ("httpx", "httpcore", "multipart", "uvicorn.access"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    import os
    _data_env = Path("/data/.env")
    if _data_env.exists():
        log.info(f"📂 Loading config from {_data_env}")
        for line in _data_env.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            k, v = k.strip(), v.strip()
            if k and v and not os.environ.get(k):
                os.environ[k] = v

    db = CacheDB(settings.DB_PATH)
    db.init()
    db.bootstrap_from_env()   # seed DB from env vars on first run
    app.state.db = db
    app.state.setup_complete = is_setup_complete()

    # Log clearly which settings are active and where they came from
    ss = db.get_all_settings()
    log.info(f"📦 DB path: {settings.DB_PATH}")
    log.info(f"📦 Settings loaded from DB — "
             f"api_key={'set' if ss.get('ALLDEBRID_API_KEY') else 'NOT SET'}, "
             f"overseerr={'set' if ss.get('OVERSEERR_URL') else 'NOT SET'}, "
             f"plex_root={ss.get('PLEX_ROOT') or 'NOT SET'}, "
             f"precache={ss.get('precache_enabled','true')}")

    # Reset any entries stuck in "resolving" from a previous crashed run
    # Also recover entries that had symlinks (were cached) but got stuck
    stuck = 0
    recovered_symlinks = 0
    with db._connect() as conn:
        result = conn.execute(
            "UPDATE cache SET status='not_found' WHERE status='resolving'"
        )
        stuck = result.rowcount
        # Any not_found entry that still has a valid symlink path → restore to cached
        # These are entries that were cached, then something went wrong on restart
        not_found = conn.execute(
            "SELECT cache_key, strm_path FROM cache WHERE status='not_found' AND strm_path IS NOT NULL"
        ).fetchall()
        for row in not_found:
            strm = row[1]
            if strm and Path(strm).is_symlink():
                conn.execute(
                    "UPDATE cache SET status='cached' WHERE cache_key=?", (row[0],)
                )
                recovered_symlinks += 1
    if stuck:
        log.info(f"🔄 Reset {stuck} stuck 'resolving' entries → 'not_found'")
    if recovered_symlinks:
        log.info(f"🔄 Recovered {recovered_symlinks} entries with existing symlinks → 'cached'")

    _init_clients(app)
    s = app.state.settings
    log.info(f"✅ Debridarr ready — plex_root={s.PLEX_ROOT or 'NOT SET'}")

    # Load DFS settings
    try:
        import json as _json
        saved_dfs = db.get_setting("dfs_settings")
        if saved_dfs:
            update_dfs_settings(_json.loads(saved_dfs))
        else:
            cache_dir = s.FUSE_SYMLINK_ROOT.replace("mnt-alldebrid", "tmp/cache") if s.FUSE_SYMLINK_ROOT else "/docker/debridarr/tmp/cache"
            update_dfs_settings({"cache_dir": cache_dir})
    except Exception as e:
        log.debug(f"DFS settings: {e}")

    try:
        Path(get_dfs_settings()["cache_dir"]).mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

    # Start FUSE
    if FUSE_AVAILABLE:
        _loop = asyncio.get_event_loop()
        _t = start_fuse_mount(s.FUSE_MOUNT, app.state.alldebrid, _loop)
        app.state.fuse_thread = _t
        if _t:
            log.info(f"🗂️  FUSE at {s.FUSE_MOUNT}")
            asyncio.create_task(_load_all_torrents(app))
    else:
        app.state.fuse_thread = None
        log.warning("⚠️  FUSE unavailable")

    asyncio.create_task(_cleanup_loop(app))
    asyncio.create_task(_symlink_health_loop(app))
    asyncio.create_task(_episode_sync_loop(app))
    asyncio.create_task(_auto_add_loop(app))

    yield

    if getattr(app.state, "fuse_thread", None):
        stop_fuse_mount(app.state.settings.FUSE_MOUNT)


app = FastAPI(title="Debridarr", version="0.5.0", lifespan=lifespan)


def _needs_setup(request: Request) -> bool:
    return not getattr(request.app.state, "setup_complete", False)

def _setup_redirect():
    return RedirectResponse("/setup", status_code=302)


# ── Job registry ──────────────────────────────────────────────────────────────
import uuid as _uuid
from collections import deque

_jobs: dict[str, dict] = {}          # job_id → job dict
_jobs_history: deque   = deque(maxlen=200)  # completed jobs (capped)
_resolve_semaphore: Optional[asyncio.Semaphore] = None  # set at startup


def _default_workers() -> int:
    try:
        from app.cache import SEARCH_DEFAULTS
        return 3  # default
    except Exception:
        return 3


def _get_semaphore(app=None) -> asyncio.Semaphore:
    global _resolve_semaphore
    if _resolve_semaphore is None:
        count = _default_workers()
        if app:
            try:
                db = getattr(app.state, "db", None)
                if db:
                    count = int(db.get_setting("resolve_workers", str(count)))
            except Exception:
                pass
        _resolve_semaphore = asyncio.Semaphore(count)
    return _resolve_semaphore


def _reset_semaphore(count: int):
    global _resolve_semaphore
    _resolve_semaphore = asyncio.Semaphore(count)


def _job_start(name: str, job_type: str = "resolve", cancellable: bool = True) -> tuple[str, asyncio.Event]:
    jid   = _uuid.uuid4().hex[:8]
    event = asyncio.Event()
    _jobs[jid] = {
        "id":          jid,
        "name":        name,
        "type":        job_type,
        "status":      "running",
        "started_at":  datetime.utcnow().isoformat(),
        "finished_at": None,
        "error":       None,
        "cancel_event": event,
        "cancellable": cancellable,
    }
    return jid, event


def _job_done(jid: str, error: str = None):
    if jid not in _jobs:
        return
    job = _jobs.pop(jid)
    job["status"]      = "error" if error else "done"
    job["finished_at"] = datetime.utcnow().isoformat()
    job["error"]       = error
    job.pop("cancel_event", None)
    _jobs_history.appendleft(job)


# ── Styles ────────────────────────────────────────────────────────────────────
_CSS = """
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
       background: #0f0f13; color: #e0e0e0; min-height: 100vh; }
header { background: #1a1a24; border-bottom: 1px solid #2a2a3a;
         padding: 14px 28px; display: flex; align-items: center; gap: 16px; }
header h1 { font-size: 1.3rem; color: #fff; }
header .ver { font-size: 0.75rem; background: #f97316; color: #fff;
              border-radius: 4px; padding: 2px 8px; }
nav { display: flex; gap: 4px; margin-left: auto; }
nav a { color: #aaa; text-decoration: none; padding: 6px 14px; border-radius: 6px;
        font-size: 0.85rem; transition: background .15s; }
nav a:hover, nav a.active { background: #2a2a3a; color: #fff; }
main { padding: 28px; max-width: 1400px; margin: 0 auto; }
h2 { font-size: 1.05rem; color: #ccc; margin-bottom: 18px; }
.card-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 14px; }
.card { background: #1a1a24; border: 1px solid #2a2a3a; border-radius: 10px; overflow: hidden; }
.card img { width: 100%; aspect-ratio: 2/3; object-fit: cover; background: #111; display: block; }
.card .no-poster { width: 100%; aspect-ratio: 2/3; background: #1a1a2e;
                   display: flex; align-items: center; justify-content: center;
                   font-size: 2rem; color: #333; }
.card .info { padding: 10px 12px; }
.card .title { font-size: 0.85rem; font-weight: 600; color: #e0e0e0;
               white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.card .meta  { font-size: 0.72rem; color: #555; margin-top: 3px; }
.card .actions { padding: 0 10px 10px; display: flex; gap: 6px; flex-wrap: wrap; }
.btn { display: inline-block; padding: 5px 12px; border-radius: 6px; font-size: 0.78rem;
       font-weight: 600; border: none; cursor: pointer; text-decoration: none; transition: opacity .15s; }
.btn-add  { background: #f97316; color: #fff; }
.btn-add:hover { opacity: .85; }
.btn-rem  { background: #3b1f00; color: #fb923c; }
.btn-sec  { background: #1e3a5f; color: #60a5fa; }
.badge-in { display: inline-block; background: #14532d; color: #4ade80;
            font-size: 0.68rem; font-weight: 700; padding: 2px 7px; border-radius: 20px; }
.badge-grey { display: inline-block; background: #1a1a24; color: #555;
              font-size: 0.68rem; padding: 2px 7px; border-radius: 20px; border: 1px solid #2a2a3a; }
.search-bar { display: flex; gap: 10px; margin-bottom: 20px; }
.search-bar input { flex: 1; background: #1a1a24; border: 1px solid #2a2a3a;
                    border-radius: 8px; padding: 9px 14px; color: #e0e0e0; font-size: 0.9rem; outline: none; }
.search-bar input:focus { border-color: #f97316; }
.tabs { display: flex; gap: 2px; margin-bottom: 20px; }
.tab { padding: 8px 20px; border-radius: 8px; cursor: pointer; font-size: 0.85rem;
       font-weight: 600; border: 1px solid #2a2a3a; background: #1a1a24; color: #888; }
.pg-bar { display:flex;gap:4px;align-items:center;justify-content:center;margin:24px 0 8px;flex-wrap:wrap; }
.pg-btn { display:inline-flex;align-items:center;justify-content:center;min-width:34px;height:34px;
  padding:0 8px;border-radius:6px;border:1px solid #2a2a3a;background:#1a1a24;color:#aaa;
  font-size:0.82rem;font-weight:600;text-decoration:none;cursor:pointer; }
.pg-btn:hover { border-color:#f97316;color:#f97316; }
.pg-cur { background:#f97316;border-color:#f97316;color:#fff;cursor:default; }
.pg-dis { opacity:0.35;cursor:default; }
.tab.active { background: #f97316; color: #fff; border-color: #f97316; }
.empty { text-align: center; padding: 60px; color: #444; font-size: 0.9rem; }
.toast { position: fixed; bottom: 24px; right: 24px; background: #1a1a24;
         border: 1px solid #2a2a3a; border-radius: 10px; padding: 12px 20px;
         font-size: 0.85rem; opacity: 0; transition: opacity .3s; z-index: 999; }
.toast.show { opacity: 1; }
table { width: 100%; border-collapse: collapse; background: #1a1a24;
        border-radius: 10px; overflow: hidden; }
th { text-align: left; padding: 11px 14px; font-size: 0.72rem; text-transform: uppercase;
     color: #555; border-bottom: 1px solid #2a2a3a; }
td { padding: 10px 14px; border-bottom: 1px solid #1e1e2e; font-size: 0.85rem; }
tr:last-child td { border-bottom: none; }
.pill { padding: 2px 9px; border-radius: 20px; font-size: 0.72rem; font-weight: 600; }
.pill-ok   { background: #14532d; color: #4ade80; }
.pill-res  { background: #1e3a5f; color: #60a5fa; }
.pill-err  { background: #3b0000; color: #f87171; }
.pill-pend { background: #2d2d00; color: #facc15; }
.pill-nf   { background: #3b1f00; color: #fb923c; }
"""

_NAV = lambda active: f"""
<nav>
  <a href="/library"  class="{'active' if active=='library'  else ''}">📚 Add to Library</a>
  <a href="/import"   class="{'active' if active=='import'   else ''}">⬇️ Import</a>
  <a href="/streams"  class="{'active' if active=='streams'  else ''}">⚡ Streams</a>
  <a href="/jobs"     class="{'active' if active=='jobs'     else ''}">⚙️ Jobs</a>
  <a href="/settings" class="{'active' if active=='settings' else ''}">⚙️ Settings</a>
</nav>"""

_TOAST_JS = """
function toast(msg, ok=true) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.style.borderColor = ok ? '#4ade80' : '#f87171';
  t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 3500);
}"""

def _pagination(base_url: str, params: dict, current: int, total: int) -> str:
    """Render a pagination bar. Preserves existing query params."""
    if total <= 1:
        return ""
    def url(p):
        q = "&".join(f"{k}={v}" for k, v in params.items() if v) + f"&page={p}"
        return f"{base_url}?{q}"

    buttons = []
    # Prev
    if current > 1:
        buttons.append(f'<a class="pg-btn" href="{url(current-1)}">‹</a>')
    else:
        buttons.append('<span class="pg-btn pg-dis">‹</span>')

    # Page numbers — show up to 7, with ellipsis
    pages = []
    if total <= 7:
        pages = list(range(1, total+1))
    else:
        pages = [1]
        if current > 3:  pages.append("…")
        for p in range(max(2,current-1), min(total, current+2)):
            pages.append(p)
        if current < total - 2: pages.append("…")
        if total not in pages:  pages.append(total)

    for p in pages:
        if p == "…":
            buttons.append('<span class="pg-btn pg-dis">…</span>')
        elif p == current:
            buttons.append(f'<span class="pg-btn pg-cur">{p}</span>')
        else:
            buttons.append(f'<a class="pg-btn" href="{url(p)}">{p}</a>')

    # Next
    if current < total:
        buttons.append(f'<a class="pg-btn" href="{url(current+1)}">›</a>')
    else:
        buttons.append('<span class="pg-btn pg-dis">›</span>')

    inner = "".join(buttons)
    return f'<div class="pg-bar">{inner}</div>'


def _page(title, nav_active, body, extra=""):
    return HTMLResponse(f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>{title} — Debridarr</title>
  <style>{_CSS}</style>
</head>
<body>
  <header>
    <h1>🎬 Debridarr</h1><span class="ver">v0.5.0</span>
    {_NAV(nav_active)}
  </header>
  <main>{body}</main>
  <div id="toast" class="toast"></div>
  <script>{_TOAST_JS}</script>
  {extra}
</body>
</html>""")


# ── Setup ─────────────────────────────────────────────────────────────────────
_SETUP_CSS = _CSS + """
.wizard { max-width: 620px; margin: 60px auto; }
.wizard-card { background: #1a1a24; border: 1px solid #2a2a3a; border-radius: 14px; padding: 36px; }
.wizard h2 { font-size: 1.4rem; color: #fff; margin-bottom: 6px; }
.wizard .sub { color: #666; font-size: 0.88rem; margin-bottom: 28px; line-height: 1.5; }
.steps { display: flex; gap: 0; margin-bottom: 32px; }
.step { flex: 1; text-align: center; font-size: 0.7rem; color: #444; padding-bottom: 8px;
        border-bottom: 2px solid #2a2a3a; }
.step.done   { color: #4ade80; border-color: #4ade80; }
.step.active { color: #f97316; border-color: #f97316; font-weight: 700; }
.field { margin-bottom: 20px; }
.field label { display: block; font-size: 0.8rem; color: #888; margin-bottom: 6px; font-weight: 600; }
.field input { width: 100%; background: #0f0f13; border: 1px solid #2a2a3a; border-radius: 8px;
               padding: 10px 14px; color: #e0e0e0; font-size: 0.9rem; outline: none; font-family: monospace; }
.field input:focus { border-color: #f97316; }
.field .hint { font-size: 0.75rem; color: #555; margin-top: 5px; line-height: 1.4; }
.field .hint a { color: #f97316; }
.test-result { margin-top: 10px; padding: 8px 12px; border-radius: 6px; font-size: 0.82rem; display: none; }
.test-result.ok      { background: #14532d; color: #4ade80; display: block; }
.test-result.err     { background: #3b0000; color: #f87171; display: block; }
.test-result.testing { background: #1e1e2e; color: #aaa; display: block; }
.row { display: flex; gap: 10px; }
.row .field { flex: 1; }
.actions { display: flex; gap: 10px; margin-top: 28px; justify-content: flex-end; }
.btn-primary { background: #f97316; color: #fff; padding: 10px 24px; border-radius: 8px;
               font-size: 0.9rem; font-weight: 600; border: none; cursor: pointer; }
.btn-primary:hover { opacity: .85; }
.btn-primary:disabled { opacity: .4; cursor: not-allowed; }
.btn-ghost { background: transparent; color: #666; padding: 10px 16px; border-radius: 8px;
             font-size: 0.9rem; border: 1px solid #2a2a3a; cursor: pointer; }
.btn-ghost:hover { color: #ccc; border-color: #444; }
.confirm-row { display: flex; justify-content: space-between; padding: 10px 0;
               border-bottom: 1px solid #1e1e2e; font-size: 0.875rem; }
.confirm-row:last-child { border-bottom: none; }
.confirm-row .lbl { color: #666; }
.confirm-row .val { color: #e0e0e0; font-family: monospace; font-size: 0.82rem; }
"""

def _setup_page(body, step):
    step_names = ["Welcome", "AllDebrid", "Overseerr", "Plex", "Confirm"]
    step_keys  = ["welcome", "alldebrid", "overseerr", "plex", "confirm"]
    idx = step_keys.index(step) if step in step_keys else 0
    steps_html = "".join(
        f'<div class="step {"done" if i < idx else "active" if i == idx else ""}">{n}</div>'
        for i, n in enumerate(step_names)
    )
    return HTMLResponse(f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Debridarr Setup</title>
  <style>{_SETUP_CSS}</style>
</head>
<body>
  <header>
    <h1>🎬 Debridarr</h1><span class="ver">v0.5.0</span>
    <span style="margin-left:auto;color:#555;font-size:0.8rem">First-run setup</span>
  </header>
  <div class="wizard">
    <div class="steps">{steps_html}</div>
    <div class="wizard-card">{body}</div>
  </div>
  <div id="toast" class="toast"></div>
  <script>{_TOAST_JS}</script>
</body>
</html>""")


@app.get("/setup", response_class=HTMLResponse)
async def setup_get(request: Request, step: str = "welcome"):
    cfg = load_saved_config()

    if step == "welcome":
        return _setup_page("""
        <div style="font-size:4rem;text-align:center;margin-bottom:20px">🎬</div>
        <h2>Welcome to Debridarr</h2>
        <p class="sub">Connect Debridarr to AllDebrid and Overseerr. Takes ~2 minutes.</p>
        <div class="actions">
          <a href="/setup?step=alldebrid" class="btn-primary" style="text-decoration:none;display:inline-block;padding:10px 24px">Get Started →</a>
        </div>""", "welcome")

    if step == "alldebrid":
        val = cfg.get("ALLDEBRID_API_KEY", "")
        return _setup_page(f"""
        <h2>AllDebrid</h2>
        <p class="sub">Debridarr uses AllDebrid to stream cached torrents instantly.</p>
        <div class="field">
          <label>API Key</label>
          <input id="api_key" type="password" value="{val}" placeholder="Paste your AllDebrid API key">
          <div class="hint">Get yours at <a href="https://alldebrid.com/apikeys" target="_blank">alldebrid.com/apikeys</a></div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="actions">
          <a href="/setup?step=welcome" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="btn" onclick="go()">Test & Continue →</button>
        </div>
        <script>
        async function go() {{
          const key = document.getElementById('api_key').value.trim();
          const res = document.getElementById('test-result');
          const btn = document.getElementById('btn');
          if (!key) {{ res.className='test-result err'; res.textContent='API key required'; return; }}
          res.className='test-result testing'; res.textContent='Testing...'; btn.disabled=true;
          const r = await fetch('/setup/test', {{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{step:'alldebrid',api_key:key}})}});
          const d = await r.json(); btn.disabled=false;
          if (d.ok) {{ res.className='test-result ok'; res.textContent='✅ '+d.message;
            setTimeout(()=>window.location='/setup?step=overseerr&akey='+encodeURIComponent(key),800); }}
          else {{ res.className='test-result err'; res.textContent='❌ '+d.message; }}
        }}
        document.getElementById('api_key').addEventListener('keydown',e=>{{if(e.key==='Enter')go();}});
        </script>""", "alldebrid")

    if step == "overseerr":
        url_val = cfg.get("OVERSEERR_URL", "http://192.168.1.x:5055")
        key_val = cfg.get("OVERSEERR_API_KEY", "")
        akey    = request.query_params.get("akey", cfg.get("ALLDEBRID_API_KEY", ""))
        return _setup_page(f"""
        <h2>Overseerr</h2>
        <p class="sub">Connect to your Overseerr instance to browse your request library.</p>
        <div class="field">
          <label>Overseerr URL</label>
          <input id="url" type="text" value="{url_val}" placeholder="http://192.168.1.x:5055">
        </div>
        <div class="field">
          <label>API Key</label>
          <input id="key" type="password" value="{key_val}" placeholder="Overseerr API key">
          <div class="hint">Overseerr → Settings → General → API Key</div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="actions">
          <a href="/setup?step=alldebrid" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="btn" onclick="go()">Test & Continue →</button>
        </div>
        <input type="hidden" id="akey" value="{akey}">
        <script>
        async function go() {{
          const url=document.getElementById('url').value.trim();
          const key=document.getElementById('key').value.trim();
          const akey=document.getElementById('akey').value;
          const res=document.getElementById('test-result'); const btn=document.getElementById('btn');
          res.className='test-result testing'; res.textContent='Testing...'; btn.disabled=true;
          const r=await fetch('/setup/test',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{step:'overseerr',url,api_key:key}})}});
          const d=await r.json(); btn.disabled=false;
          if(d.ok){{res.className='test-result ok';res.textContent='✅ '+d.message;
            setTimeout(()=>window.location='/setup?step=plex&akey='+encodeURIComponent(akey)+'&ourl='+encodeURIComponent(url)+'&okey='+encodeURIComponent(key),800);}}
          else{{res.className='test-result err';res.textContent='❌ '+d.message;}}
        }}
        </script>""", "overseerr")

    if step == "plex":
        qs = dict(request.query_params)
        hidden = "".join(f'<input type="hidden" id="{k}" value="{v}">' for k, v in qs.items() if k != "step")
        tz_val   = cfg.get("TZ", "America/Edmonton")
        puid_val = cfg.get("PUID", "1000")
        pgid_val = cfg.get("PGID", "1000")
        base_url = cfg.get("DEBRIDARR_BASE_URL", "http://192.168.1.x:7474")
        return _setup_page(f"""
        <h2>Plex Integration</h2>
        <p class="sub">Where to write library files and how Plex reaches Debridarr.</p>
        <div class="field">
          <label>Plex Library Path (inside container)</label>
          <input id="plex_root" type="text" value="/plex-strm" placeholder="/plex-strm">
          <div class="hint">Must be bind-mounted into both Debridarr and Plex.</div>
          <div id="test-result" class="test-result"></div>
        </div>
        <div class="field">
          <label>Debridarr Base URL (as seen by Plex)</label>
          <input id="base_url" type="text" value="{base_url}" placeholder="http://192.168.1.x:7474">
        </div>
        <div class="row">
          <div class="field"><label>Timezone</label><input id="tz" value="{tz_val}"></div>
          <div class="field"><label>PUID</label><input id="puid" value="{puid_val}"></div>
          <div class="field"><label>PGID</label><input id="pgid" value="{pgid_val}"></div>
        </div>
        {hidden}
        <div class="actions">
          <a href="/setup?step=overseerr" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
          <button class="btn-primary" id="btn" onclick="go()">Test & Continue →</button>
        </div>
        <script>
        async function go(){{
          const plex_root=document.getElementById('plex_root').value.trim();
          const res=document.getElementById('test-result'); const btn=document.getElementById('btn');
          res.className='test-result testing'; res.textContent='Checking...'; btn.disabled=true;
          const r=await fetch('/setup/test',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{step:'plex',plex_root}})}});
          const d=await r.json(); btn.disabled=false;
          if(d.ok){{res.className='test-result ok';res.textContent='✅ '+d.message;
            const prev={{}};
            document.querySelectorAll('input[type=hidden]').forEach(i=>prev[i.id]=i.value);
            const p=new URLSearchParams({{...prev,step:'confirm',plex_root,
              base_url:document.getElementById('base_url').value.trim(),
              tz:document.getElementById('tz').value.trim(),
              puid:document.getElementById('puid').value.trim(),
              pgid:document.getElementById('pgid').value.trim()}});
            setTimeout(()=>window.location='/setup?'+p.toString(),800);}}
          else{{res.className='test-result err';res.textContent='❌ '+d.message;}}
        }}
        </script>""", "plex")

    if step == "confirm":
        qs = dict(request.query_params)
        def row(lbl, key, mask=False):
            val = qs.get(key, "—")
            display = ("•" * 8 + val[-4:]) if mask and val and val != "—" else val
            return f'<div class="confirm-row"><span class="lbl">{lbl}</span><span class="val">{display}</span></div>'
        hidden = "".join(f'<input type="hidden" name="{k}" value="{v}">' for k, v in qs.items() if k != "step")
        return _setup_page(f"""
        <h2>Confirm & Save</h2>
        <p class="sub">Review settings and click Save to finish.</p>
        <div style="margin-bottom:24px">
          {row("AllDebrid API Key", "akey", mask=True)}
          {row("Overseerr URL", "ourl")}
          {row("Overseerr API Key", "okey", mask=True)}
          {row("Plex Library Path", "plex_root")}
          {row("Debridarr Base URL", "base_url")}
          {row("Timezone", "tz")}
        </div>
        <form method="POST" action="/setup/save">
          {hidden}
          <div class="actions">
            <a href="/setup?step=plex" class="btn-ghost" style="text-decoration:none;display:inline-block;padding:10px 16px">← Back</a>
            <button type="submit" class="btn-primary">💾 Save & Finish</button>
          </div>
        </form>""", "confirm")

    return RedirectResponse("/setup")


@app.post("/setup/test")
async def setup_test(request: Request):
    body = await request.json()
    step = body.get("step")
    if step == "alldebrid":  ok, msg = await test_alldebrid(body.get("api_key", ""))
    elif step == "overseerr": ok, msg = await test_overseerr(body.get("url", ""), body.get("api_key", ""))
    elif step == "plex":      ok, msg = await test_plex_root(body.get("plex_root", ""))
    else:                     ok, msg = False, "Unknown step"
    return JSONResponse({"ok": ok, "message": msg})


@app.post("/setup/save")
async def setup_save(request: Request):
    form = dict(await request.form())
    config = {
        "ALLDEBRID_API_KEY":  form.get("akey", ""),
        "OVERSEERR_URL":      form.get("ourl", ""),
        "OVERSEERR_API_KEY":  form.get("okey", ""),
        "DEBRIDARR_BASE_URL": form.get("base_url", ""),
        "TZ":                 form.get("tz", "America/Edmonton"),
        "PUID":               form.get("puid", "1000"),
        "PGID":               form.get("pgid", "1000"),
    }
    write_env(config)
    import os
    for k, v in config.items(): os.environ[k] = v
    os.environ["PLEX_ROOT"] = form.get("plex_root", "/plex-strm")
    mark_setup_complete()
    request.app.state.setup_complete = True
    _init_clients(request.app)
    log.info("✅ Setup complete — restarting...")
    _schedule_restart(delay=2.0)
    return HTMLResponse(f"""<!DOCTYPE html><html><head><meta charset="UTF-8">
<meta http-equiv="refresh" content="6;url=/library">
<style>{_SETUP_CSS}</style></head><body>
<header><h1>🎬 Debridarr</h1><span class="ver">v0.5.0</span></header>
<div class="wizard"><div class="wizard-card" style="text-align:center;padding:48px">
<div style="font-size:3rem;margin-bottom:16px">🎉</div>
<h2 style="color:#4ade80;margin-bottom:12px">Setup Complete!</h2>
<p style="color:#888;margin-bottom:24px">Redirecting to library...</p>
<a href="/library" style="color:#f97316">Click here if not redirected</a>
</div></div></body></html>""")


# ── / redirect ────────────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    if _needs_setup(request): return _setup_redirect()
    return RedirectResponse("/library")


# ── /jobs ─────────────────────────────────────────────────────────────────────
@app.get("/jobs", response_class=HTMLResponse)
async def jobs_page(request: Request):
    if _needs_setup(request): return _setup_redirect()
    db: CacheDB = request.app.state.db
    workers = int(db.get_setting("resolve_workers", "3"))

    def fmt_duration(start_iso: str) -> str:
        try:
            secs = int((datetime.utcnow() - datetime.fromisoformat(start_iso)).total_seconds())
            if secs < 60:  return f"{secs}s"
            if secs < 3600: return f"{secs//60}m {secs%60}s"
            return f"{secs//3600}h {(secs%3600)//60}m"
        except Exception:
            return "?"

    def job_row(j: dict, running: bool) -> str:
        dur    = fmt_duration(j["started_at"]) if running else fmt_duration(j.get("finished_at", j["started_at"]))
        status = j.get("status", "running")
        dot    = {"running": "#22c55e", "done": "#555", "error": "#ef4444", "cancelled": "#f97316"}.get(status, "#888")
        cancel = f'<button class="btn btn-rem" style="padding:3px 10px;font-size:0.72rem" onclick="cancelJob(\'{j["id"]}\')">✕ Cancel</button>' if running and j.get("cancellable") else ""
        err    = f'<span style="color:#f87171;font-size:0.72rem">{j.get("error","")}</span>' if j.get("error") else ""
        return f"""<tr>
          <td style="font-family:monospace;font-size:0.75rem;color:#555">{j["id"]}</td>
          <td><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:{dot};margin-right:6px"></span>{j["name"]}</td>
          <td style="color:#888;font-size:0.78rem">{j["type"]}</td>
          <td style="color:#888;font-size:0.78rem">{"⏱ "+dur if running else dur}</td>
          <td>{cancel}{err}</td>
        </tr>"""

    running_rows  = "".join(job_row(j, True)  for j in _jobs.values())
    history_rows  = "".join(job_row(j, False) for j in list(_jobs_history)[:50])

    running_table = f"""<table><thead><tr>
      <th>ID</th><th>Job</th><th>Type</th><th>Running</th><th></th>
    </tr></thead><tbody>{running_rows}</tbody></table>""" if running_rows else \
    '<div class="empty">No jobs running.</div>'

    history_table = f"""<table><thead><tr>
      <th>ID</th><th>Job</th><th>Type</th><th>Duration</th><th>Status</th>
    </tr></thead><tbody>{history_rows}</tbody></table>""" if history_rows else \
    '<div class="empty">No completed jobs yet.</div>'

    body = f"""
    <h2 style="margin-bottom:20px">⚙️ Jobs</h2>

    <div class="s-sect">
      <div class="s-title">Worker Settings</div>
      <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap">
        <div class="field" style="max-width:220px;margin:0">
          <label>Max concurrent resolve workers</label>
          <input id="worker-count" type="number" min="1" max="10" value="{workers}"
                 style="background:#0f0f13;border:1px solid #2a2a3a;border-radius:7px;padding:8px 12px;color:#e0e0e0;font-size:0.875rem;width:100%">
          <div class="hint">How many resolve_and_cache tasks run in parallel. Higher = faster but more AllDebrid API load.</div>
        </div>
        <button class="btn btn-add" style="padding:8px 20px;margin-top:14px" onclick="saveWorkers()">Save</button>
        <div id="worker-result" class="test-result" style="margin-top:14px;flex:1"></div>
      </div>
    </div>

    <div class="s-sect">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
        <div class="s-title" style="margin:0">Running Jobs ({len(_jobs)})</div>
        <div style="display:flex;gap:8px">
          <button class="btn btn-sec" style="padding:5px 12px;font-size:0.8rem" onclick="location.reload()">🔄 Refresh</button>
          <button class="btn btn-rem" style="padding:5px 12px;font-size:0.8rem" onclick="cancelAll()">✕ Cancel All</button>
        </div>
      </div>
      {running_table}
    </div>

    <div class="s-sect">
      <div class="s-title">Recent Jobs (last {min(len(_jobs_history),50)})</div>
      {history_table}
    </div>"""

    extra = """<script>
async function cancelJob(id) {
  const r = await fetch('/api/jobs/'+id+'/cancel', {method:'POST'});
  const d = await r.json();
  toast(r.ok ? '🚫 Job cancelled' : '❌ '+(d.detail||'Error'), r.ok);
  setTimeout(()=>location.reload(), 800);
}
async function cancelAll() {
  if (!confirm('Cancel all running jobs?')) return;
  const r = await fetch('/api/jobs/cancel-all', {method:'POST'});
  const d = await r.json();
  toast('🚫 Cancelled '+d.cancelled+' jobs');
  setTimeout(()=>location.reload(), 800);
}
async function saveWorkers() {
  const n   = parseInt(document.getElementById('worker-count').value);
  const res = document.getElementById('worker-result');
  if (!n || n < 1 || n > 10) { res.className='test-result err'; res.style.display='block'; res.textContent='❌ Must be 1–10'; return; }
  const r = await fetch('/api/jobs/workers', {method:'POST',
    headers:{'Content-Type':'application/json'}, body:JSON.stringify({count:n})});
  const d = await r.json();
  res.className = 'test-result '+(r.ok?'ok':'err');
  res.style.display = 'block';
  res.textContent = r.ok ? '✅ Workers set to '+d.workers+' (takes effect immediately)' : '❌ '+(d.detail||'Error');
}
// Auto-refresh every 3s when jobs are running
if (document.querySelector('tbody tr')) {
  setTimeout(()=>location.reload(), 3000);
}
</script>"""
    return _page("Jobs", "jobs", body, extra)


@app.post("/api/jobs/{job_id}/cancel")
async def api_job_cancel(job_id: str):
    job = _jobs.get(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    if not job.get("cancellable"):
        raise HTTPException(400, "Job is not cancellable")
    job["cancel_event"].set()
    job["status"] = "cancelling"
    return {"status": "ok", "message": f"Cancelling job {job_id}"}


@app.post("/api/jobs/cancel-all")
async def api_jobs_cancel_all():
    count = 0
    for job in list(_jobs.values()):
        if job.get("cancellable") and not job["cancel_event"].is_set():
            job["cancel_event"].set()
            job["status"] = "cancelling"
            count += 1
    return {"status": "ok", "cancelled": count}


@app.post("/api/jobs/workers")
async def api_jobs_workers(request: Request):
    body    = await request.json()
    count   = int(body.get("count", 3))
    count   = max(1, min(10, count))
    db: CacheDB = request.app.state.db
    db.set_setting("resolve_workers", str(count))
    _reset_semaphore(count)
    log.info(f"⚙️  Resolve workers set to {count}")
    return {"status": "ok", "workers": count}


@app.get("/api/jobs")
async def api_jobs_list():
    def serialise(j: dict) -> dict:
        return {k: v for k, v in j.items() if k != "cancel_event"}
    return {
        "running":  [serialise(j) for j in _jobs.values()],
        "history":  [serialise(j) for j in list(_jobs_history)[:50]],
        "workers":  _resolve_semaphore._value if _resolve_semaphore else 3,
    }


# ── /import — Sonarr / Radarr direct import ───────────────────────────────────
@app.get("/import", response_class=HTMLResponse)
async def import_page(request: Request, tab: str = "radarr", q: str = "", page: int = 1):
    if _needs_setup(request): return _setup_redirect()
    lm: LibraryManager = request.app.state.library
    db: CacheDB = request.app.state.db

    radarr_url = db.get_setting("RADARR_URL", "")
    radarr_key = db.get_setting("RADARR_API_KEY", "")
    sonarr_url = db.get_setting("SONARR_URL", "")
    sonarr_key = db.get_setting("SONARR_API_KEY", "")

    already_added = {(r["media_type"], r["title"].lower()) for r in db.fake_library_list()}

    if tab == "radarr":
        items = await lm.get_radarr_direct(radarr_url, radarr_key)
        source_name = "Radarr"
        not_configured = not radarr_url or not radarr_key
    else:
        items = await lm.get_sonarr_direct(sonarr_url, sonarr_key)
        source_name = "Sonarr"
        not_configured = not sonarr_url or not sonarr_key

    if q:
        ql = q.lower()
        items = [i for i in items if ql in i["title"].lower()]

    mtype = "movie" if tab == "radarr" else "series"

    IMP_PER_PAGE   = 24
    total_imp      = len(items)
    total_imp_pages = max(1, (total_imp + IMP_PER_PAGE - 1) // IMP_PER_PAGE)
    page           = max(1, min(page, total_imp_pages))
    not_added      = [i for i in items if (mtype, i["title"].lower()) not in already_added]
    items          = items[(page-1)*IMP_PER_PAGE : page*IMP_PER_PAGE]
    not_added_page = [i for i in items if (mtype, i["title"].lower()) not in already_added]

    cards = ""
    for item in items:
        in_lib = (mtype, item["title"].lower()) in already_added
        poster = item.get("poster", "")
        year   = item.get("year", "")
        safe   = item["title"].replace("'", "&#39;").replace('"', "&quot;")
        img    = f'<img src="{poster}" onerror="this.style.display=\'none\'" loading="lazy">' if poster \
                 else f'<div class="no-poster">{"".join(w[0].upper() for w in item["title"].split()[:2])}</div>'

        if tab == "radarr":
            meta = str(year or "")
            has_file = item.get("has_file", False)
            meta += ' <span style="color:#22c55e;font-size:0.7rem">●&nbsp;Downloaded</span>' if has_file else \
                    ' <span style="color:#888;font-size:0.7rem">○&nbsp;Not downloaded</span>'
        else:
            sc   = item.get("season_count", 0)
            meta = f"{year or ''} · {sc} season{'s' if sc!=1 else ''}"
            st   = item.get("status", "")
            col  = "#ef4444" if item.get("is_ended") else "#22c55e"
            meta += f' <span style="color:{col};font-size:0.7rem">({st})</span>'

        sc = item.get("season_count", 0)
        if in_lib:
            action = f'<span class="badge-in">✓ In Library</span>'
        else:
            action = (
                f'<button class="btn btn-add" style="padding:4px 10px;font-size:0.78rem"'
                f' data-mtype="{mtype}" data-id="{item.get("id","")}"'
                f' data-title="{safe}" data-year="{year or ""}" data-sc="{sc}"'
                f' onclick="addCard(this)">+ Add</button>'
            )

        cards += f"""<div class="card" data-title="{safe.lower()}" data-in-lib="{'1' if in_lib else '0'}">
          {img}
          <div class="info"><div class="title" title="{safe}">{item["title"]}</div>
          <div class="meta">{meta}</div></div>
          <div class="actions">{action}</div>
        </div>"""

    if not cards:
        if not_configured:
            cards = f'<div class="empty">Configure {source_name} URL and API key in <a href="/settings" style="color:#f97316">Settings</a>.</div>'
        else:
            cards = f'<div class="empty">{"No results for &quot;"+q+"&quot;" if q else "Nothing found in "+source_name}</div>'

    radarr_count = len(await lm.get_radarr_direct(radarr_url, radarr_key)) if radarr_url and radarr_key else 0
    sonarr_count = len(await lm.get_sonarr_direct(sonarr_url, sonarr_key)) if sonarr_url and sonarr_key else 0
    not_added_count = len(not_added)

    body = f"""
    <h2>Import from Sonarr / Radarr</h2>
    <div class="tabs">
      <div class="tab {'active' if tab=='radarr' else ''}" onclick="switchTab('radarr')">🎬 Radarr ({radarr_count})</div>
      <div class="tab {'active' if tab=='sonarr' else ''}" onclick="switchTab('sonarr')">📺 Sonarr ({sonarr_count})</div>
    </div>
    <div class="search-bar">
      <input id="q" type="text" placeholder="Search {source_name}..." value="{q}" oninput="filterCards()">
      <button class="btn btn-sec" onclick="clearSearch()">Clear</button>
      <button class="btn btn-sec" onclick="refreshSource()">🔄 Refresh</button>
      {f'<button class="btn btn-add" onclick="addAll()" style="margin-left:auto">+ Add All ({len(not_added_page)})</button>' if not_added_page else ''}
    </div>
    <div id="card-grid" class="card-grid">{cards}</div>
    {_pagination("/import", {"tab": tab, "q": q}, page, total_imp_pages)}
    <div id="add-progress" style="display:none;margin-top:16px;padding:12px;background:#1a1a24;border-radius:8px;font-size:0.85rem"></div>"""

    extra = f"""<script>
const CURRENT_TAB = '{tab}';

function switchTab(t) {{
  window.location.href = '/import?tab=' + t;
}}

function filterCards() {{
  const q = document.getElementById('q').value.toLowerCase();
  document.querySelectorAll('#card-grid .card').forEach(c => {{
    c.style.display = q === '' || c.dataset.title.includes(q) ? '' : 'none';
  }});
}}

function clearSearch() {{
  document.getElementById('q').value = '';
  filterCards();
}}

async function refreshSource() {{
  window.location.href = '/import?tab=' + CURRENT_TAB + '&_=' + Date.now();
}}

async function addCard(btn) {{
  btn.disabled = true;
  btn.textContent = '⏳';
  const type  = btn.dataset.mtype;
  const id    = parseInt(btn.dataset.id) || null;
  const title = btn.dataset.title.replace(/&#39;/g,"'").replace(/&quot;/g,'"');
  const year  = btn.dataset.year ? parseInt(btn.dataset.year) : null;
  const sc    = parseInt(btn.dataset.sc) || 0;
  const r = await fetch('/api/library/add', {{method:'POST',
    headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{media_type:type, arr_id:id, title, year, season_count:sc}})}});
  const d = await r.json();
  if (r.ok && d.status !== 'skipped') {{
    btn.textContent = '✓ Added';
    btn.className = 'btn';
    btn.style.background = '#14532d';
    btn.disabled = true;
    btn.closest('.card').dataset.inLib = '1';
    toast('✅ ' + title + ' added');
  }} else if (d.status === 'skipped') {{
    btn.textContent = '🎬 Not out yet';
    btn.style.background = '#78350f';
    btn.style.color = '#fcd34d';
    btn.disabled = true;
    toast('⏭️ ' + title + ' is not released yet', false);
  }} else {{
    btn.textContent = '❌ Error';
    btn.disabled = false;
    toast('❌ ' + (d.detail || d.message || 'Error'), false);
  }}
}}

async function addAll() {{
  const cards = [...document.querySelectorAll('#card-grid .card')].filter(c => c.dataset.inLib === '0' && c.style.display !== 'none');
  const prog = document.getElementById('add-progress');
  prog.style.display = 'block';
  let done = 0;
  for (const card of cards) {{
    const btn = card.querySelector('.btn-add');
    if (!btn || btn.disabled) continue;
    prog.textContent = `Adding ${{done + 1}} / ${{cards.length}}: ${{card.dataset.title}}...`;
    await addCard(btn);
    done++;
    await new Promise(r => setTimeout(r, 400));
  }}
  prog.textContent = `✅ Done — added ${{done}} item(s)`;
}}
</script>"""

    return _page("Import", "import", body, extra)


@app.post("/api/import/refresh")
async def api_import_refresh(request: Request):
    lm: LibraryManager = request.app.state.library
    lm.invalidate_direct_cache()
    return {"status": "ok"}


# ── /library — browse Overseerr ───────────────────────────────────────────────
@app.get("/library", response_class=HTMLResponse)
async def library_browse(request: Request, tab: str = "movies", q: str = "", page: int = 1):
    if _needs_setup(request): return _setup_redirect()
    lm: LibraryManager = request.app.state.library
    db: CacheDB = request.app.state.db

    PER_PAGE = 24
    already_added = {(r["media_type"], r["title"].lower()) for r in db.fake_library_list()}

    if tab == "movies":
        all_items = await lm.get_radarr_movies()
    else:
        all_items = await lm.get_sonarr_series()

    if q:
        ql = q.lower()
        all_items = [i for i in all_items if ql in i["title"].lower()]

    total_items = len(all_items)
    total_pages = max(1, (total_items + PER_PAGE - 1) // PER_PAGE)
    page        = max(1, min(page, total_pages))
    items       = all_items[(page-1)*PER_PAGE : page*PER_PAGE]

    cards = ""
    for item in items:
        mtype = "movie" if tab == "movies" else "series"
        year  = item.get("year")
        in_lib = (mtype, item["title"].lower()) in already_added
        poster = item.get("poster", "")
        img = f'<img src="{poster}" onerror="this.style.display=\'none\'" loading="lazy">' if poster else f'<div class="no-poster">{item["title"][:1]}</div>'
        safe = item["title"].replace("'", "\\'").replace('"', '&quot;')
        sc  = item.get("season_count", 0)
        meta = str(year or "")
        if tab != "movies" and sc:
            meta += f" · {sc} season{'s' if sc != 1 else ''}"
        badge = '<div class="actions"><span class="badge-in">✓ In Library</span>' if in_lib else ""

        if in_lib:
            t = item["title"].replace('"', '&quot;')
            action = f'<button class="btn btn-rem" data-mtype="{mtype}" data-title="{t}" data-year="{year or ""}" onclick="removeCard(this)">Remove</button>'
        else:
            t = item["title"].replace('"', '&quot;')
            action = f'<button class="btn btn-add" data-mtype="{mtype}" data-id="{item.get("id","")}" data-title="{t}" data-year="{year or ""}" data-sc="{sc}" onclick="addCard(this)">+ Add</button>'

        cards += f"""<div class="card">
          {img}
          <div class="info">
            <div class="title" title="{item['title']}">{item['title']}</div>
            <div class="meta">{meta}</div>
          </div>
          <div class="actions">{action}</div>
        </div>"""

    if not cards:
        cards = f'<div class="empty">{"No results for &quot;"+q+"&quot;" if q else "Nothing found — check Overseerr settings"}</div>'

    movie_count = len(await lm.get_radarr_movies())
    tv_count    = len(await lm.get_sonarr_series())

    body = f"""
    <h2>Browse Library</h2>
    <div class="tabs">
      <div class="tab {'active' if tab=='movies' else ''}" onclick="location.href='/library?tab=movies&q={q}'">🎬 Movies ({movie_count})</div>
      <div class="tab {'active' if tab=='tv'     else ''}" onclick="location.href='/library?tab=tv&q={q}'">📺 TV Shows ({tv_count})</div>
    </div>
    <div class="search-bar">
      <input id="q" type="text" placeholder="Search..." value="{q}"
             onkeydown="if(event.key==='Enter')location.href='/library?tab={tab}&q='+encodeURIComponent(this.value)">
      <button class="btn btn-add" onclick="location.href='/library?tab={tab}&q='+encodeURIComponent(document.getElementById('q').value)">Search</button>
      {'<button class="btn btn-sec" onclick="location.href=\'/library?tab='+tab+'\'">Clear</button>' if q else ''}
      <button class="btn btn-sec" onclick="refreshLib()">🔄 Refresh</button>
    </div>
    <div class="card-grid">{cards}</div>
    {_pagination("/library", {"tab": tab, "q": q}, page, total_pages)}"""

    extra = """<script>
function addCard(btn) {
  const type  = btn.dataset.mtype;
  const id    = parseInt(btn.dataset.id) || null;
  const title = btn.dataset.title;
  const year  = btn.dataset.year ? parseInt(btn.dataset.year) : null;
  const sc    = parseInt(btn.dataset.sc) || 0;
  addItem(type, id, title, year, sc);
}
function removeCard(btn) {
  const type  = btn.dataset.mtype;
  const title = btn.dataset.title;
  const year  = btn.dataset.year ? parseInt(btn.dataset.year) : null;
  removeItem(type, title, year);
}
async function addItem(type, id, title, year, sc) {
  const r = await fetch('/api/library/add', {method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({media_type:type,arr_id:id,title,year,season_count:sc})});
  const d = await r.json();
  if (r.ok && d.status !== 'skipped') { toast('✅ '+title+' added'); setTimeout(()=>location.reload(),1200); }
  else if (d.status === 'skipped') { toast('⏭️ '+title+' is not released yet — enable "Include unreleased movies" in Settings', false); }
  else { toast('❌ '+(d.detail||d.message||'Error'), false); }
}
async function removeItem(type, title, year) {
  if (!confirm('Remove "'+title+'" from library?')) return;
  const r = await fetch('/api/library/remove',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({media_type:type,title,year})});
  if (r.ok) { toast('🗑️ Removed'); setTimeout(()=>location.reload(),1200); }
  else { toast('❌ Error', false); }
}
async function refreshLib() {
  const r = await fetch('/api/library/refresh',{method:'POST'});
  const d = await r.json();
  toast('✅ Refreshed — '+d.synced+' series updated');
  setTimeout(()=>location.reload(),1200);
}
</script>"""
    return _page("Browse Library", "library", body, extra)


# ── /api/library/add ─────────────────────────────────────────────────────────
@app.post("/api/library/add")
async def api_library_add(request: Request, background_tasks: BackgroundTasks):
    body = await request.json()
    media_type   = body.get("media_type", "movie")
    arr_id       = body.get("arr_id")
    title        = body.get("title", "").strip()
    year         = body.get("year")
    season_count = body.get("season_count", 0)

    if not title:
        raise HTTPException(400, "title required")

    lm: LibraryManager = request.app.state.library
    db: CacheDB         = request.app.state.db
    tmdb_key            = db.get_setting("tmdb_api_key", "")

    if media_type == "movie":
        # Fetch full movie details from Overseerr to get poster/overview/tmdb_id
        movies = await lm.get_radarr_movies()
        movie  = next((m for m in movies if m.get("id") == arr_id or m["title"].lower() == title.lower()), None)

        poster_url = movie.get("poster", "") if movie else ""
        tmdb_id    = movie.get("tmdb_id") if movie else None
        imdb_id    = movie.get("imdb_id") if movie else None
        overview   = movie.get("overview", "") if movie else ""

        # Filter unreleased movies if setting is off
        include_unreleased_movies = db.get_setting("include_unreleased_movies", "false") == "true"
        if not include_unreleased_movies:
            from datetime import date
            today = date.today().isoformat()
            release_date = movie.get("release_date", "") if movie else ""
            if release_date and release_date > today:
                log.info(f"⏭️  Skipping unreleased movie: {title!r} (release_date={release_date!r})")
                return {"status": "skipped", "message": f"{title} is not yet released — enable 'Include unreleased movies' in Settings to add it"}

        # Fetch poster from TMDB if not from Overseerr
        if not poster_url and tmdb_key and tmdb_id:
            poster_url = await _fetch_tmdb_poster(tmdb_id, title, True, tmdb_key)

        path = lm.create_fake_movie(title, year)

        db.fake_library_add({
            "media_type": "movie",
            "title":      title,
            "year":       year,
            "radarr_id":  arr_id,
            "tmdb_id":    tmdb_id,
            "imdb_id":    imdb_id,
            "poster_url": poster_url,
            "overview":   overview,
            "status":     "movie",
            "fake_path":  str(path) if path else None,
        })
        log.info(f"🎬 Added movie: {title} ({year})")
        background_tasks.add_task(_precache_movie, request.app, title, year, tmdb_id, imdb_id)
        return {"status": "ok", "message": f"Added {title}"}

    else:
        # Series — fetch details synchronously so we can return a useful response
        series_list = await lm.get_sonarr_series()
        series = next((s for s in series_list if s.get("id") == arr_id), None)

        sc                = series.get("season_count", season_count) if series else season_count
        tvdb_id           = series.get("tvdb_id") if series else None
        tmdb_id           = series.get("tmdb_id") if series else None
        imdb_id           = series.get("imdb_id") if series else None
        poster_url        = series.get("poster", "") if series else ""
        overview          = series.get("overview", "") if series else ""
        is_ended          = series.get("is_ended", False) if series else False
        requested_seasons = series.get("requested_seasons", []) if series else []

        if not poster_url and tmdb_key and tmdb_id:
            poster_url = await _fetch_tmdb_poster(tmdb_id, title, False, tmdb_key)

        # Fetch ALL episodes from Overseerr/TMDB (including unreleased)
        episodes = await lm.get_episodes(
            arr_id,
            include_unreleased=True,
            requested_seasons=requested_seasons if requested_seasons else None,
        )

        log.info(f"📺 {title}: {len(episodes)} episodes from Overseerr for seasons {requested_seasons}")

        paths = lm.create_fake_episodes(title, year, [], episodes)

        db.fake_library_add({
            "media_type":   "series",
            "title":        title,
            "year":         year,
            "sonarr_id":    arr_id,
            "tvdb_id":      tvdb_id,
            "tmdb_id":      tmdb_id,
            "imdb_id":      imdb_id,
            "season_count": sc,
            "poster_url":   poster_url,
            "overview":     overview,
            "status":       "ended" if is_ended else "continuing",
            "fake_path":    str(Path(lm.plex_root) / "tv" / title) if lm.plex_root else None,
        })

        log.info(f"📺 Added {title!r} — {len(paths)}/{len(episodes)} placeholders written")

        # Cache all episodes in background (so play works immediately)
        background_tasks.add_task(_precache_series, request.app, title, year, episodes)
        return {"status": "ok", "message": f"Added {title} — {len(episodes)} episodes"}


@app.post("/api/library/remove")
async def api_library_remove(request: Request):
    body  = await request.json()
    mtype = body.get("media_type")
    title = body.get("title", "").strip()
    year  = body.get("year")
    lm    = request.app.state.library
    db    = request.app.state.db
    alldebrid = request.app.state.alldebrid

    # ── 1. Find all cache entries for this title ──────────────────────────────
    db_types    = ["movie"] if mtype == "movie" else ["episode", "series"]
    all_entries = db.list_all()
    entries     = [
        e for e in all_entries
        if e["title"].lower() == title.lower() and e["media_type"] in db_types
    ]
    log.info(f"🗑️  Removing '{title}' — {len(entries)} cache entries to clean up")

    # ── 2. AllDebrid: delete magnets ──────────────────────────────────────────
    import re as _re
    deleted_magnet_ids: set[str] = set()
    for entry in entries:
        magnet = entry.get("magnet_link") or ""
        m = _re.search(r"[?&]xt=urn:btih:([a-fA-F0-9]{40})", magnet, _re.I)
        if not m:
            continue
        # Find the magnet ID by querying AllDebrid status
        # We stored the magnet ID from add_magnet — it's not in our DB directly,
        # but we can delete by hash using the upload endpoint
        # Simpler: re-upload to get the ID, then delete
        try:
            result = await alldebrid._ad_post(
                alldebrid._client, alldebrid.api_key,
                "https://api.alldebrid.com/v4/magnet/upload",
                [("magnets[]", magnet)],
            )
            magnets_returned = result.get("data", {}).get("magnets", [])
            for mg in magnets_returned:
                if mg.get("error"):
                    continue
                mid = str(mg.get("id", ""))
                if mid and mid not in deleted_magnet_ids:
                    await alldebrid.delete_magnet(mid)
                    deleted_magnet_ids.add(mid)
                    log.info(f"  🗑️  AllDebrid: deleted magnet id={mid}")
        except Exception as e:
            log.warning(f"  ⚠ AllDebrid cleanup failed for '{title}': {e}")

    # ── 3. FUSE: unregister torrents ──────────────────────────────────────────
    if FUSE_AVAILABLE:
        torrent_names = {e["torrent_name"] for e in entries if e.get("torrent_name")}
        for tname in torrent_names:
            unregister_torrent(tname)
            log.info(f"  🗑️  FUSE: unregistered '{tname}'")

    # ── 4. DFS chunk cache: delete chunks for these stream URLs ───────────────
    try:
        from app.fuse_mount import _dfs, _chunk_path
        import hashlib as _hl
        cache_dir = Path(_dfs.get("cache_dir", "/docker/debridarr/tmp/cache"))
        if cache_dir.exists():
            stream_urls = {e["stream_url"] for e in entries if e.get("stream_url")}
            deleted_chunks = 0
            for url in stream_urls:
                h = _hl.md5(url.encode()).hexdigest()[:16]
                for chunk_file in cache_dir.glob(f"{h}_*"):
                    chunk_file.unlink(missing_ok=True)
                    deleted_chunks += 1
            if deleted_chunks:
                log.info(f"  🗑️  DFS: deleted {deleted_chunks} cached chunks")
    except Exception as e:
        log.warning(f"  ⚠ DFS chunk cleanup failed: {e}")

    # ── 5. Plex-strm: remove files ───────────────────────────────────────────
    if mtype == "movie":
        lm.remove_fake_movie(title, year)
    else:
        lm.remove_fake_series(title)

    # ── 6. DB: remove cache entries and fake_library record ──────────────────
    for entry in entries:
        db.delete(entry["cache_key"])
    db.fake_library_remove(mtype, title, year)

    # ── 7. Clear in-memory search cache ──────────────────────────────────────
    from app.alldebrid import _search_cache
    for k in [k for k in list(_search_cache) if title.lower() in k.lower()]:
        del _search_cache[k]

    log.info(f"🗑️  '{title}' fully removed: "
             f"{len(entries)} cache entries, {len(deleted_magnet_ids)} AllDebrid magnets, "
             f"{len({e.get('torrent_name') for e in entries if e.get('torrent_name')})} FUSE torrents")

    return {
        "status": "removed",
        "cache_entries_deleted": len(entries),
        "magnets_deleted": len(deleted_magnet_ids),
    }


@app.post("/api/library/refresh")
async def api_library_refresh(request: Request):
    lm = request.app.state.library
    db = request.app.state.db
    if not lm: return {"status": "error", "message": "Not configured"}
    lm.invalidate_cache()
    movies = await lm.get_radarr_movies(force=True)
    series = await lm.get_sonarr_series(force=True)
    added  = [r for r in db.fake_library_list() if r["media_type"] == "series"]
    include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"
    synced = 0
    for entry in added:
        sid = entry.get("sonarr_id")
        if not sid: continue
        updated = next((s for s in series if s.get("id") == sid), None)
        if not updated: continue
        result = await lm.sync_series_episodes(entry["title"], sid, entry.get("year"),
                                                include_unreleased,
                                                requested_seasons=updated.get("requested_seasons", []))
        if result.get("added", 0) > 0: synced += 1
    return {"status": "ok", "movies": len(movies), "series": len(series), "synced": synced}


# ── /streams — resolved streams + search ─────────────────────────────────────
@app.get("/streams", response_class=HTMLResponse)
async def streams_page(request: Request, q: str = "", filter_type: str = "all"):
    if _needs_setup(request): return _setup_redirect()
    db: CacheDB = request.app.state.db
    tmdb_key = db.get_setting("tmdb_api_key", "")

    # Get library items for the search/poster display
    lib_items = db.fake_library_list()
    movies_lib = [i for i in lib_items if i["media_type"] == "movie"]
    shows_lib  = [i for i in lib_items if i["media_type"] == "series"]

    # Cached counts per title
    all_cached = [e for e in db.list_all() if e["status"] == "cached"]
    cached_counts: dict[str, int] = {}
    for e in all_cached:
        mt = "movie" if e["media_type"] == "movie" else "series"
        k  = f"{mt}::{e['title'].lower()}"
        cached_counts[k] = cached_counts.get(k, 0) + 1

    # Streams table (all entries — filtering done client-side)
    entries = db.list_all()
    entries.sort(key=lambda e: e.get("title","").lower())

    def pill(s):
        cls = {"cached":"pill-ok","resolving":"pill-res","error":"pill-err","not_found":"pill-nf"}.get(s,"pill-pend")
        return f'<span class="pill {cls}">{s}</span>'

    rows = ""
    for e in entries:
        t = e.get("torrent_name","") or ""
        t_short = (t[:60]+"…") if len(t) > 60 else t
        ep  = ""
        if e.get("season"):  ep += f"S{str(e['season']).zfill(2)}"
        if e.get("episode"): ep += f"E{str(e['episode']).zfill(2)}"
        exp = datetime.fromisoformat(e["expires_at"]).strftime("%Y-%m-%d") if e.get("expires_at") else "—"
        safe_title = e['title'].replace('"','&quot;')
        rows += f"""<tr data-title="{safe_title.lower()}" data-status="{e['status']}">
          <td style="color:#888;font-size:0.8rem">{e['media_type']}</td>
          <td><strong>{e['title']}</strong><br><small style="color:#555;font-size:0.72rem">{t_short}</small></td>
          <td style="font-family:monospace">{ep}</td>
          <td>{e.get('quality','—') or '—'}</td>
          <td>{exp}</td>
          <td>{pill(e['status'])}</td>
          <td style="white-space:nowrap">
            <button class="btn btn-rem" style="padding:3px 8px;font-size:0.72rem" data-key="{e['cache_key']}" onclick="del_(this)">Del</button>
            <button class="btn btn-sec" style="padding:3px 8px;font-size:0.72rem;margin-left:4px" data-key="{e['cache_key']}" onclick="expireNow(this)">⏰ Expire</button>
          </td>
        </tr>"""

    total = len(entries)

    # My Library cards section
    def lib_card(item, mtype):
        title  = item["title"]
        safe   = title.replace("'","&#39;").replace('"','&quot;')
        poster = item.get("poster_url") or ""
        sc     = item.get("season_count") or 0
        status = item.get("status","")
        year   = item.get("year") or ""
        n      = cached_counts.get(f"{mtype}::{title.lower()}", 0)

        if poster:
            img = f'<img src="{poster}" alt="{safe}" style="width:100%;aspect-ratio:2/3;object-fit:cover;display:block">'
        else:
            initials = "".join(w[0].upper() for w in title.split()[:2])
            img = f'<div class="no-poster">{initials}</div>'

        badge = f'<span class="badge-in">✅ {n} ep{"s" if n!=1 else ""}</span>' if n and mtype=="series" else \
                (f'<span class="badge-in">✅ Cached</span>' if n else \
                 '<span class="badge-grey">⏳ Not cached</span>')

        status_pill = ""
        if mtype == "series":
            col = "#ef4444" if status == "ended" else "#22c55e"
            lbl = "Ended" if status == "ended" else "Continuing"
            status_pill = f'<span style="font-size:0.65rem;color:{col};margin-left:4px">({lbl})</span>'

        sub = f"{sc} season{'s' if sc!=1 else ''}{status_pill}" if mtype=="series" else str(year)

        return (
            f'<div class="card" data-filter-title="{safe.lower()}" style="cursor:pointer" onclick="filterByTitle(this)">' +
            img +
            f'<div class="info"><div class="title" title="{safe}">{title}</div>' +
            f'<div class="meta">{sub}</div></div>' +
            f'<div class="actions">{badge}' +
            f'<button class="btn btn-rem" style="padding:3px 8px;font-size:0.7rem"' +
            f' data-mtype="{mtype}" data-title="{safe}" data-year="{item.get("year") or ""}"' +
            ' onclick="event.stopPropagation();remCard(this)">Remove</button></div></div>'
        )

    lib_section = ""
    if movies_lib:
        lib_section += f'<h2 style="margin:0 0 12px">🎬 Movies <span style="color:#555;font-size:0.8rem;font-weight:normal">({len(movies_lib)})</span></h2>'
        lib_section += f'<div class="card-grid" style="margin-bottom:32px">{"".join(lib_card(i,"movie") for i in movies_lib)}</div>'
    if shows_lib:
        lib_section += f'<h2 style="margin:0 0 12px">📺 TV Shows <span style="color:#555;font-size:0.8rem;font-weight:normal">({len(shows_lib)})</span></h2>'
        lib_section += f'<div class="card-grid" style="margin-bottom:32px">{"".join(lib_card(i,"series") for i in shows_lib)}</div>'
    if not lib_section:
        lib_section = f'<div class="empty"><a href="/library" style="color:#f97316">Browse Library</a> to add titles.</div>'

    streams_section = f"""
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
      <h2 style="margin:0">⚡ Resolved Streams <span id="stream-count" style="color:#555;font-size:0.8rem;font-weight:normal">({total}/{total})</span></h2>
      <button class="btn btn-rem" onclick="delAll()" style="padding:6px 14px">🗑️ Delete All Visible</button>
    </div>
    <div class="search-bar" style="margin-bottom:14px">
      <input id="sq" type="text" placeholder="Search streams..." oninput="applyFilters(true)">
      <button class="btn btn-sec" onclick="clearSearch()">Clear</button>
      <select id="status-filter" onchange="applyFilters(true)"
              style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:8px;padding:8px 12px;color:#e0e0e0;font-size:0.85rem;outline:none">
        <option value="all">All statuses</option>
        <option value="cached">Cached</option>
        <option value="not_found">Not found</option>
        <option value="error">Error</option>
      </select>
    </div>
    <div id="streams-table">
      {"<table id='st'><thead><tr><th>Type</th><th>Title</th><th>Ep</th><th>Quality</th><th>Expires</th><th>Status</th><th></th></tr></thead><tbody>"+rows+"</tbody></table>" if rows else '<div class="empty">No streams yet.</div>'}
    </div>"""

    body = lib_section + '<hr style="border:none;border-top:1px solid #2a2a3a;margin:32px 0">' + streams_section

    extra = """<script>
const STREAMS_PER_PAGE = 50;
let streamPage = 1;

function applyFilters(resetPage) {
  if (resetPage) streamPage = 1;
  const q      = (document.getElementById('sq').value || '').toLowerCase().trim();
  const status = document.getElementById('status-filter').value;
  const rows   = [...document.querySelectorAll('#st tbody tr')];
  const matched = rows.filter(r => {
    const titleMatch  = !q      || r.dataset.title.includes(q);
    const statusMatch = status === 'all' || r.dataset.status === status;
    return titleMatch && statusMatch;
  });
  const totalPages = Math.max(1, Math.ceil(matched.length / STREAMS_PER_PAGE));
  streamPage = Math.min(streamPage, totalPages);
  const start = (streamPage - 1) * STREAMS_PER_PAGE;
  const end   = start + STREAMS_PER_PAGE;

  rows.forEach(r => r.style.display = 'none');
  matched.forEach((r, i) => r.style.display = (i >= start && i < end) ? '' : 'none');

  const el = document.getElementById('stream-count');
  if (el) el.textContent = '(' + matched.length + ' total)';
  renderStreamPager(matched.length, totalPages);
}

function renderStreamPager(total, totalPages) {
  let el = document.getElementById('stream-pager');
  if (!el) {
    el = document.createElement('div');
    el.id = 'stream-pager';
    el.className = 'pg-bar';
    const tbl = document.getElementById('streams-table');
    if (tbl) tbl.after(el);
  }
  if (totalPages <= 1) { el.innerHTML = ''; return; }

  let html = '';
  const prev = streamPage > 1;
  const next = streamPage < totalPages;
  html += prev ? '<span class="pg-btn" onclick="goStreamPage('+( streamPage-1)+')">‹</span>'
               : '<span class="pg-btn pg-dis">‹</span>';

  let pages = [];
  if (totalPages <= 7) { for (let i=1;i<=totalPages;i++) pages.push(i); }
  else {
    pages = [1];
    if (streamPage > 3) pages.push('…');
    for (let i=Math.max(2,streamPage-1);i<=Math.min(totalPages-1,streamPage+1);i++) pages.push(i);
    if (streamPage < totalPages-2) pages.push('…');
    pages.push(totalPages);
  }
  pages.forEach(p => {
    if (p === '…') html += '<span class="pg-btn pg-dis">…</span>';
    else if (p === streamPage) html += '<span class="pg-btn pg-cur">'+p+'</span>';
    else html += '<span class="pg-btn" onclick="goStreamPage('+p+')">'+p+'</span>';
  });

  html += next ? '<span class="pg-btn" onclick="goStreamPage('+(streamPage+1)+')">›</span>'
               : '<span class="pg-btn pg-dis">›</span>';
  el.innerHTML = html;
}

function goStreamPage(p) { streamPage = p; applyFilters(false); window.scrollTo({top:document.getElementById('st')?.offsetTop||0,behavior:'smooth'}); }

function clearSearch() {
  document.getElementById('sq').value = '';
  document.getElementById('status-filter').value = 'all';
  applyFilters(true);
}

function filterByTitle(card) {
  const t = card.dataset.filterTitle || '';
  document.getElementById('sq').value = t;
  document.getElementById('status-filter').value = 'all';
  applyFilters();
  document.getElementById('st')?.scrollIntoView({behavior:'smooth', block:'start'});
}

async function expireNow(btn) {
  const k = btn.dataset.key;
  if (!confirm('Hard reset this cached stream? Symlink deleted, placeholder restored, removed from AllDebrid. Re-caches on next play.')) return;
  const r = await fetch('/cache/'+k+'/expire', {method:'POST'});
  if (r.ok) {
    const row = btn.closest('tr');
    if (row) {
      const pill = row.querySelector('.pill');
      if (pill) { pill.textContent = 'not_found'; pill.className = 'pill pill-nf'; }
      row.dataset.status = 'not_found';
    }
    toast('⏰ Reset — will re-cache on play');
    applyFilters();
  } else {
    toast('❌ Error', false);
  }
}

async function del_(btn) {
  const k = btn.dataset.key;
  const r = await fetch('/cache/'+k, {method:'DELETE'});
  if (r.ok) {
    const row = btn.closest('tr');
    if (row) row.remove();
    toast('🗑️ Deleted');
    applyFilters();
  } else {
    toast('❌ Error', false);
  }
}

async function delAll() {
  const rows = [...document.querySelectorAll('#st tbody tr')].filter(r => r.style.display !== 'none');
  if (!confirm('Delete ' + rows.length + ' visible streams?')) return;
  for (const row of rows) {
    const btn = row.querySelector('[data-key]');
    if (btn) {
      await fetch('/cache/'+btn.dataset.key, {method:'DELETE'});
      row.remove();
    }
  }
  toast('🗑️ All deleted');
  applyFilters();
}

async function remCard(btn) {
  const type  = btn.dataset.mtype;
  const title = btn.dataset.title.replace(/&#39;/g,"'").replace(/&quot;/g,'"');
  const year  = btn.dataset.year ? parseInt(btn.dataset.year) : null;
  if (!confirm('Remove "'+title+'" from library?')) return;
  const r = await fetch('/api/library/remove',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({media_type:type,title,year})});
  if (r.ok) {
    const card = btn.closest('.card');
    if (card) card.remove();
    // Remove matching stream rows
    document.querySelectorAll('#st tbody tr').forEach(row => {
      if (row.dataset.title === title.toLowerCase()) row.remove();
    });
    toast('🗑️ Removed');
    applyFilters();
  } else {
    toast('❌ Error', false);
  }
}
</script>"""
    return _page("Streams", "streams", body, extra)


# ── /settings ────────────────────────────────────────────────────────────────
@app.get("/settings", response_class=HTMLResponse)
async def settings_page(request: Request):
    if _needs_setup(request): return _setup_redirect()
    db: CacheDB = request.app.state.db
    ss  = db.get_all_settings()   # single source of truth — everything comes from here

    saved_msg = request.query_params.get("saved", "")

    def sv(key, default=""):
        """Get a setting value from DB."""
        return ss.get(key) or default

    def field(label, key, hint="", typ="text", placeholder="", masked_if_saved=False):
        val  = sv(key)
        mask = masked_if_saved and bool(val)
        ph   = "••••••• (saved — leave blank to keep)" if mask else (placeholder or "")
        attr = ' data-saved="true"' if mask else ""
        return f"""<div class="field">
          <label>{label}{'<span class="saved-badge">saved</span>' if mask else ""}</label>
          <input id="{key}" name="{key}" type="{'password' if mask else typ}"
                 value="{'  ' if mask else val}" placeholder="{ph}" autocomplete="off"{attr}>
          {'<div class="hint">'+hint+'</div>' if hint else ''}
        </div>"""

    def toggle(label, key, hint="", onchange=""):
        checked = 'checked' if ss.get(key, "false") == "true" else ""
        oc = f' onchange="{onchange}"' if onchange else ""
        return f"""<div style="display:flex;align-items:center;justify-content:space-between;gap:20px;margin-bottom:14px">
          <div>
            <div style="font-size:0.875rem;font-weight:600;margin-bottom:4px">{label}</div>
            {'<div style="font-size:0.75rem;color:#555">'+hint+'</div>' if hint else ''}
          </div>
          <label class="toggle">
            <input type="checkbox" name="{key}" value="true" {checked}{oc}>
            <span class="slider"></span>
          </label>
        </div>"""

    def select(label, key, options, hint=""):
        """options = list of (value, label)"""
        cur = ss.get(key, options[0][0])
        opts = "".join(
            f'<option value="{v}"{"selected" if v==cur else ""}>{lbl}</option>'
            for v, lbl in options
        )
        return f"""<div class="field"><label>{label}</label>
          <select name="{key}">{opts}</select>
          {'<div class="hint">'+hint+'</div>' if hint else ''}
        </div>"""

    debridarr_url = (sv("DEBRIDARR_BASE_URL") or "http://debridarr:7474").rstrip("/")
    tautulli_url  = f"{debridarr_url}/webhook/tautulli"
    tautulli_json = '{"media_type":"{media_type}","title":"{title}","grandparent_title":"{grandparent_title}","year":"{year}","grandparent_year":"{grandparent_year}","parent_media_index":"{parent_media_index}","media_index":"{media_index}","rating_key":"{rating_key}","themoviedb_id":"{themoviedb_id}","thetvdb_id":"{thetvdb_id}","imdb_id":"{imdb_id}"}'

    saved_banner = f'<div class="test-result ok" style="margin-bottom:16px">✅ {saved_msg}</div>' if saved_msg else ""

    body = f"""
    <div style="max-width:720px">
      <h2 style="margin-bottom:4px">⚙️ Settings</h2>
      <p style="color:#555;font-size:0.85rem;margin-bottom:20px">All settings are saved immediately when you click Save.</p>
      {saved_banner}

      <form method="POST" action="/settings/save">

      <div class="s-sect">
        <div class="s-title">AllDebrid</div>
        {field("API Key","ALLDEBRID_API_KEY","alldebrid.com/apikeys","text","",masked_if_saved=True)}
      </div>

      <div class="s-sect">
        <div class="s-title">Overseerr</div>
        {field("URL","OVERSEERR_URL","http://overseerr:5055")}
        {field("API Key","OVERSEERR_API_KEY","Overseerr → Settings → General → API Key","text","",masked_if_saved=True)}
      </div>

      <div class="s-sect">
        <div class="s-title">Sonarr</div>
        {field("URL","SONARR_URL","http://sonarr:8989")}
        {field("API Key","SONARR_API_KEY","Sonarr → Settings → General → API Key","text","",masked_if_saved=True)}
      </div>

      <div class="s-sect">
        <div class="s-title">Radarr</div>
        {field("URL","RADARR_URL","http://radarr:7878")}
        {field("API Key","RADARR_API_KEY","Radarr → Settings → General → API Key","text","",masked_if_saved=True)}
      </div>

      <div class="s-sect">
        <div class="s-title">TMDB</div>
        {field("API Key","TMDB_API_KEY","themoviedb.org/settings/api — used for posters","text","",masked_if_saved=True)}
      </div>

      <div class="s-sect">
        <div class="s-title">Plex</div>
        {field("Debridarr Base URL","DEBRIDARR_BASE_URL","URL Plex uses to reach Debridarr","text","http://192.168.1.x:7474")}
        {field("Plex Library Path","PLEX_ROOT","Path inside container where files are written","text","/plex-strm")}
      </div>

      <div class="s-sect">
        <div class="s-title">Library</div>
        {toggle("Include unreleased episodes","include_unreleased_episodes","Create placeholders for episodes not yet aired")}
        {toggle("Include unreleased movies","include_unreleased_movies","Add movies to library before their release date")}
      </div>

      <div class="s-sect">
        <div class="s-title">🤖 Overseerr Automation</div>
        {toggle("Auto-add approved requests","auto_add_requests","Automatically add Overseerr approved requests to Debridarr library")}
        <div class="field" style="max-width:220px">
          <label>Check interval (minutes)</label>
          <input name="auto_add_interval_minutes" type="number" min="5" max="1440"
                 value="{ss.get('auto_add_interval_minutes','60')}">
          <div class="hint">How often to poll Overseerr for new requests</div>
        </div>
        <div style="display:flex;gap:10px;align-items:center;margin-top:4px">
          <button type="button" class="btn btn-sec" onclick="runAutoAdd()" style="padding:6px 14px">▶ Run Now</button>
          <div id="auto-add-result" class="test-result" style="margin-top:0;flex:1"></div>
        </div>
      </div>

      <div class="s-sect">
        <div class="s-title">📡 Tautulli Webhook</div>
        <p style="font-size:0.82rem;color:#888;margin-bottom:12px">Triggers a search when you press play (required when pre-caching is off).</p>
        <div class="field">
          <label>1. Tautulli → Settings → Notification Agents → Add → Webhook — set URL to:</label>
          <div style="display:flex;gap:8px;align-items:center;margin-top:6px">
            <input id="twh-url" readonly value="{tautulli_url}"
                   style="flex:1;font-family:monospace;font-size:0.8rem;background:#0f0f13;border:1px solid #2a2a3a;border-radius:6px;padding:8px 10px;color:#e0e0e0">
            <button type="button" class="btn btn-sec" style="padding:6px 14px;white-space:nowrap"
                    onclick="navigator.clipboard.writeText(document.getElementById('twh-url').value);toast('✅ Copied')">Copy</button>
          </div>
        </div>
        <div class="field" style="margin-top:10px">
          <label>2. Set Method = POST, paste this as the JSON body under Triggers → Play:</label>
          <pre id="twh-json" style="background:#0f0f13;border:1px solid #2a2a3a;border-radius:6px;padding:10px;font-size:0.74rem;color:#a0a0b0;margin-top:6px;white-space:pre-wrap;word-break:break-all">{tautulli_json}</pre>
          <button type="button" class="btn btn-sec" style="padding:6px 14px;margin-top:6px"
                  onclick="navigator.clipboard.writeText(document.getElementById('twh-json').innerText);toast('✅ Copied')">Copy JSON</button>
        </div>
        <div style="display:flex;gap:8px;margin-top:10px">
          <button type="button" class="btn btn-sec" style="padding:6px 14px" onclick="testWebhook()">Test Webhook</button>
          <div id="webhook-result" class="test-result" style="margin-top:0;flex:1"></div>
        </div>
      </div>

      <div class="s-sect">
        <div class="s-title">🔍 Torrent Search</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px">
          {select("Completed Series Strategy","series_completed_strategy",[("series_pack","Series Pack (whole show)"),("season_pack","Season Pack"),("episode","Per Episode")])}
          {select("Ongoing Series Strategy","series_ongoing_strategy",[("season_pack","Season Pack"),("episode","Per Episode"),("series_pack","Series Pack")])}
          {select("Series Quality","series_preferred_quality",[("1080p","1080p"),("720p","720p"),("any","Any")])}
          {select("Series Fallback Quality","series_fallback_any_quality",[("true","Yes — any quality"),("false","No")])}
          {select("Movie Quality","movie_preferred_quality",[("1080p","1080p"),("720p","720p"),("any","Any")])}
          {select("Movie Fallback Quality","movie_fallback_any_quality",[("true","Yes — any quality"),("false","No")])}
          <div class="field"><label>Pre-cache Cooldown (min)</label>
            <input name="precache_cooldown_minutes" type="number" min="0" max="60"
                   value="{ss.get('precache_cooldown_minutes','1')}"></div>
          <div class="field"><label>Cache TTL (days)</label>
            <input name="cache_ttl_days" type="number" min="1" max="90"
                   value="{ss.get('cache_ttl_days','30')}"></div>
        </div>
        {toggle("Pre-cache on add","precache_enabled","Resolve and cache media immediately when added to library (recommended). When off, resolving happens when you press play via Tautulli webhook.")}
      </div>

      <div class="s-sect">
        <div class="s-title">System</div>
        {field("TZ","TZ","Timezone e.g. America/New_York")}
        {field("PUID","PUID","User ID for file permissions")}
        {field("PGID","PGID","Group ID for file permissions")}
      </div>

      <div style="display:flex;gap:12px;align-items:center;margin-top:8px">
        <button type="submit" class="btn btn-add" style="padding:10px 28px;font-size:0.9rem">💾 Save All Settings</button>
        <div id="save-result" class="test-result" style="margin-top:0;flex:1"></div>
      </div>

      </form>
    </div>"""

    extra = f"""<style>
.s-sect {{ background:#1a1a24;border:1px solid #2a2a3a;border-radius:10px;padding:20px 24px;margin-bottom:16px; }}
.s-title {{ font-size:0.75rem;font-weight:700;text-transform:uppercase;color:#f97316;letter-spacing:.08em;margin-bottom:16px; }}
.field {{ margin-bottom:14px; }}
.field label {{ display:block;font-size:0.8rem;color:#888;margin-bottom:5px;font-weight:600; }}
.field input,.field select {{ width:100%;background:#0f0f13;border:1px solid #2a2a3a;border-radius:7px;
  padding:9px 13px;color:#e0e0e0;font-size:0.875rem;outline:none;font-family:monospace; }}
.field input:focus,.field select:focus {{ border-color:#f97316; }}
.field select {{ cursor:pointer;font-family:inherit; }}
.field .hint {{ font-size:0.74rem;color:#555;margin-top:4px;line-height:1.4; }}
.field .hint a {{ color:#f97316; }}
.saved-badge {{ display:inline-block;margin-left:8px;font-size:0.68rem;font-weight:700;
  background:#14532d;color:#4ade80;border-radius:4px;padding:1px 6px;text-transform:uppercase; }}
.test-result {{ margin-top:10px;padding:8px 12px;border-radius:6px;font-size:0.82rem;display:none; }}
.test-result.ok {{ background:#14532d;color:#4ade80;display:block; }}
.test-result.err {{ background:#3b0000;color:#f87171;display:block; }}
.test-result.testing {{ background:#1e1e2e;color:#aaa;display:block; }}
.toggle {{ position:relative;display:inline-block;width:44px;height:24px;flex-shrink:0; }}
.toggle input {{ position:absolute;opacity:0;width:100%;height:100%;margin:0;cursor:pointer;z-index:1; }}
.slider {{ position:absolute;inset:0;background:#2a2a3a;border-radius:24px;transition:.2s;pointer-events:none; }}
.slider:before {{ position:absolute;content:"";height:18px;width:18px;left:3px;bottom:3px;
  background:#555;border-radius:50%;transition:.2s; }}
.toggle input:checked ~ .slider {{ background:#f97316; }}
.toggle input:checked ~ .slider:before {{ transform:translateX(20px);background:#fff; }}
pre {{ font-family:monospace;overflow-x:auto; }}
</style>
<script>
function getFieldVal(id) {{
  const e=document.getElementById(id);
  if(!e) return null;
  const v=e.value.trim();
  if(!v || e.dataset.saved) return null;
  return v;
}}
async function testConn(type) {{
  const urlEl=document.getElementById('OVERSEERR_URL');
  const keyEl=document.getElementById('OVERSEERR_API_KEY');
  const adEl =document.getElementById('ALLDEBRID_API_KEY');
  const plEl =document.getElementById('PLEX_ROOT');
  const params=new URLSearchParams({{
    type,
    overseerr_url:  urlEl?.value||'',
    overseerr_key:  keyEl?.value||'',
    alldebrid_key:  adEl?.value||'',
    plex_root:      plEl?.value||'',
  }});
  const el=document.getElementById('test-'+type);
  if(el){{ el.className='test-result testing'; el.style.display='block'; el.textContent='Testing...'; }}
  const r=await fetch('/api/test-connection?'+params);
  const d=await r.json();
  if(el){{ el.className='test-result '+(d.ok?'ok':'err'); el.textContent=(d.ok?'✅ ':'❌ ')+d.message; }}
}}
async function testAll() {{ await Promise.all(['alldebrid','overseerr','plex'].map(testConn)); }}
async function testWebhook() {{
  const res=document.getElementById('webhook-result');
  res.className='test-result testing'; res.style.display='block'; res.textContent='Testing...';
  try {{
    const r=await fetch('/webhook/test');
    const d=await r.json();
    res.className='test-result '+(r.ok?'ok':'err');
    res.textContent=r.ok?'✅ Reachable — configure Tautulli to POST to this URL':'❌ '+(d.detail||'Unreachable');
  }} catch(e) {{ res.className='test-result err'; res.textContent='❌ Could not reach endpoint'; }}
}}
async function runAutoAdd() {{
  const res=document.getElementById('auto-add-result');
  res.className='test-result testing'; res.style.display='block'; res.textContent='Running...';
  const r=await fetch('/api/auto-add/run',{{method:'POST'}});
  const d=await r.json();
  res.className='test-result '+(r.ok?'ok':'err');
  res.textContent=r.ok?'✅ '+d.message:'❌ '+(d.detail||'Failed');
}}
</script>"""
    return _page("Settings", "settings", body, extra)


@app.post("/settings/save")
async def settings_save(request: Request, background_tasks: BackgroundTasks):
    """
    Single unified settings save. Everything goes to app_settings in SQLite.
    No .env involvement — DB is the single source of truth for all settings.
    After saving, 303 redirect forces a fresh page render from the DB.
    """
    form = await request.form()
    db: CacheDB = request.app.state.db

    # ── All text/number/select fields ────────────────────────────────────────
    text_keys = {
        # Search settings
        "series_completed_strategy", "series_ongoing_strategy",
        "series_preferred_quality", "series_fallback_any_quality",
        "movie_preferred_quality", "movie_fallback_any_quality",
        "cache_ttl_days", "precache_cooldown_minutes",
        "auto_add_interval_minutes", "tmdb_api_key",
        # Connection settings
        "ALLDEBRID_API_KEY", "OVERSEERR_URL", "OVERSEERR_API_KEY",
        "SONARR_URL", "SONARR_API_KEY", "RADARR_URL", "RADARR_API_KEY",
        "DEBRIDARR_BASE_URL", "PLEX_ROOT", "TZ", "PUID", "PGID",
    }
    for key in text_keys:
        val = form.get(key, "").strip()
        if val:  # only overwrite if a value was actually submitted
            db.set_setting(key, val)

    # ── Checkboxes (absent from form = false) ────────────────────────────────
    for key in ("precache_enabled", "auto_add_requests", "include_unreleased_episodes", "include_unreleased_movies"):
        db.set_setting(key, "true" if form.get(key) else "false")

    # ── Side effects ─────────────────────────────────────────────────────────
    if request.app.state.library:
        tmdb = db.get_setting("tmdb_api_key", "")
        request.app.state.library.tmdb_key = tmdb
        request.app.state.library.invalidate_cache()

    include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"
    background_tasks.add_task(_sync_all_series_episodes, request.app, include_unreleased)

    # Re-init clients so new API keys / URLs take effect immediately
    _init_clients(request.app)

    from fastapi.responses import RedirectResponse
    return RedirectResponse(url="/settings?saved=Settings+saved", status_code=303)


# ── Legacy JSON API endpoints (kept for backwards compat) ────────────────────
@app.post("/api/settings/save")
async def api_settings_save(request: Request):
    body = await request.json()
    cfg  = load_saved_config()
    allowed = {"ALLDEBRID_API_KEY","OVERSEERR_URL","OVERSEERR_API_KEY",
               "DEBRIDARR_BASE_URL","PLEX_ROOT","TZ","PUID","PGID"}
    for k, v in body.items():
        if k in allowed and v: cfg[k] = v
    if body.get("TMDB_API_KEY"):
        db: CacheDB = request.app.state.db
        db.set_setting("tmdb_api_key", body["TMDB_API_KEY"])
        if request.app.state.library:
            request.app.state.library.tmdb_key = body["TMDB_API_KEY"]
    write_env(cfg)
    import os
    for k, v in cfg.items(): os.environ[k] = v
    _init_clients(request.app)
    if request.app.state.library: request.app.state.library.invalidate_cache()
    log.info("⚙️  Settings updated")
    return {"status": "ok", "message": "Settings saved"}


@app.post("/api/settings/search")
async def api_settings_search(request: Request):
    db: CacheDB = request.app.state.db
    payload = await request.json()
    allowed = {"series_completed_strategy","series_ongoing_strategy",
               "series_preferred_quality","series_fallback_any_quality",
               "precache_cooldown_minutes","movie_preferred_quality",
               "movie_fallback_any_quality","cache_ttl_days","precache_enabled",
               "auto_add_requests","auto_add_interval_minutes"}
    for k, v in payload.items():
        if k in allowed: db.set_setting(k, str(v))
    return {"status": "ok"}


@app.get("/api/settings/get")
async def api_settings_get(request: Request):
    db: CacheDB = request.app.state.db
    return db.get_all_settings()


@app.post("/api/settings/behaviour")
async def api_settings_behaviour(request: Request, background_tasks: BackgroundTasks):
    body  = await request.json()
    key   = body.get("key", "").strip()
    value = body.get("value", "").strip()
    if key not in {"include_unreleased_episodes"}:
        raise HTTPException(400, f"Unknown setting: {key}")
    db: CacheDB = request.app.state.db
    db.set_setting(key, value)
    if key == "include_unreleased_episodes":
        background_tasks.add_task(_sync_all_series_episodes, request.app, value == "true")
    return {"status": "ok", "message": f"{key} = {value}"}


@app.get("/api/settings/dfs")
async def api_settings_dfs_get():
    return get_dfs_settings()


@app.post("/api/settings/dfs")
async def api_settings_dfs_save(request: Request):
    body = await request.json()
    allowed = {"cache_dir","disk_cache_size_gb","cache_expiry_h","chunk_size_mb","read_ahead_mb","cleanup_interval_m"}
    cfg = {k: v for k, v in body.items() if k in allowed}
    for k in ("disk_cache_size_gb","cache_expiry_h","chunk_size_mb","read_ahead_mb","cleanup_interval_m"):
        if k in cfg:
            try: cfg[k] = int(cfg[k])
            except Exception: pass
    update_dfs_settings(cfg)
    db: CacheDB = request.app.state.db
    import json
    db.set_setting("dfs_settings", json.dumps(cfg))
    return {"status": "ok", "settings": get_dfs_settings()}



@app.post("/api/auto-add/run")
async def api_auto_add_run(request: Request, background_tasks: BackgroundTasks):
    """Manually trigger an auto-add pass."""
    db: CacheDB = request.app.state.db
    if not getattr(request.app.state, "setup_complete", False):
        raise HTTPException(400, "Setup not complete")
    background_tasks.add_task(_run_auto_add, request.app)
    return {"status": "ok", "message": "Auto-add pass triggered — check logs for details"}


@app.post("/api/episodes/sync")
async def api_episodes_sync(request: Request, background_tasks: BackgroundTasks):
    """Manually trigger a new-episode sync for all tracked series."""
    background_tasks.add_task(_sync_new_episodes, request.app)
    return {"status": "ok", "message": "Episode sync triggered — check logs for details"}


@app.post("/api/library/cleanup")
async def api_library_cleanup(request: Request):
    """
    Remove anything in plex-strm that has no matching entry in the library DB.

    Checks:
      - plex-strm/movies/<folder>  → delete if title/year not in fake_library
      - plex-strm/tv/<folder>      → delete if title not in fake_library
      - Individual episode files   → delete if SxxExx not in any tracked season for that show

    Returns counts of what was removed.
    """
    db: CacheDB        = app.state.db
    lm: LibraryManager = app.state.library
    s                  = app.state.settings

    plex_root = s.PLEX_ROOT or lm.plex_root if lm else ""
    if not plex_root:
        raise HTTPException(400, "PLEX_ROOT not configured")

    plex = Path(plex_root)
    removed_movies  = []
    removed_series  = []
    removed_files   = []

    # Build lookup sets from DB
    tracked_movies: set[str] = set()   # "Title (Year)" or "Title"
    for entry in db.fake_library_list(media_type="movie"):
        yp = f" ({entry['year']})" if entry.get("year") else ""
        tracked_movies.add(f"{entry['title']}{yp}".lower())

    tracked_series: set[str] = set()   # title (lowered)
    for entry in db.fake_library_list(media_type="series"):
        tracked_series.add(entry["title"].lower())

    # Build set of (title_lower, season, episode) for all tracked cache entries
    tracked_episodes: set[tuple[str, int, int]] = set()
    for entry in db.list_all():
        if entry["media_type"] == "episode" and entry.get("season") and entry.get("episode"):
            tracked_episodes.add((entry["title"].lower(), entry["season"], entry["episode"]))

    # ── Movies ────────────────────────────────────────────────────────────────
    movies_dir = plex / "movies"
    if movies_dir.exists():
        for folder in movies_dir.iterdir():
            if not folder.is_dir():
                continue
            if folder.name.lower() not in tracked_movies:
                import shutil as _shutil
                _shutil.rmtree(folder, ignore_errors=True)
                removed_movies.append(folder.name)
                log.info(f"🧹 Cleanup: removed untracked movie folder: {folder.name}")

    # ── TV series ─────────────────────────────────────────────────────────────
    tv_dir = plex / "tv"
    if tv_dir.exists():
        for show_folder in tv_dir.iterdir():
            if not show_folder.is_dir():
                continue
            title_lower = show_folder.name.lower()

            if title_lower not in tracked_series:
                # Whole series not in library — remove entirely
                import shutil as _shutil
                _shutil.rmtree(show_folder, ignore_errors=True)
                removed_series.append(show_folder.name)
                log.info(f"🧹 Cleanup: removed untracked series folder: {show_folder.name}")
                continue

            # Series is tracked — check individual episode files
            import re as _re
            for season_dir in show_folder.iterdir():
                if not season_dir.is_dir():
                    continue
                for ep_file in season_dir.iterdir():
                    m = _re.search(r"[Ss](\d{1,2})[Ee](\d{1,2})", ep_file.name)
                    if not m:
                        continue
                    sn  = int(m.group(1))
                    epn = int(m.group(2))
                    key = (title_lower, sn, epn)
                    if key not in tracked_episodes:
                        ep_file.unlink(missing_ok=True)
                        removed_files.append(f"{show_folder.name}/Season {sn:02d}/{ep_file.name}")
                        log.info(f"🧹 Cleanup: removed untracked episode file: {ep_file.name}")
                # Remove empty season dirs
                try:
                    if not any(season_dir.iterdir()):
                        season_dir.rmdir()
                except Exception:
                    pass

    total = len(removed_movies) + len(removed_series) + len(removed_files)
    log.info(f"🧹 Cleanup complete: {len(removed_movies)} movies, {len(removed_series)} series, {len(removed_files)} episode files removed")
    return {
        "ok": True,
        "removed_movies":       removed_movies,
        "removed_series":       removed_series,
        "removed_episode_files": removed_files,
        "total_removed":        total,
    }


async def _auto_add_loop(app: FastAPI):
    """Background loop — polls Overseerr and auto-adds approved requests if enabled.
    Also syncs new episodes for all tracked ongoing series on the same schedule."""
    await asyncio.sleep(60)  # wait for startup to settle
    while True:
        db: CacheDB = app.state.db
        try:
            # Always sync new episodes for tracked series, regardless of auto_add setting
            await _sync_new_episodes(app)
        except Exception as e:
            log.error(f"Episode sync loop: {e}")

        if db.get_setting("auto_add_requests", "false") == "true":
            try:
                await _run_auto_add(app)
            except Exception as e:
                log.error(f"Auto-add loop: {e}")

        interval = int(db.get_setting("auto_add_interval_minutes", "60"))
        await asyncio.sleep(max(5, interval) * 60)


async def _sync_new_episodes(app: FastAPI):
    """
    Check every tracked series in the library for newly-aired episodes.

    For each episode that has aired but has no placeholder yet:
      1. Search AllDebrid for a cached torrent
      2. Only create a placeholder + trigger resolve if a torrent is actually available
      3. Episodes with no cached torrent are skipped silently — checked again next interval

    This means placeholders only appear in Plex when there is something to stream.
    """
    db: CacheDB         = app.state.db
    lm: LibraryManager  = app.state.library
    alldebrid           = app.state.alldebrid
    if not lm or not lm.plex_root or not alldebrid:
        return

    include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"
    s_cfg              = db.get_all_settings()
    preferred_quality  = s_cfg.get("series_preferred_quality", "1080p")
    fallback_any       = s_cfg.get("series_fallback_any_quality", "true") == "true"

    series_list = db.fake_library_list(media_type="series")
    if not series_list:
        return

    log.debug(f"\U0001f4c5 Episode sync: checking {len(series_list)} series for new episodes")
    total_new = 0

    for entry in series_list:
        title    = entry["title"]
        sid      = entry.get("sonarr_id")
        year     = entry.get("year")
        is_ended = (entry.get("status", "continuing") in ("ended", "cancelled", "canceled"))
        strategy = s_cfg.get("series_completed_strategy", "series_pack") if is_ended \
                   else s_cfg.get("series_ongoing_strategy", "season_pack")
        if not sid:
            continue

        try:
            # Invalidate episode cache so air_date data is fresh
            from app.library import _cache as _lib_cache
            for k in [k for k in list(_lib_cache) if f"episodes::{sid}" in k]:
                del _lib_cache[k]

            episodes = await lm.get_episodes(sid, include_unreleased=include_unreleased)
            if not episodes:
                continue

            # Find which SxxExx already exist in plex-strm (placeholder or symlink)
            show_dir = Path(lm.plex_root) / "tv" / title
            existing: set[tuple[int, int]] = set()
            if show_dir.exists():
                for sf in show_dir.iterdir():
                    if not sf.is_dir():
                        continue
                    for f in sf.iterdir():
                        import re as _re
                        m = _re.search(r"[Ss](\d{1,2})[Ee](\d{1,2})", f.name)
                        if m:
                            existing.add((int(m.group(1)), int(m.group(2))))

            # Episodes that have aired but have no file yet
            new_eps = [ep for ep in episodes if (ep["season"], ep["episode"]) not in existing]
            if not new_eps:
                continue

            log.debug(f"\U0001f4c5 {title}: {len(new_eps)} aired episode(s) without placeholder — checking AllDebrid")

            for ep in new_eps:
                sn, epn = ep["season"], ep["episode"]
                try:
                    results = await alldebrid.search_cached(
                        title=title,
                        media_type="episode",
                        year=year,
                        season=sn,
                        episode=epn,
                        strategy=strategy,
                        preferred_quality=preferred_quality,
                        fallback_any=fallback_any,
                    )
                    if not results:
                        log.debug(f"  \u23ed  {title} S{sn:02d}E{epn:02d} — no cached torrent yet")
                        continue

                    # Torrent available — create placeholder and resolve
                    log.info(f"  \u2705 {title} S{sn:02d}E{epn:02d} — torrent found ({results[0]['name'][:50]}), adding placeholder")
                    lm.create_fake_episodes(title, year, [], [ep])
                    total_new += 1

                    from app.models import PlayEvent, MediaType
                    event = PlayEvent(
                        media_type=MediaType.episode,
                        title=title, year=year,
                        season=sn, episode=epn,
                    )
                    asyncio.create_task(resolve_and_cache(app, event))
                    await asyncio.sleep(2)

                except Exception as e:
                    log.error(f"  Episode search {title} S{sn:02d}E{epn:02d}: {e}")

        except Exception as e:
            log.error(f"Episode sync '{title}': {e}")

    if total_new:
        log.info(f"\U0001f4c5 Episode sync: added {total_new} new episode(s) with available torrents")
    else:
        log.debug("\U0001f4c5 Episode sync: no new episodes with available torrents")


async def _run_auto_add(app: FastAPI):
    """
    Fetch all approved Overseerr requests and add any not already in the library.
    Mirrors what the user does by clicking "+ Add" on the library page.
    """
    lm: LibraryManager = app.state.library
    db: CacheDB        = app.state.db

    if not lm or not lm.url or not lm.key:
        log.info("Auto-add: Overseerr not configured — skipping")
        return

    added_entries = {
        (r["media_type"], r["title"].lower())
        for r in db.fake_library_list()
    }

    movies = await lm.get_radarr_movies(force=True)
    series = await lm.get_sonarr_series(force=True)
    tmdb_key = db.get_setting("tmdb_api_key", "")
    include_unreleased        = db.get_setting("include_unreleased_episodes", "false") == "true"
    include_unreleased_movies = db.get_setting("include_unreleased_movies",  "false") == "true"
    added_count = 0

    from datetime import date as _date
    today = _date.today().isoformat()

    for movie in movies:
        key = ("movie", movie["title"].lower())
        if key in added_entries:
            continue
        try:
            title    = movie["title"]
            year     = movie.get("year")
            tmdb_id  = movie.get("tmdb_id")
            imdb_id  = movie.get("imdb_id")
            poster   = movie.get("poster", "")
            overview = movie.get("overview", "")

            # Skip unreleased movies unless setting is on
            release_date = movie.get("release_date", "")
            if not include_unreleased_movies and (not release_date or release_date > today):
                log.debug(f"⏭️  Auto-add skipping unreleased movie: {title!r} (release_date={release_date!r})")
                continue

            if not poster and tmdb_key and tmdb_id:
                poster = await _fetch_tmdb_poster(tmdb_id, title, True, tmdb_key)

            path = lm.create_fake_movie(title, year)
            db.fake_library_add({
                "media_type": "movie",
                "title":      title,
                "year":       year,
                "tmdb_id":    tmdb_id,
                "imdb_id":    imdb_id,
                "poster_url": poster,
                "overview":   overview,
                "status":     "movie",
                "fake_path":  str(path) if path else None,
            })
            log.info(f"🤖 Auto-added movie: {title} ({year})")
            added_entries.add(key)
            added_count += 1

            if db.get_setting("precache_enabled", "true") != "false":
                asyncio.create_task(_precache_movie(app, title, year, tmdb_id, imdb_id))

        except Exception as e:
            log.error(f"Auto-add movie '{movie.get('title')}': {e}")

    for show in series:
        key = ("series", show["title"].lower())
        if key in added_entries:
            continue
        try:
            title             = show["title"]
            year              = show.get("year")
            arr_id            = show.get("id")
            tmdb_id           = show.get("tmdb_id")
            tvdb_id           = show.get("tvdb_id")
            imdb_id           = show.get("imdb_id")
            sc                = show.get("season_count", 0)
            poster            = show.get("poster", "")
            overview          = show.get("overview", "")
            is_ended          = show.get("is_ended", False)
            requested_seasons = show.get("requested_seasons", [])

            if not poster and tmdb_key and tmdb_id:
                poster = await _fetch_tmdb_poster(tmdb_id, title, False, tmdb_key)

            episodes = await lm.get_episodes(
                arr_id,
                include_unreleased=include_unreleased,
                requested_seasons=requested_seasons if requested_seasons else None,
            )
            paths = lm.create_fake_episodes(title, year, [], episodes)
            db.fake_library_add({
                "media_type":   "series",
                "title":        title,
                "year":         year,
                "sonarr_id":    arr_id,
                "tvdb_id":      tvdb_id,
                "tmdb_id":      tmdb_id,
                "imdb_id":      imdb_id,
                "season_count": sc,
                "poster_url":   poster,
                "overview":     overview,
                "status":       "ended" if is_ended else "continuing",
                "fake_path":    str(Path(lm.plex_root) / "tv" / title) if lm.plex_root else None,
            })
            log.info(f"🤖 Auto-added series: {title} ({year}) — {len(episodes)} episodes")
            added_entries.add(key)
            added_count += 1

            if db.get_setting("precache_enabled", "true") != "false":
                asyncio.create_task(_precache_series(app, title, year, episodes))

        except Exception as e:
            log.error(f"Auto-add series '{show.get('title')}': {e}")

    if added_count:
        log.info(f"🤖 Auto-add complete — {added_count} new item(s) added")
    else:
        log.debug("🤖 Auto-add complete — nothing new")


# ── Proxy / webhook / cache ───────────────────────────────────────────────────
@app.get("/webhook/test")
async def webhook_test():
    return {"status": "ok", "message": "Debridarr webhook is reachable"}

@app.get("/proxy/{cache_key}")
async def stream_proxy(cache_key: str, request: Request):
    return await proxy_stream(request, cache_key, request.app.state.db, request.app.state.alldebrid, request.app)

@app.get("/stream/{cache_key}")
async def stream_cached(cache_key: str, request: Request):
    return await stream_direct(request, cache_key, request.app.state.db, request.app.state.alldebrid)

@app.post("/resolve")
async def manual_resolve(request: Request, background_tasks: BackgroundTasks):
    body  = await request.json()
    event = PlayEvent(media_type=MediaType(body["media_type"]), title=body["title"],
                      year=body.get("year"), season=body.get("season"), episode=body.get("episode"))
    background_tasks.add_task(resolve_and_cache, request.app, event)
    s = request.app.state.settings
    return {"status": "resolving", "cache_key": event.cache_key(),
            "proxy_url": f"{s.DEBRIDARR_BASE_URL}/proxy/{event.cache_key()}"}

@app.get("/cache")
async def list_cache(request: Request): return request.app.state.db.list_all()

@app.post("/cache/{cache_key}/expire")
@app.post("/cache/{cache_key}/expire")
async def expire_cache_entry(cache_key: str, request: Request, background_tasks: BackgroundTasks):
    db        = request.app.state.db
    s         = request.app.state.settings
    alldebrid = request.app.state.alldebrid
    entry     = db.get(cache_key)
    if not entry:
        raise HTTPException(404, "Not found")
    background_tasks.add_task(_hard_expire, entry, db, s, alldebrid)
    return {"status": "ok", "message": "Expiring — symlink deleted, removed from AllDebrid"}


async def _hard_expire(entry: dict, db: "CacheDB", s, alldebrid):
    """
    Full delete for one cache entry:
    1. Delete symlink/placeholder file from plex-strm
    2. Unregister from FUSE
    3. Delete from AllDebrid
    4. Delete from DB cache table
    """
    ck           = entry["cache_key"]
    strm         = entry.get("strm_path")
    torrent_name = entry.get("torrent_name")
    magnet       = entry.get("magnet_link", "")

    # 1. Delete symlink or placeholder file entirely
    if strm:
        p = Path(strm)
        try:
            if p.exists() or p.is_symlink():
                p.unlink(missing_ok=True)
                log.info(f"🗑️  Deleted file: {p}")
        except Exception as e:
            log.debug(f"File delete {p}: {e}")

    # 2. Unregister from FUSE (only if no other cached entry uses this torrent)
    if torrent_name and FUSE_AVAILABLE:
        others = [e for e in db.list_all()
                  if e.get("torrent_name") == torrent_name
                  and e["cache_key"] != ck
                  and e["status"] == "cached"]
        if not others:
            unregister_torrent(torrent_name)

    # 3. Delete from AllDebrid by hash
    if alldebrid and magnet:
        try:
            import httpx as _hx
            m = re.search(r"btih:([a-fA-F0-9]{40})", magnet, re.I)
            if m:
                info_hash = m.group(1).lower()
                r = await _hx.AsyncClient(timeout=10).get(
                    "https://api.alldebrid.com/v4.1/magnet/status",
                    params={"agent": "debridarr", "apikey": alldebrid.api_key, "status": "ready"},
                )
                if r.status_code == 200:
                    magnets = r.json().get("data", {}).get("magnets", {})
                    if isinstance(magnets, dict):
                        magnets = list(magnets.values())
                    for t in magnets:
                        if (t.get("hash") or "").lower() == info_hash:
                            await alldebrid.delete_magnet(str(t["id"]))
                            log.info(f"🗑️  Deleted from AllDebrid: {t['id']} ({ck})")
                            break
        except Exception as e:
            log.debug(f"AllDebrid delete {ck}: {e}")

    # 4. Delete from DB
    db.delete(ck)
    log.info(f"🗑️  Expired and deleted: {ck}")
    log.info(f"🗑️  Hard expired: {ck}")


@app.delete("/cache/{cache_key}")
async def delete_cache_entry(cache_key: str, request: Request, background_tasks: BackgroundTasks):
    db    = request.app.state.db
    s     = request.app.state.settings
    alldebrid = request.app.state.alldebrid
    entry = db.get(cache_key)
    if not entry:
        raise HTTPException(404, "Not found")
    background_tasks.add_task(_hard_expire, entry, db, s, alldebrid)
    return {"status": "deleted"}

@app.get("/health")
async def health(): return {"status": "ok", "service": "debridarr", "version": "0.5.0"}


@app.get("/api/debug/settings")
async def debug_settings(request: Request):
    """
    Shows what's actually stored in the DB vs what's in env vars.
    Use this to diagnose settings not persisting after reboot.
    """
    import os
    db: CacheDB = request.app.state.db
    s           = request.app.state.settings
    ss          = db.get_all_settings()

    keys = ["ALLDEBRID_API_KEY","OVERSEERR_URL","OVERSEERR_API_KEY",
            "DEBRIDARR_BASE_URL","PLEX_ROOT","SONARR_URL","RADARR_URL",
            "precache_enabled","series_preferred_quality","cache_ttl_days"]

    from app.config import settings as cfg_settings
    return {
        "db_path":    cfg_settings.DB_PATH,
        "db_exists":  Path(cfg_settings.DB_PATH).exists(),
        "db_size_kb": round(Path(cfg_settings.DB_PATH).stat().st_size / 1024, 1) if Path(cfg_settings.DB_PATH).exists() else 0,
        "settings": {
            k: {
                "db":  ("SET" if ss.get(k) else "empty") if k.endswith("KEY") or k == "ALLDEBRID_API_KEY" else ss.get(k, "(not in db)"),
                "env": ("SET" if os.environ.get(k) else "not set") if k.endswith("KEY") or k == "ALLDEBRID_API_KEY" else os.environ.get(k, "(not in env)"),
                "active": ("SET" if getattr(s, k, None) else "not set") if k.endswith("KEY") or k == "ALLDEBRID_API_KEY" else getattr(s, k, ss.get(k, "(unknown)")),
            }
            for k in keys
        }
    }


@app.post("/api/fuse/ensure-symlinked")
@app.get("/api/fuse/ensure-symlinked")
async def fuse_ensure_symlinked(request: Request):
    """
    Walk every video file in the FUSE mount and make sure it has a
    corresponding symlink in plex-strm. Creates any that are missing.

    For each FUSE file we:
      1. Check if any cached DB entry already has strm_path pointing to it
      2. If not, look the DB entry up by torrent_name match
      3. Call _make_plex_symlink to create the symlink (removes placeholder .mp4)
      4. Update DB strm_path

    Returns a summary of what was already linked, what was fixed, and
    what couldn't be matched to a DB entry (truly orphaned torrents).
    """
    if not FUSE_AVAILABLE:
        return {"ok": False, "error": "FUSE not available", "fixed": 0, "already_linked": 0, "unmatched": []}

    db: CacheDB     = request.app.state.db
    s               = request.app.state.settings
    fuse_root       = s.FUSE_SYMLINK_ROOT
    plex_root       = s.PLEX_ROOT

    if not fuse_root or not plex_root:
        return {"ok": False, "error": "PLEX_ROOT or FUSE_SYMLINK_ROOT not set", "fixed": 0, "already_linked": 0, "unmatched": []}

    from app.fuse_mount import list_torrents, list_files, get_fuse_path

    # Build map: fuse_path_str → db_entry  (for entries that already have a strm_path)
    fuse_to_entry: dict[str, dict] = {}
    # Build map: torrent_name → [db_entry]  (for lookup when fuse_path not yet set)
    torrent_to_entries: dict[str, list] = {}

    for entry in db.list_all():
        if entry["status"] != "cached":
            continue
        strm = entry.get("strm_path") or ""
        if strm and fuse_root in strm:
            # strm_path IS the symlink file in plex-strm; its target is the fuse path
            p = Path(strm)
            if p.is_symlink():
                try:
                    target = str(p.readlink())
                    fuse_to_entry[target] = entry
                except Exception:
                    pass
        # Index by torrent_name for fallback matching
        tname = entry.get("torrent_name", "")
        if tname:
            torrent_to_entries.setdefault(tname, []).append(entry)

    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
    already_linked = 0
    fixed          = 0
    unmatched      = []

    for torrent in list_torrents():
        for filename in list_files(torrent):
            if not any(filename.lower().endswith(e) for e in video_exts):
                continue  # skip subtitles, nfo, etc.

            fuse_path = str(get_fuse_path(torrent, filename, fuse_root))

            # Already has a valid symlink pointing to this file
            if fuse_path in fuse_to_entry:
                p = Path(fuse_to_entry[fuse_path].get("strm_path", ""))
                if p.is_symlink():
                    already_linked += 1
                    continue

            # Find the DB entry for this file
            entry = None

            # 1. Exact torrent_name match
            candidates = torrent_to_entries.get(torrent, [])
            if len(candidates) == 1:
                entry = candidates[0]
            elif len(candidates) > 1:
                # Multiple entries share this torrent (season pack) — match by episode
                import re as _re
                m = _re.search(r"[Ss](\d{1,2})[Ee](\d{1,2})", filename)
                if m:
                    sn, ep = int(m.group(1)), int(m.group(2))
                    entry = next(
                        (e for e in candidates if e.get("season") == sn and e.get("episode") == ep),
                        candidates[0],  # fallback to first
                    )
                else:
                    entry = candidates[0]

            if not entry:
                unmatched.append({"torrent": torrent, "file": filename, "fuse_path": fuse_path})
                continue

            # Create the symlink
            link = _make_plex_symlink(
                entry["cache_key"],
                entry["title"], entry.get("year"),
                entry.get("season"), entry.get("episode"),
                entry["media_type"], plex_root,
                fuse_path, filename,
            )
            if link:
                db.update_cached(
                    entry["cache_key"],
                    entry.get("magnet_link", ""),
                    entry.get("stream_url", ""),
                    torrent,
                    entry.get("quality", "unknown"),
                    str(link),
                )
                log.info(f"🔗 ensure-symlinked: {filename} → {fuse_path}")
                fixed += 1
                # Update our maps so a second file in the same torrent doesn't overwrite
                fuse_to_entry[fuse_path] = entry
            else:
                unmatched.append({"torrent": torrent, "file": filename, "fuse_path": fuse_path, "error": "symlink failed"})

    log.info(f"🔗 ensure-symlinked: {already_linked} already OK, {fixed} fixed, {len(unmatched)} unmatched")
    return {
        "ok": True,
        "already_linked": already_linked,
        "fixed": fixed,
        "unmatched_count": len(unmatched),
        "unmatched": unmatched,
    }


@app.post("/webhook/tautulli")
async def tautulli_webhook(request: Request, background_tasks: BackgroundTasks):
    try:    payload = await request.json()
    except: payload = dict(await request.form())

    log.info(f"📺 Tautulli: {payload}")

    if not payload:
        log.warning(
            "📺 Tautulli webhook received empty payload — "
            "Tautulli is not configured to send parameters. "
            "Go to Settings → Tautulli Webhook and follow the setup instructions."
        )
        return {"status": "ignored", "reason": "empty payload — check Tautulli webhook JSON body configuration"}

    media_type = payload.get("media_type", "")
    title      = payload.get("grandparent_title") or payload.get("title", "")
    year       = payload.get("year") or payload.get("grandparent_year")
    season     = payload.get("parent_media_index")
    episode    = payload.get("media_index")

    if media_type not in ("movie", "episode") or not title:
        log.warning(f"📺 Tautulli webhook ignored — media_type={media_type!r} title={title!r}")
        return {"status": "ignored"}

    event = PlayEvent(
        media_type=MediaType(media_type), title=title,
        year=int(year) if year else None,
        season=int(season) if season else None,
        episode=int(episode) if episode else None,
        rating_key=payload.get("rating_key"),
        tmdb_id=payload.get("themoviedb_id") or payload.get("tmdb_id"),
        tvdb_id=payload.get("thetvdb_id") or payload.get("tvdb_id"),
        imdb_id=payload.get("imdb_id"),
    )
    log.info(f"📺 Resolving: {event.cache_key()} — {title} S{season}E{episode}")
    background_tasks.add_task(resolve_and_cache, request.app, event)
    return {"status": "accepted", "cache_key": event.cache_key()}


# ── Background helpers ────────────────────────────────────────────────────────

async def _precache_movie(app: FastAPI, title: str, year, tmdb_id, imdb_id):
    """Resolve and cache a movie immediately after it's added."""
    db: CacheDB = app.state.db
    if db.get_setting("precache_enabled", "true") == "false":
        log.info(f"⏭️  Pre-caching disabled — skipping movie: {title!r}")
        return
    await asyncio.sleep(2)
    event = PlayEvent(
        media_type=MediaType.movie,
        title=title, year=year,
        tmdb_id=str(tmdb_id) if tmdb_id else None,
        imdb_id=str(imdb_id) if imdb_id else None,
    )
    log.info(f"🎬 Pre-caching movie: {title!r}")
    try:
        await resolve_and_cache(app, event)
    except Exception as e:
        log.error(f"Movie pre-cache {title!r}: {e}")


async def _precache_series(app: FastAPI, title: str, year, episodes: list):
    """
    Cache all episodes immediately after a series is added.
    Checks FUSE first (instant), falls back to TPB search.
    Skips episodes already cached or resolving.
    """
    db_check: CacheDB = app.state.db
    if db_check.get_setting("precache_enabled", "true") == "false":
        log.info(f"⏭️  Pre-caching disabled — skipping series: {title!r}")
        return
    if not episodes:
        log.info(f"📺 No episodes to pre-cache for {title!r}")
        return

    await asyncio.sleep(3)
    db       = app.state.db
    cooldown = int(db.get_setting("precache_cooldown_minutes", "1"))

    log.info(f"📺 Pre-caching {len(episodes)} episodes for {title!r}")
    cached_count = 0

    for ep in episodes:
        event = PlayEvent(
            media_type=MediaType.episode,
            title=title, year=year,
            season=ep["season"], episode=ep["episode"],
        )
        ck = event.cache_key()
        existing = db.get(ck)
        if existing and existing["status"] in ("cached", "resolving"):
            cached_count += 1
            continue
        try:
            await resolve_and_cache(app, event)
            cached_count += 1
            await asyncio.sleep(max(2, cooldown * 60))
        except Exception as e:
            log.debug(f"Episode pre-cache {ck}: {e}")

    log.info(f"📺 Pre-cache done: {title!r} — {cached_count}/{len(episodes)} episodes")


async def _fetch_tmdb_poster(tmdb_id, title: str, is_movie: bool, tmdb_key: str) -> str:
    """Fetch poster URL from TMDB — by ID first, title search fallback."""
    if not tmdb_key: return ""
    import httpx as _hx
    endpoint = "movie" if is_movie else "tv"
    try:
        async with _hx.AsyncClient(timeout=8) as c:
            if tmdb_id:
                r = await c.get(f"https://api.themoviedb.org/3/{endpoint}/{tmdb_id}",
                                params={"api_key": tmdb_key})
                if r.status_code == 200:
                    p = r.json().get("poster_path")
                    if p: return f"https://image.tmdb.org/t/p/w342{p}"
            # Fallback: search by title
            r2 = await c.get(f"https://api.themoviedb.org/3/search/{endpoint}",
                             params={"api_key": tmdb_key, "query": title})
            if r2.status_code == 200:
                results = r2.json().get("results", [])
                if results and results[0].get("poster_path"):
                    return f"https://image.tmdb.org/t/p/w342{results[0]['poster_path']}"
    except Exception:
        pass
    return ""


async def _cleanup_loop(app: FastAPI):
    """
    Hourly cleanup — remove entries whose 30-day TTL has expired.
    Deletes symlink, restores placeholder, removes from AllDebrid, deletes DB entry.
    """
    while True:
        await asyncio.sleep(3600)
        db = app.state.db
        s  = app.state.settings

        for entry in db.list_expired():
            ck = entry["cache_key"]
            log.info(f"⏰ TTL expired: {ck}")
            await _hard_expire(entry, db, s, app.state.alldebrid)

        purged = db.purge_expired()
        if purged:
            log.info(f"⏰ Purged {purged} expired cache entries")


# Torrent sync loop intentionally removed.
# Comparing FUSE names against AllDebrid names is unreliable due to truncation
# and causes false-positive deletions of valid cached files.
# Cache lifecycle is managed by:
#   - TTL expiry (_cleanup_loop) — removes after 30 days
#   - User remove action (api_library_remove) — removes immediately
#   - Symlink health check (_check_and_repair_symlinks) — repairs broken symlinks hourly


def _restore_placeholder(cache_key, title, year, season, episode, media_type, plex_root):
    try:
        if media_type == "movie":
            yp     = f" ({year})" if year else ""
            folder = Path(plex_root) / "movies" / f"{title}{yp}"
            ph     = folder / f"{title}{yp}.mp4"
            # Remove stale symlinks before restoring placeholder
            if folder.exists():
                for f in folder.iterdir():
                    if f.is_symlink() and f.suffix in (".mkv",".mp4",".avi",".mov",".m4v"):
                        f.unlink(missing_ok=True)
        else:
            if not season or not episode: return
            folder = Path(plex_root) / "tv" / title / f"Season {season:02d}"
            se     = f"S{season:02d}E{episode:02d}"
            ph     = folder / f"{title} - {se}.mp4"
            if folder.exists():
                for f in folder.glob(f"*{se}*.mkv"):
                    if f.is_symlink(): f.unlink(missing_ok=True)
        folder.mkdir(parents=True, exist_ok=True)
        if not ph.exists() and not ph.is_symlink():
            ph.write_bytes(_FAKE_MP4)
    except Exception as e:
        log.error(f"restore_placeholder {cache_key}: {e}")


async def _episode_sync_loop(app: FastAPI):
    """Run at startup (+30s) and hourly — audit episode placeholders against TMDB."""
    await asyncio.sleep(30)
    while True:
        try:   await _run_episode_sync(app)
        except Exception as e: log.error(f"Episode sync: {e}")
        await asyncio.sleep(3600)


async def _run_episode_sync(app: FastAPI):
    lm  = app.state.library
    db  = app.state.db
    s   = app.state.settings
    if not lm or not s.PLEX_ROOT: return

    lm.invalidate_cache()
    series_list        = await lm.get_sonarr_series(force=True)
    added_series       = [r for r in db.fake_library_list() if r["media_type"] == "series"]
    include_unreleased = db.get_setting("include_unreleased_episodes", "false") == "true"
    total_added = total_removed = 0

    # ── Audit plex-strm/movies — remove folders not in fake_library ───────────
    added_movies = {r["title"].lower() for r in db.fake_library_list() if r["media_type"] == "movie"}
    movies_root  = Path(s.PLEX_ROOT) / "movies"
    if movies_root.exists():
        for folder in movies_root.iterdir():
            if not folder.is_dir(): continue
            # Extract title from "Title (Year)" folder name
            folder_title = folder.name.rsplit(" (", 1)[0].lower()
            if folder_title not in added_movies:
                import shutil as _shutil
                _shutil.rmtree(folder, ignore_errors=True)
                log.info(f"🗑️  Removed stale movie folder: {folder.name}")

    # ── Audit plex-strm/tv — remove folders not in fake_library ──────────────
    added_tv  = {r["title"].lower() for r in db.fake_library_list() if r["media_type"] == "series"}
    tv_root   = Path(s.PLEX_ROOT) / "tv"
    if tv_root.exists():
        for folder in tv_root.iterdir():
            if not folder.is_dir(): continue
            if folder.name.lower() not in added_tv:
                import shutil as _shutil
                _shutil.rmtree(folder, ignore_errors=True)
                log.info(f"🗑️  Removed stale TV folder: {folder.name}")

    for entry in added_series:
        title     = entry["title"]
        sonarr_id = entry.get("sonarr_id")
        year      = entry.get("year")
        if not sonarr_id: continue

        updated = next((s for s in series_list if s.get("id") == sonarr_id), None)
        if not updated: continue

        requested_seasons = updated.get("requested_seasons", [])
        result = await lm.sync_series_episodes(title, sonarr_id, year, include_unreleased,
                                                requested_seasons=requested_seasons)
        total_added   += result.get("added", 0)
        total_removed += result.get("removed", 0)

        # Audit: ensure every expected episode has placeholder or symlink
        try:
            all_eps = await lm.get_episodes(sonarr_id,
                                                    include_unreleased=include_unreleased,
                                                    requested_seasons=requested_seasons or None)
            by_season: dict[int, set] = {}
            for ep in all_eps:
                by_season.setdefault(ep["season"], set()).add(ep["episode"])

            show_folder = Path(s.PLEX_ROOT) / "tv" / title
            for sn, ep_nums in by_season.items():
                sf = show_folder / f"Season {sn:02d}"
                sf.mkdir(parents=True, exist_ok=True)
                on_mp4 = set(); on_sym = set()
                if sf.exists():
                    for f in sf.iterdir():
                        m = re.search(rf"S{sn:02d}E(\d{{2}})", f.name, re.I)
                        if m:
                            n = int(m.group(1))
                            if f.is_symlink(): on_sym.add(n)
                            elif f.suffix == ".mp4": on_mp4.add(n)
                covered = on_mp4 | on_sym
                for ep_n in ep_nums - covered:
                    (sf / f"{title} - S{sn:02d}E{ep_n:02d}.mp4").write_bytes(_FAKE_MP4)
                    total_added += 1
                for ep_n in on_mp4 - ep_nums:
                    ph = sf / f"{title} - S{sn:02d}E{ep_n:02d}.mp4"
                    if ph.exists() and not ph.is_symlink():
                        ph.unlink(missing_ok=True)
                        total_removed += 1
        except Exception as e:
            log.debug(f"Audit {title}: {e}")

    if total_added or total_removed:
        log.info(f"🔄 Episode sync: +{total_added} placeholders, -{total_removed} removed")
    else:
        log.info("🔄 Episode sync: all correct")


async def _sync_all_series_episodes(app: FastAPI, include_unreleased: bool):
    db = app.state.db; lm = app.state.library
    if not lm: return
    for entry in db.fake_library_list(media_type="series"):
        sid = entry.get("sonarr_id")
        if sid:
            await lm.sync_series_episodes(entry["title"], sid, entry.get("year"), include_unreleased)


async def _load_all_torrents(app: FastAPI):
    await asyncio.sleep(2)
    alldebrid = app.state.alldebrid
    s = app.state.settings
    if not alldebrid or not FUSE_AVAILABLE or not getattr(app.state, "fuse_thread", None):
        return
    try:
        torrents = await alldebrid.get_all_torrents()
        # Build hash → torrent map for reliable lookup on restart
        hash_map: dict[str, dict] = {}  # info_hash → {name, folder, files}
        for t in torrents:
            files       = t["files"]
            folder_name = t["name"]
            if files:
                stem = Path(files[0]["n"]).stem
                if stem and folder_name and stem.startswith(folder_name.rstrip("-")):
                    folder_name = stem
            register_torrent(folder_name, files)
            t["_folder"] = folder_name
            # Store by hash for reliable restart recovery
            h = t.get("hash", "").lower()
            if h:
                hash_map[h] = {"name": t["name"], "folder": folder_name, "files": files}

        log.info(f"✅ {len(torrents)} torrents loaded into FUSE")
        if s.PLEX_ROOT:
            _restore_symlinks(app, hash_map)
    except Exception as e:
        log.error(f"_load_all_torrents: {e}", exc_info=True)


def _restore_symlinks(app, hash_map: dict = None):
    """
    Restore symlinks on startup.
    Uses magnet_link hash to find the exact torrent — no name matching needed.
    Falls back to name-based FUSE search only if hash not available.
    """
    import re as _re
    db = app.state.db
    s  = app.state.settings
    if not s.PLEX_ROOT or not s.FUSE_SYMLINK_ROOT:
        return
    if hash_map is None:
        hash_map = {}

    trusted = restored = missing = 0

    for entry in db.list_all():
        if entry["status"] != "cached":
            continue
        strm = entry.get("strm_path")
        ck   = entry["cache_key"]

        # Step 1: if symlink exists on disk, try to validate/fix its FUSE target
        if strm:
            p = Path(strm)
            if p.is_symlink():
                target = str(p.readlink())
                if s.FUSE_SYMLINK_ROOT in target:
                    rel   = target.replace(s.FUSE_SYMLINK_ROOT, "").lstrip("/")
                    parts = rel.split("/", 1)
                    if len(parts) == 2:
                        folder_name, filename = parts
                        # Check if registered under this exact name
                        if get_torrent_file(folder_name, filename):
                            trusted += 1
                            continue
                        # Not registered — find the torrent by hash from magnet_link
                        magnet = entry.get("magnet_link", "")
                        m = _re.search(r"btih:([a-fA-F0-9]{40})", magnet or "", _re.I)
                        if m:
                            h = m.group(1).lower()
                            if h in hash_map:
                                # Re-register under the current folder name from AllDebrid
                                t = hash_map[h]
                                new_folder = t["folder"]
                                # Find the specific file for this episode
                                target_file = _pick_file(t["files"], entry)
                                if target_file:
                                    new_filename = target_file["n"]
                                    new_target   = get_fuse_path(new_folder, new_filename, s.FUSE_SYMLINK_ROOT)
                                    # Update symlink to point to new path
                                    p.unlink(missing_ok=True)
                                    p.symlink_to(new_target)
                                    db.update_cached(ck, magnet, entry.get("stream_url",""),
                                                     new_folder, entry.get("quality","unknown"), str(p))
                                    trusted += 1
                                    continue
                        # Hash not found — symlink exists but torrent gone from AllDebrid
                        # Keep symlink as-is; health check will handle it
                        trusted += 1
                        continue

        # Step 2: no symlink — find by hash first, then title search
        magnet = entry.get("magnet_link", "")
        m = _re.search(r"btih:([a-fA-F0-9]{40})", magnet or "", _re.I)
        torrent_data = None
        if m:
            h = m.group(1).lower()
            if h in hash_map:
                torrent_data = hash_map[h]

        if torrent_data:
            target_file = _pick_file(torrent_data["files"], entry)
            if target_file:
                folder_name = torrent_data["folder"]
                filename    = target_file["n"]
                fuse_virtual = get_fuse_path(folder_name, filename, s.FUSE_SYMLINK_ROOT)
                link = _make_plex_symlink(ck, entry["title"], entry.get("year"),
                                          entry.get("season"), entry.get("episode"),
                                          entry["media_type"], s.PLEX_ROOT, fuse_virtual, filename)
                if link:
                    db.update_cached(ck, magnet, entry.get("stream_url",""),
                                     folder_name, entry.get("quality","unknown"), str(link))
                    restored += 1
                    continue

        # Step 3: fallback — fuzzy title search in FUSE
        fuse_match = _find_in_fuse(entry["title"], entry.get("year"),
                                    entry.get("season"), entry.get("episode"))
        if not fuse_match:
            missing += 1
            continue

        torrent_name, filename, _ = fuse_match
        fuse_virtual = get_fuse_path(torrent_name, filename, s.FUSE_SYMLINK_ROOT)
        link = _make_plex_symlink(ck, entry["title"], entry.get("year"),
                                   entry.get("season"), entry.get("episode"),
                                   entry["media_type"], s.PLEX_ROOT, fuse_virtual, filename)
        if link:
            db.update_cached(ck, entry.get("magnet_link",""), entry.get("stream_url",""),
                             torrent_name, entry.get("quality","unknown"), str(link))
            restored += 1

    log.info(f"✅ Symlinks: {trusted} trusted, {restored} restored, {missing} not in FUSE")


def _pick_file(files: list, entry: dict) -> Optional[dict]:
    """Pick the right file from a torrent for this DB entry."""
    season  = entry.get("season")
    episode = entry.get("episode")
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}

    if season and episode:
        se = f"S{season:02d}E{episode:02d}".upper()
        for f in files:
            if se in f.get("n", "").upper() and any(f["n"].lower().endswith(e) for e in video_exts):
                return f

    # Fallback: largest video file
    videos = [f for f in files if any(f.get("n","").lower().endswith(e) for e in video_exts)]
    return max(videos, key=lambda f: f.get("s", 0)) if videos else None


async def _symlink_health_loop(app: FastAPI):
    # Wait for FUSE to stabilise
    prev = 0; stable = 0
    for _ in range(180):
        await asyncio.sleep(1)
        count = len(list_torrents())
        if count > 0 and count == prev:
            stable += 1
            if stable >= 5: break
        else: stable = 0
        prev = count

    log.info(f"Starting symlink health check ({prev} torrents in FUSE)")
    while True:
        try:   await _check_and_repair_symlinks(app)
        except Exception as e: log.error(f"Symlink health: {e}")
        await asyncio.sleep(3600)


async def _check_and_repair_symlinks(app: FastAPI):
    db = app.state.db; s = app.state.settings
    if not s.PLEX_ROOT: return

    cached  = [e for e in db.list_all() if e["status"] == "cached"]
    broken  = []; ok = 0

    for entry in cached:
        strm  = entry.get("strm_path")
        issue = None
        try:
            if strm:
                p = Path(strm)
                if not p.is_symlink():
                    issue = "missing"
                else:
                    target = str(p.readlink())
                    if s.FUSE_SYMLINK_ROOT in target:
                        # Symlink points into FUSE — trust it as long as it's a symlink.
                        # FUSE lazy-loads files so .exists() is unreliable.
                        # Only flag broken if the torrent folder is truly gone from FUSE
                        # AND we can't find it via title search either.
                        rel   = target.replace(s.FUSE_SYMLINK_ROOT,"").lstrip("/")
                        parts = rel.split("/", 1)
                        if len(parts) == 2:
                            if get_torrent_file(parts[0], parts[1]):
                                # Registered and found — all good
                                ok += 1
                                db.refresh_ttl(entry["cache_key"])
                            else:
                                # Not found under that key — try fuzzy search
                                m = _find_in_fuse(entry["title"], entry.get("year"),
                                                   entry.get("season"), entry.get("episode"))
                                if m:
                                    # Found under different name — re-point symlink
                                    new_folder, new_file, _ = m
                                    new_target = get_fuse_path(new_folder, new_file, s.FUSE_SYMLINK_ROOT)
                                    p.unlink(missing_ok=True)
                                    p.symlink_to(new_target)
                                    db.update_cached(entry["cache_key"],
                                                     entry.get("magnet_link",""),
                                                     entry.get("stream_url",""),
                                                     new_folder, entry.get("quality","unknown"),
                                                     str(p))
                                    ok += 1
                                    db.refresh_ttl(entry["cache_key"])
                                else:
                                    # Truly not in FUSE — needs re-resolve
                                    issue = "not in FUSE"
                        else:
                            ok += 1
                    else:
                        if p.exists(): ok += 1
                        else:          issue = "dangling"
            else:
                ok += 1  # no strm_path means no symlink expected yet
        except Exception as e:
            log.debug(f"Health check {entry['cache_key']}: {e}")

        if issue: broken.append((entry, issue))

    total = len(cached)
    if not broken:
        log.info(f"✅ Symlink check: {ok}/{total} OK"); return

    log.info(f"🔧 Symlink check: {len(broken)} broken, {ok} OK / {total}")

    # Write placeholders for all broken entries first
    for entry, _ in broken:
        try:
            mtype = entry["media_type"]; t = entry["title"]
            yr = entry.get("year"); sn = entry.get("season"); ep = entry.get("episode")
            if mtype == "movie":
                folder = Path(s.PLEX_ROOT) / "movies" / f"{t}{' ('+str(yr)+')' if yr else ''}"
                ph = folder / f"{t}{' ('+str(yr)+')' if yr else ''}.mp4"
            elif sn and ep:
                folder = Path(s.PLEX_ROOT) / "tv" / t / f"Season {sn:02d}"
                ph = folder / f"{t} - S{sn:02d}E{ep:02d}.mp4"
            else: continue
            folder.mkdir(parents=True, exist_ok=True)
            if not ph.exists() and not ph.is_symlink():
                ph.write_bytes(_FAKE_MP4)
        except Exception: pass

    for entry, issue in broken:
        log.info(f"  🔧 {entry['cache_key']}: {issue}")
        fuse_match = _find_in_fuse(entry["title"], entry.get("year"),
                                    entry.get("season"), entry.get("episode"))
        if fuse_match:
            torrent_name, filename, _ = fuse_match
            fuse_virtual = get_fuse_path(torrent_name, filename, s.FUSE_SYMLINK_ROOT)
            link = _make_plex_symlink(entry["cache_key"], entry["title"], entry.get("year"),
                                      entry.get("season"), entry.get("episode"), entry["media_type"],
                                      s.PLEX_ROOT, fuse_virtual, filename)
            if link:
                db.update_cached(entry["cache_key"], entry.get("magnet_link",""),
                                 entry.get("stream_url",""), torrent_name,
                                 entry.get("quality","unknown"), str(link))
                log.info(f"  ✅ Relinked: {entry['cache_key']}")
                continue

        # Not in FUSE — re-resolve (placeholder already written above)
        event = PlayEvent(media_type=MediaType(entry["media_type"]), title=entry["title"],
                          year=entry.get("year"), season=entry.get("season"), episode=entry.get("episode"))
        try:
            db.update_status(entry["cache_key"], "not_found")
            await resolve_and_cache(app, event)
            await asyncio.sleep(2)
        except Exception as e:
            db.update_status(entry["cache_key"], "cached")
            log.error(f"  ❌ Re-resolve failed: {entry['cache_key']}: {e}")


def _find_in_fuse(title: str, year, season, episode) -> Optional[tuple]:
    def norm(s):
        s = s.lower().replace("'","").replace("\u2019","")
        s = re.sub(r"[._]", " ", s)
        return s.split()

    title_words = norm(title)
    if not title_words: return None
    video_exts = {".mkv",".mp4",".avi",".mov",".m4v"}

    for torrent_name in list_torrents():
        t_words = norm(torrent_name)
        if not all(w in t_words for w in title_words): continue
        if year and str(year) not in torrent_name: continue
        for fname in list_files(torrent_name):
            if not any(fname.lower().endswith(e) for e in video_exts): continue
            if season and episode:
                if f"S{season:02d}E{episode:02d}".upper() not in fname.upper(): continue
            elif season:
                if f"S{season:02d}".upper() not in fname.upper(): continue
            f = get_torrent_file(torrent_name, fname)
            if f: return torrent_name, fname, f
    return None


def _detect_quality(name: str) -> str:
    n = name.lower()
    for q in ("2160p","4k","uhd","1080p","720p","480p"):
        if q in n: return q
    return "unknown"


def _parse_season_episode(filename: str) -> Optional[tuple[int, int]]:
    """Extract (season, episode) from a filename. Returns None if not found."""
    import re as _re
    m = _re.search(r'[Ss](\d{1,2})[Ee](\d{1,2})', filename)
    if m:
        return int(m.group(1)), int(m.group(2))
    return None


def _symlink_pack_episodes(
    app, db, files: list, magnet_str: str, torrent_name: str, quality: str,
    title: str, year, season: int, event_episode: int,
    media_type: str, plex_root: str, debridarr_base_url: str,
    fuse_thread, fuse_symlink_root: str,
) -> int:
    """
    For every video file in a season/series pack, create a DB cache entry
    and a Plex symlink (or .strm if FUSE is unavailable).
    Skips the episode that was already handled by the main resolve path.
    Returns the count of additional episodes symlinked.
    """
    import re as _re
    video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
    count = 0
    for f in files:
        fname = f.get("n", "")
        if not any(fname.lower().endswith(e) for e in video_exts):
            continue
        ep_info = _parse_season_episode(fname)
        if not ep_info:
            continue
        ep_season, ep_episode = ep_info
        if ep_season != season:
            continue              # multi-season pack — only handle the requested season
        if ep_episode == event_episode:
            continue              # already handled by main resolve path

        ad_link = f.get("l", "")
        if not ad_link:
            continue

        # Build a PlayEvent for this episode so cache_key is correct
        from app.models import PlayEvent, MediaType
        ep_event = PlayEvent(
            media_type=MediaType.episode,
            title=title, year=year,
            season=ep_season, episode=ep_episode,
        )
        ck = ep_event.cache_key()

        existing = db.get(ck)
        if existing and existing["status"] == "cached":
            log.debug(f"  Pack episode already cached: {ck}")
            continue

        # Write DB entry
        db.upsert(ck, ep_event, status="resolving")

        # Create symlink or strm
        strm_path = None
        if plex_root:
            if FUSE_AVAILABLE and fuse_thread:
                stem = Path(fname).stem
                fuse_folder = stem if (stem and torrent_name and stem.startswith(torrent_name.rstrip("-"))) else torrent_name
                fuse_virtual = get_fuse_path(fuse_folder, fname, fuse_symlink_root)
                link = _make_plex_symlink(ck, title, year, ep_season, ep_episode,
                                          media_type, plex_root, fuse_virtual, fname)
                strm_path = str(link) if link else None
            else:
                p = write_strm(cache_key=ck, title=title, year=year,
                               season=ep_season, episode=ep_episode,
                               media_type=media_type,
                               debridarr_base_url=debridarr_base_url,
                               plex_root=plex_root)
                strm_path = str(p) if p else None

        db.update_cached(ck, magnet_str, ad_link, torrent_name, quality, strm_path)
        log.info(f"  📦 Pack episode: S{ep_season:02d}E{ep_episode:02d} → {fname}")
        count += 1

    return count


def _make_plex_symlink(cache_key, title, year, season, episode,
                       media_type, plex_root, target, video_name) -> Optional[Path]:
    """Placeholder-first symlink creation. Never leaves Plex with an empty slot."""
    if media_type == "movie":
        yp     = f" ({year})" if year else ""
        folder = Path(plex_root) / "movies" / f"{title}{yp}"
        ph     = folder / f"{title}{yp}.mp4"
    else:
        sf     = f"Season {season:02d}" if season else "Season 00"
        folder = Path(plex_root) / "tv" / title / sf
        se     = f"S{season:02d}E{episode:02d}" if (season and episode) else "S00E00"
        ph     = folder / f"{title} - {se}.mp4"

    try:
        folder.mkdir(parents=True, exist_ok=True)
        if not ph.exists() and not ph.is_symlink():
            ph.write_bytes(_FAKE_MP4)
    except Exception as e:
        log.error(f"Placeholder write {cache_key}: {e}")

    try:
        # Remove stale symlinks for this episode
        if media_type == "movie":
            for f in folder.iterdir():
                if f.is_symlink() and f.suffix in (".mkv",".mp4",".avi",".mov",".m4v"):
                    f.unlink(missing_ok=True)
        elif season and episode:
            se_pat = f"S{season:02d}E{episode:02d}".upper()
            for f in folder.iterdir():
                if f.is_symlink() and se_pat in f.name.upper():
                    f.unlink(missing_ok=True)

        link = folder / video_name
        if link.is_symlink() or link.exists(): link.unlink(missing_ok=True)
        link.symlink_to(target)

        if link.is_symlink():
            if ph.exists() and not ph.is_symlink(): ph.unlink(missing_ok=True)
            log.info(f"🔗 Symlink: {link.name} → {target}")
            return link
        else:
            if not ph.exists(): ph.write_bytes(_FAKE_MP4)
            return None
    except Exception as e:
        log.error(f"symlink {cache_key}: {e}")
        try:
            if not ph.exists() and not ph.is_symlink():
                folder.mkdir(parents=True, exist_ok=True)
                ph.write_bytes(_FAKE_MP4)
        except Exception: pass
        return None


async def _verify_episode_with_tmdb(tmdb_id, tvdb_id, season, episode, title, tmdb_key=""):
    if not tmdb_key: return season, episode
    import httpx as _hx
    try:
        if tvdb_id:
            async with _hx.AsyncClient(timeout=10) as c:
                r = await c.get(f"https://api.themoviedb.org/3/find/{tvdb_id}",
                                params={"api_key": tmdb_key, "external_source": "tvdb_id"})
                if r.status_code == 200:
                    eps = r.json().get("tv_episode_results", [])
                    if eps:
                        e   = eps[0]
                        ts  = e.get("season_number", season)
                        tep = e.get("episode_number", episode)
                        if ts != season or tep != episode:
                            log.info(f"TMDB corrected {title} S{season:02d}E{episode:02d} → S{ts:02d}E{tep:02d}")
                        return ts, tep
    except Exception as e:
        log.debug(f"TMDB lookup {title}: {e}")
    return season, episode


async def resolve_and_cache(app: FastAPI, event: PlayEvent):
    db = app.state.db; alldebrid = app.state.alldebrid; s = app.state.settings
    cache_key = event.cache_key()

    existing = db.get(cache_key)
    if existing and existing["status"] == "cached":
        log.info(f"✅ Cache hit: {cache_key}")
        return

    # Register job and acquire worker slot
    ep = f" S{event.season:02d}E{event.episode:02d}" if event.season and event.episode else ""
    jid, cancel_event = _job_start(f"{event.title}{ep}", job_type="resolve")
    sem = _get_semaphore(app)
    try:
        async with sem:
            if cancel_event.is_set():
                _job_done(jid, "cancelled")
                return
            await _resolve_and_cache_inner(app, event, cancel_event)
        _job_done(jid)
    except asyncio.CancelledError:
        _job_done(jid, "cancelled")
        raise
    except Exception as e:
        _job_done(jid, str(e))
        raise


async def _resolve_and_cache_inner(app: FastAPI, event: PlayEvent, cancel_event: asyncio.Event = None):
    db = app.state.db; alldebrid = app.state.alldebrid; s = app.state.settings
    cache_key = event.cache_key()

    log.info(f"🔍 Resolving: {cache_key}")
    db.upsert(cache_key, event, status="resolving")

    try:
        # Verify episode numbering
        if event.media_type.value == "episode" and event.season and event.episode:
            tmdb_key = db.get_setting("tmdb_api_key", "")
            cs, cep = await _verify_episode_with_tmdb(
                event.tmdb_id, event.tvdb_id, event.season, event.episode, event.title, tmdb_key)
            if cs != event.season or cep != event.episode:
                event      = event.model_copy(update={"season": cs, "episode": cep})
                cache_key  = event.cache_key()
                existing   = db.get(cache_key)
                if existing and existing["status"] == "cached":
                    log.info(f"✅ Cache hit (corrected): {cache_key}"); return
                db.upsert(cache_key, event, status="resolving")

        # Strategy
        s_cfg = db.get_all_settings()
        if event.media_type.value == "episode":
            lm = app.state.library; is_ended = False
            if lm:
                try:
                    sl = await lm.get_sonarr_series()
                    sm = next((x for x in sl if x["title"].lower() == event.title.lower()), None)
                    if sm: is_ended = sm.get("status","").lower() in ("ended","cancelled","canceled")
                except Exception: pass
            strategy         = s_cfg.get("series_completed_strategy","series_pack") if is_ended else s_cfg.get("series_ongoing_strategy","season_pack")
            preferred_quality = s_cfg.get("series_preferred_quality","1080p")
            fallback_any      = s_cfg.get("series_fallback_any_quality","true") == "true"
        else:
            strategy         = "movie"
            preferred_quality = s_cfg.get("movie_preferred_quality","1080p")
            fallback_any      = s_cfg.get("movie_fallback_any_quality","true") == "true"

        # Check FUSE first
        fuse_match = _find_in_fuse(event.title, event.year, event.season, event.episode)
        if fuse_match:
            torrent_name, filename, fuse_file = fuse_match
            log.info(f"✅ Found in FUSE — symlinking directly")
            fuse_virtual = get_fuse_path(torrent_name, filename, s.FUSE_SYMLINK_ROOT)
            link = _make_plex_symlink(cache_key, event.title, event.year, event.season,
                                      event.episode, event.media_type.value, s.PLEX_ROOT,
                                      fuse_virtual, filename)
            db.update_cached(cache_key, "", fuse_file.get("l",""), torrent_name,
                             _detect_quality(filename), str(link) if link else None)
            return

        # Check cancellation before expensive AllDebrid search
        if cancel_event and cancel_event.is_set():
            db.update_status(cache_key, "not_found")
            log.info(f"🚫 Cancelled: {cache_key}")
            return

        # Search TPB
        log.info(f"🔎 Searching TPB for: {event.title!r}")
        results = await alldebrid.search_cached(
            title=event.title, media_type=event.media_type.value,
            year=event.year, season=event.season, episode=event.episode,
            imdb_id=event.imdb_id, strategy=strategy,
            preferred_quality=preferred_quality, fallback_any=fallback_any,
        )
        if not results:
            log.warning(f"❌ No results: {cache_key}")
            db.update_status(cache_key, "not_found")

            # ── Ongoing series fallback: no pack found → try individual episodes ──
            if (event.media_type.value == "episode"
                    and event.season
                    and strategy in ("season_pack", "episode")
                    and not is_ended):
                asyncio.create_task(
                    _resolve_season_episodes(app, event, preferred_quality, fallback_any)
                )
                log.info(f"📺 Ongoing series — queuing individual episode search for {event.title} S{event.season:02d}")
            return

        best = results[0]
        log.info(f"🎯 {best['name']} cached={best['cached']} q={best.get('quality','?')}")

        result = await alldebrid.add_magnet(best["magnet"])
        if not result:
            db.update_status(cache_key, "unlock_failed"); return

        magnet_id, files = result
        torrent_name = best["name"]

        # Find episode-specific file
        target_file = None
        if event.media_type.value == "episode" and event.season and event.episode:
            se_pat = f"S{event.season:02d}E{event.episode:02d}".upper()
            for f in files:
                if se_pat in f.get("n","").upper(): target_file = f; break
        if not target_file:
            target_file = max(files, key=lambda f: f.get("s",0))

        filename  = target_file.get("n", torrent_name)
        ad_link   = target_file.get("l","")
        file_size = target_file.get("s", 0)

        # Resolve FUSE folder name (handle truncated names)
        stem = Path(filename).stem if filename else torrent_name
        fuse_folder = stem if (stem and torrent_name and stem.startswith(torrent_name.rstrip("-"))) else torrent_name

        if not ad_link:
            log.error(f"No file link for {cache_key}")
            db.update_status(cache_key, "unlock_failed"); return

        log.info(f"📁 {fuse_folder}/{filename} ({file_size} bytes)")

        strm_path = None
        fuse_thread = getattr(app.state, "fuse_thread", None)

        if s.PLEX_ROOT:
            if FUSE_AVAILABLE and fuse_thread:
                register_torrent(fuse_folder, files)
                fuse_virtual = get_fuse_path(fuse_folder, filename, s.FUSE_SYMLINK_ROOT)
                log.info(f"📂 FUSE: {fuse_virtual}")
                link = _make_plex_symlink(cache_key, event.title, event.year, event.season,
                                          event.episode, event.media_type.value, s.PLEX_ROOT,
                                          fuse_virtual, filename)
                strm_path = str(link) if link else None
                log.info(f"🔗 {link} → {fuse_virtual}")
            else:
                p = write_strm(cache_key=cache_key, title=event.title, year=event.year,
                               season=event.season, episode=event.episode,
                               media_type=event.media_type.value,
                               debridarr_base_url=s.DEBRIDARR_BASE_URL, plex_root=s.PLEX_ROOT)
                strm_path = str(p) if p else None

        db.update_cached(cache_key, best["magnet"], ad_link, torrent_name,
                         best.get("quality","unknown"), strm_path)
        log.info(f"✅ Done: {cache_key}")

        # ── Season/series pack: symlink requested episode NOW, rest after 60s ──
        if (event.media_type.value == "episode"
                and event.season
                and strategy in ("season_pack", "series_pack")
                and len(files) > 1):
            # Delay the rest so the user can start watching the selected episode
            # without waiting for all other symlinks to be created first
            async def _delayed_pack_symlinks():
                await asyncio.sleep(260)
                extra = _symlink_pack_episodes(
                    app=app, db=db, files=files,
                    magnet_str=best["magnet"], torrent_name=torrent_name,
                    quality=best.get("quality", "unknown"),
                    title=event.title, year=event.year, season=event.season,
                    event_episode=event.episode,
                    media_type=event.media_type.value,
                    plex_root=s.PLEX_ROOT,
                    debridarr_base_url=s.DEBRIDARR_BASE_URL,
                    fuse_thread=getattr(app.state, "fuse_thread", None),
                    fuse_symlink_root=s.FUSE_SYMLINK_ROOT,
                )
                if extra:
                    log.info(f"📦 Pack: symlinked {extra} remaining episodes for {event.title} S{event.season:02d} (delayed 60s)")
            asyncio.create_task(_delayed_pack_symlinks())
            log.info(f"📦 Pack found — requested episode ready now, rest in 60s")

        if event.media_type.value == "episode" and event.season and event.episode:
            if db.get_setting("precache_enabled", "true") != "false":
                cooldown = int(db.get_setting("precache_cooldown_minutes","1"))
                asyncio.create_task(_precache_next_episodes(app, event, cooldown_minutes=cooldown))

    except Exception as e:
        log.error(f"❌ {cache_key}: {e}", exc_info=True)
        db.update_status(cache_key, "error")


async def _resolve_season_episodes(
    app: FastAPI,
    event: PlayEvent,
    preferred_quality: str,
    fallback_any: bool,
    delay_between: int = 10,
):
    """
    Fallback for ongoing series with no season pack available.
    Searches for each individual episode in the season and resolves them,
    starting with the requested episode and working outward.

    Called when strategy=season_pack|episode and no pack is found.
    Staggered by delay_between seconds to avoid hammering AllDebrid.
    """
    db        = app.state.db
    lm        = app.state.library
    alldebrid = app.state.alldebrid

    title  = event.title
    season = event.season
    year   = event.year
    target = event.episode

    # Get the full episode list for this season from Overseerr/Sonarr
    episodes_in_season = []
    if lm:
        try:
            sl = await lm.get_sonarr_series()
            sm = next((x for x in sl if x["title"].lower() == title.lower()), None)
            if sm:
                all_eps = await lm.get_episodes(sm["id"], include_unreleased=False)
                episodes_in_season = [
                    e["episode"] for e in all_eps
                    if e["season"] == season
                ]
        except Exception as e:
            log.warning(f"_resolve_season_episodes: could not get episode list: {e}")

    if not episodes_in_season:
        # Fallback: assume standard season of up to 20 episodes
        episodes_in_season = list(range(1, 21))

    # Sort: start with the requested episode, then forward, then backward
    before = sorted([e for e in episodes_in_season if e < target], reverse=True)
    after  = sorted([e for e in episodes_in_season if e > target])
    ordered = [target] + after + before   # target first, then forward, then backfill

    log.info(f"📺 Individual episode search for {title} S{season:02d} — {len(ordered)} episodes")

    resolved = 0
    for epn in ordered:
        ep_event = PlayEvent(
            media_type=MediaType.episode,
            title=title, year=year,
            season=season, episode=epn,
        )
        ck = ep_event.cache_key()
        existing = db.get(ck)
        if existing and existing["status"] == "cached":
            resolved += 1
            continue
        if existing and existing["status"] == "resolving":
            continue

        try:
            results = await alldebrid.search_cached(
                title=title, media_type="episode", year=year,
                season=season, episode=epn,
                strategy="episode",
                preferred_quality=preferred_quality,
                fallback_any=fallback_any,
            )
            if results:
                # Resolve this episode
                asyncio.create_task(resolve_and_cache(app, ep_event))
                resolved += 1
                log.debug(f"  📺 Queued resolve: {title} S{season:02d}E{epn:02d}")
            else:
                log.debug(f"  ⏭  No torrent: {title} S{season:02d}E{epn:02d}")
        except Exception as e:
            log.error(f"  Episode search {title} S{season:02d}E{epn:02d}: {e}")

        await asyncio.sleep(delay_between)

    log.info(f"📺 Individual episode resolve queued {resolved}/{len(ordered)} for {title} S{season:02d}")



async def _precache_next_episodes(app: FastAPI, event: PlayEvent, count: int = 3, cooldown_minutes: int = 1):
    await asyncio.sleep(5)
    db = app.state.db; lm = app.state.library
    title = event.title; season = event.season; episode = event.episode; year = event.year

    season_size = None
    if lm:
        try:
            sl = await lm.get_sonarr_series()
            series = next((s for s in sl if s["title"].lower() == title.lower()), None)
            if series:
                curr = next((s for s in series.get("seasons",[]) if s.get("season_number") == season), None)
                if curr: season_size = curr.get("episode_count")
        except Exception: pass

    if not season_size: return
    log.info(f"⏭️  Pre-caching '{title}' S{season:02d} ({season_size} eps)")

    all_eps = list(range(1, episode)) + list(range(episode+1, season_size+1))
    for ep in all_eps:
        fake = PlayEvent(media_type=event.media_type, title=title, year=year, season=season, episode=ep)
        ck   = fake.cache_key()
        existing = db.get(ck)
        if existing and existing["status"] in ("cached","resolving"): continue
        try:
            await resolve_and_cache(app, fake)
            await asyncio.sleep(max(3, cooldown_minutes * 60))
        except Exception as e:
            log.debug(f"Pre-cache {ck}: {e}")
