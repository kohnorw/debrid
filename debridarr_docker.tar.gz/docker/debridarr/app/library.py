"""
Library manager — pulls approved requests from Overseerr.

Overseerr API:
  GET /api/v1/request?take=100&skip=0&filter=all  → {results: [MediaRequest]}
  GET /api/v1/movie/{tmdbId}                       → movie details
  GET /api/v1/tv/{tmdbId}                          → TV details (uses TMDB id, not TVDB)

MediaRequest.status:  1=PENDING, 2=APPROVED, 3=DECLINED
MediaInfo.status:     1=UNKNOWN, 2=PENDING, 3=PROCESSING,
                      4=PARTIALLY_AVAILABLE, 5=AVAILABLE
MediaInfo.mediaType:  "movie" or "tv"
"""

import logging
import shutil
import struct
import time
from datetime import date
from pathlib import Path
from typing import Optional

import httpx

log = logging.getLogger("debridarr.library")


# ── Fake MP4 placeholder ───────────────────────────────────────────────────────

def _make_fake_mp4() -> bytes:
    def box(t, p):
        return struct.pack(">I", 8 + len(p)) + t + p
    ftyp = box(b"ftyp", b"mp42\x00\x00\x00\x00mp42isom")
    mvhd = box(b"mvhd",
        b"\x00" * 12
        + struct.pack(">I", 1000) + struct.pack(">I", 1000)
        + struct.pack(">I", 0x00010000) + struct.pack(">H", 0x0100)
        + b"\x00" * 10
        + struct.pack(">9i", 0x00010000,0,0, 0,0x00010000,0, 0,0,0x40000000)
        + b"\x00" * 24 + struct.pack(">I", 2)
    )
    return ftyp + box(b"moov", mvhd)


_FAKE_MP4 = _make_fake_mp4()

_cache: dict[str, tuple[float, list]] = {}
_TTL = 120


class LibraryManager:
    def __init__(
        self,
        overseerr_url: str = "",
        overseerr_key: str = "",
        plex_root: str = "",
        # legacy ignored params
        sonarr_url: str = "", sonarr_key: str = "",
        radarr_url: str = "", radarr_key: str = "",
    ):
        self.url = overseerr_url.rstrip("/")
        self.key = overseerr_key
        self.plex_root = plex_root
        self._http = httpx.AsyncClient(timeout=15)

    def _headers(self) -> dict:
        return {"X-Api-Key": self.key}

    async def _get(self, path: str, params: dict = None) -> dict:
        r = await self._http.get(
            f"{self.url}/api/v1{path}",
            headers=self._headers(),
            params=params or {},
        )
        r.raise_for_status()
        return r.json()

    # ── Fetch all requests from Overseerr ──────────────────────────────────────

    async def _get_all_requests(self, media_type: str, force: bool = False) -> list[dict]:
        """
        Fetch all requests of given type ('movie' or 'tv') from Overseerr.
        Returns raw request objects with media details already fetched.
        """
        cache_key = f"overseerr::{media_type}"
        if not force and cache_key in _cache:
            ts, data = _cache[cache_key]
            if time.time() - ts < _TTL:
                return data

        if not self.url or not self.key:
            return []

        results = []
        skip = 0
        seen_tmdb: set[int] = set()

        while True:
            try:
                data = await self._get("/request", {
                    "take": 100,
                    "skip": skip,
                    "filter": "all",
                    "sort": "added",
                })
            except Exception as e:
                log.error(f"Overseerr request fetch failed: {e}")
                break

            requests = data.get("results", [])
            if not requests:
                break

            for req in requests:
                media = req.get("media", {})

                # Filter by media type
                if media.get("mediaType") != media_type:
                    continue

                # Only include non-declined requests
                req_status = req.get("status", 0)
                if req_status == 3:  # DECLINED
                    continue

                tmdb_id = media.get("tmdbId")
                if not tmdb_id or tmdb_id in seen_tmdb:
                    continue
                seen_tmdb.add(tmdb_id)

                try:
                    if media_type == "movie":
                        details = await self._get(f"/movie/{tmdb_id}")
                        results.append({
                            "id":       tmdb_id,
                            "title":    details.get("title", "Unknown"),
                            "year":     int(details.get("releaseDate", "0")[:4]) if details.get("releaseDate") else None,
                            "tmdb_id":  tmdb_id,
                            "imdb_id":  details.get("externalIds", {}).get("imdbId", ""),
                            "poster":   f"https://image.tmdb.org/t/p/w300{details['posterPath']}" if details.get("posterPath") else "",
                            "overview": details.get("overview", ""),
                            "status":   media.get("status", 1),
                            "has_file": media.get("status", 1) == 5,
                        })
                    else:
                        details = await self._get(f"/tv/{tmdb_id}")
                        seasons = [
                            {
                                "season_number": s["seasonNumber"],
                                "episode_count": s.get("episodeCount", 0),
                            }
                            for s in details.get("seasons", [])
                            if s.get("seasonNumber", 0) > 0
                        ]
                        results.append({
                            "id":           tmdb_id,
                            "title":        details.get("name", "Unknown"),
                            "year":         int(details.get("firstAirDate", "0")[:4]) if details.get("firstAirDate") else None,
                            "tvdb_id":      details.get("externalIds", {}).get("tvdbId"),
                            "tmdb_id":      tmdb_id,
                            "imdb_id":      details.get("externalIds", {}).get("imdbId", ""),
                            "poster":       f"https://image.tmdb.org/t/p/w300{details['posterPath']}" if details.get("posterPath") else "",
                            "overview":     details.get("overview", ""),
                            "status":       media.get("status", 1),
                            "seasons":      seasons,
                            "season_count": len(seasons),
                        })
                except Exception as e:
                    log.debug(f"Failed to get {media_type} details tmdb:{tmdb_id}: {e}")

            if len(requests) < 100:
                break
            skip += 100

        results.sort(key=lambda x: x["title"].lstrip("The ").lstrip("A "))
        _cache[cache_key] = (time.time(), results)
        log.info(f"Overseerr: {len(results)} {media_type} requests fetched")
        return results

    # ── Public API (named to match existing calls in main.py) ─────────────────

    async def get_radarr_movies(self, force: bool = False) -> list[dict]:
        return await self._get_all_requests("movie", force)

    async def get_sonarr_series(self, force: bool = False) -> list[dict]:
        return await self._get_all_requests("tv", force)

    async def get_sonarr_episodes(self, series_id: int, include_unreleased: bool = False) -> list[dict]:
        """Fetch episodes for a TV series via Overseerr → TMDB."""
        cache_key = f"overseerr::episodes::{series_id}"
        if cache_key in _cache:
            ts, data = _cache[cache_key]
            if time.time() - ts < _TTL:
                return self._filter_episodes(data, include_unreleased)
        try:
            details = await self._get(f"/tv/{series_id}")
            episodes = []
            for season in details.get("seasons", []):
                sn = season.get("seasonNumber", 0)
                if sn == 0:
                    continue
                try:
                    sd = await self._get(f"/tv/{series_id}/season/{sn}")
                    for ep in sd.get("episodes", []):
                        episodes.append({
                            "season":   sn,
                            "episode":  ep.get("episodeNumber", 0),
                            "title":    ep.get("name", ""),
                            "air_date": ep.get("airDate", ""),
                            "has_file": False,
                        })
                except Exception:
                    pass
            _cache[cache_key] = (time.time(), episodes)
            return self._filter_episodes(episodes, include_unreleased)
        except Exception as e:
            log.error(f"Failed to fetch episodes for {series_id}: {e}")
            return []

    def _filter_episodes(self, episodes: list, include_unreleased: bool) -> list:
        if include_unreleased:
            return [e for e in episodes if e.get("season", 0) > 0]
        today = date.today().isoformat()
        return [
            e for e in episodes
            if e.get("season", 0) > 0
            and e.get("air_date", "") != ""
            and e.get("air_date", "") <= today
        ]

    # ── Fake file creation ─────────────────────────────────────────────────────

    def create_fake_movie(self, title: str, year: Optional[int]) -> Optional[Path]:
        if not self.plex_root:
            return None
        try:
            year_part = f" ({year})" if year else ""
            folder = Path(self.plex_root) / "movies" / f"{title}{year_part}"
            path = folder / f"{title}{year_part}.mp4"
            folder.mkdir(parents=True, exist_ok=True)
            if not path.exists():
                path.write_bytes(_FAKE_MP4)
            log.info(f"🎬 Fake movie: {path}")
            return path
        except Exception as e:
            log.error(f"Failed to create fake movie '{title}': {e}")
            return None

    def create_fake_episodes(self, title: str, year: Optional[int], seasons: list, episodes: list) -> list:
        if not self.plex_root:
            return []
        created = []
        for ep in episodes:
            s, e = ep["season"], ep["episode"]
            ep_title = ep.get("title", "")
            ep_title_part = f" - {ep_title}" if ep_title else ""
            folder = Path(self.plex_root) / "tv" / title / f"Season {s:02d}"
            fname = f"{title} - S{s:02d}E{e:02d}{ep_title_part}.mp4"
            path = folder / fname
            try:
                folder.mkdir(parents=True, exist_ok=True)
                if not path.exists():
                    path.write_bytes(_FAKE_MP4)
                created.append(path)
            except Exception as ex:
                log.error(f"Failed to create episode '{fname}': {ex}")
        log.info(f"📺 Created {len(created)} fake episode files for '{title}'")
        return created

    def remove_fake_movie(self, title: str, year: Optional[int]) -> bool:
        try:
            year_part = f" ({year})" if year else ""
            folder = Path(self.plex_root) / "movies" / f"{title}{year_part}"
            if folder.exists():
                shutil.rmtree(folder)
                log.info(f"🗑️  Removed: {folder}")
                return True
        except Exception as e:
            log.error(f"Failed to remove movie '{title}': {e}")
        return False

    def remove_fake_series(self, title: str) -> bool:
        try:
            folder = Path(self.plex_root) / "tv" / title
            if folder.exists():
                shutil.rmtree(folder)
                log.info(f"🗑️  Removed: {folder}")
                return True
        except Exception as e:
            log.error(f"Failed to remove series '{title}': {e}")
        return False

    def invalidate_cache(self):
        _cache.clear()

    async def sync_series_episodes(self, title: str, series_id: int, year: Optional[int], include_unreleased: bool) -> dict:
        if not self.plex_root:
            return {"added": 0, "removed": 0}
        show_folder = Path(self.plex_root) / "tv" / title
        added = removed = 0
        try:
            all_eps = await self.get_sonarr_episodes(series_id, include_unreleased=True)
            should = self._filter_episodes(all_eps, include_unreleased)

            def fname(ep):
                ep_title = ep.get("title", "")
                suffix = f" - {ep_title}" if ep_title else ""
                return f"{title} - S{ep['season']:02d}E{ep['episode']:02d}{suffix}.mp4"

            should_names = {fname(e) for e in should}
            existing: dict[str, Path] = {}
            if show_folder.exists():
                for sd in show_folder.iterdir():
                    if sd.is_dir():
                        for f in sd.iterdir():
                            if f.suffix == ".mp4":
                                existing[f.name] = f

            for ep in should:
                fn = fname(ep)
                if fn not in existing:
                    sf = show_folder / f"Season {ep['season']:02d}"
                    sf.mkdir(parents=True, exist_ok=True)
                    (sf / fn).write_bytes(_FAKE_MP4)
                    added += 1

            for fn, fp in existing.items():
                if fn not in should_names and not fp.is_symlink():
                    fp.unlink(missing_ok=True)
                    removed += 1
                    _rmdir_if_empty(fp.parent)

            log.info(f"🔄 Synced '{title}': +{added} added, -{removed} removed")
        except Exception as e:
            log.error(f"sync_series_episodes failed for '{title}': {e}", exc_info=True)
        return {"added": added, "removed": removed}


def _rmdir_if_empty(path: Path):
    try:
        if path.exists() and not any(path.iterdir()):
            path.rmdir()
    except Exception:
        pass
