"""
Library manager for Debridarr — powered by Overseerr.

Fetches approved/available requests from Overseerr and creates placeholder
.mp4 files so Plex can scan and index them before streams are resolved.

Movies:  <plex_root>/movies/<Title> (<Year>)/<Title> (<Year>).mp4
TV:      <plex_root>/tv/<Title>/Season <N>/<Title> - S<N>E<M>.mp4
"""

import logging
import time
from datetime import date
from pathlib import Path
from typing import Optional
import shutil

import httpx

log = logging.getLogger("debridarr.library")


def _make_fake_mp4() -> bytes:
    import struct
    def box(t, payload):
        return struct.pack(">I", 8 + len(payload)) + t + payload
    ftyp = box(b"ftyp", b"mp42\x00\x00\x00\x00mp42isom")
    mvhd = box(b"mvhd",
        b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
        + struct.pack(">I", 1000) + struct.pack(">I", 1000)
        + struct.pack(">I", 0x00010000) + struct.pack(">H", 0x0100)
        + b"\x00" * 10
        + struct.pack(">9i", 0x00010000,0,0, 0,0x00010000,0, 0,0,0x40000000)
        + b"\x00" * 24 + struct.pack(">I", 2)
    )
    return ftyp + box(b"moov", mvhd)


_FAKE_MP4 = _make_fake_mp4()

_library_cache: dict[str, tuple[float, list]] = {}
_LIBRARY_CACHE_TTL = 120


class LibraryManager:
    def __init__(
        self,
        overseerr_url: str,
        overseerr_key: str,
        plex_root: str,
        # Legacy params kept for compatibility — ignored
        sonarr_url: str = "",
        sonarr_key: str = "",
        radarr_url: str = "",
        radarr_key: str = "",
    ):
        self.overseerr_url = overseerr_url.rstrip("/")
        self.overseerr_key = overseerr_key
        self.plex_root = plex_root
        self._client = httpx.AsyncClient(timeout=15)

    # ── Overseerr ─────────────────────────────────────────────────────────────

    async def _overseerr_get(self, path: str, params: dict = None) -> dict:
        """Make an authenticated Overseerr API call."""
        resp = await self._client.get(
            f"{self.overseerr_url}/api/v1{path}",
            headers={"X-Api-Key": self.overseerr_key},
            params=params or {},
        )
        resp.raise_for_status()
        return resp.json()

    async def get_radarr_movies(self, force: bool = False) -> list[dict]:
        """Return approved/available movie requests from Overseerr."""
        cache_key = "overseerr::movies"
        if not force and cache_key in _library_cache:
            ts, data = _library_cache[cache_key]
            if time.time() - ts < _LIBRARY_CACHE_TTL:
                return data

        if not self.overseerr_url or not self.overseerr_key:
            return []

        try:
            results = []
            page = 1
            while True:
                data = await self._overseerr_get(
                    "/request",
                    {"take": 100, "skip": (page - 1) * 100, "filter": "all", "type": "movie"}
                )
                requests = data.get("results", [])
                if not requests:
                    break
                for r in requests:
                    if r.get("status") not in (2, 3, 4, 5):  # approved/partially/available/processing
                        continue
                    media = r.get("media", {})
                    if not media:
                        continue
                    tmdb_id = media.get("tmdbId")
                    if not tmdb_id:
                        continue
                    # Fetch movie details from Overseerr
                    try:
                        details = await self._overseerr_get(f"/movie/{tmdb_id}")
                        results.append({
                            "id": tmdb_id,
                            "title": details.get("title", "Unknown"),
                            "year": details.get("releaseDate", "")[:4] or None,
                            "tmdb_id": tmdb_id,
                            "imdb_id": details.get("externalIds", {}).get("imdbId", ""),
                            "poster": f"https://image.tmdb.org/t/p/w300{details.get('posterPath','')}" if details.get("posterPath") else "",
                            "overview": details.get("overview", ""),
                            "status": "requested",
                            "has_file": media.get("status") == 5,  # 5 = available
                        })
                    except Exception as e:
                        log.debug(f"Failed to get movie details for tmdb:{tmdb_id}: {e}")
                if len(requests) < 100:
                    break
                page += 1

            result = sorted(results, key=lambda m: m["title"].lstrip("The ").lstrip("A "))
            _library_cache[cache_key] = (time.time(), result)
            return result
        except Exception as e:
            log.error(f"Failed to fetch Overseerr movie requests: {e}")
            return []

    async def get_sonarr_series(self, force: bool = False) -> list[dict]:
        """Return approved/available TV requests from Overseerr."""
        cache_key = "overseerr::series"
        if not force and cache_key in _library_cache:
            ts, data = _library_cache[cache_key]
            if time.time() - ts < _LIBRARY_CACHE_TTL:
                return data

        if not self.overseerr_url or not self.overseerr_key:
            return []

        try:
            results = []
            page = 1
            while True:
                data = await self._overseerr_get(
                    "/request",
                    {"take": 100, "skip": (page - 1) * 100, "filter": "all", "type": "tv"}
                )
                requests = data.get("results", [])
                if not requests:
                    break
                seen_tvdb = set()
                for r in requests:
                    if r.get("status") not in (2, 3, 4, 5):
                        continue
                    media = r.get("media", {})
                    tvdb_id = media.get("tvdbId")
                    if not tvdb_id or tvdb_id in seen_tvdb:
                        continue
                    seen_tvdb.add(tvdb_id)
                    try:
                        details = await self._overseerr_get(f"/tv/{tvdb_id}")
                        seasons = [
                            {
                                "season_number": s["seasonNumber"],
                                "episode_count": s.get("episodeCount", 0),
                            }
                            for s in details.get("seasons", [])
                            if s.get("seasonNumber", 0) > 0
                        ]
                        results.append({
                            "id": tvdb_id,
                            "title": details.get("name", "Unknown"),
                            "year": details.get("firstAirDate", "")[:4] or None,
                            "tvdb_id": tvdb_id,
                            "imdb_id": details.get("externalIds", {}).get("imdbId", ""),
                            "poster": f"https://image.tmdb.org/t/p/w300{details.get('posterPath','')}" if details.get("posterPath") else "",
                            "overview": details.get("overview", ""),
                            "status": "requested",
                            "seasons": seasons,
                            "season_count": len(seasons),
                        })
                    except Exception as e:
                        log.debug(f"Failed to get TV details for tvdb:{tvdb_id}: {e}")
                if len(requests) < 100:
                    break
                page += 1

            result = sorted(results, key=lambda s: s["title"].lstrip("The ").lstrip("A "))
            _library_cache[cache_key] = (time.time(), result)
            return result
        except Exception as e:
            log.error(f"Failed to fetch Overseerr TV requests: {e}")
            return []

    async def get_sonarr_episodes(self, series_id: int, include_unreleased: bool = False) -> list[dict]:
        """Return episodes for a series from Overseerr/TMDB."""
        cache_key = f"overseerr::episodes::{series_id}"
        if cache_key in _library_cache:
            ts, data = _library_cache[cache_key]
            if time.time() - ts < _LIBRARY_CACHE_TTL:
                return self._filter_episodes(data, include_unreleased)
        try:
            details = await self._overseerr_get(f"/tv/{series_id}")
            episodes = []
            for season in details.get("seasons", []):
                sn = season.get("seasonNumber", 0)
                if sn == 0:
                    continue
                try:
                    season_detail = await self._overseerr_get(f"/tv/{series_id}/season/{sn}")
                    for ep in season_detail.get("episodes", []):
                        episodes.append({
                            "id": ep.get("id", 0),
                            "series_id": series_id,
                            "title": ep.get("name", ""),
                            "season": sn,
                            "episode": ep.get("episodeNumber", 0),
                            "air_date": ep.get("airDate", ""),
                            "has_file": False,
                        })
                except Exception:
                    pass
            _library_cache[cache_key] = (time.time(), episodes)
            return self._filter_episodes(episodes, include_unreleased)
        except Exception as e:
            log.error(f"Failed to fetch episodes for series {series_id}: {e}")
            return []

    def _filter_episodes(self, episodes: list, include_unreleased: bool) -> list:
        if include_unreleased:
            return [e for e in episodes if e.get("season", 0) > 0]
        today = date.today().isoformat()
        return [
            e for e in episodes
            if e.get("season", 0) > 0
            and e.get("air_date", "") <= today
            and e.get("air_date", "")
        ]

    # ── Fake file creation ─────────────────────────────────────────────────────

    def create_fake_movie(self, title: str, year: Optional[int]) -> Optional[Path]:
        if not self.plex_root:
            return None
        try:
            year_part = f" ({year})" if year else ""
            folder_name = f"{title}{year_part}"
            path = Path(self.plex_root) / "movies" / folder_name / f"{folder_name}.mp4"
            path.parent.mkdir(parents=True, exist_ok=True)
            if not path.exists():
                path.write_bytes(_FAKE_MP4)
            log.info(f"🎬 Fake movie: {path}")
            return path
        except Exception as e:
            log.error(f"Failed to create fake movie '{title}': {e}")
            return None

    def create_fake_episodes(self, title: str, year: Optional[int], seasons: list, episodes: list) -> list[Path]:
        if not self.plex_root:
            return []
        created = []
        for ep in episodes:
            s, e = ep["season"], ep["episode"]
            ep_title = ep.get("title", "")
            ep_title_part = f" - {ep_title}" if ep_title else ""
            season_folder = Path(self.plex_root) / "tv" / title / f"Season {s:02d}"
            file_name = f"{title} - S{s:02d}E{e:02d}{ep_title_part}.mp4"
            path = season_folder / file_name
            try:
                path.parent.mkdir(parents=True, exist_ok=True)
                if not path.exists():
                    path.write_bytes(_FAKE_MP4)
                created.append(path)
            except Exception as ex:
                log.error(f"Failed to create episode file '{file_name}': {ex}")
        log.info(f"📺 Created {len(created)} fake episode files for '{title}'")
        return created

    def remove_fake_movie(self, title: str, year: Optional[int]) -> bool:
        try:
            year_part = f" ({year})" if year else ""
            folder = Path(self.plex_root) / "movies" / f"{title}{year_part}"
            if folder.exists():
                shutil.rmtree(folder)
                log.info(f"🗑️  Removed fake movie folder: {folder}")
                return True
        except Exception as e:
            log.error(f"Failed to remove fake movie '{title}': {e}")
        return False

    def remove_fake_series(self, title: str) -> bool:
        try:
            folder = Path(self.plex_root) / "tv" / title
            if folder.exists():
                shutil.rmtree(folder)
                log.info(f"🗑️  Removed fake series folder: {folder}")
                return True
        except Exception as e:
            log.error(f"Failed to remove fake series '{title}': {e}")
        return False

    def invalidate_cache(self):
        _library_cache.clear()

    async def sync_series_episodes(self, title: str, sonarr_id: int, year: Optional[int], include_unreleased: bool) -> dict:
        if not self.plex_root:
            return {"added": 0, "removed": 0}
        show_folder = Path(self.plex_root) / "tv" / title
        added = removed = 0
        try:
            all_eps = await self.get_sonarr_episodes(sonarr_id, include_unreleased=True)
            should_exist = self._filter_episodes(all_eps, include_unreleased)

            def ep_filename(ep):
                s, e = ep["season"], ep["episode"]
                ep_title = ep.get("title", "")
                ep_title_part = f" - {ep_title}" if ep_title else ""
                return f"{title} - S{s:02d}E{e:02d}{ep_title_part}.mp4"

            should_exist_names = {ep_filename(ep) for ep in should_exist}
            existing: dict[str, Path] = {}
            if show_folder.exists():
                for season_dir in show_folder.iterdir():
                    if season_dir.is_dir():
                        for f in season_dir.iterdir():
                            if f.suffix == ".mp4":
                                existing[f.name] = f

            for ep in should_exist:
                fname = ep_filename(ep)
                if fname not in existing:
                    s = ep["season"]
                    season_folder = show_folder / f"Season {s:02d}"
                    season_folder.mkdir(parents=True, exist_ok=True)
                    (season_folder / fname).write_bytes(_FAKE_MP4)
                    added += 1

            for fname, fpath in existing.items():
                if fname not in should_exist_names and not fpath.is_symlink():
                    fpath.unlink(missing_ok=True)
                    removed += 1
                    _rmdir_if_empty(fpath.parent)

            log.info(f"🔄 Synced '{title}': +{added} added, -{removed} removed")
        except Exception as e:
            log.error(f"sync_series_episodes failed for '{title}': {e}", exc_info=True)
        return {"added": added, "removed": removed}


def _rmdir_if_empty(path: Path):
    try:
        if path.exists() and not any(path.iterdir()):
            path.rmdir()
    except Exception:
        pass
