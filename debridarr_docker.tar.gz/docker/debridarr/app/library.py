"""
Library manager for Debridarr.

Responsibilities:
  1. Fetch the full movie/series library from Radarr and Sonarr
  2. Create fake placeholder .mkv files on disk so Plex can scan and index them
  3. Track which items are in the fake library (separate from the resolved cache)
  4. Remove fake files when items are removed

Fake file strategy:
  Plex matches metadata purely from the filename + folder structure.
  A zero-byte .mkv is enough for Plex to scan, identify, and show the item.
  When the user hits play, Tautulli fires → Debridarr resolves → proxy streams real bytes.

  Movies:  <plex_root>/movies/<Title> (<Year>)/<Title> (<Year>).mkv
  TV:      <plex_root>/tv/<Title>/Season <N>/<Title> - S<N>E<M>.mkv
"""

import logging
import time
from pathlib import Path
from typing import Optional

import httpx

log = logging.getLogger("debridarr.library")

# In-process cache so we don't hammer Sonarr/Radarr on every page load
_library_cache: dict[str, tuple[float, list]] = {}
_LIBRARY_CACHE_TTL = 120  # 2 minutes


class LibraryManager:
    def __init__(
        self,
        sonarr_url: str,
        sonarr_key: str,
        radarr_url: str,
        radarr_key: str,
        plex_root: str,
    ):
        self.sonarr_url = sonarr_url.rstrip("/")
        self.sonarr_key = sonarr_key
        self.radarr_url = radarr_url.rstrip("/")
        self.radarr_key = radarr_key
        self.plex_root = plex_root
        self._client = httpx.AsyncClient(timeout=15)

    # ── Radarr ────────────────────────────────────────────────────────────────

    async def get_radarr_movies(self, force: bool = False) -> list[dict]:
        """Return all movies in Radarr, sorted by title."""
        cache_key = "radarr::movies"
        if not force and cache_key in _library_cache:
            ts, data = _library_cache[cache_key]
            if time.time() - ts < _LIBRARY_CACHE_TTL:
                return data

        if not self.radarr_url or not self.radarr_key:
            return []

        try:
            resp = await self._client.get(
                f"{self.radarr_url}/api/v3/movie",
                headers={"X-Api-Key": self.radarr_key},
            )
            resp.raise_for_status()
            movies = resp.json()
            result = sorted([
                {
                    "id": m["id"],
                    "title": m["title"],
                    "year": m.get("year"),
                    "tmdb_id": m.get("tmdbId"),
                    "imdb_id": m.get("imdbId"),
                    "poster": m.get("images", [{}])[0].get("remoteUrl", ""),
                    "overview": m.get("overview", ""),
                    "status": m.get("status", ""),
                    "has_file": m.get("hasFile", False),
                }
                for m in movies
            ], key=lambda m: m["title"].lstrip("The ").lstrip("A "))
            _library_cache[cache_key] = (time.time(), result)
            return result
        except Exception as e:
            log.error(f"Failed to fetch Radarr movies: {e}")
            return []

    # ── Sonarr ────────────────────────────────────────────────────────────────

    async def get_sonarr_series(self, force: bool = False) -> list[dict]:
        """Return all series in Sonarr, sorted by title."""
        cache_key = "sonarr::series"
        if not force and cache_key in _library_cache:
            ts, data = _library_cache[cache_key]
            if time.time() - ts < _LIBRARY_CACHE_TTL:
                return data

        if not self.sonarr_url or not self.sonarr_key:
            return []

        try:
            resp = await self._client.get(
                f"{self.sonarr_url}/api/v3/series",
                headers={"X-Api-Key": self.sonarr_key},
            )
            resp.raise_for_status()
            series = resp.json()
            result = sorted([
                {
                    "id": s["id"],
                    "title": s["title"],
                    "year": s.get("year"),
                    "tvdb_id": s.get("tvdbId"),
                    "imdb_id": s.get("imdbId"),
                    "poster": next(
                        (i.get("remoteUrl", "") for i in s.get("images", []) if i.get("coverType") == "poster"),
                        "",
                    ),
                    "overview": s.get("overview", ""),
                    "status": s.get("status", ""),
                    "seasons": [
                        {"season_number": sn["seasonNumber"], "episode_count": sn.get("statistics", {}).get("totalEpisodeCount", 0)}
                        for sn in s.get("seasons", [])
                        if sn["seasonNumber"] > 0
                    ],
                    "season_count": len([sn for sn in s.get("seasons", []) if sn["seasonNumber"] > 0]),
                }
                for s in series
            ], key=lambda s: s["title"].lstrip("The ").lstrip("A "))
            _library_cache[cache_key] = (time.time(), result)
            return result
        except Exception as e:
            log.error(f"Failed to fetch Sonarr series: {e}")
            return []

    async def get_sonarr_episodes(self, series_id: int) -> list[dict]:
        """Return all episodes for a given Sonarr series ID."""
        cache_key = f"sonarr::episodes::{series_id}"
        if cache_key in _library_cache:
            ts, data = _library_cache[cache_key]
            if time.time() - ts < _LIBRARY_CACHE_TTL:
                return data

        try:
            resp = await self._client.get(
                f"{self.sonarr_url}/api/v3/episode",
                params={"seriesId": series_id},
                headers={"X-Api-Key": self.sonarr_key},
            )
            resp.raise_for_status()
            episodes = resp.json()
            result = [
                {
                    "id": e["id"],
                    "series_id": series_id,
                    "title": e.get("title", ""),
                    "season": e["seasonNumber"],
                    "episode": e["episodeNumber"],
                    "air_date": e.get("airDate", ""),
                    "overview": e.get("overview", ""),
                    "has_file": e.get("hasFile", False),
                }
                for e in episodes
                if e["seasonNumber"] > 0
            ]
            result.sort(key=lambda e: (e["season"], e["episode"]))
            _library_cache[cache_key] = (time.time(), result)
            return result
        except Exception as e:
            log.error(f"Failed to fetch episodes for series {series_id}: {e}")
            return []

    # ── Fake file creation ────────────────────────────────────────────────────

    def create_fake_movie(self, title: str, year: Optional[int]) -> Optional[Path]:
        """
        Create a zero-byte .mkv in the Plex movies folder.
        Returns the path, or None if plex_root not configured.
        """
        if not self.plex_root:
            return None
        try:
            year_part = f" ({year})" if year else ""
            folder_name = f"{title}{year_part}"
            file_name = f"{folder_name}.mkv"
            path = Path(self.plex_root) / "movies" / folder_name / file_name
            path.parent.mkdir(parents=True, exist_ok=True)
            if not path.exists():
                path.touch()
            log.info(f"🎬 Fake movie file: {path}")
            return path
        except Exception as e:
            log.error(f"Failed to create fake movie for '{title}': {e}")
            return None

    def create_fake_episodes(
        self, title: str, year: Optional[int], seasons: list[dict], episodes: list[dict]
    ) -> list[Path]:
        """
        Create zero-byte .mkv files for all episodes of a series.
        Returns list of paths created.
        """
        if not self.plex_root:
            return []

        created = []
        show_folder = Path(self.plex_root) / "tv" / title

        for ep in episodes:
            s = ep["season"]
            e = ep["episode"]
            ep_title = ep.get("title", "")
            season_folder = show_folder / f"Season {s:02d}"
            # Plex-standard naming: Show Title - S01E01 - Episode Title.mkv
            ep_title_part = f" - {ep_title}" if ep_title else ""
            file_name = f"{title} - S{s:02d}E{e:02d}{ep_title_part}.mkv"
            path = season_folder / file_name
            try:
                path.parent.mkdir(parents=True, exist_ok=True)
                if not path.exists():
                    path.touch()
                created.append(path)
            except Exception as ex:
                log.warning(f"Failed to create fake episode {file_name}: {ex}")

        log.info(f"📺 Created {len(created)} fake episode files for '{title}'")
        return created

    def remove_fake_movie(self, title: str, year: Optional[int]) -> bool:
        """Remove a fake movie and its folder."""
        if not self.plex_root:
            return False
        try:
            year_part = f" ({year})" if year else ""
            folder_name = f"{title}{year_part}"
            folder = Path(self.plex_root) / "movies" / folder_name
            if folder.exists():
                for f in folder.iterdir():
                    f.unlink()
                folder.rmdir()
                log.info(f"🗑️  Removed fake movie folder: {folder}")
                return True
        except Exception as e:
            log.error(f"Failed to remove fake movie '{title}': {e}")
        return False

    def remove_fake_series(self, title: str) -> bool:
        """Remove all fake episode files and folders for a series."""
        if not self.plex_root:
            return False
        try:
            import shutil
            folder = Path(self.plex_root) / "tv" / title
            if folder.exists():
                shutil.rmtree(folder)
                log.info(f"🗑️  Removed fake series folder: {folder}")
                return True
        except Exception as e:
            log.error(f"Failed to remove fake series '{title}': {e}")
        return False

    def invalidate_cache(self):
        """Force next library fetch to hit Sonarr/Radarr."""
        _library_cache.clear()
