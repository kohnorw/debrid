"""
Library manager for Debridarr.

Responsibilities:
  1. Fetch the full movie/series library from Radarr and Sonarr
  2. Create fake placeholder .mkv files on disk so Plex can scan and index them
  3. Track which items are in the fake library (separate from the resolved cache)
  4. Remove fake files when items are removed

Fake file strategy:
  Plex matches metadata purely from the filename + folder structure.
  A zero-byte .mkv is enough for Plex to scan, identify, and show the item.
  When the user hits play, Tautulli fires → Debridarr resolves → proxy streams real bytes.

  Movies:  <plex_root>/movies/<Title> (<Year>)/<Title> (<Year>).mkv
  TV:      <plex_root>/tv/<Title>/Season <N>/<Title> - S<N>E<M>.mkv
"""

import logging
from datetime import date
import time
from pathlib import Path
from typing import Optional

import httpx

log = logging.getLogger("debridarr.library")


def _make_fake_mp4() -> bytes:
    """
    Build the smallest valid MP4 that Plex will accept during a library scan.
    Just ftyp + moov boxes — no actual media data. ~140 bytes.
    Plex checks the container structure, not whether there's a video stream.
    """
    import struct

    def box(t: bytes, payload: bytes) -> bytes:
        return struct.pack(">I", 8 + len(payload)) + t + payload

    ftyp = box(b"ftyp",
        b"mp42"              # major brand
        + b"\x00\x00\x00\x00"  # minor version
        + b"mp42isom"        # compatible brands
    )
    mvhd = box(b"mvhd",
        b"\x00\x00\x00\x00"    # version + flags
        + b"\x00\x00\x00\x00"  # creation time
        + b"\x00\x00\x00\x00"  # modification time
        + struct.pack(">I", 1000)  # timescale
        + struct.pack(">I", 1000)  # duration (1 sec)
        + struct.pack(">I", 0x00010000)   # rate
        + struct.pack(">H", 0x0100)       # volume
        + b"\x00" * 10
        + struct.pack(">9i", 0x00010000, 0, 0, 0, 0x00010000, 0, 0, 0, 0x40000000)
        + b"\x00" * 24
        + struct.pack(">I", 2)     # next_track_id
    )
    return ftyp + box(b"moov", mvhd)


_FAKE_MP4 = _make_fake_mp4()  # build once at import time

# In-process cache so we don't hammer Sonarr/Radarr on every page load
_library_cache: dict[str, tuple[float, list]] = {}
_LIBRARY_CACHE_TTL = 120  # 2 minutes


class LibraryManager:
    def __init__(
        self,
        sonarr_url: str,
        sonarr_key: str,
        radarr_url: str,
        radarr_key: str,
        plex_root: str,
    ):
        self.sonarr_url = sonarr_url.rstrip("/")
        self.sonarr_key = sonarr_key
        self.radarr_url = radarr_url.rstrip("/")
        self.radarr_key = radarr_key
        self.plex_root = plex_root
        self._client = httpx.AsyncClient(timeout=15)

    # ── Radarr ────────────────────────────────────────────────────────────────

    async def get_radarr_movies(self, force: bool = False) -> list[dict]:
        """Return all movies in Radarr, sorted by title."""
        cache_key = "radarr::movies"
        if not force and cache_key in _library_cache:
            ts, data = _library_cache[cache_key]
            if time.time() - ts < _LIBRARY_CACHE_TTL:
                return data

        if not self.radarr_url or not self.radarr_key:
            return []

        try:
            resp = await self._client.get(
                f"{self.radarr_url}/api/v3/movie",
                headers={"X-Api-Key": self.radarr_key},
            )
            resp.raise_for_status()
            movies = resp.json()
            result = sorted([
                {
                    "id": m["id"],
                    "title": m["title"],
                    "year": m.get("year"),
                    "tmdb_id": m.get("tmdbId"),
                    "imdb_id": m.get("imdbId"),
                    "poster": m.get("images", [{}])[0].get("remoteUrl", ""),
                    "overview": m.get("overview", ""),
                    "status": m.get("status", ""),
                    "has_file": m.get("hasFile", False),
                }
                for m in movies
            ], key=lambda m: m["title"].lstrip("The ").lstrip("A "))
            _library_cache[cache_key] = (time.time(), result)
            return result
        except Exception as e:
            log.error(f"Failed to fetch Radarr movies: {e}")
            return []

    # ── Sonarr ────────────────────────────────────────────────────────────────

    async def get_sonarr_series(self, force: bool = False) -> list[dict]:
        """Return all series in Sonarr, sorted by title."""
        cache_key = "sonarr::series"
        if not force and cache_key in _library_cache:
            ts, data = _library_cache[cache_key]
            if time.time() - ts < _LIBRARY_CACHE_TTL:
                return data

        if not self.sonarr_url or not self.sonarr_key:
            return []

        try:
            resp = await self._client.get(
                f"{self.sonarr_url}/api/v3/series",
                headers={"X-Api-Key": self.sonarr_key},
            )
            resp.raise_for_status()
            series = resp.json()
            result = sorted([
                {
                    "id": s["id"],
                    "title": s["title"],
                    "year": s.get("year"),
                    "tvdb_id": s.get("tvdbId"),
                    "imdb_id": s.get("imdbId"),
                    "poster": next(
                        (i.get("remoteUrl", "") for i in s.get("images", []) if i.get("coverType") == "poster"),
                        "",
                    ),
                    "overview": s.get("overview", ""),
                    "status": s.get("status", ""),
                    "seasons": [
                        {"season_number": sn["seasonNumber"], "episode_count": sn.get("statistics", {}).get("totalEpisodeCount", 0)}
                        for sn in s.get("seasons", [])
                        if sn["seasonNumber"] > 0
                    ],
                    "season_count": len([sn for sn in s.get("seasons", []) if sn["seasonNumber"] > 0]),
                }
                for s in series
            ], key=lambda s: s["title"].lstrip("The ").lstrip("A "))
            _library_cache[cache_key] = (time.time(), result)
            return result
        except Exception as e:
            log.error(f"Failed to fetch Sonarr series: {e}")
            return []

    async def get_sonarr_episodes(self, series_id: int, include_unreleased: bool = False) -> list[dict]:
        """Return episodes for a series. By default, only returns aired episodes."""
        cache_key = f"sonarr::episodes::{series_id}"
        if cache_key in _library_cache:
            ts, data = _library_cache[cache_key]
            if time.time() - ts < _LIBRARY_CACHE_TTL:
                # Still apply the unreleased filter on cached data
                return self._filter_episodes(data, include_unreleased)

        try:
            resp = await self._client.get(
                f"{self.sonarr_url}/api/v3/episode",
                params={"seriesId": series_id},
                headers={"X-Api-Key": self.sonarr_key},
            )
            resp.raise_for_status()
            episodes = resp.json()
            # Store ALL episodes in cache — filter at call time
            result = [
                {
                    "id": e["id"],
                    "series_id": series_id,
                    "title": e.get("title", ""),
                    "season": e["seasonNumber"],
                    "episode": e["episodeNumber"],
                    "air_date": e.get("airDate", ""),
                    "overview": e.get("overview", ""),
                    "has_file": e.get("hasFile", False),
                }
                for e in episodes
                if e["seasonNumber"] > 0
            ]
            result.sort(key=lambda e: (e["season"], e["episode"]))
            _library_cache[cache_key] = (time.time(), result)
            return self._filter_episodes(result, include_unreleased)
        except Exception as e:
            log.error(f"Failed to fetch episodes for series {series_id}: {e}")
            return []

    def _filter_episodes(self, episodes: list[dict], include_unreleased: bool) -> list[dict]:
        """Filter out episodes that haven't aired yet, unless include_unreleased is True."""
        if include_unreleased:
            return episodes
        today = date.today().isoformat()
        return [
            e for e in episodes
            if e.get("air_date") and e["air_date"] <= today
        ]

    # ── Fake file creation ────────────────────────────────────────────────────

    def create_fake_movie(self, title: str, year: Optional[int]) -> Optional[Path]:
        """
        Create a minimal valid MP4 placeholder in the Plex movies folder.
        Plex requires a non-empty, structurally valid container to scan the file.
        Returns the path, or None if plex_root not configured.
        """
        if not self.plex_root:
            return None
        try:
            year_part = f" ({year})" if year else ""
            folder_name = f"{title}{year_part}"
            file_name = f"{folder_name}.mp4"
            path = Path(self.plex_root) / "movies" / folder_name / file_name
            path.parent.mkdir(parents=True, exist_ok=True)
            if not path.exists():
                path.write_bytes(_FAKE_MP4)
            log.info(f"🎬 Fake movie file: {path} ({len(_FAKE_MP4)}B)")
            return path
        except Exception as e:
            log.error(f"Failed to create fake movie for '{title}': {e}")
            return None

    def create_fake_episodes(
        self, title: str, year: Optional[int], seasons: list[dict], episodes: list[dict]
    ) -> list[Path]:
        """
        Create zero-byte .mkv files for all episodes of a series.
        Returns list of paths created.
        """
        if not self.plex_root:
            return []

        created = []
        show_folder = Path(self.plex_root) / "tv" / title

        for ep in episodes:
            s = ep["season"]
            e = ep["episode"]
            ep_title = ep.get("title", "")
            season_folder = show_folder / f"Season {s:02d}"
            # Plex-standard naming: Show Title - S01E01 - Episode Title.mkv
            ep_title_part = f" - {ep_title}" if ep_title else ""
            file_name = f"{title} - S{s:02d}E{e:02d}{ep_title_part}.mp4"
            path = season_folder / file_name
            try:
                path.parent.mkdir(parents=True, exist_ok=True)
                if not path.exists():
                    path.write_bytes(_FAKE_MP4)
                created.append(path)
            except Exception as ex:
                log.warning(f"Failed to create fake episode {file_name}: {ex}")

        log.info(f"📺 Created {len(created)} fake episode files for '{title}'")
        return created

    def remove_fake_movie(self, title: str, year: Optional[int]) -> bool:
        """Remove a fake movie and its folder."""
        if not self.plex_root:
            return False
        try:
            year_part = f" ({year})" if year else ""
            folder_name = f"{title}{year_part}"
            folder = Path(self.plex_root) / "movies" / folder_name
            if folder.exists():
                for f in folder.iterdir():
                    f.unlink()
                folder.rmdir()
                log.info(f"🗑️  Removed fake movie folder: {folder}")
                return True
        except Exception as e:
            log.error(f"Failed to remove fake movie '{title}': {e}")
        return False

    def remove_fake_series(self, title: str) -> bool:
        """Remove all fake episode files and folders for a series."""
        if not self.plex_root:
            return False
        try:
            import shutil
            folder = Path(self.plex_root) / "tv" / title
            if folder.exists():
                shutil.rmtree(folder)
                log.info(f"🗑️  Removed fake series folder: {folder}")
                return True
        except Exception as e:
            log.error(f"Failed to remove fake series '{title}': {e}")
        return False

    def invalidate_cache(self):
        """Force next library fetch to hit Sonarr/Radarr."""
        _library_cache.clear()

    async def sync_series_episodes(
        self, title: str, sonarr_id: int, year: Optional[int], include_unreleased: bool
    ) -> dict:
        """
        Diff the fake files on disk against what should exist given the current
        include_unreleased setting. Adds missing files, removes ones that shouldn't
        be there. Does NOT remove the show folder — Plex keeps the library entry.
        Returns {"added": int, "removed": int}.
        """
        if not self.plex_root:
            return {"added": 0, "removed": 0}

        show_folder = Path(self.plex_root) / "tv" / title
        added = 0
        removed = 0

        try:
            # Fetch all episodes from Sonarr (bypass cache for accuracy)
            all_eps = await self.get_sonarr_episodes(sonarr_id, include_unreleased=True)
            should_exist = self._filter_episodes(all_eps, include_unreleased)

            # Build the set of filenames that should exist
            def ep_filename(ep: dict) -> str:
                s, e = ep["season"], ep["episode"]
                ep_title = ep.get("title", "")
                ep_title_part = f" - {ep_title}" if ep_title else ""
                return f"{title} - S{s:02d}E{e:02d}{ep_title_part}.mp4"

            should_exist_names = {ep_filename(ep) for ep in should_exist}

            # Find all existing fake .mkv files across all season folders
            existing: dict[str, Path] = {}
            if show_folder.exists():
                for season_dir in show_folder.iterdir():
                    if season_dir.is_dir():
                        for f in season_dir.iterdir():
                            if f.suffix == ".mp4":
                                existing[f.name] = f

            existing_names = set(existing.keys())

            # Add missing files
            for ep in should_exist:
                fname = ep_filename(ep)
                if fname not in existing_names:
                    s = ep["season"]
                    season_folder = show_folder / f"Season {s:02d}"
                    season_folder.mkdir(parents=True, exist_ok=True)
                    (season_folder / fname).write_bytes(_FAKE_MP4)
                    added += 1
                    log.debug(f"+ {fname}")

            # Remove files that shouldn't exist (unreleased episodes when toggled off)
            for fname, fpath in existing.items():
                if fname not in should_exist_names:
                    fpath.unlink(missing_ok=True)
                    removed += 1
                    log.debug(f"- {fname}")
                    # Clean up empty season folders
                    _rmdir_if_empty(fpath.parent)

            log.info(
                f"🔄 Synced '{title}': +{added} added, -{removed} removed "
                f"(include_unreleased={include_unreleased})"
            )
        except Exception as e:
            log.error(f"sync_series_episodes failed for '{title}': {e}", exc_info=True)

        return {"added": added, "removed": removed}


def _rmdir_if_empty(path: Path):
    try:
        if path.exists() and not any(path.iterdir()):
            path.rmdir()
    except Exception:
        pass
