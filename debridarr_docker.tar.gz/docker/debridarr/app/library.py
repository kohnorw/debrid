"""
Library manager — pulls approved requests from Overseerr.

Overseerr API:
  GET /api/v1/request?take=100&skip=0&filter=all  → {results: [MediaRequest]}
  GET /api/v1/movie/{tmdbId}                       → movie details
  GET /api/v1/tv/{tmdbId}                          → TV details (uses TMDB id, not TVDB)

MediaRequest.status:  1=PENDING, 2=APPROVED, 3=DECLINED
MediaInfo.status:     1=UNKNOWN, 2=PENDING, 3=PROCESSING,
                      4=PARTIALLY_AVAILABLE, 5=AVAILABLE
MediaInfo.mediaType:  "movie" or "tv"
"""

import logging
import shutil
import struct
import time
from datetime import date
from pathlib import Path
from typing import Optional

import httpx

log = logging.getLogger("debridarr.library")


# ── Placeholder MP4 ──────────────────────────────────────────────────────────
#
# app/placeholder.mp4 — a 3-second H.264 still of the "Grabbing Your Content"
# poster image (1280x720, Constrained Baseline). Plex plays it, Tautulli fires
# "Playback Start", resolve_and_cache runs, symlink replaces the placeholder.
# On re-play the real video streams immediately.

def _make_fake_mp4() -> bytes:
    """
    Load the placeholder MP4 from disk. Falls back to a minimal H.264 black
    frame if the file is missing (e.g. first-run before Docker volume is ready).
    """
    placeholder = Path(__file__).parent / "placeholder.mp4"
    if placeholder.exists():
        return placeholder.read_bytes()
    # Fallback: real single black frame H.264 (664 bytes)
    def box(t, p):
        import struct as _s
        return _s.pack(">I", 8 + len(p)) + t + p
    SPS = bytes([0x67,0x42,0xc0,0x0a,0xd9,0x00,0xa0,0x47,0xfe,0xc8])
    PPS = bytes([0x68,0xce,0x38,0x80])
    IDR = bytes([0x65,0x88,0x84,0x00,0x33,0xff])
    ts, sd = 30000, 3000
    avcc = b"\x01" + SPS[1:4] + b"\xff\xe1" + struct.pack(">H",len(SPS)) + SPS + b"\x01" + struct.pack(">H",len(PPS)) + PPS
    avc1 = box(b"avc1", b"\x00"*6+struct.pack(">H",1)+b"\x00"*16+struct.pack(">HH",16,16)+struct.pack(">II",0x00480000,0x00480000)+b"\x00"*4+struct.pack(">H",1)+b"\x00"*32+struct.pack(">H",24)+struct.pack(">h",-1)+box(b"avcC",avcc))
    sample = struct.pack(">I",len(IDR))+IDR
    def stbl(off):
        return box(b"stbl", box(b"stsd",b"\x00"*4+struct.pack(">I",1)+avc1)+box(b"stts",b"\x00"*4+struct.pack(">II",1,1)+struct.pack(">II",1,sd))+box(b"stss",b"\x00"*4+struct.pack(">II",1,1))+box(b"stsc",b"\x00"*4+struct.pack(">I",1)+struct.pack(">III",1,1,1))+box(b"stsz",b"\x00"*4+struct.pack(">II",0,1)+struct.pack(">I",len(sample)))+box(b"stco",b"\x00"*4+struct.pack(">II",1,off)))
    ftyp = box(b"ftyp",b"mp42\x00\x00\x00\x00mp42isom")
    mvhd = box(b"mvhd",b"\x00"*12+struct.pack(">II",ts,sd)+struct.pack(">I",0x00010000)+struct.pack(">H",0x0100)+b"\x00"*10+struct.pack(">9i",0x00010000,0,0,0,0x00010000,0,0,0,0x40000000)+b"\x00"*24+struct.pack(">I",2))
    tkhd = box(b"tkhd",b"\x00\x00\x00\x03"+b"\x00"*8+struct.pack(">I",1)+b"\x00"*4+struct.pack(">I",sd)+b"\x00"*12+struct.pack(">9i",0x00010000,0,0,0,0x00010000,0,0,0,0x40000000)+struct.pack(">II",16<<16,16<<16))
    mdhd = box(b"mdhd",b"\x00"*12+struct.pack(">II",ts,sd)+struct.pack(">H",0x55C4)+b"\x00\x00")
    hdlr = box(b"hdlr",b"\x00"*8+b"vide"+b"\x00"*12+b"VideoHandler\x00")
    vmhd = box(b"vmhd",b"\x00\x00\x00\x01"+b"\x00"*6)
    dinf = box(b"dinf",box(b"dref",b"\x00"*4+struct.pack(">I",1)+box(b"url ",b"\x00\x00\x00\x01")))
    moov_d = box(b"moov",mvhd+box(b"trak",tkhd+box(b"mdia",mdhd+hdlr+box(b"minf",vmhd+dinf+stbl(0)))))
    off = len(ftyp)+len(moov_d)+8
    moov = box(b"moov",mvhd+box(b"trak",tkhd+box(b"mdia",mdhd+hdlr+box(b"minf",vmhd+dinf+stbl(off)))))
    return ftyp+moov+box(b"mdat",sample)


_FAKE_MP4 = _make_fake_mp4()

_cache: dict[str, tuple[float, list]] = {}
_TTL = 120


class LibraryManager:
    def __init__(
        self,
        overseerr_url: str = "",
        overseerr_key: str = "",
        plex_root: str = "",
        tmdb_api_key: str = "",
        # legacy ignored params
        sonarr_url: str = "", sonarr_key: str = "",
        radarr_url: str = "", radarr_key: str = "",
    ):
        self.url = overseerr_url.rstrip("/")
        self.key = overseerr_key
        self.plex_root = plex_root
        self.tmdb_key = tmdb_api_key
        self._http = httpx.AsyncClient(timeout=15)

    def _headers(self) -> dict:
        return {"X-Api-Key": self.key}

    async def _get(self, path: str, params: dict = None) -> dict:
        r = await self._http.get(
            f"{self.url}/api/v1{path}",
            headers=self._headers(),
            params=params or {},
        )
        r.raise_for_status()
        return r.json()

    # ── Fetch all requests from Overseerr ──────────────────────────────────────

    async def _get_all_requests(self, media_type: str, force: bool = False) -> list[dict]:
        """
        Fetch all requests of given type ('movie' or 'tv') from Overseerr.
        Returns raw request objects with media details already fetched.
        """
        cache_key = f"overseerr::{media_type}"
        if not force and cache_key in _cache:
            ts, data = _cache[cache_key]
            if time.time() - ts < _TTL:
                return data

        if not self.url or not self.key:
            return []

        # tmdb_id → accumulated requested season numbers
        # Multiple requests for the same show (different seasons) must be merged
        requested_seasons_map: dict[int, set] = {}
        # tmdb_id → first valid request's media object (for status etc)
        media_map: dict[int, dict] = {}
        # ordered list of tmdb_ids as first seen
        tmdb_order: list[int] = []

        skip = 0

        while True:
            try:
                data = await self._get("/request", {
                    "take": 100,
                    "skip": skip,
                    "filter": "all",
                    "sort": "added",
                })
            except Exception as e:
                log.error(f"Overseerr request fetch failed: {e}")
                break

            log.debug(f"Overseerr page skip={skip}: {len(data.get('results',[]))} requests")

            requests = data.get("results", [])
            if not requests:
                break

            for req in requests:
                media = req.get("media", {})
                req_status = req.get("status", 0)
                req_media_type = media.get("mediaType", "unknown")

                # Filter by media type
                if req_media_type != media_type:
                    continue

                # Only include non-declined requests
                if req_status == 3:  # DECLINED
                    continue

                tmdb_id = media.get("tmdbId")
                if not tmdb_id:
                    continue

                # Accumulate requested seasons — merge multiple requests for same show
                req_seasons = req.get("seasons", [])
                season_nums = {
                    s["seasonNumber"] for s in req_seasons
                    if s.get("seasonNumber", 0) > 0
                }

                if tmdb_id not in requested_seasons_map:
                    requested_seasons_map[tmdb_id] = set()
                    media_map[tmdb_id] = media
                    tmdb_order.append(tmdb_id)

                requested_seasons_map[tmdb_id].update(season_nums)

            if len(requests) < 100:
                break
            skip += 100

        # Now fetch details for each unique show
        results = []
        for tmdb_id in tmdb_order:
            media = media_map[tmdb_id]
            requested_season_nums = requested_seasons_map[tmdb_id]  # merged from all requests

            try:
                if media_type == "movie":
                    details = await self._get(f"/movie/{tmdb_id}")
                    release_date = details.get("releaseDate", "") or ""
                    results.append({
                        "id":           tmdb_id,
                        "title":        details.get("title", "Unknown"),
                        "year":         int(release_date[:4]) if release_date else None,
                        "release_date": release_date,   # full "YYYY-MM-DD" or ""
                        "tmdb_id":      tmdb_id,
                        "imdb_id":      details.get("externalIds", {}).get("imdbId", ""),
                        "poster":       f"https://image.tmdb.org/t/p/w300{details['posterPath']}" if details.get("posterPath") else "",
                        "overview":     details.get("overview", ""),
                        "status":       media.get("status", 1),
                        "has_file":     media.get("status", 1) == 5,
                    })
                else:
                    details = await self._get(f"/tv/{tmdb_id}")

                    # All available seasons from TMDB
                    all_seasons = [
                        {
                            "season_number": s["seasonNumber"],
                            "episode_count": s.get("episodeCount", 0),
                        }
                        for s in details.get("seasons", [])
                        if s.get("seasonNumber", 0) > 0
                    ]

                    # Filter to only requested seasons (merged from all requests for this show)
                    # If empty, all seasons were requested
                    if requested_season_nums:
                        seasons = [s for s in all_seasons if s["season_number"] in requested_season_nums]
                    else:
                        seasons = all_seasons

                    log.debug(f"TV {details.get('name')} tmdb={tmdb_id}: requested_seasons={sorted(requested_season_nums)}, seasons={[s['season_number'] for s in seasons]}")

                    # Overseerr status field from TV details (not the request status)
                    show_status = details.get("status", "").lower()  # e.g. "Ended", "Returning Series"
                    is_ended = show_status in ("ended", "cancelled", "canceled")

                    results.append({
                        "id":                tmdb_id,
                        "title":             details.get("name", "Unknown"),
                        "year":              int(details.get("firstAirDate", "0")[:4]) if details.get("firstAirDate") else None,
                        "tvdb_id":           details.get("externalIds", {}).get("tvdbId"),
                        "tmdb_id":           tmdb_id,
                        "imdb_id":           details.get("externalIds", {}).get("imdbId", ""),
                        "poster":            f"https://image.tmdb.org/t/p/w300{details['posterPath']}" if details.get("posterPath") else "",
                        "overview":          details.get("overview", ""),
                        "media_status":      media.get("status", 1),
                        "show_status":       show_status,
                        "is_ended":          is_ended,
                        "seasons":           seasons,
                        "season_count":      len(seasons),
                        "requested_seasons": sorted(requested_season_nums) if requested_season_nums else [],
                    })
            except Exception as e:
                log.debug(f"Failed to get {media_type} details tmdb:{tmdb_id}: {e}")

        results.sort(key=lambda x: x["title"].lstrip("The ").lstrip("A "))
        _cache[cache_key] = (time.time(), results)
        log.info(f"Overseerr: {len(results)} {media_type} requests fetched")
        return results

    # ── Public API (named to match existing calls in main.py) ─────────────────

    async def get_radarr_movies(self, force: bool = False) -> list[dict]:
        return await self._get_all_requests("movie", force)

    async def get_sonarr_series(self, force: bool = False) -> list[dict]:
        return await self._get_all_requests("tv", force)

    async def get_episodes(self, series_id: int, include_unreleased: bool = False,
                                   requested_seasons: list = None) -> list[dict]:
        """Fetch episodes for a TV series via Overseerr → TMDB.
        If requested_seasons is provided, only fetch those seasons.
        """
        season_key = ",".join(str(s) for s in sorted(requested_seasons)) if requested_seasons else "all"
        cache_key = f"overseerr::episodes::{series_id}::{season_key}"
        if cache_key in _cache:
            ts, data = _cache[cache_key]
            if time.time() - ts < _TTL:
                return self._filter_episodes(data, include_unreleased)
        try:
            details = await self._get(f"/tv/{series_id}")
            episodes = []
            for season in details.get("seasons", []):
                sn = season.get("seasonNumber", 0)
                if sn == 0:
                    continue
                # Skip seasons not in the requested list
                if requested_seasons and sn not in requested_seasons:
                    continue
                try:
                    sd = await self._get(f"/tv/{series_id}/season/{sn}")
                    for ep in sd.get("episodes", []):
                        episodes.append({
                            "season":   sn,
                            "episode":  ep.get("episodeNumber", 0),
                            "title":    ep.get("name", ""),
                            "air_date": ep.get("airDate", ""),
                            "has_file": False,
                        })
                except Exception:
                    pass
            _cache[cache_key] = (time.time(), episodes)
            return self._filter_episodes(episodes, include_unreleased)
        except Exception as e:
            log.error(f"Failed to fetch episodes for {series_id}: {e}")
            return []

    def _filter_episodes(self, episodes: list, include_unreleased: bool) -> list:
        if include_unreleased:
            return [e for e in episodes if e.get("season", 0) > 0]
        today = date.today().isoformat()
        return [
            e for e in episodes
            if e.get("season", 0) > 0
            and e.get("air_date") is not None
            and e.get("air_date", "") != ""
            and e.get("air_date", "") <= today
        ]

    # ── Fake file creation ─────────────────────────────────────────────────────

    def create_fake_movie(self, title: str, year: Optional[int]) -> Optional[Path]:
        if not self.plex_root:
            return None
        try:
            year_part = f" ({year})" if year else ""
            folder = Path(self.plex_root) / "movies" / f"{title}{year_part}"
            path = folder / f"{title}{year_part}.mp4"
            folder.mkdir(parents=True, exist_ok=True)
            if not path.exists():
                path.write_bytes(_FAKE_MP4)
            log.info(f"🎬 Fake movie: {path}")
            return path
        except Exception as e:
            log.error(f"Failed to create fake movie '{title}': {e}")
            return None

    def create_fake_episodes(self, title: str, year, seasons: list, episodes: list) -> list:
        """
        Create .mp4 placeholder files for every episode in the list.
        Skips an episode only if a real .mkv symlink already exists for it (already cached).
        Always writes placeholder if only an old .mp4 placeholder exists.
        """
        if not self.plex_root:
            log.warning(f"create_fake_episodes: plex_root not set — skipping")
            return []
        if not episodes:
            log.warning(f"create_fake_episodes: no episodes provided for '{title}'")
            return []
        created = []
        for ep in episodes:
            s, e = ep["season"], ep["episode"]
            folder = Path(self.plex_root) / "tv" / title / f"Season {s:02d}"
            fname  = f"{title} - S{s:02d}E{e:02d}.mp4"
            path   = folder / fname
            se_pat = f"S{s:02d}E{e:02d}".upper()
            try:
                folder.mkdir(parents=True, exist_ok=True)
                # Skip only if a working symlink (cached .mkv) already covers this episode
                has_symlink = any(
                    f.is_symlink() and se_pat in f.name.upper()
                    for f in folder.iterdir()
                ) if folder.exists() else False
                if not has_symlink:
                    path.write_bytes(_FAKE_MP4)
                    created.append(path)
                else:
                    log.debug(f"  Skipping {fname} — symlink exists")
            except Exception as ex:
                log.error(f"Failed to create episode '{fname}': {ex}")
        log.info(f"📺 {len(created)} placeholders created for '{title}' ({len(episodes)} eps total)")
        return created

    def remove_fake_movie(self, title: str, year: Optional[int]) -> bool:
        try:
            year_part = f" ({year})" if year else ""
            folder = Path(self.plex_root) / "movies" / f"{title}{year_part}"
            if folder.exists():
                shutil.rmtree(folder)
                log.info(f"🗑️  Removed: {folder}")
                return True
        except Exception as e:
            log.error(f"Failed to remove movie '{title}': {e}")
        return False

    def remove_fake_series(self, title: str) -> bool:
        try:
            folder = Path(self.plex_root) / "tv" / title
            if folder.exists():
                shutil.rmtree(folder)
                log.info(f"🗑️  Removed: {folder}")
                return True
        except Exception as e:
            log.error(f"Failed to remove series '{title}': {e}")
        return False

    def invalidate_cache(self):
        _cache.clear()

    # ── Direct Sonarr / Radarr import ────────────────────────────────────────

    async def get_radarr_direct(self, url: str, api_key: str) -> list[dict]:
        """Fetch all movies directly from Radarr (bypasses Overseerr)."""
        if not url or not api_key:
            return []
        cache_key = f"radarr_direct::{url}"
        if cache_key in _cache:
            ts, data = _cache[cache_key]
            if time.time() - ts < _TTL:
                return data
        try:
            async with httpx.AsyncClient(timeout=15) as c:
                r = await c.get(
                    f"{url.rstrip('/')}/api/v3/movie",
                    headers={"X-Api-Key": api_key},
                )
                r.raise_for_status()
                movies = []
                for m in r.json():
                    # Try every Radarr release date field, fall back to year
                    release_date = (
                        m.get("digitalRelease") or
                        m.get("physicalRelease") or
                        m.get("inCinemas") or
                        m.get("releaseDate") or ""
                    )
                    if release_date:
                        release_date = release_date[:10]  # YYYY-MM-DD
                    # If still empty but we have a year, synthesise a date so
                    # the release filter works correctly (Jan 1 of that year)
                    radarr_year = m.get("year")
                    if not release_date and radarr_year:
                        release_date = f"{radarr_year}-01-01"
                    year = int(release_date[:4]) if release_date else radarr_year
                    movies.append({
                        "id":           m.get("id"),
                        "title":        m.get("title", "Unknown"),
                        "year":         year,
                        "release_date": release_date,
                        "tmdb_id":      m.get("tmdbId"),
                        "imdb_id":      m.get("imdbId", ""),
                        "poster":       self._radarr_poster(url, m),
                        "overview":     m.get("overview", ""),
                        "has_file":     m.get("hasFile", False),
                        "monitored":    m.get("monitored", True),
                        "source":       "radarr",
                    })
                movies.sort(key=lambda x: x["title"].lstrip("The ").lstrip("A "))
                _cache[cache_key] = (time.time(), movies)
                log.info(f"Radarr direct: {len(movies)} movies")
                return movies
        except Exception as e:
            log.error(f"Radarr direct import failed: {e}")
            return []

    def _radarr_poster(self, base_url: str, movie: dict) -> str:
        for img in movie.get("images", []):
            if img.get("coverType") == "poster":
                url = img.get("remoteUrl") or img.get("url", "")
                if url.startswith("http"):
                    return url
                if url:
                    return f"{base_url.rstrip('/')}{url}"
        return ""

    async def get_sonarr_direct(self, url: str, api_key: str) -> list[dict]:
        """Fetch all series directly from Sonarr (bypasses Overseerr)."""
        if not url or not api_key:
            return []
        cache_key = f"sonarr_direct::{url}"
        if cache_key in _cache:
            ts, data = _cache[cache_key]
            if time.time() - ts < _TTL:
                return data
        try:
            async with httpx.AsyncClient(timeout=15) as c:
                r = await c.get(
                    f"{url.rstrip('/')}/api/v3/series",
                    headers={"X-Api-Key": api_key},
                )
                r.raise_for_status()
                series = []
                for s in r.json():
                    status    = s.get("status", "continuing").lower()
                    is_ended  = status in ("ended", "deleted")
                    seasons   = [
                        {"season_number": sn["seasonNumber"], "episode_count": sn.get("statistics", {}).get("totalEpisodeCount", 0)}
                        for sn in s.get("seasons", [])
                        if sn.get("seasonNumber", 0) > 0
                    ]
                    series.append({
                        "id":           s.get("id"),
                        "title":        s.get("title", "Unknown"),
                        "year":         s.get("year"),
                        "tvdb_id":      s.get("tvdbId"),
                        "tmdb_id":      s.get("tmdbId"),
                        "imdb_id":      s.get("imdbId", ""),
                        "poster":       self._sonarr_poster(url, s),
                        "overview":     s.get("overview", ""),
                        "status":       status,
                        "is_ended":     is_ended,
                        "monitored":    s.get("monitored", True),
                        "season_count": len(seasons),
                        "seasons":      seasons,
                        "requested_seasons": [],
                        "source":       "sonarr",
                    })
                series.sort(key=lambda x: x["title"].lstrip("The ").lstrip("A "))
                _cache[cache_key] = (time.time(), series)
                log.info(f"Sonarr direct: {len(series)} series")
                return series
        except Exception as e:
            log.error(f"Sonarr direct import failed: {e}")
            return []

    def _sonarr_poster(self, base_url: str, series: dict) -> str:
        for img in series.get("images", []):
            if img.get("coverType") == "poster":
                url = img.get("remoteUrl") or img.get("url", "")
                if url.startswith("http"):
                    return url
                if url:
                    return f"{base_url.rstrip('/')}{url}"
        return ""

    def invalidate_direct_cache(self):
        for k in [k for k in list(_cache) if k.startswith(("radarr_direct::", "sonarr_direct::"))]:
            del _cache[k]

    async def sync_series_episodes(self, title: str, series_id: int, year: Optional[int], include_unreleased: bool, requested_seasons: list = None) -> dict:
        if not self.plex_root:
            return {"added": 0, "removed": 0}
        show_folder = Path(self.plex_root) / "tv" / title
        added = removed = 0
        try:
            all_eps = await self.get_episodes(series_id, include_unreleased=True, requested_seasons=requested_seasons)
            should = self._filter_episodes(all_eps, include_unreleased)

            # Simple filename — no episode title to avoid duplicates
            def fname(ep):
                return f"{title} - S{ep['season']:02d}E{ep['episode']:02d}.mp4"

            should_names = {fname(e) for e in should}

            # Only look at .mp4 placeholder files — never touch .mkv symlinks
            existing: dict[str, Path] = {}
            if show_folder.exists():
                for sd in show_folder.iterdir():
                    if sd.is_dir():
                        for f in sd.iterdir():
                            if f.suffix == ".mp4" and not f.is_symlink():
                                existing[f.name] = f

            # Add missing placeholders — but skip if a symlink already exists for that episode
            for ep in should:
                fn = fname(ep)
                if fn not in existing:
                    # Check if a symlink already covers this S##E## (resolved stream)
                    se_pat = f"S{ep['season']:02d}E{ep['episode']:02d}".upper()
                    sf = show_folder / f"Season {ep['season']:02d}"
                    has_symlink = sf.exists() and any(
                        f.is_symlink() and se_pat in f.name.upper()
                        for f in sf.iterdir()
                    )
                    if not has_symlink:
                        sf.mkdir(parents=True, exist_ok=True)
                        (sf / fn).write_bytes(_FAKE_MP4)
                        added += 1

            # Remove placeholders for episodes no longer in request
            # Never remove symlinks (.mkv) — those are resolved streams
            for fn, fp in existing.items():
                if fn not in should_names:
                    fp.unlink(missing_ok=True)
                    removed += 1
                    _rmdir_if_empty(fp.parent)

            log.info(f"🔄 Synced '{title}': +{added} added, -{removed} removed")
        except Exception as e:
            log.error(f"sync_series_episodes failed for '{title}': {e}", exc_info=True)
        return {"added": added, "removed": removed}


def _rmdir_if_empty(path: Path):
    try:
        if path.exists() and not any(path.iterdir()):
            path.rmdir()
    except Exception:
        pass
