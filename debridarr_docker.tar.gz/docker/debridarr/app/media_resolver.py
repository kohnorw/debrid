"""
MediaResolver — queries Sonarr and Radarr to enrich play events with
accurate metadata (TVDB IDs, IMDB IDs, exact episode titles).
Results are cached in-process to minimize API calls.
"""

import logging
import time
from typing import Optional

import httpx

log = logging.getLogger("debridarr.resolver")

_meta_cache: dict[str, tuple[float, dict]] = {}
_META_TTL = 3600 * 6  # 6 hours


class MediaResolver:
    def __init__(
        self,
        sonarr_url: str = "",
        sonarr_key: str = "",
        radarr_url: str = "",
        radarr_key: str = "",
    ):
        self.sonarr_url = sonarr_url.rstrip("/")
        self.sonarr_key = sonarr_key
        self.radarr_url = radarr_url.rstrip("/")
        self.radarr_key = radarr_key
        self._client = httpx.AsyncClient(timeout=10)

    async def get_movie_meta(self, title: str, year: Optional[int] = None) -> dict:
        """Look up movie in Radarr to get IMDB/TMDB IDs."""
        cache_key = f"radarr::{title}::{year}"
        if cache_key in _meta_cache:
            ts, data = _meta_cache[cache_key]
            if time.time() - ts < _META_TTL:
                return data

        if not self.radarr_url or not self.radarr_key:
            return {}

        try:
            resp = await self._client.get(
                f"{self.radarr_url}/api/v3/movie/lookup",
                params={"term": title},
                headers={"X-Api-Key": self.radarr_key},
            )
            movies = resp.json()
            # Find best match
            for m in movies:
                if year and m.get("year") != year:
                    continue
                meta = {
                    "title": m.get("title", title),
                    "year": m.get("year"),
                    "imdb_id": m.get("imdbId"),
                    "tmdb_id": m.get("tmdbId"),
                }
                _meta_cache[cache_key] = (time.time(), meta)
                return meta
        except Exception as e:
            log.debug(f"Radarr lookup failed for '{title}': {e}")

        return {}

    async def get_episode_meta(
        self, title: str, season: Optional[int], episode: Optional[int]
    ) -> dict:
        """Look up episode in Sonarr to get TVDB ID and episode title."""
        cache_key = f"sonarr::{title}::s{season}e{episode}"
        if cache_key in _meta_cache:
            ts, data = _meta_cache[cache_key]
            if time.time() - ts < _META_TTL:
                return data

        if not self.sonarr_url or not self.sonarr_key:
            return {}

        try:
            # First find the series
            series_resp = await self._client.get(
                f"{self.sonarr_url}/api/v3/series/lookup",
                params={"term": title},
                headers={"X-Api-Key": self.sonarr_key},
            )
            series_list = series_resp.json()
            if not series_list:
                return {}

            series = series_list[0]
            series_id = series.get("id") or series.get("tvdbId")
            meta = {
                "title": series.get("title", title),
                "tvdb_id": series.get("tvdbId"),
                "season": season,
                "episode": episode,
            }
            _meta_cache[cache_key] = (time.time(), meta)
            return meta

        except Exception as e:
            log.debug(f"Sonarr lookup failed for '{title}': {e}")

        return {}
