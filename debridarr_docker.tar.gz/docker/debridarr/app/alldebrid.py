"""
AllDebrid API client — robust multi-source search with fallback chain.

Search strategy (tries each until results found):
  1. TPB exact: "Hacks S04E05 1080p"
  2. TPB without quality: "Hacks S04E05"
  3. TPB season pack: "Hacks Season 4"  (episodes only)
  4. TPB title only + year: "Hacks 2021"
  5. Fallback indexers: YIFY (movies), RARBG mirror, 1337x API

For each batch of results we do ONE AllDebrid instant-cache check.
Prefer cached torrents; fall back to best-seeded if nothing is cached.
"""

import asyncio
import logging
import re
import time
import urllib.parse
from typing import Optional

import httpx

log = logging.getLogger("debridarr.alldebrid")

ALLDEBRID_API = "https://api.alldebrid.com/v4"
AGENT = "debridarr"

# TPB mirrors — tried in order
TPB_ENDPOINTS = [
    "https://apibay.org/q.php",
    "https://thepiratebay.org/api/q.php",
]

# Extra public indexers
YIFY_API    = "https://yts.mx/api/v2/list_movies.json"
ITORRENTS   = "https://itorrents-indexer.fly.dev/search"  # 1337x-compatible

_search_cache: dict[str, tuple[float, list]] = {}
_CACHE_TTL = 3600  # 1 hour


class AllDebridClient:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self._client = httpx.AsyncClient(
            timeout=20,
            headers={"User-Agent": "debridarr/0.2"},
            follow_redirects=True,
        )

    # ─────────────────────────────────────────────────────────────────────────
    # Public
    # ─────────────────────────────────────────────────────────────────────────

    async def search_cached(
        self,
        title: str,
        media_type: str = "movie",
        year: Optional[int] = None,
        season: Optional[int] = None,
        episode: Optional[int] = None,
        imdb_id: Optional[str] = None,
    ) -> list[dict]:
        """
        Try multiple search strategies until we find AllDebrid-cached results.
        Returns scored list of torrents (best first).
        """
        cache_key = f"{title}::{media_type}::s{season}e{episode}"
        if cache_key in _search_cache:
            ts, results = _search_cache[cache_key]
            if time.time() - ts < _CACHE_TTL:
                log.debug(f"Search cache hit: {cache_key}")
                return results

        queries = self._build_queries(title, media_type, year, season, episode)
        all_torrents: list[dict] = []

        for query, cat in queries:
            log.info(f"🔎 Trying: {query!r}")
            torrents = await self._search_tpb(query, cat)

            # Try YIFY as extra source for movies
            if not torrents and media_type == "movie":
                torrents = await self._search_yify(title, year)

            if not torrents:
                log.debug(f"  No results for {query!r}")
                continue

            # Deduplicate against what we already have
            seen = {t["info_hash"] for t in all_torrents}
            new = [t for t in torrents if t["info_hash"] not in seen]
            all_torrents.extend(new)

            # Batch-check AllDebrid cache for everything collected so far
            hashes = [t["info_hash"] for t in all_torrents]
            cached_hashes = await self._check_cache_batch(hashes)
            cached = [t for t in all_torrents if t["info_hash"] in cached_hashes]

            if cached:
                log.info(f"✅ Found {len(cached)} cached on AllDebrid via {query!r}")
                scored = self._score(cached, media_type, season, episode)
                _search_cache[cache_key] = (time.time(), scored[:5])
                return scored[:5]

            log.debug(f"  {len(new)} results, 0 cached — trying next query")

        # Nothing cached anywhere — fall back to best seeded from everything collected
        if all_torrents:
            log.warning(
                f"⚠️  No cached results after {len(queries)} queries for '{title}' "
                f"— using best-seeded (may be slow)"
            )
            scored = self._score(
                sorted(all_torrents, key=lambda t: int(t.get("seeders", 0)), reverse=True)[:3],
                media_type, season, episode,
            )
            _search_cache[cache_key] = (time.time(), scored)
            return scored

        log.error(f"❌ No results at all for '{title}' after exhausting all sources")
        _search_cache[cache_key] = (time.time(), [])
        return []

    async def unlock_magnet(self, magnet: str) -> Optional[str]:
        """Upload magnet to AllDebrid, wait for ready, return best video stream URL."""
        try:
            resp = await self._client.get(
                f"{ALLDEBRID_API}/magnet/upload",
                params={"agent": AGENT, "apikey": self.api_key, "magnets[]": magnet},
            )
            data = resp.json()
            if data.get("status") != "success":
                log.error(f"Magnet upload failed: {data}")
                return None

            magnet_id = data["data"]["magnets"][0]["id"]

            for attempt in range(15):
                status_resp = await self._client.get(
                    f"{ALLDEBRID_API}/magnet/status",
                    params={"agent": AGENT, "apikey": self.api_key, "id": magnet_id},
                )
                info = status_resp.json().get("data", {}).get("magnets", {})
                status = info.get("status", "")
                log.debug(f"Magnet {magnet_id} status: {status}")
                if status == "Ready":
                    break
                if status in ("Error", "Fail", "Deleted"):
                    log.error(f"Magnet failed: {status}")
                    return None
                await asyncio.sleep(2 if attempt < 5 else 5)
            else:
                log.error("Magnet timed out")
                return None

            links_resp = await self._client.get(
                f"{ALLDEBRID_API}/magnet/files",
                params={"agent": AGENT, "apikey": self.api_key, "id[]": magnet_id},
            )
            files = links_resp.json().get("data", {}).get("magnets", [{}])[0].get("files", [])
            if not files:
                log.error("No files in magnet")
                return None

            video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
            flat = self._flatten_files(files)
            videos = [f for f in flat if any(f["n"].lower().endswith(e) for e in video_exts)]
            best = max(videos or flat, key=lambda f: f.get("s", 0))
            link = best.get("l", "")
            if not link:
                return None
            return await self.unlock_link(link)

        except Exception as e:
            log.error(f"unlock_magnet failed: {e}", exc_info=True)
            return None

    async def unlock_link(self, link: str) -> Optional[str]:
        try:
            resp = await self._client.get(
                f"{ALLDEBRID_API}/link/unlock",
                params={"agent": AGENT, "apikey": self.api_key, "link": link},
            )
            data = resp.json()
            if data.get("status") != "success":
                log.error(f"Link unlock failed: {data}")
                return None
            return data["data"]["link"]
        except Exception as e:
            log.error(f"unlock_link failed: {e}", exc_info=True)
            return None

    # ─────────────────────────────────────────────────────────────────────────
    # Query builder
    # ─────────────────────────────────────────────────────────────────────────

    def _build_queries(
        self,
        title: str,
        media_type: str,
        year: Optional[int],
        season: Optional[int],
        episode: Optional[int],
    ) -> list[tuple[str, str]]:
        """
        Return ordered list of (query_string, tpb_category) to try.
        Episode queries go from specific → broad.
        Movie queries try multiple quality tags.
        """
        t = self._clean(title)
        queries: list[tuple[str, str]] = []

        if media_type == "episode":
            cat = "205"  # TPB: TV shows
            if season and episode:
                se      = f"S{season:02d}E{episode:02d}"
                se_dot  = f"S{season:02d}.E{episode:02d}"
                se_x    = f"{season}x{episode:02d}"
                # Specific episode, multiple quality variants
                for q in ["1080p", "720p", ""]:
                    queries.append((f"{t} {se} {q}".strip(), cat))
                for q in ["1080p", ""]:
                    queries.append((f"{t} {se_dot} {q}".strip(), cat))
                queries.append((f"{t} {se_x}", cat))
            if season:
                # Season pack — Plex can pick the right episode from a pack
                for q in ["1080p", "720p", ""]:
                    queries.append((f"{t} Season {season} {q}".strip(), cat))
                queries.append((f"{t} S{season:02d} Complete", cat))
            # Broad title search
            queries.append((t, cat))

        else:  # movie
            cat = "207"  # TPB: HD Movies (falls back to 200 if empty)
            year_str = str(year) if year else ""
            for q in ["2160p", "1080p", "BluRay", "720p", ""]:
                queries.append((f"{t} {year_str} {q}".strip(), cat))
            # Also try general video category
            queries.append((f"{t} {year_str}".strip(), "200"))

        return queries

    # ─────────────────────────────────────────────────────────────────────────
    # Sources
    # ─────────────────────────────────────────────────────────────────────────

    async def _search_tpb(self, query: str, cat: str) -> list[dict]:
        clean = re.sub(r"[^\w\s\.\-]", "", query).strip()
        for endpoint in TPB_ENDPOINTS:
            try:
                resp = await self._client.get(
                    endpoint,
                    params={"q": clean, "cat": cat},
                    timeout=10,
                )
                if resp.status_code != 200:
                    continue
                results = resp.json()
                if not results or (
                    len(results) == 1
                    and results[0].get("name") in ("No results returned", "")
                ):
                    continue
                torrents = []
                for r in results:
                    if not r.get("info_hash"):
                        continue
                    torrents.append({
                        "info_hash": r["info_hash"].upper(),
                        "name":      r.get("name", ""),
                        "size":      int(r.get("size", 0)),
                        "seeders":   int(r.get("seeders", 0)),
                        "magnet":    self._build_magnet(r["info_hash"], r.get("name", "")),
                        "quality":   self._detect_quality(r.get("name", "")),
                        "source":    "tpb",
                    })
                if torrents:
                    return torrents
            except Exception as e:
                log.debug(f"TPB endpoint {endpoint} failed: {e}")
        return []

    async def _search_yify(self, title: str, year: Optional[int]) -> list[dict]:
        """YIFY/YTS — great for movies, has reliable 1080p/4K."""
        try:
            params = {"query_term": title, "sort_by": "seeds", "limit": 20}
            if year:
                params["query_term"] = f"{title} {year}"
            resp = await self._client.get(YIFY_API, params=params, timeout=10)
            data = resp.json()
            movies = data.get("data", {}).get("movies", [])
            torrents = []
            for m in movies:
                for t in m.get("torrents", []):
                    info_hash = t.get("hash", "").upper()
                    if not info_hash:
                        continue
                    name = f"{m['title']} ({m.get('year','')})"
                    quality = t.get("quality", "")
                    torrents.append({
                        "info_hash": info_hash,
                        "name":      f"{name} {quality}",
                        "size":      t.get("size_bytes", 0),
                        "seeders":   t.get("seeds", 0),
                        "magnet":    self._build_magnet(info_hash, name),
                        "quality":   self._detect_quality(quality),
                        "source":    "yify",
                    })
            return torrents
        except Exception as e:
            log.debug(f"YIFY search failed: {e}")
        return []

    # ─────────────────────────────────────────────────────────────────────────
    # AllDebrid cache check
    # ─────────────────────────────────────────────────────────────────────────

    async def _check_cache_batch(self, hashes: list[str]) -> set[str]:
        if not hashes:
            return set()
        try:
            params = [("agent", AGENT), ("apikey", self.api_key)]
            for h in hashes[:50]:
                params.append(("magnets[]", h))
            resp = await self._client.get(
                f"{ALLDEBRID_API}/magnet/instant", params=params, timeout=15
            )
            data = resp.json()
            if data.get("status") != "success":
                return set()
            cached = set()
            for m in data.get("data", {}).get("magnets", []):
                if m.get("instant") or m.get("cached"):
                    cached.add(m.get("hash", "").upper())
            return cached
        except Exception as e:
            log.error(f"Batch cache check failed: {e}")
            return set()

    # ─────────────────────────────────────────────────────────────────────────
    # Helpers
    # ─────────────────────────────────────────────────────────────────────────

    def _clean(self, title: str) -> str:
        """Strip special chars, collapse spaces."""
        return re.sub(r"\s+", " ", re.sub(r"[^\w\s]", " ", title)).strip()

    def _build_magnet(self, info_hash: str, name: str) -> str:
        trackers = [
            "udp://tracker.opentrackr.org:1337/announce",
            "udp://open.stealth.si:80/announce",
            "udp://tracker.torrent.eu.org:451/announce",
            "udp://exodus.desync.com:6969/announce",
        ]
        dn = urllib.parse.quote(name)
        tr = "&".join(f"tr={urllib.parse.quote(t)}" for t in trackers)
        return f"magnet:?xt=urn:btih:{info_hash}&dn={dn}&{tr}"

    def _detect_quality(self, name: str) -> str:
        n = name.lower()
        for q in ["2160p", "4k", "uhd", "1080p", "720p", "480p"]:
            if q in n:
                return q
        return "unknown"

    def _score(
        self,
        torrents: list[dict],
        media_type: str,
        season: Optional[int],
        episode: Optional[int],
    ) -> list[dict]:
        """
        Score torrents. For episodes, strongly prefer exact S##E## matches
        over season packs to avoid Plex having to pick from a multi-file torrent.
        """
        se_tag = ""
        if season and episode:
            se_tag = f"s{season:02d}e{episode:02d}"

        def score(t: dict) -> float:
            name_lower = t.get("name", "").lower()
            q = t.get("quality", "").lower()

            # Quality score
            q_score = {"1080p": 100, "2160p": 85, "4k": 85, "720p": 60, "unknown": 20}.get(q, 20)

            # Exact episode match bonus (for TV)
            ep_score = 50 if se_tag and se_tag in name_lower else 0

            # Season pack penalty — prefer single episode files
            pack_penalty = -30 if any(w in name_lower for w in ["complete", "season", "batch", "pack"]) else 0

            # Source bonus
            src_score = 5 if t.get("source") == "yify" else 0

            # Size score (bigger = better quality, up to ~15GB)
            size_gb = t.get("size", 0) / (1024 ** 3)
            size_score = min(size_gb * 3, 15)

            return q_score + ep_score + pack_penalty + src_score + size_score

        return sorted(torrents, key=score, reverse=True)

    def _flatten_files(self, files, depth=0) -> list[dict]:
        result = []
        for f in files:
            if "e" in f:
                result.extend(self._flatten_files(f["e"], depth + 1))
            else:
                result.append(f)
        return result
