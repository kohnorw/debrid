"""
AllDebrid API client.

Search logic ported from kohnorw/debrid alldebrid-web/app.py:
  - _sanitize, parse_query, strip_season, filter_by_season, filter_by_quality
  - check_cache: uploads magnets → reads ready flag → immediately deletes them
    (nothing stays in your AllDebrid account)
  - Multi-mirror TPB fetch with fallback
  - Season strip fallback: no results for S04E05 → retry with just title
  - Quality fallback: no 1080p results → broaden to any quality

Unlock logic (separate from search):
  - unlock_magnet: adds magnet for real, waits for ready, returns stream URL
  - unlock_link: converts AllDebrid link to direct CDN URL
"""

import asyncio
import logging
import re
import time
import urllib.parse
from typing import Optional

import httpx

log = logging.getLogger("debridarr.alldebrid")

ALLDEBRID_API    = "https://api.alldebrid.com/v4"
ALLDEBRID_UPLOAD = f"{ALLDEBRID_API}/magnet/upload"
ALLDEBRID_DELETE = f"{ALLDEBRID_API}/magnet/delete"
AGENT            = "debridarr"

APIBAY_URLS = [
    "https://apibay.org/q.php",
    "https://apibay.nocensor.space/q.php",
    "https://thepiratebay.org/q.php",
]

QUALITY_RE = re.compile(
    r'\b(2160p?|1080p?|720p?|480p?|4k|uhd|hdr|hdr10|dv|web-?dl|webrip|bluray|blu-ray'
    r'|hevc|x265|x264|h264|h265|remux|proper|repack)\b',
    re.IGNORECASE,
)

_search_cache: dict[str, tuple[float, list]] = {}
_CACHE_TTL = 3600


# ── Query helpers (ported from kohnorw/debrid) ────────────────────────────────

def _sanitize(query: str) -> str:
    q = re.sub(r"[''`´]", "", query)
    q = re.sub(r"[^\w\s\-]", " ", q)
    return re.sub(r"\s+", " ", q).strip()


def _parse_query(raw: str) -> tuple[str, Optional[int], Optional[int], list[str]]:
    """
    Returns (clean_title, season, episode, quality_tokens).
    Converts 'Season 4' → 'S04', extracts S##E## etc.
    """
    quality = QUALITY_RE.findall(raw)
    search_raw = QUALITY_RE.sub("", raw).strip()

    # "Season 4" → "S04"
    m = re.search(r'\bseason\s+(\d+)\b', search_raw, re.IGNORECASE)
    if m:
        season_num = int(m.group(1))
        search_raw = re.sub(
            r'\bseason\s+\d+\b', f"S{season_num:02d}", search_raw, flags=re.IGNORECASE
        )

    season = episode = None
    m = re.search(r'(?<![a-zA-Z])S(\d{1,2})(?:E(\d{1,2}))?(?![a-zA-Z0-9])', search_raw, re.IGNORECASE)
    if m:
        season = int(m.group(1))
        if m.group(2):
            episode = int(m.group(2))

    return " ".join(search_raw.split()).strip(), season, episode, quality


def _strip_season(query: str) -> str:
    t = re.sub(r'(?<![a-zA-Z])S\d{1,2}(?:E\d{1,2})?(?![a-zA-Z0-9])', "", query, flags=re.IGNORECASE)
    return " ".join(t.split())


def _filter_by_season(torrents: list[dict], season: Optional[int], episode: Optional[int]) -> list[dict]:
    if season is None:
        return torrents
    # Match S07, SEASON 7, SEASON 07 — all valid formats on TPB
    season_patterns = [
        f"S{season:02d}",
        f"SEASON {season}",
        f"SEASON {season:02d}",
        f"S{season:02d} ",   # bare season without episode
    ]
    out = []
    for t in torrents:
        nu = t.get("name", "").upper()
        if not any(p in nu for p in season_patterns):
            continue
        # Reject packs that explicitly span multiple seasons (S01E01...S03E10 style)
        others = re.findall(r"S(\d{2})E\d{2}", nu)
        if others and not all(int(s) == season for s in others):
            continue
        # Only reject on missing episode tag if the torrent has episode tags at all
        # (season packs don't have E## and should still pass through)
        has_ep_tag = bool(re.search(r'E\d{2}', nu))
        if episode is not None and has_ep_tag and f"E{episode:02d}" not in nu:
            continue
        out.append(t)
    return out


def _filter_by_quality(torrents: list[dict], quality: list[str]) -> list[dict]:
    if not quality:
        return torrents
    out = [
        t for t in torrents
        if any(q.upper().rstrip("P") in t.get("name", "").upper() for q in quality)
    ]
    return out if out else torrents


def _score(torrents: list[dict], season: Optional[int], episode: Optional[int]) -> list[dict]:
    se_tag = f"s{season:02d}e{episode:02d}" if season and episode else ""

    def _s(t: dict) -> float:
        name = t.get("name", "").lower()
        q = t.get("quality", "").lower()
        q_score = {"1080p": 100, "2160p": 85, "4k": 85, "720p": 60}.get(q, 20)
        ep_score = 50 if se_tag and se_tag in name else 0
        pack_pen = -30 if any(w in name for w in ("complete", "season", "batch", "pack")) else 0
        size_score = min(t.get("size", 0) / (1024**3) * 3, 15)
        cached_bonus = 200 if t.get("cached") else 0
        return cached_bonus + q_score + ep_score + pack_pen + size_score

    return sorted(torrents, key=_s, reverse=True)


# ── TPB fetch ─────────────────────────────────────────────────────────────────

async def _fetch_tpb(client: httpx.AsyncClient, query: str, limit: int = 40) -> list[dict]:
    """Try each apibay mirror, return first successful result."""
    queries = [query]
    sanitized = _sanitize(query)
    if sanitized.lower() != query.lower():
        queries.append(sanitized)

    for q in queries:
        for url in APIBAY_URLS:
            try:
                resp = await client.get(url, params={"q": q, "cat": 0}, timeout=10)
                if resp.status_code != 200:
                    continue
                data = resp.json()
                if not data or (isinstance(data, list) and data[0].get("id") == "0"):
                    continue
                valid = [
                    x for x in data
                    if isinstance(x, dict)
                    and x.get("info_hash")
                    and re.fullmatch(r'[0-9a-fA-F]{40}', x["info_hash"])
                ]
                if valid:
                    log.debug(f"TPB hit on {url!r} for {q!r}: {len(valid)} results")
                    return valid[:limit]
            except Exception as e:
                log.debug(f"TPB {url} failed: {e}")
    return []


# ── AllDebrid cache check (upload → check ready → delete) ─────────────────────

def _make_magnet(info_hash: str, name: str = "") -> str:
    dn = urllib.parse.quote(name, safe="")
    return f"magnet:?xt=urn:btih:{info_hash.lower()}&dn={dn}"


async def _check_cache(client: httpx.AsyncClient, api_key: str, torrents: list[dict]) -> dict[str, bool]:
    """
    Upload all magnets to AllDebrid, read the ready flag, delete them immediately.
    Returns {info_hash_lower: bool}.
    Nothing stays in your AllDebrid account.
    """
    if not torrents or not api_key:
        return {}

    pairs = [("magnets[]", _make_magnet(t["info_hash"], t.get("name", ""))) for t in torrents]
    body = urllib.parse.urlencode(pairs)

    try:
        resp = await client.post(
            ALLDEBRID_UPLOAD,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/x-www-form-urlencoded",
            },
            content=body,
            timeout=15,
        )
        result = resp.json()
    except Exception as e:
        log.error(f"AllDebrid upload failed: {e}")
        return {}

    if result.get("status") == "error":
        log.warning(f"AllDebrid upload error: {result}")
        return {}

    ready_map: dict[str, bool] = {}
    ids_to_delete = []

    for m in result.get("data", {}).get("magnets", []):
        if m.get("error"):
            continue
        h = (m.get("hash") or "").lower()
        if h:
            ready_map[h] = bool(m.get("ready", False))
        if m.get("id"):
            ids_to_delete.append(m["id"])

    # Delete immediately — we only wanted to check cache status
    for mid in ids_to_delete:
        try:
            await client.post(
                ALLDEBRID_DELETE,
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                content=urllib.parse.urlencode({"id": mid}),
                timeout=10,
            )
        except Exception:
            pass

    cached_count = sum(1 for v in ready_map.values() if v)
    log.info(f"Cache check: {cached_count}/{len(ready_map)} cached")
    return ready_map


# ── Main client ───────────────────────────────────────────────────────────────

class AllDebridClient:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self._client = httpx.AsyncClient(
            timeout=20,
            headers={"User-Agent": "debridarr/0.2"},
            follow_redirects=True,
        )

    async def search_cached(
        self,
        title: str,
        media_type: str = "movie",
        year: Optional[int] = None,
        season: Optional[int] = None,
        episode: Optional[int] = None,
        imdb_id: Optional[str] = None,
    ) -> list[dict]:
        """
        Search TPB, check AllDebrid cache, return scored results.
        Mirrors the do_search() logic from kohnorw/debrid.
        """
        cache_key = f"{title}::{media_type}::s{season}e{episode}"
        if cache_key in _search_cache:
            ts, results = _search_cache[cache_key]
            if time.time() - ts < _CACHE_TTL:
                log.debug(f"Search cache hit: {cache_key}")
                return results

        # Build the initial query the same way alldebrid-web does
        if media_type == "episode" and season and episode:
            query = f"{title} S{season:02d}E{episode:02d}"
        elif media_type == "episode" and season:
            query = f"{title} S{season:02d}"
        else:
            query = f"{title} {year or ''}".strip()

        # parse_query handles "Season X" → S0X conversion, extracts quality tokens
        parsed_q, parsed_s, parsed_ep, quality = _parse_query(query)
        log.info(f"🔎 Searching: {parsed_q!r} s={parsed_s} ep={parsed_ep} quality={quality}")

        torrents = await _fetch_tpb(self._client, parsed_q)

        # Season/episode fallback: strip season tag and retry with just title
        if not torrents and parsed_s is not None:
            fallback = _strip_season(parsed_q)
            if fallback and fallback.lower() != parsed_q.lower():
                log.info(f"🔎 Fallback search (no season): {fallback!r}")
                torrents = await _fetch_tpb(self._client, fallback, limit=80)

        if not torrents:
            log.warning(f"No TPB results for '{title}'")
            _search_cache[cache_key] = (time.time(), [])
            return []

        # Filter by season/episode
        filtered = _filter_by_season(torrents, parsed_s, parsed_ep)
        if not filtered and parsed_s is not None:
            log.info("Season filter returned nothing — using all results")
            filtered = torrents

        # Filter by quality — but don't wipe results if no quality matches
        if quality:
            filtered = _filter_by_quality(filtered, quality)

        # Check AllDebrid cache (upload all → read ready → delete all)
        ready_map = await _check_cache(self._client, self.api_key, filtered)

        # Annotate with cache status + quality + build magnets
        results = []
        for t in filtered:
            h = t["info_hash"].lower()
            results.append({
                "info_hash": h,
                "name":      t.get("name", ""),
                "size":      int(t.get("size", 0)),
                "seeders":   int(t.get("seeders", 0) or 0),
                "magnet":    _make_magnet(h, t.get("name", "")),
                "quality":   self._detect_quality(t.get("name", "")),
                "cached":    ready_map.get(h, False),
                "source":    "tpb",
            })

        # Sort: cached first, then by score
        scored = _score(results, parsed_s, parsed_ep)
        cached_results = [r for r in scored if r["cached"]]
        uncached_results = [r for r in scored if not r["cached"]]

        if not cached_results:
            log.warning(f"⚠️  No cached results for '{title}' — best seeded will be slow to start")

        final = (cached_results + uncached_results)[:5]
        _search_cache[cache_key] = (time.time(), final)
        return final

    async def unlock_magnet(self, magnet: str) -> Optional[str]:
        """Add magnet for real (not just cache check), wait for ready, return stream URL."""
        try:
            resp = await self._client.get(
                f"{ALLDEBRID_API}/magnet/upload",
                params={"agent": AGENT, "apikey": self.api_key, "magnets[]": magnet},
            )
            data = resp.json()
            if data.get("status") != "success":
                log.error(f"Magnet upload failed: {data}")
                return None

            magnet_id = data["data"]["magnets"][0]["id"]

            for attempt in range(15):
                sr = await self._client.get(
                    f"{ALLDEBRID_API}/magnet/status",
                    params={"agent": AGENT, "apikey": self.api_key, "id": magnet_id},
                )
                info = sr.json().get("data", {}).get("magnets", {})
                status = info.get("status", "")
                log.debug(f"Magnet {magnet_id}: {status}")
                if status == "Ready":
                    break
                if status in ("Error", "Fail", "Deleted"):
                    log.error(f"Magnet failed: {status}")
                    return None
                await asyncio.sleep(2 if attempt < 5 else 5)
            else:
                log.error("Magnet timed out")
                return None

            lr = await self._client.get(
                f"{ALLDEBRID_API}/magnet/files",
                params={"agent": AGENT, "apikey": self.api_key, "id[]": magnet_id},
            )
            files = lr.json().get("data", {}).get("magnets", [{}])[0].get("files", [])
            if not files:
                log.error("No files in magnet")
                return None

            video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
            flat = self._flatten_files(files)
            videos = [f for f in flat if any(f["n"].lower().endswith(e) for e in video_exts)]
            best = max(videos or flat, key=lambda f: f.get("s", 0))
            link = best.get("l", "")
            if not link:
                return None
            return await self.unlock_link(link)

        except Exception as e:
            log.error(f"unlock_magnet failed: {e}", exc_info=True)
            return None

    async def unlock_link(self, link: str) -> Optional[str]:
        try:
            resp = await self._client.get(
                f"{ALLDEBRID_API}/link/unlock",
                params={"agent": AGENT, "apikey": self.api_key, "link": link},
            )
            data = resp.json()
            if data.get("status") != "success":
                log.error(f"Link unlock failed: {data}")
                return None
            return data["data"]["link"]
        except Exception as e:
            log.error(f"unlock_link failed: {e}", exc_info=True)
            return None

    def _detect_quality(self, name: str) -> str:
        n = name.lower()
        for q in ["2160p", "4k", "uhd", "1080p", "720p", "480p"]:
            if q in n:
                return q
        return "unknown"

    def _flatten_files(self, files, depth=0) -> list[dict]:
        result = []
        for f in files:
            if "e" in f:
                result.extend(self._flatten_files(f["e"], depth + 1))
            else:
                result.append(f)
        return result
