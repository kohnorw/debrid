"""
AllDebrid client — search, cache check, unlock.

Search logic ported from kohnorw/debrid alldebrid-web/app.py.
"""

import asyncio
import logging
import re
import time
import urllib.parse
from typing import Optional

import httpx

log = logging.getLogger("debridarr.alldebrid")

ALLDEBRID_API    = "https://api.alldebrid.com/v4"
ALLDEBRID_UPLOAD = f"{ALLDEBRID_API}/magnet/upload"
ALLDEBRID_DELETE = f"{ALLDEBRID_API}/magnet/delete"
ALLDEBRID_STATUS = f"{ALLDEBRID_API}/magnet/status"
ALLDEBRID_FILES  = f"{ALLDEBRID_API}/magnet/files"
ALLDEBRID_UNLOCK = f"{ALLDEBRID_API}/link/unlock"
AGENT = "debridarr"

APIBAY_URLS = [
    "https://apibay.org/q.php",
    "https://apibay.nocensor.space/q.php",
    "https://thepiratebay.org/q.php",
]

QUALITY_RE = re.compile(
    r'\b(2160p?|1080p?|720p?|480p?|4k|uhd|hdr|web-?dl|webrip|bluray|hevc|x265|x264|remux|proper|repack)\b',
    re.IGNORECASE,
)

_search_cache: dict[str, tuple[float, list]] = {}
_CACHE_TTL = 3600


# ── Helpers (ported from kohnorw/debrid) ──────────────────────────────────────

def _sanitize(q: str) -> str:
    q = re.sub(r"[''`´]", "", q)
    q = re.sub(r"[^\w\s\-]", " ", q)
    return re.sub(r"\s+", " ", q).strip()

def _parse_query(raw: str):
    quality = QUALITY_RE.findall(raw)
    s = QUALITY_RE.sub("", raw).strip()
    m = re.search(r'\bseason\s+(\d+)\b', s, re.IGNORECASE)
    if m:
        n = int(m.group(1))
        s = re.sub(r'\bseason\s+\d+\b', f"S{n:02d}", s, flags=re.IGNORECASE)
    season = episode = None
    m = re.search(r'(?<![a-zA-Z])S(\d{1,2})(?:E(\d{1,2}))?(?![a-zA-Z0-9])', s, re.IGNORECASE)
    if m:
        season = int(m.group(1))
        if m.group(2):
            episode = int(m.group(2))
    return " ".join(s.split()).strip(), season, episode, quality

def _strip_season(q: str) -> str:
    t = re.sub(r'(?<![a-zA-Z])S\d{1,2}(?:E\d{1,2})?(?![a-zA-Z0-9])', "", q, flags=re.IGNORECASE)
    return " ".join(t.split())

def _filter_by_season(torrents, season, episode):
    if season is None:
        return torrents
    s_str = f"S{season:02d}"
    s_alt = f"SEASON {season}"
    out = []
    for t in torrents:
        nu = t.get("name", "").upper()
        if s_str not in nu and s_alt not in nu:
            continue
        others = re.findall(r'S(\d{2})E\d{2}', nu)
        if others and not all(int(s) == season for s in others):
            continue
        has_ep_tags = bool(re.search(r'E\d{2}', nu))
        if episode is not None and has_ep_tags and f"E{episode:02d}" not in nu:
            continue
        out.append(t)
    return out

def _filter_by_quality(torrents, quality):
    if not quality:
        return torrents
    out = [t for t in torrents if any(q.upper().rstrip("P") in t.get("name","").upper() for q in quality)]
    return out if out else torrents

def _make_magnet(info_hash: str, name: str = "") -> str:
    return f"magnet:?xt=urn:btih:{info_hash.lower()}&dn={urllib.parse.quote(name, safe='')}"

def _detect_quality(name: str) -> str:
    n = name.lower()
    for q in ["2160p", "4k", "uhd", "1080p", "720p", "480p"]:
        if q in n:
            return q
    return "unknown"


# ── TPB fetch ──────────────────────────────────────────────────────────────────

async def _fetch(client, query: str, limit: int = 40) -> list:
    queries = [query]
    san = _sanitize(query)
    if san.lower() != query.lower():
        queries.append(san)
    for q in queries:
        for url in APIBAY_URLS:
            try:
                r = await client.get(url, params={"q": q, "cat": 0}, timeout=10)
                if r.status_code != 200:
                    continue
                data = r.json()
                if not data or (isinstance(data, list) and data[0].get("id") == "0"):
                    continue
                valid = [x for x in data if isinstance(x, dict) and x.get("info_hash")
                         and re.fullmatch(r'[0-9a-fA-F]{40}', x["info_hash"])]
                if valid:
                    return valid[:limit]
            except Exception as e:
                log.debug(f"TPB {url} failed: {e}")
    return []


# ── AllDebrid cache check (upload → read ready → delete) ──────────────────────

async def _check_cache(client, api_key: str, torrents: list) -> dict:
    """Upload all magnets, read ready flag, delete immediately. Nothing stays in account."""
    if not torrents or not api_key:
        return {}
    pairs = [("magnets[]", _make_magnet(t["info_hash"], t.get("name",""))) for t in torrents]
    try:
        r = await client.post(
            ALLDEBRID_UPLOAD,
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/x-www-form-urlencoded"},
            content=urllib.parse.urlencode(pairs),
            timeout=15,
        )
        result = r.json()
    except Exception as e:
        log.error(f"Cache check upload failed: {e}")
        return {}

    if result.get("status") == "error":
        log.warning(f"AllDebrid error: {result}")
        return {}

    ready_map = {}
    ids_to_delete = []
    for m in result.get("data", {}).get("magnets", []):
        if m.get("error"):
            continue
        h = (m.get("hash") or "").lower()
        if h:
            ready_map[h] = bool(m.get("ready", False))
        if m.get("id"):
            ids_to_delete.append(m["id"])

    # Batch delete — one request
    if ids_to_delete:
        try:
            await client.post(
                ALLDEBRID_DELETE,
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/x-www-form-urlencoded"},
                content=urllib.parse.urlencode([("id[]", str(mid)) for mid in ids_to_delete]),
                timeout=10,
            )
        except Exception:
            pass

    cached = sum(1 for v in ready_map.values() if v)
    log.info(f"Cache check: {cached}/{len(ready_map)} cached")
    return ready_map


# ── Search ─────────────────────────────────────────────────────────────────────

async def _do_search(client, api_key, query, season=None, episode=None, quality=None, limit=40):
    torrents = await _fetch(client, query, limit)
    if not torrents and season is not None:
        fallback = _strip_season(query)
        if fallback and fallback.lower() != query.lower():
            log.info(f"🔎 Fallback: {fallback!r}")
            torrents = await _fetch(client, fallback, limit * 2)
    if not torrents:
        return []

    filtered = _filter_by_season(torrents, season, episode)
    if not filtered and season is not None:
        filtered = torrents
    if quality:
        filtered = _filter_by_quality(filtered, quality)

    ready_map = await _check_cache(client, api_key, filtered)

    results = []
    for t in filtered:
        h = t["info_hash"].lower()
        results.append({
            "info_hash": h,
            "name":      t.get("name", ""),
            "size":      int(t.get("size", 0) or 0),
            "seeders":   int(t.get("seeders", 0) or 0),
            "magnet":    _make_magnet(h, t.get("name", "")),
            "quality":   _detect_quality(t.get("name", "")),
            "cached":    ready_map.get(h, False),
        })

    results.sort(key=lambda x: (not x["cached"], -x["seeders"]))
    return results


# ── Main client ────────────────────────────────────────────────────────────────

class AllDebridClient:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self._client = httpx.AsyncClient(timeout=20, follow_redirects=True)

    async def search_cached(self, title, media_type="movie", year=None, season=None, episode=None, imdb_id=None):
        cache_key = f"{title}::{media_type}::s{season}e{episode}"
        if cache_key in _search_cache:
            ts, r = _search_cache[cache_key]
            if time.time() - ts < _CACHE_TTL:
                return r

        if media_type == "episode" and season and episode:
            query = f"{title} S{season:02d}E{episode:02d}"
        elif media_type == "episode" and season:
            query = f"{title} S{season:02d}"
        else:
            query = f"{title} {year or ''}".strip()

        parsed_q, parsed_s, parsed_ep, quality = _parse_query(query)
        log.info(f"🔎 Query: {parsed_q!r}  s={parsed_s} ep={parsed_ep}")

        results = await _do_search(self._client, self.api_key, parsed_q, parsed_s, parsed_ep, quality)

        if results:
            cached_count = sum(1 for r in results if r["cached"])
            log.info(f"✅ {len(results)} results, {cached_count} cached for '{title}'")
        else:
            log.warning(f"❌ No results for '{title}'")

        _search_cache[cache_key] = (time.time(), results[:5])
        return results[:5]

    async def _get_existing_magnet_id(self, info_hash: str) -> Optional[int]:
        """Check if this magnet is already in the user's AllDebrid account."""
        try:
            r = await self._client.get(
                f"{ALLDEBRID_API}/magnet/status",
                params={"agent": AGENT, "apikey": self.api_key},
            )
            data = r.json()
            if data.get("status") != "success":
                return None
            magnets = data.get("data", {}).get("magnets", [])
            target = info_hash.lower()
            for m in magnets:
                if (m.get("hash") or "").lower() == target and m.get("status") == "Ready":
                    log.info(f"Found existing magnet in account: id={m['id']} name={m.get('filename','')[:40]}")
                    return m["id"]
        except Exception as e:
            log.debug(f"Existing magnet check failed: {e}")
        return None

    async def add_and_unlock(self, magnet: str) -> Optional[tuple[str, str]]:
        """
        Add a cached magnet to AllDebrid, get the stream URL.
        Returns (stream_url, filename) or None.

        Flow:
          1. Check if already in account → skip upload if so
          2. Upload magnet — instant for cached content
          3. Poll status until Ready
          4. Get file list, pick largest video file
          5. Unlock link → direct CDN URL
          6. Delete magnet from account (CDN URL is independent)
        """
        # Extract info_hash from magnet for account check
        hash_match = re.search(r'btih:([0-9a-fA-F]{40})', magnet, re.IGNORECASE)
        info_hash = hash_match.group(1) if hash_match else ""

        try:
            magnet_id = None

            # Step 1: Check if already in account
            if info_hash:
                magnet_id = await self._get_existing_magnet_id(info_hash)
                if magnet_id:
                    log.info(f"♻️  Reusing existing magnet {magnet_id} from account")

            if not magnet_id:
                # Step 2: Upload
                r = await self._client.get(
                    f"{ALLDEBRID_API}/magnet/upload",
                    params={"agent": AGENT, "apikey": self.api_key, "magnets[]": magnet},
                )
                data = r.json()
                if data.get("status") != "success":
                    log.error(f"Upload failed: {data}")
                    return None

                magnet_info = data["data"]["magnets"][0]
                magnet_id = magnet_info["id"]
                log.info(f"Magnet uploaded id={magnet_id} ready={magnet_info.get('ready')}")

                # If already ready (cached), skip polling
                if not magnet_info.get("ready"):
                    # Step 3: Poll until Ready — cached content is usually ready in 1-3s
                    for attempt in range(20):
                        await asyncio.sleep(2)
                        sr = await self._client.get(
                            ALLDEBRID_STATUS,
                            params={"agent": AGENT, "apikey": self.api_key, "id": magnet_id},
                        )
                        info = sr.json().get("data", {}).get("magnets", {})
                        status = info.get("status", "")
                        log.info(f"Magnet {magnet_id}: status={status!r}")
                        if status == "Ready":
                            break
                        if status in ("Error", "Fail", "Deleted", "Banned", "Virus", "OverQuota"):
                            log.error(f"Magnet failed: {status}")
                            return None
                    else:
                        log.error(f"Magnet {magnet_id} timed out")
                        return None

            # Step 3: Get files
            fr = await self._client.get(
                ALLDEBRID_FILES,
                params={"agent": AGENT, "apikey": self.api_key, "id[]": magnet_id},
            )
            files = fr.json().get("data", {}).get("magnets", [{}])[0].get("files", [])
            if not files:
                log.error("No files returned")
                return None

            # Pick largest video file
            video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
            flat = self._flatten(files)
            videos = [f for f in flat if any(f["n"].lower().endswith(e) for e in video_exts)]
            best = max(videos or flat, key=lambda f: f.get("s", 0))
            link = best.get("l", "")
            filename = best.get("n", "")

            if not link:
                log.error("No link in file list")
                return None

            # Step 4: Unlock → direct CDN URL
            ur = await self._client.get(
                ALLDEBRID_UNLOCK,
                params={"agent": AGENT, "apikey": self.api_key, "link": link},
            )
            ud = ur.json()
            if ud.get("status") != "success":
                log.error(f"Unlock failed: {ud}")
                return None

            stream_url = ud["data"]["link"]
            log.info(f"✅ Unlocked: {filename} → {stream_url[:60]}...")

            # Keep the magnet in the AllDebrid account — needed to re-unlock
            # the CDN URL when it expires. The FUSE mount will call
            # unlock_link again using the stored magnet link.
            log.info(f"📌 Keeping magnet {magnet_id} in account for re-unlock on expiry")

            return stream_url, filename

        except Exception as e:
            log.error(f"add_and_unlock failed: {e}", exc_info=True)
            return None

    def _flatten(self, files, depth=0):
        result = []
        for f in files:
            if "e" in f:
                result.extend(self._flatten(f["e"], depth + 1))
            else:
                result.append(f)
        return result
