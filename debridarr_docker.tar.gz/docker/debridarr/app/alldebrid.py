"""
AllDebrid client.

Search flow (no side effects on your account):
  1. Search TPB for torrent hashes matching the title
  2. Upload all hashes to /magnet/upload — AllDebrid instantly returns ready=true/false
     for each hash without actually downloading anything
  3. Read the ready flags, then DELETE every ID returned by that upload immediately
     The upload response always contains the IDs we just created, so no pre-snapshot needed
  4. Return only the cached (ready=true) results to the caller
  5. When resolve_and_cache picks the best result, upload it once more via add_magnet,
     get the file links, then DELETE that magnet too

Nothing persists in the AllDebrid account from searching.
"""

import asyncio
import logging
import re
import time
from pathlib import Path
import urllib.parse
from typing import Optional

import httpx

log = logging.getLogger("debridarr.alldebrid")

AD_BASE   = "https://api.alldebrid.com/v4"
AD_UPLOAD = f"{AD_BASE}/magnet/upload"
AD_DELETE = f"{AD_BASE}/magnet/delete"
AD_STATUS = "https://api.alldebrid.com/v4.1/magnet/status"
AD_FILES  = f"{AD_BASE}/magnet/files"
AD_UNLOCK = f"{AD_BASE}/link/unlock"
AGENT     = "debridarr"

APIBAY_URLS = [
    "https://apibay.org/q.php",
    "https://apibay.nocensor.space/q.php",
    "https://thepiratebay.org/q.php",
]

QUALITY_RE = re.compile(
    r'\b(2160p?|1080p?|720p?|480p?|4k|uhd|hdr|hdr10|dv|web-?dl|webrip|bluray|blu-ray'
    r'|hevc|x265|x264|h264|h265|remux|proper|repack)\b',
    re.IGNORECASE,
)

_search_cache: dict[str, tuple[float, list]] = {}
_CACHE_TTL = 3600


# ── Helpers ───────────────────────────────────────────────────────────────────

def _sanitize(query: str) -> str:
    q = re.sub(r"[''`´]", "", query)
    q = re.sub(r"[^\w\s\-]", " ", q)
    return re.sub(r"\s+", " ", q).strip()


def parse_query(raw: str):
    """Returns (clean_title, season, episode, quality_tokens)"""
    quality = QUALITY_RE.findall(raw)
    search_raw = QUALITY_RE.sub("", raw).strip()
    m = re.search(r'\bseason\s+(\d+)\b', search_raw, re.IGNORECASE)
    if m:
        season_num = int(m.group(1))
        search_raw = re.sub(r'\bseason\s+\d+\b', f"S{season_num:02d}", search_raw, flags=re.IGNORECASE)
    season = episode = None
    m = re.search(r'(?<![a-zA-Z])S(\d{1,2})(?:E(\d{1,2}))?(?![a-zA-Z0-9])', search_raw, re.IGNORECASE)
    if m:
        season = int(m.group(1))
        if m.group(2):
            episode = int(m.group(2))
    return " ".join(search_raw.split()).strip(), season, episode, quality


def strip_season(query: str) -> str:
    t = re.sub(r'(?<![a-zA-Z])S\d{1,2}(?:E\d{1,2})?(?![a-zA-Z0-9])', "", query, flags=re.IGNORECASE)
    return " ".join(t.split())


def filter_by_season(torrents: list, season, episode) -> list:
    if season is None:
        return torrents
    s_str = f"S{season:02d}"
    s_alt = f"SEASON {season}"
    out = []
    for t in torrents:
        nu = t.get("name", "").upper()
        if s_str not in nu and s_alt not in nu:
            continue
        others = re.findall(r'S(\d{2})E\d{2}', nu)
        if others and not all(int(s) == season for s in others):
            continue
        has_ep_tags = bool(re.search(r'E\d{2}', nu))
        if episode is not None and has_ep_tags and f"E{episode:02d}" not in nu:
            continue
        out.append(t)
    return out


def filter_by_quality(torrents: list, quality: list) -> list:
    if not quality:
        return torrents
    out = []
    for t in torrents:
        name_up = t.get("name", "").upper()
        for q in quality:
            if q.upper().rstrip("P") in name_up:
                out.append(t)
                break
    return out if out else torrents


def _make_magnet(torrent: dict) -> str:
    h    = torrent["info_hash"].lower()
    name = urllib.parse.quote(torrent.get("name", ""), safe="")
    return f"magnet:?xt=urn:btih:{h}&dn={name}"


# ── TPB fetch ─────────────────────────────────────────────────────────────────

async def _fetch(client: httpx.AsyncClient, query: str, limit: int = 40) -> list:
    queries = [query]
    san = _sanitize(query)
    if san.lower() != query.lower():
        queries.append(san)
    for q in queries:
        for url in APIBAY_URLS:
            try:
                r = await client.get(url, params={"q": q, "cat": 0}, timeout=10)
                if r.status_code != 200:
                    continue
                data = r.json()
                if not data or (isinstance(data, list) and data[0].get("id") == "0"):
                    continue
                valid = [
                    x for x in data
                    if isinstance(x, dict)
                    and x.get("info_hash")
                    and re.fullmatch(r'[0-9a-fA-F]{40}', x["info_hash"])
                ]
                if valid:
                    return valid[:limit]
            except Exception as e:
                log.debug(f"TPB {url} failed: {e}")
    return []


# ── AllDebrid API helpers ─────────────────────────────────────────────────────

def _auth_headers(api_key: str) -> dict:
    return {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/x-www-form-urlencoded",
    }


async def _ad_post(
    client: httpx.AsyncClient,
    api_key: str,
    endpoint: str,
    params: "dict | list",
    timeout: int = 15,
) -> dict:
    """POST to AllDebrid with Bearer auth."""
    body = urllib.parse.urlencode(params) if isinstance(params, dict) else urllib.parse.urlencode(params)
    try:
        r = await client.post(
            endpoint,
            headers=_auth_headers(api_key),
            content=body,
            timeout=timeout,
        )
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.error(f"AllDebrid POST {endpoint} failed: {e}")
        return {}


async def _delete_one(client: httpx.AsyncClient, api_key: str, magnet_id: str):
    """Delete a single magnet from AllDebrid. Best-effort."""
    try:
        await _ad_post(client, api_key, AD_DELETE, {"id": magnet_id}, timeout=10)
        log.debug(f"Deleted magnet id={magnet_id}")
    except Exception as e:
        log.debug(f"Delete magnet {magnet_id} failed (non-critical): {e}")


async def _delete_many(client: httpx.AsyncClient, api_key: str, ids: list):
    """Delete a list of magnets from AllDebrid."""
    for mid in ids:
        await _delete_one(client, api_key, str(mid))


# ── Cache check — the core of the search, no account side-effects ─────────────

async def check_cache(client: httpx.AsyncClient, api_key: str, torrents: list) -> dict:
    """
    Check which hashes are cached on AllDebrid WITHOUT leaving anything in the account.

    How it works:
      - POST all magnet hashes to /magnet/upload in one request
      - AllDebrid responds instantly with ready=true/false for each hash
        (ready=true means the file is already on AllDebrid's servers)
      - The upload response always contains the IDs that were just created by THIS call
      - DELETE every one of those IDs immediately — nothing persists

    Returns {hash_lower: bool} — True means cached and streamable.
    """
    if not torrents:
        return {}

    magnets = [_make_magnet(t) for t in torrents]
    pairs   = [("magnets[]", m) for m in magnets]

    upload_result = await _ad_post(client, api_key, AD_UPLOAD, pairs)

    if not upload_result or upload_result.get("status") != "success":
        log.debug(f"check_cache upload error: {upload_result.get('error', {})}")
        return {}

    ready_map:    dict[str, bool] = {}
    ids_to_delete: list[str]      = []

    for m in upload_result.get("data", {}).get("magnets", []):
        # Error entries (e.g. MAGNET_INVALID_URI) have no id and no hash — skip
        if m.get("error"):
            continue

        h = (m.get("hash") or "").lower()
        if h:
            ready_map[h] = bool(m.get("ready", False))

        # Always collect every ID returned by this upload call — they are ours to delete.
        # The upload response only contains IDs created in this request.
        if m.get("id"):
            ids_to_delete.append(str(m["id"]))

    # Delete all probe IDs — no try/except here so failures are visible in logs
    await _delete_many(client, api_key, ids_to_delete)

    cached_count = sum(1 for v in ready_map.values() if v)
    log.debug(
        f"check_cache: {cached_count}/{len(ready_map)} cached, "
        f"{len(ids_to_delete)} probe IDs deleted"
    )
    return ready_map


# ── Title matching ────────────────────────────────────────────────────────────

def _title_matches(torrent_name: str, expected_title: str) -> bool:
    def normalize(s: str) -> list[str]:
        s = s.lower()
        s = s.replace("'", "").replace("'", "").replace("`", "")
        s = re.sub(r"[._]", " ", s)
        s = re.sub(r"[^\w\s]", " ", s)
        return [w for w in s.split() if w]

    title_portion = re.split(
        r'(?<!\w)(?:s\d{1,2}e\d{1,2}|s\d{2}(?!\w)|\b\d{4}\b|1080p|720p|480p|'
        r'2160p|4k|uhd|bluray|webrip|hdtv|x264|x265|h264|h265|complete\b|'
        r'season\b|episode\b)',
        torrent_name.lower(),
        maxsplit=1,
        flags=re.IGNORECASE,
    )[0]

    torrent_words = normalize(title_portion)
    title_words   = normalize(expected_title)

    if not title_words or not torrent_words:
        return True

    def strip_articles(words):
        while words and words[0] in ("the", "a", "an"):
            words = words[1:]
        return words

    tw = strip_articles(title_words)
    rw = strip_articles(torrent_words)

    if not tw:
        return True
    if len(rw) < len(tw):
        return False
    if rw[:len(tw)] != tw:
        return False

    extra = len(rw) - len(tw)
    ok_suffixes = {"us", "uk", "au", "ca", "nz", "hd", "repack", "proper"}

    if extra == 0:
        return True
    elif extra <= 2:
        if len(tw) <= 2:
            return all(w in ok_suffixes for w in rw[len(tw):])
        return True
    else:
        return False


# ── do_search ─────────────────────────────────────────────────────────────────

async def do_search(
    client: httpx.AsyncClient,
    api_key: str,
    query: str,
    season=None,
    episode=None,
    quality=None,
    limit: int = 40,
    title: str = "",
) -> list:
    """
    Search TPB, check AllDebrid cache status, return results with cached flag set.
    All probe magnets are deleted inside check_cache before this returns.
    """
    torrents = await _fetch(client, query, limit)
    if not torrents and season is not None:
        fallback = strip_season(query)
        if fallback and fallback.lower() != query.lower():
            log.debug(f"Fallback search: {fallback!r}")
            torrents = await _fetch(client, fallback, limit * 2)
    if not torrents:
        return []

    if title:
        before   = len(torrents)
        torrents = [t for t in torrents if _title_matches(t.get("name", ""), title)]
        if len(torrents) < before:
            log.debug(f"Title filter: {before} → {len(torrents)} for {title!r}")
        if not torrents:
            log.warning(f"Title filter removed all results for {title!r} — retrying unfiltered")
            torrents = await _fetch(client, query, limit)

    filtered = filter_by_season(torrents, season, episode)
    if not filtered and season is not None:
        filtered = torrents
    if quality:
        filtered = filter_by_quality(filtered, quality)

    ready_map = await check_cache(client, api_key, filtered) if api_key else {}

    results = []
    for t in filtered:
        h = t["info_hash"].lower()
        results.append({
            "hash":    h,
            "name":    t.get("name", "Unknown"),
            "size":    int(t.get("size", 0) or 0),
            "seeders": int(t.get("seeders", 0) or 0),
            "magnet":  _make_magnet(t),
            "quality": _detect_quality(t.get("name", "")),
            "cached":  ready_map.get(h, False),
        })

    results.sort(key=lambda x: (not x["cached"], -x["seeders"]))
    return results


def _detect_quality(name: str) -> str:
    n = name.lower()
    for q in ["2160p", "4k", "uhd", "1080p", "720p", "480p"]:
        if q in n:
            return q
    return "unknown"


# ── Main client ───────────────────────────────────────────────────────────────

class AllDebridClient:
    def __init__(self, api_key: str):
        self.api_key  = api_key
        self._client  = httpx.AsyncClient(timeout=30, follow_redirects=True)

    async def search_cached(
        self,
        title: str,
        media_type: str = "movie",
        year=None,
        season=None,
        episode=None,
        imdb_id=None,
        strategy: str = "episode",
        preferred_quality: str = "1080p",
        fallback_any: bool = True,
    ) -> list:
        """
        Return only AllDebrid-cached results. Uncached torrents are filtered out entirely —
        they would require a full download before streaming is possible.
        All probe magnets are cleaned up before this returns.
        """
        ck = f"{title}::{media_type}::s{season}e{episode}::{strategy}"
        if ck in _search_cache:
            ts, r = _search_cache[ck]
            if time.time() - ts < _CACHE_TTL:
                return r

        def cached_only(results: list) -> list:
            return [r for r in results if r.get("cached")]

        def quality_filter(results: list, quality: str) -> list:
            if quality == "any":
                return results
            matched = [r for r in results if quality.lower() in r.get("name", "").lower()]
            return matched if matched else (results if fallback_any else [])

        results = []

        if media_type in ("episode", "tv"):
            if strategy == "series_pack":
                q, *_, qual = parse_query(f"{title} {year or ''}".strip())
                all_r  = await do_search(self._client, self.api_key, q, None, None, qual, title=title)
                packs  = [r for r in cached_only(all_r) if not re.search(r"S\d{2}E\d{2}", r["name"], re.I)]
                results = quality_filter(packs, preferred_quality)
                if results:
                    log.info(f"✅ Series pack (cached) for {title!r}: {results[0]['name']}")

            if not results and strategy in ("season_pack", "series_pack") and season:
                q, *_, qual = parse_query(f"{title} S{season:02d}")
                all_r  = await do_search(self._client, self.api_key, q, season, None, qual, title=title)
                packs  = [r for r in cached_only(all_r) if not re.search(r"S\d{2}E\d{2}", r["name"], re.I)]
                results = quality_filter(packs, preferred_quality)
                if results:
                    log.info(f"✅ Season pack (cached) for {title!r} S{season:02d}: {results[0]['name']}")

            if not results and season and episode:
                q, ps, pe, qual = parse_query(f"{title} S{season:02d}E{episode:02d}")
                all_r   = await do_search(self._client, self.api_key, q, ps, pe, qual, title=title)
                results = quality_filter(cached_only(all_r), preferred_quality)
                if results:
                    log.info(f"✅ Episode (cached) for {title!r} S{season:02d}E{episode:02d}")

        else:
            for query_str in [f"{title} {year}".strip() if year else title, title]:
                q, ps, pe, qual = parse_query(query_str)
                all_r  = await do_search(self._client, self.api_key, q, ps, pe, qual, title=title)
                cached = cached_only(all_r)
                results = quality_filter(cached, preferred_quality)
                if results:
                    break
                if preferred_quality != "any" and fallback_any:
                    results = quality_filter(cached, "any")
                    if results:
                        break

        if not results:
            log.warning(f"No cached results for {title!r} (strategy={strategy})")
        else:
            log.info(f"{len(results)} cached results for {title!r}")

        top = results[:5]
        if top:
            _search_cache[ck] = (time.time(), top)
        return top

    async def add_magnet(self, magnet: str) -> Optional[tuple[str, list]]:
        """
        Upload the chosen cached magnet, get its file links, then DELETE it.

        File links from /magnet/files are permanent CDN URLs — the magnet slot
        is not needed once we have them. The magnet is deleted whether the call
        succeeds, fails, or raises an exception.
        """
        magnet_id = None
        try:
            # 1. Upload
            result = await _ad_post(
                self._client, self.api_key, AD_UPLOAD,
                [("magnets[]", magnet)],
            )
            if not result or result.get("status") != "success":
                log.error(f"Magnet upload failed: {result.get('error', {})}")
                return None

            magnets = result.get("data", {}).get("magnets", [])
            if not magnets or magnets[0].get("error"):
                log.error(f"Magnet upload error: {magnets[0].get('error') if magnets else 'empty'}")
                return None

            m         = magnets[0]
            magnet_id = str(m["id"])
            log.debug(f"Magnet uploaded id={magnet_id} ready={m.get('ready')}")

            # 2. Poll until ready (cached magnets are usually instant)
            if not m.get("ready"):
                for _ in range(15):
                    await asyncio.sleep(2)
                    sr          = await _ad_post(self._client, self.api_key, AD_STATUS, {"id": magnet_id})
                    magnets_raw = sr.get("data", {}).get("magnets", {})

                    if isinstance(magnets_raw, list):
                        info = next((x for x in magnets_raw if str(x.get("id")) == magnet_id), {})
                    elif isinstance(magnets_raw, dict):
                        info = magnets_raw.get(magnet_id) or magnets_raw.get(str(magnet_id)) or {}
                    else:
                        info = {}

                    sc     = info.get("statusCode", -1)
                    status = info.get("status", "")
                    log.debug(f"Magnet {magnet_id}: {status!r} (code={sc})")

                    if sc == 4 or status == "Ready":
                        break
                    if sc in range(5, 16):   # all error codes 5-15
                        log.error(f"Magnet {magnet_id} failed: statusCode={sc}")
                        return None         # finally block deletes it
                else:
                    log.error(f"Magnet {magnet_id} timed out")
                    return None             # finally block deletes it

            # 3. Get file list
            fr          = await _ad_post(self._client, self.api_key, AD_FILES, [("id[]", magnet_id)])
            mfiles      = fr.get("data", {}).get("magnets", [])
            if isinstance(mfiles, dict):
                mfiles = list(mfiles.values())

            files_raw = mfiles[0].get("files", []) if mfiles else []
            files     = self._flatten_files(files_raw)

            video_exts   = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
            videos       = [f for f in files if any(f.get("n", "").lower().endswith(e) for e in video_exts)]
            target_files = videos if videos else files

            log.debug(f"Magnet {magnet_id}: {len(target_files)} video files found")
            return magnet_id, target_files

        except Exception as e:
            log.error(f"add_magnet failed: {e}", exc_info=True)
            return None

        finally:
            # Always delete — runs whether we return normally, return None, or raise
            if magnet_id:
                await _delete_one(self._client, self.api_key, magnet_id)
                log.debug(f"Magnet {magnet_id} deleted (finally block)")

    async def unlock_magnet(self, link: str) -> Optional[str]:
        """Unlock a file link to get a fresh CDN URL (used by the proxy for re-streaming)."""
        try:
            result = await _ad_post(self._client, self.api_key, AD_UNLOCK, {"link": link})
            if not result or result.get("status") != "success":
                log.error(f"Unlock failed: {result.get('error', {})}")
                return None
            return result["data"]["link"]
        except Exception as e:
            log.error(f"unlock_magnet failed: {e}", exc_info=True)
            return None

    async def unlock_file(self, link: str) -> Optional[str]:
        """Alias for fuse_mount.py compatibility."""
        return await self.unlock_magnet(link)

    async def delete_magnet(self, magnet_id: str):
        """Delete a magnet by ID (used by cache expiry and hard-expire flows)."""
        await _delete_one(self._client, self.api_key, magnet_id)

    def _flatten_files(self, files, depth=0) -> list:
        result = []
        for f in files:
            if "e" in f:
                result.extend(self._flatten_files(f["e"], depth + 1))
            else:
                result.append(f)
        return result

    async def get_all_torrents(self) -> list[dict]:
        """Fetch all ready torrents from AllDebrid for FUSE mount."""
        try:
            r           = await _ad_post(self._client, self.api_key, AD_STATUS, {"status": "ready"})
            magnets_raw = r.get("data", {}).get("magnets", {})
            magnets     = list(magnets_raw.values()) if isinstance(magnets_raw, dict) else (magnets_raw if isinstance(magnets_raw, list) else [])

            if not magnets:
                log.info("AllDebrid: no ready torrents")
                return []

            ids     = [str(m["id"]) for m in magnets if m.get("id")]
            id_name = {str(m["id"]): m.get("filename", f"torrent_{m['id']}") for m in magnets if m.get("id")}
            id_hash = {str(m["id"]): (m.get("hash") or "").lower() for m in magnets if m.get("id")}

            video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
            result     = []
            BATCH      = 50

            for i in range(0, len(ids), BATCH):
                batch = ids[i:i + BATCH]
                fr    = await _ad_post(self._client, self.api_key, AD_FILES, [("id[]", x) for x in batch])
                if not fr or fr.get("status") != "success":
                    log.debug(f"magnet/files batch error: {fr.get('error', {})}")
                    continue

                mfiles = fr.get("data", {}).get("magnets", [])
                if isinstance(mfiles, dict):
                    mfiles = list(mfiles.values())

                for mf in mfiles:
                    mid    = str(mf.get("id", ""))
                    name   = id_name.get(mid, f"torrent_{mid}")
                    flat   = self._flatten_files(mf.get("files", []))
                    videos = [f for f in flat if any(f.get("n", "").lower().endswith(e) for e in video_exts)]
                    if videos:
                        stem        = Path(videos[0]["n"]).stem
                        folder_name = stem if (stem and stem.startswith(name.rstrip("-"))) else name
                        result.append({"id": mid, "name": folder_name, "hash": id_hash.get(mid, ""), "files": videos})

            log.info(f"AllDebrid: {len(result)} torrents ready")
            return result

        except Exception as e:
            log.error(f"get_all_torrents failed: {e}", exc_info=True)
            return []
