"""
AllDebrid API client — corrected to match docs at docs.alldebrid.com

Auth:  Authorization: Bearer {apikey} header on every authenticated request.
       The 'agent' and 'apikey' query params were removed as of 15 Jan 2025.
HTTP:  All magnet/link endpoints use POST with application/x-www-form-urlencoded body.
       (As of 15 Jan 2025 POST is the documented default; GET is deprecated.)
URLs:
  POST /v4/magnet/upload     — upload magnet (cache-check or permanent)
  POST /v4.1/magnet/status   — poll status of a magnet by id
  POST /v4/magnet/files      — get file list for one or more magnet ids
  POST /v4/magnet/delete     — delete a magnet
  POST /v4/link/unlock       — unlock a file link to a direct CDN URL
"""

import asyncio
import logging
import re
import time
import urllib.parse
from pathlib import Path
from typing import Optional

import httpx

log = logging.getLogger("debridarr.alldebrid")

AD_UPLOAD = "https://api.alldebrid.com/v4/magnet/upload"
AD_STATUS = "https://api.alldebrid.com/v4.1/magnet/status"
AD_FILES  = "https://api.alldebrid.com/v4/magnet/files"
AD_DELETE = "https://api.alldebrid.com/v4/magnet/delete"
AD_UNLOCK = "https://api.alldebrid.com/v4/link/unlock"

QUALITY_RE = re.compile(
    r'\b(2160p?|1080p?|720p?|480p?|4k|uhd|hdr|hdr10|dv|web-?dl|webrip|bluray|blu-ray'
    r'|hevc|x265|x264|h264|h265|remux|proper|repack)\b',
    re.IGNORECASE,
)

_search_cache: dict[str, tuple[float, list]] = {}
_CACHE_TTL = 3600

_CAM_RE = re.compile(
    r'\b(cam|camrip|hdcam|ts|telesync|telecine|tc|scr|screener|r5|r6|dvdscr|workprint|wp)\b',
    re.IGNORECASE,
)
_LANG_RE = re.compile(
    r'\b(french|german|spanish|italian|portuguese|dutch|russian|chinese|korean|japanese'
    r'|hindi|arabic|polish|turkish|swedish|danish|norwegian|finnish|hungarian|czech'
    r'|romanian|greek|hebrew|thai|vietnamese|ukrainian|slovak|bulgarian)\b',
    re.IGNORECASE,
)

def _is_cam(name: str) -> bool:     return bool(_CAM_RE.search(name))
def _is_foreign(name: str) -> bool: return bool(_LANG_RE.search(name))


# ── Low-level helper ──────────────────────────────────────────────────────────

async def _api_post(client: httpx.AsyncClient, api_key: str,
                    url: str, pairs: list[tuple] | None = None) -> dict | None:
    """
    POST to an AllDebrid API endpoint.
    Auth:    Authorization: Bearer header (the only supported auth method).
    Body:    application/x-www-form-urlencoded.
    Retries: 3 attempts with exponential backoff on 429/502/503/504.
    Returns: parsed JSON dict, or None on failure.
    """
    body = urllib.parse.urlencode(pairs or [])
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type":  "application/x-www-form-urlencoded",
    }
    endpoint = url.split("/")[-1]
    for attempt in range(3):
        try:
            r = await client.post(url, headers=headers, content=body, timeout=15)
            if r.status_code in (429, 502, 503, 504):
                wait = 2 ** attempt
                log.warning(f"AllDebrid {endpoint} HTTP {r.status_code} — retry in {wait}s")
                await asyncio.sleep(wait)
                continue
            if r.status_code != 200:
                log.error(f"AllDebrid {endpoint} HTTP {r.status_code}: {r.text[:120]}")
                return None
            text = r.text.strip()
            if not text:
                log.error(f"AllDebrid {endpoint}: empty response")
                return None
            return r.json()
        except httpx.TimeoutException:
            log.warning(f"AllDebrid {endpoint} timeout (attempt {attempt+1})")
            if attempt < 2: await asyncio.sleep(2 ** attempt)
        except Exception as e:
            log.error(f"AllDebrid {endpoint} error: {e}")
            if attempt < 2: await asyncio.sleep(2 ** attempt)
    return None


# ── Cache-check helpers (upload batch → check ready → delete all) ─────────────

def _sanitize(query: str) -> str:
    q = re.sub(r"[''`´]", "", query)
    q = re.sub(r"[^\w\s\-]", " ", q)
    return re.sub(r"\s+", " ", q).strip()

def _make_magnet(t: dict) -> str:
    """Convert a TPB torrent dict to a magnet URI."""
    info_hash = t.get("info_hash", "")
    name      = urllib.parse.quote(t.get("name", info_hash), safe="")
    trackers  = "&".join([
        "tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce",
        "tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce",
        "tr=udp%3A%2F%2Ftracker.dler.org%3A6969%2Fannounce",
    ])
    return f"magnet:?xt=urn:btih:{info_hash}&dn={name}&{trackers}"


async def _upload_magnets(client: httpx.AsyncClient, api_key: str,
                           torrents: list) -> dict:
    """Upload a batch of magnets for cache-checking. Returns raw API response dict."""
    if not torrents:
        return {}
    pairs = [("magnets[]", _make_magnet(t)) for t in torrents]
    result = await _api_post(client, api_key, AD_UPLOAD, pairs)
    if not result:
        return {}
    if result.get("status") == "error":
        log.debug(f"Batch upload error: {result.get('error', {})}")
        return {}
    return result


async def _delete_magnets(client: httpx.AsyncClient, api_key: str, ids: list):
    """
    Delete a list of temp (cache-check) magnets one by one.
    Retries on transient errors; logs but never raises.
    """
    for mid in ids:
        for attempt in range(3):
            try:
                r = await client.post(
                    AD_DELETE,
                    headers={"Authorization": f"Bearer {api_key}",
                             "Content-Type": "application/x-www-form-urlencoded"},
                    content=urllib.parse.urlencode({"id": mid}),
                    timeout=10,
                )
                if r.status_code in (429, 502, 503, 504):
                    await asyncio.sleep(2 ** attempt)
                    continue
                if r.status_code != 200:
                    log.debug(f"Delete magnet {mid}: HTTP {r.status_code}")
                break
            except Exception as e:
                log.debug(f"Delete magnet {mid}: {e}")
                if attempt < 2: await asyncio.sleep(2 ** attempt)


async def check_cache(client: httpx.AsyncClient, api_key: str,
                       torrents: list) -> dict:
    """
    Upload all magnets, read their 'ready' flag, delete ALL of them (including errors).
    Returns {hash_lower: bool} mapping each hash to whether it's cached.
    """
    result = await _upload_magnets(client, api_key, torrents)
    if not result:
        return {}

    ready_map:      dict[str, bool] = {}
    ids_to_delete:  list            = []

    for m in result.get("data", {}).get("magnets", []):
        mid = m.get("id")
        if mid:
            ids_to_delete.append(mid)     # Collect ID BEFORE checking for errors
        if m.get("error"):
            continue                       # Don't record in ready_map, but WILL delete
        h = (m.get("hash") or "").lower()
        if h:
            ready_map[h] = bool(m.get("ready", False))

    await _delete_magnets(client, api_key, ids_to_delete)
    cached = sum(1 for v in ready_map.values() if v)
    log.debug(f"Cache check: {cached}/{len(ready_map)} cached, "
              f"deleted {len(ids_to_delete)} temp magnets")
    return ready_map


# ── TPB search ────────────────────────────────────────────────────────────────

APIBAY_URLS = [
    "https://apibay.org/q.php",
    "https://apibay.nocensor.space/q.php",
    "https://thepiratebay.org/q.php",
]

def parse_query(title: str, year: int | None, season: int | None,
                episode: int | None, strategy: str, media_type: str) -> str:
    title = _sanitize(title)
    if media_type == "movie":
        return f"{title} {year}" if year else title
    if strategy == "series_pack":
        return title
    if season:
        s = f"S{season:02d}"
        if strategy == "season_pack":
            return f"{title} {s}"
        if episode:
            return f"{title} {s}E{episode:02d}"
    return title


def strip_season(name: str) -> str:
    return re.sub(r"\s*S\d{2}E\d{2}.*", "", name, flags=re.I).strip()


def filter_by_season(results: list, season: int | None, episode: int | None,
                      strategy: str) -> list:
    if not season:
        return results
    se_str = f"S{season:02d}"
    ep_str = f"E{episode:02d}" if episode else ""

    out = []
    for r in results:
        name = r.get("name", "")
        name_up = name.upper()
        has_se  = se_str.upper() in name_up
        has_ep  = ep_str.upper() in name_up if ep_str else True

        if strategy == "series_pack":
            if re.search(r'S\d{2}', name, re.I):
                continue                     # Skip single-season packs
            out.append(r)
        elif strategy == "season_pack":
            if has_se and not re.search(r'E\d{2}', name, re.I):
                out.append(r)
        else:
            if has_se and has_ep:
                out.append(r)
    return out


def _detect_quality(name: str) -> str:
    m = QUALITY_RE.search(name)
    return m.group(0).lower() if m else ""


def filter_by_quality(results: list, preferred: str, fallback_any: bool) -> list:
    if not preferred or preferred == "any":
        return results
    preferred_l = preferred.lower()
    exact = [r for r in results if preferred_l in r.get("name", "").lower()]
    if exact:
        return exact
    if fallback_any:
        return results
    return []


async def _fetch(client: httpx.AsyncClient, query: str,
                  category: int = 0) -> list[dict]:
    """Fetch results from TPB API bay, trying mirrors until one succeeds."""
    for url in APIBAY_URLS:
        try:
            r = await client.get(url, params={"q": query, "cat": category}, timeout=12)
            if r.status_code != 200:
                continue
            data = r.json()
            if isinstance(data, list) and data:
                if not data[0].get("info_hash"):
                    continue
                return [d for d in data if d.get("info_hash") and d.get("info_hash") != "0" * 40]
        except Exception:
            continue
    return []


def _title_matches(torrent_name: str, expected_title: str) -> bool:
    def _norm(s): return re.sub(r"[^\w]", "", s.lower())
    tok  = re.split(r"[\s.\-_]+", _sanitize(expected_title).lower())
    name = _norm(torrent_name)
    return all(_norm(t) in name for t in tok if t)


async def do_search(client: httpx.AsyncClient, api_key: str,
                    query: str, season: int | None, episode: int | None,
                    preferred_quality: str, title: str = "",
                    strategy: str = "episode", fallback_any: bool = True) -> list[dict]:
    """
    Fetch from TPB, check AllDebrid cache, sort cached results first.
    Returns list of result dicts with 'cached', 'quality' fields added.
    """
    results = await _fetch(client, query)

    if title:
        results = [r for r in results if _title_matches(r.get("name", ""), title)]

    results = filter_by_season(results, season, episode, strategy)
    results = filter_by_quality(results, preferred_quality, fallback_any)

    if not results:
        return []

    ready_map = await check_cache(client, api_key, results)

    for r in results:
        h = (r.get("info_hash") or "").lower()
        r["cached"]  = ready_map.get(h, False)
        r["quality"] = _detect_quality(r.get("name", ""))

    results.sort(key=lambda r: (0 if r["cached"] else 1,
                                 0 if r.get("quality") else 1))
    return results


# ── AllDebrid class (persistent connection for add/unlock/FUSE) ───────────────

class AllDebrid:
    """
    Permanent AllDebrid client — manages magnets that stay in the account
    for FUSE reads (as opposed to temp cache-check magnets which are deleted).
    """

    def __init__(self, api_key: str):
        self.api_key = api_key
        self._client = httpx.AsyncClient(
            timeout=30,
            follow_redirects=True,
            limits=httpx.Limits(max_keepalive_connections=10, max_connections=20),
        )

    async def aclose(self):
        await self._client.aclose()

    def _auth_headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type":  "application/x-www-form-urlencoded",
        }

    async def _post(self, url: str, pairs: list[tuple] | None = None) -> dict | None:
        """Convenience POST with retry using this instance's api_key."""
        return await _api_post(self._client, self.api_key, url, pairs)

    # ── Search wrapper ────────────────────────────────────────────────────────

    async def search_cached(
        self,
        title: str,
        media_type: str,
        year: int | None        = None,
        season: int | None      = None,
        episode: int | None     = None,
        imdb_id: str | None     = None,
        strategy: str           = "episode",
        preferred_quality: str  = "1080p",
        fallback_any: bool      = True,
        english_only: bool      = False,
        no_cam: bool            = True,
    ) -> list[dict]:
        cache_key = f"{title}|{media_type}|{season}|{episode}|{strategy}|{english_only}|{no_cam}"
        if cache_key in _search_cache:
            ts, cached = _search_cache[cache_key]
            if time.time() - ts < _CACHE_TTL:
                return cached

        query = parse_query(title, year, season, episode, strategy, media_type)

        # Try to find episode via TMDB title lookup for non-standard show names
        if media_type in ("episode", "series") and season and episode:
            try:
                season_ep, ep_ep = await self._resolve_episode_via_tmdb(
                    title, season, episode, imdb_id
                )
                if season_ep and ep_ep:
                    season, episode = season_ep, ep_ep
                    query = parse_query(title, year, season, episode, strategy, media_type)
            except Exception:
                pass

        async with httpx.AsyncClient(timeout=20) as client:
            results = await do_search(
                client, self.api_key, query,
                season, episode, preferred_quality,
                title=title, strategy=strategy, fallback_any=fallback_any,
            )

        # Apply content filters
        if english_only:
            results = [r for r in results if not _is_foreign(r.get("name", ""))]
        if no_cam:
            results = [r for r in results if not _is_cam(r.get("name", ""))]

        top = results[:5]
        if top:
            _search_cache[cache_key] = (time.time(), top)
        return top

    # ── Add magnet permanently ────────────────────────────────────────────────

    async def add_magnet(self, magnet: str) -> Optional[tuple[str, list]]:
        """
        Add a magnet permanently to the AllDebrid account (FUSE reads require it).
        Returns (magnet_id, files) where files = [{n, l, s}, ...].
        Polls status until statusCode == 4 (Ready).
        """
        # 1. Upload
        result = await self._post(AD_UPLOAD, [("magnets[]", magnet)])
        if not result or result.get("status") != "success":
            log.error(f"add_magnet upload failed: {result}")
            return None

        magnets = result.get("data", {}).get("magnets", [])
        if not magnets:
            log.error("add_magnet: empty magnets list in response")
            return None

        m = magnets[0]
        if m.get("error"):
            log.error(f"add_magnet error: {m['error']}")
            return None

        magnet_id = str(m["id"])
        log.debug(f"Magnet uploaded: id={magnet_id} ready={m.get('ready')}")

        # 2. Poll status until Ready (statusCode == 4) or error
        if not m.get("ready"):
            for attempt in range(30):
                await asyncio.sleep(3)
                sr = await self._post(AD_STATUS, [("id", magnet_id)])
                if not sr or sr.get("status") != "success":
                    log.debug(f"Status poll {attempt}: bad response")
                    continue

                # v4.1 returns magnets as a list
                sr_magnets = sr.get("data", {}).get("magnets", [])
                if isinstance(sr_magnets, list):
                    info = next((x for x in sr_magnets if str(x.get("id")) == magnet_id), {})
                elif isinstance(sr_magnets, dict):
                    info = sr_magnets.get(magnet_id) or sr_magnets.get(str(magnet_id)) or {}
                else:
                    info = {}

                status_code = info.get("statusCode", -1)
                status      = info.get("status", "")
                log.debug(f"Magnet {magnet_id}: {status!r} (code={status_code})")

                if status_code == 4 or status == "Ready":
                    break
                # Error codes 5–15 are all terminal failures
                if status_code >= 5:
                    log.error(f"Magnet {magnet_id} failed: {status} ({status_code})")
                    return None
            else:
                log.error(f"Magnet {magnet_id} timed out waiting for Ready")
                return None

        # 3. Get file list
        fr = await self._post(AD_FILES, [("id[]", magnet_id)])
        if not fr or fr.get("status") != "success":
            log.error(f"add_magnet files failed: {fr}")
            return None

        magnets_files = fr.get("data", {}).get("magnets", [])
        if isinstance(magnets_files, dict):
            magnets_files = list(magnets_files.values())

        mf_entry = next(
            (x for x in magnets_files if str(x.get("id")) == magnet_id),
            magnets_files[0] if magnets_files else {},
        )
        files_raw = mf_entry.get("files", [])
        files     = self._flatten_files(files_raw)

        video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
        videos     = [f for f in files if any(f.get("n", "").lower().endswith(e) for e in video_exts)]
        target     = videos if videos else files

        log.debug(f"Magnet {magnet_id}: {len(target)} usable files")
        return magnet_id, target

    # ── Unlock file to direct CDN URL ─────────────────────────────────────────

    async def unlock_file(self, link: str) -> Optional[str]:
        """
        Unlock an AllDebrid file link to get a direct CDN download URL.
        POST /v4/link/unlock with the link in the POST body.
        """
        result = await self._post(AD_UNLOCK, [("link", link)])
        if not result or result.get("status") != "success":
            log.error(f"unlock_file failed: {result}")
            return None
        cdn = result.get("data", {}).get("link")
        if not cdn:
            log.error(f"unlock_file: no link in response: {result}")
        return cdn

    # ── Delete a permanent magnet ─────────────────────────────────────────────

    async def delete_magnet(self, magnet_id: str):
        """Delete a permanent magnet from the AllDebrid account."""
        try:
            result = await self._post(AD_DELETE, [("id", magnet_id)])
            if result and result.get("status") == "success":
                log.debug(f"Magnet {magnet_id} deleted")
            else:
                log.debug(f"Delete magnet {magnet_id}: {result}")
        except Exception as e:
            log.debug(f"Delete magnet {magnet_id} failed (non-critical): {e}")

    # ── Get all ready torrents (for FUSE mount on startup) ────────────────────

    async def get_all_torrents(self) -> list[dict]:
        """
        Fetch all Ready torrents from the account for FUSE mount registration.
        Uses:
          POST /v4.1/magnet/status  (status=ready)
          POST /v4/magnet/files     (batched)
        """
        try:
            # Step 1: list all ready magnets
            sr = await self._post(AD_STATUS, [("status", "ready")])
            if not sr or sr.get("status") != "success":
                log.warning(f"get_all_torrents: status failed: {sr}")
                return []

            magnets_raw = sr.get("data", {}).get("magnets", [])
            if isinstance(magnets_raw, dict):
                magnets = list(magnets_raw.values())
            elif isinstance(magnets_raw, list):
                magnets = magnets_raw
            else:
                return []

            if not magnets:
                log.info("AllDebrid: no ready torrents in account")
                return []

            ids      = [str(m.get("id", "")) for m in magnets if m.get("id")]
            id_name  = {str(m["id"]): m.get("filename", f"torrent_{m['id']}") for m in magnets}
            id_hash  = {str(m["id"]): (m.get("hash") or "").lower()           for m in magnets}
            video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
            result   = []
            BATCH    = 50

            # Step 2: fetch files in batches
            for i in range(0, len(ids), BATCH):
                batch = ids[i:i + BATCH]
                pairs = [("id[]", bid) for bid in batch]
                fd    = await self._post(AD_FILES, pairs)
                if not fd or fd.get("status") != "success":
                    log.debug(f"magnet/files batch error: {fd}")
                    continue

                mf_list = fd.get("data", {}).get("magnets", [])
                if isinstance(mf_list, dict):
                    mf_list = list(mf_list.values())

                for mf in mf_list:
                    if mf.get("error"):
                        continue
                    mid   = str(mf.get("id", ""))
                    name  = id_name.get(mid, f"torrent_{mid}")
                    flat  = self._flatten_files(mf.get("files", []))
                    vids  = [f for f in flat if any(f.get("n","").lower().endswith(e) for e in video_exts)]
                    if vids:
                        result.append({
                            "id":    mid,
                            "name":  name,
                            "hash":  id_hash.get(mid, ""),
                            "files": vids,
                        })

            log.info(f"AllDebrid: {len(result)} ready torrents loaded")
            return result

        except Exception as e:
            log.error(f"get_all_torrents failed: {e}", exc_info=True)
            return []

    # ── TMDB episode lookup (for shows with non-standard numbering) ───────────

    async def _resolve_episode_via_tmdb(
        self, title: str, season: int, episode: int, imdb_id: str | None
    ) -> tuple[int | None, int | None]:
        return season, episode   # Placeholder — TMDB lookup handled in main.py

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _flatten_files(self, files: list, depth: int = 0) -> list:
        """Recursively flatten the AllDebrid file tree into a flat list."""
        result = []
        for f in files:
            if "e" in f:
                result.extend(self._flatten_files(f["e"], depth + 1))
            else:
                result.append(f)
        return result

# Backwards-compatible alias
AllDebridClient = AllDebrid
