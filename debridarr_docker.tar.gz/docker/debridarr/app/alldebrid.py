"""
AllDebrid client.

Search: exact port of kohnorw/debrid alldebrid-web/app.py
  - _sanitize, parse_query, strip_season, filter_by_season, filter_by_quality
  - _fetch (TPB with fallback mirrors)
  - check_cache: upload all → read ready flag → delete all (one per id, like original)
  - do_search: _fetch → filter → check_cache → sort cached first

Add + unlock (like decypharr):
  - add_magnet: upload magnet → poll until statusCode==4 → get file list
  - unlock_file: /link/unlock on each file's link → direct CDN URL
  - Magnet STAYS in account — it's the source for FUSE reads
  - Only the cache-check magnets are deleted
"""

import asyncio
import logging
import re
import time
import urllib.parse
from typing import Optional

import httpx

log = logging.getLogger("debridarr.alldebrid")

AD_BASE   = "https://api.alldebrid.com/v4"
AD_UPLOAD = f"{AD_BASE}/magnet/upload"
AD_DELETE = f"{AD_BASE}/magnet/delete"
AD_STATUS = "https://api.alldebrid.com/v4.1/magnet/status"
AD_FILES  = f"{AD_BASE}/magnet/files"
AD_UNLOCK = f"{AD_BASE}/link/unlock"
AGENT     = "debridarr"

APIBAY_URLS = [
    "https://apibay.org/q.php",
    "https://apibay.nocensor.space/q.php",
    "https://thepiratebay.org/q.php",
]

QUALITY_RE = re.compile(
    r'\b(2160p?|1080p?|720p?|480p?|4k|uhd|hdr|hdr10|dv|web-?dl|webrip|bluray|blu-ray'
    r'|hevc|x265|x264|h264|h265|remux|proper|repack)\b',
    re.IGNORECASE,
)

_search_cache: dict[str, tuple[float, list]] = {}
_CACHE_TTL = 3600


# ── Exact port of kohnorw/debrid helpers ──────────────────────────────────────

def _sanitize(query: str) -> str:
    q = re.sub(r"[''`´]", "", query)
    q = re.sub(r"[^\w\s\-]", " ", q)
    return re.sub(r"\s+", " ", q).strip()


def parse_query(raw: str):
    """Returns (clean_title, season, episode, quality_tokens)"""
    quality = QUALITY_RE.findall(raw)
    search_raw = QUALITY_RE.sub("", raw).strip()
    m = re.search(r'\bseason\s+(\d+)\b', search_raw, re.IGNORECASE)
    if m:
        season_num = int(m.group(1))
        search_raw = re.sub(r'\bseason\s+\d+\b', f"S{season_num:02d}", search_raw, flags=re.IGNORECASE)
    season = episode = None
    m = re.search(r'(?<![a-zA-Z])S(\d{1,2})(?:E(\d{1,2}))?(?![a-zA-Z0-9])', search_raw, re.IGNORECASE)
    if m:
        season = int(m.group(1))
        if m.group(2):
            episode = int(m.group(2))
    return " ".join(search_raw.split()).strip(), season, episode, quality


def strip_season(query: str) -> str:
    t = re.sub(r'(?<![a-zA-Z])S\d{1,2}(?:E\d{1,2})?(?![a-zA-Z0-9])', "", query, flags=re.IGNORECASE)
    return " ".join(t.split())


def filter_by_season(torrents: list, season, episode) -> list:
    if season is None:
        return torrents
    s_str = f"S{season:02d}"
    s_alt = f"SEASON {season}"
    out = []
    for t in torrents:
        nu = t.get("name", "").upper()
        if s_str not in nu and s_alt not in nu:
            continue
        others = re.findall(r'S(\d{2})E\d{2}', nu)
        if others and not all(int(s) == season for s in others):
            continue
        has_ep_tags = bool(re.search(r'E\d{2}', nu))
        if episode is not None and has_ep_tags and f"E{episode:02d}" not in nu:
            continue
        out.append(t)
    return out


def filter_by_quality(torrents: list, quality: list) -> list:
    if not quality:
        return torrents
    out = []
    for t in torrents:
        name_up = t.get("name", "").upper()
        for q in quality:
            if q.upper().rstrip("P") in name_up:
                out.append(t)
                break
    return out if out else torrents


def _make_magnet(torrent: dict) -> str:
    h    = torrent["info_hash"].lower()
    name = urllib.parse.quote(torrent.get("name", ""), safe="")
    return f"magnet:?xt=urn:btih:{h}&dn={name}"


# ── TPB fetch (async version of kohnorw _fetch) ───────────────────────────────

async def _fetch(client: httpx.AsyncClient, query: str, limit: int = 40) -> list:
    queries = [query]
    san = _sanitize(query)
    if san.lower() != query.lower():
        queries.append(san)
    for q in queries:
        for url in APIBAY_URLS:
            try:
                r = await client.get(url, params={"q": q, "cat": 0}, timeout=10)
                if r.status_code != 200:
                    continue
                data = r.json()
                if not data or (isinstance(data, list) and data[0].get("id") == "0"):
                    continue
                valid = [
                    x for x in data
                    if isinstance(x, dict)
                    and x.get("info_hash")
                    and re.fullmatch(r'[0-9a-fA-F]{40}', x["info_hash"])
                ]
                if valid:
                    return valid[:limit]
            except Exception as e:
                log.debug(f"TPB {url} failed: {e}")
    return []


# ── check_cache: exact port of kohnorw/debrid check_cache ────────────────────
# Upload all magnets → read ready flag → delete each id (one POST per id, like original)

async def _ad_post(client: httpx.AsyncClient, api_key: str, torrents: list) -> dict:
    if not torrents:
        return {}
    pairs = [("magnets[]", _make_magnet(t)) for t in torrents]
    body  = urllib.parse.urlencode(pairs)
    try:
        r = await client.post(
            AD_UPLOAD,
            headers={"Authorization": f"Bearer {api_key}",
                     "Content-Type": "application/x-www-form-urlencoded"},
            content=body,
            timeout=15,
        )
        r.raise_for_status()
        return r.json()
    except Exception as e:
        log.error(f"AllDebrid upload failed: {e}")
        return {}


async def _delete_magnets(client: httpx.AsyncClient, api_key: str, ids: list):
    """Delete each magnet individually — mirrors kohnorw/debrid _delete_magnets."""
    for mid in ids:
        try:
            await client.post(
                AD_DELETE,
                headers={"Authorization": f"Bearer {api_key}",
                         "Content-Type": "application/x-www-form-urlencoded"},
                content=urllib.parse.urlencode({"id": mid}),
                timeout=10,
            )
        except Exception:
            pass


async def check_cache(client: httpx.AsyncClient, api_key: str, torrents: list) -> dict:
    """Upload all, read ready flag, delete all. Returns {hash: bool}."""
    result = await _ad_post(client, api_key, torrents)
    if result.get("status") == "error":
        return {}
    ready_map: dict[str, bool] = {}
    ids_to_delete = []
    for m in result.get("data", {}).get("magnets", []):
        if m.get("error"):
            continue
        h = (m.get("hash") or "").lower()
        if h:
            ready_map[h] = bool(m.get("ready", False))
        if m.get("id"):
            ids_to_delete.append(m["id"])
    await _delete_magnets(client, api_key, ids_to_delete)
    cached = sum(1 for v in ready_map.values() if v)
    log.info(f"Cache check: {cached}/{len(ready_map)} cached, deleted {len(ids_to_delete)} temp magnets")
    return ready_map


# ── do_search: exact port of kohnorw/debrid do_search ────────────────────────

async def do_search(
    client: httpx.AsyncClient,
    api_key: str,
    query: str,
    season=None,
    episode=None,
    quality=None,
    limit: int = 40,
) -> list:
    torrents = await _fetch(client, query, limit)
    if not torrents and season is not None:
        fallback = strip_season(query)
        if fallback and fallback.lower() != query.lower():
            log.info(f"🔎 Fallback search: {fallback!r}")
            torrents = await _fetch(client, fallback, limit * 2)
    if not torrents:
        return []

    filtered = filter_by_season(torrents, season, episode)
    if not filtered and season is not None:
        filtered = torrents
    if quality:
        filtered = filter_by_quality(filtered, quality)

    if api_key:
        ready_map = await check_cache(client, api_key, filtered)
    else:
        ready_map = {}

    results = []
    for t in filtered:
        h = t["info_hash"].lower()
        results.append({
            "hash":    h,
            "name":    t.get("name", "Unknown"),
            "size":    int(t.get("size", 0) or 0),
            "seeders": int(t.get("seeders", 0) or 0),
            "magnet":  _make_magnet(t),
            "quality": _detect_quality(t.get("name", "")),
            "cached":  ready_map.get(h, False),
        })
    results.sort(key=lambda x: (not x["cached"], -x["seeders"]))
    return results


def _detect_quality(name: str) -> str:
    n = name.lower()
    for q in ["2160p", "4k", "uhd", "1080p", "720p", "480p"]:
        if q in n:
            return q
    return "unknown"


# ── Main client ────────────────────────────────────────────────────────────────

class AllDebridClient:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self._client = httpx.AsyncClient(timeout=30, follow_redirects=True)

    async def search_cached(
        self,
        title: str,
        media_type: str = "movie",
        year=None,
        season=None,
        episode=None,
        imdb_id=None,
        total_seasons: int = None,
        total_episodes: int = None,
        season_episode_count: int = None,
    ) -> list:
        """
        Simple search:
          - TV episode  -> "Title S##E##"
          - Movie       -> "Title Year"
        Pre-caching the rest of the season is handled after resolve.
        """
        cache_key = f"{title}::{media_type}::s{season}e{episode}"
        if cache_key in _search_cache:
            ts, r = _search_cache[cache_key]
            if time.time() - ts < _CACHE_TTL:
                return r

        if media_type == "episode" and season and episode:
            query = f"{title} S{season:02d}E{episode:02d}"
        elif media_type == "episode" and season:
            query = f"{title} S{season:02d}"
        else:
            query = f"{title} {year or ''}".strip()

        parsed_q, parsed_s, parsed_ep, quality = parse_query(query)
        log.info(f"Search: {parsed_q!r} s={parsed_s} ep={parsed_ep}")

        results = await do_search(
            self._client, self.api_key,
            parsed_q, parsed_s, parsed_ep, quality,
        )

        if results:
            cached = sum(1 for r in results if r["cached"])
            log.info(f"{len(results)} results, {cached} cached for {title!r}")
        else:
            log.warning(f"No results for {title!r}")

        _search_cache[cache_key] = (time.time(), results[:5])
        return results[:5]

    async def add_magnet(self, magnet: str) -> Optional[tuple[str, list]]:
        """
        Add magnet to AllDebrid account (stays there for FUSE reads).
        Returns (magnet_id, files) where files = [{name, link, size}, ...]
        Mirrors decypharr's addMagnetLink → GetTorrent flow.

        statusCode meanings (from decypharr):
          0-3 = Downloading
          4   = Downloaded/Ready
        """
        try:
            # Upload
            r = await self._client.get(
                AD_UPLOAD,
                params={"agent": AGENT, "apikey": self.api_key, "magnets[]": magnet},
            )
            data = r.json()
            if data.get("status") != "success":
                log.error(f"Magnet upload failed: {data}")
                return None

            m = data["data"]["magnets"][0]
            if m.get("error"):
                log.error(f"Magnet error: {m['error']}")
                return None

            magnet_id = str(m["id"])
            log.info(f"Magnet uploaded id={magnet_id} ready={m.get('ready')}")

            # If not instantly ready, poll until statusCode == 4
            if not m.get("ready"):
                for attempt in range(20):
                    await asyncio.sleep(2)
                    sr = await self._client.get(
                        AD_STATUS,
                        params={"agent": AGENT, "apikey": self.api_key, "id": magnet_id},
                    )
                    sr_data = sr.json().get("data", {}).get("magnets", {})
                    # v4.1 returns magnets as dict keyed by id, or single object
                    if isinstance(sr_data, dict) and magnet_id in sr_data:
                        info = sr_data[magnet_id]
                    elif isinstance(sr_data, dict) and str(magnet_id) in sr_data:
                        info = sr_data[str(magnet_id)]
                    elif isinstance(sr_data, dict):
                        # Single magnet response
                        info = sr_data
                    else:
                        info = {}
                    status_code = info.get("statusCode", -1)
                    status      = info.get("status", "")
                    log.info(f"Magnet {magnet_id}: status={status!r} statusCode={status_code}")
                    if status_code == 4 or status == "Ready":
                        break
                    if status in ("Error", "Fail", "Deleted", "Banned", "Virus", "OverQuota"):
                        log.error(f"Magnet failed: {status}")
                        return None
                else:
                    log.error(f"Magnet {magnet_id} timed out")
                    return None

            # Get file list
            fr = await self._client.get(
                AD_FILES,
                params={"agent": AGENT, "apikey": self.api_key, "id[]": magnet_id},
            )
            files_raw = fr.json().get("data", {}).get("magnets", [{}])[0].get("files", [])
            files = self._flatten_files(files_raw)

            # Filter to video files, pick largest
            video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
            videos = [f for f in files if any(f["n"].lower().endswith(e) for e in video_exts)]
            target_files = videos if videos else files

            log.info(f"Magnet {magnet_id}: {len(target_files)} video files")
            return magnet_id, target_files

        except Exception as e:
            log.error(f"add_magnet failed: {e}", exc_info=True)
            return None

    async def unlock_file(self, link: str) -> Optional[str]:
        """Unlock a file link to get a direct CDN URL. Mirrors decypharr fetchDownloadLink."""
        try:
            r = await self._client.get(
                AD_UNLOCK,
                params={"agent": AGENT, "apikey": self.api_key, "link": link},
            )
            d = r.json()
            if d.get("status") != "success":
                log.error(f"Unlock failed: {d}")
                return None
            return d["data"]["link"]
        except Exception as e:
            log.error(f"unlock_file failed: {e}", exc_info=True)
            return None

    async def delete_magnet(self, magnet_id: str):
        """Delete a magnet from AllDebrid account."""
        try:
            await self._client.post(
                AD_DELETE,
                headers={"Authorization": f"Bearer {self.api_key}",
                         "Content-Type": "application/x-www-form-urlencoded"},
                content=urllib.parse.urlencode({"id": magnet_id}),
                timeout=10,
            )
            log.info(f"🗑️  Deleted magnet {magnet_id}")
        except Exception as e:
            log.debug(f"Delete magnet failed (non-critical): {e}")

    def _flatten_files(self, files, depth=0) -> list:
        result = []
        for f in files:
            if "e" in f:
                result.extend(self._flatten_files(f["e"], depth + 1))
            else:
                result.append(f)
        return result

    async def get_all_torrents(self) -> list[dict]:
        """
        Fetch all ready torrents from AllDebrid account.

        v4.1/magnet/status — returns magnet list (NO files since Oct 2024)
          magnets is a DICT keyed by id (not a list)
          filter: status=ready returns only ready ones

        v4/magnet/files?id[]=x&id[]=y — returns files for given IDs
        """
        try:
            # Step 1: get all ready magnet IDs and names
            r = await self._client.get(
                "https://api.alldebrid.com/v4.1/magnet/status",
                params={"agent": AGENT, "apikey": self.api_key, "status": "ready"},
            )
            data = r.json()

            if data.get("status") != "success":
                err = data.get("error", {})
                log.warning(f"get_all_torrents status failed: {err}")
                return []

            magnets_raw = data.get("data", {}).get("magnets", {})

            # magnets is a dict keyed by string ID
            if isinstance(magnets_raw, dict):
                magnets = list(magnets_raw.values())
            elif isinstance(magnets_raw, list):
                magnets = magnets_raw
            else:
                log.warning(f"Unexpected magnets type: {type(magnets_raw)}")
                return []

            if not magnets:
                log.info("AllDebrid: no ready torrents")
                return []

            # Step 2: fetch files for all ready magnets in one call
            ids = [str(m.get("id", "")) for m in magnets if m.get("id")]
            params = {"agent": AGENT, "apikey": self.api_key}
            for i in ids:
                params[f"id[]"] = i  # httpx handles repeated keys

            # Use a list of tuples for repeated params
            file_params = [
                ("agent", AGENT),
                ("apikey", self.api_key),
            ] + [("id[]", i) for i in ids]

            r2 = await self._client.get(
                "https://api.alldebrid.com/v4/magnet/files",
                params=file_params,
            )
            files_data = r2.json()

            if files_data.get("status") != "success":
                err = files_data.get("error", {})
                log.warning(f"get_all_torrents files failed: {err}")
                return []

            # magnets/files response: data.magnets is list of {id, files:[]}
            magnets_files = files_data.get("data", {}).get("magnets", [])
            if isinstance(magnets_files, dict):
                magnets_files = list(magnets_files.values())

            # Build id→name map from status response
            id_name = {str(m.get("id", "")): m.get("filename", f"torrent_{m.get('id','')}")
                       for m in magnets}

            video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
            result = []

            for mf in magnets_files:
                mid = str(mf.get("id", ""))
                name = id_name.get(mid, f"torrent_{mid}")
                raw_files = mf.get("files", [])
                flat = self._flatten_files(raw_files)
                videos = [f for f in flat if any(f.get("n","").lower().endswith(e) for e in video_exts)]
                if videos:
                    result.append({
                        "id":    mid,
                        "name":  name,
                        "files": videos,
                    })

            log.info(f"AllDebrid: {len(result)} torrents with video files")
            return result

        except Exception as e:
            log.error(f"get_all_torrents failed: {e}", exc_info=True)
            return []


