"""
AllDebrid API client — lightweight wrapper.
Design goals:
  - Minimal API calls (batch hash checks, cache results aggressively)
  - Search via The Pirate Bay (like kohnorw/debrid does)
  - Unlock magnets for direct stream URLs
"""

import asyncio
import hashlib
import logging
import re
import time
import urllib.parse
from typing import Optional

import httpx

log = logging.getLogger("debridarr.alldebrid")

ALLDEBRID_API = "https://api.alldebrid.com/v4"
APIBAY_URL = "https://apibay.org/q.php"
AGENT = "debridarr"

# Simple in-process cache so we don't hammer AllDebrid
_search_cache: dict[str, tuple[float, list]] = {}  # query → (timestamp, results)
_SEARCH_CACHE_TTL = 3600  # 1 hour


class AllDebridClient:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self._client = httpx.AsyncClient(
            timeout=30,
            headers={"User-Agent": "debridarr/0.1"},
        )

    # ─────────────────────────────────────────
    # Public interface
    # ─────────────────────────────────────────

    async def search_cached(self, query: str, media_type: str = "movie") -> list[dict]:
        """
        Search TPB for query, batch-check AllDebrid cache, return only cached results
        sorted by size (largest = usually best quality match).
        Results are cached in-process for 1h to avoid repeated API hits.
        """
        cache_key = f"{query}::{media_type}"
        if cache_key in _search_cache:
            ts, results = _search_cache[cache_key]
            if time.time() - ts < _SEARCH_CACHE_TTL:
                log.debug(f"Search cache hit for '{query}'")
                return results

        # 1. Search The Pirate Bay
        torrents = await self._search_tpb(query, media_type)
        if not torrents:
            log.warning(f"No TPB results for '{query}'")
            return []

        # 2. Batch check AllDebrid cache (single API call for all hashes)
        hashes = [t["info_hash"].upper() for t in torrents]
        cached_hashes = await self._check_cache_batch(hashes)

        # 3. Filter to only cached torrents
        cached = [t for t in torrents if t["info_hash"].upper() in cached_hashes]
        log.info(f"Found {len(cached)}/{len(torrents)} cached on AllDebrid for '{query}'")

        if not cached:
            # Fall back to non-cached if nothing available (will be slower to start)
            log.info("No cached results, falling back to best seeded torrent")
            cached = sorted(torrents, key=lambda t: int(t.get("seeders", 0)), reverse=True)[:1]

        # 4. Score and sort: prefer 1080p, then size
        scored = self._score_results(cached, quality_pref="1080p")
        results = scored[:5]  # top 5

        _search_cache[cache_key] = (time.time(), results)
        return results

    async def unlock_magnet(self, magnet: str) -> Optional[str]:
        """
        Add magnet to AllDebrid, get the file list, return the best video stream URL.
        AllDebrid unlocks instantly for cached content.
        """
        try:
            # Step 1: Upload the magnet
            resp = await self._client.get(
                f"{ALLDEBRID_API}/magnet/upload",
                params={"agent": AGENT, "apikey": self.api_key, "magnets[]": magnet},
            )
            data = resp.json()
            if data.get("status") != "success":
                log.error(f"Magnet upload failed: {data}")
                return None

            magnet_id = data["data"]["magnets"][0]["id"]
            log.debug(f"Magnet uploaded, id={magnet_id}")

            # Step 2: Wait for it to be ready (cached = near-instant)
            for attempt in range(10):
                status_resp = await self._client.get(
                    f"{ALLDEBRID_API}/magnet/status",
                    params={"agent": AGENT, "apikey": self.api_key, "id": magnet_id},
                )
                status_data = status_resp.json()
                magnet_info = status_data.get("data", {}).get("magnets", {})
                magnet_status = magnet_info.get("status", "")
                log.debug(f"Magnet status: {magnet_status}")

                if magnet_status == "Ready":
                    break
                elif magnet_status in ("Error", "Fail"):
                    log.error(f"Magnet processing failed: {magnet_status}")
                    return None

                await asyncio.sleep(2 if attempt < 3 else 5)
            else:
                log.error("Magnet did not become ready in time")
                return None

            # Step 3: Get the file links
            links_resp = await self._client.get(
                f"{ALLDEBRID_API}/magnet/files",
                params={"agent": AGENT, "apikey": self.api_key, "id[]": magnet_id},
            )
            links_data = links_resp.json()
            files = links_data.get("data", {}).get("magnets", [{}])[0].get("files", [])
            if not files:
                log.error("No files returned for magnet")
                return None

            # Pick largest video file
            video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
            video_files = [
                f for f in self._flatten_files(files)
                if any(f["n"].lower().endswith(ext) for ext in video_exts)
            ]
            if not video_files:
                video_files = self._flatten_files(files)

            best_file = max(video_files, key=lambda f: f.get("s", 0))
            link = best_file.get("l") or best_file.get("e", [{}])[0].get("l", "")

            if not link:
                log.error("No download link in file listing")
                return None

            # Step 4: Unlock the link to get a direct HTTP URL
            return await self.unlock_link(link)

        except Exception as e:
            log.error(f"unlock_magnet failed: {e}", exc_info=True)
            return None

    async def unlock_link(self, link: str) -> Optional[str]:
        """Unlock an AllDebrid link to get a direct stream URL."""
        try:
            resp = await self._client.get(
                f"{ALLDEBRID_API}/link/unlock",
                params={"agent": AGENT, "apikey": self.api_key, "link": link},
            )
            data = resp.json()
            if data.get("status") != "success":
                log.error(f"Link unlock failed: {data}")
                return None
            return data["data"]["link"]
        except Exception as e:
            log.error(f"unlock_link failed: {e}", exc_info=True)
            return None

    # ─────────────────────────────────────────
    # Internal helpers
    # ─────────────────────────────────────────

    async def _search_tpb(self, query: str, media_type: str) -> list[dict]:
        """Search The Pirate Bay and return torrent dicts."""
        # Clean query for URL
        clean = re.sub(r"[^\w\s]", "", query).strip()
        cat = "200" if media_type == "movie" else "205"  # TPB categories: 200=video, 205=TV

        try:
            resp = await self._client.get(
                APIBAY_URL,
                params={"q": clean, "cat": cat},
            )
            results = resp.json()
            if not results or (len(results) == 1 and results[0].get("name") == "No results returned"):
                return []

            torrents = []
            for r in results:
                if not r.get("info_hash"):
                    continue
                torrents.append({
                    "info_hash": r["info_hash"].upper(),
                    "name": r.get("name", ""),
                    "size": int(r.get("size", 0)),
                    "seeders": int(r.get("seeders", 0)),
                    "magnet": self._build_magnet(r["info_hash"], r.get("name", "")),
                    "quality": self._detect_quality(r.get("name", "")),
                })
            return torrents
        except Exception as e:
            log.error(f"TPB search failed: {e}", exc_info=True)
            return []

    async def _check_cache_batch(self, hashes: list[str]) -> set[str]:
        """
        Batch check AllDebrid cache for multiple hashes.
        Returns set of cached hashes. One API call for all hashes.
        AllDebrid limit: we delete the check immediately (no quota used).
        """
        if not hashes:
            return set()

        try:
            # AllDebrid accepts multiple hashes[]=
            params = [("agent", AGENT), ("apikey", self.api_key)]
            for h in hashes[:50]:  # cap at 50 to be safe
                params.append(("magnets[]", h))

            resp = await self._client.get(
                f"{ALLDEBRID_API}/magnet/instant",
                params=params,
            )
            data = resp.json()
            if data.get("status") != "success":
                log.warning(f"Cache check API error: {data}")
                return set()

            magnets = data.get("data", {}).get("magnets", [])
            cached = set()
            for m in magnets:
                if m.get("instant") or m.get("cached"):
                    cached.add(m.get("hash", "").upper())
            return cached

        except Exception as e:
            log.error(f"Batch cache check failed: {e}", exc_info=True)
            return set()

    def _build_magnet(self, info_hash: str, name: str) -> str:
        trackers = [
            "udp://tracker.opentrackr.org:1337/announce",
            "udp://open.stealth.si:80/announce",
            "udp://tracker.torrent.eu.org:451/announce",
        ]
        encoded_name = urllib.parse.quote(name)
        tracker_str = "&".join(f"tr={urllib.parse.quote(t)}" for t in trackers)
        return f"magnet:?xt=urn:btih:{info_hash}&dn={encoded_name}&{tracker_str}"

    def _detect_quality(self, name: str) -> str:
        name_lower = name.lower()
        for q in ["2160p", "4k", "uhd", "1080p", "720p", "480p"]:
            if q in name_lower:
                return q
        return "unknown"

    def _score_results(self, torrents: list[dict], quality_pref: str = "1080p") -> list[dict]:
        """Score torrents: preferred quality first, then by size."""
        def score(t):
            q = t.get("quality", "").lower()
            quality_score = {quality_pref: 100, "1080p": 80, "720p": 50, "2160p": 60, "4k": 60}.get(q, 10)
            size_score = min(t.get("size", 0) / (1024**3), 20)  # cap at 20GB in score
            return quality_score + size_score

        return sorted(torrents, key=score, reverse=True)

    def _flatten_files(self, files, depth=0) -> list[dict]:
        """Recursively flatten AllDebrid nested file listings."""
        result = []
        for f in files:
            if "e" in f:  # folder
                result.extend(self._flatten_files(f["e"], depth + 1))
            else:
                result.append(f)
        return result
