"""
AllDebrid API client.

Search: exact port of do_search() + helpers from kohnorw/debrid/alldebrid-web/app.py.
No changes to logic — only async httpx instead of sync requests.

Unlock: separate from search — adds magnet for real, waits for ready, returns stream URL.
"""

import asyncio
import logging
import re
import time
import urllib.parse
from typing import Optional

import httpx

log = logging.getLogger("debridarr.alldebrid")

ALLDEBRID_API    = "https://api.alldebrid.com/v4"
ALLDEBRID_UPLOAD = f"{ALLDEBRID_API}/magnet/upload"
ALLDEBRID_DELETE = f"{ALLDEBRID_API}/magnet/delete"
AGENT            = "debridarr"

APIBAY_URLS = [
    "https://apibay.org/q.php",
    "https://apibay.nocensor.space/q.php",
    "https://thepiratebay.org/q.php",
]

QUALITY_RE = re.compile(
    r'\b(2160p?|1080p?|720p?|480p?|4k|uhd|hdr|hdr10|dv|web-?dl|webrip|bluray|blu-ray'
    r'|hevc|x265|x264|h264|h265|remux|proper|repack)\b',
    re.IGNORECASE,
)

_search_cache: dict[str, tuple[float, list]] = {}
_CACHE_TTL = 3600


# ─────────────────────────────────────────────────────────────────────────────
# Exact port of helpers from kohnorw/debrid/alldebrid-web/app.py
# ─────────────────────────────────────────────────────────────────────────────

def _sanitize(query: str) -> str:
    q = re.sub(r"[''`´]", "", query)
    q = re.sub(r"[^\w\s\-]", " ", q)
    return re.sub(r"\s+", " ", q).strip()


def _parse_query(raw: str):
    """Returns (clean_title, season, episode, quality_tokens) — exact port."""
    quality = QUALITY_RE.findall(raw)
    search_raw = QUALITY_RE.sub("", raw).strip()

    m = re.search(r'\bseason\s+(\d+)\b', search_raw, re.IGNORECASE)
    if m:
        season_num = int(m.group(1))
        search_raw = re.sub(
            r'\bseason\s+\d+\b', f"S{season_num:02d}", search_raw, flags=re.IGNORECASE
        )

    season = episode = None
    m = re.search(r'(?<![a-zA-Z])S(\d{1,2})(?:E(\d{1,2}))?(?![a-zA-Z0-9])', search_raw, re.IGNORECASE)
    if m:
        season = int(m.group(1))
        if m.group(2):
            episode = int(m.group(2))

    return " ".join(search_raw.split()).strip(), season, episode, quality


def _strip_season(query: str) -> str:
    t = re.sub(r'(?<![a-zA-Z])S\d{1,2}(?:E\d{1,2})?(?![a-zA-Z0-9])', "", query, flags=re.IGNORECASE)
    return " ".join(t.split())


def _filter_by_season(torrents: list, season, episode) -> list:
    """
    Port from kohnorw/debrid with one addition:
    season packs (no E## tag) are kept even when episode is specified —
    Plex can pick the right episode from a pack.
    """
    if season is None:
        return torrents
    s_str = f"S{season:02d}"
    s_alt = f"SEASON {season}"
    out = []
    for t in torrents:
        nu = t.get("name", "").upper()
        if s_str not in nu and s_alt not in nu:
            continue
        # Reject packs that span multiple seasons
        others = re.findall(r'S(\d{2})E\d{2}', nu)
        if others and not all(int(s) == season for s in others):
            continue
        # If episode specified: keep exact match OR season pack (no episode tags at all)
        has_ep_tags = bool(re.search(r'E\d{2}', nu))
        if episode is not None and has_ep_tags and f"E{episode:02d}" not in nu:
            continue
        out.append(t)
    return out


def _filter_by_quality(torrents: list, quality: list) -> list:
    """Exact port from kohnorw/debrid."""
    if not quality:
        return torrents
    out = [
        t for t in torrents
        if any(q.upper().rstrip("P") in t.get("name", "").upper() for q in quality)
    ]
    return out if out else torrents


def _make_magnet(info_hash: str, name: str = "") -> str:
    dn = urllib.parse.quote(name, safe="")
    return f"magnet:?xt=urn:btih:{info_hash.lower()}&dn={dn}"


def _detect_quality(name: str) -> str:
    n = name.lower()
    for q in ["2160p", "4k", "uhd", "1080p", "720p", "480p"]:
        if q in n:
            return q
    return "unknown"


# ─────────────────────────────────────────────────────────────────────────────
# Async TPB fetch — mirrors _fetch() from kohnorw/debrid
# ─────────────────────────────────────────────────────────────────────────────

async def _fetch(client: httpx.AsyncClient, query: str, limit: int = 40) -> list:
    queries = [query]
    sanitized = _sanitize(query)
    if sanitized.lower() != query.lower():
        queries.append(sanitized)

    for q in queries:
        for url in APIBAY_URLS:
            try:
                resp = await client.get(url, params={"q": q, "cat": 0}, timeout=10)
                if resp.status_code != 200:
                    continue
                data = resp.json()
                if not data or (isinstance(data, list) and data[0].get("id") == "0"):
                    continue
                valid = [
                    x for x in data
                    if isinstance(x, dict)
                    and x.get("info_hash")
                    and re.fullmatch(r'[0-9a-fA-F]{40}', x["info_hash"])
                ]
                if valid:
                    log.debug(f"TPB {url!r}: {len(valid)} results for {q!r}")
                    return valid[:limit]
            except Exception as e:
                log.debug(f"TPB {url} failed: {e}")
    return []


# ─────────────────────────────────────────────────────────────────────────────
# AllDebrid cache check — exact port of check_cache() from kohnorw/debrid
# Upload magnets → read ready flag → delete immediately (nothing stays in account)
# ─────────────────────────────────────────────────────────────────────────────

async def _check_cache(client: httpx.AsyncClient, api_key: str, torrents: list) -> dict:
    if not torrents or not api_key:
        return {}

    pairs = [("magnets[]", _make_magnet(t["info_hash"], t.get("name", ""))) for t in torrents]
    body = urllib.parse.urlencode(pairs)

    try:
        resp = await client.post(
            ALLDEBRID_UPLOAD,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/x-www-form-urlencoded",
            },
            content=body,
            timeout=15,
        )
        result = resp.json()
    except Exception as e:
        log.error(f"AllDebrid upload failed: {e}")
        return {}

    if result.get("status") == "error":
        log.warning(f"AllDebrid error: {result}")
        return {}

    ready_map = {}
    ids_to_delete = []

    for m in result.get("data", {}).get("magnets", []):
        if m.get("error"):
            continue
        h = (m.get("hash") or "").lower()
        if h:
            ready_map[h] = bool(m.get("ready", False))
        if m.get("id"):
            ids_to_delete.append(m["id"])

    # Delete all at once — batch the IDs into one request
    if ids_to_delete:
        try:
            pairs = [("id[]", str(mid)) for mid in ids_to_delete]
            await client.post(
                ALLDEBRID_DELETE,
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                content=urllib.parse.urlencode(pairs),
                timeout=10,
            )
        except Exception:
            pass

    cached_count = sum(1 for v in ready_map.values() if v)
    log.info(f"Cache check: {cached_count}/{len(ready_map)} cached on AllDebrid")
    return ready_map


# ─────────────────────────────────────────────────────────────────────────────
# do_search — exact async port of do_search() from kohnorw/debrid
# ─────────────────────────────────────────────────────────────────────────────

async def _do_search(
    client: httpx.AsyncClient,
    api_key: str,
    query: str,
    season=None,
    episode=None,
    quality=None,
    limit: int = 40,
) -> list:
    torrents = await _fetch(client, query, limit)

    # Fallback: strip season tag and retry with just title
    if not torrents and season is not None:
        fallback = _strip_season(query)
        if fallback and fallback.lower() != query.lower():
            log.info(f"🔎 Fallback search: {fallback!r}")
            torrents = await _fetch(client, fallback, limit * 2)

    if not torrents:
        return []

    filtered = _filter_by_season(torrents, season, episode)
    if not filtered and season is not None:
        filtered = torrents  # season filter wiped everything — use all results

    if quality:
        filtered = _filter_by_quality(filtered, quality)

    ready_map = await _check_cache(client, api_key, filtered)

    results = []
    for t in filtered:
        h = t["info_hash"].lower()
        results.append({
            "info_hash": h,
            "name":      t.get("name", ""),
            "size":      int(t.get("size", 0) or 0),
            "seeders":   int(t.get("seeders", 0) or 0),
            "magnet":    _make_magnet(h, t.get("name", "")),
            "quality":   _detect_quality(t.get("name", "")),
            "cached":    ready_map.get(h, False),
            "source":    "tpb",
        })

    # Sort: cached first, then by seeders (exact port of kohnorw sort)
    results.sort(key=lambda x: (not x["cached"], -x["seeders"]))
    return results


# ─────────────────────────────────────────────────────────────────────────────
# Main client
# ─────────────────────────────────────────────────────────────────────────────

class AllDebridClient:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self._client = httpx.AsyncClient(
            timeout=20,
            headers={"User-Agent": "debridarr/0.2"},
            follow_redirects=True,
        )

    async def search_cached(
        self,
        title: str,
        media_type: str = "movie",
        year: Optional[int] = None,
        season: Optional[int] = None,
        episode: Optional[int] = None,
        imdb_id: Optional[str] = None,
    ) -> list:
        cache_key = f"{title}::{media_type}::s{season}e{episode}"
        if cache_key in _search_cache:
            ts, results = _search_cache[cache_key]
            if time.time() - ts < _CACHE_TTL:
                log.debug(f"Search cache hit: {cache_key}")
                return results

        # Build query exactly as alldebrid-web's torznab route does
        if media_type == "episode" and season and episode:
            query = f"{title} S{season:02d}E{episode:02d}"
        elif media_type == "episode" and season:
            query = f"{title} S{season:02d}"
        else:
            query = f"{title} {year or ''}".strip()

        # parse_query handles "Season X" → S0X, strips quality, extracts S##E##
        parsed_q, parsed_s, parsed_ep, quality = _parse_query(query)
        log.info(f"🔎 Query: {parsed_q!r}  s={parsed_s} ep={parsed_ep} quality={quality}")

        results = await _do_search(
            self._client, self.api_key,
            parsed_q, parsed_s, parsed_ep, quality,
        )

        if not results:
            log.warning(f"❌ No results for '{title}'")
        else:
            cached = sum(1 for r in results if r["cached"])
            log.info(f"✅ {len(results)} results, {cached} cached for '{title}'")

        _search_cache[cache_key] = (time.time(), results[:5])
        return results[:5]

    async def unlock_magnet(self, magnet: str) -> Optional[str]:
        """Add magnet for real, wait for ready, return direct stream URL."""
        try:
            resp = await self._client.get(
                f"{ALLDEBRID_API}/magnet/upload",
                params={"agent": AGENT, "apikey": self.api_key, "magnets[]": magnet},
            )
            data = resp.json()
            if data.get("status") != "success":
                log.error(f"Magnet upload failed: {data}")
                return None

            magnet_id = data["data"]["magnets"][0]["id"]

            for attempt in range(15):
                sr = await self._client.get(
                    f"{ALLDEBRID_API}/magnet/status",
                    params={"agent": AGENT, "apikey": self.api_key, "id": magnet_id},
                )
                sr_data = sr.json()
                info = sr_data.get("data", {}).get("magnets", {})
                status = info.get("status", "")
                # Log full status on first few attempts so we can see what AllDebrid returns
                if attempt < 3:
                    log.info(f"Magnet {magnet_id} status={status!r} statusCode={info.get('statusCode')} "
                             f"error={info.get('error')} filename={info.get('filename','')[:40]}")
                else:
                    log.debug(f"Magnet {magnet_id}: {status}")
                if status == "Ready":
                    break
                # AllDebrid uses "Processing" while downloading, "Downloading" while fetching
                # For cached content it should be Ready almost immediately
                if status in ("Error", "Fail", "Deleted", "Banned", "Virus", "OverQuota"):
                    log.error(f"Magnet failed with status: {status!r} — full response: {info}")
                    return None
                await asyncio.sleep(2 if attempt < 5 else 5)
            else:
                log.error(f"Magnet {magnet_id} timed out — last status: {status!r}")
                return None

            lr = await self._client.get(
                f"{ALLDEBRID_API}/magnet/files",
                params={"agent": AGENT, "apikey": self.api_key, "id[]": magnet_id},
            )
            files = lr.json().get("data", {}).get("magnets", [{}])[0].get("files", [])
            if not files:
                log.error("No files in magnet")
                return None

            video_exts = {".mkv", ".mp4", ".avi", ".mov", ".m4v"}
            flat = self._flatten_files(files)
            videos = [f for f in flat if any(f["n"].lower().endswith(e) for e in video_exts)]
            best = max(videos or flat, key=lambda f: f.get("s", 0))
            link = best.get("l", "")
            if not link:
                return None
            return await self.unlock_link(link)

        except Exception as e:
            log.error(f"unlock_magnet failed: {e}", exc_info=True)
            return None

    async def unlock_link(self, link: str) -> Optional[str]:
        try:
            resp = await self._client.get(
                f"{ALLDEBRID_API}/link/unlock",
                params={"agent": AGENT, "apikey": self.api_key, "link": link},
            )
            data = resp.json()
            if data.get("status") != "success":
                log.error(f"Link unlock failed: {data}")
                return None
            return data["data"]["link"]
        except Exception as e:
            log.error(f"unlock_link failed: {e}", exc_info=True)
            return None

    def _flatten_files(self, files, depth=0) -> list:
        result = []
        for f in files:
            if "e" in f:
                result.extend(self._flatten_files(f["e"], depth + 1))
            else:
                result.append(f)
        return result
