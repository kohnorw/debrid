"""
Worker pool for Debridarr.
Manages concurrent resolve/cache tasks with cancellation support.
"""
import asyncio
import logging
import time
import uuid
from enum import Enum
from typing import Optional, Callable, Awaitable

log = logging.getLogger("debridarr.workers")


class WorkerStatus(str, Enum):
    queued    = "queued"
    running   = "running"
    done      = "done"
    failed    = "failed"
    cancelled = "cancelled"


class Worker:
    def __init__(self, worker_id: str, label: str, coro_fn: Callable[[], Awaitable]):
        self.id        = worker_id
        self.label     = label
        self.coro_fn   = coro_fn
        self.status    = WorkerStatus.queued
        self.created   = time.time()
        self.started: Optional[float] = None
        self.ended:   Optional[float] = None
        self.error:   Optional[str]   = None
        self._task:   Optional[asyncio.Task] = None

    def to_dict(self) -> dict:
        return {
            "id":      self.id,
            "label":   self.label,
            "status":  self.status.value,
            "created": self.created,
            "started": self.started,
            "ended":   self.ended,
            "error":   self.error,
            "elapsed": round(time.time() - (self.started or self.created), 1),
        }


class WorkerPool:
    def __init__(self, max_workers: int = 3):
        self._max      = max_workers
        self._workers: dict[str, Worker] = {}
        self._queue:   asyncio.Queue     = asyncio.Queue()
        self._running  = 0
        self._lock     = asyncio.Lock()
        self._loop_task: Optional[asyncio.Task] = None

    @property
    def max_workers(self) -> int:
        return self._max

    def set_max_workers(self, n: int):
        self._max = max(1, min(20, n))

    def stats(self) -> dict:
        workers = [w.to_dict() for w in self._workers.values()]
        return {
            "max_workers": self._max,
            "running":     sum(1 for w in workers if w["status"] == "running"),
            "queued":      sum(1 for w in workers if w["status"] == "queued"),
            "done":        sum(1 for w in workers if w["status"] == "done"),
            "failed":      sum(1 for w in workers if w["status"] == "failed"),
            "cancelled":   sum(1 for w in workers if w["status"] == "cancelled"),
            "workers":     workers,
        }

    def get_recent(self, n: int = 50) -> list:
        """Most recent N workers, sorted newest first."""
        ws = sorted(self._workers.values(), key=lambda w: w.created, reverse=True)
        return [w.to_dict() for w in ws[:n]]

    def enqueue(self, label: str, coro_fn: Callable[[], Awaitable]) -> str:
        wid = str(uuid.uuid4())[:8]
        w   = Worker(wid, label, coro_fn)
        self._workers[wid] = w
        self._queue.put_nowait(w)
        log.debug(f"⚙️  Queued: [{wid}] {label}")
        return wid

    def cancel(self, worker_id: str) -> bool:
        w = self._workers.get(worker_id)
        if not w:
            return False
        if w.status == WorkerStatus.running and w._task:
            w._task.cancel()
            w.status = WorkerStatus.cancelled
            w.ended  = time.time()
            log.info(f"⚙️  Cancelled: [{worker_id}] {w.label}")
            return True
        if w.status == WorkerStatus.queued:
            w.status = WorkerStatus.cancelled
            w.ended  = time.time()
            log.info(f"⚙️  Cancelled queued: [{worker_id}] {w.label}")
            return True
        return False

    def cancel_all(self) -> int:
        """Cancel every queued and running worker, then drain the asyncio queue."""
        count = 0
        for wid in list(self._workers.keys()):
            if self.cancel(wid):
                count += 1
        # Drain the asyncio queue so _run_loop doesn't pick up stale entries
        drained = 0
        while not self._queue.empty():
            try:
                self._queue.get_nowait()
                self._queue.task_done()
                drained += 1
            except Exception:
                break
        if count or drained:
            log.info(f"🛑 cancel_all: {count} cancelled, {drained} drained from queue")
        return count

    def prune(self, keep: int = 100):
        """Remove old finished workers, keeping last N."""
        finished = [w for w in self._workers.values()
                    if w.status in (WorkerStatus.done, WorkerStatus.failed, WorkerStatus.cancelled)]
        finished.sort(key=lambda w: w.ended or 0)
        for w in finished[:-keep]:
            del self._workers[w.id]

    def start(self):
        self._loop_task = asyncio.create_task(self._run_loop())

    async def _run_loop(self):
        while True:
            try:
                w = await self._queue.get()
                # Skip cancelled workers (e.g. from cancel_all when precaching disabled)
                if w.status == WorkerStatus.cancelled:
                    self._queue.task_done()
                    continue
                while self._running >= self._max:
                    await asyncio.sleep(0.2)
                    # Re-check if cancelled while waiting for a slot
                    if w.status == WorkerStatus.cancelled:
                        break
                if w.status == WorkerStatus.cancelled:
                    self._queue.task_done()
                    continue
                asyncio.create_task(self._run_worker(w))
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.error(f"Worker loop error: {e}")

    async def _run_worker(self, w: Worker):
        if w.status == WorkerStatus.cancelled:
            return
        self._running += 1
        w.status  = WorkerStatus.running
        w.started = time.time()
        task      = asyncio.current_task()
        w._task   = task
        log.debug(f"⚙️  Start: [{w.id}] {w.label}")
        try:
            await w.coro_fn()
            if w.status != WorkerStatus.cancelled:
                w.status = WorkerStatus.done
        except asyncio.CancelledError:
            w.status = WorkerStatus.cancelled
        except Exception as e:
            w.status = WorkerStatus.failed
            w.error  = str(e)
            log.error(f"⚙️  Failed: [{w.id}] {w.label}: {e}")
        finally:
            w.ended   = time.time()
            self._running -= 1
            self.prune()

    def is_already_queued(self, label: str) -> bool:
        """Check if a task with this label is already queued or running."""
        for w in self._workers.values():
            if w.label == label and w.status in (WorkerStatus.queued, WorkerStatus.running):
                return True
        return False


# Global pool — created on startup
_pool: Optional[WorkerPool] = None


def get_pool() -> WorkerPool:
    global _pool
    if _pool is None:
        _pool = WorkerPool(max_workers=3)
    return _pool


def init_pool(max_workers: int = 3) -> WorkerPool:
    global _pool
    _pool = WorkerPool(max_workers=max_workers)
    return _pool
