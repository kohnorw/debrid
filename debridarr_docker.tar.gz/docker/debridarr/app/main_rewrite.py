"""
Debridarr v2 — Full clean rewrite.
All buttons/toggles working, correct AllDebrid API, settings show active state,
search through server endpoint, placeholders only on proper release.
"""

import asyncio
import json
import logging
import re
import urllib.parse
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional
import struct

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from app.alldebrid import (
    AllDebrid as AllDebridClient,
    SearchConfig,
    _make_magnet,
    _search_cache,
)
from app.cache import CacheDB
from app.config import load_saved_config, save_config
from app.library import LibraryManager
from app.models import MediaType, PlayEvent
from app.workers import WorkerPool

log = logging.getLogger("debridarr")

# ── Fake MP4 placeholder ──────────────────────────────────────────────────────
def _make_fake_mp4() -> bytes:
    def box(t, p): return struct.pack(">I", 8+len(p))+t+p
    ftyp = box(b"ftyp", b"mp42\x00\x00\x00\x00mp42isom")
    mvhd = box(b"mvhd",
        b"\x00"*12+struct.pack(">I",1000)+struct.pack(">I",1000)
        +struct.pack(">I",0x00010000)+struct.pack(">H",0x0100)+b"\x00"*10
        +struct.pack(">9i",0x00010000,0,0,0,0x00010000,0,0,0,0x40000000)
        +b"\x00"*24+struct.pack(">I",2))
    return ftyp+box(b"moov",mvhd)
_FAKE_MP4 = _make_fake_mp4()

# Good quality gate for movies
_GOOD_QUALITY_RE = re.compile(
    r'\b(2160p?|1080p?|720p?|4k|uhd|web-?dl|webdl|bluray|blu-?ray|remux)\b', re.I)

# ─────────────────────────────────────────────────────────────────────────────
# CSS
# ─────────────────────────────────────────────────────────────────────────────
_CSS = """
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#0a0a0f;color:#e0e0e0;min-height:100vh}
nav{display:flex;gap:2px;padding:12px 20px;background:#111118;border-bottom:1px solid #1e1e2e;flex-wrap:wrap}
nav a{padding:7px 14px;border-radius:6px;text-decoration:none;color:#888;font-size:.85rem;font-weight:500;transition:.15s}
nav a:hover{color:#e0e0e0;background:#1a1a24}
nav a.active{color:#fff;background:#f97316}
main{max-width:1400px;margin:0 auto;padding:24px 20px}
h2{font-size:1.2rem;font-weight:700;color:#e0e0e0;margin-bottom:20px}
.search-bar{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.search-bar input,.search-bar select{background:#1a1a24;border:1px solid #2a2a3a;border-radius:8px;padding:9px 14px;color:#e0e0e0;font-size:.9rem;outline:none;min-width:160px}
.search-bar input:focus,.search-bar select:focus{border-color:#f97316}
.card-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:14px}
.card{background:#1a1a24;border:1px solid #2a2a3a;border-radius:10px;overflow:hidden;display:flex;flex-direction:column}
.card img{width:100%;aspect-ratio:2/3;object-fit:cover;display:block}
.card .no-poster{width:100%;aspect-ratio:2/3;background:#0f0f13;display:flex;align-items:center;justify-content:center;font-size:2.5rem}
.card .info{padding:10px 12px;flex:1}
.card .title{font-size:.82rem;font-weight:600;color:#e0e0e0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.card .meta{font-size:.72rem;color:#555;margin-top:3px}
.card .actions{padding:0 10px 10px;display:flex;gap:6px;flex-wrap:wrap}
.btn{padding:7px 14px;border-radius:7px;border:1px solid #2a2a3a;cursor:pointer;font-size:.82rem;font-weight:600;transition:.15s;background:#1a1a24;color:#aaa}
.btn:hover{border-color:#aaa;color:#e0e0e0}
.btn:disabled{opacity:.5;cursor:not-allowed}
.btn-add{background:#f97316;color:#fff;border-color:#f97316}
.btn-add:hover:not(:disabled){background:#ea6c0a}
.btn-rem{background:#3b0000;color:#f87171;border-color:#5a1010}
.btn-rem:hover:not(:disabled){background:#4a0808}
.btn-sec{background:#1a1a2e;color:#60a5fa;border-color:#1e3a5f}
.btn-sec:hover:not(:disabled){background:#1e3a5f}
.btn-sm{padding:4px 10px;font-size:.75rem}
.pill{display:inline-flex;align-items:center;padding:2px 8px;border-radius:4px;font-size:.7rem;font-weight:600}
.pill-ok{background:#14532d;color:#4ade80}
.pill-res{background:#1e3a5f;color:#60a5fa}
.pill-err{background:#3b0000;color:#f87171}
.pill-nf{background:#3b1f00;color:#fb923c}
.pill-pend{background:#2d2d00;color:#facc15}
.pill-thtr{background:#2d1a4e;color:#c084fc}
.empty{text-align:center;padding:60px 20px;color:#444;font-size:.9rem}
.pg{display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin:12px 0}
.pg a,.pg .cur,.pg .dots{display:inline-flex;align-items:center;justify-content:center;min-width:32px;height:32px;padding:0 8px;border-radius:6px;font-size:.82rem;text-decoration:none;border:1px solid #2a2a3a;background:#1a1a24;color:#aaa}
.pg a:hover{border-color:#f97316;color:#f97316}
.pg .cur{background:#f97316;color:#fff;border-color:#f97316;font-weight:700}
.pg .dots{background:transparent;border-color:transparent;color:#444;min-width:20px}
.field{display:flex;flex-direction:column;gap:5px}
.field label{font-size:.78rem;font-weight:600;color:#aaa}
.field input,.field select,.field textarea{background:#0f0f13;border:1px solid #2a2a3a;border-radius:7px;padding:8px 12px;color:#e0e0e0;font-size:.85rem;outline:none}
.field input:focus,.field select:focus,.field textarea:focus{border-color:#f97316}
.field .hint{font-size:.72rem;color:#444}
.toggle{position:relative;display:inline-block;width:42px;height:24px;flex-shrink:0}
.toggle input{opacity:0;width:0;height:0}
.slider{position:absolute;inset:0;background:#2a2a3a;border-radius:24px;cursor:pointer;transition:.2s}
.slider:before{content:"";position:absolute;height:18px;width:18px;left:3px;bottom:3px;background:#555;border-radius:50%;transition:.2s}
input:checked+.slider{background:#f97316}
input:checked+.slider:before{transform:translateX(18px);background:#fff}
.test-result{font-size:.82rem;padding:8px 12px;border-radius:6px;display:none}
.test-result.testing{display:block;background:#1a1a24;color:#aaa;border:1px solid #2a2a3a}
.test-result.ok{display:block;background:#14532d;color:#4ade80;border:1px solid #166534}
.test-result.err{display:block;background:#3b0000;color:#f87171;border:1px solid #5a1010}
.s-sect{background:#1a1a24;border:1px solid #2a2a3a;border-radius:10px;padding:20px 24px;margin-bottom:16px}
.s-title{font-size:.72rem;font-weight:700;text-transform:uppercase;color:#f97316;letter-spacing:.08em;margin-bottom:16px}
.s-sub{font-size:.7rem;font-weight:700;text-transform:uppercase;color:#666;letter-spacing:.06em;margin-bottom:8px;margin-top:16px}
.setting-row{display:flex;align-items:center;justify-content:space-between;gap:20px;padding:10px 0}
.setting-row:not(:last-child){border-bottom:1px solid #1e1e2e}
.setting-row .label{font-size:.875rem;font-weight:600}
.setting-row .desc{font-size:.75rem;color:#555;margin-top:2px}
.setting-active .label{color:#f97316}
#toast{position:fixed;bottom:24px;right:24px;background:#1a1a24;border:1px solid #2a2a3a;border-radius:8px;padding:12px 18px;font-size:.85rem;z-index:999;opacity:0;transition:.3s;pointer-events:none;max-width:320px}
#toast.show{opacity:1}
.snr-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:14px}
.snr-card{border-radius:8px;overflow:hidden;cursor:pointer;background:#0f0f13;border:2px solid #2a2a3a;transition:transform .15s,box-shadow .15s}
.snr-card:hover{transform:scale(1.03);box-shadow:0 4px 20px rgba(0,0,0,.5)}
.snr-card.active{outline:3px solid #f97316}
.snr-detail{background:#13131c;border:1px solid #2a2a3a;border-radius:10px;margin-bottom:20px;overflow:hidden}
.snr-detail-hdr{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;padding:18px 20px 14px;border-bottom:1px solid #1e1e2e;flex-wrap:wrap}
.snr-seasons{padding:4px 20px 16px}
.snr-season{padding:12px 0;border-bottom:1px solid #1e1e2e}
.snr-season:last-child{border-bottom:none}
.snr-season-hdr{display:flex;align-items:center;gap:12px;margin-bottom:10px;flex-wrap:wrap}
.snr-sn-title{font-size:.82rem;font-weight:700;color:#c0c0c0;min-width:70px}
.snr-episodes{display:flex;flex-wrap:wrap;gap:4px}
.ep-chip{display:inline-flex;align-items:center;justify-content:center;min-width:38px;height:24px;padding:0 5px;border-radius:4px;font-size:.68rem;font-weight:700}
.ep-ok{background:#14532d;color:#4ade80}
.ep-miss{background:#1e1e28;color:#3a3a4a;border:1px solid #2a2a3a}
table{width:100%;border-collapse:collapse}
th,td{padding:9px 12px;text-align:left;border-bottom:1px solid #1e1e2e;font-size:.85rem}
th{color:#555;font-size:.75rem;font-weight:700;text-transform:uppercase}
code{background:#1a1a2e;padding:1px 5px;border-radius:3px;font-size:.82rem;color:#60a5fa}
"""

_TOAST_JS = """
function toast(msg, ok) {
  if (ok === undefined) ok = true;
  var t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.style.borderColor = ok ? '#4ade80' : '#f87171';
  t.classList.add('show');
  setTimeout(function() { t.classList.remove('show'); }, 3500);
}
"""

def _page(title, active, body, extra_js=""):
    nav_items = [
        ("movies","🎬 Movies"), ("series","📺 Series"),
        ("search","🔎 Search"), ("missing","❌ Missing"), ("settings","⚙️ Settings"),
    ]
    nav = "".join(
        '<a href="/{k}" class="{cls}">{l}</a>'.format(
            k=k, cls="active" if k==active else "", l=l)
        for k,l in nav_items)
    return (
        "<!DOCTYPE html><html lang='en'><head>"
        "<meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
        f"<title>{title} — Debridarr</title>"
        f"<style>{_CSS}</style></head><body>"
        f"<nav>{nav}</nav>"
        f"<main>{body}</main>"
        "<div id='toast'></div>"
        f"<script>{_TOAST_JS}\n{extra_js}</script>"
        "</body></html>"
    )

def _poster_html(url, icon, w="100%", h=""):
    asp = "aspect-ratio:2/3;"
    s1 = f"width:{w};{('height:'+h+';') if h else ''}{asp}object-fit:cover;display:block"
    s2 = f"width:{w};{('height:'+h+';') if h else ''}{asp}background:#0f0f13;display:none;align-items:center;justify-content:center;font-size:2.5rem"
    s3 = s2.replace("display:none","display:flex")
    if url:
        return (f'<img src="{url}" style="{s1}" loading="lazy"'
                f' onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'flex\'">'
                f'<div style="{s2}">{icon}</div>')
    return f'<div style="{s3}">{icon}</div>'

def _pg_html(total, page, n_pages, per_page, base, pp_opts):
    if n_pages <= 1 and total <= (min(pp_opts) if pp_opts else 1):
        return ""
    def lnk(p, lbl=None):
        cls = ' class="cur"' if p==page else ""
        return f'<a href="{base}&page={p}&per_page={per_page}"{cls}>{lbl or p}</a>'
    parts = []
    if page > 1: parts.append(lnk(page-1, "← Prev"))
    if n_pages <= 7:
        for p in range(1, n_pages+1): parts.append(lnk(p))
    else:
        parts.append(lnk(1))
        if page > 3: parts.append('<span class="dots">…</span>')
        for p in range(max(2,page-1), min(n_pages,page+2)): parts.append(lnk(p))
        if page < n_pages-2: parts.append('<span class="dots">…</span>')
        parts.append(lnk(n_pages))
    if page < n_pages: parts.append(lnk(page+1, "Next →"))
    parts.append(f'<span style="color:#555;font-size:.75rem">{total} total</span>')
    opts = "".join(
        f'<option value="{base}&page=1&per_page={n}" {"selected" if n==per_page else ""}>{n}/page</option>'
        for n in pp_opts)
    parts.append(
        '<select onchange="location.href=this.value" '
        'style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:6px;'
        'padding:5px 10px;color:#aaa;font-size:.78rem;cursor:pointer">'
        + opts + '</select>')
    return '<div class="pg" style="margin:14px 0">' + " ".join(parts) + "</div>"

def _safe_int(v):
    try: return int(v) if v is not None else None
    except: return None

def _needs_setup(cfg=None):
    c = cfg or load_saved_config()
    return not c.get("ALLDEBRID_API_KEY") or not c.get("PLEX_ROOT")
