"""Data models for Debridarr."""

import re
from enum import Enum
from typing import Optional

from pydantic import BaseModel


class MediaType(str, Enum):
    movie = "movie"
    episode = "episode"


class PlayEvent(BaseModel):
    media_type: MediaType
    title: str
    year: Optional[int] = None
    season: Optional[int] = None
    episode: Optional[int] = None
    rating_key: Optional[str] = None
    imdb_id: Optional[str] = None
    tmdb_id: Optional[str] = None
    tvdb_id: Optional[str] = None

    def cache_key(self) -> str:
        """Generate a stable, filesystem-safe cache key for this media item."""
        clean = re.sub(r"[^\w\s]", "", self.title).strip().lower().replace(" ", "_")
        if self.media_type == MediaType.movie:
            year_part = f"_{self.year}" if self.year else ""
            return f"movie_{clean}{year_part}"
        else:
            s = f"_s{self.season:02d}" if self.season else ""
            e = f"e{self.episode:02d}" if self.episode else ""
            return f"episode_{clean}{s}{e}"


class CachedLink(BaseModel):
    cache_key: str
    media_type: MediaType
    title: str
    year: Optional[int] = None
    season: Optional[int] = None
    episode: Optional[int] = None
    quality: str
    torrent_name: str
    stream_url: str
    status: str
    expires_at: str
