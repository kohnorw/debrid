"""Configuration — all settings come from environment variables."""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # AllDebrid
    ALLDEBRID_API_KEY: str = ""

    # Sonarr
    SONARR_URL: str = "http://sonarr:8989"
    SONARR_API_KEY: str = ""

    # Radarr
    RADARR_URL: str = "http://radarr:7878"
    RADARR_API_KEY: str = ""

    # App
    DB_PATH: str = "/data/debridarr.db"
    PORT: int = 7474
    LOG_LEVEL: str = "INFO"
    CACHE_TTL_DAYS: int = 30

    # Plex integration
    # Path that is bind-mounted into BOTH this container AND Plex.
    # Debridarr writes .strm files here; Plex reads them.
    # e.g. /plex/debridarr  →  mounted as /mnt/debridarr in Plex
    PLEX_ROOT: str = ""

    # Base URL this container is reachable at FROM Plex's network.
    # Written into .strm files. Default assumes same Docker network.
    # e.g. http://debridarr:7474  or  http://192.168.1.50:7474
    DEBRIDARR_BASE_URL: str = "http://debridarr:7474"

    model_config = {"env_file": ".env", "extra": "ignore"}


settings = Settings()
