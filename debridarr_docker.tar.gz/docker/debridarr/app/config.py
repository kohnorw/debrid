from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    ALLDEBRID_API_KEY:  str = ""
    OVERSEERR_URL:      str = ""
    OVERSEERR_API_KEY:  str = ""
    DB_PATH:            str = "/data/debridarr.db"
    PORT:               int = 7474
    LOG_LEVEL:          str = "INFO"
    CACHE_TTL_DAYS:     int = 30
    PLEX_ROOT:          str = "/plex-strm"
    DEBRIDARR_BASE_URL: str = ""
    FUSE_MOUNT:         str = "/docker/debridarr/mnt-alldebrid"
    FUSE_SYMLINK_ROOT:  str = "/docker/debridarr/mnt-alldebrid"

    model_config = {"env_file": "/data/.env", "extra": "ignore"}

settings = Settings()
