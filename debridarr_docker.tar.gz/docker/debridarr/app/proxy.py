"""
Streaming proxy for Debridarr.

STRATEGY:
  When a file is cached and stream_url is valid:
    → Return HTTP 302 redirect to the AllDebrid CDN URL.
    Plex follows the redirect and plays the CDN URL directly.
    No proxying, no buffering, seeks work natively.

  When stream_url is stale (>4h old):
    → Re-unlock via /link/unlock to get a fresh CDN URL, then 302.

  When not yet cached (pre-cache off, on-play resolve):
    → Return the fragmented MP4 keepalive stream (fmp4 init + empty moof/mdat
      fragments) to hold Plex's connection open while resolve runs.
    → When cached, stop the keepalive. Plex re-requests, hits the 302 path.

  IMPORTANT: re-unlock uses stream_url (the AllDebrid file link), NOT magnet_link.
    magnet_link = "magnet:?xt=urn:btih:..."  — used to identify the torrent
    stream_url  = "https://alldebrid.com/f/..."  — the file link passed to /link/unlock
    cdn_url     = "https://cdn*.alldebrid.com/..."  — the actual CDN playback URL (expires)

  We store stream_url (stable file link) in the DB.
  _fresh_url calls unlock_magnet(stream_url) to get a fresh cdn_url, then 302 to that.
"""

import asyncio
import logging
import struct
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, AsyncIterator

import httpx
from fastapi import HTTPException, Request
from fastapi.responses import RedirectResponse, StreamingResponse
from starlette.responses import Response

log = logging.getLogger("debridarr.proxy")

RESOLVE_TIMEOUT = 120           # seconds to hold keepalive before giving up
KEEPALIVE_EVERY = 4             # seconds between keepalive fragments
LINK_MAX_AGE    = timedelta(hours=4)

_refresh_locks: dict[str, asyncio.Lock] = {}
_fragment_counter = 0


def _get_lock(key: str) -> asyncio.Lock:
    if key not in _refresh_locks:
        _refresh_locks[key] = asyncio.Lock()
    return _refresh_locks[key]


# ── MP4 keepalive helpers (used when not-yet-cached) ─────────────────────────

def _box(t: bytes, payload: bytes) -> bytes:
    return struct.pack(">I", 8 + len(payload)) + t + payload


def _fmp4_init() -> bytes:
    """ftyp + moov with mvex — tells Plex this is a fragmented/live stream."""
    ftyp = _box(b"ftyp", b"isom\x00\x00\x00\x00isomiso2avc1mp41")
    mvhd = _box(b"mvhd",
        b"\x00\x00\x00\x00" + b"\x00\x00\x00\x00" + b"\x00\x00\x00\x00"
        + struct.pack(">I", 90000) + b"\xff\xff\xff\xff"
        + struct.pack(">I", 0x00010000) + struct.pack(">H", 0x0100)
        + b"\x00" * 10
        + struct.pack(">9i", 0x00010000,0,0, 0,0x00010000,0, 0,0,0x40000000)
        + b"\x00" * 24 + struct.pack(">I", 2)
    )
    tkhd = _box(b"tkhd",
        b"\x00\x00\x00\x03" + b"\x00"*8 + struct.pack(">I", 1)
        + b"\x00"*4 + b"\xff\xff\xff\xff" + b"\x00"*8 + b"\x00"*4
        + struct.pack(">9i", 0x00010000,0,0, 0,0x00010000,0, 0,0,0x40000000)
        + struct.pack(">HH", 1920, 1080) + b"\x00\x00\x00\x00"
    )
    mdhd = _box(b"mdhd",
        b"\x00\x00\x00\x00" + b"\x00"*8
        + struct.pack(">I", 90000) + b"\xff\xff\xff\xff"
        + struct.pack(">H", 0x55C4) + b"\x00\x00"
    )
    hdlr  = _box(b"hdlr", b"\x00"*8 + b"vide" + b"\x00"*12 + b"VideoHandler\x00")
    vmhd  = _box(b"vmhd", b"\x00\x00\x00\x01" + b"\x00"*6)
    url_  = _box(b"url ", b"\x00\x00\x00\x01")
    dinf  = _box(b"dinf", _box(b"dref", b"\x00"*4 + struct.pack(">I",1) + url_))
    avcc  = (b"\x01" + b"\x42\xe0\x1e" + b"\xff\xe1"
             + struct.pack(">H", 0) + b"\x00")
    avc1  = _box(b"avc1",
        b"\x00"*6 + struct.pack(">H", 1) + b"\x00"*16
        + struct.pack(">HH", 1920, 1080)
        + struct.pack(">II", 0x00480000, 0x00480000) + b"\x00"*4
        + struct.pack(">H", 1) + b"\x00"*32
        + struct.pack(">H", 24) + struct.pack(">h", -1)
        + _box(b"avcC", avcc)
    )
    stsd  = _box(b"stsd", b"\x00"*4 + struct.pack(">I", 1) + avc1)
    stts  = _box(b"stts", b"\x00"*4 + b"\x00"*4)
    stsc  = _box(b"stsc", b"\x00"*4 + b"\x00"*4)
    stsz  = _box(b"stsz", b"\x00"*4 + b"\x00"*8)
    stco  = _box(b"stco", b"\x00"*4 + b"\x00"*4)
    stbl  = _box(b"stbl", stsd + stts + stsc + stsz + stco)
    minf  = _box(b"minf", vmhd + dinf + stbl)
    mdia  = _box(b"mdia", mdhd + hdlr + minf)
    trak  = _box(b"trak", tkhd + mdia)
    mehd  = _box(b"mehd", b"\x01\x00\x00\x00" + b"\xff"*8)
    trex  = _box(b"trex", b"\x00"*4 + struct.pack(">IIIII", 1, 1, 0, 0, 0))
    mvex  = _box(b"mvex", mehd + trex)
    moov  = _box(b"moov", mvhd + trak + mvex)
    return ftyp + moov


def _fmp4_keepalive(sequence: int) -> bytes:
    """moof + empty mdat — valid fragment, no samples, resets Plex read timeout."""
    mfhd = _box(b"mfhd", b"\x00"*4 + struct.pack(">I", sequence))
    tfhd = _box(b"tfhd", b"\x00\x02\x00\x00" + struct.pack(">I", 1))
    traf = _box(b"traf", tfhd)
    moof = _box(b"moof", mfhd + traf)
    mdat = _box(b"mdat", b"")
    return moof + mdat


_INIT_SEGMENT = _fmp4_init()


# ── .strm file management ─────────────────────────────────────────────────────

def write_strm(
    cache_key: str, title: str, year: Optional[int],
    season: Optional[int], episode: Optional[int],
    media_type: str, debridarr_base_url: str, plex_root: str,
) -> Optional[Path]:
    if not plex_root:
        return None
    try:
        url = f"{debridarr_base_url.rstrip('/')}/proxy/{cache_key}"
        if media_type == "movie":
            yp   = f" ({year})" if year else ""
            name = f"{title}{yp}"
            path = Path(plex_root) / "movies" / name / f"{name}.strm"
        else:
            sf   = f"Season {season:02d}" if season else "Season 00"
            se   = f"S{season:02d}E{episode:02d}" if (season and episode) else "S00E00"
            path = Path(plex_root) / "tv" / title / sf / f"{title} - {se}.strm"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(url + "\n")
        log.info(f"📄 Wrote .strm → {path}")
        return path
    except Exception as e:
        log.error(f"write_strm {cache_key}: {e}", exc_info=True)
        return None


def delete_strm(
    cache_key: str, title: str, year: Optional[int],
    season: Optional[int], episode: Optional[int],
    media_type: str, plex_root: str,
) -> bool:
    if not plex_root:
        return False
    try:
        if media_type == "movie":
            yp   = f" ({year})" if year else ""
            name = f"{title}{yp}"
            path = Path(plex_root) / "movies" / name / f"{name}.strm"
        else:
            sf   = f"Season {season:02d}" if season else "Season 00"
            se   = f"S{season:02d}E{episode:02d}" if (season and episode) else "S00E00"
            path = Path(plex_root) / "tv" / title / sf / f"{title} - {se}.strm"
        if path.exists():
            path.unlink()
            log.info(f"🗑️  Deleted .strm → {path}")
            _rmdir_if_empty(path.parent)
            _rmdir_if_empty(path.parent.parent)
            return True
    except Exception as e:
        log.warning(f"delete_strm {cache_key}: {e}")
    return False


def _rmdir_if_empty(p: Path):
    try:
        if p.exists() and not any(p.iterdir()):
            p.rmdir()
    except Exception:
        pass


# ── Main proxy endpoint ───────────────────────────────────────────────────────

async def proxy_stream(
    request: Request, cache_key: str, db, alldebrid, app=None,
) -> Response:
    """
    /proxy/<cache_key>

    CACHED:
      Get a fresh CDN URL (re-unlock if >4h old) and return HTTP 302.
      Plex follows the redirect and plays the CDN URL directly.
      Seeks, range requests, and buffering all work natively via the CDN.

    NOT CACHED:
      Fire resolve_and_cache, return fragmented MP4 keepalive stream.
      Plex holds the connection open. When cached, keepalive stops and
      Plex re-requests — hitting the 302 fast path.
    """
    entry = db.get(cache_key)

    # ── Fast path: already cached → redirect to CDN ───────────────────────────
    if entry and entry["status"] == "cached":
        cdn_url = await _fresh_cdn_url(entry, cache_key, db, alldebrid)
        if cdn_url:
            log.info(f"▶️  302 → CDN for {cache_key}")
            return RedirectResponse(url=cdn_url, status_code=302)
        # CDN unlock failed — fall through to proxy stream
        log.warning(f"CDN unlock failed for {cache_key}, falling back to proxy")
        return StreamingResponse(
            _proxy_stream_iter(entry, cache_key, db, alldebrid),
            status_code=200,
            media_type=_content_type(entry.get("torrent_name", "")),
            headers={"Cache-Control": "no-store", "Accept-Ranges": "bytes"},
        )

    # ── Slow path: not cached yet → keepalive while resolving ─────────────────
    if app is None:
        raise HTTPException(503, "App context unavailable")

    if entry is None or entry["status"] in ("not_found", "error"):
        try:
            from app.models import PlayEvent
            from app.main import resolve_and_cache
            event = PlayEvent.from_cache_key(cache_key)
            log.info(f"▶️  On-play resolve: {cache_key} ({event.title!r})")
            asyncio.create_task(resolve_and_cache(app, event))
        except Exception as e:
            log.error(f"Could not start resolve for {cache_key}: {e}")
            raise HTTPException(503, str(e))
    else:
        log.info(f"▶️  Resolve in progress for {cache_key} ({entry['status']})")

    return StreamingResponse(
        _keepalive_stream(cache_key, db),
        status_code=200,
        media_type="video/mp4",
        headers={
            "Cache-Control":          "no-store",
            "Accept-Ranges":          "bytes",
            "Transfer-Encoding":      "chunked",
            "X-Content-Type-Options": "nosniff",
        },
    )


async def _fresh_cdn_url(entry: dict, cache_key: str, db, alldebrid) -> Optional[str]:
    """
    Return a playable CDN URL. Re-unlocks via AllDebrid if the stored URL is stale.

    stream_url = the AllDebrid file link (e.g. https://alldebrid.com/f/abc)
                 passed to /link/unlock → returns a fresh CDN URL
    """
    async with _get_lock(cache_key):
        fresh = db.get(cache_key) or entry
        ts    = fresh.get("link_refreshed_at")

        if ts:
            age = datetime.utcnow() - datetime.fromisoformat(ts)
            if age < LINK_MAX_AGE and fresh.get("stream_url"):
                # Still fresh — but stream_url might be the file link, not CDN URL
                # Unlock it to get the actual CDN URL Plex can play
                pass  # fall through to unlock below

        file_link = fresh.get("stream_url", "")
        if not file_link:
            return None

        try:
            cdn_url = await alldebrid.unlock_magnet(file_link)
            if cdn_url:
                db.update_stream_url(cache_key, file_link)   # keep stable file link in DB
                log.debug(f"Unlocked {cache_key} → {cdn_url[:60]}...")
                return cdn_url
        except Exception as e:
            log.error(f"Unlock failed {cache_key}: {e}")

        return None


async def _keepalive_stream(cache_key: str, db) -> AsyncIterator[bytes]:
    """
    Fragmented MP4 keepalive. Holds Plex's connection open while resolve runs.
    Sends fmp4 init immediately (satisfies response-start timeout), then
    empty moof+mdat fragments every KEEPALIVE_EVERY seconds.
    Stops when cached — Plex re-requests and hits the 302 fast path.
    """
    global _fragment_counter
    yield _INIT_SEGMENT
    log.debug(f"⏳ Keepalive started for {cache_key}")

    elapsed = 0
    while elapsed < RESOLVE_TIMEOUT:
        await asyncio.sleep(KEEPALIVE_EVERY)
        elapsed += KEEPALIVE_EVERY

        entry  = db.get(cache_key)
        status = entry["status"] if entry else "missing"

        if status == "cached":
            log.info(f"✅ Resolved in {elapsed}s — stopping keepalive for {cache_key}")
            return

        if status in ("error", "unlock_failed"):
            log.warning(f"❌ Resolve failed for {cache_key}: {status}")
            return

        _fragment_counter += 1
        yield _fmp4_keepalive(_fragment_counter)
        log.debug(f"⏳ {cache_key}: {status} ({elapsed}s) keepalive #{_fragment_counter}")

    log.warning(f"⏰ Keepalive timed out for {cache_key} after {elapsed}s")


async def _proxy_stream_iter(
    entry: dict, cache_key: str, db, alldebrid,
) -> AsyncIterator[bytes]:
    """Fallback: proxy the stream directly if CDN redirect fails."""
    file_link = entry.get("stream_url", "")
    if not file_link:
        return
    try:
        cdn_url = await alldebrid.unlock_magnet(file_link)
    except Exception:
        cdn_url = None
    url = cdn_url or file_link

    client = httpx.AsyncClient(timeout=None, follow_redirects=True)
    try:
        async with client.stream("GET", url) as r:
            if r.status_code not in (200, 206):
                log.error(f"Proxy fallback HTTP {r.status_code} for {cache_key}")
                return
            async for chunk in r.aiter_bytes(256 * 1024):
                yield chunk
    except Exception as e:
        log.error(f"Proxy fallback failed {cache_key}: {e}")
    finally:
        await client.aclose()


# ── Direct stream endpoint (/stream/<cache_key>) ──────────────────────────────

async def stream_direct(request: Request, cache_key: str, db, alldebrid) -> Response:
    entry = db.get(cache_key)
    if not entry or entry["status"] != "cached":
        raise HTTPException(503, "Not cached yet")
    cdn_url = await _fresh_cdn_url(entry, cache_key, db, alldebrid)
    if cdn_url:
        return RedirectResponse(url=cdn_url, status_code=302)
    raise HTTPException(503, "Could not unlock stream URL")


def _content_type(filename: str) -> str:
    n = filename.lower() if filename else ""
    if n.endswith(".mkv"):            return "video/x-matroska"
    if n.endswith((".mp4", ".m4v")): return "video/mp4"
    if n.endswith(".avi"):            return "video/x-msvideo"
    return "video/mp4"
