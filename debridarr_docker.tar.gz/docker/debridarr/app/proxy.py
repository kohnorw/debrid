"""
Streaming proxy for Debridarr.

Why a proxy instead of a redirect:
  - AllDebrid direct URLs are time-limited (hours, not days).
  - A 302 redirect hands the real URL to Plex. If Plex seeks, resumes,
    or the link expires mid-movie, playback breaks.
  - A proxy keeps ONE stable URL (/proxy/<cache_key>) that Plex always hits.
    We stream bytes through, re-acquiring the AllDebrid URL silently whenever
    it expires. Plex never sees the churn.

Symlink (.strm) strategy:
  - On resolve, we write  <plex_root>/<path>/Title.strm
    containing exactly: http://debridarr:7474/proxy/<cache_key>
  - Plex indexes .strm as a playable item (no re-scan needed after first index).
  - The cache_key never changes, so the .strm file is permanent for 30 days.
  - On cache expiry / purge we delete the .strm so Plex stops showing the item.

Byte-range / seek support:
  - We forward the client's Range header to AllDebrid verbatim.
  - If AllDebrid returns 206 Partial Content, we relay the Content-Range
    and return 206 to Plex so seeking works correctly.
  - On a 403/410 from AllDebrid (expired URL), we silently re-unlock and retry once.
"""

import asyncio
import logging
import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, AsyncIterator

import httpx
from fastapi import HTTPException, Request
from fastapi.responses import StreamingResponse

log = logging.getLogger("debridarr.proxy")

# Re-unlock if the stored URL is older than this
LINK_MAX_AGE = timedelta(hours=4)

# Chunk size for streaming (256 KB)
CHUNK_SIZE = 256 * 1024

# Lock table so two concurrent requests for the same key don't
# both try to re-unlock at the same time
_refresh_locks: dict[str, asyncio.Lock] = {}


def _get_lock(cache_key: str) -> asyncio.Lock:
    if cache_key not in _refresh_locks:
        _refresh_locks[cache_key] = asyncio.Lock()
    return _refresh_locks[cache_key]


# ─────────────────────────────────────────────────────────────────────────────
# .strm file management
# ─────────────────────────────────────────────────────────────────────────────

def write_strm(
    cache_key: str,
    title: str,
    year: Optional[int],
    season: Optional[int],
    episode: Optional[int],
    media_type: str,
    debridarr_base_url: str,
    plex_root: str,
) -> Optional[Path]:
    """
    Write a .strm file into the Plex library path.
    Returns the path written, or None if plex_root is not configured.

    Directory layout:
      Movies:   <plex_root>/movies/<Title> (<Year>)/<Title> (<Year>).strm
      TV:       <plex_root>/tv/<Title>/Season <N>/<Title> - S<N>E<M>.strm

    The .strm content is a single line:
      http://debridarr:7474/proxy/<cache_key>
    """
    if not plex_root:
        return None

    try:
        proxy_url = f"{debridarr_base_url.rstrip('/')}/proxy/{cache_key}"

        if media_type == "movie":
            year_part = f" ({year})" if year else ""
            folder_name = f"{title}{year_part}"
            file_name = f"{folder_name}.strm"
            strm_path = Path(plex_root) / "movies" / folder_name / file_name
        else:
            s_str = f"S{season:02d}" if season else "S00"
            e_str = f"E{episode:02d}" if episode else "E00"
            season_folder = f"Season {season:02d}" if season else "Season 00"
            file_name = f"{title} - {s_str}{e_str}.strm"
            strm_path = Path(plex_root) / "tv" / title / season_folder / file_name

        strm_path.parent.mkdir(parents=True, exist_ok=True)
        strm_path.write_text(proxy_url + "\n")
        log.info(f"📄 Wrote .strm → {strm_path}")
        return strm_path

    except Exception as e:
        log.error(f"Failed to write .strm for {cache_key}: {e}", exc_info=True)
        return None


def delete_strm(
    cache_key: str,
    title: str,
    year: Optional[int],
    season: Optional[int],
    episode: Optional[int],
    media_type: str,
    plex_root: str,
) -> bool:
    """Remove the .strm file when a cache entry expires or is manually deleted."""
    if not plex_root:
        return False

    try:
        if media_type == "movie":
            year_part = f" ({year})" if year else ""
            folder_name = f"{title}{year_part}"
            strm_path = Path(plex_root) / "movies" / folder_name / f"{folder_name}.strm"
        else:
            s_str = f"S{season:02d}" if season else "S00"
            e_str = f"E{episode:02d}" if episode else "E00"
            season_folder = f"Season {season:02d}" if season else "Season 00"
            strm_path = Path(plex_root) / "tv" / title / season_folder / f"{title} - {s_str}{e_str}.strm"

        if strm_path.exists():
            strm_path.unlink()
            log.info(f"🗑️  Deleted .strm → {strm_path}")
            # Remove empty parent dirs (season folder, show folder)
            _rmdir_if_empty(strm_path.parent)
            _rmdir_if_empty(strm_path.parent.parent)
            return True
    except Exception as e:
        log.warning(f"Failed to delete .strm for {cache_key}: {e}")

    return False


def _rmdir_if_empty(path: Path):
    try:
        if path.exists() and not any(path.iterdir()):
            path.rmdir()
    except Exception:
        pass


# ─────────────────────────────────────────────────────────────────────────────
# Proxy stream handler
# ─────────────────────────────────────────────────────────────────────────────

async def proxy_stream(request: Request, cache_key: str, db, alldebrid) -> StreamingResponse:
    """
    Core proxy: stream bytes from AllDebrid to Plex.
    Handles:
      - Range requests (seeking)
      - Transparent URL re-acquisition on expiry
      - One retry per expired URL
    """
    entry = db.get(cache_key)
    if not entry:
        raise HTTPException(status_code=404, detail=f"No cached entry for {cache_key}")
    if entry["status"] != "cached":
        raise HTTPException(status_code=202, detail="Media not yet resolved")

    stream_url = await _get_fresh_url(entry, cache_key, db, alldebrid)

    # Forward Range header from Plex so seeking works
    headers = {}
    range_header = request.headers.get("range")
    if range_header:
        headers["Range"] = range_header

    return StreamingResponse(
        _stream_with_retry(stream_url, headers, cache_key, entry, db, alldebrid),
        status_code=206 if range_header else 200,
        media_type=_guess_content_type(entry.get("torrent_name", "")),
        headers=_build_response_headers(entry),
    )


async def _get_fresh_url(entry: dict, cache_key: str, db, alldebrid) -> str:
    """Return a fresh AllDebrid URL, re-unlocking if stale. Thread-safe per cache_key."""
    lock = _get_lock(cache_key)
    async with lock:
        # Re-read after acquiring lock (another coroutine may have refreshed)
        fresh_entry = db.get(cache_key) or entry
        refreshed_at = fresh_entry.get("link_refreshed_at")

        if refreshed_at:
            age = datetime.utcnow() - datetime.fromisoformat(refreshed_at)
            if age < LINK_MAX_AGE:
                return fresh_entry["stream_url"]

        log.info(f"🔄 Re-unlocking URL for {cache_key} (age > {LINK_MAX_AGE})")
        try:
            new_url = await alldebrid.unlock_magnet(fresh_entry["magnet_link"])
            if new_url:
                db.update_stream_url(cache_key, new_url)
                return new_url
            else:
                log.warning(f"Re-unlock returned no URL for {cache_key}, using stale URL")
                return fresh_entry["stream_url"]
        except Exception as e:
            log.error(f"Re-unlock failed for {cache_key}: {e}")
            return fresh_entry["stream_url"]


async def _stream_with_retry(
    stream_url: str,
    headers: dict,
    cache_key: str,
    entry: dict,
    db,
    alldebrid,
) -> AsyncIterator[bytes]:
    """
    Stream bytes from AllDebrid. On 403/410/416 (expired/bad URL),
    re-unlock once and retry the stream from the beginning of the range.
    """
    client = httpx.AsyncClient(timeout=None, follow_redirects=True)
    retried = False

    try:
        while True:
            try:
                async with client.stream("GET", stream_url, headers=headers) as resp:
                    if resp.status_code in (403, 410) and not retried:
                        log.warning(
                            f"AllDebrid returned {resp.status_code} for {cache_key}, "
                            f"re-unlocking and retrying..."
                        )
                        retried = True
                        # Force re-unlock
                        new_url = await alldebrid.unlock_magnet(entry["magnet_link"])
                        if new_url:
                            db.update_stream_url(cache_key, new_url)
                            stream_url = new_url
                        continue

                    if resp.status_code not in (200, 206):
                        log.error(
                            f"AllDebrid stream returned unexpected status {resp.status_code} "
                            f"for {cache_key}"
                        )
                        return

                    async for chunk in resp.aiter_bytes(chunk_size=CHUNK_SIZE):
                        yield chunk
                    return  # done

            except (httpx.RemoteProtocolError, httpx.ReadError) as e:
                if not retried:
                    log.warning(f"Stream interrupted for {cache_key}: {e}, retrying with fresh URL")
                    retried = True
                    new_url = await alldebrid.unlock_magnet(entry["magnet_link"])
                    if new_url:
                        db.update_stream_url(cache_key, new_url)
                        stream_url = new_url
                    continue
                log.error(f"Stream failed for {cache_key} after retry: {e}")
                return
    finally:
        await client.aclose()


def _guess_content_type(filename: str) -> str:
    name = filename.lower()
    if name.endswith(".mkv"):
        return "video/x-matroska"
    if name.endswith(".mp4") or name.endswith(".m4v"):
        return "video/mp4"
    if name.endswith(".avi"):
        return "video/x-msvideo"
    return "video/mp4"  # safe default; Plex ignores this anyway


def _build_response_headers(entry: dict) -> dict:
    headers = {}
    torrent_name = entry.get("torrent_name", "")
    if torrent_name:
        # Suggest filename to Plex
        safe_name = torrent_name.replace('"', "")
        headers["Content-Disposition"] = f'inline; filename="{safe_name}"'
    # Allow Plex to cache aggressively
    headers["Cache-Control"] = "no-store"
    headers["Accept-Ranges"] = "bytes"
    return headers
