"""
Streaming proxy for Debridarr.

/proxy/<cache_key> — called by Plex when it opens a .strm file.

CACHED:
  Stream immediately with range-request support.

NOT CACHED:
  1. Fire resolve_and_cache as a background task
  2. Block the HTTP connection by sleeping in a loop (up to RESOLVE_TIMEOUT)
  3. The moment the DB shows status='cached', start streaming real video bytes
  4. If the timeout expires or resolve fails, return an empty 503 body

Plex holds the connection open while we sleep — it shows a loading spinner
exactly like any slow streaming service. No s1001, no error dialog.
"""

import asyncio
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, AsyncIterator

import httpx
from fastapi import HTTPException, Request
from fastapi.responses import StreamingResponse
from starlette.responses import Response

log = logging.getLogger("debridarr.proxy")

RESOLVE_TIMEOUT = 120           # seconds to block before giving up
POLL_INTERVAL   = 2             # seconds between DB status checks
CHUNK_SIZE      = 256 * 1024    # 256 KB per streaming chunk
LINK_MAX_AGE    = timedelta(hours=4)

_refresh_locks: dict[str, asyncio.Lock] = {}


def _get_lock(key: str) -> asyncio.Lock:
    if key not in _refresh_locks:
        _refresh_locks[key] = asyncio.Lock()
    return _refresh_locks[key]


# ── .strm helpers ─────────────────────────────────────────────────────────────

def write_strm(
    cache_key: str, title: str, year: Optional[int],
    season: Optional[int], episode: Optional[int],
    media_type: str, debridarr_base_url: str, plex_root: str,
) -> Optional[Path]:
    if not plex_root:
        return None
    try:
        url = f"{debridarr_base_url.rstrip('/')}/proxy/{cache_key}"
        if media_type == "movie":
            yp   = f" ({year})" if year else ""
            name = f"{title}{yp}"
            path = Path(plex_root) / "movies" / name / f"{name}.strm"
        else:
            sf   = f"Season {season:02d}" if season else "Season 00"
            se   = f"S{season:02d}E{episode:02d}" if (season and episode) else "S00E00"
            path = Path(plex_root) / "tv" / title / sf / f"{title} - {se}.strm"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(url + "\n")
        log.info(f"📄 Wrote .strm → {path}")
        return path
    except Exception as e:
        log.error(f"write_strm {cache_key}: {e}", exc_info=True)
        return None


def delete_strm(
    cache_key: str, title: str, year: Optional[int],
    season: Optional[int], episode: Optional[int],
    media_type: str, plex_root: str,
) -> bool:
    if not plex_root:
        return False
    try:
        if media_type == "movie":
            yp   = f" ({year})" if year else ""
            name = f"{title}{yp}"
            path = Path(plex_root) / "movies" / name / f"{name}.strm"
        else:
            sf   = f"Season {season:02d}" if season else "Season 00"
            se   = f"S{season:02d}E{episode:02d}" if (season and episode) else "S00E00"
            path = Path(plex_root) / "tv" / title / sf / f"{title} - {se}.strm"
        if path.exists():
            path.unlink()
            log.info(f"🗑️  Deleted .strm → {path}")
            _rmdir_if_empty(path.parent)
            _rmdir_if_empty(path.parent.parent)
            return True
    except Exception as e:
        log.warning(f"delete_strm {cache_key}: {e}")
    return False


def _rmdir_if_empty(p: Path):
    try:
        if p.exists() and not any(p.iterdir()):
            p.rmdir()
    except Exception:
        pass


# ── Proxy endpoint ────────────────────────────────────────────────────────────

async def proxy_stream(
    request: Request, cache_key: str, db, alldebrid, app=None,
) -> Response:
    """
    Main handler for /proxy/<cache_key>.

    Already cached → stream immediately.
    Not cached     → block up to RESOLVE_TIMEOUT seconds then stream.
    """
    entry = db.get(cache_key)

    # Fast path — already cached
    if entry and entry["status"] == "cached":
        return _make_stream_response(request, cache_key, entry, db, alldebrid)

    # Slow path — trigger resolve and block
    if app is None:
        raise HTTPException(503, "App context unavailable")

    if entry is None or entry["status"] in ("not_found", "error"):
        try:
            from app.models import PlayEvent
            from app.main import resolve_and_cache
            event = PlayEvent.from_cache_key(cache_key)
            log.info(f"▶️  Blocking for resolve: {cache_key} ({event.title!r})")
            asyncio.create_task(resolve_and_cache(app, event))
        except Exception as e:
            log.error(f"resolve_and_cache failed to start for {cache_key}: {e}")
            raise HTTPException(503, str(e))
    else:
        log.info(f"▶️  Blocking — resolve already running: {cache_key} ({entry['status']})")

    range_hdr = request.headers.get("range")
    return StreamingResponse(
        _block_then_stream(cache_key, db, alldebrid, range_hdr),
        status_code=206 if range_hdr else 200,
        media_type="video/mp4",
        headers={"Cache-Control": "no-store", "Accept-Ranges": "bytes"},
    )


async def _block_then_stream(
    cache_key: str, db, alldebrid, range_hdr: Optional[str],
) -> AsyncIterator[bytes]:
    """
    Sleep in POLL_INTERVAL increments until the entry is cached or we time out.
    Yields nothing while waiting — Plex holds the connection open (loading spinner).
    Once cached, yields real video bytes without any redirect or gap.
    """
    elapsed = 0
    while elapsed < RESOLVE_TIMEOUT:
        await asyncio.sleep(POLL_INTERVAL)
        elapsed += POLL_INTERVAL

        entry  = db.get(cache_key)
        status = entry["status"] if entry else "missing"
        log.debug(f"⏳ {cache_key}: {status} ({elapsed}s / {RESOLVE_TIMEOUT}s)")

        if status == "cached":
            log.info(f"✅ Resolve done in {elapsed}s — streaming {cache_key}")
            stream_url = await _fresh_url(entry, cache_key, db, alldebrid)
            headers    = {"Range": range_hdr} if range_hdr else {}
            async for chunk in _fetch(stream_url, headers, cache_key, entry, db, alldebrid):
                yield chunk
            return

        if status in ("error", "unlock_failed"):
            log.warning(f"❌ Resolve failed for {cache_key}: {status}")
            return   # empty body → Plex shows error (resolve actually failed)

    log.warning(f"⏰ Timed out waiting for {cache_key} after {elapsed}s")
    # empty body after timeout → Plex shows error


# ── Direct stream endpoint (/stream/<cache_key>) ──────────────────────────────

async def stream_direct(request: Request, cache_key: str, db, alldebrid) -> Response:
    entry = db.get(cache_key)
    if not entry or entry["status"] != "cached":
        raise HTTPException(503, "Not cached yet")
    return _make_stream_response(request, cache_key, entry, db, alldebrid)


# ── Internal helpers ──────────────────────────────────────────────────────────

def _make_stream_response(request, cache_key, entry, db, alldebrid) -> StreamingResponse:
    range_hdr = request.headers.get("range")
    headers   = {"Range": range_hdr} if range_hdr else {}
    return StreamingResponse(
        _stream_entry(cache_key, entry, db, alldebrid, headers),
        status_code=206 if range_hdr else 200,
        media_type=_content_type(entry.get("torrent_name", "")),
        headers=_response_headers(entry),
    )


async def _stream_entry(cache_key, entry, db, alldebrid, headers) -> AsyncIterator[bytes]:
    url = await _fresh_url(entry, cache_key, db, alldebrid)
    async for chunk in _fetch(url, headers, cache_key, entry, db, alldebrid):
        yield chunk


async def _fresh_url(entry: dict, cache_key: str, db, alldebrid) -> str:
    """Return a valid AllDebrid CDN URL, re-unlocking if older than LINK_MAX_AGE."""
    async with _get_lock(cache_key):
        fresh = db.get(cache_key) or entry
        ts    = fresh.get("link_refreshed_at")
        if ts and (datetime.utcnow() - datetime.fromisoformat(ts)) < LINK_MAX_AGE:
            return fresh["stream_url"]
        log.info(f"🔄 Re-unlocking {cache_key}")
        try:
            new = await alldebrid.unlock_magnet(fresh["magnet_link"])
            if new:
                db.update_stream_url(cache_key, new)
                return new
        except Exception as e:
            log.error(f"Re-unlock failed {cache_key}: {e}")
        return fresh["stream_url"]


async def _fetch(
    url: str, headers: dict, cache_key: str, entry: dict, db, alldebrid,
) -> AsyncIterator[bytes]:
    """Fetch from AllDebrid CDN, retrying once on 403/410 or connection error."""
    client  = httpx.AsyncClient(timeout=None, follow_redirects=True)
    retried = False
    try:
        while True:
            try:
                async with client.stream("GET", url, headers=headers) as r:
                    if r.status_code in (403, 410) and not retried:
                        retried = True
                        new = await alldebrid.unlock_magnet(entry["magnet_link"])
                        if new:
                            db.update_stream_url(cache_key, new)
                            url = new
                        continue
                    if r.status_code not in (200, 206):
                        log.error(f"CDN HTTP {r.status_code} for {cache_key}")
                        return
                    async for chunk in r.aiter_bytes(CHUNK_SIZE):
                        yield chunk
                    return
            except (httpx.RemoteProtocolError, httpx.ReadError) as e:
                if not retried:
                    retried = True
                    log.warning(f"Stream error {cache_key}: {e} — retrying")
                    new = await alldebrid.unlock_magnet(entry["magnet_link"])
                    if new:
                        db.update_stream_url(cache_key, new)
                        url = new
                    continue
                log.error(f"Stream failed {cache_key}: {e}")
                return
    finally:
        await client.aclose()


def _content_type(filename: str) -> str:
    n = filename.lower()
    if n.endswith(".mkv"):            return "video/x-matroska"
    if n.endswith((".mp4", ".m4v")): return "video/mp4"
    if n.endswith(".avi"):            return "video/x-msvideo"
    return "video/mp4"


def _response_headers(entry: dict) -> dict:
    h = {"Cache-Control": "no-store", "Accept-Ranges": "bytes"}
    name = entry.get("torrent_name", "")
    if name:
        h["Content-Disposition"] = f'inline; filename="{name.replace(chr(34), "")}"'
    return h
