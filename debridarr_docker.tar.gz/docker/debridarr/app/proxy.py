"""
Streaming proxy for Debridarr.

HOW WE KEEP PLEX WAITING WITHOUT s1001:

Plex has two independent timeouts on .strm URLs:
  1. Response-start timeout (~10s): fires if no bytes arrive at all.
  2. Read timeout: reset on every byte received.

Previous attempts:
  - Silent blocking (no yield)    → hits timeout #1
  - Null bytes after MP4 header   → Plex rejects invalid stream data

The solution: fragmented MP4 streaming.

  Init segment (ftyp + moov with mvex):
    Tells Plex "this is a fragmented/live MP4 stream — wait for moof+mdat
    fragments". Sent immediately, satisfies timeout #1.

  Keepalive fragments (moof + empty mdat):
    A minimal valid MP4 fragment with no sample data. Plex accepts these,
    buffers nothing, and resets timeout #2. Sent every KEEPALIVE_EVERY seconds.

  When resolve finishes:
    Generator returns. Plex sees stream end, re-requests the .strm URL,
    and hits the fast-path which streams the real video immediately.
"""

import asyncio
import logging
import struct
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, AsyncIterator

import httpx
from fastapi import HTTPException, Request
from fastapi.responses import StreamingResponse
from starlette.responses import Response

log = logging.getLogger("debridarr.proxy")

RESOLVE_TIMEOUT = 120           # seconds to wait before giving up
KEEPALIVE_EVERY = 4             # seconds between keepalive fragments
CHUNK_SIZE      = 256 * 1024    # 256 KB per real video chunk
LINK_MAX_AGE    = timedelta(hours=4)

_refresh_locks: dict[str, asyncio.Lock] = {}

_fragment_counter = 0           # global moof sequence number


def _get_lock(key: str) -> asyncio.Lock:
    if key not in _refresh_locks:
        _refresh_locks[key] = asyncio.Lock()
    return _refresh_locks[key]


# ── MP4 helpers ───────────────────────────────────────────────────────────────

def _box(t: bytes, payload: bytes) -> bytes:
    return struct.pack(">I", 8 + len(payload)) + t + payload


def _fmp4_init() -> bytes:
    """
    Fragmented MP4 init segment: ftyp + moov.

    The moov declares:
      - One H.264 video track (1920x1080, timescale=90000)
      - mvex/trex: signals this is a fragmented stream
    Plex sees this and waits indefinitely for moof+mdat fragments.
    """
    ftyp = _box(b"ftyp", b"isom\x00\x00\x00\x00isomiso2avc1mp41")

    mvhd = _box(b"mvhd",
        b"\x00\x00\x00\x00"                     # version+flags
        + b"\x00\x00\x00\x00"                   # creation
        + b"\x00\x00\x00\x00"                   # modification
        + struct.pack(">I", 90000)               # timescale
        + b"\xff\xff\xff\xff"                    # duration unknown
        + struct.pack(">I", 0x00010000)          # rate 1.0
        + struct.pack(">H", 0x0100)              # volume 1.0
        + b"\x00" * 10                           # reserved
        + struct.pack(">9i", 0x00010000,0,0, 0,0x00010000,0, 0,0,0x40000000)
        + b"\x00" * 24                           # pre-defined
        + struct.pack(">I", 2)                   # next track id
    )

    tkhd = _box(b"tkhd",
        b"\x00\x00\x00\x03"                     # version=0, flags=track enabled+in movie
        + b"\x00\x00\x00\x00"                   # creation
        + b"\x00\x00\x00\x00"                   # modification
        + struct.pack(">I", 1)                   # track id = 1
        + b"\x00\x00\x00\x00"                   # reserved
        + b"\xff\xff\xff\xff"                    # duration unknown
        + b"\x00" * 8                            # reserved
        + b"\x00\x00"                            # layer
        + b"\x00\x00"                            # alternate group
        + b"\x00\x00"                            # volume (video has 0)
        + b"\x00\x00"                            # reserved
        + struct.pack(">9i", 0x00010000,0,0, 0,0x00010000,0, 0,0,0x40000000)
        + struct.pack(">HH", 1920, 1080)         # width, height (integer part only)
        + b"\x00\x00\x00\x00"                   # fractional part
    )

    mdhd = _box(b"mdhd",
        b"\x00\x00\x00\x00"
        + b"\x00\x00\x00\x00"
        + b"\x00\x00\x00\x00"
        + struct.pack(">I", 90000)               # timescale
        + b"\xff\xff\xff\xff"                    # duration unknown
        + struct.pack(">H", 0x55C4)              # language 'und'
        + b"\x00\x00"
    )

    hdlr = _box(b"hdlr",
        b"\x00\x00\x00\x00"
        + b"\x00\x00\x00\x00"                   # pre-defined
        + b"vide"
        + b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
        + b"VideoHandler\x00"
    )

    vmhd = _box(b"vmhd", b"\x00\x00\x00\x01" + b"\x00\x00\x00\x00\x00\x00")
    url  = _box(b"url ", b"\x00\x00\x00\x01")
    dref = _box(b"dref", b"\x00\x00\x00\x00" + struct.pack(">I", 1) + url)
    dinf = _box(b"dinf", dref)

    # avcC: minimal H.264 decoder config — no actual SPS/PPS needed for Plex to accept
    avcc = _box(b"avcC",
        b"\x01"                                  # configurationVersion
        + b"\x42\xe0\x1e"                        # profile/compat/level = Baseline 3.0
        + b"\xff"                                # lengthSizeMinusOne = 3
        + b"\xe1"                                # numSPS = 1
        + struct.pack(">H", 0)                   # SPS NALU length = 0
        + b"\x00"                                # numPPS = 0
    )
    avc1 = _box(b"avc1",
        b"\x00\x00\x00\x00\x00\x00"             # reserved
        + struct.pack(">H", 1)                   # data ref index
        + b"\x00" * 16                           # reserved
        + struct.pack(">HH", 1920, 1080)         # width, height
        + struct.pack(">II", 0x00480000, 0x00480000)  # hRes, vRes
        + b"\x00\x00\x00\x00"                   # reserved
        + struct.pack(">H", 1)                   # frame count
        + b"\x00" * 32                           # compressor name
        + struct.pack(">H", 24)                  # depth
        + struct.pack(">h", -1)                  # pre-defined
        + avcc
    )

    stsd = _box(b"stsd", b"\x00\x00\x00\x00" + struct.pack(">I", 1) + avc1)
    stts = _box(b"stts", b"\x00\x00\x00\x00" + b"\x00\x00\x00\x00")
    stsc = _box(b"stsc", b"\x00\x00\x00\x00" + b"\x00\x00\x00\x00")
    stsz = _box(b"stsz", b"\x00\x00\x00\x00" * 3)
    stco = _box(b"stco", b"\x00\x00\x00\x00" + b"\x00\x00\x00\x00")
    stbl = _box(b"stbl", stsd + stts + stsc + stsz + stco)
    minf = _box(b"minf", vmhd + dinf + stbl)
    mdia = _box(b"mdia", mdhd + hdlr + minf)
    trak = _box(b"trak", tkhd + mdia)

    # mvex: declares this moov as the init segment of a fragmented stream
    mehd = _box(b"mehd",
        b"\x01\x00\x00\x00"                     # version=1
        + b"\xff\xff\xff\xff\xff\xff\xff\xff"    # fragment_duration unknown
    )
    trex = _box(b"trex",
        b"\x00\x00\x00\x00"
        + struct.pack(">I", 1)                   # track id
        + struct.pack(">IIII", 1, 0, 0, 0)       # defaults
    )
    mvex = _box(b"mvex", mehd + trex)
    moov = _box(b"moov", mvhd + trak + mvex)

    return ftyp + moov


def _fmp4_keepalive(sequence: int) -> bytes:
    """
    Minimal valid fmp4 fragment: moof + empty mdat.
    Contains no sample data — Plex accepts it, buffers nothing,
    and resets its read timeout.
    """
    mfhd = _box(b"mfhd",
        b"\x00\x00\x00\x00"                     # version+flags
        + struct.pack(">I", sequence)            # sequence number
    )
    # tf_flags = 0x020000 (default-base-is-moof)
    tfhd = _box(b"tfhd",
        b"\x00\x02\x00\x00"                     # flags
        + struct.pack(">I", 1)                   # track id
    )
    traf = _box(b"traf", tfhd)
    moof = _box(b"moof", mfhd + traf)
    mdat = _box(b"mdat", b"")
    return moof + mdat


# Pre-build the init segment once at import time
_INIT_SEGMENT = _fmp4_init()


# ── .strm file management ─────────────────────────────────────────────────────

def write_strm(
    cache_key: str, title: str, year: Optional[int],
    season: Optional[int], episode: Optional[int],
    media_type: str, debridarr_base_url: str, plex_root: str,
) -> Optional[Path]:
    if not plex_root:
        return None
    try:
        url = f"{debridarr_base_url.rstrip('/')}/proxy/{cache_key}"
        if media_type == "movie":
            yp   = f" ({year})" if year else ""
            name = f"{title}{yp}"
            path = Path(plex_root) / "movies" / name / f"{name}.strm"
        else:
            sf   = f"Season {season:02d}" if season else "Season 00"
            se   = f"S{season:02d}E{episode:02d}" if (season and episode) else "S00E00"
            path = Path(plex_root) / "tv" / title / sf / f"{title} - {se}.strm"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(url + "\n")
        log.info(f"📄 Wrote .strm → {path}")
        return path
    except Exception as e:
        log.error(f"write_strm {cache_key}: {e}", exc_info=True)
        return None


def delete_strm(
    cache_key: str, title: str, year: Optional[int],
    season: Optional[int], episode: Optional[int],
    media_type: str, plex_root: str,
) -> bool:
    if not plex_root:
        return False
    try:
        if media_type == "movie":
            yp   = f" ({year})" if year else ""
            name = f"{title}{yp}"
            path = Path(plex_root) / "movies" / name / f"{name}.strm"
        else:
            sf   = f"Season {season:02d}" if season else "Season 00"
            se   = f"S{season:02d}E{episode:02d}" if (season and episode) else "S00E00"
            path = Path(plex_root) / "tv" / title / sf / f"{title} - {se}.strm"
        if path.exists():
            path.unlink()
            log.info(f"🗑️  Deleted .strm → {path}")
            _rmdir_if_empty(path.parent)
            _rmdir_if_empty(path.parent.parent)
            return True
    except Exception as e:
        log.warning(f"delete_strm {cache_key}: {e}")
    return False


def _rmdir_if_empty(p: Path):
    try:
        if p.exists() and not any(p.iterdir()):
            p.rmdir()
    except Exception:
        pass


# ── Main proxy endpoint ───────────────────────────────────────────────────────

async def proxy_stream(
    request: Request, cache_key: str, db, alldebrid, app=None,
) -> Response:
    entry = db.get(cache_key)

    # Fast path — already cached
    if entry and entry["status"] == "cached":
        return _make_stream_response(request, cache_key, entry, db, alldebrid)

    # Slow path — trigger resolve then stream keepalive fragments
    if app is None:
        raise HTTPException(503, "App context unavailable")

    if entry is None or entry["status"] in ("not_found", "error"):
        try:
            from app.models import PlayEvent
            from app.main import resolve_and_cache
            event = PlayEvent.from_cache_key(cache_key)
            log.info(f"▶️  On-play resolve: {cache_key} ({event.title!r})")
            asyncio.create_task(resolve_and_cache(app, event))
        except Exception as e:
            log.error(f"Could not start resolve for {cache_key}: {e}")
            raise HTTPException(503, str(e))
    else:
        log.info(f"▶️  Waiting for in-progress resolve: {cache_key} ({entry['status']})")

    return StreamingResponse(
        _keepalive_stream(cache_key, db),
        status_code=200,
        media_type="video/mp4",
        headers={
            "Cache-Control":              "no-store",
            "Accept-Ranges":              "bytes",
            "Transfer-Encoding":          "chunked",
            "X-Content-Type-Options":     "nosniff",
        },
    )


async def _keepalive_stream(cache_key: str, db) -> AsyncIterator[bytes]:
    """
    Fragmented MP4 keepalive stream.

    1. Send ftyp + moov (with mvex) immediately — Plex sees a valid
       fragmented MP4 stream declaration and waits for fragments.
    2. Every KEEPALIVE_EVERY seconds send moof + empty mdat — a valid
       fragment with no sample data. Plex accepts it and resets its
       read timeout.
    3. When the entry is cached, return cleanly. Plex re-requests the
       .strm URL and hits the fast-path which streams the real video.
    """
    global _fragment_counter

    # Immediately send the fmp4 init segment
    yield _INIT_SEGMENT
    log.debug(f"⏳ Sent fmp4 init segment for {cache_key} ({len(_INIT_SEGMENT)} bytes)")

    elapsed = 0
    while elapsed < RESOLVE_TIMEOUT:
        await asyncio.sleep(KEEPALIVE_EVERY)
        elapsed += KEEPALIVE_EVERY

        entry  = db.get(cache_key)
        status = entry["status"] if entry else "missing"

        if status == "cached":
            log.info(f"✅ Resolved after {elapsed}s — ending keepalive for {cache_key}")
            return  # Plex re-requests .strm, hits fast-path

        if status in ("error", "unlock_failed"):
            log.warning(f"❌ Resolve failed for {cache_key}: {status}")
            return

        # Send a keepalive fragment
        _fragment_counter += 1
        yield _fmp4_keepalive(_fragment_counter)
        log.debug(f"⏳ {cache_key}: {status} ({elapsed}s) — sent keepalive fragment #{_fragment_counter}")

    log.warning(f"⏰ Keepalive timed out for {cache_key} after {elapsed}s")


# ── Direct stream endpoint (/stream/<cache_key>) ──────────────────────────────

async def stream_direct(request: Request, cache_key: str, db, alldebrid) -> Response:
    entry = db.get(cache_key)
    if not entry or entry["status"] != "cached":
        raise HTTPException(503, "Not cached yet")
    return _make_stream_response(request, cache_key, entry, db, alldebrid)


# ── Streaming helpers ─────────────────────────────────────────────────────────

def _make_stream_response(request, cache_key, entry, db, alldebrid) -> StreamingResponse:
    range_hdr = request.headers.get("range")
    headers   = {"Range": range_hdr} if range_hdr else {}
    return StreamingResponse(
        _stream_entry(cache_key, entry, db, alldebrid, headers),
        status_code=206 if range_hdr else 200,
        media_type=_content_type(entry.get("torrent_name", "")),
        headers=_response_headers(entry),
    )


async def _stream_entry(cache_key, entry, db, alldebrid, headers) -> AsyncIterator[bytes]:
    url = await _fresh_url(entry, cache_key, db, alldebrid)
    async for chunk in _fetch(url, headers, cache_key, entry, db, alldebrid):
        yield chunk


async def _fresh_url(entry: dict, cache_key: str, db, alldebrid) -> str:
    async with _get_lock(cache_key):
        fresh = db.get(cache_key) or entry
        ts    = fresh.get("link_refreshed_at")
        if ts and (datetime.utcnow() - datetime.fromisoformat(ts)) < LINK_MAX_AGE:
            return fresh["stream_url"]
        log.info(f"🔄 Re-unlocking {cache_key}")
        try:
            new = await alldebrid.unlock_magnet(fresh["magnet_link"])
            if new:
                db.update_stream_url(cache_key, new)
                return new
        except Exception as e:
            log.error(f"Re-unlock failed {cache_key}: {e}")
        return fresh["stream_url"]


async def _fetch(
    url: str, headers: dict, cache_key: str, entry: dict, db, alldebrid,
) -> AsyncIterator[bytes]:
    client  = httpx.AsyncClient(timeout=None, follow_redirects=True)
    retried = False
    try:
        while True:
            try:
                async with client.stream("GET", url, headers=headers) as r:
                    if r.status_code in (403, 410) and not retried:
                        retried = True
                        new = await alldebrid.unlock_magnet(entry["magnet_link"])
                        if new:
                            db.update_stream_url(cache_key, new)
                            url = new
                        continue
                    if r.status_code not in (200, 206):
                        log.error(f"CDN HTTP {r.status_code} for {cache_key}")
                        return
                    async for chunk in r.aiter_bytes(CHUNK_SIZE):
                        yield chunk
                    return
            except (httpx.RemoteProtocolError, httpx.ReadError) as e:
                if not retried:
                    retried = True
                    log.warning(f"Stream interrupted {cache_key}: {e} — retrying")
                    new = await alldebrid.unlock_magnet(entry["magnet_link"])
                    if new:
                        db.update_stream_url(cache_key, new)
                        url = new
                    continue
                log.error(f"Stream failed {cache_key}: {e}")
                return
    finally:
        await client.aclose()


def _content_type(filename: str) -> str:
    n = filename.lower()
    if n.endswith(".mkv"):            return "video/x-matroska"
    if n.endswith((".mp4", ".m4v")): return "video/mp4"
    if n.endswith(".avi"):            return "video/x-msvideo"
    return "video/mp4"


def _response_headers(entry: dict) -> dict:
    h = {"Cache-Control": "no-store", "Accept-Ranges": "bytes"}
    name = entry.get("torrent_name", "")
    if name:
        h["Content-Disposition"] = f'inline; filename="{name.replace(chr(34), "")}"'
    return h
