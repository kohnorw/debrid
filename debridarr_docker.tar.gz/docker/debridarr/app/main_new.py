"""Debridarr — On-the-fly AllDebrid streaming for Plex"""

import asyncio, logging, re, shutil, sys
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from app.alldebrid import AllDebridClient
from app.cache import CacheDB
from app.config import settings
from app.library import LibraryManager, _FAKE_MP4
from app.models import MediaType, PlayEvent
from app.proxy import proxy_stream, write_strm
from app.workers import WorkerPool, get_pool, init_pool
from app.fuse_mount import (
    start_fuse_mount, stop_fuse_mount,
    register_torrent, unregister_torrent, get_fuse_path,
    list_torrents, list_files, get_torrent_file,
    FUSE_AVAILABLE, update_dfs_settings, get_dfs_settings,
)
from app.setup import (
    is_setup_complete, mark_setup_complete,
    load_saved_config, write_env,
    test_alldebrid, test_overseerr, test_plex_root,
)

logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("debridarr")
for noisy in ("httpx","httpcore","multipart","uvicorn.access"):
    logging.getLogger(noisy).setLevel(logging.WARNING)


# ── Startup ───────────────────────────────────────────────────────────────────

def _schedule_restart(delay=2.0):
    import threading, subprocess, time
    def _do():
        time.sleep(delay)
        try: subprocess.run(["kill","-TERM","1"], check=False)
        except: pass
    threading.Thread(target=_do, daemon=True).start()


def _init_clients(app):
    import os
    class _S:
        ALLDEBRID_API_KEY  = os.environ.get("ALLDEBRID_API_KEY","")
        OVERSEERR_URL      = os.environ.get("OVERSEERR_URL","")
        OVERSEERR_API_KEY  = os.environ.get("OVERSEERR_API_KEY","")
        PLEX_ROOT          = os.environ.get("PLEX_ROOT","/plex-strm")
        DEBRIDARR_BASE_URL = os.environ.get("DEBRIDARR_BASE_URL","")
        DB_PATH            = os.environ.get("DB_PATH","/data/debridarr.db")
        PORT               = int(os.environ.get("PORT","7474"))
        LOG_LEVEL          = os.environ.get("LOG_LEVEL","INFO")
        FUSE_MOUNT         = os.environ.get("FUSE_MOUNT","/mnt/alldebrid")
        FUSE_SYMLINK_ROOT  = os.environ.get("FUSE_SYMLINK_ROOT","/docker/debridarr/mnt-alldebrid")
    s = _S()
    db = getattr(app.state, "db", None)
    tmdb_key = db.get_setting("tmdb_api_key","") if db else ""
    app.state.alldebrid = AllDebridClient(s.ALLDEBRID_API_KEY)
    app.state.library = LibraryManager(
        overseerr_url=s.OVERSEERR_URL, overseerr_key=s.OVERSEERR_API_KEY,
        plex_root=s.PLEX_ROOT, tmdb_api_key=tmdb_key,
    )
    app.state.settings = s


@asynccontextmanager
async def lifespan(app: FastAPI):
    import os
    _env = Path("/data/.env")
    if _env.exists():
        for line in _env.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line: continue
            k, _, v = line.partition("=")
            k, v = k.strip(), v.strip()
            if k and v and not os.environ.get(k): os.environ[k] = v

    db = CacheDB(settings.DB_PATH)
    db.init()
    app.state.db = db
    app.state.setup_complete = is_setup_complete()

    # Reset stuck + recover symlinked entries
    with db._connect() as conn:
        stuck = conn.execute("UPDATE cache SET status='not_found' WHERE status='resolving'").rowcount
        nf = conn.execute("SELECT cache_key,strm_path FROM cache WHERE status='not_found' AND strm_path IS NOT NULL").fetchall()
        recovered = 0
        for row in nf:
            if row[1] and Path(row[1]).is_symlink():
                conn.execute("UPDATE cache SET status='cached' WHERE cache_key=?", (row[0],))
                recovered += 1
    if stuck:     log.info(f"🔄 Reset {stuck} stuck 'resolving' → 'not_found'")
    if recovered: log.info(f"🔄 Recovered {recovered} symlinked entries → 'cached'")

    _init_clients(app)
    s = app.state.settings

    # Worker pool
    max_w = int(db.get_setting("max_workers","3"))
    pool = init_pool(max_w)
    pool.start()
    app.state.pool = pool

    # DFS settings
    try:
        import json as _j
        saved = db.get_setting("dfs_settings")
        if saved: update_dfs_settings(_j.loads(saved))
        else:
            cd = s.FUSE_SYMLINK_ROOT.replace("mnt-alldebrid","tmp/cache") if s.FUSE_SYMLINK_ROOT else "/docker/debridarr/tmp/cache"
            update_dfs_settings({"cache_dir": cd})
        Path(get_dfs_settings()["cache_dir"]).mkdir(parents=True, exist_ok=True)
    except: pass

    # FUSE
    if FUSE_AVAILABLE:
        _t = start_fuse_mount(s.FUSE_MOUNT, app.state.alldebrid, asyncio.get_event_loop())
        app.state.fuse_thread = _t
        if _t:
            log.info(f"🗂️  FUSE at {s.FUSE_MOUNT}")
            asyncio.create_task(_load_all_torrents(app))
    else:
        app.state.fuse_thread = None
        log.warning("⚠️  FUSE unavailable")

    asyncio.create_task(_cleanup_loop(app))
    asyncio.create_task(_symlink_health_loop(app))
    asyncio.create_task(_episode_sync_loop(app))
    log.info(f"✅ Debridarr ready — workers={max_w} plex={s.PLEX_ROOT or 'NOT SET'}")
    yield
    if getattr(app.state,"fuse_thread",None):
        stop_fuse_mount(app.state.settings.FUSE_MOUNT)


app = FastAPI(title="Debridarr", version="0.6.0", lifespan=lifespan)
def _needs_setup(r): return not getattr(r.app.state,"setup_complete",False)
def _setup_redirect(): return RedirectResponse("/setup",status_code=302)


# ── Shared UI ─────────────────────────────────────────────────────────────────

_CSS = """
* { box-sizing:border-box; margin:0; padding:0 }
body { font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif; background:#0f0f13; color:#e0e0e0; min-height:100vh }
header { background:#1a1a24; border-bottom:1px solid #2a2a3a; padding:14px 28px; display:flex; align-items:center; gap:16px }
header h1 { font-size:1.3rem; color:#fff }
header .ver { font-size:0.75rem; background:#f97316; color:#fff; border-radius:4px; padding:2px 8px }
nav { display:flex; gap:4px; margin-left:auto }
nav a { color:#aaa; text-decoration:none; padding:6px 14px; border-radius:6px; font-size:0.85rem; transition:background .15s }
nav a:hover,nav a.active { background:#2a2a3a; color:#fff }
main { padding:28px; max-width:1400px; margin:0 auto }
h2 { font-size:1.05rem; color:#ccc; margin-bottom:18px }
.card-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(160px,1fr)); gap:14px }
.card { background:#1a1a24; border:1px solid #2a2a3a; border-radius:10px; overflow:hidden }
.card img { width:100%; aspect-ratio:2/3; object-fit:cover; background:#111; display:block }
.card .no-poster { width:100%; aspect-ratio:2/3; background:#1a1a2e; display:flex; align-items:center; justify-content:center; font-size:2rem; color:#333 }
.card .info { padding:10px 12px }
.card .title { font-size:0.85rem; font-weight:600; color:#e0e0e0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis }
.card .meta { font-size:0.72rem; color:#555; margin-top:3px }
.card .actions { padding:0 10px 10px; display:flex; gap:6px; flex-wrap:wrap }
.btn { display:inline-block; padding:5px 12px; border-radius:6px; font-size:0.78rem; font-weight:600; border:none; cursor:pointer; text-decoration:none; transition:opacity .15s }
.btn:hover { opacity:.85 }
.btn-add { background:#f97316; color:#fff }
.btn-rem { background:#3b1f00; color:#fb923c }
.btn-sec { background:#1e3a5f; color:#60a5fa }
.btn-grn { background:#14532d; color:#4ade80 }
.btn-sm  { padding:3px 8px; font-size:0.72rem }
.badge-in   { display:inline-block; background:#14532d; color:#4ade80; font-size:0.68rem; font-weight:700; padding:2px 7px; border-radius:20px }
.badge-grey { display:inline-block; background:#1a1a24; color:#555; font-size:0.68rem; padding:2px 7px; border-radius:20px; border:1px solid #2a2a3a }
.badge-warn { display:inline-block; background:#451a03; color:#fdba74; font-size:0.68rem; font-weight:700; padding:2px 7px; border-radius:20px }
.search-bar { display:flex; gap:10px; margin-bottom:20px }
.search-bar input,.search-bar select { background:#1a1a24; border:1px solid #2a2a3a; border-radius:8px; padding:9px 14px; color:#e0e0e0; font-size:0.9rem; outline:none }
.search-bar input { flex:1 }
.search-bar input:focus,.search-bar select:focus { border-color:#f97316 }
.tabs { display:flex; gap:2px; margin-bottom:20px }
.tab { padding:8px 20px; border-radius:8px; cursor:pointer; font-size:0.85rem; font-weight:600; border:1px solid #2a2a3a; background:#1a1a24; color:#888 }
.tab.active { background:#f97316; color:#fff; border-color:#f97316 }
.empty { text-align:center; padding:60px; color:#444; font-size:0.9rem }
.toast { position:fixed; bottom:24px; right:24px; background:#1a1a24; border:1px solid #2a2a3a; border-radius:10px; padding:12px 20px; font-size:0.85rem; opacity:0; transition:opacity .3s; z-index:999 }
.toast.show { opacity:1 }
table { width:100%; border-collapse:collapse; background:#1a1a24; border-radius:10px; overflow:hidden }
th { text-align:left; padding:11px 14px; font-size:0.72rem; text-transform:uppercase; color:#555; border-bottom:1px solid #2a2a3a }
td { padding:10px 14px; border-bottom:1px solid #1e1e2e; font-size:0.85rem }
tr:last-child td { border-bottom:none }
tr:hover td { background:#1e1e2e }
.pill { padding:2px 9px; border-radius:20px; font-size:0.72rem; font-weight:600 }
.pill-ok   { background:#14532d; color:#4ade80 }
.pill-res  { background:#1e3a5f; color:#60a5fa }
.pill-err  { background:#3b0000; color:#f87171 }
.pill-pend { background:#2d2d00; color:#facc15 }
.pill-nf   { background:#3b1f00; color:#fb923c }
.pill-run  { background:#1e3a5f; color:#60a5fa }
.pill-queue{ background:#1e2d1e; color:#86efac }
.pill-fail { background:#3b0000; color:#f87171 }
.pill-can  { background:#2a2a2a; color:#888 }
.workers-bar { background:#1a1a24; border:1px solid #2a2a3a; border-radius:10px; padding:14px 18px; margin-bottom:20px; display:flex; align-items:center; gap:16px; flex-wrap:wrap }
.workers-bar .stat { font-size:0.8rem; color:#888 }
.workers-bar .stat strong { color:#e0e0e0 }
.pg { display:flex; gap:4px; align-items:center; margin-top:16px }
.pg a,.pg span,.pg select { padding:5px 10px; border-radius:6px; font-size:0.8rem; background:#1a1a24; border:1px solid #2a2a3a; color:#aaa; text-decoration:none }
.pg a:hover { border-color:#f97316; color:#f97316 }
.pg .cur { background:#f97316; color:#fff; border-color:#f97316 }
"""

_NAV = lambda a: f"""<nav>
  <a href="/library"  class="{'active' if a=='library'  else ''}">📚 Library</a>
  <a href="/streams"  class="{'active' if a=='streams'  else ''}">⚡ Streams</a>
  <a href="/missing"  class="{'active' if a=='missing'  else ''}">🔍 Missing</a>
  <a href="/workers"  class="{'active' if a=='workers'  else ''}">⚙️ Workers</a>
  <a href="/settings" class="{'active' if a=='settings' else ''}">🛠 Settings</a>
</nav>"""

_TOAST_JS = "function toast(msg,ok=true){const t=document.getElementById('toast');t.textContent=msg;t.style.borderColor=ok?'#4ade80':'#f87171';t.classList.add('show');setTimeout(()=>t.classList.remove('show'),3500)}"

def _page(title, nav, body, extra=""):
    return HTMLResponse(f"""<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title} — Debridarr</title><style>{_CSS}</style>{extra}</head>
<body><header><h1>🎬 Debridarr</h1><span class="ver">v0.6.0</span>{_NAV(nav)}</header>
<main>{body}</main><div id="toast" class="toast"></div>
<script>{_TOAST_JS}</script></body></html>""")

def _pg(page, total_pages, per_page, base_url):
    if total_pages <= 1: return ""
    links = '<div class="pg">'
    if page > 1: links += f'<a href="{base_url}&page={page-1}&per_page={per_page}">← Prev</a>'
    for p in range(max(1,page-2), min(total_pages+1,page+3)):
        cls = ' class="cur"' if p==page else ''
        links += f'<a href="{base_url}&page={p}&per_page={per_page}"{cls}>{p}</a>'
    if page < total_pages: links += f'<a href="{base_url}&page={page+1}&per_page={per_page}">Next →</a>'
    links += f'<span style="color:#555;font-size:0.75rem">{per_page}/page</span>'
    links += f'<select onchange="location.href=\'{base_url}&page=1&per_page=\'+this.value" style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:6px;padding:4px 8px;color:#aaa;font-size:0.78rem">'
    for n in [20,50,100]:
        links += f'<option value="{n}" {"selected" if n==per_page else ""}>{n}/page</option>'
    links += '</select></div>'
    return links

# ── Setup ─────────────────────────────────────────────────────────────────────
_SETUP_CSS = _CSS + """
.wizard{max-width:620px;margin:60px auto}
.wizard-card{background:#1a1a24;border:1px solid #2a2a3a;border-radius:14px;padding:36px}
.wizard h2{font-size:1.4rem;color:#fff;margin-bottom:6px}
.sub{color:#666;font-size:0.88rem;margin-bottom:28px;line-height:1.5}
.steps{display:flex;margin-bottom:32px}
.step{flex:1;text-align:center;font-size:0.7rem;color:#444;padding-bottom:8px;border-bottom:2px solid #2a2a3a}
.step.done{color:#4ade80;border-color:#4ade80}.step.active{color:#f97316;border-color:#f97316;font-weight:700}
.field{margin-bottom:20px}.field label{display:block;font-size:0.8rem;color:#888;margin-bottom:6px;font-weight:600}
.field input{width:100%;background:#0f0f13;border:1px solid #2a2a3a;border-radius:8px;padding:10px 14px;color:#e0e0e0;font-size:0.9rem;outline:none;font-family:monospace}
.field input:focus{border-color:#f97316}.field .hint{font-size:0.75rem;color:#555;margin-top:5px;line-height:1.4}.field .hint a{color:#f97316}
.tr{margin-top:10px;padding:8px 12px;border-radius:6px;font-size:0.82rem;display:none}
.tr.ok{background:#14532d;color:#4ade80;display:block}.tr.err{background:#3b0000;color:#f87171;display:block}.tr.testing{background:#1e1e2e;color:#aaa;display:block}
.row{display:flex;gap:10px}.row .field{flex:1}
.wa{display:flex;gap:10px;margin-top:28px;justify-content:flex-end}
.bp{background:#f97316;color:#fff;padding:10px 24px;border-radius:8px;font-size:0.9rem;font-weight:600;border:none;cursor:pointer}.bp:hover{opacity:.85}.bp:disabled{opacity:.4;cursor:not-allowed}
.bg{background:transparent;color:#666;padding:10px 16px;border-radius:8px;font-size:0.9rem;border:1px solid #2a2a3a;cursor:pointer}.bg:hover{color:#ccc;border-color:#444}
"""

def _setup_page(body, step):
    names=["Welcome","AllDebrid","Overseerr","Plex","Confirm"]
    keys=["welcome","alldebrid","overseerr","plex","confirm"]
    idx=keys.index(step) if step in keys else 0
    sh="".join(f'<div class="step {"done" if i<idx else "active" if i==idx else ""}">{n}</div>' for i,n in enumerate(names))
    return HTMLResponse(f"""<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Debridarr Setup</title><style>{_SETUP_CSS}</style></head>
<body><header><h1>🎬 Debridarr</h1><span class="ver">v0.6.0</span><span style="margin-left:auto;color:#555;font-size:0.8rem">First-run setup</span></header>
<div class="wizard"><div class="steps">{sh}</div><div class="wizard-card">{body}</div></div>
<div id="toast" class="toast"></div><script>{_TOAST_JS}</script></body></html>""")


@app.get("/setup", response_class=HTMLResponse)
async def setup_get(request: Request, step: str = "welcome"):
    cfg = load_saved_config()
    if step == "welcome":
        return _setup_page('<div style="font-size:4rem;text-align:center;margin-bottom:20px">🎬</div><h2>Welcome to Debridarr</h2><p class="sub">Takes ~2 minutes.</p><div class="wa"><a href="/setup?step=alldebrid" class="bp" style="text-decoration:none;display:inline-block;padding:10px 24px">Get Started →</a></div>',"welcome")
    if step == "alldebrid":
        v = cfg.get("ALLDEBRID_API_KEY","")
        return _setup_page(f'<h2>AllDebrid</h2><p class="sub">Streams cached torrents via AllDebrid.</p><div class="field"><label>API Key</label><input id="k" type="password" value="{v}" placeholder="Paste API key"><div class="hint">Get it at <a href="https://alldebrid.com/apikeys" target="_blank">alldebrid.com/apikeys</a></div><div id="tr" class="tr"></div></div><div class="wa"><a href="/setup?step=welcome" class="bg" style="text-decoration:none;display:inline-block">← Back</a><button class="bp" id="btn" onclick="go()">Test & Continue →</button></div><script>async function go(){{const k=document.getElementById("k").value.trim(),r_=document.getElementById("tr"),b=document.getElementById("btn");if(!k){{r_.className="tr err";r_.textContent="Required";return}}r_.className="tr testing";r_.textContent="Testing...";b.disabled=true;const r=await fetch("/setup/test",{{method:"POST",headers:{{"Content-Type":"application/json"}},body:JSON.stringify({{step:"alldebrid",api_key:k}})}});const d=await r.json();b.disabled=false;if(d.ok){{r_.className="tr ok";r_.textContent="✅ "+d.message;setTimeout(()=>location.href="/setup?step=overseerr&akey="+encodeURIComponent(k),800)}}else{{r_.className="tr err";r_.textContent="❌ "+d.message}}}}document.getElementById("k").addEventListener("keydown",e=>{{if(e.key==="Enter")go()}})</script>',"alldebrid")
    if step == "overseerr":
        akey = request.query_params.get("akey", cfg.get("ALLDEBRID_API_KEY",""))
        return _setup_page(f'<h2>Overseerr</h2><p class="sub">Connect to your request library.</p><div class="field"><label>URL</label><input id="url" value="{cfg.get("OVERSEERR_URL","http://192.168.1.x:5055")}"></div><div class="field"><label>API Key</label><input id="key" type="password" value="{cfg.get("OVERSEERR_API_KEY","")}"><div class="hint">Overseerr → Settings → General → API Key</div><div id="tr" class="tr"></div></div><input type="hidden" id="akey" value="{akey}"><div class="wa"><a href="/setup?step=alldebrid" class="bg" style="text-decoration:none;display:inline-block">← Back</a><button class="bp" id="btn" onclick="go()">Test & Continue →</button></div><script>async function go(){{const url=document.getElementById("url").value.trim(),key=document.getElementById("key").value.trim(),akey=document.getElementById("akey").value,r_=document.getElementById("tr"),b=document.getElementById("btn");r_.className="tr testing";r_.textContent="Testing...";b.disabled=true;const r=await fetch("/setup/test",{{method:"POST",headers:{{"Content-Type":"application/json"}},body:JSON.stringify({{step:"overseerr",url,api_key:key}})}});const d=await r.json();b.disabled=false;if(d.ok){{r_.className="tr ok";r_.textContent="✅ "+d.message;setTimeout(()=>location.href="/setup?step=plex&akey="+encodeURIComponent(akey)+"&ourl="+encodeURIComponent(url)+"&okey="+encodeURIComponent(key),800)}}else{{r_.className="tr err";r_.textContent="❌ "+d.message}}}}</script>',"overseerr")
    if step == "plex":
        qs = dict(request.query_params)
        hidden = "".join(f'<input type="hidden" id="{k}" value="{v}">' for k,v in qs.items() if k!="step")
        return _setup_page(f'<h2>Plex Integration</h2><p class="sub">Where to write library files.</p><div class="field"><label>Plex Library Path</label><input id="plex_root" value="/plex-strm"><div class="hint">Bind-mounted into both Debridarr and Plex.</div><div id="tr" class="tr"></div></div><div class="field"><label>Debridarr Base URL</label><input id="base_url" value="{cfg.get("DEBRIDARR_BASE_URL","http://192.168.1.x:7474")}"></div><div class="row"><div class="field"><label>Timezone</label><input id="tz" value="{cfg.get("TZ","America/Edmonton")}"></div><div class="field"><label>PUID</label><input id="puid" value="{cfg.get("PUID","1000")}"></div><div class="field"><label>PGID</label><input id="pgid" value="{cfg.get("PGID","1000")}"></div></div>{hidden}<div class="wa"><a href="/setup?step=overseerr" class="bg" style="text-decoration:none;display:inline-block">← Back</a><button class="bp" id="btn" onclick="go()">Test & Continue →</button></div><script>async function go(){{const pr=document.getElementById("plex_root").value.trim(),r_=document.getElementById("tr"),b=document.getElementById("btn");r_.className="tr testing";r_.textContent="Checking...";b.disabled=true;const r=await fetch("/setup/test",{{method:"POST",headers:{{"Content-Type":"application/json"}},body:JSON.stringify({{step:"plex",plex_root:pr}})}});const d=await r.json();b.disabled=false;if(d.ok){{r_.className="tr ok";r_.textContent="✅ "+d.message;const prev={{}};document.querySelectorAll("input[type=hidden]").forEach(i=>prev[i.id]=i.value);const p=new URLSearchParams({{...prev,step:"confirm",plex_root:pr,base_url:document.getElementById("base_url").value.trim(),tz:document.getElementById("tz").value.trim(),puid:document.getElementById("puid").value.trim(),pgid:document.getElementById("pgid").value.trim()}});setTimeout(()=>location.href="/setup?"+p.toString(),800)}}else{{r_.className="tr err";r_.textContent="❌ "+d.message}}}}</script>',"plex")
    if step == "confirm":
        qs = dict(request.query_params)
        def row(lbl,key,mask=False):
            val=qs.get(key,"—"); d=("•"*8+val[-4:]) if mask and val and val!="—" else val
            return f'<div style="display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid #1e1e2e"><span style="color:#666">{lbl}</span><span style="font-family:monospace;font-size:0.82rem">{d}</span></div>'
        hidden="".join(f'<input type="hidden" name="{k}" value="{v}">' for k,v in qs.items() if k!="step")
        return _setup_page(f'<h2>Confirm & Save</h2><p class="sub">Review and click Save.</p><div style="margin-bottom:24px">{row("AllDebrid API","akey",True)}{row("Overseerr URL","ourl")}{row("Overseerr API","okey",True)}{row("Plex Path","plex_root")}{row("Base URL","base_url")}{row("Timezone","tz")}</div><form method="POST" action="/setup/save">{hidden}<div class="wa"><a href="/setup?step=plex" class="bg" style="text-decoration:none;display:inline-block">← Back</a><button type="submit" class="bp">💾 Save & Finish</button></div></form>',"confirm")
    return RedirectResponse("/setup")


@app.post("/setup/test")
async def setup_test(request: Request):
    body=await request.json(); step=body.get("step")
    if step=="alldebrid":  ok,msg=await test_alldebrid(body.get("api_key",""))
    elif step=="overseerr":ok,msg=await test_overseerr(body.get("url",""),body.get("api_key",""))
    elif step=="plex":     ok,msg=await test_plex_root(body.get("plex_root",""))
    else:                  ok,msg=False,"Unknown step"
    return JSONResponse({"ok":ok,"message":msg})


@app.post("/setup/save")
async def setup_save(request: Request):
    form=dict(await request.form())
    config={"ALLDEBRID_API_KEY":form.get("akey",""),"OVERSEERR_URL":form.get("ourl",""),
            "OVERSEERR_API_KEY":form.get("okey",""),"DEBRIDARR_BASE_URL":form.get("base_url",""),
            "TZ":form.get("tz","America/Edmonton"),"PUID":form.get("puid","1000"),"PGID":form.get("pgid","1000")}
    write_env(config)
    import os
    for k,v in config.items(): os.environ[k]=v
    os.environ["PLEX_ROOT"]=form.get("plex_root","/plex-strm")
    mark_setup_complete(); request.app.state.setup_complete=True
    _init_clients(request.app); _schedule_restart(2.0)
    return HTMLResponse(f'<!DOCTYPE html><html><head><meta charset="UTF-8"><meta http-equiv="refresh" content="6;url=/library"><style>{_SETUP_CSS}</style></head><body><header><h1>🎬 Debridarr</h1><span class="ver">v0.6.0</span></header><div class="wizard"><div class="wizard-card" style="text-align:center;padding:48px"><div style="font-size:3rem;margin-bottom:16px">🎉</div><h2 style="color:#4ade80;margin-bottom:12px">Setup Complete!</h2><p style="color:#888;margin-bottom:24px">Redirecting...</p><a href="/library" style="color:#f97316">Click here if not redirected</a></div></div></body></html>')


@app.get("/", response_class=HTMLResponse)
async def root(r: Request):
    if _needs_setup(r): return _setup_redirect()
    return RedirectResponse("/library")

# ── /library ──────────────────────────────────────────────────────────────────
@app.get("/library", response_class=HTMLResponse)
async def library_browse(request: Request, tab: str="movies", q: str="", page: int=1, per_page: int=20):
    if _needs_setup(request): return _setup_redirect()
    lm=request.app.state.library; db=request.app.state.db
    added={(r["media_type"],r["title"].lower()) for r in db.fake_library_list()}
    items=await lm.get_radarr_movies() if tab=="movies" else await lm.get_sonarr_series()
    if q: items=[i for i in items if q.lower() in i["title"].lower()]
    total=len(items); total_pages=max(1,(total+per_page-1)//per_page)
    page=max(1,min(page,total_pages))
    page_items=items[(page-1)*per_page:page*per_page]
    cards=""
    for item in page_items:
        mtype="movie" if tab=="movies" else "series"; year=item.get("year")
        in_lib=(mtype,item["title"].lower()) in added; poster=item.get("poster","")
        t=item["title"].replace('"','&quot;'); sc=item.get("season_count",0)
        meta=str(year or "")
        if tab!="movies" and sc: meta+=f" · {sc} season{'s' if sc!=1 else ''}"
        img=f'<img src="{poster}" onerror="this.style.display=\'none\'" loading="lazy">' if poster else f'<div class="no-poster">{item["title"][:1]}</div>'
        if in_lib:
            action=f'<button class="btn btn-rem" data-mtype="{mtype}" data-title="{t}" data-year="{year or ""}" onclick="remCard(this)">Remove</button>'
        else:
            action=f'<button class="btn btn-add" data-mtype="{mtype}" data-id="{item.get("id","")}" data-title="{t}" data-year="{year or ""}" data-sc="{sc}" onclick="addCard(this)">+ Add</button>'
        cards+=f'<div class="card">{img}<div class="info"><div class="title" title="{t}">{item["title"]}</div><div class="meta">{meta}</div></div><div class="actions">{action}</div></div>'
    if not cards: cards=f'<div class="empty">{"No results for &quot;"+q+"&quot;" if q else "Nothing found"}</div>'
    mc=len(await lm.get_radarr_movies()); tc=len(await lm.get_sonarr_series())
    base=f"/library?tab={tab}&q={q}"
    body=f"""<h2>Browse Library</h2>
    <div class="tabs">
      <div class="tab {'active' if tab=='movies' else ''}" onclick="location.href='/library?tab=movies&q={q}'">🎬 Movies ({mc})</div>
      <div class="tab {'active' if tab=='tv' else ''}" onclick="location.href='/library?tab=tv&q={q}'">📺 TV Shows ({tc})</div>
    </div>
    <div class="search-bar">
      <input id="q" type="text" placeholder="Search..." value="{q}" onkeydown="if(event.key==='Enter')location.href='/library?tab={tab}&q='+encodeURIComponent(this.value)">
      <button class="btn btn-add" onclick="location.href='/library?tab={tab}&q='+encodeURIComponent(document.getElementById('q').value)">Search</button>
      {'<button class="btn btn-sec" onclick="location.href=\'/library?tab='+tab+'\'">Clear</button>' if q else ''}
      <button class="btn btn-sec" onclick="refreshLib()">🔄 Refresh</button>
    </div>
    <div class="card-grid">{cards}</div>{_pg(page,total_pages,per_page,base)}"""
    extra="""<script>
function addCard(btn){const t=btn.dataset.mtype,id=parseInt(btn.dataset.id)||null,ti=btn.dataset.title,yr=btn.dataset.year?parseInt(btn.dataset.year):null,sc=parseInt(btn.dataset.sc)||0;doAdd(t,id,ti,yr,sc,btn)}
function remCard(btn){const t=btn.dataset.mtype,ti=btn.dataset.title.replace(/&#39;/g,"'").replace(/&quot;/g,'"'),yr=btn.dataset.year?parseInt(btn.dataset.year):null;doRem(t,ti,yr)}
async function doAdd(type,id,title,year,sc,btn){
  if(btn){btn.disabled=true;btn.textContent='Adding...'}
  const r=await fetch('/api/library/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({media_type:type,arr_id:id,title,year,season_count:sc})});
  const d=await r.json();
  if(r.ok){toast('✅ '+title+' added');setTimeout(()=>location.reload(),1200)}
  else{toast('❌ '+(d.detail||d.message||'Error'),false);if(btn){btn.disabled=false;btn.textContent='+ Add'}}}
async function doRem(type,title,year){
  if(!confirm('Remove "'+title+'" from library? This deletes all symlinks and AllDebrid torrents.'))return;
  const r=await fetch('/api/library/remove',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({media_type:type,title,year})});
  if(r.ok){toast('🗑️ Removed');setTimeout(()=>location.reload(),1200)}else{toast('❌ Error',false)}}
async function refreshLib(){await fetch('/api/library/refresh',{method:'POST'});toast('✅ Refreshed');setTimeout(()=>location.reload(),1200)}
</script>"""
    return _page("Library","library",body,extra)


@app.post("/api/library/add")
async def api_library_add(request: Request, background_tasks: BackgroundTasks):
    body=await request.json()
    mtype=body.get("media_type","movie"); arr_id=body.get("arr_id"); title=body.get("title","").strip()
    year=body.get("year"); sc=body.get("season_count",0)
    if not title: raise HTTPException(400,"title required")
    lm=request.app.state.library; db=request.app.state.db; tmdb_key=db.get_setting("tmdb_api_key","")
    if mtype=="movie":
        movies=await lm.get_radarr_movies()
        mv=next((m for m in movies if m.get("id")==arr_id or m["title"].lower()==title.lower()),None)
        path=lm.create_fake_movie(title,year)
        poster=mv.get("poster","") if mv else ""
        tmdb_id=mv.get("tmdb_id") if mv else None; imdb_id=mv.get("imdb_id") if mv else None
        overview=mv.get("overview","") if mv else ""
        if not poster and tmdb_key and tmdb_id: poster=await _fetch_tmdb_poster(tmdb_id,title,True,tmdb_key)
        db.fake_library_add({"media_type":"movie","title":title,"year":year,"radarr_id":arr_id,
            "tmdb_id":tmdb_id,"imdb_id":imdb_id,"poster_url":poster,"overview":overview,
            "status":"movie","fake_path":str(path) if path else None})
        log.info(f"🎬 Added movie: {title} ({year})")
        background_tasks.add_task(_precache_movie,request.app,title,year,tmdb_id,imdb_id)
        return {"status":"ok","message":f"Added {title}"}
    else:
        sl=await lm.get_sonarr_series()
        series=next((s for s in sl if s.get("id")==arr_id),None)
        sc2=series.get("season_count",sc) if series else sc
        tvdb_id=series.get("tvdb_id") if series else None; tmdb_id=series.get("tmdb_id") if series else None
        imdb_id=series.get("imdb_id") if series else None; poster=series.get("poster","") if series else ""
        overview=series.get("overview","") if series else ""; is_ended=series.get("is_ended",False) if series else False
        req_seasons=series.get("requested_seasons",[]) if series else []
        if not poster and tmdb_key and tmdb_id: poster=await _fetch_tmdb_poster(tmdb_id,title,False,tmdb_key)
        inc=db.get_setting("include_unreleased_episodes","false")=="true"
        episodes=await lm.get_episodes(arr_id,include_unreleased=inc,requested_seasons=req_seasons if req_seasons else None)
        log.info(f"📺 {title}: {len(episodes)} episodes")
        paths=lm.create_fake_episodes(title,year,[],episodes)
        db.fake_library_add({"media_type":"series","title":title,"year":year,"sonarr_id":arr_id,
            "tvdb_id":tvdb_id,"tmdb_id":tmdb_id,"imdb_id":imdb_id,"season_count":sc2,
            "poster_url":poster,"overview":overview,"status":"ended" if is_ended else "continuing",
            "fake_path":str(Path(lm.plex_root)/"tv"/title) if lm.plex_root else None})
        log.info(f"📺 Added {title!r} — {len(paths)}/{len(episodes)} placeholders")
        background_tasks.add_task(_precache_series,request.app,title,year,episodes)
        return {"status":"ok","message":f"Added {title} — {len(episodes)} episodes"}


@app.post("/api/library/remove")
async def api_library_remove(request: Request, background_tasks: BackgroundTasks):
    body=await request.json()
    mtype=body.get("media_type"); title=body.get("title","").strip(); year=body.get("year")
    lm=request.app.state.library; db=request.app.state.db
    s=request.app.state.settings; alldebrid=request.app.state.alldebrid
    # 1. Remove plex-strm folder
    if mtype=="movie": lm.remove_fake_movie(title,year)
    else:              lm.remove_fake_series(title)
    # 2. Hard-expire all cache entries (symlinks + AllDebrid + DB)
    db_types=["movie"] if mtype=="movie" else ["episode","series"]
    entries=[e for e in db.list_all() if e["title"].lower()==title.lower() and e["media_type"] in db_types]
    for entry in entries:
        background_tasks.add_task(_hard_expire,entry,db,s,alldebrid)
    # 3. Remove from fake_library
    db.fake_library_remove(mtype,title,year)
    # 4. Clear search cache
    from app.alldebrid import _search_cache
    for k in [k for k in list(_search_cache) if title.lower() in k.lower()]: del _search_cache[k]
    # 5. Cancel workers for this title
    pool:WorkerPool=request.app.state.pool; cancelled=0
    for w in list(pool._workers.values()):
        if title.lower() in w.label.lower() and w.status.value in ("queued","running"):
            pool.cancel(w.id); cancelled+=1
    log.info(f"🗑️  Removed '{title}' — {len(entries)} entries, {cancelled} workers cancelled")
    return {"status":"removed","entries":len(entries),"workers_cancelled":cancelled}


@app.post("/api/library/refresh")
async def api_library_refresh(request: Request):
    lm=request.app.state.library; db=request.app.state.db
    if not lm: return {"status":"error"}
    lm.invalidate_cache()
    movies=await lm.get_radarr_movies(force=True); series=await lm.get_sonarr_series(force=True)
    added=[r for r in db.fake_library_list() if r["media_type"]=="series"]
    inc=db.get_setting("include_unreleased_episodes","false")=="true"; synced=0
    for entry in added:
        sid=entry.get("sonarr_id")
        if not sid: continue
        upd=next((s for s in series if s.get("id")==sid),None)
        if not upd: continue
        result=await lm.sync_series_episodes(entry["title"],sid,entry.get("year"),inc,requested_seasons=upd.get("requested_seasons",[]))
        if result.get("added",0)>0: synced+=1
    return {"status":"ok","movies":len(movies),"series":len(series),"synced":synced}

# ── /streams ──────────────────────────────────────────────────────────────────
@app.get("/streams", response_class=HTMLResponse)
async def streams_page(request: Request, q: str="", filter_type: str="all", page: int=1, per_page: int=20):
    if _needs_setup(request): return _setup_redirect()
    db=request.app.state.db
    lib_items=db.fake_library_list()
    movies_lib=[i for i in lib_items if i["media_type"]=="movie"]
    shows_lib=[i for i in lib_items if i["media_type"]=="series"]
    all_cached=[e for e in db.list_all() if e["status"]=="cached"]
    c_counts:dict={}
    for e in all_cached:
        mt="movie" if e["media_type"]=="movie" else "series"; k=f"{mt}::{e['title'].lower()}"
        c_counts[k]=c_counts.get(k,0)+1
    entries=db.list_all()
    if q: entries=[e for e in entries if q.lower() in e["title"].lower()]
    if filter_type!="all": entries=[e for e in entries if e["status"]==filter_type]
    total=len(entries); total_pages=max(1,(total+per_page-1)//per_page)
    page=max(1,min(page,total_pages)); paged=entries[(page-1)*per_page:page*per_page]
    def pill(s):
        cls={"cached":"pill-ok","resolving":"pill-res","error":"pill-err","not_found":"pill-nf"}.get(s,"pill-pend")
        return f'<span class="pill {cls}">{s}</span>'
    rows=""
    for e in paged:
        t=(e.get("torrent_name","") or ""); ts=(t[:55]+"…") if len(t)>55 else t
        ep=""
        if e.get("season"):  ep+=f"S{str(e['season']).zfill(2)}"
        if e.get("episode"): ep+=f"E{str(e['episode']).zfill(2)}"
        exp=datetime.fromisoformat(e["expires_at"]).strftime("%Y-%m-%d") if e.get("expires_at") else "—"
        ck=e["cache_key"]
        rows+=f'<tr><td style="color:#888;font-size:0.78rem">{e["media_type"]}</td><td><strong>{e["title"]}</strong><br><small style="color:#555;font-size:0.7rem">{ts}</small></td><td style="font-family:monospace">{ep}</td><td>{e.get("quality","—") or "—"}</td><td>{exp}</td><td>{pill(e["status"])}</td><td style="white-space:nowrap"><button class="btn btn-rem btn-sm" data-key="{ck}" onclick="delEntry(this)">Del</button> <button class="btn btn-sec btn-sm" data-key="{ck}" onclick="expireEntry(this)">⏰</button></td></tr>'
    def lib_card(item,mtype):
        title=item["title"]; safe=title.replace('"','&quot;').replace("'","&#39;")
        poster=item.get("poster_url") or ""; sc=item.get("season_count") or 0
        year=item.get("year") or ""; n=c_counts.get(f"{mtype}::{title.lower()}",0)
        img=f'<img src="{poster}" style="width:100%;aspect-ratio:2/3;object-fit:cover;display:block">' if poster else f'<div class="no-poster">{"".join(w[0].upper() for w in title.split()[:2])}</div>'
        status=item.get("status","")
        if mtype=="series":
            col="#ef4444" if status=="ended" else "#22c55e"
            sub=f'{sc} season{"s" if sc!=1 else ""} <span style="color:{col};font-size:0.65rem">({status})</span>'
        else: sub=str(year)
        badge=f'<span class="badge-in">✅ {n} ep{"s" if n!=1 else ""}</span>' if n and mtype=="series" else ('<span class="badge-in">✅ Cached</span>' if n else '<span class="badge-grey">⏳ Not cached</span>')
        return (f'<div class="card" data-filter="{safe}" style="cursor:pointer" onclick="filterByTitle(this)">'
                +img+f'<div class="info"><div class="title" title="{safe}">{title}</div><div class="meta">{sub}</div></div>'
                +f'<div class="actions">{badge}<button class="btn btn-rem btn-sm" data-mtype="{mtype}" data-title="{safe}" data-year="{item.get("year") or ""}" onclick="event.stopPropagation();remCard(this)">Remove</button></div></div>')
    lib_html=""
    if movies_lib:
        lib_html+=f'<h2 style="margin:0 0 12px">🎬 Movies ({len(movies_lib)})</h2><div class="card-grid" style="margin-bottom:32px">{"".join(lib_card(i,"movie") for i in movies_lib)}</div>'
    if shows_lib:
        lib_html+=f'<h2 style="margin:0 0 12px">📺 TV Shows ({len(shows_lib)})</h2><div class="card-grid" style="margin-bottom:32px">{"".join(lib_card(i,"series") for i in shows_lib)}</div>'
    if not lib_html: lib_html='<div class="empty"><a href="/library" style="color:#f97316">Browse Library</a> to add titles.</div>'
    base=f"/streams?q={q}&filter_type={filter_type}"
    del_all=f'<button class="btn btn-rem btn-sm" onclick="delAll()">🗑️ Del All</button>' if paged else ""
    streams_html=f"""
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
      <h2 style="margin:0">⚡ Streams ({total})</h2>{del_all}
    </div>
    <div class="search-bar" style="margin-bottom:14px">
      <input id="sq" type="text" placeholder="Search streams..." value="{q}" onkeydown="if(event.key==='Enter')goSearch()">
      <button class="btn btn-sec" onclick="goSearch()">Search</button>
      {'<button class="btn btn-sec" onclick="location.href=\'/streams\'">Clear</button>' if q else ''}
      <select onchange="location.href='/streams?q={q}&filter_type='+this.value" style="background:#1a1a24;border:1px solid #2a2a3a;border-radius:8px;padding:9px 14px;color:#e0e0e0;font-size:0.85rem;outline:none">
        <option value="all" {'selected' if filter_type=='all' else ''}>All</option>
        <option value="cached" {'selected' if filter_type=='cached' else ''}>Cached</option>
        <option value="not_found" {'selected' if filter_type=='not_found' else ''}>Not found</option>
        <option value="error" {'selected' if filter_type=='error' else ''}>Error</option>
      </select>
    </div>
    {"<table><thead><tr><th>Type</th><th>Title</th><th>Ep</th><th>Quality</th><th>Expires</th><th>Status</th><th></th></tr></thead><tbody>"+rows+"</tbody></table>"+_pg(page,total_pages,per_page,base) if rows else '<div class="empty">No streams.</div>'}"""
    body=lib_html+'<hr style="border:none;border-top:1px solid #2a2a3a;margin:32px 0">'+streams_html
    extra="""<script>
function goSearch(){location.href='/streams?q='+encodeURIComponent(document.getElementById('sq').value)+'&filter_type=all'}
function filterByTitle(card){document.getElementById('sq').value=card.dataset.filter||'';goSearch()}
async function expireEntry(btn){if(!confirm('Hard reset? Deletes symlink, restores placeholder, removes from AllDebrid.'))return;const r=await fetch('/cache/'+btn.dataset.key+'/expire',{method:'POST'});toast(r.ok?'⏰ Reset':'❌ Error',r.ok);setTimeout(()=>location.reload(),1800)}
async function delEntry(btn){await fetch('/cache/'+btn.dataset.key,{method:'DELETE'});toast('🗑️ Deleted');setTimeout(()=>location.reload(),1200)}
async function delAll(){const btns=[...document.querySelectorAll('[data-key]')];if(!confirm('Delete all '+btns.length+' entries?'))return;for(const b of btns)await fetch('/cache/'+b.dataset.key,{method:'DELETE'});toast('🗑️ Done');setTimeout(()=>location.reload(),1000)}
async function remCard(btn){const type=btn.dataset.mtype,title=btn.dataset.title.replace(/&#39;/g,"'").replace(/&quot;/g,'"'),year=btn.dataset.year?parseInt(btn.dataset.year):null;if(!confirm('Remove "'+title+'"? Deletes all symlinks and AllDebrid torrents.'))return;const r=await fetch('/api/library/remove',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({media_type:type,title,year})});if(r.ok){toast('🗑️ Removed');setTimeout(()=>location.reload(),1200)}else{toast('❌ Error',false)}}
</script>"""
    return _page("Streams","streams",body,extra)
