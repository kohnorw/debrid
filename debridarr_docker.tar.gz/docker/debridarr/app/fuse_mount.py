"""
AllDebrid FUSE filesystem.

Mirrors decypharr's approach:
- Files are virtual FUSE nodes
- On read(): unlock the AllDebrid file link → fetch bytes via HTTP Range
- Links are re-unlocked when expired (403/410)
- forceUnmount before mounting (cleans stale mounts)
- SIGTERM/SIGINT handler for clean shutdown
"""

import errno
import logging
import os
import signal
import stat
import subprocess
import threading
import time
from pathlib import Path
from typing import Optional

import httpx

log = logging.getLogger("debridarr.fuse")

try:
    import fuse
    from fuse import FUSE, FuseOSError, Operations
    FUSE_AVAILABLE = True
except ImportError:
    FUSE_AVAILABLE = False
    log.warning("fusepy not installed — FUSE unavailable")


# ── File registry ──────────────────────────────────────────────────────────────
# cache_key → {name, ad_link, cdn_url, cdn_generated, size, magnet_id}
_registry: dict[str, dict] = {}
_registry_lock = threading.Lock()
_mount_point: Optional[str] = None


def register_file(cache_key: str, name: str, ad_link: str, size: int = 0, magnet_id: str = "", **_):
    """Register an AllDebrid file link (not a CDN URL) in the FUSE registry."""
    with _registry_lock:
        _registry[cache_key] = {
            "name":          name,
            "ad_link":       ad_link,    # AllDebrid file link — used to unlock CDN URL
            "cdn_url":       "",         # cached CDN URL (refreshed when expired)
            "cdn_generated": 0.0,
            "size":          size,
            "magnet_id":     magnet_id,
        }
    log.info(f"📂 FUSE registered: {cache_key} → {name}")


def unregister_file(cache_key: str):
    with _registry_lock:
        _registry.pop(cache_key, None)


def get_fuse_path(cache_key: str, name: str, mount_point: str) -> Path:
    return Path(mount_point) / cache_key / name


# ── Unmount helpers (decypharr forceUnmount pattern) ──────────────────────────

def force_unmount(mount_point: str) -> bool:
    for cmd in [
        ["umount", mount_point],
        ["umount", "-l", mount_point],
        ["fusermount", "-uz", mount_point],
        ["fusermount3", "-uz", mount_point],
    ]:
        try:
            if subprocess.run(cmd, capture_output=True, timeout=10).returncode == 0:
                log.info(f"🗂️  Unmounted {mount_point} via {cmd[0]}")
                return True
        except Exception:
            continue
    return False


def is_mounted(mount_point: str) -> bool:
    try:
        with open("/proc/mounts") as f:
            return any(mount_point in line for line in f)
    except Exception:
        return False


# ── FUSE filesystem ────────────────────────────────────────────────────────────

if FUSE_AVAILABLE:
    class AllDebridFS(Operations):
        """
        Read-only FUSE FS. Each file read:
          1. Gets the stored AllDebrid link for this cache_key
          2. Unlocks it to get a CDN URL (cached 4h, re-unlocked on 403/410)
          3. Fetches the requested byte range from the CDN
        """

        def __init__(self, alldebrid_client, loop):
            self._ad   = alldebrid_client
            self._loop = loop
            self._http = httpx.Client(timeout=120, follow_redirects=True)
            # Per-key lock to prevent concurrent unlock calls
            self._unlock_locks: dict[str, threading.Lock] = {}
            self._unlock_locks_lock = threading.Lock()

        def _get_unlock_lock(self, cache_key: str) -> threading.Lock:
            with self._unlock_locks_lock:
                if cache_key not in self._unlock_locks:
                    self._unlock_locks[cache_key] = threading.Lock()
                return self._unlock_locks[cache_key]

        # ── Metadata ────────────────────────────────────────────────────────────

        def getattr(self, path: str, fh=None):
            now = int(time.time())
            parts = [p for p in path.split("/") if p]
            if not parts:
                return self._dir_stat(now)
            if len(parts) == 1:
                with _registry_lock:
                    if parts[0] in _registry:
                        return self._dir_stat(now)
                raise FuseOSError(errno.ENOENT)
            if len(parts) == 2:
                cache_key, filename = parts
                with _registry_lock:
                    entry = _registry.get(cache_key)
                if entry and entry["name"] == filename:
                    size = entry.get("size", 0)
                    if not size:
                        size = self._probe_size(cache_key, entry)
                        with _registry_lock:
                            if cache_key in _registry:
                                _registry[cache_key]["size"] = size
                    return self._file_stat(now, size)
                raise FuseOSError(errno.ENOENT)
            raise FuseOSError(errno.ENOENT)

        def readdir(self, path: str, fh):
            parts = [p for p in path.split("/") if p]
            yield "."; yield ".."
            if not parts:
                with _registry_lock:
                    for key in list(_registry.keys()):
                        yield key
            elif len(parts) == 1:
                with _registry_lock:
                    entry = _registry.get(parts[0])
                if entry:
                    yield entry["name"]

        def open(self, path: str, flags): return 0

        # ── Reading ──────────────────────────────────────────────────────────────

        def read(self, path: str, size: int, offset: int, fh) -> bytes:
            parts = [p for p in path.split("/") if p]
            if len(parts) != 2:
                raise FuseOSError(errno.ENOENT)
            cache_key, filename = parts
            with _registry_lock:
                entry = dict(_registry.get(cache_key, {}))
            if not entry or entry.get("name") != filename:
                raise FuseOSError(errno.ENOENT)

            cdn_url = self._get_cdn_url(cache_key, entry)
            if not cdn_url:
                raise FuseOSError(errno.EIO)

            return self._fetch_range(cdn_url, offset, offset + size - 1, cache_key, entry)

        def _get_cdn_url(self, cache_key: str, entry: dict) -> Optional[str]:
            """Get a valid CDN URL, unlocking if needed. Thread-safe."""
            lock = self._get_unlock_lock(cache_key)
            with lock:
                # Re-read in case another thread just refreshed
                with _registry_lock:
                    entry = dict(_registry.get(cache_key, entry))

                cdn_url = entry.get("cdn_url", "")
                cdn_age = time.time() - entry.get("cdn_generated", 0)

                if cdn_url and cdn_age < 4 * 3600:  # 4 hour CDN URL lifetime
                    return cdn_url

                # Unlock the AllDebrid file link to get a fresh CDN URL
                ad_link = entry.get("ad_link", "")
                if not ad_link:
                    log.error(f"No ad_link for {cache_key}")
                    return None

                try:
                    future = __import__("asyncio").run_coroutine_threadsafe(
                        self._ad.unlock_file(ad_link), self._loop
                    )
                    new_url = future.result(timeout=30)
                except Exception as e:
                    log.error(f"unlock_file failed for {cache_key}: {e}")
                    return cdn_url or None  # return stale if available

                if new_url:
                    with _registry_lock:
                        if cache_key in _registry:
                            _registry[cache_key]["cdn_url"]       = new_url
                            _registry[cache_key]["cdn_generated"]  = time.time()
                    log.info(f"🔓 Unlocked CDN URL for {cache_key}")
                    return new_url

                return cdn_url or None

        def _fetch_range(self, cdn_url: str, start: int, end: int, cache_key: str, entry: dict) -> bytes:
            headers = {"Range": f"bytes={start}-{end}"}
            for attempt in range(2):
                try:
                    resp = self._http.get(cdn_url, headers=headers, timeout=120)
                    if resp.status_code in (200, 206):
                        return resp.content
                    if resp.status_code in (403, 410) and attempt == 0:
                        log.warning(f"CDN URL expired for {cache_key}, re-unlocking...")
                        # Force re-unlock
                        with _registry_lock:
                            if cache_key in _registry:
                                _registry[cache_key]["cdn_generated"] = 0
                        cdn_url = self._get_cdn_url(cache_key, entry) or cdn_url
                        continue
                    raise FuseOSError(errno.EIO)
                except httpx.RequestError as e:
                    if attempt == 0:
                        continue
                    log.error(f"Network error reading {cache_key}: {e}")
                    raise FuseOSError(errno.EIO)
            raise FuseOSError(errno.EIO)

        def _probe_size(self, cache_key: str, entry: dict) -> int:
            cdn_url = self._get_cdn_url(cache_key, entry)
            if not cdn_url:
                return 0
            try:
                resp = self._http.head(cdn_url, timeout=10)
                return int(resp.headers.get("content-length", 0))
            except Exception:
                return 0

        def _dir_stat(self, now):
            return {"st_mode": stat.S_IFDIR | 0o555, "st_nlink": 2, "st_size": 0,
                    "st_ctime": now, "st_mtime": now, "st_atime": now,
                    "st_uid": os.getuid(), "st_gid": os.getgid()}

        def _file_stat(self, now, size):
            return {"st_mode": stat.S_IFREG | 0o444, "st_nlink": 1, "st_size": size,
                    "st_ctime": now, "st_mtime": now, "st_atime": now,
                    "st_uid": os.getuid(), "st_gid": os.getgid()}

        def access(self, path, mode): return 0
        def statfs(self, path):
            return {"f_bsize": 512, "f_blocks": 0, "f_bfree": 0,
                    "f_bavail": 0, "f_files": 0, "f_ffree": 0}


# ── Mount lifecycle ────────────────────────────────────────────────────────────

def start_fuse_mount(mount_point: str, alldebrid_client, loop) -> Optional[threading.Thread]:
    global _mount_point
    if not FUSE_AVAILABLE:
        return None

    mp = Path(mount_point)

    # Clean up stale mount (decypharr always does this)
    if is_mounted(mount_point):
        log.info(f"Stale mount at {mount_point} — cleaning up")
        force_unmount(mount_point)
        time.sleep(0.5)

    mp.mkdir(parents=True, exist_ok=True)
    _mount_point = mount_point

    # Signal handlers for clean shutdown on container stop
    def _shutdown(signum, frame):
        log.info(f"Signal {signum} — unmounting FUSE")
        stop_fuse_mount(mount_point)
        signal.signal(signum, signal.SIG_DFL)
        os.kill(os.getpid(), signum)

    signal.signal(signal.SIGTERM, _shutdown)
    signal.signal(signal.SIGINT,  _shutdown)

    fs_instance = AllDebridFS(alldebrid_client, loop)

    def _run():
        try:
            log.info(f"🗂️  Mounting AllDebrid FUSE at {mount_point}")
            FUSE(fs_instance, mount_point,
                 nothreads=False, foreground=True, ro=True,
                 allow_other=True, big_writes=True)
        except Exception as e:
            log.error(f"FUSE mount error: {e}", exc_info=True)

    t = threading.Thread(target=_run, name="fuse-alldebrid", daemon=True)
    t.start()

    for i in range(5):
        time.sleep(1)
        if is_mounted(mount_point):
            log.info(f"✅ FUSE mounted at {mount_point}")
            return t
        log.debug(f"Waiting for FUSE... {i+1}/5")

    log.warning(f"⚠️  FUSE not confirmed mounted at {mount_point}")
    return t


def stop_fuse_mount(mount_point: str = None):
    mp = mount_point or _mount_point
    if not mp:
        return
    if is_mounted(mp):
        force_unmount(mp)
