"""
AllDebrid FUSE filesystem — modelled on sirrobot01/decypharr.

Key design decisions from decypharr:
1. Mount point bind-mounted from host with 'shared' propagation
2. forceUnmount before every mount attempt  
3. SIGTERM/SIGINT handlers unmount cleanly
4. Files unlocked on first open, CDN URL cached per-file
5. HTTP Range requests serve bytes directly from AllDebrid CDN
"""

import errno
import logging
import os
import signal
import stat
import subprocess
import threading
import time
from pathlib import Path
from typing import Optional

import httpx

log = logging.getLogger("debridarr.fuse")

# Lazy imports — don't crash if libfuse not present
FUSE_AVAILABLE = False
FUSE = None
FuseOSError = None
Operations = None

def _try_load_fuse():
    global FUSE_AVAILABLE, FUSE, FuseOSError, Operations
    try:
        import ctypes
        import ctypes.util
        # Try to find libfuse explicitly before importing fusepy
        lib = ctypes.util.find_library("fuse")
        if lib:
            ctypes.CDLL(lib)
        from fuse import FUSE as _FUSE, FuseOSError as _FOE, Operations as _Ops
        FUSE = _FUSE
        FuseOSError = _FOE
        Operations = _Ops
        FUSE_AVAILABLE = True
        log.info("✅ libfuse loaded successfully")
    except Exception as e:
        log.warning(f"FUSE unavailable ({e}) — using HTTP proxy fallback")

_try_load_fuse()


# ── File registry ──────────────────────────────────────────────────────────────

_registry: dict[str, dict] = {}
_registry_lock = threading.Lock()
_mount_point: Optional[str] = None


def register_file(cache_key: str, name: str, ad_link: str,
                  size: int = 0, magnet_id: str = "", **_):
    with _registry_lock:
        _registry[cache_key] = {
            "name":         name,
            "ad_link":      ad_link,
            "cdn_url":      "",
            "cdn_ts":       0.0,
            "size":         size,
            "magnet_id":    magnet_id,
        }
    log.info(f"📂 FUSE registered: {cache_key} → {name}")


def unregister_file(cache_key: str):
    with _registry_lock:
        _registry.pop(cache_key, None)


def get_fuse_path(cache_key: str, name: str, mount_point: str) -> Path:
    return Path(mount_point) / cache_key / name


# ── Force unmount — mirrors decypharr forceUnmount ────────────────────────────

def _force_unmount(path: str):
    for cmd in [
        ["fusermount", "-uz", path],
        ["fusermount3", "-uz", path],
        ["umount", "-l", path],
        ["umount", path],
    ]:
        try:
            r = subprocess.run(cmd, capture_output=True, timeout=5)
            if r.returncode == 0:
                log.info(f"Unmounted {path} via {cmd[0]}")
                return
        except Exception:
            continue


def _is_mounted(path: str) -> bool:
    try:
        with open("/proc/mounts") as f:
            return any(path in line for line in f)
    except Exception:
        return False


# ── FUSE filesystem ────────────────────────────────────────────────────────────

if FUSE_AVAILABLE:
    class AllDebridFS(Operations):

        def __init__(self, ad_client, loop):
            self._ad   = ad_client
            self._loop = loop
            self._http = httpx.Client(timeout=120, follow_redirects=True)
            self._locks: dict[str, threading.Lock] = {}
            self._locks_mu = threading.Lock()

        def _lock(self, key: str) -> threading.Lock:
            with self._locks_mu:
                if key not in self._locks:
                    self._locks[key] = threading.Lock()
                return self._locks[key]

        # ── Metadata ──────────────────────────────────────────────────────────

        def getattr(self, path, fh=None):
            now = int(time.time())
            parts = [p for p in path.split("/") if p]

            if not parts:
                return self._dstat(now)

            if len(parts) == 1:
                with _registry_lock:
                    if parts[0] in _registry:
                        return self._dstat(now)
                raise FuseOSError(errno.ENOENT)

            if len(parts) == 2:
                cache_key, fname = parts
                with _registry_lock:
                    e = _registry.get(cache_key)
                if e and e["name"] == fname:
                    sz = e["size"] or self._probe(cache_key, e)
                    return self._fstat(now, sz)
                raise FuseOSError(errno.ENOENT)

            raise FuseOSError(errno.ENOENT)

        def readdir(self, path, fh):
            parts = [p for p in path.split("/") if p]
            yield "."; yield ".."
            if not parts:
                with _registry_lock:
                    yield from list(_registry.keys())
            elif len(parts) == 1:
                with _registry_lock:
                    e = _registry.get(parts[0])
                if e:
                    yield e["name"]

        def open(self, path, flags):
            return 0

        # ── Reading ───────────────────────────────────────────────────────────

        def read(self, path, size, offset, fh):
            parts = [p for p in path.split("/") if p]
            if len(parts) != 2:
                raise FuseOSError(errno.ENOENT)

            cache_key, fname = parts
            with _registry_lock:
                e = dict(_registry.get(cache_key, {}))
            if not e or e.get("name") != fname:
                raise FuseOSError(errno.ENOENT)

            url = self._cdn_url(cache_key, e)
            if not url:
                raise FuseOSError(errno.EIO)

            return self._range(url, offset, offset + size - 1, cache_key)

        def _cdn_url(self, cache_key: str, entry: dict) -> Optional[str]:
            with self._lock(cache_key):
                with _registry_lock:
                    e = dict(_registry.get(cache_key, entry))
                url = e.get("cdn_url", "")
                age = time.time() - e.get("cdn_ts", 0)
                if url and age < 4 * 3600:
                    return url

                ad_link = e.get("ad_link", "")
                if not ad_link:
                    return None

                import asyncio
                try:
                    fut = asyncio.run_coroutine_threadsafe(
                        self._ad.unlock_file(ad_link), self._loop)
                    new_url = fut.result(timeout=30)
                except Exception as ex:
                    log.error(f"unlock_file failed for {cache_key}: {ex}")
                    return url or None

                if new_url:
                    with _registry_lock:
                        if cache_key in _registry:
                            _registry[cache_key]["cdn_url"] = new_url
                            _registry[cache_key]["cdn_ts"]  = time.time()
                    log.info(f"🔓 CDN URL unlocked for {cache_key}")
                    return new_url
                return url or None

        def _range(self, url, start, end, cache_key):
            for attempt in range(2):
                try:
                    r = self._http.get(url, headers={"Range": f"bytes={start}-{end}"})
                    if r.status_code in (200, 206):
                        return r.content
                    if r.status_code in (403, 410) and attempt == 0:
                        with _registry_lock:
                            if cache_key in _registry:
                                _registry[cache_key]["cdn_ts"] = 0
                        with _registry_lock:
                            e = dict(_registry.get(cache_key, {}))
                        url = self._cdn_url(cache_key, e) or url
                        continue
                    raise FuseOSError(errno.EIO)
                except httpx.RequestError:
                    if attempt == 0:
                        continue
                    raise FuseOSError(errno.EIO)
            raise FuseOSError(errno.EIO)

        def _probe(self, cache_key, e):
            url = self._cdn_url(cache_key, e)
            if not url:
                return 0
            try:
                r = self._http.head(url, timeout=10)
                sz = int(r.headers.get("content-length", 0))
                with _registry_lock:
                    if cache_key in _registry:
                        _registry[cache_key]["size"] = sz
                return sz
            except Exception:
                return 0

        def _dstat(self, now):
            return {"st_mode": stat.S_IFDIR | 0o555, "st_nlink": 2,
                    "st_size": 0, "st_ctime": now, "st_mtime": now,
                    "st_atime": now, "st_uid": os.getuid(), "st_gid": os.getgid()}

        def _fstat(self, now, size):
            return {"st_mode": stat.S_IFREG | 0o444, "st_nlink": 1,
                    "st_size": size, "st_ctime": now, "st_mtime": now,
                    "st_atime": now, "st_uid": os.getuid(), "st_gid": os.getgid()}

        def access(self, path, mode): return 0
        def statfs(self, path):
            return {"f_bsize": 512, "f_blocks": 4096, "f_bfree": 4096,
                    "f_bavail": 4096, "f_files": 0, "f_ffree": 0}


# ── Mount ──────────────────────────────────────────────────────────────────────

def start_fuse_mount(mount_point: str, ad_client, loop) -> Optional[threading.Thread]:
    global _mount_point
    if not FUSE_AVAILABLE:
        log.warning("FUSE not available — skipping mount")
        return None

    # Always force-unmount first (decypharr pattern)
    if _is_mounted(mount_point):
        log.info(f"Stale mount at {mount_point} — cleaning up")
        _force_unmount(mount_point)
        time.sleep(0.5)

    Path(mount_point).mkdir(parents=True, exist_ok=True)
    _mount_point = mount_point

    # Signal handlers — clean unmount on container stop
    def _sig(signum, frame):
        log.info(f"Signal {signum} — unmounting")
        stop_fuse_mount(mount_point)
        signal.signal(signum, signal.SIG_DFL)
        os.kill(os.getpid(), signum)

    signal.signal(signal.SIGTERM, _sig)
    signal.signal(signal.SIGINT,  _sig)

    fs = AllDebridFS(ad_client, loop)

    def _run():
        try:
            log.info(f"🗂️  Mounting FUSE at {mount_point}")
            FUSE(fs, mount_point,
                 nothreads=False,
                 foreground=True,
                 ro=True,
                 allow_other=True,
                 big_writes=True,
                 max_read=131072)
        except Exception as e:
            log.error(f"FUSE error: {e}", exc_info=True)

    t = threading.Thread(target=_run, name="fuse", daemon=True)
    t.start()

    for i in range(10):
        time.sleep(0.5)
        if _is_mounted(mount_point):
            log.info(f"✅ FUSE mounted at {mount_point}")
            return t

    log.error(f"❌ FUSE failed to mount at {mount_point}")
    return None


def stop_fuse_mount(mount_point: str = None):
    mp = mount_point or _mount_point
    if mp and _is_mounted(mp):
        _force_unmount(mp)
