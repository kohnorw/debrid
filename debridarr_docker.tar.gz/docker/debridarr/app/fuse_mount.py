"""
AllDebrid FUSE filesystem for Debridarr.
Patterns taken from sirrobot01/decypharr:
  - forceUnmount before mounting (cleans stale mounts from previous container runs)
  - forceUnmount tries: umount, umount -l, fusermount -uz, fusermount3 -uz
  - SIGTERM/SIGINT handler unmounts cleanly before exit
  - Mount in a daemon thread; unmount is synchronous
  - user_allow_other in /etc/fuse.conf so Plex (different uid) can read
"""

import errno
import logging
import os
import signal
import stat
import subprocess
import threading
import time
from pathlib import Path
from typing import Optional

import httpx

log = logging.getLogger("debridarr.fuse")

try:
    import fuse
    from fuse import FUSE, FuseOSError, Operations
    FUSE_AVAILABLE = True
except ImportError:
    FUSE_AVAILABLE = False
    log.warning("fusepy not installed — FUSE mount unavailable, using HTTP proxy")


# ── Virtual file registry ──────────────────────────────────────────────────────

_registry: dict[str, dict] = {}
_registry_lock = threading.Lock()
_fuse_server: Optional[threading.Thread] = None
_mount_point: Optional[str] = None


def register_file(cache_key: str, url: str, name: str, size: int = 0, magnet: str = ""):
    with _registry_lock:
        _registry[cache_key] = {
            "url":          url,
            "name":         name,
            "size":         size,
            "magnet":       magnet,
            "refreshed_at": time.time(),
        }
    log.info(f"📂 FUSE registered: {cache_key} → {name} ({size} bytes)")


def unregister_file(cache_key: str):
    with _registry_lock:
        _registry.pop(cache_key, None)


def get_fuse_path(cache_key: str, name: str, mount_point: str) -> Path:
    return Path(mount_point) / cache_key / name


# ── Force unmount — mirrors decypharr's forceUnmount ──────────────────────────

def force_unmount(mount_point: str) -> bool:
    """
    Try every unmount method in sequence.
    Returns True if any succeeded.
    Mirrors decypharr pkg/mount/dfs/backend/hanwen/backend.go forceUnmount().
    """
    methods = [
        ["umount", mount_point],
        ["umount", "-l", mount_point],          # lazy — detach even if busy
        ["fusermount", "-uz", mount_point],      # fuse2
        ["fusermount3", "-uz", mount_point],     # fuse3
    ]
    for cmd in methods:
        try:
            result = subprocess.run(cmd, capture_output=True, timeout=10)
            if result.returncode == 0:
                log.info(f"🗂️  Unmounted {mount_point} via {cmd[0]}")
                return True
        except (FileNotFoundError, subprocess.TimeoutExpired):
            continue
        except Exception as e:
            log.debug(f"Unmount attempt {cmd} failed: {e}")
    return False


def is_mounted(mount_point: str) -> bool:
    """Check if the path is currently a FUSE mount point."""
    try:
        mp = Path(mount_point)
        if not mp.exists():
            return False
        # Read /proc/mounts to check
        with open("/proc/mounts") as f:
            return any(mount_point in line for line in f)
    except Exception:
        return False


# ── FUSE filesystem ────────────────────────────────────────────────────────────

if FUSE_AVAILABLE:
    class AllDebridFS(Operations):
        """
        Read-only FUSE filesystem backed by AllDebrid CDN URLs.
        /<cache_key>/<filename> → streams bytes from AllDebrid with Range headers.
        """

        def __init__(self, alldebrid_client, loop):
            self._ad   = alldebrid_client
            self._loop = loop
            self._http = httpx.Client(timeout=60, follow_redirects=True)

        # ── Metadata ────────────────────────────────────────────────────────────

        def getattr(self, path: str, fh=None):
            now = int(time.time())
            parts = [p for p in path.split("/") if p]

            if not parts:
                return self._dir_stat(now)

            if len(parts) == 1:
                with _registry_lock:
                    if parts[0] in _registry:
                        return self._dir_stat(now)
                raise FuseOSError(errno.ENOENT)

            if len(parts) == 2:
                cache_key, filename = parts
                with _registry_lock:
                    entry = _registry.get(cache_key)
                if entry and entry["name"] == filename:
                    size = entry.get("size", 0)
                    if not size:
                        size = self._probe_size(entry["url"])
                        with _registry_lock:
                            if cache_key in _registry:
                                _registry[cache_key]["size"] = size
                    return self._file_stat(now, size)
                raise FuseOSError(errno.ENOENT)

            raise FuseOSError(errno.ENOENT)

        def readdir(self, path: str, fh):
            parts = [p for p in path.split("/") if p]
            yield "."
            yield ".."
            if not parts:
                with _registry_lock:
                    for key in list(_registry.keys()):
                        yield key
            elif len(parts) == 1:
                with _registry_lock:
                    entry = _registry.get(parts[0])
                if entry:
                    yield entry["name"]

        def open(self, path: str, flags):
            return 0

        # ── Reading — core of the FUSE FS ───────────────────────────────────────

        def read(self, path: str, size: int, offset: int, fh) -> bytes:
            parts = [p for p in path.split("/") if p]
            if len(parts) != 2:
                raise FuseOSError(errno.ENOENT)

            cache_key, filename = parts
            with _registry_lock:
                entry = dict(_registry.get(cache_key, {}))
            if not entry or entry.get("name") != filename:
                raise FuseOSError(errno.ENOENT)

            return self._fetch_range(entry["url"], offset, offset + size - 1, cache_key, entry)

        def _fetch_range(self, url: str, start: int, end: int, cache_key: str, entry: dict) -> bytes:
            headers = {"Range": f"bytes={start}-{end}"}
            for attempt in range(2):
                try:
                    resp = self._http.get(url, headers=headers, timeout=120)
                    if resp.status_code in (200, 206):
                        return resp.content
                    if resp.status_code in (403, 410) and attempt == 0:
                        log.warning(f"AllDebrid URL expired for {cache_key}, refreshing...")
                        new_url = self._refresh_url(cache_key, entry)
                        if new_url:
                            url = new_url
                        continue
                    log.error(f"HTTP {resp.status_code} reading {cache_key}")
                    raise FuseOSError(errno.EIO)
                except httpx.RequestError as e:
                    if attempt == 0:
                        continue
                    log.error(f"Network error reading {cache_key}: {e}")
                    raise FuseOSError(errno.EIO)
            raise FuseOSError(errno.EIO)

        def _refresh_url(self, cache_key: str, entry: dict) -> Optional[str]:
            magnet = entry.get("magnet", "")
            if not magnet:
                return None
            try:
                import asyncio
                future = asyncio.run_coroutine_threadsafe(
                    self._ad.unlock_magnet(magnet), self._loop
                )
                new_url = future.result(timeout=30)
                if new_url:
                    with _registry_lock:
                        if cache_key in _registry:
                            _registry[cache_key]["url"] = new_url
                            _registry[cache_key]["refreshed_at"] = time.time()
                return new_url
            except Exception as e:
                log.error(f"URL refresh failed for {cache_key}: {e}")
                return None

        def _probe_size(self, url: str) -> int:
            try:
                resp = self._http.head(url, timeout=10)
                return int(resp.headers.get("content-length", 0))
            except Exception:
                return 0

        def _dir_stat(self, now: int) -> dict:
            return {"st_mode": stat.S_IFDIR | 0o555, "st_nlink": 2, "st_size": 0,
                    "st_ctime": now, "st_mtime": now, "st_atime": now,
                    "st_uid": os.getuid(), "st_gid": os.getgid()}

        def _file_stat(self, now: int, size: int) -> dict:
            return {"st_mode": stat.S_IFREG | 0o444, "st_nlink": 1, "st_size": size,
                    "st_ctime": now, "st_mtime": now, "st_atime": now,
                    "st_uid": os.getuid(), "st_gid": os.getgid()}

        def access(self, path, mode): return 0
        def statfs(self, path):
            return {"f_bsize": 512, "f_blocks": 0, "f_bfree": 0,
                    "f_bavail": 0, "f_files": 0, "f_ffree": 0}


# ── Mount / unmount lifecycle ──────────────────────────────────────────────────

def start_fuse_mount(mount_point: str, alldebrid_client, loop) -> Optional[threading.Thread]:
    """
    Mount AllDebrid FUSE filesystem.
    Follows decypharr's pattern:
      1. Force-unmount any stale mount first (previous container run)
      2. Create mount point
      3. Mount in daemon thread
      4. Register SIGTERM/SIGINT handlers for clean shutdown
    """
    global _mount_point

    if not FUSE_AVAILABLE:
        log.warning("FUSE not available")
        return None

    mp = Path(mount_point)

    # Step 1: Clean up any stale mount (decypharr always does this before mounting)
    if is_mounted(mount_point):
        log.info(f"🗂️  Stale mount detected at {mount_point}, cleaning up...")
        force_unmount(mount_point)
        time.sleep(0.5)

    # Step 2: Ensure mount point exists
    mp.mkdir(parents=True, exist_ok=True)

    _mount_point = mount_point

    # Step 3: Register signal handlers for clean shutdown
    # This is the key fix — Python FUSE doesn't unmount on SIGTERM by default
    def _shutdown_handler(signum, frame):
        log.info(f"🛑 Signal {signum} received — unmounting FUSE and exiting")
        stop_fuse_mount(mount_point)
        # Re-raise to let the process exit normally
        signal.signal(signum, signal.SIG_DFL)
        os.kill(os.getpid(), signum)

    signal.signal(signal.SIGTERM, _shutdown_handler)
    signal.signal(signal.SIGINT,  _shutdown_handler)

    # Step 4: Mount in daemon thread
    fs_instance = AllDebridFS(alldebrid_client, loop)

    def _run():
        try:
            log.info(f"🗂️  Mounting AllDebrid FUSE at {mount_point}")
            FUSE(
                fs_instance,
                mount_point,
                nothreads=False,
                foreground=True,
                ro=True,
                allow_other=True,   # Plex runs as a different user
                big_writes=True,    # better throughput for video
            )
        except Exception as e:
            log.error(f"FUSE mount error: {e}", exc_info=True)

    t = threading.Thread(target=_run, name="fuse-alldebrid", daemon=True)
    t.start()

    # Wait for mount to come up then verify
    for i in range(5):
        time.sleep(1)
        if is_mounted(mount_point):
            log.info(f"✅ FUSE mounted at {mount_point} (confirmed via /proc/mounts)")
            return t
        log.debug(f"Waiting for FUSE mount... attempt {i+1}/5")

    log.warning(f"⚠️  FUSE mount not confirmed at {mount_point} after 5s — thread alive={t.is_alive()}")
    return t


def stop_fuse_mount(mount_point: str = None):
    """
    Cleanly unmount the FUSE filesystem.
    Tries all methods like decypharr's forceUnmount.
    Called on SIGTERM, container stop, or lifespan teardown.
    """
    mp = mount_point or _mount_point
    if not mp:
        return
    log.info(f"🗂️  Unmounting FUSE at {mp}...")
    if not is_mounted(mp):
        log.info("Nothing to unmount")
        return
    success = force_unmount(mp)
    if not success:
        log.warning(f"Could not unmount {mp} — may need manual cleanup")
    else:
        log.info(f"✅ FUSE unmounted: {mp}")
