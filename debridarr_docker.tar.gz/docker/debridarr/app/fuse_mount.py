"""
AllDebrid FUSE filesystem — mirrors sirrobot01/decypharr structure.

Mount layout (same as decypharr):
  /mnt/alldebrid/
    <torrent_name>/          ← one dir per torrent in AllDebrid account
      <video_file.mkv>       ← virtual file, bytes fetched via HTTP Range

On startup: fetch ALL torrents from AllDebrid, build virtual FS.
On read:    unlock file link → get CDN URL → fetch byte range.
On stop:    SIGTERM handler unmounts cleanly (decypharr forceUnmount pattern).
"""

import errno
import logging
import os
import signal
import stat
import subprocess
import threading
import time
from pathlib import Path
from typing import Optional

import httpx

log = logging.getLogger("debridarr.fuse")

# ── Safe lazy import of fusepy ─────────────────────────────────────────────────
FUSE_AVAILABLE = False
FUSE = None
FuseOSError = None
Operations = None

def _load_fuse():
    global FUSE_AVAILABLE, FUSE, FuseOSError, Operations
    try:
        from fuse import FUSE as _F, FuseOSError as _E, Operations as _O
        FUSE, FuseOSError, Operations = _F, _E, _O
        FUSE_AVAILABLE = True
    except Exception as e:
        log.warning(f"FUSE not available: {e}")

_load_fuse()

# ── In-memory torrent registry ─────────────────────────────────────────────────
# Mirrors decypharr's torrent list: {torrent_name: {files: [{name, link, size}]}}
_torrents: dict[str, dict] = {}
_torrents_lock = threading.Lock()

# CDN URL cache: {ad_link: (cdn_url, timestamp)}
_cdn_cache: dict[str, tuple[str, float]] = {}
_cdn_lock = threading.Lock()

_mount_point: Optional[str] = None
_ad_client = None
_event_loop = None


def get_fuse_path(torrent_name: str, filename: str, mount_point: str) -> Path:
    return Path(mount_point) / torrent_name / filename


def register_torrent(torrent_name: str, files: list):
    """Register a torrent and its files in the virtual FS."""
    with _torrents_lock:
        _torrents[torrent_name] = {"files": {f["n"]: f for f in files}}
    log.info(f"📂 FUSE: registered '{torrent_name}' ({len(files)} files)")


def get_torrent_file(torrent_name: str, filename: str) -> Optional[dict]:
    with _torrents_lock:
        t = _torrents.get(torrent_name)
        if t:
            return t["files"].get(filename)
    return None


def list_torrents() -> list[str]:
    with _torrents_lock:
        return list(_torrents.keys())


def list_files(torrent_name: str) -> list[str]:
    with _torrents_lock:
        t = _torrents.get(torrent_name, {})
        return list(t.get("files", {}).keys())


# ── CDN URL management ─────────────────────────────────────────────────────────

def _get_cdn_url(ad_link: str) -> Optional[str]:
    """Get or refresh CDN URL for an AllDebrid file link."""
    with _cdn_lock:
        cached = _cdn_cache.get(ad_link)
        if cached and time.time() - cached[1] < 4 * 3600:
            return cached[0]

    if not _ad_client or not _event_loop:
        return None

    import asyncio
    try:
        fut = asyncio.run_coroutine_threadsafe(
            _ad_client.unlock_file(ad_link), _event_loop)
        url = fut.result(timeout=30)
        if url:
            with _cdn_lock:
                _cdn_cache[ad_link] = (url, time.time())
            return url
    except Exception as e:
        log.error(f"unlock_file failed: {e}")
    return None


def _invalidate_cdn(ad_link: str):
    with _cdn_lock:
        _cdn_cache.pop(ad_link, None)


# ── Force unmount (decypharr forceUnmount) ─────────────────────────────────────

def _force_unmount(path: str):
    for cmd in [
        ["fusermount", "-uz", path],
        ["fusermount3", "-uz", path],
        ["umount", "-l", path],
        ["umount", path],
    ]:
        try:
            if subprocess.run(cmd, capture_output=True, timeout=5).returncode == 0:
                log.info(f"Unmounted {path} via {cmd[0]}")
                return
        except Exception:
            continue


def _is_mounted(path: str) -> bool:
    try:
        with open("/proc/mounts") as f:
            return any(path in line for line in f)
    except Exception:
        return False


# ── FUSE filesystem ────────────────────────────────────────────────────────────

if FUSE_AVAILABLE:

    class AllDebridFS(Operations):
        """
        Virtual FS mirroring decypharr's structure:
          / → torrent dirs → files
        """

        def __init__(self):
            self._http = httpx.Client(timeout=120, follow_redirects=True)

        # ── Metadata ──────────────────────────────────────────────────────────

        def getattr(self, path, fh=None):
            now = int(time.time())
            parts = [p for p in path.split("/") if p]

            if not parts:                          # root
                return self._dstat(now)

            if len(parts) == 1:                    # torrent dir
                if parts[0] in list_torrents():
                    return self._dstat(now)
                raise FuseOSError(errno.ENOENT)

            if len(parts) == 2:                    # file
                torrent_name, filename = parts
                f = get_torrent_file(torrent_name, filename)
                if f:
                    return self._fstat(now, f.get("s", 0))
                raise FuseOSError(errno.ENOENT)

            raise FuseOSError(errno.ENOENT)

        def readdir(self, path, fh):
            parts = [p for p in path.split("/") if p]
            yield "."; yield ".."

            if not parts:
                yield from list_torrents()
            elif len(parts) == 1:
                yield from list_files(parts[0])

        def open(self, path, flags):
            return 0

        # ── Reading ───────────────────────────────────────────────────────────

        def read(self, path, size, offset, fh):
            parts = [p for p in path.split("/") if p]
            if len(parts) != 2:
                raise FuseOSError(errno.ENOENT)

            torrent_name, filename = parts
            f = get_torrent_file(torrent_name, filename)
            if not f:
                raise FuseOSError(errno.ENOENT)

            ad_link = f.get("l", "")
            if not ad_link:
                raise FuseOSError(errno.EIO)

            url = _get_cdn_url(ad_link)
            if not url:
                raise FuseOSError(errno.EIO)

            return self._fetch(url, offset, offset + size - 1, ad_link)

        def _fetch(self, url: str, start: int, end: int, ad_link: str) -> bytes:
            for attempt in range(2):
                try:
                    r = self._http.get(url, headers={"Range": f"bytes={start}-{end}"})
                    if r.status_code in (200, 206):
                        return r.content
                    if r.status_code in (403, 410) and attempt == 0:
                        _invalidate_cdn(ad_link)
                        url = _get_cdn_url(ad_link) or url
                        continue
                    raise FuseOSError(errno.EIO)
                except httpx.RequestError:
                    if attempt == 0:
                        continue
                    raise FuseOSError(errno.EIO)
            raise FuseOSError(errno.EIO)

        def _dstat(self, now):
            return {"st_mode": stat.S_IFDIR | 0o755, "st_nlink": 2,
                    "st_size": 4096, "st_ctime": now, "st_mtime": now,
                    "st_atime": now, "st_uid": os.getuid(), "st_gid": os.getgid()}

        def _fstat(self, now, size):
            return {"st_mode": stat.S_IFREG | 0o444, "st_nlink": 1,
                    "st_size": size, "st_ctime": now, "st_mtime": now,
                    "st_atime": now, "st_uid": os.getuid(), "st_gid": os.getgid()}

        def access(self, path, mode): return 0
        def statfs(self, path):
            return {"f_bsize": 4096, "f_blocks": 2**40, "f_bfree": 2**40,
                    "f_bavail": 2**40, "f_files": 0, "f_ffree": 0}


# ── Mount lifecycle ────────────────────────────────────────────────────────────

def start_fuse_mount(mount_point: str, ad_client, loop) -> Optional[threading.Thread]:
    global _mount_point, _ad_client, _event_loop

    if not FUSE_AVAILABLE:
        log.warning("FUSE not available — skipping mount")
        return None

    _ad_client   = ad_client
    _event_loop  = loop
    _mount_point = mount_point

    # decypharr: always force-unmount before mounting
    if _is_mounted(mount_point):
        log.info(f"Stale mount at {mount_point} — cleaning up")
        _force_unmount(mount_point)
        time.sleep(0.5)

    Path(mount_point).mkdir(parents=True, exist_ok=True)

    # Signal handlers — clean unmount on container stop (decypharr pattern)
    def _sig(signum, frame):
        log.info(f"Signal {signum} — unmounting FUSE")
        stop_fuse_mount()
        signal.signal(signum, signal.SIG_DFL)
        os.kill(os.getpid(), signum)

    signal.signal(signal.SIGTERM, _sig)
    signal.signal(signal.SIGINT,  _sig)

    fs = AllDebridFS()

    def _run():
        try:
            log.info(f"🗂️  Mounting FUSE at {mount_point}")
            FUSE(fs, mount_point,
                 nothreads=False,
                 foreground=True,
                 ro=True,
                 allow_other=True,
                 big_writes=True,
                 max_read=131072)
        except Exception as e:
            log.error(f"FUSE mount error: {e}", exc_info=True)

    t = threading.Thread(target=_run, name="fuse", daemon=True)
    t.start()

    for _ in range(10):
        time.sleep(0.5)
        if _is_mounted(mount_point):
            log.info(f"✅ FUSE mounted at {mount_point}")
            return t

    log.error(f"❌ FUSE did not mount at {mount_point}")
    return None


def stop_fuse_mount(mount_point: str = None):
    mp = mount_point or _mount_point
    if mp and _is_mounted(mp):
        _force_unmount(mp)
