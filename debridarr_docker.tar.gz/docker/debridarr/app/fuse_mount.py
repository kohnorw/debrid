"""
AllDebrid FUSE filesystem with DFS disk chunk cache.
"""

import errno
import hashlib
import logging
import os
import signal
import stat
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Optional

import httpx

log = logging.getLogger("debridarr.fuse")

# ── Lazy fusepy load ───────────────────────────────────────────────────────────
FUSE_AVAILABLE = False
FUSE = FuseOSError = Operations = None

def _load_fuse():
    global FUSE_AVAILABLE, FUSE, FuseOSError, Operations
    try:
        from fuse import FUSE as _F, FuseOSError as _E, Operations as _O
        FUSE, FuseOSError, Operations = _F, _E, _O
        FUSE_AVAILABLE = True
    except Exception as e:
        log.warning(f"FUSE not available: {e}")

_load_fuse()

# ── Torrent registry ───────────────────────────────────────────────────────────
_torrents: dict[str, dict] = {}
_torrents_lock = threading.Lock()

# ── CDN URL cache ──────────────────────────────────────────────────────────────
_cdn_cache: dict[str, tuple[str, float]] = {}
_cdn_lock = threading.Lock()

# ── DFS settings ───────────────────────────────────────────────────────────────
_dfs = {
    "cache_dir":          "/tmp/cache",
    "disk_cache_size_gb": 30,
    "cache_expiry_h":     24,
    "chunk_size_mb":      8,
    "read_ahead_mb":      500,
    "cleanup_interval_m": 20,
}
_dfs_lock = threading.Lock()

# ── Module state ──────────────────────────────────────────────────────────────
_mount_point: Optional[str] = None
_ad_client   = None
_event_loop  = None
_prefetch_pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="prefetch")


def update_dfs_settings(s: dict):
    with _dfs_lock:
        _dfs.update(s)


def get_dfs_settings() -> dict:
    with _dfs_lock:
        return dict(_dfs)


def get_fuse_path(torrent_name: str, filename: str, mount_point: str) -> Path:
    return Path(mount_point) / torrent_name / filename


def register_torrent(torrent_name: str, files: list):
    with _torrents_lock:
        _torrents[torrent_name] = {"files": {f["n"]: f for f in files}}
    log.info(f"📂 FUSE: {torrent_name} ({len(files)} files)")


def unregister_torrent(torrent_name: str):
    with _torrents_lock:
        _torrents.pop(torrent_name, None)
    log.info(f"🗑️  FUSE: unregistered {torrent_name}")


def get_torrent_file(torrent_name: str, filename: str) -> Optional[dict]:
    with _torrents_lock:
        t = _torrents.get(torrent_name)
        return t["files"].get(filename) if t else None


def list_torrents() -> list:
    with _torrents_lock:
        return list(_torrents.keys())


def list_files(torrent_name: str) -> list:
    with _torrents_lock:
        t = _torrents.get(torrent_name, {})
        return list(t.get("files", {}).keys())


# ── DFS chunk cache ────────────────────────────────────────────────────────────

def _chunk_path(ad_link: str, chunk_idx: int) -> Path:
    with _dfs_lock:
        cache_dir = Path(_dfs["cache_dir"])
    cache_dir.mkdir(parents=True, exist_ok=True)
    h = hashlib.md5(ad_link.encode()).hexdigest()[:16]
    return cache_dir / f"{h}_{chunk_idx}"


def _read_chunk(ad_link: str, chunk_idx: int) -> Optional[bytes]:
    p = _chunk_path(ad_link, chunk_idx)
    try:
        if p.exists():
            p.touch()
            return p.read_bytes()
    except Exception:
        pass
    return None


def _write_chunk(ad_link: str, chunk_idx: int, data: bytes):
    try:
        _chunk_path(ad_link, chunk_idx).write_bytes(data)
    except Exception:
        pass


def _cleanup_cache():
    with _dfs_lock:
        cache_dir = Path(_dfs["cache_dir"])
        expiry_s  = _dfs["cache_expiry_h"] * 3600
        max_bytes = _dfs["disk_cache_size_gb"] * 1024**3
    if not cache_dir.exists():
        return
    now = time.time()
    chunks = []
    for p in cache_dir.iterdir():
        if not p.is_file():
            continue
        try:
            atime = p.stat().st_atime
            if now - atime > expiry_s:
                p.unlink(missing_ok=True)
            else:
                chunks.append((atime, p.stat().st_size, p))
        except Exception:
            pass
    chunks.sort(key=lambda x: x[0])
    total = sum(s for _, s, _ in chunks)
    for _, size, p in chunks:
        if total <= max_bytes:
            break
        try:
            p.unlink(missing_ok=True)
            total -= size
        except Exception:
            pass


def _start_cleanup_thread():
    def _loop():
        while True:
            with _dfs_lock:
                interval = _dfs["cleanup_interval_m"] * 60
            time.sleep(interval)
            try:
                _cleanup_cache()
            except Exception:
                pass
    t = threading.Thread(target=_loop, name="dfs-cleanup", daemon=True)
    t.start()


# ── CDN URL ───────────────────────────────────────────────────────────────────

def _get_cdn_url(ad_link: str) -> Optional[str]:
    with _cdn_lock:
        cached = _cdn_cache.get(ad_link)
        if cached and time.time() - cached[1] < 4 * 3600:
            return cached[0]
    if not _ad_client or not _event_loop:
        return None
    import asyncio
    try:
        fut = asyncio.run_coroutine_threadsafe(
            _ad_client.unlock_file(ad_link), _event_loop)
        url = fut.result(timeout=30)
        if url:
            with _cdn_lock:
                _cdn_cache[ad_link] = (url, time.time())
            return url
    except Exception as e:
        log.error(f"unlock_file failed: {e}")
    return None


def _invalidate_cdn(ad_link: str):
    with _cdn_lock:
        _cdn_cache.pop(ad_link, None)


# ── Force unmount ──────────────────────────────────────────────────────────────

def _force_unmount(path: str):
    for cmd in [
        ["fusermount", "-uz", path],
        ["fusermount3", "-uz", path],
        ["umount", "-l", path],
        ["umount", path],
    ]:
        try:
            if subprocess.run(cmd, capture_output=True, timeout=5).returncode == 0:
                log.info(f"Unmounted {path} via {cmd[0]}")
                return
        except Exception:
            continue


def _is_mounted(path: str) -> bool:
    try:
        with open("/proc/mounts") as f:
            return any(path in line for line in f)
    except Exception:
        return False


# ── FUSE filesystem ────────────────────────────────────────────────────────────

if FUSE_AVAILABLE:

    class AllDebridFS(Operations):

        def __init__(self):
            self._http = httpx.Client(timeout=120, follow_redirects=True)

        def getattr(self, path, fh=None):
            now = int(time.time())
            parts = [p for p in path.split("/") if p]
            if not parts:
                return self._dstat(now)
            if len(parts) == 1:
                if parts[0] in list_torrents():
                    return self._dstat(now)
                raise FuseOSError(errno.ENOENT)
            if len(parts) == 2:
                f = get_torrent_file(parts[0], parts[1])
                if f:
                    return self._fstat(now, f.get("s", 0))
                raise FuseOSError(errno.ENOENT)
            raise FuseOSError(errno.ENOENT)

        def readdir(self, path, fh):
            parts = [p for p in path.split("/") if p]
            yield "."; yield ".."
            if not parts:
                yield from list_torrents()
            elif len(parts) == 1:
                yield from list_files(parts[0])

        def open(self, path, flags):
            return 0

        def read(self, path, size, offset, fh):
            parts = [p for p in path.split("/") if p]
            if len(parts) != 2:
                raise FuseOSError(errno.ENOENT)
            torrent_name, filename = parts
            f = get_torrent_file(torrent_name, filename)
            if not f:
                raise FuseOSError(errno.ENOENT)
            ad_link = f.get("l", "")
            if not ad_link:
                raise FuseOSError(errno.EIO)

            with _dfs_lock:
                chunk_bytes = _dfs["chunk_size_mb"] * 1024 * 1024
                read_ahead  = _dfs["read_ahead_mb"] * 1024 * 1024

            chunk_idx = offset // chunk_bytes
            chunk_off = offset % chunk_bytes
            result    = b""

            while len(result) < size:
                chunk = self._get_chunk(ad_link, chunk_idx, chunk_bytes)
                if not chunk:
                    break
                piece = chunk[chunk_off: chunk_off + (size - len(result))]
                result += piece
                if len(piece) < len(chunk) - chunk_off:
                    break
                chunk_idx += 1
                chunk_off  = 0

            # Background read-ahead
            ahead = read_ahead // chunk_bytes
            _prefetch_pool.submit(self._prefetch, ad_link, chunk_idx, int(ahead), chunk_bytes)

            return result

        def _get_chunk(self, ad_link: str, chunk_idx: int, chunk_bytes: int) -> Optional[bytes]:
            cached = _read_chunk(ad_link, chunk_idx)
            if cached is not None:
                return cached
            url = _get_cdn_url(ad_link)
            if not url:
                return None
            start = chunk_idx * chunk_bytes
            end   = start + chunk_bytes - 1
            for attempt in range(2):
                try:
                    r = self._http.get(url, headers={"Range": f"bytes={start}-{end}"})
                    if r.status_code in (200, 206):
                        _write_chunk(ad_link, chunk_idx, r.content)
                        return r.content
                    if r.status_code in (403, 410) and attempt == 0:
                        _invalidate_cdn(ad_link)
                        url = _get_cdn_url(ad_link) or url
                        continue
                    return None
                except Exception:
                    if attempt == 0:
                        continue
                    return None
            return None

        def _prefetch(self, ad_link: str, start_chunk: int, num_chunks: int, chunk_bytes: int):
            for i in range(num_chunks):
                if _read_chunk(ad_link, start_chunk + i) is None:
                    self._get_chunk(ad_link, start_chunk + i, chunk_bytes)

        def _dstat(self, now):
            return {"st_mode": stat.S_IFDIR | 0o755, "st_nlink": 2,
                    "st_size": 4096, "st_ctime": now, "st_mtime": now,
                    "st_atime": now, "st_uid": os.getuid(), "st_gid": os.getgid()}

        def _fstat(self, now, size):
            return {"st_mode": stat.S_IFREG | 0o444, "st_nlink": 1,
                    "st_size": size, "st_ctime": now, "st_mtime": now,
                    "st_atime": now, "st_uid": os.getuid(), "st_gid": os.getgid()}

        def access(self, path, mode): return 0
        def statfs(self, path):
            with _dfs_lock:
                max_b = _dfs["disk_cache_size_gb"] * 1024**3
            blocks = max_b // 4096
            return {"f_bsize": 4096, "f_blocks": blocks, "f_bfree": blocks,
                    "f_bavail": blocks, "f_files": 0, "f_ffree": 0}


# ── Mount lifecycle ────────────────────────────────────────────────────────────

def start_fuse_mount(mount_point: str, ad_client, loop) -> Optional[threading.Thread]:
    global _mount_point, _ad_client, _event_loop

    if not FUSE_AVAILABLE:
        log.warning("FUSE not available")
        return None

    _ad_client   = ad_client
    _event_loop  = loop
    _mount_point = mount_point

    if _is_mounted(mount_point):
        log.info(f"Stale mount at {mount_point} — cleaning up")
        _force_unmount(mount_point)
        time.sleep(0.5)

    Path(mount_point).mkdir(parents=True, exist_ok=True)
    _start_cleanup_thread()

    def _sig(signum, frame):
        log.info(f"Signal {signum} — unmounting")
        stop_fuse_mount()
        signal.signal(signum, signal.SIG_DFL)
        os.kill(os.getpid(), signum)

    signal.signal(signal.SIGTERM, _sig)
    signal.signal(signal.SIGINT,  _sig)

    fs = AllDebridFS()

    def _run():
        try:
            log.info(f"🗂️  Mounting FUSE at {mount_point}")
            FUSE(fs, mount_point,
                 nothreads=False, foreground=True, ro=True,
                 allow_other=True, big_writes=True, max_read=131072)
        except Exception as e:
            log.error(f"FUSE error: {e}", exc_info=True)

    t = threading.Thread(target=_run, name="fuse", daemon=True)
    t.start()

    for _ in range(10):
        time.sleep(0.5)
        if _is_mounted(mount_point):
            log.info(f"✅ FUSE mounted at {mount_point}")
            return t

    log.error(f"❌ FUSE failed to mount at {mount_point}")
    return None


def stop_fuse_mount(mount_point: str = None):
    mp = mount_point or _mount_point
    if mp and _is_mounted(mp):
        _force_unmount(mp)
