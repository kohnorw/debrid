"""
AllDebrid FUSE filesystem for Debridarr.

Mounts AllDebrid as a virtual filesystem at /mnt/alldebrid so Plex can
stream files directly without any proxy layer. Symlinks in the Plex library
point into this mount.

Flow:
  1. User plays something → Tautulli fires → Debridarr resolves torrent
  2. Debridarr unlocks the magnet → gets a list of (filename, direct_url) pairs
  3. Debridarr writes a symlink:
       /plex-strm/movies/Inception (2010)/Inception (2010).mp4
       → /mnt/alldebrid/movie_inception_2010/Inception.2010.1080p.mkv
  4. FUSE mount handles /mnt/alldebrid/* — each read() fetches bytes from
     the AllDebrid CDN URL with proper Range headers
  5. Plex streams natively — no proxy, no URL expiry visible to Plex,
     seeking works via HTTP Range

The FUSE filesystem is read-only and lazy — it only fetches bytes when
Plex actually reads them, and refreshes the AllDebrid URL on 403/410.
"""

import asyncio
import errno
import logging
import os
import stat
import threading
import time
from pathlib import Path
from typing import Optional

log = logging.getLogger("debridarr.fuse")

try:
    import fuse
    from fuse import FUSE, FuseOSError, Operations
    FUSE_AVAILABLE = True
except ImportError:
    FUSE_AVAILABLE = False
    log.warning("fusepy not installed — FUSE mount unavailable")

import httpx


# ── Virtual file registry ──────────────────────────────────────────────────────
# cache_key → {"url": str, "size": int, "name": str, "refreshed_at": float}
_registry: dict[str, dict] = {}
_registry_lock = threading.Lock()


def register_file(cache_key: str, url: str, name: str, size: int = 0):
    """Register an AllDebrid URL so the FUSE FS can serve it."""
    with _registry_lock:
        _registry[cache_key] = {
            "url":          url,
            "name":         name,
            "size":         size,
            "refreshed_at": time.time(),
        }
    log.info(f"📂 FUSE registered: {cache_key} → {name}")


def unregister_file(cache_key: str):
    with _registry_lock:
        _registry.pop(cache_key, None)


def get_fuse_path(cache_key: str, name: str, mount_point: str) -> Path:
    """Return the virtual path inside the FUSE mount for a cache key."""
    return Path(mount_point) / cache_key / name


# ── FUSE filesystem ────────────────────────────────────────────────────────────

if FUSE_AVAILABLE:
    class AllDebridFS(Operations):
        """
        Read-only FUSE filesystem backed by AllDebrid CDN URLs.

        Directory structure:
          /                        — root
          /<cache_key>/            — one dir per resolved media item
          /<cache_key>/<filename>  — the actual video file (virtual)
        """

        def __init__(self, alldebrid_client, loop):
            self._ad   = alldebrid_client
            self._loop = loop
            self._http = httpx.Client(timeout=30, follow_redirects=True)

        # ── Filesystem metadata ────────────────────────────────────────────────

        def getattr(self, path: str, fh=None):
            now = int(time.time())
            parts = [p for p in path.split("/") if p]

            if len(parts) == 0:
                # Root directory
                return self._dir_stat(now)

            if len(parts) == 1:
                # cache_key directory
                with _registry_lock:
                    if parts[0] in _registry:
                        return self._dir_stat(now)
                raise FuseOSError(errno.ENOENT)

            if len(parts) == 2:
                # Virtual file
                cache_key, filename = parts
                with _registry_lock:
                    entry = _registry.get(cache_key)
                if entry and entry["name"] == filename:
                    size = entry.get("size", 0)
                    if size == 0:
                        size = self._probe_size(entry["url"])
                        with _registry_lock:
                            if cache_key in _registry:
                                _registry[cache_key]["size"] = size
                    return self._file_stat(now, size)
                raise FuseOSError(errno.ENOENT)

            raise FuseOSError(errno.ENOENT)

        def readdir(self, path: str, fh):
            parts = [p for p in path.split("/") if p]
            yield "."
            yield ".."

            if len(parts) == 0:
                with _registry_lock:
                    for key in list(_registry.keys()):
                        yield key

            elif len(parts) == 1:
                cache_key = parts[0]
                with _registry_lock:
                    entry = _registry.get(cache_key)
                if entry:
                    yield entry["name"]

        # ── File reading ────────────────────────────────────────────────────────

        def open(self, path: str, flags):
            return 0  # no real file handles needed

        def read(self, path: str, size: int, offset: int, fh) -> bytes:
            parts = [p for p in path.split("/") if p]
            if len(parts) != 2:
                raise FuseOSError(errno.ENOENT)

            cache_key, filename = parts
            with _registry_lock:
                entry = _registry.get(cache_key)
            if not entry or entry["name"] != filename:
                raise FuseOSError(errno.ENOENT)

            url = entry["url"]
            return self._fetch_range(url, offset, offset + size - 1, cache_key)

        def _fetch_range(self, url: str, start: int, end: int, cache_key: str) -> bytes:
            """Fetch a byte range from AllDebrid CDN. Refreshes URL on 403/410."""
            headers = {"Range": f"bytes={start}-{end}"}
            for attempt in range(2):
                try:
                    resp = self._http.get(url, headers=headers, timeout=30)
                    if resp.status_code in (200, 206):
                        return resp.content
                    if resp.status_code in (403, 410) and attempt == 0:
                        log.warning(f"AllDebrid URL expired for {cache_key}, refreshing...")
                        url = self._refresh_url(cache_key)
                        if not url:
                            raise FuseOSError(errno.EIO)
                        continue
                    log.error(f"FUSE read failed: HTTP {resp.status_code} for {cache_key}")
                    raise FuseOSError(errno.EIO)
                except httpx.RequestError as e:
                    if attempt == 0:
                        continue
                    log.error(f"FUSE network error: {e}")
                    raise FuseOSError(errno.EIO)
            raise FuseOSError(errno.EIO)

        def _refresh_url(self, cache_key: str) -> Optional[str]:
            """Re-unlock the magnet to get a fresh URL. Runs sync via the event loop."""
            with _registry_lock:
                entry = _registry.get(cache_key)
            if not entry or "magnet" not in entry:
                return None
            try:
                future = asyncio.run_coroutine_threadsafe(
                    self._ad.unlock_magnet(entry["magnet"]), self._loop
                )
                new_url = future.result(timeout=30)
                if new_url:
                    with _registry_lock:
                        if cache_key in _registry:
                            _registry[cache_key]["url"] = new_url
                            _registry[cache_key]["refreshed_at"] = time.time()
                return new_url
            except Exception as e:
                log.error(f"URL refresh failed for {cache_key}: {e}")
                return None

        def _probe_size(self, url: str) -> int:
            """HEAD request to get Content-Length."""
            try:
                resp = self._http.head(url, timeout=10)
                cl = resp.headers.get("content-length", "0")
                return int(cl)
            except Exception:
                return 0

        # ── Stat helpers ────────────────────────────────────────────────────────

        def _dir_stat(self, now: int) -> dict:
            return {
                "st_mode":  stat.S_IFDIR | 0o555,
                "st_nlink": 2,
                "st_size":  0,
                "st_ctime": now,
                "st_mtime": now,
                "st_atime": now,
                "st_uid":   os.getuid(),
                "st_gid":   os.getgid(),
            }

        def _file_stat(self, now: int, size: int) -> dict:
            return {
                "st_mode":  stat.S_IFREG | 0o444,
                "st_nlink": 1,
                "st_size":  size,
                "st_ctime": now,
                "st_mtime": now,
                "st_atime": now,
                "st_uid":   os.getuid(),
                "st_gid":   os.getgid(),
            }

        # ── Required no-ops ─────────────────────────────────────────────────────
        def access(self, path, mode): return 0
        def statfs(self, path):
            return {"f_bsize": 512, "f_blocks": 0, "f_bfree": 0, "f_bavail": 0,
                    "f_files": 0, "f_ffree": 0}


def start_fuse_mount(mount_point: str, alldebrid_client, loop) -> Optional[threading.Thread]:
    """
    Start the FUSE filesystem in a background thread.
    Returns the thread or None if FUSE is not available.
    """
    if not FUSE_AVAILABLE:
        log.warning("FUSE not available — install fusepy and libfuse2")
        return None

    mp = Path(mount_point)
    mp.mkdir(parents=True, exist_ok=True)

    def _run():
        try:
            log.info(f"🗂️  Starting FUSE mount at {mount_point}")
            FUSE(
                AllDebridFS(alldebrid_client, loop),
                str(mount_point),
                nothreads=False,
                foreground=True,
                ro=True,
                allow_other=True,   # lets Plex (different user) read the mount
            )
        except Exception as e:
            log.error(f"FUSE mount failed: {e}", exc_info=True)

    t = threading.Thread(target=_run, name="fuse-mount", daemon=True)
    t.start()
    time.sleep(0.5)  # give FUSE a moment to initialise
    log.info(f"✅ FUSE mount started at {mount_point}")
    return t


def stop_fuse_mount(mount_point: str):
    """Unmount the FUSE filesystem."""
    try:
        os.system(f"fusermount -u {mount_point} 2>/dev/null || umount {mount_point} 2>/dev/null")
        log.info(f"🗂️  FUSE unmounted: {mount_point}")
    except Exception as e:
        log.warning(f"FUSE unmount failed: {e}")
