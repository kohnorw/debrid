"""
SQLite cache for Debridarr.
Two tables:
  cache        — resolved AllDebrid links (30-day TTL)
  fake_library — items added to the Plex placeholder library
"""

import sqlite3
import logging
from datetime import datetime, timedelta
from typing import Optional
from app.models import PlayEvent, MediaType

log = logging.getLogger("debridarr.cache")

TTL_DAYS = 30


class CacheDB:
    def __init__(self, db_path: str):
        self.db_path = db_path

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        return conn

    def init(self):
        with self._connect() as conn:
            # ── Resolved link cache ──────────────────────────────────────────
            conn.execute("""
                CREATE TABLE IF NOT EXISTS cache (
                    cache_key         TEXT PRIMARY KEY,
                    media_type        TEXT NOT NULL,
                    title             TEXT NOT NULL,
                    year              INTEGER,
                    season            INTEGER,
                    episode           INTEGER,
                    quality           TEXT,
                    torrent_name      TEXT,
                    magnet_link       TEXT,
                    stream_url        TEXT,
                    strm_path         TEXT,
                    status            TEXT NOT NULL DEFAULT 'pending',
                    link_refreshed_at TEXT,
                    created_at        TEXT NOT NULL,
                    expires_at        TEXT NOT NULL,
                    last_accessed     TEXT
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_cache_expires ON cache(expires_at)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_cache_status  ON cache(status)")

            # Migration: add strm_path if upgrading from v0.1
            existing_cols = {r[1] for r in conn.execute("PRAGMA table_info(cache)").fetchall()}
            if "strm_path" not in existing_cols:
                conn.execute("ALTER TABLE cache ADD COLUMN strm_path TEXT")
                log.info("Migrated cache table: added strm_path column")

            # ── Fake library ─────────────────────────────────────────────────
            conn.execute("""
                CREATE TABLE IF NOT EXISTS fake_library (
                    id            INTEGER PRIMARY KEY AUTOINCREMENT,
                    media_type    TEXT NOT NULL,
                    title         TEXT NOT NULL,
                    year          INTEGER,
                    sonarr_id     INTEGER,
                    radarr_id     INTEGER,
                    tvdb_id       INTEGER,
                    tmdb_id       INTEGER,
                    imdb_id       TEXT,
                    season_count  INTEGER,
                    fake_path     TEXT,
                    added_at      TEXT NOT NULL,
                    UNIQUE(media_type, title, year)
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_fake_type ON fake_library(media_type)")

            # App behaviour settings (not infrastructure — stored in DB, not .env)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS app_settings (
                    key   TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                )
            """)
            # Defaults
            conn.execute("""
                INSERT OR IGNORE INTO app_settings (key, value)
                VALUES ('include_unreleased_episodes', 'false')
            """)

        log.info(f"Cache DB ready at {self.db_path}")

    # ── Cache reads ────────────────────────────────────────────────────────────

    def get(self, cache_key: str) -> Optional[dict]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM cache WHERE cache_key = ?", (cache_key,)
            ).fetchone()
            if not row:
                return None
            conn.execute(
                "UPDATE cache SET last_accessed = ? WHERE cache_key = ?",
                (datetime.utcnow().isoformat(), cache_key),
            )
            return dict(row)

    def list_all(self) -> list[dict]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM cache ORDER BY created_at DESC"
            ).fetchall()
            return [dict(r) for r in rows]

    def list_expired(self) -> list[dict]:
        now = datetime.utcnow().isoformat()
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM cache WHERE expires_at < ?", (now,)
            ).fetchall()
            return [dict(r) for r in rows]

    # ── Cache writes ───────────────────────────────────────────────────────────

    def upsert(self, cache_key: str, event: PlayEvent, status: str = "pending"):
        now = datetime.utcnow()
        expires = now + timedelta(days=TTL_DAYS)
        with self._connect() as conn:
            conn.execute("""
                INSERT INTO cache
                    (cache_key, media_type, title, year, season, episode, status, created_at, expires_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(cache_key) DO UPDATE SET
                    status = excluded.status,
                    last_accessed = ?
            """, (
                cache_key,
                event.media_type.value,
                event.title,
                event.year,
                event.season,
                event.episode,
                status,
                now.isoformat(),
                expires.isoformat(),
                now.isoformat(),
            ))

    def update_status(self, cache_key: str, status: str):
        with self._connect() as conn:
            conn.execute(
                "UPDATE cache SET status = ? WHERE cache_key = ?",
                (status, cache_key),
            )

    def update_cached(
        self,
        cache_key: str,
        magnet: str,
        stream_url: str,
        torrent_name: str,
        quality: str,
        strm_path: Optional[str] = None,
    ):
        now = datetime.utcnow()
        expires = now + timedelta(days=TTL_DAYS)
        with self._connect() as conn:
            conn.execute("""
                UPDATE cache SET
                    status            = 'cached',
                    magnet_link       = ?,
                    stream_url        = ?,
                    torrent_name      = ?,
                    quality           = ?,
                    strm_path         = ?,
                    link_refreshed_at = ?,
                    expires_at        = ?
                WHERE cache_key = ?
            """, (
                magnet, stream_url, torrent_name, quality,
                strm_path, now.isoformat(), expires.isoformat(), cache_key,
            ))

    def update_stream_url(self, cache_key: str, stream_url: str):
        now = datetime.utcnow()
        with self._connect() as conn:
            conn.execute(
                "UPDATE cache SET stream_url = ?, link_refreshed_at = ? WHERE cache_key = ?",
                (stream_url, now.isoformat(), cache_key),
            )

    def delete(self, cache_key: str):
        with self._connect() as conn:
            conn.execute("DELETE FROM cache WHERE cache_key = ?", (cache_key,))

    def purge_expired(self) -> int:
        now = datetime.utcnow().isoformat()
        with self._connect() as conn:
            result = conn.execute(
                "DELETE FROM cache WHERE expires_at < ?", (now,)
            )
            return result.rowcount

    # ── App settings ──────────────────────────────────────────────────────────────

    def get_setting(self, key: str, default: str = "") -> str:
        with self._connect() as conn:
            row = conn.execute("SELECT value FROM app_settings WHERE key=?", (key,)).fetchone()
            return row[0] if row else default

    def set_setting(self, key: str, value: str):
        with self._connect() as conn:
            conn.execute("INSERT OR REPLACE INTO app_settings (key, value) VALUES (?,?)", (key, value))

    def get_all_settings(self) -> dict:
        with self._connect() as conn:
            rows = conn.execute("SELECT key, value FROM app_settings").fetchall()
            return {r[0]: r[1] for r in rows}

    # ── Fake library ───────────────────────────────────────────────────────────────

    def fake_library_add(self, entry: dict) -> bool:
        now = datetime.utcnow().isoformat()
        try:
            with self._connect() as conn:
                conn.execute("""
                    INSERT INTO fake_library
                        (media_type, title, year, sonarr_id, radarr_id,
                         tvdb_id, tmdb_id, imdb_id, season_count, fake_path, added_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(media_type, title, year) DO UPDATE SET
                        fake_path = excluded.fake_path,
                        added_at  = excluded.added_at
                """, (
                    entry["media_type"],
                    entry["title"],
                    entry.get("year"),
                    entry.get("sonarr_id"),
                    entry.get("radarr_id"),
                    entry.get("tvdb_id"),
                    entry.get("tmdb_id"),
                    entry.get("imdb_id"),
                    entry.get("season_count"),
                    entry.get("fake_path"),
                    now,
                ))
            return True
        except Exception as e:
            log.error(f"fake_library_add failed: {e}")
            return False

    def fake_library_remove(self, media_type: str, title: str, year: Optional[int]) -> bool:
        with self._connect() as conn:
            conn.execute(
                "DELETE FROM fake_library WHERE media_type=? AND title=? AND year IS ?",
                (media_type, title, year),
            )
        return True

    def fake_library_list(self, media_type: Optional[str] = None) -> list[dict]:
        with self._connect() as conn:
            if media_type:
                rows = conn.execute(
                    "SELECT * FROM fake_library WHERE media_type=? ORDER BY title",
                    (media_type,),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM fake_library ORDER BY media_type, title"
                ).fetchall()
            return [dict(r) for r in rows]

    def fake_library_get(self, media_type: str, title: str, year: Optional[int]) -> Optional[dict]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM fake_library WHERE media_type=? AND title=? AND year IS ?",
                (media_type, title, year),
            ).fetchone()
            return dict(row) if row else None
