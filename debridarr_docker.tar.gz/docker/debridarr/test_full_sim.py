"""
Full simulation — directly calls every critical endpoint function
with a mock Request/state. No ASGI, no network, no Docker needed.
Proves the settings page crash is fixed before packaging.
"""
import asyncio, sys, os, json, tempfile, re, traceback
sys.path.insert(0, "/home/claude/debridarr")
os.chdir("/home/claude/debridarr")

PASS = 0; FAIL = 0

def ok(n, d=""): global PASS; PASS += 1; print(f"  ✅ {n}" + (f" ({d})" if d else ""))
def fail(n, d=""): global FAIL; FAIL += 1; print(f"  ❌ {n}" + (f" — {d}" if d else ""))

# ── Build fake state ─────────────────────────────────────────────────────────
from app.cache import CacheDB
from app.models import MediaType, PlayEvent
import app.main as M

db_file = tempfile.mktemp(suffix=".db")
db = CacheDB(db_file)
db.init()
# Seed settings that contain curly-brace template values — this is what triggers the crash
db.set_setting("alldebrid_api_key",  "test_key_abc")
db.set_setting("plex_root",          "/tmp/test-plex")
db.set_setting("template_movie",     "{title} {year}")
db.set_setting("template_episode",   "{title} S{season}E{episode}")
db.set_setting("template_season_pack","{title} S{season}")
db.set_setting("template_series_pack","{title}")
db.set_setting("no_cam",             "true")
db.set_setting("precache_enabled",   "true")
db.set_setting("auto_add",           "false")
db.set_setting("english_only",       "false")
db.set_setting("include_unreleased_episodes","false")
db.set_setting("search_min_seeders", "1")
db.set_setting("search_max_results", "5")
db.set_setting("cache_ttl_days",     "30")

os.makedirs("/tmp/test-plex/movies", exist_ok=True)
os.makedirs("/tmp/test-plex/tv", exist_ok=True)

# Add library entries (some with potential None fields)
db.fake_library_add({"media_type":"movie","title":"Dune Part Two","year":2024,
    "poster_url":"","overview":"","status":"movie","fake_path":None})
db.fake_library_add({"media_type":"series","title":"Breaking Bad","year":2008,
    "poster_url":"","overview":"","status":"continuing","season_count":5,"fake_path":None})
# Edge case: title with apostrophe
db.fake_library_add({"media_type":"movie","title":"It's a Wonderful Life","year":1946,
    "poster_url":"","overview":"","status":"movie","fake_path":None})

class FakeAD:
    api_key = "test_key_abc"
    async def search_cached(self, **kw): return []
    async def add_magnet(self, m): return None
    async def unlock_file(self, l): return "https://cdn.test/file.mkv"
    async def delete_magnet(self, i): pass
    async def get_all_torrents(self): return []
    async def aclose(self): pass

class FakeLM:
    url = ""; plex_root = "/tmp/test-plex"
    async def get_radarr_movies(self): return []
    async def get_sonarr_series(self): return []
    async def get_episodes(self, *a, **kw): return []
    def create_fake_episodes(self, *a): pass
    def remove_fake_movie(self, *a): pass
    def remove_fake_series(self, *a): pass

class FakeSettings:
    PLEX_ROOT = "/tmp/test-plex"; ALLDEBRID_API_KEY = "test"
    OVERSEERR_URL = ""; OVERSEERR_API_KEY = ""; DEBRIDARR_BASE_URL = ""
    DB_PATH = db_file; FUSE_MOUNT = "/mnt/fake"; FUSE_SYMLINK_ROOT = "/tmp/fuse"
    LOG_LEVEL = "INFO"; PORT = 7474

class FakePool:
    def stats(self): return {"max_workers":3,"running":0,"queued":0,"done":0,"failed":0,"cancelled":0,"workers":[]}
    def set_max_workers(self, n): pass
    async def enqueue(self, label, fn): return "wid_test"
    def is_already_queued(self, label): return False

class FakeState:
    db = db; settings = FakeSettings(); alldebrid = FakeAD()
    library = FakeLM(); worker_pool = FakePool(); setup_complete = True

class FakeApp:
    state = FakeState()

class FakeBT:
    def __init__(self): self.tasks = []
    def add_task(self, fn, *a, **kw): self.tasks.append(fn)

def req(body=None, params=None):
    class R:
        app = FakeApp()
        query_params = params or {}
        url = type("U",(),{"path":"/test"})()
        async def json(self): return body or {}
        async def form(self): return body or {}
    return R()

M._needs_setup = lambda r: False
M.load_saved_config = lambda: {
    "ALLDEBRID_API_KEY":"test","PLEX_ROOT":"/tmp/test-plex",
    "OVERSEERR_URL":"","OVERSEERR_API_KEY":"",
    "TMDB_API_KEY":"","DEBRIDARR_BASE_URL":"",
    "TAUTULLI_URL":"","TAUTULLI_API_KEY":"",
    "TZ":"UTC","PUID":"1000","PGID":"1000",
}

def status(r):
    if hasattr(r, "status_code"): return r.status_code
    return 200

def body_json(r):
    if hasattr(r, "body"):
        try: return json.loads(r.body)
        except: return {}
    if isinstance(r, dict): return r
    return {}

async def run():

    # ═══════════════════════════════════════════════════════════════════════
    # SECTION 1: Settings page — the crash fix
    # ═══════════════════════════════════════════════════════════════════════
    print("\n── Settings page (crash fix) ──")

    # Prove json.dumps survives template curly braces
    all_settings = db.get_all_settings()
    try:
        _ss_json = json.dumps(all_settings)
        parsed   = json.loads(_ss_json)
        assert parsed.get("template_movie") == "{title} {year}", "template_movie wrong"
        assert parsed.get("template_episode") == "{title} S{season}E{episode}"
        ok("json.dumps of template settings with {curly} braces produces valid JSON",
           f"template_movie={parsed['template_movie']!r}")
    except Exception as e:
        fail("json.dumps of template settings", str(e))

    # Directly call settings_page and check it doesn't crash
    try:
        r = await M.settings_page(req())
        sc = status(r)
        if sc == 200:
            content = r.body.decode() if hasattr(r.body,'decode') else str(r.body)
            if "const _SS =" in content and "template_movie" in content:
                ok("settings_page() returns 200 with _SS containing template settings")
            elif sc == 200:
                ok("settings_page() returns 200", "(_SS check skipped)")
            else:
                fail("settings_page() _SS missing from output")
        else:
            fail("settings_page() status", f"got {sc}")
    except Exception as e:
        fail("settings_page() crashed", traceback.format_exc().splitlines()[-1])

    # ═══════════════════════════════════════════════════════════════════════
    # SECTION 2: All toggle endpoints
    # ═══════════════════════════════════════════════════════════════════════
    print("\n── Settings toggles ──")
    from fastapi import HTTPException
    for key, val, label in [
        ("precache_enabled",            "true",  "⚡ Pre-caching ON"),
        ("precache_enabled",            "false", "⚡ Pre-caching OFF"),
        ("auto_add",                    "true",  "🤖 Auto-add ON"),
        ("auto_add",                    "false", "🤖 Auto-add OFF"),
        ("english_only",                "true",  "🇬🇧 English-only ON"),
        ("no_cam",                      "true",  "🚫 CAM filter ON"),
        ("no_cam",                      "false", "🚫 CAM filter OFF"),
        ("include_unreleased_episodes", "true",  "📅 Unreleased episodes ON"),
        ("include_unreleased_episodes", "false", "📅 Unreleased episodes OFF"),
    ]:
        try:
            r = await M.api_settings_behaviour(req({"key":key,"value":val}), FakeBT())
            d = body_json(r)
            saved = db.get_setting(key,"")
            if d.get("status")=="ok" and saved==val:
                ok(f"Toggle {label}", f"persisted={saved!r}")
            else:
                fail(f"Toggle {label}", f"status={d.get('status')} saved={saved!r}")
        except Exception as e:
            fail(f"Toggle {label}", traceback.format_exc().splitlines()[-1])

    # Unknown key must be rejected
    try:
        await M.api_settings_behaviour(req({"key":"__evil__","value":"true"}), FakeBT())
        fail("Unknown key rejected")
    except HTTPException as e:
        ok("Unknown setting key rejected (400)") if e.status_code==400 else fail("Unknown key", f"got {e.status_code}")

    # ═══════════════════════════════════════════════════════════════════════
    # SECTION 3: Save search settings
    # ═══════════════════════════════════════════════════════════════════════
    print("\n── Save search settings ──")
    try:
        r = await M.api_settings_search(req({
            "template_movie":           "{title} {year} 4K",
            "template_episode":         "{title} S{season}E{episode} WEB",
            "template_season_pack":     "{title} S{season} Complete",
            "template_series_pack":     "{title} Complete Series",
            "search_min_seeders":       "3",
            "search_max_results":       "8",
            "cache_ttl_days":           "14",
            "movie_preferred_quality":  "2160p",
            "series_preferred_quality": "1080p",
            "series_completed_strategy":"series_pack",
            "series_ongoing_strategy":  "season_pack",
        }))
        d = body_json(r)
        if d.get("status") == "ok":
            for k, v in [("template_movie","{title} {year} 4K"),
                         ("search_min_seeders","3"),("cache_ttl_days","14"),
                         ("movie_preferred_quality","2160p")]:
                saved = db.get_setting(k,"")
                ok(f"  Persisted {k}={v!r}") if saved==v else fail(f"  {k}", f"got {saved!r}")
        else:
            fail("api_settings_search", str(d))
    except Exception as e:
        fail("api_settings_search", traceback.format_exc().splitlines()[-1])

    # Verify settings page STILL works after saving template with curly braces
    try:
        r = await M.settings_page(req())
        ok("settings_page() still works after saving templates with {curly} braces",
           f"HTTP {status(r)}")
    except Exception as e:
        fail("settings_page() after template save", traceback.format_exc().splitlines()[-1])

    # ═══════════════════════════════════════════════════════════════════════
    # SECTION 4: Movies page
    # ═══════════════════════════════════════════════════════════════════════
    print("\n── Movies page ──")
    # Seed a cached entry
    db.upsert("movie_dune_part_two_2024",
        PlayEvent(media_type=MediaType.movie, title="Dune Part Two", year=2024), "cached")

    for fn_name, body_val, label in [
        ("api_import_plex", {"title":"Inception","year":2010,"media_type":"movie"}, "+ Register"),
        ("api_cache_movie", {"title":"Inception","year":2010}, "🔎 Cache"),
    ]:
        fn = getattr(M, fn_name)
        try:
            r = await fn(req(body_val), FakeBT())
            d = body_json(r)
            ok(f"{label} → {fn_name}", d.get("status","?"))
        except Exception as e:
            fail(f"{label}", traceback.format_exc().splitlines()[-1])

    # Expire
    try:
        r = await M.expire_cache_entry("movie_dune_part_two_2024", req(), FakeBT())
        ok("🔄 Re-cache → expire_cache_entry")
    except Exception as e:
        fail("expire_cache_entry", traceback.format_exc().splitlines()[-1])

    # Remove (with apostrophe in title — tests json.dumps safety)
    try:
        r = await M.api_library_remove(
            req({"media_type":"movie","title":"It's a Wonderful Life","year":1946}))
        d = body_json(r)
        ok("Remove movie with apostrophe in title → api_library_remove", d.get("status","?"))
    except Exception as e:
        fail("api_library_remove apostrophe", traceback.format_exc().splitlines()[-1])

    # ═══════════════════════════════════════════════════════════════════════
    # SECTION 5: Series page
    # ═══════════════════════════════════════════════════════════════════════
    print("\n── Series page ──")
    for fn_name, body_val, label in [
        ("api_import_plex", {"title":"The Wire","year":2002,"media_type":"series"}, "+ Register"),
        ("api_cache_season", {"title":"Breaking Bad","year":2008,"season":3}, "🔎 Season Pack"),
        ("api_cache_series", {"title":"Breaking Bad","year":2008}, "📦 Series Pack"),
    ]:
        fn = getattr(M, fn_name)
        try:
            r = await fn(req(body_val), FakeBT())
            d = body_json(r)
            ok(f"{label} → {fn_name}", d.get("status","?"))
        except Exception as e:
            fail(f"{label}", traceback.format_exc().splitlines()[-1])

    # ═══════════════════════════════════════════════════════════════════════
    # SECTION 6: Search page
    # ═══════════════════════════════════════════════════════════════════════
    print("\n── Search page ──")
    # Edge case: fake_library_list with a None title row
    with db._connect() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO fake_library (media_type, title, year, added_at) VALUES (?,?,?,?)",
            ("movie", None, 2000, "2024-01-01")
        )
    try:
        in_lib_json = json.dumps([
            (r["title"] or "").lower()
            for r in db.fake_library_list()
            if r.get("title")
        ])
        json.loads(in_lib_json)  # validate
        ok("fake_library_list with None title → guarded correctly")
    except Exception as e:
        fail("fake_library_list None guard", str(e))

    # TMDB search (no key → graceful)
    try:
        r = await M.api_search(req(params={"q":"inception","media_type":"movie"}))
        d = body_json(r) if hasattr(r,"body") else (r if isinstance(r,dict) else {})
        ok("api_search with no TMDB key → graceful error", str(d.get("error","ok"))[:50])
    except Exception as e:
        fail("api_search no-key", traceback.format_exc().splitlines()[-1])

    # Torrent search (no AllDebrid → graceful)
    try:
        r = await M.api_search_torrents(req(params={"q":"breaking bad","season":"3"}))
        d = body_json(r) if hasattr(r,"body") else (r if isinstance(r,dict) else {})
        ok("api_search_torrents with no results → returns {results:[]}", str(d.get("results",["?"])[:1]))
    except Exception as e:
        fail("api_search_torrents", traceback.format_exc().splitlines()[-1])

    # ═══════════════════════════════════════════════════════════════════════
    # SECTION 7: Input validation
    # ═══════════════════════════════════════════════════════════════════════
    print("\n── Input validation ──")
    from fastapi import HTTPException as HE
    for fn_name, body_val, label in [
        ("api_cache_movie",    {"year":2024},          "cache/movie no title → 400"),
        ("api_cache_season",   {"year":2008},          "cache/season no title → 400"),
        ("api_library_remove", {"media_type":"movie"}, "library/remove no title → 400"),
        ("api_search_add",     {"media_type":"movie"}, "search/add no title → 400"),
        ("api_import_plex",    {"media_type":"movie"}, "import/plex no title → 400"),
    ]:
        fn = getattr(M, fn_name)
        try:
            sig = fn.__code__.co_varnames[:fn.__code__.co_argcount]
            r = await (fn(req(body_val), FakeBT()) if "background_tasks" in sig else fn(req(body_val)))
            fail(label, f"expected 400 but got {status(r)}")
        except HE as e:
            ok(label) if e.status_code==400 else fail(label, f"got {e.status_code}")
        except Exception as e:
            fail(label, traceback.format_exc().splitlines()[-1])

    # ═══════════════════════════════════════════════════════════════════════
    # SECTION 8: Tautulli webhook
    # ═══════════════════════════════════════════════════════════════════════
    print("\n── Tautulli webhook ──")
    for payload, label in [
        ({"media_type":"movie","title":"Tenet","year":"2020"}, "movie play"),
        ({"media_type":"episode","title":"Seinfeld","season":"1","episode":"3"}, "episode play"),
        ({"media_type":"trailer"}, "unknown type → ignored"),
    ]:
        try:
            r = await M.tautulli_webhook(req(payload), FakeBT())
            d = body_json(r) if hasattr(r,"body") else (r if isinstance(r,dict) else {})
            ok(f"Webhook: {label}", d.get("status","?"))
        except Exception as e:
            fail(f"Webhook: {label}", traceback.format_exc().splitlines()[-1])

    # ═══════════════════════════════════════════════════════════════════════
    # SECTION 9: Pre-cache toggle
    # ═══════════════════════════════════════════════════════════════════════
    print("\n── Pre-cache toggle ──")
    db.set_setting("precache_enabled", "false")
    called = []
    orig = M.resolve_and_cache
    async def _spy(app, ev): called.append(ev.title)
    M.resolve_and_cache = _spy
    try:
        await M._precache_movie(FakeApp(), "Ghost", 2025, None, None)
        ok("precache_enabled=false → _precache_movie skipped") if not called else fail("precache not skipped", str(called))
        await M._precache_series(FakeApp(), "Ghost Show", 2025, [{"season":1,"episode":1}])
        ok("precache_enabled=false → _precache_series skipped") if not called else fail("series precache not skipped", str(called))
    finally:
        db.set_setting("precache_enabled", "true")
        M.resolve_and_cache = orig

asyncio.run(run())

import os as _os; _os.unlink(db_file)

print(f"\n{'='*56}")
print(f"  {PASS} passed   {FAIL} failed")
if FAIL:
    print("\n  ❌ Fix failures above before deploying!")
    sys.exit(1)
else:
    print("\n  ✅ All tests pass — safe to deploy")
    sys.exit(0)
