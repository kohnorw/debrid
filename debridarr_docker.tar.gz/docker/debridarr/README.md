# 🎬 Debridarr

**On-the-fly AllDebrid streaming for Plex** — click play, watch instantly.

Inspired by [placeholdarr](https://github.com/kohnorw/placeholdarr) and using the AllDebrid indexer approach from [kohnorw/debrid](https://github.com/kohnorw/debrid).

---

## How It Works

```
User clicks Play in Plex
        │
        ▼
Tautulli fires a webhook ──► Debridarr /webhook/tautulli
        │
        ▼
Search The Pirate Bay for "[Title] 1080p" (or "S01E05 1080p")
        │
        ▼
Batch-check AllDebrid cache for all result hashes (1 API call)
        │
        ├── Cached? ──► Unlock magnet ──► Get direct HTTP stream URL
        │                                         │
        │                                         ▼
        │                              Store in SQLite (30 days)
        │                                         │
        └── Not cached? ──► Mark as not_found    ▼
                                        Plex streams via /stream/<key>
```

**Key design choices:**
- **Minimal AllDebrid API calls** — one batch hash-check per search, results cached 1 hour in-process
- **No background polling** — resolution happens on demand when Plex play fires
- **30-day SQLite cache** — once found, the stream URL is stored locally and refreshed only when stale (6h)
- **Single Docker container** — SQLite, no external DB

---

## Quick Start

```bash
# 1. Clone / download
git clone https://github.com/you/debridarr
cd debridarr

# 2. Configure
cp .env.example .env
nano .env   # fill in ALLDEBRID_API_KEY at minimum

# 3. Run
docker compose up -d

# 4. Check it's up
curl http://localhost:7474/health
# → {"status":"ok","service":"debridarr"}

# 5. Open dashboard
open http://localhost:7474
```

---

## Tautulli Setup (Required for Plex)

Tautulli detects what Plex is playing and sends a webhook to Debridarr.

1. Go to **Tautulli → Settings → Notification Agents → Add a new notification agent → Webhook**
2. Set **Webhook URL** to: `http://debridarr:7474/webhook/tautulli`
3. Set **HTTP Method** to `POST`
4. Under **Triggers**, enable: `Playback Start`
5. Under **Data**, set **JSON Data** to:

```json
{
  "media_type": "{media_type}",
  "title": "{title}",
  "grandparent_title": "{grandparent_title}",
  "year": "{year}",
  "parent_media_index": "{parent_media_index}",
  "media_index": "{media_index}",
  "rating_key": "{rating_key}",
  "imdb_id": "{imdb_id}",
  "themoviedb_id": "{themoviedb_id}",
  "thetvdb_id": "{thetvdb_id}"
}
```

---

## Sonarr / Radarr Setup (Optional but Recommended)

Connect so Debridarr can enrich search queries with proper metadata.

**In Sonarr/Radarr → Settings → Connect → Add → Webhook:**
- URL: `http://debridarr:7474/webhook/sonarr` (or `/radarr`)
- Triggers: any (Debridarr just acknowledges for now)

---

## API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/` | Dashboard UI |
| `GET` | `/health` | Health check |
| `POST` | `/webhook/tautulli` | Tautulli play event |
| `POST` | `/webhook/sonarr` | Sonarr event (catalog awareness) |
| `POST` | `/webhook/radarr` | Radarr event |
| `POST` | `/resolve` | Manual resolve trigger |
| `GET` | `/stream/{key}` | Redirect to AllDebrid stream URL |
| `GET` | `/cache` | List all cache entries (JSON) |
| `DELETE` | `/cache/{key}` | Remove a cache entry |

### Manual Resolve (Testing)

```bash
# Test a movie
curl -X POST http://localhost:7474/resolve \
  -H "Content-Type: application/json" \
  -d '{"media_type":"movie","title":"Inception","year":2010}'

# Test an episode
curl -X POST http://localhost:7474/resolve \
  -H "Content-Type: application/json" \
  -d '{"media_type":"episode","title":"Breaking Bad","season":3,"episode":5}'

# Check results
curl http://localhost:7474/cache
```

---

## Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `ALLDEBRID_API_KEY` | ✅ | — | Your AllDebrid API key |
| `SONARR_URL` | — | `http://sonarr:8989` | Sonarr URL |
| `SONARR_API_KEY` | — | — | Sonarr API key |
| `RADARR_URL` | — | `http://radarr:7878` | Radarr URL |
| `RADARR_API_KEY` | — | — | Radarr API key |
| `CACHE_TTL_DAYS` | — | `30` | How long to cache resolved links |
| `LOG_LEVEL` | — | `INFO` | Logging verbosity |

---

## Caching Strategy

Debridarr is designed to be very light on API calls:

1. **In-process search cache** — TPB search + AllDebrid hash-check results are cached 1 hour in memory. If 5 people play the same show in an hour, AllDebrid is only hit once.
2. **SQLite link cache** — Once a magnet is unlocked and a stream URL obtained, it's stored for 30 days. Subsequent plays are instant redirects with zero API calls.
3. **Link refresh** — AllDebrid direct URLs expire; Debridarr automatically re-unlocks the stored magnet if the link is >6 hours old.
4. **Batch hash check** — All TPB results are checked in a single AllDebrid API call (`/magnet/instant`), not one call per torrent.

---

## Data Volume

The `/data` volume contains a single SQLite file (`debridarr.db`). Back it up if you care about the cache, but it's fully regenerated on demand.

---

## Limitations / Roadmap

- **No Plex library file replacement** — This PoC streams via redirect; it doesn't create actual files in Plex libraries. For that, integrate with Sonarr/Radarr's download client support (point them at Debridarr as a custom download client, or use rclone to mount AllDebrid as a virtual filesystem).
- **Stream URL lifetime** — AllDebrid direct URLs are time-limited. Long movies may need mid-stream refresh (handled by Plex retry, or implement a proxy endpoint).
- **TPB availability** — Searches go through `apibay.org`; if it's down, use a fallback search endpoint.
