# Debridarr

On-the-fly AllDebrid streaming for Plex. When you play something in Plex, Debridarr searches for a cached torrent on AllDebrid, mounts it via FUSE, and symlinks it into your Plex library — no downloading, no storage required.

---

## How It Works

```
Plex play → Tautulli webhook → Debridarr
  → Search TPB for cached torrent on AllDebrid
  → Add magnet to AllDebrid
  → Mount file in FUSE at /docker/debridarr/mnt-alldebrid/<torrent>/<file.mkv>
  → Symlink plex-strm/movies|tv/... → FUSE file
  → Plex streams bytes via HTTP Range from AllDebrid CDN
```

---

## Requirements

- Docker + Docker Compose
- AllDebrid account with API key
- Overseerr (for library browsing)
- Tautulli (to detect Plex playback)
- Plex Media Server

---

## Install

Upload `debridarr_docker.tar.gz` to `/docker/debridarr/`, then:

```bash
cd /docker/debridarr
mkdir -p /tmp/debridarr_extract && \
tar -xzf debridarr_docker.tar.gz -C /tmp/debridarr_extract && \
cp -r /tmp/debridarr_extract/docker/debridarr/. /docker/debridarr/ && \
rm -rf /tmp/debridarr_extract && \
mkdir -p /docker/debridarr/tmp/cache && \
docker-compose build --no-cache && \
docker-compose up -d && \
docker logs debridarr -f
```

---

## Update

Upload new `debridarr_docker.tar.gz` to `/docker/debridarr/`, then:

```bash
cd /docker/debridarr
mkdir -p /tmp/debridarr_extract && \
tar -xzf debridarr_docker.tar.gz -C /tmp/debridarr_extract && \
cp -r /tmp/debridarr_extract/docker/debridarr/. /docker/debridarr/ && \
rm -rf /tmp/debridarr_extract && \
mkdir -p /docker/debridarr/tmp/cache && \
docker-compose down && \
docker-compose build --no-cache && \
docker-compose up -d && \
docker logs debridarr -f
```

---

## Tautulli Setup

1. Settings → Notification Agents → Add → **Webhook**
2. **Webhook URL:** `http://debridarr:7474/webhook/tautulli`
3. **Method:** POST
4. **Triggers:** Playback Start only
5. **Data → Playback Start**, paste:

```json
{
  "media_type": "{media_type}",
  "title": "{title}",
  "grandparent_title": "{grandparent_title}",
  "year": "{year}",
  "grandparent_year": "{grandparent_year}",
  "parent_media_index": "{parent_media_index}",
  "media_index": "{media_index}",
  "rating_key": "{rating_key}",
  "imdb_id": "{imdb_id}",
  "themoviedb_id": "{themoviedb_id}",
  "thetvdb_id": "{thetvdb_id}"
}
```

---

## Plex Setup

Add two libraries pointing to the `plex-strm` folders:

| Library | Path |
|---------|------|
| Movies  | `/docker/debridarr/plex-strm/movies` |
| TV Shows | `/docker/debridarr/plex-strm/tv` |

Plex must also be able to follow symlinks into `/docker/debridarr/mnt-alldebrid`.

---

## Directory Structure

```
/docker/debridarr/
├── app/                  # Application code
├── data/                 # Database + config (.env, .setup_complete)
├── plex-strm/
│   ├── movies/           # Movie placeholders + symlinks
│   └── tv/               # TV placeholders + symlinks
├── mnt-alldebrid/        # FUSE mount — AllDebrid torrents appear here
├── tmp/
│   └── cache/            # DFS chunk cache (configurable in Settings)
├── config/tautulli/
├── docker-compose.yml
├── Dockerfile
└── entrypoint.sh
```

---

## Web UI

| Page | Description |
|------|-------------|
| `/library` | Browse Overseerr requests, add to Plex library |
| `/my-library` | View and manage added items |
| `/settings` | Configure AllDebrid, Overseerr, DFS cache |

---

## DFS Cache

Chunks from AllDebrid CDN are cached locally for smooth playback. Configure in **Settings → DFS Cache**:

| Setting | Default | Description |
|---------|---------|-------------|
| Cache Directory | `/docker/debridarr/tmp/cache` | Where chunks are stored |
| Disk Cache Size | 30 GB | Maximum cache size |
| Cache Expiry | 24h | How long to keep chunks |
| Chunk Size | 8 MB | Fetch unit from CDN |
| Read Ahead | 500 MB | Pre-fetch buffer |
| Cleanup Interval | 20 min | How often to enforce limits |

---

## Environment Variables

| Variable | Description |
|----------|-------------|
| `ALLDEBRID_API_KEY` | Your AllDebrid API key |
| `OVERSEERR_URL` | e.g. `http://192.168.1.x:5055` |
| `OVERSEERR_API_KEY` | Overseerr API key |
| `PLEX_ROOT` | Path inside container (default `/plex-strm`) |
| `FUSE_MOUNT` | FUSE mount path (default `/docker/debridarr/mnt-alldebrid`) |
| `FUSE_SYMLINK_ROOT` | Host path for symlinks (default `/docker/debridarr/mnt-alldebrid`) |
| `DFS_CACHE_DIR` | Chunk cache path (default `/docker/debridarr/tmp/cache`) |
| `CACHE_TTL_DAYS` | Days before cache expires (default `30`) |
| `LOG_LEVEL` | `INFO` or `DEBUG` |

---

## Ports

| Port | Service |
|------|---------|
| 7474 | Debridarr UI |
| 8181 | Tautulli |
