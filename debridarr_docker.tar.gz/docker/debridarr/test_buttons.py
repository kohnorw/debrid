"""
Button test — calls endpoint functions directly with a fake Request,
bypassing FastAPI's ASGI stack entirely. Fast, reliable, no lifespan issues.
"""
import asyncio, sys, os, json, tempfile, re
sys.path.insert(0, "/home/claude/debridarr")
os.chdir("/home/claude/debridarr")

PASS = 0; FAIL = 0
def ok(n, w=""):  global PASS; PASS += 1; print(f"  ✅ {n}")
def fail(n, w=""): global FAIL; FAIL += 1; print(f"  ❌ {n}" + (f" — {w}" if w else ""))

# ── 1. STATIC: every data-action has a fetch URL, every fetch URL has a route ─
print("\n── Static analysis ──")

SRC = open("app/main.py").read()

html_actions = set(re.findall(r'''data-action=['"]([\w-]+)['"]''', SRC))
routes       = set(re.findall(r'''@app\.(?:get|post)\(['"](/[^'"]+)''', SRC))

# For each action, find the fetch URL its JS handler calls
def find_fetch_for_action(action):
    pattern = (
        r"(?:action|a)\s*===?\s*['\"]" + re.escape(action) + r"['\"]"
        r".*?fetch\(\s*['\"]([^'\"]+)['\"]"
    )
    m = re.search(pattern, SRC, re.DOTALL)
    return m.group(1) if m else None

CLIENT_ONLY = {"close-panel"}   # no fetch, purely client-side

for action in sorted(html_actions):
    if action in CLIENT_ONLY:
        ok(f"data-action='{action}' — client-only, no fetch needed"); continue
    url = find_fetch_for_action(action)
    if not url:
        fail(f"data-action='{action}' — no fetch() found in JS"); continue
    base = url.split('?')[0].split('$')[0]
    found = any(
        re.sub(r'\{[^}]+\}', '__', r) == re.sub(r'\{[^}]+\}', '__', base)
        or base.startswith(r.split('{')[0].rstrip('/'))
        for r in routes
    )
    msg = f"data-action='{action}' → fetch('{url}')"
    (ok if found else fail)(msg, "" if found else "no matching @app route")

# Every fetch URL in JS maps to a route
fetch_urls = set(re.findall(r"""fetch\(['\"]([^'"?$\s]+)['\"]""", SRC))
fetch_urls = {u for u in fetch_urls if u.startswith('/')}

for url in sorted(fetch_urls):
    found = any(
        re.sub(r'\{[^}]+\}', '__', r) == re.sub(r'\{[^}]+\}', '__', url)
        or url.startswith(r.split('{')[0].rstrip('/'))
        for r in routes
    )
    (ok if found else fail)(f"fetch('{url}') has route")

# ── 2. RUNTIME: call handlers with a mock Request ────────────────────────────
print("\n── Runtime: mock request → endpoint function ──")

from app.cache import CacheDB
from app.models import MediaType, PlayEvent
import app.main as M

# Temp DB
db_file = tempfile.mktemp(suffix=".db")
db = CacheDB(db_file)
db.init()
db.set_setting("alldebrid_api_key", "test_key")
db.set_setting("plex_root", "/tmp/test-plex")
db.set_setting("no_cam", "true")
db.set_setting("precache_enabled", "true")
db.set_setting("search_sources", "https://apibay.org/q.php")
os.makedirs("/tmp/test-plex/movies", exist_ok=True)
os.makedirs("/tmp/test-plex/tv", exist_ok=True)

# Seed library
db.fake_library_add({"media_type":"movie","title":"Dune Part Two","year":2024,
    "poster_url":"","overview":"","status":"movie","fake_path":None})
db.fake_library_add({"media_type":"series","title":"Breaking Bad","year":2008,
    "poster_url":"","overview":"","status":"continuing","season_count":5,"fake_path":None})

# Seed a cached entry for expire test
db.upsert("movie_dune_part_two_2024",
    PlayEvent(media_type=MediaType.movie, title="Dune Part Two", year=2024), "cached")
db.update_cached("movie_dune_part_two_2024","magnet:test","https://cdn/f.mkv",
                  "Dune.2024.1080p","1080p","/tmp/test-plex/movies/Dune/f.mkv")

# Fake app state objects
class FakeAD:
    api_key = "test"
    async def search_cached(self, **kw): return []
    async def add_magnet(self, m): return None
    async def unlock_file(self, l): return "https://cdn.test/file.mkv"
    async def delete_magnet(self, i): pass
    async def get_all_torrents(self): return []
    async def aclose(self): pass

class FakeLM:
    url = ""; plex_root = "/tmp/test-plex"
    async def get_radarr_movies(self): return []
    async def get_sonarr_series(self): return []
    async def get_episodes(self, *a, **kw): return []
    def create_fake_episodes(self, *a): pass
    def remove_fake_movie(self, *a): pass
    def remove_fake_series(self, *a): pass

class FakeSettings:
    PLEX_ROOT = "/tmp/test-plex"; ALLDEBRID_API_KEY = "test"
    OVERSEERR_URL = ""; OVERSEERR_API_KEY = ""; DEBRIDARR_BASE_URL = ""
    DB_PATH = db_file; FUSE_MOUNT = "/mnt/fake"; FUSE_SYMLINK_ROOT = "/tmp/fuse"
    LOG_LEVEL = "INFO"; PORT = 7474

class FakePool:
    def stats(self):
        return {"max_workers":3,"running":0,"queued":0,"done":0,"failed":0,"cancelled":0,"workers":[]}
    def set_max_workers(self, n): pass
    async def enqueue(self, label, fn): return "wid_test"
    def is_already_queued(self, label): return False
    def cancel_all(self): return 0

class FakeAppState:
    db         = db
    settings   = FakeSettings()
    alldebrid  = FakeAD()
    library    = FakeLM()
    worker_pool= FakePool()
    setup_complete = True

class FakeApp:
    state = FakeAppState()

class FakeBT:
    """BackgroundTasks shim — records tasks instead of running them."""
    def __init__(self): self.tasks = []
    def add_task(self, fn, *args, **kwargs): self.tasks.append((fn, args, kwargs))

def req(body=None, params=None):
    """Build a mock Request with our fake app state."""
    class R:
        app       = FakeApp()
        query_params = params or {}
        url       = type("U", (), {"path":"/test"})()
        async def json(self): return body or {}
    return R()

# Patch _needs_setup so pages don't redirect
M._needs_setup = lambda r: False

async def run():
    from fastapi import HTTPException
    from fastapi.responses import JSONResponse, RedirectResponse

    def status(r):
        if isinstance(r, (JSONResponse,)): return r.status_code
        if isinstance(r, RedirectResponse): return r.status_code
        if hasattr(r, 'status_code'): return r.status_code
        return 200

    def body(r):
        if isinstance(r, JSONResponse):
            return json.loads(r.body)
        return {}

    # ── Movies: + Register ──────────────────────────────────────────────────
    print("\n  [Movies page]")
    bt = FakeBT()
    r = await M.api_import_plex(req({"title":"Inception","year":2010,"media_type":"movie"}), bt)
    (ok if status(r)==200 and body(r).get("status") in ("ok","already_added") else fail)(
        "+ Register button → /api/import/plex", body(r))

    # ── Movies: 🔎 Cache ────────────────────────────────────────────────────
    bt = FakeBT()
    r = await M.api_cache_movie(req({"title":"Dune Part Two","year":2024}), bt)
    (ok if status(r)==200 and body(r).get("status")=="queued" else fail)(
        "🔎 Cache button → /api/cache/movie", body(r))

    # ── Movies: 🔄 Re-cache (expire) ────────────────────────────────────────
    # Endpoint signature: expire_cache_entry(cache_key, request, background_tasks)
    bt = FakeBT()
    r = await M.expire_cache_entry("movie_dune_part_two_2024", req(), bt)
    (ok if status(r)==200 else fail)("🔄 Re-cache button → /cache/{key}/expire", body(r))

    # ── Movies: Remove ──────────────────────────────────────────────────────
    r = await M.api_library_remove(
        req({"media_type":"movie","title":"Inception","year":2010}))
    (ok if status(r)==200 and body(r).get("status")=="removed" else fail)(
        "Remove button → /api/library/remove", body(r))

    # ── Series: + Register ──────────────────────────────────────────────────
    print("\n  [Series page]")
    bt = FakeBT()
    r = await M.api_import_plex(
        req({"title":"The Wire","year":2002,"media_type":"series"}), bt)
    (ok if status(r)==200 else fail)(
        "+ Register button → /api/import/plex (series)", body(r))

    # ── Series: 🔎 Season Pack ──────────────────────────────────────────────
    bt = FakeBT()
    r = await M.api_cache_season(
        req({"title":"Breaking Bad","year":2008,"season":3}), bt)
    (ok if status(r)==200 and body(r).get("status")=="queued" else fail)(
        "🔎 Pack button → /api/cache/season", body(r))

    # ── Series: 📦 Series Pack ──────────────────────────────────────────────
    bt = FakeBT()
    r = await M.api_cache_series(
        req({"title":"Breaking Bad","year":2008}), bt)
    (ok if status(r)==200 and body(r).get("status")=="queued" else fail)(
        "📦 Series Pack button → /api/cache/series", body(r))

    # ── Series: 🗑️ Remove ───────────────────────────────────────────────────
    r = await M.api_library_remove(
        req({"media_type":"series","title":"Breaking Bad","year":2008}))
    (ok if status(r)==200 else fail)(
        "🗑️ Remove button → /api/library/remove (series)", body(r))

    # ── Search: TMDB title search ────────────────────────────────────────────
    print("\n  [Search page]")
    r = await M.api_search(req(params={"q":"inception","media_type":"movie"}))
    d = body(r) if hasattr(r,'body') else (r if isinstance(r,dict) else {})
    (ok if "results" in d else fail)("Title search → /api/search returns {results:[]}", d)

    # ── Search: TPB torrent search ───────────────────────────────────────────
    r = await M.api_search_torrents(req(params={"q":"breaking bad s01"}))
    d = body(r) if hasattr(r,'body') else (r if isinstance(r,dict) else {})
    (ok if "results" in d else fail)(
        "Torrent search → /api/search/torrents returns {results:[]}", d)

    # ── Search: + Add to Library ─────────────────────────────────────────────
    bt = FakeBT()
    r = await M.api_search_add(
        req({"title":"Oppenheimer","year":2023,"media_type":"movie","tmdb_id":"872585"}), bt)
    d = body(r) if hasattr(r,'body') else (r if isinstance(r,dict) else {})
    (ok if d.get("status") in ("ok","already_added") else fail)(
        "+ Add to Library → /api/search/add", d)

    # ── Settings: all 5 toggles ──────────────────────────────────────────────
    print("\n  [Settings page — toggles]")
    for key, val, label in [
        ("precache_enabled",            "false", "⚡ Pre-caching OFF"),
        ("precache_enabled",            "true",  "⚡ Pre-caching ON"),
        ("auto_add",                    "true",  "🤖 Auto-add ON"),
        ("auto_add",                    "false", "🤖 Auto-add OFF"),
        ("english_only",                "true",  "🇬🇧 English-only ON"),
        ("english_only",                "false", "🇬🇧 English-only OFF"),
        ("no_cam",                      "false", "🚫 CAM filter OFF"),
        ("no_cam",                      "true",  "🚫 CAM filter ON"),
        ("include_unreleased_episodes", "true",  "📅 Unreleased episodes ON"),
        ("include_unreleased_episodes", "false", "📅 Unreleased episodes OFF"),
    ]:
        bt = FakeBT()
        try:
            r = await M.api_settings_behaviour(req({"key":key,"value":val}), bt)
            d = body(r) if hasattr(r,'body') else (r if isinstance(r,dict) else {})
            (ok if d.get("status")=="ok" else fail)(f"Toggle {label}", d)
            # Verify it persisted
            saved = db.get_setting(key,"")
            (ok if saved==val else fail)(f"  → persisted in DB ({key}={val!r})", f"got {saved!r}")
        except Exception as e:
            fail(f"Toggle {label}", str(e))

    # Unknown key must be rejected
    try:
        r = await M.api_settings_behaviour(req({"key":"__evil__","value":"true"}), FakeBT())
        fail("Unknown setting key should be rejected 400", f"got status {status(r)}")
    except HTTPException as e:
        (ok if e.status_code==400 else fail)("Unknown setting key rejected (400)", str(e))

    # ── Settings: 💾 Save All Search Settings ────────────────────────────────
    print("\n  [Settings page — Save search]")
    r = await M.api_settings_search(req({
        "template_movie":          "{title} {year} 2160p",
        "template_episode":        "{title} S{season}E{episode} WEB",
        "template_season_pack":    "{title} Season {season}",
        "template_series_pack":    "{title} Complete",
        "search_extra_movie":      "remux",
        "search_extra_series":     "1080p",
        "search_min_seeders":      "5",
        "search_max_results":      "10",
        "cache_ttl_days":          "21",
        "precache_cooldown_minutes":"3",
        "movie_preferred_quality": "2160p",
        "series_preferred_quality":"1080p",
        "movie_fallback_any_quality":"true",
        "series_fallback_any_quality":"true",
        "series_completed_strategy":"series_pack",
        "series_ongoing_strategy": "season_pack",
    }))
    d = body(r) if hasattr(r,'body') else (r if isinstance(r,dict) else {})
    (ok if d.get("status")=="ok" else fail)("💾 Save All Search Settings", d)

    # Verify several fields persisted
    for k, v in [("template_movie","{title} {year} 2160p"),
                 ("search_min_seeders","5"),
                 ("cache_ttl_days","21"),
                 ("movie_preferred_quality","2160p")]:
        saved = db.get_setting(k,"")
        (ok if saved==v else fail)(f"  Persisted {k}", f"expected {v!r}, got {saved!r}")

    # ── Settings: GET /api/settings/get ─────────────────────────────────────
    r = await M.api_settings_get(req())
    d = body(r) if hasattr(r,'body') else (r if isinstance(r,dict) else {})
    (ok if d.get("template_movie")=="{title} {year} 2160p" else fail)(
        "GET /api/settings/get returns updated values", f"got {d.get('template_movie')!r}")

    # ── Settings: 🔌 Test Sources ─────────────────────────────────────────
    r = await M.api_test_sources(req({"sources":"https://apibay.org/q.php"}))
    d = body(r) if hasattr(r,'body') else (r if isinstance(r,dict) else {})
    (ok if "ok" in d else fail)("🔌 Test Sources button → /api/settings/test-sources", d)

    # ── Workers view ────────────────────────────────────────────────────────
    print("\n  [Workers panel]")
    r = await M.api_workers_get(req())
    d = body(r) if hasattr(r,'body') else (r if isinstance(r,dict) else {})
    (ok if all(k in d for k in ("running","queued","workers")) else fail)(
        "Worker live view → /api/workers correct shape", list(d.keys()))

    # ── Tautulli webhook ────────────────────────────────────────────────────
    print("\n  [Tautulli webhook]")
    bt = FakeBT()
    r = await M.tautulli_webhook(req({"media_type":"movie","title":"Tenet","year":"2020"}), bt)
    d = body(r) if hasattr(r,'body') else (r if isinstance(r,dict) else {})
    (ok if d.get("status") in ("queued","cached","already_queued") else fail)(
        "Movie play → webhook queues resolve_and_cache", d)

    bt = FakeBT()
    r = await M.tautulli_webhook(
        req({"media_type":"episode","title":"Seinfeld","season":"1","episode":"3"}), bt)
    d = body(r) if hasattr(r,'body') else (r if isinstance(r,dict) else {})
    (ok if d.get("status") in ("queued","cached","already_queued") else fail)(
        "Episode play → webhook queues resolve_and_cache", d)

    r = await M.tautulli_webhook(req({"media_type":"trailer"}), FakeBT())
    d = body(r) if hasattr(r,'body') else (r if isinstance(r,dict) else {})
    (ok if d.get("status")=="ignored" else fail)(
        "Unknown media type ignored gracefully", d)

    # ── Input validation ────────────────────────────────────────────────────
    print("\n  [Input validation]")
    for fn, body_val, label in [
        (M.api_cache_movie,    {"year":2024},          "cache/movie — missing title → 400"),
        (M.api_cache_season,   {"year":2008},          "cache/season — missing title → 400"),
        (M.api_library_remove, {"media_type":"movie"}, "library/remove — missing title → 400"),
        (M.api_search_add,     {"media_type":"movie"}, "search/add — missing title → 400"),
        (M.api_import_plex,    {"media_type":"movie"}, "import/plex — missing title → 400"),
    ]:
        try:
            bt = FakeBT()
            sig = fn.__code__.co_varnames[:fn.__code__.co_argcount]
            r = await (fn(req(body_val), bt) if "background_tasks" in sig else fn(req(body_val)))
            fail(label, f"expected HTTPException 400 but got {status(r)}")
        except HTTPException as e:
            (ok if e.status_code==400 else fail)(label, f"got {e.status_code}")

    # ── Pre-cache toggle respected ───────────────────────────────────────────
    print("\n  [Pre-cache toggle behaviour]")
    db.set_setting("precache_enabled", "false")
    called = []
    orig = M.resolve_and_cache
    async def _spy(app, ev): called.append(ev.title)
    M.resolve_and_cache = _spy
    await M._precache_movie(None, "Ghost Movie", 2025, None, None)
    (ok if not called else fail)(
        "precache_enabled=false → _precache_movie skips resolve_and_cache",
        f"called={called}")
    await M._precache_series(None, "Ghost Show", 2025, [{"season":1,"episode":1}])
    (ok if not called else fail)(
        "precache_enabled=false → _precache_series skips all caching",
        f"called={called}")
    db.set_setting("precache_enabled", "true")
    M.resolve_and_cache = orig

asyncio.run(run())
os.unlink(db_file)

print(f"\n{'='*52}")
print(f"  {PASS} passed   {FAIL} failed")
sys.exit(0 if FAIL == 0 else 1)
