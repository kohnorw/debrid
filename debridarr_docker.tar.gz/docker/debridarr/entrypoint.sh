#!/bin/sh
# Entrypoint for Debridarr — mirrors decypharr's entrypoint.sh
# Runs as root to set up FUSE and permissions, then drops to PUID:PGID
set -e

PUID=${PUID:-1000}
PGID=${PGID:-1000}
FUSE_MOUNT=${FUSE_MOUNT:-/mnt/alldebrid}

# ── FUSE setup ────────────────────────────────────────────────────────────────
# Ensure user_allow_other is set (lets Plex read FUSE mounts owned by debridarr)
if ! grep -q "^user_allow_other" /etc/fuse.conf 2>/dev/null; then
    echo "user_allow_other" >> /etc/fuse.conf
fi

# Clean up any stale FUSE mount from a previous container run
# (decypharr does this; prevents "Transport endpoint is not connected" errors)
if mountpoint -q "$FUSE_MOUNT" 2>/dev/null; then
    echo "[entrypoint] Stale FUSE mount at $FUSE_MOUNT — cleaning up"
    fusermount -uz "$FUSE_MOUNT" 2>/dev/null || \
    fusermount3 -uz "$FUSE_MOUNT" 2>/dev/null || \
    umount -l "$FUSE_MOUNT" 2>/dev/null || true
    sleep 0.5
fi

# Ensure mount point exists and is owned by app user
mkdir -p "$FUSE_MOUNT" /data /plex-strm
chown -R "$PUID:$PGID" "$FUSE_MOUNT" /data /plex-strm /app 2>/dev/null || true

# ── Drop to app user and exec ─────────────────────────────────────────────────
if [ "$(id -u)" = "0" ]; then
    echo "[entrypoint] Starting as $PUID:$PGID"
    exec gosu "$PUID:$PGID" "$@"
else
    exec "$@"
fi
