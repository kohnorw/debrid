#!/bin/sh
set -e

FUSE_MOUNT=${FUSE_MOUNT:-/docker/debridarr/mnt-alldebrid}

if ! grep -q "^user_allow_other" /etc/fuse.conf 2>/dev/null; then
    echo "user_allow_other" >> /etc/fuse.conf
fi

# Clean up stale FUSE mount
if mountpoint -q "$FUSE_MOUNT" 2>/dev/null; then
    echo "[entrypoint] Stale FUSE mount at $FUSE_MOUNT — cleaning up"
    fusermount -uz "$FUSE_MOUNT" 2>/dev/null || \
    fusermount3 -uz "$FUSE_MOUNT" 2>/dev/null || \
    umount -l "$FUSE_MOUNT" 2>/dev/null || true
    sleep 0.5
fi

mkdir -p "$FUSE_MOUNT" /data /plex-strm

# Run app as root — FUSE needs root to mount on host path
# user_allow_other in fuse.conf lets Plex (other users) read the mount
export USER=root
export HOME=/root
exec "$@"
