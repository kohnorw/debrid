#!/bin/sh
# Mirrors decypharr's entrypoint.sh exactly
set -e

PUID=${PUID:-1000}
PGID=${PGID:-1000}
FUSE_MOUNT=${FUSE_MOUNT:-/mnt/alldebrid}

# user_allow_other so Plex (different uid) can read the FUSE mount
if ! grep -q "^user_allow_other" /etc/fuse.conf 2>/dev/null; then
    echo "user_allow_other" >> /etc/fuse.conf
fi

# Clean up any stale FUSE mount from previous container run
if mountpoint -q "$FUSE_MOUNT" 2>/dev/null; then
    echo "[entrypoint] Stale FUSE mount at $FUSE_MOUNT — cleaning up"
    fusermount3 -uz "$FUSE_MOUNT" 2>/dev/null || \
    fusermount -uz "$FUSE_MOUNT" 2>/dev/null || \
    umount -l "$FUSE_MOUNT" 2>/dev/null || true
    sleep 0.5
fi

mkdir -p "$FUSE_MOUNT" /data /plex-strm

if [ "$(id -u)" != "0" ]; then
    echo "[entrypoint] Running as non-root $(id -u):$(id -g)"
    export USER="$(id -un 2>/dev/null || echo debridarr)"
    export HOME=/app
    exec "$@"
fi

echo "[entrypoint] Starting as $PUID:$PGID"

# Create group/user if needed (like decypharr)
if ! getent group "$PGID" > /dev/null 2>&1; then
    addgroup -g "$PGID" appgroup
fi
if ! getent passwd "$PUID" > /dev/null 2>&1; then
    adduser -D -u "$PUID" -G "$(getent group "$PGID" | cut -d: -f1)" -s /bin/sh appuser
fi

USERNAME=$(getent passwd "$PUID" | cut -d: -f1)

# Add user to fuse group so fusermount works without root
adduser "$USERNAME" fuse 2>/dev/null || true

chown -R "$PUID:$PGID" "$FUSE_MOUNT" /data /plex-strm /app 2>/dev/null || true

export USER="$USERNAME"
export HOME=/app

# su-exec from Alpine apk — same as decypharr
exec su-exec "$PUID:$PGID" "$@"
