#!/bin/sh
set -e

PUID=${PUID:-1000}
PGID=${PGID:-1000}
FUSE_MOUNT=${FUSE_MOUNT:-/mnt/alldebrid}

# Ensure user_allow_other so Plex (different uid) can read FUSE mount
if ! grep -q "^user_allow_other" /etc/fuse.conf 2>/dev/null; then
    echo "user_allow_other" >> /etc/fuse.conf
fi

# Clean up any stale FUSE mount from previous container run
if mountpoint -q "$FUSE_MOUNT" 2>/dev/null; then
    echo "[entrypoint] Stale FUSE mount at $FUSE_MOUNT — cleaning up"
    fusermount -uz "$FUSE_MOUNT" 2>/dev/null || \
    fusermount3 -uz "$FUSE_MOUNT" 2>/dev/null || \
    umount -l "$FUSE_MOUNT" 2>/dev/null || true
    sleep 0.5
fi

mkdir -p "$FUSE_MOUNT" /data /plex-strm
chown -R "$PUID:$PGID" "$FUSE_MOUNT" /data /plex-strm /app 2>/dev/null || true

if [ "$(id -u)" = "0" ]; then
    echo "[entrypoint] Starting as $PUID:$PGID"
    export USER=$(getent passwd "$PUID" | cut -d: -f1 || echo "debridarr")
    export HOME=/app
    exec gosu "$PUID:$PGID" env USER="$USER" HOME="$HOME" "$@"
else
    export USER=$(id -un 2>/dev/null || echo "debridarr")
    export HOME=/app
    exec "$@"
fi
