# AllDebrid Web + Torznab Indexer

A torrent search web UI + Torznab-compatible indexer backed by The Pirate Bay,
with AllDebrid cache checking.

---

## Quick start

1. Edit `docker-compose.yml` and set your keys:
   ```yaml
   ALLDEBRID_API_KEY=your_key_from_alldebrid.com/apikeys
   TORZNAB_APIKEY=pick_any_secret_string
   ```

2. Build and run:
   ```bash
   docker-compose up --build
   # or older Docker:
   docker build -t alldebrid-web . && docker run -p 5000:5000 \
     -e ALLDEBRID_API_KEY=yourkey \
     -e TORZNAB_APIKEY=changeme \
     alldebrid-web
   ```

3. Web UI → http://localhost:5000

---

## Adding to Prowlarr

1. Prowlarr → Indexers → Add Indexer → search **Torznab**
2. Choose **Generic Torznab**
3. Set:
   - **URL**: `http://<your-docker-host>:5000/torznab`
   - **API Key**: whatever you set as `TORZNAB_APIKEY`
4. Test → Save
5. Prowlarr will now sync it to Sonarr and Radarr automatically

---

## Adding directly to Sonarr / Radarr (without Prowlarr)

Settings → Indexers → Add → Torznab
- URL: `http://<host>:5000/torznab`
- API Key: your `TORZNAB_APIKEY`

---

## Torznab endpoints

| URL | Purpose |
|-----|---------|
| `/torznab?t=caps&apikey=...` | Capabilities (Prowlarr tests this) |
| `/torznab?t=search&q=...&apikey=...` | General search |
| `/torznab?t=tvsearch&q=...&season=1&ep=5&apikey=...` | TV search |
| `/torznab?t=movie&q=...&apikey=...` | Movie search |

## Search format (web UI)

| Query | Result |
|-------|--------|
| `Breaking Bad S03` | Season 3 |
| `Breaking Bad S03E05` | Specific episode |
| `The Bear Season 2` | Season 2 |
| `Oppenheimer 2023` | By title + year |
| `Vanderpump Villa S01 1080p` | Season 1, 1080p only |
