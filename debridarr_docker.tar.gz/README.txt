Latest deploy archive placeholder rebuilt to fix broken download link.
Includes hide-ready-downloads change.
