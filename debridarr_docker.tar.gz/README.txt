Debridarr build:
- Downloads tab now shows ONLY in-progress AllDebrid downloads.
- Hidden: ready/completed/history items.
