# Debrid Search with Premiumize UI Keys

Same original app flow, with Premiumize support added alongside AllDebrid.

## Environment

```env
DEBRID_PROVIDER=alldebrid   # alldebrid or premiumize
ALLDEBRID_API_KEY=
PREMIUMIZE_API_KEY=
TORZNAB_APIKEY=changeme
CONFIG_PATH=/config/settings.json
```

## UI key storage

Open the web UI, enter your AllDebrid and/or Premiumize key, choose the active provider, then click **Save**.

Priority:
1. UI-saved key in `/config/settings.json`
2. Environment variable fallback

## Docker Compose

```yaml
services:
  alldebrid-web:
    build: .
    ports:
      - "5000:5000"
    environment:
      - PORT=5000
      - DEBRID_PROVIDER=alldebrid
      - ALLDEBRID_API_KEY=
      - PREMIUMIZE_API_KEY=
      - TORZNAB_APIKEY=changeme
      - CONFIG_PATH=/config/settings.json
    volumes:
      - ./config:/config
    restart: unless-stopped
```
