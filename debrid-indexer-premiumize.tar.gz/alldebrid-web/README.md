# Debrid Indexer

A self-hosted torrent search web UI + Torznab indexer backed by The Pirate Bay, with cache checking and add support for **AllDebrid** and **Premiumize**.

---

## What it does

- Searches The Pirate Bay for movie/TV torrent metadata
- Checks whether results are instantly available on AllDebrid or Premiumize
- Exposes a Torznab API endpoint for Prowlarr, Sonarr, and Radarr
- Web UI for manual searching and adding a selected magnet to your debrid provider

---

## Requirements

- Docker
- One of:
  - AllDebrid API key: https://alldebrid.com/apikeys
  - Premiumize API key: https://www.premiumize.me/account

---

## Setup

### 1. Extract and configure

```bash
tar -xzf debrid-indexer-premiumize.tar.gz
cd alldebrid-web
```

Edit `docker-compose.yml` and set your provider/key:

```yaml
environment:
  - DEBRID_PROVIDER=premiumize   # alldebrid or premiumize
  - PREMIUMIZE_API_KEY=your_premiumize_api_key_here
  - ALLDEBRID_API_KEY=your_alldebrid_api_key_here
  - TORZNAB_APIKEY=changeme
```

`TORZNAB_APIKEY` is a password you make up — Prowlarr will use it to authenticate.

### 2. Build and run

```bash
docker compose up --build -d
```

Without Compose:

```bash
docker build -t debrid-indexer .
docker run -d -p 5000:5000 \
  -e DEBRID_PROVIDER=premiumize \
  -e PREMIUMIZE_API_KEY=your_key \
  -e TORZNAB_APIKEY=changeme \
  --restart unless-stopped \
  debrid-indexer
```

### 3. Open the web UI

```text
http://localhost:5000
```

The web UI has a provider dropdown, so you can test AllDebrid or Premiumize manually.

---

## Adding to Prowlarr

1. Go to **Prowlarr → Indexers → Add Indexer**
2. Search for **Torznab** and select **Generic Torznab**
3. Fill in:
   - **Name**: Debrid Indexer
   - **URL**: `http://<your-docker-host-ip>:5000/torznab`
   - **API Key**: whatever you set as `TORZNAB_APIKEY`
4. Click **Test**
5. Click **Save**

To force a provider from Prowlarr, add `?provider=premiumize` or `?provider=alldebrid` to the Torznab URL if your client supports query strings. Otherwise set `DEBRID_PROVIDER` in Docker.

---

## Torznab API endpoints

| URL | Description |
|-----|-------------|
| `/torznab?t=caps&apikey=...` | Capabilities |
| `/torznab?t=search&q=...&apikey=...` | General search |
| `/torznab?t=tvsearch&q=...&season=1&ep=5&apikey=...` | TV search |
| `/torznab?t=movie&q=...&apikey=...` | Movie search |

---

## Environment variables

| Variable | Required | Description |
|----------|----------|-------------|
| `DEBRID_PROVIDER` | No | `alldebrid` or `premiumize`; default `alldebrid` |
| `ALLDEBRID_API_KEY` | For AllDebrid | AllDebrid API key |
| `PREMIUMIZE_API_KEY` | For Premiumize | Premiumize API key |
| `TORZNAB_APIKEY` | Yes | Password for Torznab endpoint |
| `PORT` | No | Port to run on, default `5000` |

---

## Premiumize support

Premiumize cache checking uses `/api/cache/check` with `items[]` magnets. Adding uses `/api/transfer/create` with `src=<magnet>`.

---

## Notes

- Cached results sort first by default.
- AllDebrid cache checking still uses temporary upload/delete.
- Premiumize cache checking does not create a transfer; it only checks cache availability.
- Clicking **Add** creates a real transfer/job on the selected provider.
