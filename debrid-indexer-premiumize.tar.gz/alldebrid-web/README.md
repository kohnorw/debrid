# Debrid Search

Clean Flask rewrite with Premiumize and AllDebrid support.

## Docker / Portainer

Set the provider and key in `docker-compose.yml`:

```yaml
environment:
  - DEBRID_PROVIDER=premiumize
  - PREMIUMIZE_API_KEY=your_key_here
  - TORZNAB_APIKEY=changeme
```

Then deploy:

```bash
docker compose up -d --build
```

Open:

```text
http://SERVER-IP:5000
```

## Providers

Supported values:

```text
DEBRID_PROVIDER=premiumize
DEBRID_PROVIDER=alldebrid
```

Premiumize uses:

- `POST /api/cache/check` with `items[]`
- `POST /api/transfer/create` with `src`
- optional `PREMIUMIZE_FOLDER_ID`

AllDebrid uses:

- `POST /v4/magnet/upload` for cache check/add
- `POST /v4/magnet/delete` to clean temporary cache-check magnets

## Torznab / Prowlarr

URL:

```text
http://SERVER-IP:5000/torznab/api?t=caps&apikey=changeme
```

Base Torznab URL in Prowlarr:

```text
http://SERVER-IP:5000/torznab/api
```

API key:

```text
changeme
```

For Torznab cache checks, the app uses the env key for the configured `DEBRID_PROVIDER`.

## Web API

Search:

```bash
curl -s http://localhost:5000/api/search \
  -H 'Content-Type: application/json' \
  -d '{"provider":"premiumize","api_key":"YOUR_KEY","query":"Friends S01E01 1080p"}' | jq
```

Add:

```bash
curl -s http://localhost:5000/api/add \
  -H 'Content-Type: application/json' \
  -d '{"provider":"premiumize","api_key":"YOUR_KEY","hash":"INFO_HASH","name":"Name"}' | jq
```
