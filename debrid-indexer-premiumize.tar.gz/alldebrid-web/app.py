import os
import re
import urllib.parse
import requests
from datetime import datetime, timezone
from xml.sax.saxutils import escape as xml_escape
from flask import Flask, request, jsonify, render_template, Response

app = Flask(__name__)

# ── config ────────────────────────────────────────────────────────────────────

APIBAY_URLS = [
    "https://apibay.org/q.php",
    "https://apibay.nocensor.space/q.php",
    "https://thepiratebay.org/q.php",
]
ALLDEBRID_UPLOAD = "https://api.alldebrid.com/v4/magnet/upload"
ALLDEBRID_DELETE = "https://api.alldebrid.com/v4/magnet/delete"
PREMIUMIZE_CACHE_CHECK = "https://www.premiumize.me/api/cache/check"
PREMIUMIZE_TRANSFER_CREATE = "https://www.premiumize.me/api/transfer/create"

DEFAULT_PROVIDER = os.environ.get("DEBRID_PROVIDER", os.environ.get("PROVIDER", "alldebrid")).strip().lower()
AD_API_KEY     = os.environ.get("ALLDEBRID_API_KEY", "")
PM_API_KEY     = os.environ.get("PREMIUMIZE_API_KEY", "")
TORZNAB_APIKEY = os.environ.get("TORZNAB_APIKEY", "changeme")

# ── category maps ─────────────────────────────────────────────────────────────

# TPB category -> Newznab category ID
def tpb_to_newznab(tpb_cat, name=""):
    # Override based on name patterns — TPB often miscategorises
    name_up = name.upper()
    if re.search(r'S\d{2}E\d{2}|SEASON\s+\d+|\bS\d{2}\b', name_up):
        return 5000  # TV
    try:
        c = int(tpb_cat)
    except Exception:
        return 8000
    if 200 <= c < 300: return 2000   # Movies
    if 500 <= c < 600: return 5000   # TV
    if 300 <= c < 400: return 3000   # Audio
    return 8000                       # Other

NEWZNAB_CATS = {
    2000: "Movies",
    2010: "Movies/Foreign",
    2020: "Movies/Other",
    2030: "Movies/SD",
    2040: "Movies/HD",
    2045: "Movies/UHD",
    2050: "Movies/BluRay",
    2060: "Movies/3D",
    5000: "TV",
    5010: "TV/WEB-DL",
    5020: "TV/Foreign",
    5030: "TV/SD",
    5040: "TV/HD",
    5045: "TV/UHD",
    5050: "TV/Other",
    5060: "TV/Sport",
    5070: "TV/Anime",
    5080: "TV/Documentary",
    8000: "Other",
    8010: "Other/Misc",
}

# ── helpers ───────────────────────────────────────────────────────────────────

QUALITY_PATTERNS = re.compile(
    r'\b(2160p?|1080p?|720p?|480p?|4k|uhd|hdr|hdr10|dv|web-?dl|webrip|bluray|blu-ray|hevc|x265|x264|h264|h265|remux|proper|repack)\b',
    re.IGNORECASE
)

def fmt_size(b):
    try:
        return int(b)
    except Exception:
        return 0

def fmt_size_str(b):
    try:
        b = int(b)
    except Exception:
        return "?"
    if b > 1_000_000_000: return f"{b/1_000_000_000:.2f} GB"
    if b > 1_000_000:     return f"{b/1_000_000:.0f} MB"
    if b > 1_000:         return f"{b/1_000:.0f} KB"
    return f"{b} B"

def _sanitize(query):
    q = re.sub(r"[''`´]", "", query)
    q = re.sub(r"[^\w\s\-]", " ", q)
    return re.sub(r"\s+", " ", q).strip()

def parse_query(raw):
    season, episode, quality = None, None, []
    quality = QUALITY_PATTERNS.findall(raw)
    search_raw = QUALITY_PATTERNS.sub('', raw).strip()
    m = re.search(r'\bseason\s+(\d+)\b', search_raw, re.IGNORECASE)
    if m:
        season = int(m.group(1))
        search_raw = re.sub(r'\bseason\s+\d+\b', f'S{season:02d}', search_raw, flags=re.IGNORECASE)
    m = re.search(r'(?<![a-zA-Z])S(\d{1,2})(?:E(\d{1,2}))?(?![a-zA-Z0-9])', search_raw, re.IGNORECASE)
    if m:
        season = int(m.group(1))
        if m.group(2):
            episode = int(m.group(2))
    return ' '.join(search_raw.split()).strip(), season, episode, quality

def strip_season(query):
    t = re.sub(r'(?<![a-zA-Z])S\d{1,2}(?:E\d{1,2})?(?![a-zA-Z0-9])', '', query, flags=re.IGNORECASE)
    return ' '.join(t.split())

def filter_by_season(torrents, season, episode):
    if season is None:
        return torrents
    s_str = f"S{season:02d}"
    s_alt = f"SEASON {season}"
    out = []
    for t in torrents:
        nu = t.get("name", "").upper()
        if s_str not in nu and s_alt not in nu:
            continue
        others = re.findall(r'S(\d{2})E\d{2}', nu)
        if others and not all(int(s) == season for s in others):
            continue
        if episode is not None and f"E{episode:02d}" not in nu:
            continue
        out.append(t)
    return out

def filter_by_quality(torrents, quality):
    if not quality:
        return torrents
    out = []
    for t in torrents:
        name_up = t.get("name", "").upper()
        for q in quality:
            if q.upper().rstrip('P') in name_up:
                out.append(t)
                break
    return out if out else torrents

def _fetch(query, limit=40):
    queries = [query]
    sanitized = _sanitize(query)
    if sanitized.lower() != query.lower():
        queries.append(sanitized)
    for q in queries:
        for url in APIBAY_URLS:
            try:
                r = requests.get(url, params={"q": q, "cat": 0}, timeout=10)
                if r.status_code != 200:
                    continue
                data = r.json()
                if not data or (isinstance(data, list) and data[0].get("id") == "0"):
                    continue
                valid = [
                    x for x in data
                    if isinstance(x, dict)
                    and x.get("info_hash")
                    and re.fullmatch(r'[0-9a-fA-F]{40}', x["info_hash"])
                ]
                if valid:
                    return valid[:limit]
            except Exception:
                continue
    return []

def _make_magnet(torrent):
    h    = torrent["info_hash"].lower()
    name = urllib.parse.quote(torrent.get("name", ""), safe="")
    return f"magnet:?xt=urn:btih:{h}&dn={name}"

def normalize_provider(provider=None):
    provider = (provider or DEFAULT_PROVIDER or "alldebrid").strip().lower()
    aliases = {
        "ad": "alldebrid",
        "all-debrid": "alldebrid",
        "alldebrid": "alldebrid",
        "pm": "premiumize",
        "premiumize.me": "premiumize",
        "premiumize": "premiumize",
    }
    return aliases.get(provider, "alldebrid")

def default_api_key(provider):
    provider = normalize_provider(provider)
    return PM_API_KEY if provider == "premiumize" else AD_API_KEY

def _ad_post(api_key, torrents):
    if not torrents:
        return {}
    pairs = [("magnets[]", _make_magnet(t)) for t in torrents]
    body  = urllib.parse.urlencode(pairs)
    try:
        r = requests.post(
            ALLDEBRID_UPLOAD,
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/x-www-form-urlencoded"},
            data=body, timeout=15,
        )
        r.raise_for_status()
        return r.json()
    except requests.RequestException:
        return {}

def _delete_magnets(api_key, ids):
    for mid in ids:
        try:
            requests.post(
                ALLDEBRID_DELETE,
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/x-www-form-urlencoded"},
                data=urllib.parse.urlencode({"id": mid}), timeout=10,
            )
        except Exception:
            pass

def check_cache_alldebrid(api_key, torrents):
    result = _ad_post(api_key, torrents)
    if result.get("status") == "error":
        return {}
    ready_map, ids_to_delete = {}, []
    for m in result.get("data", {}).get("magnets", []):
        if m.get("error"):
            continue
        h = (m.get("hash") or "").lower()
        if h:
            ready_map[h] = bool(m.get("ready", False))
        if m.get("id"):
            ids_to_delete.append(m["id"])
    _delete_magnets(api_key, ids_to_delete)
    return ready_map

def check_cache_premiumize(api_key, torrents):
    if not torrents:
        return {}
    magnets = [_make_magnet(t) for t in torrents]
    pairs = [("items[]", m) for m in magnets]
    try:
        r = requests.post(
            PREMIUMIZE_CACHE_CHECK,
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/x-www-form-urlencoded"},
            data=urllib.parse.urlencode(pairs), timeout=15,
        )
        r.raise_for_status()
        data = r.json()
    except requests.RequestException:
        return {}
    if data.get("status") != "success":
        return {}
    responses = data.get("response", []) or []
    ready_map = {}
    for torrent, ready in zip(torrents, responses):
        h = torrent["info_hash"].lower()
        ready_map[h] = bool(ready)
    return ready_map

def check_cache(api_key, torrents, provider=None):
    provider = normalize_provider(provider)
    if provider == "premiumize":
        return check_cache_premiumize(api_key, torrents)
    return check_cache_alldebrid(api_key, torrents)

def add_magnet_alldebrid(api_key, torrent):
    result = _ad_post(api_key, [torrent])
    magnets = result.get("data", {}).get("magnets", [])
    if not magnets:
        return {"error": result.get("error", {}).get("message", "Unknown error")}
    m = magnets[0]
    if m.get("error"):
        return {"error": m["error"].get("message", "Unknown error")}
    return {"provider": "alldebrid", "name": m.get("name", torrent.get("name", "?")), "ready": bool(m.get("ready", False)), "id": m.get("id")}

def add_magnet_premiumize(api_key, torrent):
    magnet = _make_magnet(torrent)
    try:
        r = requests.post(
            PREMIUMIZE_TRANSFER_CREATE,
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/x-www-form-urlencoded"},
            data=urllib.parse.urlencode({"src": magnet}), timeout=20,
        )
        r.raise_for_status()
        data = r.json()
    except requests.RequestException as exc:
        return {"error": str(exc) or "Premiumize request failed"}
    if data.get("status") != "success":
        return {"error": data.get("message") or data.get("code") or "Premiumize transfer/create failed"}
    return {"provider": "premiumize", "name": data.get("name", torrent.get("name", "?")), "ready": True, "id": data.get("id")}

def add_magnet(api_key, torrent, provider=None):
    provider = normalize_provider(provider)
    if provider == "premiumize":
        return add_magnet_premiumize(api_key, torrent)
    return add_magnet_alldebrid(api_key, torrent)

def do_search(query, season=None, episode=None, quality=None, limit=40, api_key=None, provider=None):
    torrents = _fetch(query, limit)
    if not torrents and season is not None:
        fallback = strip_season(query)
        if fallback and fallback.lower() != query.lower():
            torrents = _fetch(fallback, limit * 2)
    if not torrents:
        return []
    filtered = filter_by_season(torrents, season, episode)
    if not filtered and season is not None:
        filtered = torrents
    if quality:
        filtered = filter_by_quality(filtered, quality)
    if api_key:
        ready_map = check_cache(api_key, filtered, provider)
    else:
        ready_map = {}
    results = []
    for t in filtered:
        h = t["info_hash"].lower()
        results.append({
            "hash":     h,
            "name":     t.get("name", "Unknown"),
            "size":     fmt_size(t.get("size", 0)),
            "size_str": fmt_size_str(t.get("size", 0)),
            "seeders":  int(t.get("seeders", 0) or 0),
            "leechers": int(t.get("leechers", 0) or 0),
            "category": tpb_to_newznab(t.get("category", 0), t.get("name", "")),
            "tpb_cat":  t.get("category", "0"),
            "cached":   ready_map.get(h, False),
        })
    results.sort(key=lambda x: (not x["cached"], -x["seeders"]))
    return results

# ── Torznab XML builder ───────────────────────────────────────────────────────

def torznab_caps():
    return '''<?xml version="1.0" encoding="UTF-8"?>
<caps>
  <server title="Debrid Indexer" />
  <limits default="40" max="100"/>
  <searching>
    <search available="yes" supportedParams="q"/>
    <tv-search available="yes" supportedParams="q,season,ep"/>
    <movie-search available="yes" supportedParams="q"/>
  </searching>
  <categories>
    <category id="2000" name="Movies">
      <subcat id="2040" name="Movies/HD"/>
      <subcat id="2045" name="Movies/UHD"/>
      <subcat id="2030" name="Movies/SD"/>
      <subcat id="2050" name="Movies/BluRay"/>
    </category>
    <category id="5000" name="TV">
      <subcat id="5040" name="TV/HD"/>
      <subcat id="5045" name="TV/UHD"/>
      <subcat id="5030" name="TV/SD"/>
      <subcat id="5010" name="TV/WEB-DL"/>
    </category>
    <category id="8000" name="Other"/>
  </categories>
</caps>'''

def torznab_results(results, query=""):
    now = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
    items = []
    for r in results:
        magnet = f"magnet:?xt=urn:btih:{r['hash']}&dn={urllib.parse.quote(r['name'], safe='')}"
        cached_attr = '<torznab:attr name="cached" value="1"/>' if r["cached"] else ''
        items.append(f"""    <item>
      <title>{xml_escape(r['name'])}</title>
      <guid>{xml_escape(magnet)}</guid>
      <link>{xml_escape(magnet)}</link>
      <pubDate>{now}</pubDate>
      <size>{r['size']}</size>
      <enclosure url="{xml_escape(magnet)}" length="{r['size']}" type="application/x-bittorrent"/>
      <torznab:attr name="magneturl" value="{xml_escape(magnet)}"/>
      <torznab:attr name="infohash" value="{r['hash']}"/>
      <torznab:attr name="seeders" value="{r['seeders']}"/>
      <torznab:attr name="leechers" value="{r['leechers']}"/>
      <torznab:attr name="size" value="{r['size']}"/>
      <torznab:attr name="category" value="{r['category']}"/>
      {cached_attr}
    </item>""")

    items_xml = "\n".join(items)
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:torznab="http://torznab.com/schemas/2015/feed">
  <channel>
    <title>Debrid Indexer</title>
    <description>TPB via debrid cache check</description>
    <link>http://localhost</link>
    <language>en-US</language>
    <pubDate>{now}</pubDate>
    <response xmlns="urn:newznab:api" offset="0" total="{len(results)}"/>
{items_xml}
  </channel>
</rss>'''

def xml_error(code, description):
    return Response(
        f'''<?xml version="1.0" encoding="UTF-8"?>
<error code="{code}" description="{xml_escape(description)}"/>''',
        mimetype="application/xml", status=400
    )

# ── routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")

# Torznab endpoint — Prowlarr points here
@app.route("/torznab")
@app.route("/torznab/api")
def torznab():
    # API key check
    apikey = request.args.get("apikey", "")
    if TORZNAB_APIKEY and apikey != TORZNAB_APIKEY:
        return xml_error(100, "Invalid API key")

    t = request.args.get("t", "").lower()

    # Capabilities
    if t == "caps":
        return Response(torznab_caps(), mimetype="application/xml")

    # Search / TV search / Movie search
    if t in ("search", "tvsearch", "movie"):
        q      = request.args.get("q", "").strip()
        season = request.args.get("season", "").strip()
        ep     = request.args.get("ep", "").strip()
        cat    = request.args.get("cat", "").strip()

        app.logger.info(f"Torznab {t}: q={q!r} season={season!r} ep={ep!r} cat={cat!r}")

        # Build search query from q + season/ep params
        query = q
        if season:
            try:
                s = int(season)
                query = f"{q} S{s:02d}" if q else f"S{s:02d}"
                if ep:
                    query += f"E{int(ep):02d}"
            except ValueError:
                pass

        # Prowlarr sends empty q to "browse" by category — fetch some results anyway
        if not query:
            app.logger.info("Empty query — fetching fallback results")
            cat_top = 0
            if cat and cat != "0":
                nums = [int(c) for c in cat.split(",") if c.strip().isdigit()]
                if nums:
                    cat_top = nums[0] // 1000  # 5 = TV, 2 = Movie
            fallback_q = "S01 OR S02" if cat_top == 5 else "1080p 2160p"
            raw = _fetch(fallback_q, 40) or _fetch("1080p", 40)
            fb_results = []
            for ti in raw:
                h = ti["info_hash"].lower()
                fb_results.append({
                    "hash":     h,
                    "name":     ti.get("name", "Unknown"),
                    "size":     fmt_size(ti.get("size", 0)),
                    "size_str": fmt_size_str(ti.get("size", 0)),
                    "seeders":  int(ti.get("seeders", 0) or 0),
                    "leechers": int(ti.get("leechers", 0) or 0),
                    "category": tpb_to_newznab(ti.get("category", 0), ti.get("name", "")),
                    "cached":   False,
                })
            return Response(torznab_results(fb_results, ""), mimetype="application/xml")

        parsed_q, parsed_s, parsed_ep, quality = parse_query(query)
        app.logger.info(f"Parsed: q={parsed_q!r} s={parsed_s} ep={parsed_ep}")

        provider = normalize_provider(request.args.get("provider", DEFAULT_PROVIDER))
        results = do_search(parsed_q, parsed_s, parsed_ep, quality, limit=40, api_key=default_api_key(provider), provider=provider)
        app.logger.info(f"Results: {len(results)}")

        # Category filter — TPB often miscategorises TV as Movies so we do a
        # loose match: if the filter would wipe all results, skip it entirely.
        if cat and cat != "0":
            requested = [int(c) for c in cat.split(",") if c.strip().isdigit() and c.strip() != "0"]
            if requested:
                # Broad match: 5030 requested matches anything in 5000-5999
                filtered = [r for r in results if any(
                    r["category"] == rc or r["category"] // 1000 == rc // 1000
                    for rc in requested
                )]
                # Only apply if we still have results — TPB miscategorises a lot
                if filtered:
                    results = filtered
                # else: skip filter, return everything

        return Response(torznab_results(results, q), mimetype="application/xml")

    # Unknown t= value — return empty caps-like response so Prowlarr doesn't error
    app.logger.warning(f"Unknown torznab function: {t!r}")
    return xml_error(202, f"Unknown function: {t}")

# Web UI search API
@app.route("/api/search", methods=["POST"])
def search():
    data    = request.json or {}
    provider = normalize_provider(data.get("provider", DEFAULT_PROVIDER))
    api_key = data.get("api_key", "").strip() or default_api_key(provider)
    query   = data.get("query", "").strip()

    if not api_key:
        return jsonify({"error": "API key required"}), 400
    if not query:
        return jsonify({"error": "Query required"}), 400

    parsed_q, season, episode, quality = parse_query(query)
    results = do_search(parsed_q, season, episode, quality, limit=40, api_key=api_key, provider=provider)

    return jsonify({
        "results": [
            {**r, "size": r["size_str"]}
            for r in results
        ],
        "total": len(results),
        "provider": provider
    })

@app.route("/api/add", methods=["POST"])
def add():
    data    = request.json or {}
    provider = normalize_provider(data.get("provider", DEFAULT_PROVIDER))
    api_key = data.get("api_key", "").strip() or default_api_key(provider)
    hash_   = data.get("hash", "").strip().lower()
    name    = data.get("name", "").strip()

    if not api_key or not hash_:
        return jsonify({"error": "api_key and hash required"}), 400

    result = add_magnet(api_key, {"info_hash": hash_, "name": name}, provider)
    if "error" in result:
        return jsonify(result), 400
    return jsonify(result)

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
