import os
import re
import json
import time
import urllib.parse
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional, Tuple
from xml.sax.saxutils import escape as xml_escape

import requests
from flask import Flask, Response, jsonify, render_template, request

app = Flask(__name__)

# -----------------------------------------------------------------------------
# Config
# -----------------------------------------------------------------------------

APP_TITLE = os.environ.get("APP_TITLE", "Debrid Search")
PORT = int(os.environ.get("PORT", "5000"))
TORZNAB_APIKEY = os.environ.get("TORZNAB_APIKEY", "changeme")
DEFAULT_PROVIDER = os.environ.get("DEBRID_PROVIDER", "premiumize").strip().lower()

ALLDEBRID_API_KEY = os.environ.get("ALLDEBRID_API_KEY", "")
PREMIUMIZE_API_KEY = os.environ.get("PREMIUMIZE_API_KEY", "")
PREMIUMIZE_FOLDER_ID = os.environ.get("PREMIUMIZE_FOLDER_ID", "")

REQUEST_TIMEOUT = int(os.environ.get("REQUEST_TIMEOUT", "20"))
SEARCH_LIMIT = int(os.environ.get("SEARCH_LIMIT", "50"))

APIBAY_URLS = [
    x.strip()
    for x in os.environ.get(
        "APIBAY_URLS",
        "https://apibay.org/q.php,https://apibay.nocensor.space/q.php,https://thepiratebay.org/q.php",
    ).split(",")
    if x.strip()
]

SESSION = requests.Session()
SESSION.headers.update({"User-Agent": "debrid-search/2.0"})

# -----------------------------------------------------------------------------
# Models and formatting
# -----------------------------------------------------------------------------

QUALITY_RE = re.compile(
    r"\b(2160p|1080p|720p|480p|4k|uhd|hdr10?|dv|dolby[ ._-]?vision|web[ ._-]?dl|webrip|bluray|blu[ ._-]?ray|remux|x265|x264|h265|h264|hevc|av1|proper|repack)\b",
    re.I,
)
HASH_RE = re.compile(r"^[0-9a-fA-F]{40}$")
VIDEO_RE = re.compile(r"\.(mkv|mp4|avi|mov|m4v|ts|webm)$", re.I)

NEWZNAB_CATS = {
    2000: "Movies",
    2030: "Movies/SD",
    2040: "Movies/HD",
    2045: "Movies/UHD",
    2050: "Movies/BluRay",
    5000: "TV",
    5030: "TV/SD",
    5040: "TV/HD",
    5045: "TV/UHD",
    5010: "TV/WEB-DL",
    5070: "TV/Anime",
    8000: "Other",
}

@dataclass
class Torrent:
    name: str
    info_hash: str
    size: int = 0
    seeders: int = 0
    leechers: int = 0
    tpb_category: str = "0"

    @property
    def magnet(self) -> str:
        return make_magnet(self.info_hash, self.name)

    @property
    def category(self) -> int:
        return tpb_to_newznab(self.tpb_category, self.name)


def tpb_to_newznab(tpb_cat: Any, name: str = "") -> int:
    up = name.upper()
    if re.search(r"S\d{1,2}E\d{1,3}|SEASON[ ._-]?\d+|\bS\d{1,2}\b", up):
        if "2160" in up or "4K" in up or "UHD" in up:
            return 5045
        if "720" in up or "1080" in up:
            return 5040
        return 5000
    try:
        c = int(tpb_cat)
    except Exception:
        return 8000
    if 200 <= c < 300:
        if "2160" in up or "4K" in up or "UHD" in up:
            return 2045
        if "BLURAY" in up or "BLU-RAY" in up:
            return 2050
        if "720" in up or "1080" in up:
            return 2040
        return 2000
    if 500 <= c < 600:
        return 5000
    return 8000


def make_magnet(info_hash: str, name: str = "") -> str:
    dn = urllib.parse.quote(name or info_hash, safe="")
    trackers = [
        "udp://tracker.opentrackr.org:1337/announce",
        "udp://open.stealth.si:80/announce",
        "udp://tracker.torrent.eu.org:451/announce",
    ]
    tr = "".join("&tr=" + urllib.parse.quote(t, safe="") for t in trackers)
    return f"magnet:?xt=urn:btih:{info_hash.lower()}&dn={dn}{tr}"


def bytes_int(value: Any) -> int:
    try:
        return int(value or 0)
    except Exception:
        return 0


def size_str(num: Any) -> str:
    b = bytes_int(num)
    if b >= 1_000_000_000_000:
        return f"{b/1_000_000_000_000:.2f} TB"
    if b >= 1_000_000_000:
        return f"{b/1_000_000_000:.2f} GB"
    if b >= 1_000_000:
        return f"{b/1_000_000:.0f} MB"
    if b >= 1_000:
        return f"{b/1_000:.0f} KB"
    return f"{b} B"


def sanitize_query(q: str) -> str:
    q = re.sub(r"['’`´]", "", q or "")
    q = re.sub(r"[^\w\s.\-]", " ", q)
    return re.sub(r"\s+", " ", q).strip()


def parse_query(raw: str) -> Tuple[str, Optional[int], Optional[int], List[str]]:
    raw = raw or ""
    qualities = QUALITY_RE.findall(raw)
    q = QUALITY_RE.sub(" ", raw)
    season = episode = None

    m = re.search(r"\bseason[ ._-]?(\d{1,2})\b", q, re.I)
    if m:
        season = int(m.group(1))
        q = re.sub(r"\bseason[ ._-]?\d{1,2}\b", f"S{season:02d}", q, flags=re.I)

    m = re.search(r"\bS(\d{1,2})E(\d{1,3})\b", q, re.I)
    if m:
        season, episode = int(m.group(1)), int(m.group(2))
    else:
        m = re.search(r"\bS(\d{1,2})\b", q, re.I)
        if m:
            season = int(m.group(1))

    return sanitize_query(q), season, episode, list({x.lower() for x in qualities})

# -----------------------------------------------------------------------------
# Torrent source
# -----------------------------------------------------------------------------

def fetch_torrents(query: str, limit: int = SEARCH_LIMIT) -> List[Torrent]:
    query = sanitize_query(query)
    if not query:
        return []
    attempts = [query]
    compact = query.replace(".", " ")
    if compact != query:
        attempts.append(compact)

    seen = set()
    for q in attempts:
        for url in APIBAY_URLS:
            try:
                resp = SESSION.get(url, params={"q": q, "cat": 0}, timeout=REQUEST_TIMEOUT)
                if resp.status_code != 200:
                    continue
                data = resp.json()
            except Exception as e:
                app.logger.warning("source failed url=%s q=%s error=%s", url, q, e)
                continue
            if not isinstance(data, list) or not data or data[0].get("id") == "0":
                continue
            out: List[Torrent] = []
            for row in data:
                if not isinstance(row, dict):
                    continue
                h = str(row.get("info_hash", "")).lower()
                if not HASH_RE.match(h) or h in seen:
                    continue
                seen.add(h)
                out.append(Torrent(
                    name=str(row.get("name") or h),
                    info_hash=h,
                    size=bytes_int(row.get("size")),
                    seeders=bytes_int(row.get("seeders")),
                    leechers=bytes_int(row.get("leechers")),
                    tpb_category=str(row.get("category") or "0"),
                ))
            if out:
                return out[:limit]
    return []


def filter_torrents(torrents: List[Torrent], season: Optional[int], episode: Optional[int], qualities: List[str]) -> List[Torrent]:
    filtered = torrents
    if season is not None:
        s = f"S{season:02d}"
        season_re = re.compile(rf"(\b{s}\b|season[ ._-]?0?{season}\b)", re.I)
        tmp = [t for t in filtered if season_re.search(t.name)]
        if tmp:
            filtered = tmp
        if episode is not None:
            e = f"E{episode:02d}"
            tmp = [t for t in filtered if re.search(rf"\bS{season:02d}{e}\b|\b{season}x{episode:02d}\b", t.name, re.I)]
            if tmp:
                filtered = tmp
    if qualities:
        tmp = []
        for t in filtered:
            up = t.name.lower()
            if any(q.rstrip("p") in up or q in up for q in qualities):
                tmp.append(t)
        if tmp:
            filtered = tmp
    return filtered

# -----------------------------------------------------------------------------
# Debrid providers
# -----------------------------------------------------------------------------

class DebridError(Exception):
    pass

class BaseProvider:
    name = "base"
    label = "Base"

    def __init__(self, api_key: str):
        self.api_key = api_key.strip()
        if not self.api_key:
            raise DebridError("API key required")

    def check_cache(self, torrents: List[Torrent]) -> Dict[str, Dict[str, Any]]:
        raise NotImplementedError

    def add(self, torrent: Torrent) -> Dict[str, Any]:
        raise NotImplementedError

    def test(self) -> Dict[str, Any]:
        return {"ok": True, "provider": self.name}

class PremiumizeProvider(BaseProvider):
    name = "premiumize"
    label = "Premiumize"
    base = "https://www.premiumize.me/api"

    def _request(self, method: str, path: str, **kwargs: Any) -> Dict[str, Any]:
        headers = kwargs.pop("headers", {}) or {}
        headers["Authorization"] = f"Bearer {self.api_key}"
        url = self.base + path
        resp = SESSION.request(method, url, headers=headers, timeout=REQUEST_TIMEOUT, **kwargs)
        try:
            data = resp.json()
        except Exception:
            raise DebridError(f"Premiumize returned HTTP {resp.status_code}: {resp.text[:200]}")
        if data.get("status") == "error":
            raise DebridError(data.get("message") or data.get("code") or "Premiumize API error")
        if resp.status_code >= 400:
            raise DebridError(data.get("message") or f"Premiumize HTTP {resp.status_code}")
        return data

    def test(self) -> Dict[str, Any]:
        data = self._request("GET", "/account/info")
        return {"ok": True, "provider": self.name, "customer_id": data.get("customer_id"), "premium_until": data.get("premium_until")}

    def check_cache(self, torrents: List[Torrent]) -> Dict[str, Dict[str, Any]]:
        if not torrents:
            return {}
        items = [("items[]", t.magnet) for t in torrents]
        data = self._request("POST", "/cache/check", data=items)
        responses = data.get("response") or []
        filenames = data.get("filename") or []
        filesizes = data.get("filesize") or []
        out: Dict[str, Dict[str, Any]] = {}
        for idx, t in enumerate(torrents):
            cached = bool(responses[idx]) if idx < len(responses) else False
            out[t.info_hash] = {
                "cached": cached,
                "cached_name": filenames[idx] if idx < len(filenames) else None,
                "cached_size": bytes_int(filesizes[idx]) if idx < len(filesizes) else 0,
            }
        return out

    def add(self, torrent: Torrent) -> Dict[str, Any]:
        payload: List[Tuple[str, str]] = [("src", torrent.magnet)]
        if PREMIUMIZE_FOLDER_ID:
            payload.append(("folder_id", PREMIUMIZE_FOLDER_ID))
        data = self._request("POST", "/transfer/create", data=payload)
        return {
            "id": data.get("id"),
            "name": data.get("name") or torrent.name,
            "ready": False,
            "status": "queued",
            "provider": self.name,
        }

class AllDebridProvider(BaseProvider):
    name = "alldebrid"
    label = "AllDebrid"
    upload_url = "https://api.alldebrid.com/v4/magnet/upload"
    delete_url = "https://api.alldebrid.com/v4/magnet/delete"
    user_url = "https://api.alldebrid.com/v4/user"

    def _post(self, url: str, data: Any) -> Dict[str, Any]:
        resp = SESSION.post(url, headers={"Authorization": f"Bearer {self.api_key}"}, data=data, timeout=REQUEST_TIMEOUT)
        try:
            payload = resp.json()
        except Exception:
            raise DebridError(f"AllDebrid returned HTTP {resp.status_code}: {resp.text[:200]}")
        if payload.get("status") == "error":
            err = payload.get("error") or {}
            raise DebridError(err.get("message") or err.get("code") or "AllDebrid API error")
        return payload

    def test(self) -> Dict[str, Any]:
        resp = SESSION.get(self.user_url, headers={"Authorization": f"Bearer {self.api_key}"}, timeout=REQUEST_TIMEOUT)
        data = resp.json()
        if data.get("status") == "error":
            err = data.get("error") or {}
            raise DebridError(err.get("message") or "AllDebrid API error")
        return {"ok": True, "provider": self.name}

    def _upload(self, torrents: List[Torrent]) -> Dict[str, Any]:
        pairs = [("magnets[]", t.magnet) for t in torrents]
        return self._post(self.upload_url, pairs)

    def check_cache(self, torrents: List[Torrent]) -> Dict[str, Dict[str, Any]]:
        if not torrents:
            return {}
        data = self._upload(torrents)
        out: Dict[str, Dict[str, Any]] = {}
        delete_ids = []
        for m in (data.get("data") or {}).get("magnets", []):
            h = str(m.get("hash") or "").lower()
            if h:
                out[h] = {"cached": bool(m.get("ready")), "cached_name": m.get("name"), "cached_size": bytes_int(m.get("size"))}
            if m.get("id"):
                delete_ids.append(m["id"])
        for mid in delete_ids:
            try:
                self._post(self.delete_url, [("id", mid)])
            except Exception:
                pass
        return out

    def add(self, torrent: Torrent) -> Dict[str, Any]:
        data = self._upload([torrent])
        magnets = (data.get("data") or {}).get("magnets") or []
        if not magnets:
            raise DebridError("AllDebrid did not return a magnet result")
        m = magnets[0]
        if m.get("error"):
            err = m.get("error") or {}
            raise DebridError(err.get("message") or "AllDebrid add failed")
        return {"id": m.get("id"), "name": m.get("name") or torrent.name, "ready": bool(m.get("ready")), "status": "ready" if m.get("ready") else "queued", "provider": self.name}

PROVIDERS = {"premiumize": PremiumizeProvider, "alldebrid": AllDebridProvider}


def get_provider(provider_name: Optional[str] = None, api_key: Optional[str] = None) -> BaseProvider:
    name = (provider_name or DEFAULT_PROVIDER or "premiumize").strip().lower()
    if name not in PROVIDERS:
        raise DebridError(f"Unknown provider '{name}'. Use premiumize or alldebrid.")
    key = (api_key or "").strip()
    if not key:
        key = PREMIUMIZE_API_KEY if name == "premiumize" else ALLDEBRID_API_KEY
    return PROVIDERS[name](key)

# -----------------------------------------------------------------------------
# Search service
# -----------------------------------------------------------------------------

def search_service(query: str, provider_name: Optional[str], api_key: Optional[str], limit: int = SEARCH_LIMIT) -> List[Dict[str, Any]]:
    parsed_q, season, episode, qualities = parse_query(query)
    torrents = fetch_torrents(parsed_q, limit)
    if not torrents and season is not None:
        fallback = re.sub(r"\bS\d{1,2}(?:E\d{1,3})?\b", "", parsed_q, flags=re.I).strip()
        if fallback:
            torrents = fetch_torrents(fallback, limit * 2)
    torrents = filter_torrents(torrents, season, episode, qualities)

    cache: Dict[str, Dict[str, Any]] = {}
    cache_error = None
    try:
        provider = get_provider(provider_name, api_key)
        cache = provider.check_cache(torrents)
    except Exception as e:
        cache_error = str(e)
        app.logger.warning("cache check failed: %s", e)

    results: List[Dict[str, Any]] = []
    for t in torrents:
        c = cache.get(t.info_hash, {})
        results.append({
            "hash": t.info_hash,
            "name": t.name,
            "magnet": t.magnet,
            "size_bytes": t.size,
            "size": size_str(t.size),
            "seeders": t.seeders,
            "leechers": t.leechers,
            "category": t.category,
            "category_name": NEWZNAB_CATS.get(t.category, "Other"),
            "cached": bool(c.get("cached")),
            "cached_name": c.get("cached_name"),
            "cached_size": size_str(c.get("cached_size")) if c.get("cached_size") else None,
            "cache_error": cache_error,
        })
    results.sort(key=lambda r: (not r["cached"], -r["seeders"], -r["size_bytes"]))
    return results

# -----------------------------------------------------------------------------
# Torznab XML
# -----------------------------------------------------------------------------

def torznab_caps() -> str:
    return '''<?xml version="1.0" encoding="UTF-8"?>
<caps>
  <server title="Debrid Search" />
  <limits default="50" max="100"/>
  <searching>
    <search available="yes" supportedParams="q"/>
    <tv-search available="yes" supportedParams="q,season,ep"/>
    <movie-search available="yes" supportedParams="q"/>
  </searching>
  <categories>
    <category id="2000" name="Movies"><subcat id="2040" name="Movies/HD"/><subcat id="2045" name="Movies/UHD"/></category>
    <category id="5000" name="TV"><subcat id="5040" name="TV/HD"/><subcat id="5045" name="TV/UHD"/></category>
    <category id="8000" name="Other"/>
  </categories>
</caps>'''


def torznab_results(results: List[Dict[str, Any]]) -> str:
    now = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
    items = []
    for r in results:
        attrs = [
            f'<torznab:attr name="magneturl" value="{xml_escape(r["magnet"])}"/>',
            f'<torznab:attr name="infohash" value="{r["hash"]}"/>',
            f'<torznab:attr name="seeders" value="{r["seeders"]}"/>',
            f'<torznab:attr name="leechers" value="{r["leechers"]}"/>',
            f'<torznab:attr name="size" value="{r["size_bytes"]}"/>',
            f'<torznab:attr name="category" value="{r["category"]}"/>',
        ]
        if r.get("cached"):
            attrs.append('<torznab:attr name="cached" value="1"/>')
        items.append(f'''    <item>
      <title>{xml_escape(r["name"])}</title>
      <guid isPermaLink="false">{r["hash"]}</guid>
      <link>{xml_escape(r["magnet"])}</link>
      <pubDate>{now}</pubDate>
      <size>{r["size_bytes"]}</size>
      <category>{r["category_name"]}</category>
      <enclosure url="{xml_escape(r["magnet"])}" length="{r["size_bytes"]}" type="application/x-bittorrent"/>
      {' '.join(attrs)}
    </item>''')
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:torznab="http://torznab.com/schemas/2015/feed">
  <channel>
    <title>Debrid Search</title>
    <description>Cached torrent search for Premiumize and AllDebrid</description>
    <link>http://localhost</link>
    <language>en-US</language>
    <pubDate>{now}</pubDate>
    <response xmlns="urn:newznab:api" offset="0" total="{len(results)}"/>
{chr(10).join(items)}
  </channel>
</rss>'''


def xml_error(code: int, description: str, status: int = 400) -> Response:
    return Response(f'''<?xml version="1.0" encoding="UTF-8"?>\n<error code="{code}" description="{xml_escape(description)}"/>''', mimetype="application/xml", status=status)

# -----------------------------------------------------------------------------
# Routes
# -----------------------------------------------------------------------------

@app.get("/")
def index() -> str:
    return render_template("index.html", app_title=APP_TITLE, default_provider=DEFAULT_PROVIDER)

@app.get("/health")
def health() -> Response:
    return jsonify({"ok": True, "provider": DEFAULT_PROVIDER, "sources": APIBAY_URLS})

@app.get("/api/config")
def config() -> Response:
    return jsonify({
        "app_title": APP_TITLE,
        "default_provider": DEFAULT_PROVIDER,
        "providers": [{"id": k, "label": cls.label} for k, cls in PROVIDERS.items()],
        "has_env_key": {"premiumize": bool(PREMIUMIZE_API_KEY), "alldebrid": bool(ALLDEBRID_API_KEY)},
    })

@app.post("/api/test")
def api_test() -> Response:
    data = request.get_json(silent=True) or {}
    try:
        provider = get_provider(data.get("provider"), data.get("api_key"))
        return jsonify(provider.test())
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400

@app.post("/api/search")
def api_search() -> Response:
    data = request.get_json(silent=True) or {}
    query = str(data.get("query") or "").strip()
    if not query:
        return jsonify({"error": "Query required"}), 400
    provider = data.get("provider") or DEFAULT_PROVIDER
    api_key = data.get("api_key") or ""
    results = search_service(query, provider, api_key, SEARCH_LIMIT)
    return jsonify({"results": results, "total": len(results), "provider": provider})

@app.post("/api/add")
def api_add() -> Response:
    data = request.get_json(silent=True) or {}
    provider_name = data.get("provider") or DEFAULT_PROVIDER
    api_key = data.get("api_key") or ""
    h = str(data.get("hash") or "").strip().lower()
    name = str(data.get("name") or h).strip()
    if not HASH_RE.match(h):
        return jsonify({"error": "Valid 40-character info hash required"}), 400
    try:
        provider = get_provider(provider_name, api_key)
        result = provider.add(Torrent(name=name, info_hash=h))
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.get("/torznab")
@app.get("/torznab/api")
def torznab() -> Response:
    apikey = request.args.get("apikey", "")
    if TORZNAB_APIKEY and apikey != TORZNAB_APIKEY:
        return xml_error(100, "Invalid API key")
    t = request.args.get("t", "").lower()
    if t == "caps":
        return Response(torznab_caps(), mimetype="application/xml")
    if t not in ("search", "tvsearch", "movie"):
        return xml_error(202, f"Unknown function: {t}")

    q = request.args.get("q", "").strip()
    season = request.args.get("season", "").strip()
    ep = request.args.get("ep", "").strip()
    cat = request.args.get("cat", "").strip()
    provider = request.args.get("provider", DEFAULT_PROVIDER)
    api_key = request.args.get("debrid_key", "")

    query = q
    if season:
        try:
            query = f"{q} S{int(season):02d}"
            if ep:
                query += f"E{int(ep):02d}"
        except Exception:
            pass
    if not query:
        query = "1080p"

    results = search_service(query, provider, api_key, SEARCH_LIMIT)
    if cat and cat != "0":
        requested = [int(x) for x in cat.split(",") if x.strip().isdigit() and x.strip() != "0"]
        if requested:
            filtered = [r for r in results if any(r["category"] == rc or r["category"] // 1000 == rc // 1000 for rc in requested)]
            if filtered:
                results = filtered
    return Response(torznab_results(results), mimetype="application/xml")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=PORT, debug=False)
