# premiumize-web

A minimal web UI + Torznab indexer that searches The Pirate Bay and checks
instant availability via **Premiumize**.

## Features

- Search TPB torrents and see which are instantly cached on Premiumize
- **▶ Play** button on cached results — fetches direct links via `directdl` and opens them in your browser or media player
- **Add** button to send a magnet straight to your Premiumize cloud
- **Verify** button to confirm your API key and see premium status / expiry
- Torznab endpoint for Prowlarr/Sonarr/Radarr

## Quick start

```bash
# With Docker
PREMIUMIZE_API_KEY=your_key docker compose up

# Without Docker
pip install -r requirements.txt
PREMIUMIZE_API_KEY=your_key python app.py
```

Then open http://localhost:5000

Your API key is at https://www.premiumize.me/account

## Environment variables

| Variable             | Default    | Purpose                                |
|----------------------|------------|----------------------------------------|
| `PREMIUMIZE_API_KEY` | *(empty)*  | Pre-fills the API key in the UI        |
| `TORZNAB_APIKEY`     | `changeme` | Protects the `/torznab` endpoint       |
| `PORT`               | `5000`     | Port the server listens on             |

## API endpoints

| Method | Path           | Description                                   |
|--------|----------------|-----------------------------------------------|
| POST   | `/api/search`  | Search TPB + check Premiumize cache           |
| POST   | `/api/add`     | Add a magnet to Premiumize cloud transfers    |
| POST   | `/api/links`   | Get direct play/download links via directdl   |
| POST   | `/api/account` | Verify key + return premium status            |
| GET    | `/torznab`     | Torznab-compatible XML indexer                |

## Torznab (Prowlarr)

Point Prowlarr at `http://your-host:5000/torznab` with API key `changeme`
(or whatever you set `TORZNAB_APIKEY` to).
